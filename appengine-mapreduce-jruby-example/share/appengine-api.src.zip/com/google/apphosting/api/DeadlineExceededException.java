/*    */ package com.google.apphosting.api;
/*    */ 
/*    */ public class DeadlineExceededException extends RuntimeException
/*    */ {
/*    */   public DeadlineExceededException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DeadlineExceededException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.api.DeadlineExceededException
 * JD-Core Version:    0.6.0
 */