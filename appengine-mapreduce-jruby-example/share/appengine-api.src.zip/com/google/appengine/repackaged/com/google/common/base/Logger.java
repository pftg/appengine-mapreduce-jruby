package com.google.appengine.repackaged.com.google.common.base;

import com.google.common.annotations.GoogleInternal;

@Deprecated
@GoogleInternal
public abstract interface Logger
{
  public static final int DEBUG_LVL = 0;
  public static final int EVENT_LVL = 1;
  public static final int ERROR_LVL = 2;
  public static final int SILENT_LVL = 3;

  public abstract void setThreshold(int paramInt);

  public abstract int getThreshold();

  public abstract void logDebug(String paramString);

  public abstract void logEvent(String paramString);

  public abstract void logTimedEvent(String paramString, long paramLong1, long paramLong2);

  public abstract void logException(Throwable paramThrowable, String paramString);

  public abstract void logException(Throwable paramThrowable);

  public abstract void logSevereException(Throwable paramThrowable);

  public abstract void logSevereException(Throwable paramThrowable, String paramString);

  public abstract void logError(String paramString);

  public abstract void setErrorEmail(String paramString);

  public abstract void close();

  public abstract void setThreadTag(String paramString);

  public abstract String getThreadTag();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Logger
 * JD-Core Version:    0.6.0
 */