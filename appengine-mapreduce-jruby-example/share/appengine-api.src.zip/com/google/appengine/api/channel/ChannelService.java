package com.google.appengine.api.channel;

import javax.servlet.http.HttpServletRequest;

public abstract interface ChannelService
{
  public abstract String createChannel(String paramString);

  public abstract void sendMessage(ChannelMessage paramChannelMessage);

  public abstract ChannelMessage parseMessage(HttpServletRequest paramHttpServletRequest);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.channel.ChannelService
 * JD-Core Version:    0.6.0
 */