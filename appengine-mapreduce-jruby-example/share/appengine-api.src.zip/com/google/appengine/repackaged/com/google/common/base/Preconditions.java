/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Preconditions
/*     */ {
/*     */   public static void checkArgument(boolean expression)
/*     */   {
/*  73 */     if (!expression)
/*  74 */       throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   public static void checkArgument(boolean expression, @Nullable Object errorMessage)
/*     */   {
/*  89 */     if (!expression)
/*  90 */       throw new IllegalArgumentException(String.valueOf(errorMessage));
/*     */   }
/*     */ 
/*     */   public static void checkArgument(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object[] errorMessageArgs)
/*     */   {
/* 116 */     if (!expression)
/* 117 */       throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
/*     */   }
/*     */ 
/*     */   public static void checkState(boolean expression)
/*     */   {
/* 130 */     if (!expression)
/* 131 */       throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public static void checkState(boolean expression, @Nullable Object errorMessage)
/*     */   {
/* 146 */     if (!expression)
/* 147 */       throw new IllegalStateException(String.valueOf(errorMessage));
/*     */   }
/*     */ 
/*     */   public static void checkState(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object[] errorMessageArgs)
/*     */   {
/* 173 */     if (!expression)
/* 174 */       throw new IllegalStateException(format(errorMessageTemplate, errorMessageArgs));
/*     */   }
/*     */ 
/*     */   public static <T> T checkNotNull(T reference)
/*     */   {
/* 188 */     if (reference == null) {
/* 189 */       throw new NullPointerException();
/*     */     }
/* 191 */     return reference;
/*     */   }
/*     */ 
/*     */   public static <T> T checkNotNull(T reference, @Nullable Object errorMessage)
/*     */   {
/* 205 */     if (reference == null) {
/* 206 */       throw new NullPointerException(String.valueOf(errorMessage));
/*     */     }
/* 208 */     return reference;
/*     */   }
/*     */ 
/*     */   public static <T> T checkNotNull(T reference, @Nullable String errorMessageTemplate, @Nullable Object[] errorMessageArgs)
/*     */   {
/* 231 */     if (reference == null)
/*     */     {
/* 233 */       throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
/*     */     }
/*     */ 
/* 236 */     return reference;
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <T extends Iterable<?>> T checkContentsNotNull(T iterable)
/*     */   {
/* 260 */     if (containsOrIsNull(iterable)) {
/* 261 */       throw new NullPointerException();
/*     */     }
/* 263 */     return iterable;
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <T extends Iterable<?>> T checkContentsNotNull(T iterable, @Nullable Object errorMessage)
/*     */   {
/* 290 */     if (containsOrIsNull(iterable)) {
/* 291 */       throw new NullPointerException(String.valueOf(errorMessage));
/*     */     }
/* 293 */     return iterable;
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <T extends Iterable<?>> T checkContentsNotNull(T iterable, @Nullable String errorMessageTemplate, @Nullable Object[] errorMessageArgs)
/*     */   {
/* 328 */     if (containsOrIsNull(iterable)) {
/* 329 */       throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
/*     */     }
/*     */ 
/* 332 */     return iterable;
/*     */   }
/*     */   @GoogleInternal
/*     */   private static boolean containsOrIsNull(@Nullable Iterable<?> iterable) {
/* 337 */     if (iterable == null) {
/* 338 */       return true;
/*     */     }
/*     */ 
/* 341 */     if ((iterable instanceof Collection)) {
/* 342 */       Collection collection = (Collection)iterable;
/*     */       try {
/* 344 */         return collection.contains(null);
/*     */       }
/*     */       catch (NullPointerException e) {
/* 347 */         return false;
/*     */       }
/*     */     }
/* 350 */     for (Iterator i$ = iterable.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 351 */       if (element == null) {
/* 352 */         return true;
/*     */       }
/*     */     }
/* 355 */     return false;
/*     */   }
/*     */ 
/*     */   public static int checkElementIndex(int index, int size)
/*     */   {
/* 402 */     return checkElementIndex(index, size, "index");
/*     */   }
/*     */ 
/*     */   public static int checkElementIndex(int index, int size, @Nullable String desc)
/*     */   {
/* 422 */     if ((index < 0) || (index >= size)) {
/* 423 */       throw new IndexOutOfBoundsException(badElementIndex(index, size, desc));
/*     */     }
/* 425 */     return index;
/*     */   }
/*     */ 
/*     */   private static String badElementIndex(int index, int size, String desc) {
/* 429 */     if (index < 0)
/* 430 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) });
/* 431 */     if (size < 0) {
/* 432 */       throw new IllegalArgumentException("negative size: " + size);
/*     */     }
/* 434 */     return format("%s (%s) must be less than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/*     */   }
/*     */ 
/*     */   public static int checkPositionIndex(int index, int size)
/*     */   {
/* 452 */     return checkPositionIndex(index, size, "index");
/*     */   }
/*     */ 
/*     */   public static int checkPositionIndex(int index, int size, @Nullable String desc)
/*     */   {
/* 472 */     if ((index < 0) || (index > size)) {
/* 473 */       throw new IndexOutOfBoundsException(badPositionIndex(index, size, desc));
/*     */     }
/* 475 */     return index;
/*     */   }
/*     */ 
/*     */   private static String badPositionIndex(int index, int size, String desc) {
/* 479 */     if (index < 0)
/* 480 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) });
/* 481 */     if (size < 0) {
/* 482 */       throw new IllegalArgumentException("negative size: " + size);
/*     */     }
/* 484 */     return format("%s (%s) must not be greater than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/*     */   }
/*     */ 
/*     */   public static void checkPositionIndexes(int start, int end, int size)
/*     */   {
/* 505 */     if ((start < 0) || (end < start) || (end > size))
/* 506 */       throw new IndexOutOfBoundsException(badPositionIndexes(start, end, size));
/*     */   }
/*     */ 
/*     */   private static String badPositionIndexes(int start, int end, int size)
/*     */   {
/* 511 */     if ((start < 0) || (start > size)) {
/* 512 */       return badPositionIndex(start, size, "start index");
/*     */     }
/* 514 */     if ((end < 0) || (end > size)) {
/* 515 */       return badPositionIndex(end, size, "end index");
/*     */     }
/*     */ 
/* 518 */     return format("end index (%s) must not be less than start index (%s)", new Object[] { Integer.valueOf(end), Integer.valueOf(start) });
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static String format(String template, @Nullable Object[] args)
/*     */   {
/* 536 */     template = String.valueOf(template);
/*     */ 
/* 539 */     StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);
/*     */ 
/* 541 */     int templateStart = 0;
/* 542 */     int i = 0;
/* 543 */     while (i < args.length) {
/* 544 */       int placeholderStart = template.indexOf("%s", templateStart);
/* 545 */       if (placeholderStart == -1) {
/*     */         break;
/*     */       }
/* 548 */       builder.append(template.substring(templateStart, placeholderStart));
/* 549 */       builder.append(args[(i++)]);
/* 550 */       templateStart = placeholderStart + 2;
/*     */     }
/* 552 */     builder.append(template.substring(templateStart));
/*     */ 
/* 555 */     if (i < args.length) {
/* 556 */       builder.append(" [");
/* 557 */       builder.append(args[(i++)]);
/* 558 */       while (i < args.length) {
/* 559 */         builder.append(", ");
/* 560 */         builder.append(args[(i++)]);
/*     */       }
/* 562 */       builder.append("]");
/*     */     }
/*     */ 
/* 565 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Preconditions
 * JD-Core Version:    0.6.0
 */