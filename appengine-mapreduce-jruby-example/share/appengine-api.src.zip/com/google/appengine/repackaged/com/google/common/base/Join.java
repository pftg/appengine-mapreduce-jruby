/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.IOException;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public final class Join
/*     */ {
/*     */   public static String join(String delimiter, Iterable<?> tokens)
/*     */   {
/*  60 */     return Joiner.on(delimiter).useForNull("null").join(tokens);
/*     */   }
/*     */ 
/*     */   public static String join(String delimiter, Object[] tokens)
/*     */   {
/*  76 */     return Joiner.on(delimiter).useForNull("null").join(tokens);
/*     */   }
/*     */ 
/*     */   public static String join(String delimiter, @Nullable Object firstToken, Object[] otherTokens)
/*     */   {
/*  93 */     return Joiner.on(delimiter).useForNull("null").join(iterable(firstToken, otherTokens));
/*     */   }
/*     */ 
/*     */   public static String join(String delimiter, Iterator<?> tokens)
/*     */   {
/* 109 */     StringBuilder sb = new StringBuilder();
/* 110 */     join(sb, delimiter, tokens);
/* 111 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String join(String keyValueSeparator, String entryDelimiter, Map<?, ?> map)
/*     */   {
/* 128 */     return Joiner.on(entryDelimiter).useForNull("null").withKeyValueSeparator(keyValueSeparator).join(map);
/*     */   }
/*     */ 
/*     */   public static <T extends Appendable> T join(T appendable, String delimiter, Iterable<?> tokens)
/*     */   {
/*     */     try
/*     */     {
/* 149 */       return Joiner.on(delimiter).useForNull("null").appendTo(appendable, tokens); } catch (IOException e) {
/*     */     }
/* 151 */     throw new JoinException(e, null);
/*     */   }
/*     */ 
/*     */   public static <T extends Appendable> T join(T appendable, String delimiter, Object[] tokens)
/*     */   {
/* 169 */     return join(appendable, delimiter, Arrays.asList(tokens));
/*     */   }
/*     */ 
/*     */   public static <T extends Appendable> T join(T appendable, String delimiter, @Nullable Object firstToken, Object[] otherTokens)
/*     */   {
/* 188 */     return join(appendable, delimiter, iterable(firstToken, otherTokens));
/*     */   }
/*     */ 
/*     */   public static <T extends Appendable> T join(T appendable, String delimiter, Iterator<?> tokens)
/*     */   {
/* 205 */     Preconditions.checkNotNull(appendable);
/* 206 */     Preconditions.checkNotNull(delimiter);
/* 207 */     if (tokens.hasNext()) {
/*     */       try {
/* 209 */         appendOneToken(appendable, tokens.next());
/* 210 */         while (tokens.hasNext()) {
/* 211 */           appendable.append(delimiter);
/* 212 */           appendOneToken(appendable, tokens.next());
/*     */         }
/*     */       } catch (IOException e) {
/* 215 */         throw new JoinException(e, null);
/*     */       }
/*     */     }
/* 218 */     return appendable;
/*     */   }
/*     */ 
/*     */   public static <T extends Appendable> T join(T appendable, String keyValueSeparator, String entryDelimiter, Map<?, ?> map)
/*     */   {
/*     */     try
/*     */     {
/* 238 */       return Joiner.on(entryDelimiter).useForNull("null").withKeyValueSeparator(keyValueSeparator).appendTo(appendable, map);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/* 243 */     throw new JoinException(e, null);
/*     */   }
/*     */ 
/*     */   private static void appendOneToken(Appendable appendable, Object token) throws IOException
/*     */   {
/* 248 */     appendable.append(toCharSequence(token));
/*     */   }
/*     */ 
/*     */   private static CharSequence toCharSequence(Object token) {
/* 252 */     return (token instanceof CharSequence) ? (CharSequence)token : String.valueOf(token);
/*     */   }
/*     */ 
/*     */   private static Iterable<Object> iterable(Object first, Object[] rest)
/*     */   {
/* 272 */     Preconditions.checkNotNull(rest);
/* 273 */     return new AbstractList(rest, first) {
/*     */       public int size() {
/* 275 */         return this.val$rest.length + 1;
/*     */       }
/*     */ 
/*     */       public Object get(int index) {
/* 279 */         return index == 0 ? this.val$first : this.val$rest[(index - 1)];
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static class JoinException extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     private JoinException(IOException cause)
/*     */     {
/* 261 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Join
 * JD-Core Version:    0.6.0
 */