/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class PostalAddress
/*    */   implements Serializable, Comparable<PostalAddress>
/*    */ {
/*    */   public static final long serialVersionUID = -1090628591187239495L;
/*    */   private String address;
/*    */ 
/*    */   public PostalAddress(String address)
/*    */   {
/* 34 */     if (address == null) {
/* 35 */       throw new NullPointerException("address must not be null");
/*    */     }
/* 37 */     this.address = address;
/*    */   }
/*    */ 
/*    */   private PostalAddress()
/*    */   {
/* 47 */     this.address = null;
/*    */   }
/*    */ 
/*    */   public String getAddress() {
/* 51 */     return this.address;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 56 */     if (this == o) {
/* 57 */       return true;
/*    */     }
/* 59 */     if ((o == null) || (getClass() != o.getClass())) {
/* 60 */       return false;
/*    */     }
/*    */ 
/* 63 */     PostalAddress that = (PostalAddress)o;
/*    */ 
/* 66 */     return this.address.equals(that.address);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 74 */     return this.address.hashCode();
/*    */   }
/*    */ 
/*    */   public int compareTo(PostalAddress o) {
/* 78 */     return this.address.compareTo(o.address);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.PostalAddress
 * JD-Core Version:    0.6.0
 */