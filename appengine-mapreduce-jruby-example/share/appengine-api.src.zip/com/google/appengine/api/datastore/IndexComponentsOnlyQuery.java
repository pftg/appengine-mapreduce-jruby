/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.DatastorePb.Query;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order.Direction;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Index.Property;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Index.Property.Direction;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Property;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ class IndexComponentsOnlyQuery extends ValidatedQuery
/*     */ {
/*  37 */   private final List<String> equalityProps = new ArrayList();
/*  38 */   private final List<OnestoreEntity.Index.Property> indexProps = new ArrayList();
/*  39 */   private boolean hasKeyProperty = false;
/*     */ 
/*  94 */   private static final Comparator<OnestoreEntity.Index.Property> PROPERTY_NAME_COMPARATOR = new Comparator() {
/*     */     public int compare(OnestoreEntity.Index.Property o1, OnestoreEntity.Index.Property o2) {
/*  96 */       return o1.getName().compareTo(o2.getName());
/*     */     }
/*  94 */   };
/*     */ 
/*     */   public IndexComponentsOnlyQuery(DatastorePb.Query query)
/*     */   {
/*  42 */     super(query);
/*  43 */     removeNativelySupportedComponents();
/*  44 */     categorizeQuery();
/*     */   }
/*     */ 
/*     */   private void removeNativelySupportedComponents()
/*     */   {
/*  51 */     boolean hasKeyDescOrder = false;
/*  52 */     if (this.query.orderSize() > 0) {
/*  53 */       DatastorePb.Query.Order lastOrder = this.query.getOrder(this.query.orderSize() - 1);
/*  54 */       if (lastOrder.getProperty().equals("__key__")) {
/*  55 */         if (lastOrder.getDirection() == DatastorePb.Query.Order.Direction.ASCENDING.getValue())
/*  56 */           this.query.removeOrder(this.query.orderSize() - 1);
/*     */         else {
/*  58 */           hasKeyDescOrder = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  69 */     if (!hasKeyDescOrder) {
/*  70 */       boolean hasNonKeyInequality = false;
/*  71 */       for (DatastorePb.Query.Filter f : this.query.filters()) {
/*  72 */         if ((ValidatedQuery.INEQUALITY_OPERATORS.contains(f.getOpEnum())) && (!"__key__".equals(f.getProperty(0).getName())))
/*     */         {
/*  74 */           hasNonKeyInequality = true;
/*  75 */           break;
/*     */         }
/*     */       }
/*     */ 
/*  79 */       if (!hasNonKeyInequality)
/*     */       {
/*  82 */         Iterator itr = this.query.filterIterator();
/*  83 */         while (itr.hasNext())
/*  84 */           if (((DatastorePb.Query.Filter)itr.next()).getProperty(0).getName().equals("__key__"))
/*  85 */             itr.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void categorizeQuery()
/*     */   {
/* 101 */     Set ineqProps = new HashSet();
/* 102 */     Set existsProps = new HashSet();
/* 103 */     this.hasKeyProperty = false;
/* 104 */     for (DatastorePb.Query.Filter filter : this.query.filters()) {
/* 105 */       String propName = filter.getProperty(0).getName();
/* 106 */       switch (2.$SwitchMap$com$google$apphosting$api$DatastorePb$Query$Filter$Operator[filter.getOpEnum().ordinal()]) {
/*     */       case 1:
/* 108 */         this.equalityProps.add(propName);
/* 109 */         break;
/*     */       case 2:
/* 111 */         existsProps.add(propName);
/* 112 */         break;
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/* 117 */         ineqProps.add(propName);
/*     */       }
/*     */ 
/* 120 */       if (propName.equals("__key__")) {
/* 121 */         this.hasKeyProperty = true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 128 */     for (String eqProp : this.equalityProps) {
/* 129 */       this.indexProps.add(newIndexProperty(eqProp, OnestoreEntity.Index.Property.Direction.ASCENDING));
/*     */     }
/*     */ 
/* 133 */     Collections.sort(this.indexProps, PROPERTY_NAME_COMPARATOR);
/*     */ 
/* 136 */     if ((this.query.orderSize() == 0) && (!ineqProps.isEmpty()))
/*     */     {
/* 140 */       this.indexProps.add(newIndexProperty((String)ineqProps.iterator().next(), OnestoreEntity.Index.Property.Direction.ASCENDING));
/*     */     }
/*     */ 
/* 145 */     for (DatastorePb.Query.Order order : this.query.orders()) {
/* 146 */       if (order.getProperty().equals("__key__")) {
/* 147 */         this.hasKeyProperty = true;
/*     */       }
/* 149 */       this.indexProps.add(newIndexProperty(order.getProperty(), OnestoreEntity.Index.Property.Direction.valueOf(order.getDirection())));
/*     */     }
/*     */ 
/* 154 */     for (String existsProp : existsProps)
/* 155 */       if (!indexPropertyWithNameExists(existsProp, this.indexProps))
/*     */       {
/* 157 */         this.indexProps.add(newIndexProperty(existsProp, OnestoreEntity.Index.Property.Direction.ASCENDING));
/*     */       }
/*     */   }
/*     */ 
/*     */   private static boolean indexPropertyWithNameExists(String propName, List<OnestoreEntity.Index.Property> indexProperties)
/*     */   {
/* 164 */     for (OnestoreEntity.Index.Property indexProperty : indexProperties) {
/* 165 */       if (indexProperty.getName().equals(propName)) {
/* 166 */         return true;
/*     */       }
/*     */     }
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   private static OnestoreEntity.Index.Property newIndexProperty(String name, OnestoreEntity.Index.Property.Direction direction) {
/* 173 */     OnestoreEntity.Index.Property indexProperty = new OnestoreEntity.Index.Property();
/* 174 */     indexProperty.setName(name);
/* 175 */     indexProperty.setDirection(direction);
/* 176 */     return indexProperty;
/*     */   }
/*     */ 
/*     */   public List<String> getEqualityProps() {
/* 180 */     return this.equalityProps;
/*     */   }
/*     */ 
/*     */   public boolean hasKeyProperty() {
/* 184 */     return this.hasKeyProperty;
/*     */   }
/*     */ 
/*     */   public List<OnestoreEntity.Index.Property> getIndexProps() {
/* 188 */     return this.indexProps;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 193 */     if (this == o) {
/* 194 */       return true;
/*     */     }
/* 196 */     if ((o == null) || (getClass() != o.getClass())) {
/* 197 */       return false;
/*     */     }
/*     */ 
/* 200 */     IndexComponentsOnlyQuery that = (IndexComponentsOnlyQuery)o;
/*     */ 
/* 203 */     return this.query.equals(that.query);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 211 */     return this.query.hashCode();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.IndexComponentsOnlyQuery
 * JD-Core Version:    0.6.0
 */