/*      */ package com.google.appengine.api.mail;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import com.google.apphosting.api.ApiBasePb.VoidProto;
/*      */ import com.google.net.rpc.DefaultStubCreationFilter;
/*      */ import com.google.net.rpc.RPC;
/*      */ import com.google.net.rpc.RpcCallback;
/*      */ import com.google.net.rpc.RpcCancelCallback;
/*      */ import com.google.net.rpc.RpcException;
/*      */ import com.google.net.rpc.RpcInterface;
/*      */ import com.google.net.rpc.RpcServerParameters;
/*      */ import com.google.net.rpc.RpcService;
/*      */ import com.google.net.rpc.RpcStub;
/*      */ import com.google.net.rpc.RpcStubFactory;
/*      */ import com.google.net.rpc.RpcStubParameters;
/*      */ import com.google.net.rpc.StubCreationFilter;
/*      */ import com.google.net.rpc.impl.ApplicationHandler;
/*      */ import com.google.net.rpc.impl.BlockingApplicationHandler;
/*      */ import com.google.net.rpc.impl.RpcHandlerRegistry;
/*      */ import com.google.net.rpc.impl.RpcServerConfig;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1CompatibilityStub;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1HandlerRegistry;
/*      */ import com.google.net.rpc3.server.RpcServer.Builder;
/*      */ import com.google.net.ssl.SslSecurityLevel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ public class MailServicePb
/*      */ {
/*      */   public static final class MailService
/*      */   {
/* 1886 */     private static volatile StubCreationFilter stubCreationFilter_ = new DefaultStubCreationFilter();
/*      */ 
/* 1892 */     private static final RpcStubFactory stubFactory_ = new RpcStubFactory() {
/*      */       public RpcStub newRpcStub(RpcStubParameters params) {
/* 1894 */         return new MailServicePb.MailService.SimpleStub(MailServicePb.MailService.stubCreationFilter_.filterStubParameters("MailService", params));
/*      */       }
/* 1892 */     };
/*      */ 
/*      */     public static void setStubCreationFilter(StubCreationFilter filter)
/*      */     {
/* 1889 */       stubCreationFilter_ = filter == null ? new DefaultStubCreationFilter() : filter;
/*      */     }
/*      */ 
/*      */     public static RpcStubFactory stubFactory()
/*      */     {
/* 1898 */       return stubFactory_;
/*      */     }
/*      */ 
/*      */     public static BlockingStub newBlockingStub(RpcStubParameters params)
/*      */     {
/* 1941 */       return new BlockingStub(stubCreationFilter_.filterStubParameters("MailService", params));
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcStubParameters params)
/*      */     {
/* 1964 */       return new Stub(stubCreationFilter_.filterStubParameters("MailService", params));
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcHandlerRegistry registry)
/*      */     {
/* 2013 */       ServerConfig config = new ServerConfig();
/* 2014 */       exportServiceUsingConfig(service, registry, config);
/* 2015 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 2021 */       registry.registerHandler(config.serviceName(), "Send", new MailServicePb.MailMessage(), new ApiBasePb.VoidProto(), null, config.Send_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 2025 */           this.val$service.send(rpc, (MailServicePb.MailMessage)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 2029 */       registry.registerHandler(config.serviceName(), "SendToAdmins", new MailServicePb.MailMessage(), new ApiBasePb.VoidProto(), null, config.SendToAdmins_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 2033 */           this.val$service.sendToAdmins(rpc, (MailServicePb.MailMessage)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     public static RpcService newService(Interface impl) {
/* 2040 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 2042 */           return MailServicePb.MailService.exportService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcServer.Builder builder) {
/* 2049 */       ServerConfig config = new ServerConfig();
/* 2050 */       exportServiceUsingConfig(service, builder, config);
/* 2051 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 2057 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 2058 */       exportServiceUsingConfig(service, registry, config);
/* 2059 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcHandlerRegistry registry)
/*      */     {
/* 2064 */       ServerConfig config = new ServerConfig();
/* 2065 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 2066 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 2072 */       registry.registerHandler(config.serviceName(), "Send", new MailServicePb.MailMessage(), new ApiBasePb.VoidProto(), null, config.Send_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 2076 */           return this.val$service.send(rpc, (MailServicePb.MailMessage)rpc.internalRequest());
/*      */         }
/*      */       });
/* 2079 */       registry.registerHandler(config.serviceName(), "SendToAdmins", new MailServicePb.MailMessage(), new ApiBasePb.VoidProto(), null, config.SendToAdmins_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 2083 */           return this.val$service.sendToAdmins(rpc, (MailServicePb.MailMessage)rpc.internalRequest());
/*      */         } } );
/*      */     }
/*      */ 
/*      */     public static RpcService newBlockingService(BlockingInterface impl) {
/* 2089 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 2091 */           return MailServicePb.MailService.exportBlockingService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcServer.Builder builder) {
/* 2098 */       ServerConfig config = new ServerConfig();
/* 2099 */       exportBlockingServiceUsingConfig(service, builder, config);
/* 2100 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 2106 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 2107 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 2108 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static void unexport(RpcHandlerRegistry registry) {
/* 2112 */       registry.unregisterService("MailService");
/*      */     }
/*      */ 
/*      */     public static class ServerConfig extends RpcServerConfig
/*      */     {
/* 1968 */       final RpcServerParameters Send_parameters_ = new RpcServerParameters();
/* 1969 */       final RpcServerParameters SendToAdmins_parameters_ = new RpcServerParameters();
/*      */ 
/*      */       public ServerConfig() {
/* 1972 */         this("MailService");
/*      */       }
/*      */       public ServerConfig(String serviceName) {
/* 1975 */         super();
/*      */       }
/*      */       public void setRpcRunner(Executor t) {
/* 1978 */         setRpcRunner_Send(t);
/* 1979 */         setRpcRunner_SendToAdmins(t);
/*      */       }
/*      */ 
/*      */       public void setRpcRunner_Send(Executor t) {
/* 1983 */         this.Send_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_SendToAdmins(Executor t) {
/* 1986 */         this.SendToAdmins_parameters_.setRpcRunner(t);
/*      */       }
/*      */ 
/*      */       public void setServerLogging_Send(int t) {
/* 1990 */         this.Send_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_SendToAdmins(int t) {
/* 1993 */         this.SendToAdmins_parameters_.setServerLogging(t);
/*      */       }
/*      */ 
/*      */       public void setSecurityLevel_Send(SslSecurityLevel t) {
/* 1997 */         this.Send_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_SendToAdmins(SslSecurityLevel t) {
/* 2000 */         this.SendToAdmins_parameters_.setSecurityLevel(t);
/*      */       }
/*      */ 
/*      */       public void setRpcCancelCallback_Send(RpcCancelCallback t) {
/* 2004 */         this.Send_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_SendToAdmins(RpcCancelCallback t) {
/* 2007 */         this.SendToAdmins_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class Stub extends MailServicePb.MailService.BlockingStub
/*      */       implements MailServicePb.MailService.Interface
/*      */     {
/*      */       Stub(RpcStubParameters params)
/*      */       {
/* 1951 */         super();
/*      */       }
/*      */       public void send(RPC rpc, MailServicePb.MailMessage req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 1954 */         startNonBlockingRpc(rpc, this.Send_method_, "Send", req, reply, cb, this.Send_parameters_);
/*      */       }
/*      */ 
/*      */       public void sendToAdmins(RPC rpc, MailServicePb.MailMessage req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 1958 */         startNonBlockingRpc(rpc, this.SendToAdmins_method_, "SendToAdmins", req, reply, cb, this.SendToAdmins_parameters_);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface extends RpcInterface
/*      */     {
/*      */       public abstract void send(RPC paramRPC, MailServicePb.MailMessage paramMailMessage, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void sendToAdmins(RPC paramRPC, MailServicePb.MailMessage paramMailMessage, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*      */     }
/*      */ 
/*      */     public static class BlockingStub extends MailServicePb.MailService.BaseStub
/*      */       implements MailServicePb.MailService.BlockingInterface
/*      */     {
/*      */       BlockingStub(RpcStubParameters params)
/*      */       {
/* 1924 */         super();
/*      */       }
/*      */       public ApiBasePb.VoidProto send(RPC rpc, MailServicePb.MailMessage req) throws RpcException {
/* 1927 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 1928 */         startBlockingRpc(rpc, this.Send_method_, "Send", req, reply, this.Send_parameters_);
/*      */ 
/* 1930 */         return reply;
/*      */       }
/*      */       public ApiBasePb.VoidProto sendToAdmins(RPC rpc, MailServicePb.MailMessage req) throws RpcException {
/* 1933 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 1934 */         startBlockingRpc(rpc, this.SendToAdmins_method_, "SendToAdmins", req, reply, this.SendToAdmins_parameters_);
/*      */ 
/* 1936 */         return reply;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface extends RpcInterface
/*      */     {
/*      */       public abstract ApiBasePb.VoidProto send(RPC paramRPC, MailServicePb.MailMessage paramMailMessage)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ApiBasePb.VoidProto sendToAdmins(RPC paramRPC, MailServicePb.MailMessage paramMailMessage)
/*      */         throws RpcException;
/*      */     }
/*      */ 
/*      */     private static class BaseStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       protected final String Send_method_;
/* 1912 */       protected final RPC Send_parameters_ = newRpcPrototype(MailServicePb.MailService.Method.Send);
/*      */       protected final String SendToAdmins_method_;
/* 1914 */       protected final RPC SendToAdmins_parameters_ = newRpcPrototype(MailServicePb.MailService.Method.SendToAdmins);
/*      */ 
/*      */       protected BaseStub(RpcStubParameters params)
/*      */       {
/* 1906 */         super(params, MailServicePb.MailService.Method.class);
/* 1907 */         this.Send_method_ = makeFullMethodName("Send");
/* 1908 */         this.SendToAdmins_method_ = makeFullMethodName("SendToAdmins");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class SimpleStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       public SimpleStub(RpcStubParameters params)
/*      */       {
/* 1901 */         super(params, MailServicePb.MailService.Method.class);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Method
/*      */     {
/* 1882 */       Send, 
/* 1883 */       SendToAdmins;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MailMessage extends ProtocolMessage<MailMessage>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  624 */     private byte[] sender_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  625 */     private byte[] replyto_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  626 */     private List<byte[]> to_ = null;
/*  627 */     private List<byte[]> cc_ = null;
/*  628 */     private List<byte[]> bcc_ = null;
/*  629 */     private byte[] subject_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  630 */     private byte[] textbody_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  631 */     private byte[] htmlbody_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  632 */     private List<MailServicePb.MailAttachment> attachment_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final MailMessage IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kSender = 1;
/*      */     public static final int kReplyTo = 2;
/*      */     public static final int kTo = 3;
/*      */     public static final int kCc = 4;
/*      */     public static final int kBcc = 5;
/*      */     public static final int kSubject = 6;
/*      */     public static final int kTextBody = 7;
/*      */     public static final int kHtmlBody = 8;
/*      */     public static final int kAttachment = 9;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getSenderAsBytes()
/*      */     {
/*  638 */       return this.sender_;
/*      */     }
/*      */     public final boolean hasSender() {
/*  641 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public MailMessage clearSender() {
/*  644 */       this.optional_0_ &= -2;
/*  645 */       this.sender_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  646 */       return this;
/*      */     }
/*      */     public MailMessage setSenderAsBytes(byte[] x) {
/*  649 */       this.optional_0_ |= 1;
/*  650 */       this.sender_ = x;
/*  651 */       return this;
/*      */     }
/*      */     public final String getSender() {
/*  654 */       return ProtocolSupport.toStringUtf8(this.sender_);
/*      */     }
/*      */     public MailMessage setSender(String v) {
/*  657 */       if (v == null) throw new NullPointerException();
/*  658 */       this.optional_0_ |= 1;
/*  659 */       this.sender_ = ProtocolSupport.toBytesUtf8(v);
/*  660 */       return this;
/*      */     }
/*      */     public final String getSender(Charset cs) {
/*  663 */       return ProtocolSupport.toString(this.sender_, cs);
/*      */     }
/*      */     public MailMessage setSender(String v, Charset cs) {
/*  666 */       if (v == null) throw new NullPointerException();
/*  667 */       this.optional_0_ |= 1;
/*  668 */       this.sender_ = ProtocolSupport.toBytes(v, cs);
/*  669 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getReplyToAsBytes()
/*      */     {
/*  674 */       return this.replyto_;
/*      */     }
/*      */     public final boolean hasReplyTo() {
/*  677 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public MailMessage clearReplyTo() {
/*  680 */       this.optional_0_ &= -3;
/*  681 */       this.replyto_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  682 */       return this;
/*      */     }
/*      */     public MailMessage setReplyToAsBytes(byte[] x) {
/*  685 */       this.optional_0_ |= 2;
/*  686 */       this.replyto_ = x;
/*  687 */       return this;
/*      */     }
/*      */     public final String getReplyTo() {
/*  690 */       return ProtocolSupport.toStringUtf8(this.replyto_);
/*      */     }
/*      */     public MailMessage setReplyTo(String v) {
/*  693 */       if (v == null) throw new NullPointerException();
/*  694 */       this.optional_0_ |= 2;
/*  695 */       this.replyto_ = ProtocolSupport.toBytesUtf8(v);
/*  696 */       return this;
/*      */     }
/*      */     public final String getReplyTo(Charset cs) {
/*  699 */       return ProtocolSupport.toString(this.replyto_, cs);
/*      */     }
/*      */     public MailMessage setReplyTo(String v, Charset cs) {
/*  702 */       if (v == null) throw new NullPointerException();
/*  703 */       this.optional_0_ |= 2;
/*  704 */       this.replyto_ = ProtocolSupport.toBytes(v, cs);
/*  705 */       return this;
/*      */     }
/*      */ 
/*      */     public final int toSize()
/*      */     {
/*  710 */       return this.to_ != null ? this.to_.size() : 0;
/*      */     }
/*      */     public final byte[] getToAsBytes(int i) {
/*  713 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.to_ != null ? this.to_.size() : 0)); } else throw new AssertionError();
/*  714 */       return (byte[])this.to_.get(i);
/*      */     }
/*      */     public MailMessage clearTo() {
/*  717 */       if (this.to_ != null) this.to_.clear();
/*  718 */       return this;
/*      */     }
/*      */     public final String getTo(int i) {
/*  721 */       return ProtocolSupport.toStringUtf8((byte[])this.to_.get(i));
/*      */     }
/*      */     public MailMessage setToAsBytes(int i, byte[] v) {
/*  724 */       this.to_.set(i, v);
/*  725 */       return this;
/*      */     }
/*      */     public MailMessage setTo(int i, String v) {
/*  728 */       if (v == null) throw new NullPointerException();
/*  729 */       this.to_.set(i, ProtocolSupport.toBytesUtf8(v));
/*  730 */       return this;
/*      */     }
/*      */     public MailMessage addToAsBytes(byte[] v) {
/*  733 */       if (this.to_ == null) this.to_ = new ArrayList(4);
/*  734 */       this.to_.add(v);
/*  735 */       return this;
/*      */     }
/*      */     public MailMessage addTo(String v) {
/*  738 */       if (v == null) throw new NullPointerException();
/*  739 */       if (this.to_ == null) this.to_ = new ArrayList(4);
/*  740 */       this.to_.add(ProtocolSupport.toBytesUtf8(v));
/*  741 */       return this;
/*      */     }
/*      */     public final Iterator<String> toIterator() {
/*  744 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.to_);
/*      */     }
/*      */     public final List<String> tos() {
/*  747 */       return ProtocolSupport.byteArrayToUnicodeList(this.to_);
/*      */     }
/*      */     public final Iterator<byte[]> toAsBytesIterator() {
/*  750 */       return this.to_ == null ? ProtocolSupport.emptyIterator() : this.to_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> tosAsBytes()
/*      */     {
/*  755 */       return ProtocolSupport.unmodifiableList(this.to_);
/*      */     }
/*      */     public final List<byte[]> mutableTosAsBytes() {
/*  758 */       if (this.to_ == null) this.to_ = new ArrayList(4);
/*  759 */       return this.to_;
/*      */     }
/*      */     public final String getTo(int i, Charset cs) {
/*  762 */       return ProtocolSupport.toString((byte[])this.to_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public MailMessage setTo(int i, String v, Charset cs) {
/*  766 */       if (v == null) throw new NullPointerException();
/*  767 */       this.to_.set(i, ProtocolSupport.toBytes(v, cs));
/*  768 */       return this;
/*      */     }
/*      */ 
/*      */     public MailMessage addTo(String v, Charset cs) {
/*  772 */       if (v == null) throw new NullPointerException();
/*  773 */       if (this.to_ == null) this.to_ = new ArrayList(4);
/*  774 */       this.to_.add(ProtocolSupport.toBytes(v, cs));
/*  775 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> toIterator(Charset cs) {
/*  779 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.to_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> tos(Charset cs) {
/*  783 */       return ProtocolSupport.byteArrayToUnicodeList(this.to_, cs);
/*      */     }
/*      */ 
/*      */     public final int ccSize()
/*      */     {
/*  788 */       return this.cc_ != null ? this.cc_.size() : 0;
/*      */     }
/*      */     public final byte[] getCcAsBytes(int i) {
/*  791 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.cc_ != null ? this.cc_.size() : 0)); } else throw new AssertionError();
/*  792 */       return (byte[])this.cc_.get(i);
/*      */     }
/*      */     public MailMessage clearCc() {
/*  795 */       if (this.cc_ != null) this.cc_.clear();
/*  796 */       return this;
/*      */     }
/*      */     public final String getCc(int i) {
/*  799 */       return ProtocolSupport.toStringUtf8((byte[])this.cc_.get(i));
/*      */     }
/*      */     public MailMessage setCcAsBytes(int i, byte[] v) {
/*  802 */       this.cc_.set(i, v);
/*  803 */       return this;
/*      */     }
/*      */     public MailMessage setCc(int i, String v) {
/*  806 */       if (v == null) throw new NullPointerException();
/*  807 */       this.cc_.set(i, ProtocolSupport.toBytesUtf8(v));
/*  808 */       return this;
/*      */     }
/*      */     public MailMessage addCcAsBytes(byte[] v) {
/*  811 */       if (this.cc_ == null) this.cc_ = new ArrayList(4);
/*  812 */       this.cc_.add(v);
/*  813 */       return this;
/*      */     }
/*      */     public MailMessage addCc(String v) {
/*  816 */       if (v == null) throw new NullPointerException();
/*  817 */       if (this.cc_ == null) this.cc_ = new ArrayList(4);
/*  818 */       this.cc_.add(ProtocolSupport.toBytesUtf8(v));
/*  819 */       return this;
/*      */     }
/*      */     public final Iterator<String> ccIterator() {
/*  822 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.cc_);
/*      */     }
/*      */     public final List<String> ccs() {
/*  825 */       return ProtocolSupport.byteArrayToUnicodeList(this.cc_);
/*      */     }
/*      */     public final Iterator<byte[]> ccAsBytesIterator() {
/*  828 */       return this.cc_ == null ? ProtocolSupport.emptyIterator() : this.cc_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> ccsAsBytes()
/*      */     {
/*  833 */       return ProtocolSupport.unmodifiableList(this.cc_);
/*      */     }
/*      */     public final List<byte[]> mutableCcsAsBytes() {
/*  836 */       if (this.cc_ == null) this.cc_ = new ArrayList(4);
/*  837 */       return this.cc_;
/*      */     }
/*      */     public final String getCc(int i, Charset cs) {
/*  840 */       return ProtocolSupport.toString((byte[])this.cc_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public MailMessage setCc(int i, String v, Charset cs) {
/*  844 */       if (v == null) throw new NullPointerException();
/*  845 */       this.cc_.set(i, ProtocolSupport.toBytes(v, cs));
/*  846 */       return this;
/*      */     }
/*      */ 
/*      */     public MailMessage addCc(String v, Charset cs) {
/*  850 */       if (v == null) throw new NullPointerException();
/*  851 */       if (this.cc_ == null) this.cc_ = new ArrayList(4);
/*  852 */       this.cc_.add(ProtocolSupport.toBytes(v, cs));
/*  853 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> ccIterator(Charset cs) {
/*  857 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.cc_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> ccs(Charset cs) {
/*  861 */       return ProtocolSupport.byteArrayToUnicodeList(this.cc_, cs);
/*      */     }
/*      */ 
/*      */     public final int bccSize()
/*      */     {
/*  866 */       return this.bcc_ != null ? this.bcc_.size() : 0;
/*      */     }
/*      */     public final byte[] getBccAsBytes(int i) {
/*  869 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.bcc_ != null ? this.bcc_.size() : 0)); } else throw new AssertionError();
/*  870 */       return (byte[])this.bcc_.get(i);
/*      */     }
/*      */     public MailMessage clearBcc() {
/*  873 */       if (this.bcc_ != null) this.bcc_.clear();
/*  874 */       return this;
/*      */     }
/*      */     public final String getBcc(int i) {
/*  877 */       return ProtocolSupport.toStringUtf8((byte[])this.bcc_.get(i));
/*      */     }
/*      */     public MailMessage setBccAsBytes(int i, byte[] v) {
/*  880 */       this.bcc_.set(i, v);
/*  881 */       return this;
/*      */     }
/*      */     public MailMessage setBcc(int i, String v) {
/*  884 */       if (v == null) throw new NullPointerException();
/*  885 */       this.bcc_.set(i, ProtocolSupport.toBytesUtf8(v));
/*  886 */       return this;
/*      */     }
/*      */     public MailMessage addBccAsBytes(byte[] v) {
/*  889 */       if (this.bcc_ == null) this.bcc_ = new ArrayList(4);
/*  890 */       this.bcc_.add(v);
/*  891 */       return this;
/*      */     }
/*      */     public MailMessage addBcc(String v) {
/*  894 */       if (v == null) throw new NullPointerException();
/*  895 */       if (this.bcc_ == null) this.bcc_ = new ArrayList(4);
/*  896 */       this.bcc_.add(ProtocolSupport.toBytesUtf8(v));
/*  897 */       return this;
/*      */     }
/*      */     public final Iterator<String> bccIterator() {
/*  900 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.bcc_);
/*      */     }
/*      */     public final List<String> bccs() {
/*  903 */       return ProtocolSupport.byteArrayToUnicodeList(this.bcc_);
/*      */     }
/*      */     public final Iterator<byte[]> bccAsBytesIterator() {
/*  906 */       return this.bcc_ == null ? ProtocolSupport.emptyIterator() : this.bcc_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> bccsAsBytes()
/*      */     {
/*  911 */       return ProtocolSupport.unmodifiableList(this.bcc_);
/*      */     }
/*      */     public final List<byte[]> mutableBccsAsBytes() {
/*  914 */       if (this.bcc_ == null) this.bcc_ = new ArrayList(4);
/*  915 */       return this.bcc_;
/*      */     }
/*      */     public final String getBcc(int i, Charset cs) {
/*  918 */       return ProtocolSupport.toString((byte[])this.bcc_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public MailMessage setBcc(int i, String v, Charset cs) {
/*  922 */       if (v == null) throw new NullPointerException();
/*  923 */       this.bcc_.set(i, ProtocolSupport.toBytes(v, cs));
/*  924 */       return this;
/*      */     }
/*      */ 
/*      */     public MailMessage addBcc(String v, Charset cs) {
/*  928 */       if (v == null) throw new NullPointerException();
/*  929 */       if (this.bcc_ == null) this.bcc_ = new ArrayList(4);
/*  930 */       this.bcc_.add(ProtocolSupport.toBytes(v, cs));
/*  931 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> bccIterator(Charset cs) {
/*  935 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.bcc_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> bccs(Charset cs) {
/*  939 */       return ProtocolSupport.byteArrayToUnicodeList(this.bcc_, cs);
/*      */     }
/*      */ 
/*      */     public final byte[] getSubjectAsBytes()
/*      */     {
/*  944 */       return this.subject_;
/*      */     }
/*      */     public final boolean hasSubject() {
/*  947 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public MailMessage clearSubject() {
/*  950 */       this.optional_0_ &= -5;
/*  951 */       this.subject_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  952 */       return this;
/*      */     }
/*      */     public MailMessage setSubjectAsBytes(byte[] x) {
/*  955 */       this.optional_0_ |= 4;
/*  956 */       this.subject_ = x;
/*  957 */       return this;
/*      */     }
/*      */     public final String getSubject() {
/*  960 */       return ProtocolSupport.toStringUtf8(this.subject_);
/*      */     }
/*      */     public MailMessage setSubject(String v) {
/*  963 */       if (v == null) throw new NullPointerException();
/*  964 */       this.optional_0_ |= 4;
/*  965 */       this.subject_ = ProtocolSupport.toBytesUtf8(v);
/*  966 */       return this;
/*      */     }
/*      */     public final String getSubject(Charset cs) {
/*  969 */       return ProtocolSupport.toString(this.subject_, cs);
/*      */     }
/*      */     public MailMessage setSubject(String v, Charset cs) {
/*  972 */       if (v == null) throw new NullPointerException();
/*  973 */       this.optional_0_ |= 4;
/*  974 */       this.subject_ = ProtocolSupport.toBytes(v, cs);
/*  975 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getTextBodyAsBytes()
/*      */     {
/*  980 */       return this.textbody_;
/*      */     }
/*      */     public final boolean hasTextBody() {
/*  983 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public MailMessage clearTextBody() {
/*  986 */       this.optional_0_ &= -9;
/*  987 */       this.textbody_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  988 */       return this;
/*      */     }
/*      */     public MailMessage setTextBodyAsBytes(byte[] x) {
/*  991 */       this.optional_0_ |= 8;
/*  992 */       this.textbody_ = x;
/*  993 */       return this;
/*      */     }
/*      */     public final String getTextBody() {
/*  996 */       return ProtocolSupport.toStringUtf8(this.textbody_);
/*      */     }
/*      */     public MailMessage setTextBody(String v) {
/*  999 */       if (v == null) throw new NullPointerException();
/* 1000 */       this.optional_0_ |= 8;
/* 1001 */       this.textbody_ = ProtocolSupport.toBytesUtf8(v);
/* 1002 */       return this;
/*      */     }
/*      */     public final String getTextBody(Charset cs) {
/* 1005 */       return ProtocolSupport.toString(this.textbody_, cs);
/*      */     }
/*      */     public MailMessage setTextBody(String v, Charset cs) {
/* 1008 */       if (v == null) throw new NullPointerException();
/* 1009 */       this.optional_0_ |= 8;
/* 1010 */       this.textbody_ = ProtocolSupport.toBytes(v, cs);
/* 1011 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getHtmlBodyAsBytes()
/*      */     {
/* 1016 */       return this.htmlbody_;
/*      */     }
/*      */     public final boolean hasHtmlBody() {
/* 1019 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public MailMessage clearHtmlBody() {
/* 1022 */       this.optional_0_ &= -17;
/* 1023 */       this.htmlbody_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1024 */       return this;
/*      */     }
/*      */     public MailMessage setHtmlBodyAsBytes(byte[] x) {
/* 1027 */       this.optional_0_ |= 16;
/* 1028 */       this.htmlbody_ = x;
/* 1029 */       return this;
/*      */     }
/*      */     public final String getHtmlBody() {
/* 1032 */       return ProtocolSupport.toStringUtf8(this.htmlbody_);
/*      */     }
/*      */     public MailMessage setHtmlBody(String v) {
/* 1035 */       if (v == null) throw new NullPointerException();
/* 1036 */       this.optional_0_ |= 16;
/* 1037 */       this.htmlbody_ = ProtocolSupport.toBytesUtf8(v);
/* 1038 */       return this;
/*      */     }
/*      */     public final String getHtmlBody(Charset cs) {
/* 1041 */       return ProtocolSupport.toString(this.htmlbody_, cs);
/*      */     }
/*      */     public MailMessage setHtmlBody(String v, Charset cs) {
/* 1044 */       if (v == null) throw new NullPointerException();
/* 1045 */       this.optional_0_ |= 16;
/* 1046 */       this.htmlbody_ = ProtocolSupport.toBytes(v, cs);
/* 1047 */       return this;
/*      */     }
/*      */ 
/*      */     public final int attachmentSize()
/*      */     {
/* 1052 */       return this.attachment_ != null ? this.attachment_.size() : 0;
/*      */     }
/*      */     public final MailServicePb.MailAttachment getAttachment(int i) {
/* 1055 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.attachment_ != null ? this.attachment_.size() : 0)); } else throw new AssertionError();
/* 1056 */       return (MailServicePb.MailAttachment)this.attachment_.get(i);
/*      */     }
/*      */     public MailMessage clearAttachment() {
/* 1059 */       if (this.attachment_ != null) this.attachment_.clear();
/* 1060 */       return this;
/*      */     }
/*      */     public MailServicePb.MailAttachment getMutableAttachment(int i) {
/* 1063 */       assert ((i >= 0) && (this.attachment_ != null) && (i < this.attachment_.size()));
/* 1064 */       return (MailServicePb.MailAttachment)this.attachment_.get(i);
/*      */     }
/*      */     public MailServicePb.MailAttachment addAttachment() {
/* 1067 */       MailServicePb.MailAttachment v = new MailServicePb.MailAttachment();
/* 1068 */       if (this.attachment_ == null) this.attachment_ = new ArrayList(4);
/* 1069 */       this.attachment_.add(v);
/* 1070 */       return v;
/*      */     }
/*      */     public MailServicePb.MailAttachment addAttachment(MailServicePb.MailAttachment v) {
/* 1073 */       if (this.attachment_ == null) this.attachment_ = new ArrayList(4);
/* 1074 */       this.attachment_.add(v);
/* 1075 */       return v;
/*      */     }
/*      */     public MailServicePb.MailAttachment insertAttachment(int i, MailServicePb.MailAttachment v) {
/* 1078 */       if (this.attachment_ == null) this.attachment_ = new ArrayList(4);
/* 1079 */       this.attachment_.add(i, v);
/* 1080 */       return v;
/*      */     }
/*      */     public MailServicePb.MailAttachment removeAttachment(int i) {
/* 1083 */       return (MailServicePb.MailAttachment)this.attachment_.remove(i);
/*      */     }
/*      */     public final Iterator<MailServicePb.MailAttachment> attachmentIterator() {
/* 1086 */       if (this.attachment_ == null) {
/* 1087 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 1089 */       return this.attachment_.iterator();
/*      */     }
/*      */     public final List<MailServicePb.MailAttachment> attachments() {
/* 1092 */       return ProtocolSupport.unmodifiableList(this.attachment_);
/*      */     }
/*      */     public final List<MailServicePb.MailAttachment> mutableAttachments() {
/* 1095 */       if (this.attachment_ == null) this.attachment_ = new ArrayList(4);
/* 1096 */       return this.attachment_;
/*      */     }
/*      */ 
/*      */     public MailMessage mergeFrom(MailMessage that)
/*      */     {
/* 1103 */       assert (that != this);
/* 1104 */       int this_t0 = this.optional_0_;
/* 1105 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1107 */       if ((that_t0 & 0x1) != 0) {
/* 1108 */         this_t0 |= 1;
/* 1109 */         this.sender_ = that.sender_;
/*      */       }
/*      */ 
/* 1112 */       if ((that_t0 & 0x2) != 0) {
/* 1113 */         this_t0 |= 2;
/* 1114 */         this.replyto_ = that.replyto_;
/*      */       }
/*      */ 
/* 1117 */       if ((that.to_ != null) && (that.to_.size() > 0)) {
/* 1118 */         if (this.to_ == null)
/* 1119 */           this.to_ = new ArrayList(that.to_);
/*      */         else {
/* 1121 */           this.to_.addAll(that.to_);
/*      */         }
/*      */       }
/*      */ 
/* 1125 */       if ((that.cc_ != null) && (that.cc_.size() > 0)) {
/* 1126 */         if (this.cc_ == null)
/* 1127 */           this.cc_ = new ArrayList(that.cc_);
/*      */         else {
/* 1129 */           this.cc_.addAll(that.cc_);
/*      */         }
/*      */       }
/*      */ 
/* 1133 */       if ((that.bcc_ != null) && (that.bcc_.size() > 0)) {
/* 1134 */         if (this.bcc_ == null)
/* 1135 */           this.bcc_ = new ArrayList(that.bcc_);
/*      */         else {
/* 1137 */           this.bcc_.addAll(that.bcc_);
/*      */         }
/*      */       }
/*      */ 
/* 1141 */       if ((that_t0 & 0x4) != 0) {
/* 1142 */         this_t0 |= 4;
/* 1143 */         this.subject_ = that.subject_;
/*      */       }
/*      */ 
/* 1146 */       if ((that_t0 & 0x8) != 0) {
/* 1147 */         this_t0 |= 8;
/* 1148 */         this.textbody_ = that.textbody_;
/*      */       }
/*      */ 
/* 1151 */       if ((that_t0 & 0x10) != 0) {
/* 1152 */         this_t0 |= 16;
/* 1153 */         this.htmlbody_ = that.htmlbody_;
/*      */       }
/*      */ 
/* 1156 */       if (that.attachment_ != null) {
/* 1157 */         for (MailServicePb.MailAttachment v : that.attachment_) {
/* 1158 */           addAttachment().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 1162 */       if (that.uninterpreted != null) {
/* 1163 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1165 */       this.optional_0_ = this_t0;
/* 1166 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(MailMessage that) {
/* 1170 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(MailMessage that) {
/* 1174 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(MailMessage that, boolean ignoreUninterpreted) {
/* 1178 */       if (that == null) return false;
/* 1179 */       if (that == this) return true;
/* 1180 */       int this_t0 = this.optional_0_;
/* 1181 */       int that_t0 = that.optional_0_;
/* 1182 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1184 */       if (((this_t0 & 0x1) != 0) && 
/* 1185 */         (!Arrays.equals(this.sender_, that.sender_))) return false;
/*      */ 
/* 1188 */       if (((this_t0 & 0x2) != 0) && 
/* 1189 */         (!Arrays.equals(this.replyto_, that.replyto_))) return false;
/* 1193 */       int n;
/* 1193 */       if ((n = this.to_ != null ? this.to_.size() : 0) != (that.to_ != null ? that.to_.size() : 0)) return false;
/* 1194 */       for (int i = 0; i < n; i++) {
/* 1195 */         if (!Arrays.equals((byte[])this.to_.get(i), (byte[])that.to_.get(i))) return false;
/*      */       }
/*      */ 
/* 1198 */       if ((n = this.cc_ != null ? this.cc_.size() : 0) != (that.cc_ != null ? that.cc_.size() : 0)) return false;
/* 1199 */       for (int i = 0; i < n; i++) {
/* 1200 */         if (!Arrays.equals((byte[])this.cc_.get(i), (byte[])that.cc_.get(i))) return false;
/*      */       }
/*      */ 
/* 1203 */       if ((n = this.bcc_ != null ? this.bcc_.size() : 0) != (that.bcc_ != null ? that.bcc_.size() : 0)) return false;
/* 1204 */       for (int i = 0; i < n; i++) {
/* 1205 */         if (!Arrays.equals((byte[])this.bcc_.get(i), (byte[])that.bcc_.get(i))) return false;
/*      */       }
/*      */ 
/* 1208 */       if (((this_t0 & 0x4) != 0) && 
/* 1209 */         (!Arrays.equals(this.subject_, that.subject_))) return false;
/*      */ 
/* 1212 */       if (((this_t0 & 0x8) != 0) && 
/* 1213 */         (!Arrays.equals(this.textbody_, that.textbody_))) return false;
/*      */ 
/* 1216 */       if (((this_t0 & 0x10) != 0) && 
/* 1217 */         (!Arrays.equals(this.htmlbody_, that.htmlbody_))) return false;
/*      */ 
/* 1220 */       if ((n = this.attachment_ != null ? this.attachment_.size() : 0) != (that.attachment_ != null ? that.attachment_.size() : 0)) return false;
/* 1221 */       for (int i = 0; i < n; i++) {
/* 1222 */         if (!((MailServicePb.MailAttachment)this.attachment_.get(i)).equals((MailServicePb.MailAttachment)that.attachment_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 1225 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1230 */       return ((that instanceof MailMessage)) && (equals((MailMessage)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1234 */       int hash = -1153084626;
/*      */ 
/* 1236 */       int this_t0 = this.optional_0_;
/* 1237 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.sender_) : -113);
/*      */ 
/* 1239 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.replyto_) : -113);
/*      */ 
/* 1241 */       hash *= 31;
/* 1242 */       int i = 0; for (int n = this.to_ != null ? this.to_.size() : 0; i < n; i++) {
/* 1243 */         hash = hash * 31 + Arrays.hashCode((byte[])this.to_.get(i));
/*      */       }
/*      */ 
/* 1246 */       hash *= 31;
/* 1247 */       int i = 0; for (int n = this.cc_ != null ? this.cc_.size() : 0; i < n; i++) {
/* 1248 */         hash = hash * 31 + Arrays.hashCode((byte[])this.cc_.get(i));
/*      */       }
/*      */ 
/* 1251 */       hash *= 31;
/* 1252 */       int i = 0; for (int n = this.bcc_ != null ? this.bcc_.size() : 0; i < n; i++) {
/* 1253 */         hash = hash * 31 + Arrays.hashCode((byte[])this.bcc_.get(i));
/*      */       }
/*      */ 
/* 1256 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.subject_) : -113);
/*      */ 
/* 1258 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Arrays.hashCode(this.textbody_) : -113);
/*      */ 
/* 1260 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? Arrays.hashCode(this.htmlbody_) : -113);
/*      */ 
/* 1262 */       hash *= 31;
/* 1263 */       int i = 0; for (int n = this.attachment_ != null ? this.attachment_.size() : 0; i < n; i++) {
/* 1264 */         hash = hash * 31 + ((MailServicePb.MailAttachment)this.attachment_.get(i)).hashCode();
/*      */       }
/* 1266 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1267 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1269 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1273 */       int this_t0 = this.optional_0_;
/* 1274 */       if ((this_t0 & 0x5) != 5)
/*      */       {
/* 1276 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/* 1281 */       if (this.attachment_ != null) {
/* 1282 */         for (MailServicePb.MailAttachment v : this.attachment_) {
/* 1283 */           if (!v.isInitialized()) {
/* 1284 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 1288 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1294 */       int n = 2 + Protocol.stringSize(this.sender_.length) + Protocol.stringSize(this.subject_.length);
/*      */       int m;
/* 1298 */       n += (m = this.to_ != null ? this.to_.size() : 0);
/* 1299 */       for (int i = 0; i < m; i++) {
/* 1300 */         n += Protocol.stringSize(((byte[])this.to_.get(i)).length);
/*      */       }
/*      */ 
/* 1303 */       n += (m = this.cc_ != null ? this.cc_.size() : 0);
/* 1304 */       for (int i = 0; i < m; i++) {
/* 1305 */         n += Protocol.stringSize(((byte[])this.cc_.get(i)).length);
/*      */       }
/*      */ 
/* 1308 */       n += (m = this.bcc_ != null ? this.bcc_.size() : 0);
/* 1309 */       for (int i = 0; i < m; i++) {
/* 1310 */         n += Protocol.stringSize(((byte[])this.bcc_.get(i)).length);
/*      */       }
/*      */ 
/* 1313 */       n += (m = this.attachment_ != null ? this.attachment_.size() : 0);
/* 1314 */       for (int i = 0; i < m; i++) {
/* 1315 */         n += Protocol.stringSize(((MailServicePb.MailAttachment)this.attachment_.get(i)).encodingSize());
/*      */       }
/* 1317 */       int this_t0 = this.optional_0_;
/* 1318 */       if ((this_t0 & 0x1A) != 0) {
/* 1319 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 1321 */           n += 1 + Protocol.stringSize(this.replyto_.length);
/*      */         }
/* 1323 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 1325 */           n += 1 + Protocol.stringSize(this.textbody_.length);
/*      */         }
/* 1327 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 1329 */           n += 1 + Protocol.stringSize(this.htmlbody_.length);
/*      */         }
/*      */       }
/*      */ 
/* 1333 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1340 */       int n = 12 + this.sender_.length + this.subject_.length;
/*      */       int m;
/* 1343 */       n += 6 * (m = this.to_ != null ? this.to_.size() : 0);
/* 1344 */       for (int i = 0; i < m; i++) {
/* 1345 */         n += ((byte[])this.to_.get(i)).length;
/*      */       }
/*      */ 
/* 1348 */       n += 6 * (m = this.cc_ != null ? this.cc_.size() : 0);
/* 1349 */       for (int i = 0; i < m; i++) {
/* 1350 */         n += ((byte[])this.cc_.get(i)).length;
/*      */       }
/*      */ 
/* 1353 */       n += 6 * (m = this.bcc_ != null ? this.bcc_.size() : 0);
/* 1354 */       for (int i = 0; i < m; i++) {
/* 1355 */         n += ((byte[])this.bcc_.get(i)).length;
/*      */       }
/*      */ 
/* 1358 */       n += 6 * (m = this.attachment_ != null ? this.attachment_.size() : 0);
/* 1359 */       for (int i = 0; i < m; i++) {
/* 1360 */         n += ((MailServicePb.MailAttachment)this.attachment_.get(i)).maxEncodingSize();
/*      */       }
/* 1362 */       int this_t0 = this.optional_0_;
/* 1363 */       if ((this_t0 & 0x1A) != 0) {
/* 1364 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 1366 */           n += 6 + this.replyto_.length;
/*      */         }
/* 1368 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 1370 */           n += 6 + this.textbody_.length;
/*      */         }
/* 1372 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 1374 */           n += 6 + this.htmlbody_.length;
/*      */         }
/*      */       }
/*      */ 
/* 1378 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1383 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1387 */       this.optional_0_ = 0;
/* 1388 */       this.sender_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1389 */       this.replyto_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1390 */       if (this.to_ != null) this.to_.clear();
/* 1391 */       if (this.cc_ != null) this.cc_.clear();
/* 1392 */       if (this.bcc_ != null) this.bcc_.clear();
/* 1393 */       this.subject_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1394 */       this.textbody_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1395 */       this.htmlbody_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1396 */       if (this.attachment_ != null) this.attachment_.clear();
/* 1397 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public MailMessage newInstance() {
/* 1401 */       return new MailMessage();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1405 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1450 */       sink.putByte(10);
/* 1451 */       sink.putPrefixedData(this.sender_);
/*      */ 
/* 1453 */       int this_t0 = this.optional_0_;
/* 1454 */       if ((this_t0 & 0x2) != 0) {
/* 1455 */         sink.putByte(18);
/* 1456 */         sink.putPrefixedData(this.replyto_);
/*      */       }
/*      */ 
/* 1459 */       int i = 0; for (int m = this.to_ != null ? this.to_.size() : 0; i < m; i++) {
/* 1460 */         byte[] v = (byte[])this.to_.get(i);
/* 1461 */         sink.putByte(26);
/* 1462 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 1465 */       int i = 0; for (int m = this.cc_ != null ? this.cc_.size() : 0; i < m; i++) {
/* 1466 */         byte[] v = (byte[])this.cc_.get(i);
/* 1467 */         sink.putByte(34);
/* 1468 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 1471 */       int i = 0; for (int m = this.bcc_ != null ? this.bcc_.size() : 0; i < m; i++) {
/* 1472 */         byte[] v = (byte[])this.bcc_.get(i);
/* 1473 */         sink.putByte(42);
/* 1474 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 1477 */       sink.putByte(50);
/* 1478 */       sink.putPrefixedData(this.subject_);
/*      */ 
/* 1480 */       if ((this_t0 & 0x8) != 0) {
/* 1481 */         sink.putByte(58);
/* 1482 */         sink.putPrefixedData(this.textbody_);
/*      */       }
/*      */ 
/* 1485 */       if ((this_t0 & 0x10) != 0) {
/* 1486 */         sink.putByte(66);
/* 1487 */         sink.putPrefixedData(this.htmlbody_);
/*      */       }
/*      */ 
/* 1490 */       int i = 0; for (int m = this.attachment_ != null ? this.attachment_.size() : 0; i < m; i++) {
/* 1491 */         MailServicePb.MailAttachment v = (MailServicePb.MailAttachment)this.attachment_.get(i);
/* 1492 */         sink.putByte(74);
/* 1493 */         sink.putForeign(v);
/*      */       }
/*      */ 
/* 1496 */       if (this.uninterpreted != null)
/* 1497 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1502 */       boolean result = true;
/* 1503 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1505 */       while (source.hasRemaining()) {
/* 1506 */         int tt = source.getVarInt();
/* 1507 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1511 */           result = false;
/* 1512 */           break;
/*      */         case 10:
/* 1515 */           this.sender_ = source.getPrefixedData();
/* 1516 */           this_t0 |= 1;
/* 1517 */           break;
/*      */         case 18:
/* 1520 */           this.replyto_ = source.getPrefixedData();
/* 1521 */           this_t0 |= 2;
/* 1522 */           break;
/*      */         case 26:
/* 1525 */           addToAsBytes(source.getPrefixedData());
/* 1526 */           break;
/*      */         case 34:
/* 1529 */           addCcAsBytes(source.getPrefixedData());
/* 1530 */           break;
/*      */         case 42:
/* 1533 */           addBccAsBytes(source.getPrefixedData());
/* 1534 */           break;
/*      */         case 50:
/* 1537 */           this.subject_ = source.getPrefixedData();
/* 1538 */           this_t0 |= 4;
/* 1539 */           break;
/*      */         case 58:
/* 1542 */           this.textbody_ = source.getPrefixedData();
/* 1543 */           this_t0 |= 8;
/* 1544 */           break;
/*      */         case 66:
/* 1547 */           this.htmlbody_ = source.getPrefixedData();
/* 1548 */           this_t0 |= 16;
/* 1549 */           break;
/*      */         case 74:
/* 1552 */           source.push(source.getVarInt());
/* 1553 */           if (!addAttachment().merge(source)) { result = false; break label284; }
/* 1554 */           source.pop();
/* 1555 */           break;
/*      */         default:
/* 1557 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1562 */       label284: this.optional_0_ = this_t0;
/* 1563 */       return result;
/*      */     }
/*      */ 
/*      */     public MailMessage getDefaultInstanceForType()
/*      */     {
/* 1568 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final MailMessage getDefaultInstance() {
/* 1572 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public MailMessage freeze()
/*      */     {
/* 1801 */       this.sender_ = ProtocolSupport.freezeString(this.sender_);
/* 1802 */       this.replyto_ = ProtocolSupport.freezeString(this.replyto_);
/* 1803 */       this.to_ = ProtocolSupport.freezeStrings(this.to_);
/* 1804 */       this.cc_ = ProtocolSupport.freezeStrings(this.cc_);
/* 1805 */       this.bcc_ = ProtocolSupport.freezeStrings(this.bcc_);
/* 1806 */       this.subject_ = ProtocolSupport.freezeString(this.subject_);
/* 1807 */       this.textbody_ = ProtocolSupport.freezeString(this.textbody_);
/* 1808 */       this.htmlbody_ = ProtocolSupport.freezeString(this.htmlbody_);
/* 1809 */       this.attachment_ = ProtocolSupport.freezeMessages(this.attachment_);
/* 1810 */       return this;
/*      */     }
/*      */ 
/*      */     public MailMessage unfreeze() {
/* 1814 */       this.to_ = ProtocolSupport.unfreezeStrings(this.to_);
/* 1815 */       this.cc_ = ProtocolSupport.unfreezeStrings(this.cc_);
/* 1816 */       this.bcc_ = ProtocolSupport.unfreezeStrings(this.bcc_);
/* 1817 */       this.attachment_ = ProtocolSupport.unfreezeMessages(this.attachment_);
/* 1818 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 1822 */       return (ProtocolSupport.isFrozenStrings(this.to_)) || (ProtocolSupport.isFrozenStrings(this.cc_)) || (ProtocolSupport.isFrozenStrings(this.bcc_)) || (ProtocolSupport.isFrozenMessages(this.attachment_));
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1828 */       if (this.uninterpreted == null) {
/* 1829 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1831 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1576 */       IMMUTABLE_DEFAULT_INSTANCE = new MailMessage()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public MailServicePb.MailMessage clearSender()
/*      */         {
/* 1584 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setSenderAsBytes(byte[] x) {
/* 1587 */           ProtocolSupport.unsupportedOperation();
/* 1588 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setSender(String v) {
/* 1591 */           ProtocolSupport.unsupportedOperation();
/* 1592 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setSender(String v, Charset cs) {
/* 1595 */           ProtocolSupport.unsupportedOperation();
/* 1596 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearReplyTo()
/*      */         {
/* 1601 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setReplyToAsBytes(byte[] x) {
/* 1604 */           ProtocolSupport.unsupportedOperation();
/* 1605 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setReplyTo(String v) {
/* 1608 */           ProtocolSupport.unsupportedOperation();
/* 1609 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setReplyTo(String v, Charset cs) {
/* 1612 */           ProtocolSupport.unsupportedOperation();
/* 1613 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearTo()
/*      */         {
/* 1618 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setToAsBytes(int i, byte[] v) {
/* 1621 */           ProtocolSupport.unsupportedOperation();
/* 1622 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setTo(int i, String v) {
/* 1625 */           ProtocolSupport.unsupportedOperation();
/* 1626 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage addToAsBytes(byte[] v) {
/* 1629 */           ProtocolSupport.unsupportedOperation();
/* 1630 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage addTo(String v) {
/* 1633 */           ProtocolSupport.unsupportedOperation();
/* 1634 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage setTo(int i, String v, Charset cs) {
/* 1638 */           ProtocolSupport.unsupportedOperation();
/* 1639 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage addTo(String v, Charset cs) {
/* 1643 */           ProtocolSupport.unsupportedOperation();
/* 1644 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearCc()
/*      */         {
/* 1649 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setCcAsBytes(int i, byte[] v) {
/* 1652 */           ProtocolSupport.unsupportedOperation();
/* 1653 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setCc(int i, String v) {
/* 1656 */           ProtocolSupport.unsupportedOperation();
/* 1657 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage addCcAsBytes(byte[] v) {
/* 1660 */           ProtocolSupport.unsupportedOperation();
/* 1661 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage addCc(String v) {
/* 1664 */           ProtocolSupport.unsupportedOperation();
/* 1665 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage setCc(int i, String v, Charset cs) {
/* 1669 */           ProtocolSupport.unsupportedOperation();
/* 1670 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage addCc(String v, Charset cs) {
/* 1674 */           ProtocolSupport.unsupportedOperation();
/* 1675 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearBcc()
/*      */         {
/* 1680 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setBccAsBytes(int i, byte[] v) {
/* 1683 */           ProtocolSupport.unsupportedOperation();
/* 1684 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setBcc(int i, String v) {
/* 1687 */           ProtocolSupport.unsupportedOperation();
/* 1688 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage addBccAsBytes(byte[] v) {
/* 1691 */           ProtocolSupport.unsupportedOperation();
/* 1692 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage addBcc(String v) {
/* 1695 */           ProtocolSupport.unsupportedOperation();
/* 1696 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage setBcc(int i, String v, Charset cs) {
/* 1700 */           ProtocolSupport.unsupportedOperation();
/* 1701 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage addBcc(String v, Charset cs) {
/* 1705 */           ProtocolSupport.unsupportedOperation();
/* 1706 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearSubject()
/*      */         {
/* 1711 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setSubjectAsBytes(byte[] x) {
/* 1714 */           ProtocolSupport.unsupportedOperation();
/* 1715 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setSubject(String v) {
/* 1718 */           ProtocolSupport.unsupportedOperation();
/* 1719 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setSubject(String v, Charset cs) {
/* 1722 */           ProtocolSupport.unsupportedOperation();
/* 1723 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearTextBody()
/*      */         {
/* 1728 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setTextBodyAsBytes(byte[] x) {
/* 1731 */           ProtocolSupport.unsupportedOperation();
/* 1732 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setTextBody(String v) {
/* 1735 */           ProtocolSupport.unsupportedOperation();
/* 1736 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setTextBody(String v, Charset cs) {
/* 1739 */           ProtocolSupport.unsupportedOperation();
/* 1740 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearHtmlBody()
/*      */         {
/* 1745 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setHtmlBodyAsBytes(byte[] x) {
/* 1748 */           ProtocolSupport.unsupportedOperation();
/* 1749 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setHtmlBody(String v) {
/* 1752 */           ProtocolSupport.unsupportedOperation();
/* 1753 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage setHtmlBody(String v, Charset cs) {
/* 1756 */           ProtocolSupport.unsupportedOperation();
/* 1757 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage clearAttachment()
/*      */         {
/* 1762 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment getMutableAttachment(int i) {
/* 1765 */           return (MailServicePb.MailAttachment)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public MailServicePb.MailAttachment addAttachment() {
/* 1768 */           return (MailServicePb.MailAttachment)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public MailServicePb.MailAttachment addAttachment(MailServicePb.MailAttachment v) {
/* 1771 */           return (MailServicePb.MailAttachment)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public MailServicePb.MailAttachment insertAttachment(int i, MailServicePb.MailAttachment v) {
/* 1774 */           return (MailServicePb.MailAttachment)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public MailServicePb.MailAttachment removeAttachment(int i) {
/* 1777 */           return (MailServicePb.MailAttachment)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailMessage mergeFrom(MailServicePb.MailMessage that) {
/* 1781 */           ProtocolSupport.unsupportedOperation();
/* 1782 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1785 */           ProtocolSupport.unsupportedOperation();
/* 1786 */           return false;
/*      */         }
/*      */         public MailServicePb.MailMessage freeze() {
/* 1789 */           return this;
/*      */         }
/*      */         public MailServicePb.MailMessage unfreeze() {
/* 1792 */           ProtocolSupport.unsupportedOperation();
/* 1793 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1796 */           return true;
/*      */         }
/*      */       };
/* 1844 */       text = new String[10];
/*      */ 
/* 1846 */       text[0] = "ErrorCode";
/* 1847 */       text[1] = "Sender";
/* 1848 */       text[2] = "ReplyTo";
/* 1849 */       text[3] = "To";
/* 1850 */       text[4] = "Cc";
/* 1851 */       text[5] = "Bcc";
/* 1852 */       text[6] = "Subject";
/* 1853 */       text[7] = "TextBody";
/* 1854 */       text[8] = "HtmlBody";
/* 1855 */       text[9] = "Attachment";
/*      */ 
/* 1858 */       types = new int[10];
/*      */ 
/* 1860 */       Arrays.fill(types, 6);
/* 1861 */       types[0] = 0;
/* 1862 */       types[1] = 2;
/* 1863 */       types[2] = 2;
/* 1864 */       types[3] = 2;
/* 1865 */       types[4] = 2;
/* 1866 */       types[5] = 2;
/* 1867 */       types[6] = 2;
/* 1868 */       types[7] = 2;
/* 1869 */       types[8] = 2;
/* 1870 */       types[9] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1409 */       private static final ProtocolType protocolType = new ProtocolType(MailServicePb.MailMessage.class, "Z!apphosting/api/mail_service.proto\n\026apphosting.MailMessage\023\032\006Sender \001(\0020\t8\002\024\023\032\007ReplyTo \002(\0020\t8\001\024\023\032\002To \003(\0020\t8\003\024\023\032\002Cc \004(\0020\t8\003\024\023\032\003Bcc \005(\0020\t8\003\024\023\032\007Subject \006(\0020\t8\002\024\023\032\bTextBody \007(\0020\t8\001\024\023\032\bHtmlBody \b(\0020\t8\001\024\023\032\nAttachment \t(\0020\0138\003J\031apphosting.MailAttachment\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("Sender", "sender", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("ReplyTo", "replyto", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("To", "to", 3, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("Cc", "cc", 4, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("Bcc", "bcc", 5, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("Subject", "subject", 6, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("TextBody", "textbody", 7, 3, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("HtmlBody", "htmlbody", 8, 4, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("Attachment", "attachment", 9, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, MailServicePb.MailAttachment.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MailAttachment extends ProtocolMessage<MailAttachment>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  259 */     private byte[] filename_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  260 */     private byte[] data_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final MailAttachment IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kFileName = 1;
/*      */     public static final int kData = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getFileNameAsBytes()
/*      */     {
/*  266 */       return this.filename_;
/*      */     }
/*      */     public final boolean hasFileName() {
/*  269 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public MailAttachment clearFileName() {
/*  272 */       this.optional_0_ &= -2;
/*  273 */       this.filename_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  274 */       return this;
/*      */     }
/*      */     public MailAttachment setFileNameAsBytes(byte[] x) {
/*  277 */       this.optional_0_ |= 1;
/*  278 */       this.filename_ = x;
/*  279 */       return this;
/*      */     }
/*      */     public final String getFileName() {
/*  282 */       return ProtocolSupport.toStringUtf8(this.filename_);
/*      */     }
/*      */     public MailAttachment setFileName(String v) {
/*  285 */       if (v == null) throw new NullPointerException();
/*  286 */       this.optional_0_ |= 1;
/*  287 */       this.filename_ = ProtocolSupport.toBytesUtf8(v);
/*  288 */       return this;
/*      */     }
/*      */     public final String getFileName(Charset cs) {
/*  291 */       return ProtocolSupport.toString(this.filename_, cs);
/*      */     }
/*      */     public MailAttachment setFileName(String v, Charset cs) {
/*  294 */       if (v == null) throw new NullPointerException();
/*  295 */       this.optional_0_ |= 1;
/*  296 */       this.filename_ = ProtocolSupport.toBytes(v, cs);
/*  297 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getDataAsBytes()
/*      */     {
/*  302 */       return this.data_;
/*      */     }
/*      */     public final boolean hasData() {
/*  305 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public MailAttachment clearData() {
/*  308 */       this.optional_0_ &= -3;
/*  309 */       this.data_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  310 */       return this;
/*      */     }
/*      */     public MailAttachment setDataAsBytes(byte[] x) {
/*  313 */       this.optional_0_ |= 2;
/*  314 */       this.data_ = x;
/*  315 */       return this;
/*      */     }
/*      */     public final String getData() {
/*  318 */       return ProtocolSupport.toStringUtf8(this.data_);
/*      */     }
/*      */     public MailAttachment setData(String v) {
/*  321 */       if (v == null) throw new NullPointerException();
/*  322 */       this.optional_0_ |= 2;
/*  323 */       this.data_ = ProtocolSupport.toBytesUtf8(v);
/*  324 */       return this;
/*      */     }
/*      */     public final String getData(Charset cs) {
/*  327 */       return ProtocolSupport.toString(this.data_, cs);
/*      */     }
/*      */     public MailAttachment setData(String v, Charset cs) {
/*  330 */       if (v == null) throw new NullPointerException();
/*  331 */       this.optional_0_ |= 2;
/*  332 */       this.data_ = ProtocolSupport.toBytes(v, cs);
/*  333 */       return this;
/*      */     }
/*      */ 
/*      */     public MailAttachment mergeFrom(MailAttachment that)
/*      */     {
/*  340 */       assert (that != this);
/*  341 */       int this_t0 = this.optional_0_;
/*  342 */       int that_t0 = that.optional_0_;
/*      */ 
/*  344 */       if ((that_t0 & 0x1) != 0) {
/*  345 */         this_t0 |= 1;
/*  346 */         this.filename_ = that.filename_;
/*      */       }
/*      */ 
/*  349 */       if ((that_t0 & 0x2) != 0) {
/*  350 */         this_t0 |= 2;
/*  351 */         this.data_ = that.data_;
/*      */       }
/*      */ 
/*  354 */       if (that.uninterpreted != null) {
/*  355 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  357 */       this.optional_0_ = this_t0;
/*  358 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(MailAttachment that) {
/*  362 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(MailAttachment that) {
/*  366 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(MailAttachment that, boolean ignoreUninterpreted) {
/*  370 */       if (that == null) return false;
/*  371 */       if (that == this) return true;
/*  372 */       int this_t0 = this.optional_0_;
/*  373 */       int that_t0 = that.optional_0_;
/*  374 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  376 */       if (((this_t0 & 0x1) != 0) && 
/*  377 */         (!Arrays.equals(this.filename_, that.filename_))) return false;
/*      */ 
/*  380 */       if (((this_t0 & 0x2) != 0) && 
/*  381 */         (!Arrays.equals(this.data_, that.data_))) return false;
/*      */ 
/*  384 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  389 */       return ((that instanceof MailAttachment)) && (equals((MailAttachment)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  393 */       int hash = -1936143812;
/*      */ 
/*  395 */       int this_t0 = this.optional_0_;
/*  396 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.filename_) : -113);
/*      */ 
/*  398 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.data_) : -113);
/*  399 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  400 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  402 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  406 */       int this_t0 = this.optional_0_;
/*  407 */       if ((this_t0 & 0x3) != 3)
/*      */       {
/*  409 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/*  413 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  419 */       int n = 2 + Protocol.stringSize(this.filename_.length) + Protocol.stringSize(this.data_.length);
/*      */ 
/*  422 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  429 */       int n = 12 + this.filename_.length + this.data_.length;
/*      */ 
/*  431 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  436 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  440 */       this.optional_0_ = 0;
/*  441 */       this.filename_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  442 */       this.data_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  443 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public MailAttachment newInstance() {
/*  447 */       return new MailAttachment();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  451 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  472 */       sink.putByte(10);
/*  473 */       sink.putPrefixedData(this.filename_);
/*      */ 
/*  475 */       sink.putByte(18);
/*  476 */       sink.putPrefixedData(this.data_);
/*      */ 
/*  478 */       if (this.uninterpreted != null)
/*  479 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  484 */       boolean result = true;
/*  485 */       int this_t0 = this.optional_0_;
/*      */ 
/*  487 */       while (source.hasRemaining()) {
/*  488 */         int tt = source.getVarInt();
/*  489 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  493 */           result = false;
/*  494 */           break;
/*      */         case 10:
/*  497 */           this.filename_ = source.getPrefixedData();
/*  498 */           this_t0 |= 1;
/*  499 */           break;
/*      */         case 18:
/*  502 */           this.data_ = source.getPrefixedData();
/*  503 */           this_t0 |= 2;
/*  504 */           break;
/*      */         default:
/*  506 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  511 */       this.optional_0_ = this_t0;
/*  512 */       return result;
/*      */     }
/*      */ 
/*      */     public MailAttachment getDefaultInstanceForType()
/*      */     {
/*  517 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final MailAttachment getDefaultInstance() {
/*  521 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public MailAttachment freeze()
/*      */     {
/*  586 */       this.filename_ = ProtocolSupport.freezeString(this.filename_);
/*  587 */       this.data_ = ProtocolSupport.freezeString(this.data_);
/*  588 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  591 */       if (this.uninterpreted == null) {
/*  592 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  594 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  525 */       IMMUTABLE_DEFAULT_INSTANCE = new MailAttachment()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public MailServicePb.MailAttachment clearFileName()
/*      */         {
/*  533 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment setFileNameAsBytes(byte[] x) {
/*  536 */           ProtocolSupport.unsupportedOperation();
/*  537 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment setFileName(String v) {
/*  540 */           ProtocolSupport.unsupportedOperation();
/*  541 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment setFileName(String v, Charset cs) {
/*  544 */           ProtocolSupport.unsupportedOperation();
/*  545 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailAttachment clearData()
/*      */         {
/*  550 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment setDataAsBytes(byte[] x) {
/*  553 */           ProtocolSupport.unsupportedOperation();
/*  554 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment setData(String v) {
/*  557 */           ProtocolSupport.unsupportedOperation();
/*  558 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment setData(String v, Charset cs) {
/*  561 */           ProtocolSupport.unsupportedOperation();
/*  562 */           return this;
/*      */         }
/*      */ 
/*      */         public MailServicePb.MailAttachment mergeFrom(MailServicePb.MailAttachment that) {
/*  566 */           ProtocolSupport.unsupportedOperation();
/*  567 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  570 */           ProtocolSupport.unsupportedOperation();
/*  571 */           return false;
/*      */         }
/*      */         public MailServicePb.MailAttachment freeze() {
/*  574 */           return this;
/*      */         }
/*      */         public MailServicePb.MailAttachment unfreeze() {
/*  577 */           ProtocolSupport.unsupportedOperation();
/*  578 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  581 */           return true;
/*      */         }
/*      */       };
/*  600 */       text = new String[3];
/*      */ 
/*  602 */       text[0] = "ErrorCode";
/*  603 */       text[1] = "FileName";
/*  604 */       text[2] = "Data";
/*      */ 
/*  607 */       types = new int[3];
/*      */ 
/*  609 */       Arrays.fill(types, 6);
/*  610 */       types[0] = 0;
/*  611 */       types[1] = 2;
/*  612 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  455 */       private static final ProtocolType protocolType = new ProtocolType(MailServicePb.MailAttachment.class, "Z!apphosting/api/mail_service.proto\n\031apphosting.MailAttachment\023\032\bFileName \001(\0020\t8\002\024\023\032\004Data \002(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("FileName", "filename", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("Data", "data", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class MailServiceError extends ProtocolMessage<MailServiceError>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final MailServiceError IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public MailServiceError mergeFrom(MailServiceError that)
/*      */     {
/*   80 */       assert (that != this);
/*      */ 
/*   82 */       if (that.uninterpreted != null) {
/*   83 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   85 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(MailServiceError that) {
/*   89 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(MailServiceError that) {
/*   93 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(MailServiceError that, boolean ignoreUninterpreted) {
/*   97 */       if (that == null) return false;
/*   98 */       if (that == this) return true;
/*      */ 
/*  100 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  105 */       return ((that instanceof MailServiceError)) && (equals((MailServiceError)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  109 */       int hash = -448357120;
/*  110 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  111 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  113 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  117 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  121 */       int n = 0;
/*      */ 
/*  123 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  128 */       int n = 0;
/*      */ 
/*  130 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  135 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  139 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public MailServiceError newInstance() {
/*  143 */       return new MailServiceError();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  147 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  171 */       if (this.uninterpreted != null)
/*  172 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  177 */       boolean result = true;
/*      */ 
/*  179 */       while (source.hasRemaining()) {
/*  180 */         int tt = source.getVarInt();
/*  181 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  185 */           result = false;
/*  186 */           break;
/*      */         default:
/*  188 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  193 */       return result;
/*      */     }
/*      */ 
/*      */     public MailServiceError getDefaultInstanceForType()
/*      */     {
/*  198 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final MailServiceError getDefaultInstance() {
/*  202 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  232 */       if (this.uninterpreted == null) {
/*  233 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  235 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  206 */       IMMUTABLE_DEFAULT_INSTANCE = new MailServiceError()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public MailServicePb.MailServiceError mergeFrom(MailServicePb.MailServiceError that)
/*      */         {
/*  213 */           ProtocolSupport.unsupportedOperation();
/*  214 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  217 */           ProtocolSupport.unsupportedOperation();
/*  218 */           return false;
/*      */         }
/*      */         public MailServicePb.MailServiceError freeze() {
/*  221 */           return this;
/*      */         }
/*      */         public MailServicePb.MailServiceError unfreeze() {
/*  224 */           ProtocolSupport.unsupportedOperation();
/*  225 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  228 */           return true;
/*      */         }
/*      */       };
/*  239 */       text = new String[1];
/*      */ 
/*  241 */       text[0] = "ErrorCode";
/*      */ 
/*  244 */       types = new int[1];
/*      */ 
/*  246 */       Arrays.fill(types, 6);
/*  247 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  151 */       private static final ProtocolType protocolType = new ProtocolType(MailServicePb.MailServiceError.class, "", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   50 */       OK(0), 
/*   51 */       INTERNAL_ERROR(1), 
/*   52 */       BAD_REQUEST(2), 
/*   53 */       UNAUTHORIZED_SENDER(3), 
/*   54 */       INVALID_ATTACHMENT_TYPE(4);
/*      */ 
/*      */       public static final ErrorCode ErrorCode_MIN;
/*      */       public static final ErrorCode ErrorCode_MAX;
/*      */       private final int value;
/*      */ 
/*   59 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   62 */         switch (value) { case 0:
/*   63 */           return OK;
/*      */         case 1:
/*   64 */           return INTERNAL_ERROR;
/*      */         case 2:
/*   65 */           return BAD_REQUEST;
/*      */         case 3:
/*   66 */           return UNAUTHORIZED_SENDER;
/*      */         case 4:
/*   67 */           return INVALID_ATTACHMENT_TYPE;
/*      */         }
/*   69 */         return null;
/*      */       }
/*      */ 
/*      */       private ErrorCode(int v) {
/*   73 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   56 */         ErrorCode_MIN = OK;
/*   57 */         ErrorCode_MAX = INVALID_ATTACHMENT_TYPE;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.mail.MailServicePb
 * JD-Core Version:    0.6.0
 */