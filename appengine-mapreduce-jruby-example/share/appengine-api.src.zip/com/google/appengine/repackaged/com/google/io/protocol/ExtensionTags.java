/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Maps;
/*     */ import java.io.Serializable;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public final class ExtensionTags
/*     */   implements MessageAppender, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 0L;
/*  23 */   private final Map<Integer, LazyParsingExtension> delegate = Maps.newTreeMap();
/*     */ 
/*     */   public final void addLengthDelimited(int tagNumber, byte[] bytes)
/*     */   {
/*  27 */     throw new UnsupportedOperationException("todo(danignatoff): implement");
/*     */   }
/*     */ 
/*     */   public final void addMessage(int tagNumber, ProtocolMessage message)
/*     */   {
/*  33 */     throw new UnsupportedOperationException("todo(danignatoff): implement");
/*     */   }
/*     */ 
/*     */   public final void putBytes(Integer key, byte[] value) {
/*  37 */     if (this.delegate.containsKey(key))
/*  38 */       ((LazyParsingExtension)this.delegate.get(key)).addRaw(ByteBuffer.wrap(value));
/*     */     else
/*  40 */       this.delegate.put(key, LazyParsingExtension.raw(ByteBuffer.wrap(value)));
/*     */   }
/*     */ 
/*     */   public final void putExtension(Integer key, LazyParsingExtension extension)
/*     */   {
/*  45 */     this.delegate.put(key, extension);
/*     */   }
/*     */ 
/*     */   public final void putAll(ExtensionTags other)
/*     */   {
/*  50 */     for (Map.Entry tagAndData : other.delegate.entrySet()) {
/*  51 */       LazyParsingExtension ext = get((Integer)tagAndData.getKey());
/*  52 */       if (ext != null)
/*  53 */         ext.merge((LazyParsingExtension)tagAndData.getValue());
/*     */       else
/*  55 */         putExtension((Integer)tagAndData.getKey(), (LazyParsingExtension)tagAndData.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void remove(Integer key)
/*     */   {
/*  61 */     this.delegate.remove(key);
/*     */   }
/*     */ 
/*     */   public final boolean containsKey(Integer key) {
/*  65 */     return this.delegate.containsKey(key);
/*     */   }
/*     */ 
/*     */   public final LazyParsingExtension get(Integer key) {
/*  69 */     return (LazyParsingExtension)this.delegate.get(key);
/*     */   }
/*     */ 
/*     */   public final int encodingSize()
/*     */   {
/*  74 */     int result = 0;
/*  75 */     for (Map.Entry tagAndData : this.delegate.entrySet()) {
/*  76 */       LazyParsingExtension ext = (LazyParsingExtension)tagAndData.getValue();
/*  77 */       if (ext.isParsed()) {
/*  78 */         result += ext.parsedAs.encodingSize(ext.parsed);
/*     */       } else {
/*  80 */         result += ext.raw.size() * Protocol.varIntSize(((Integer)tagAndData.getKey()).intValue());
/*  81 */         for (ByteBuffer b : ext.raw) {
/*  82 */           result += b.remaining();
/*     */         }
/*     */       }
/*     */     }
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */   public final int maxEncodingSize() {
/*  90 */     return encodingSize();
/*     */   }
/*     */ 
/*     */   public final void put(ProtocolSink sink)
/*     */   {
/*  95 */     for (Iterator i$ = this.delegate.entrySet().iterator(); i$.hasNext(); ) { tagAndData = (Map.Entry)i$.next();
/*  96 */       if (((LazyParsingExtension)tagAndData.getValue()).isParsed())
/*  97 */         ((LazyParsingExtension)tagAndData.getValue()).parsedAs.write(((LazyParsingExtension)tagAndData.getValue()).parsed, sink);
/*     */       else
/*  99 */         for (ByteBuffer b : ((LazyParsingExtension)tagAndData.getValue()).raw) {
/* 100 */           sink.putVarInt(((Integer)tagAndData.getKey()).intValue());
/* 101 */           sink.putBytes(b.array());
/*     */         }
/*     */     }
/*     */     Map.Entry tagAndData;
/*     */   }
/*     */ 
/*     */   public static boolean equivalent(ExtensionTags t1, ExtensionTags t2)
/*     */   {
/* 113 */     if ((t1 == null) || (t1.effectivelyEmpty())) {
/* 114 */       return (t2 == null) || (t2.effectivelyEmpty());
/*     */     }
/* 116 */     return t1.equals(t2);
/*     */   }
/*     */ 
/*     */   public final boolean equals(Object obj)
/*     */   {
/* 122 */     if ((obj instanceof ExtensionTags)) {
/* 123 */       ExtensionTags other = (ExtensionTags)obj;
/* 124 */       return this.delegate.equals(other.delegate);
/*     */     }
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 144 */     throw new UnsupportedOperationException("hashCode is not supported for ExtensionTags");
/*     */   }
/*     */ 
/*     */   private boolean effectivelyEmpty()
/*     */   {
/* 149 */     for (Integer key : this.delegate.keySet()) {
/* 150 */       LazyParsingExtension e = (LazyParsingExtension)this.delegate.get(key);
/* 151 */       if (!e.isParsed()) {
/* 152 */         return false;
/*     */       }
/* 154 */       if (!(e.parsed instanceof Collection)) {
/* 155 */         return false;
/*     */       }
/* 157 */       if (!((Collection)e.parsed).isEmpty()) {
/* 158 */         return false;
/*     */       }
/*     */     }
/* 161 */     return true;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ExtensionTags
 * JD-Core Version:    0.6.0
 */