/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ public class ImagesServiceFailureException extends RuntimeException
/*    */ {
/*    */   public ImagesServiceFailureException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImagesServiceFailureException
 * JD-Core Version:    0.6.0
 */