/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import com.google.common.annotations.GwtIncompatible;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.util.EnumMap;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ @GwtCompatible(emulated=true)
/*    */ public final class EnumMultiset<E extends Enum<E>> extends AbstractMapBasedMultiset<E>
/*    */ {
/*    */   private transient Class<E> type;
/*    */ 
/*    */   @GwtIncompatible("Not needed in emulated source")
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public static <E extends Enum<E>> EnumMultiset<E> create(Class<E> type)
/*    */   {
/* 42 */     return new EnumMultiset(type);
/*    */   }
/*    */ 
/*    */   public static <E extends Enum<E>> EnumMultiset<E> create(Iterable<E> elements)
/*    */   {
/* 53 */     Iterator iterator = elements.iterator();
/* 54 */     Preconditions.checkArgument(iterator.hasNext(), "EnumMultiset constructor passed empty Iterable");
/*    */ 
/* 56 */     EnumMultiset multiset = new EnumMultiset(((Enum)iterator.next()).getDeclaringClass());
/*    */ 
/* 58 */     Iterables.addAll(multiset, elements);
/* 59 */     return multiset;
/*    */   }
/*    */ 
/*    */   private EnumMultiset(Class<E> type)
/*    */   {
/* 66 */     super(new EnumMap(type));
/* 67 */     this.type = type;
/*    */   }
/*    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*    */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 72 */     stream.defaultWriteObject();
/* 73 */     stream.writeObject(this.type);
/* 74 */     Serialization.writeMultiset(this, stream);
/*    */   }
/*    */ 
/*    */   @GwtIncompatible("java.io.ObjectInputStream")
/*    */   private void readObject(ObjectInputStream stream)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 85 */     stream.defaultReadObject();
/*    */ 
/* 87 */     Class localType = (Class)stream.readObject();
/* 88 */     this.type = localType;
/* 89 */     setBackingMap(new EnumMap(this.type));
/* 90 */     Serialization.populateMultiset(this, stream);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.EnumMultiset
 * JD-Core Version:    0.6.0
 */