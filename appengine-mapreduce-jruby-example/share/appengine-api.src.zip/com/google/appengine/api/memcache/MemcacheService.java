/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public abstract interface MemcacheService
/*    */ {
/*    */   public abstract String getNamespace();
/*    */ 
/*    */   @Deprecated
/*    */   public abstract void setNamespace(String paramString);
/*    */ 
/*    */   public abstract Object get(Object paramObject);
/*    */ 
/*    */   public abstract boolean contains(Object paramObject);
/*    */ 
/*    */   public abstract <T> Map<T, Object> getAll(Collection<T> paramCollection);
/*    */ 
/*    */   public abstract boolean put(Object paramObject1, Object paramObject2, Expiration paramExpiration, SetPolicy paramSetPolicy);
/*    */ 
/*    */   public abstract void put(Object paramObject1, Object paramObject2, Expiration paramExpiration);
/*    */ 
/*    */   public abstract void put(Object paramObject1, Object paramObject2);
/*    */ 
/*    */   public abstract <T> Set<T> putAll(Map<T, ?> paramMap, Expiration paramExpiration, SetPolicy paramSetPolicy);
/*    */ 
/*    */   public abstract void putAll(Map<?, ?> paramMap, Expiration paramExpiration);
/*    */ 
/*    */   public abstract void putAll(Map<?, ?> paramMap);
/*    */ 
/*    */   public abstract boolean delete(Object paramObject);
/*    */ 
/*    */   public abstract boolean delete(Object paramObject, long paramLong);
/*    */ 
/*    */   public abstract <T> Set<T> deleteAll(Collection<T> paramCollection);
/*    */ 
/*    */   public abstract <T> Set<T> deleteAll(Collection<T> paramCollection, long paramLong);
/*    */ 
/*    */   public abstract Long increment(Object paramObject, long paramLong);
/*    */ 
/*    */   public abstract Long increment(Object paramObject, long paramLong, Long paramLong1);
/*    */ 
/*    */   public abstract <T> Map<T, Long> incrementAll(Collection<T> paramCollection, long paramLong);
/*    */ 
/*    */   public abstract <T> Map<T, Long> incrementAll(Collection<T> paramCollection, long paramLong, Long paramLong1);
/*    */ 
/*    */   public abstract <T> Map<T, Long> incrementAll(Map<T, Long> paramMap);
/*    */ 
/*    */   public abstract <T> Map<T, Long> incrementAll(Map<T, Long> paramMap, Long paramLong);
/*    */ 
/*    */   public abstract void clearAll();
/*    */ 
/*    */   public abstract Stats getStatistics();
/*    */ 
/*    */   public abstract void setErrorHandler(ErrorHandler paramErrorHandler);
/*    */ 
/*    */   public abstract ErrorHandler getErrorHandler();
/*    */ 
/*    */   public static enum SetPolicy
/*    */   {
/* 49 */     SET_ALWAYS, 
/*    */ 
/* 54 */     ADD_ONLY_IF_NOT_PRESENT, 
/*    */ 
/* 59 */     REPLACE_ONLY_IF_PRESENT;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.MemcacheService
 * JD-Core Version:    0.6.0
 */