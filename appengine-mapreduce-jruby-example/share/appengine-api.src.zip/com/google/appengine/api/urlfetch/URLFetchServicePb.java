/*      */ package com.google.appengine.api.urlfetch;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.protobuf.BlockingRpcChannel;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.BlockingService;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.Descriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumValueDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.MethodDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.ServiceDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.Builder;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Internal.EnumLiteMap;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcCallback;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcChannel;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcController;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcUtil;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Service;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ServiceException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet.Builder;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class URLFetchServicePb
/*      */ {
/*      */   private static Descriptors.Descriptor internal_static_apphosting_URLFetchServiceError_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_URLFetchServiceError_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_URLFetchRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_URLFetchRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_URLFetchRequest_Header_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_URLFetchRequest_Header_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_URLFetchResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_URLFetchResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_URLFetchResponse_Header_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_URLFetchResponse_Header_fieldAccessorTable;
/*      */   private static Descriptors.FileDescriptor descriptor;
/*      */ 
/*      */   public static void registerAllExtensions(ExtensionRegistry registry)
/*      */   {
/*      */   }
/*      */ 
/*      */   public static Descriptors.FileDescriptor getDescriptor()
/*      */   {
/* 2821 */     return descriptor;
/*      */   }
/*      */   public static void internalForceInit() {
/*      */   }
/*      */   static {
/* 2826 */     String[] descriptorData = { "", "dline\030\b \001(\001\032$\n\006Header\022\013\n\003Key\030\004 \002(\t\022\r\n\005Value\030\005 \002(\t\"A\n\rRequestMethod\022\007\n\003GET\020\001\022\b\n\004POST\020\002\022\b\n\004HEAD\020\003\022\007\n\003PUT\020\004\022\n\n\006DELETE\020\005\"×\002\n\020URLFetchResponse\022\017\n\007Content\030\001 \001(\f\022\022\n\nStatusCode\030\002 \002(\005\0223\n\006header\030\003 \003(\n2#.apphosting.URLFetchResponse.Header\022\"\n\023ContentWasTruncated\030\006 \001(\b:\005false\022\031\n\021ExternalBytesSent\030\007 \001(\003\022\035\n\025ExternalBytesReceived\030\b \001(\003\022\020\n\bFinalUrl\030\t \001(\t\022\035\n\022ApiCpuMilliseconds\030\n \001(\003:\0010\022\027\n\fApiBytesSent\030\013 \001(\003:\0010\022\033\n\020A", "piBytesReceived\030\f \001(\003:\0010\032$\n\006Header\022\013\n\003Key\030\004 \002(\t\022\r\n\005Value\030\005 \002(\t2U\n\017URLFetchService\022B\n\005Fetch\022\033.apphosting.URLFetchRequest\032\034.apphosting.URLFetchResponseB<\n!com.google.appengine.api.urlfetch\020\001 \001(\002B\021URLFetchServicePb" };
/*      */ 
/* 2854 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*      */     {
/*      */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*      */       {
/* 2858 */         URLFetchServicePb.access$6502(root);
/* 2859 */         URLFetchServicePb.access$002((Descriptors.Descriptor)URLFetchServicePb.getDescriptor().getMessageTypes().get(0));
/*      */ 
/* 2861 */         URLFetchServicePb.access$102(new GeneratedMessage.FieldAccessorTable(URLFetchServicePb.internal_static_apphosting_URLFetchServiceError_descriptor, new String[0], URLFetchServicePb.URLFetchServiceError.class, URLFetchServicePb.URLFetchServiceError.Builder.class));
/*      */ 
/* 2867 */         URLFetchServicePb.access$502((Descriptors.Descriptor)URLFetchServicePb.getDescriptor().getMessageTypes().get(1));
/*      */ 
/* 2869 */         URLFetchServicePb.access$602(new GeneratedMessage.FieldAccessorTable(URLFetchServicePb.internal_static_apphosting_URLFetchRequest_descriptor, new String[] { "Method", "Url", "Header", "Payload", "FollowRedirects", "Deadline" }, URLFetchServicePb.URLFetchRequest.class, URLFetchServicePb.URLFetchRequest.Builder.class));
/*      */ 
/* 2875 */         URLFetchServicePb.access$702((Descriptors.Descriptor)URLFetchServicePb.internal_static_apphosting_URLFetchRequest_descriptor.getNestedTypes().get(0));
/*      */ 
/* 2877 */         URLFetchServicePb.access$802(new GeneratedMessage.FieldAccessorTable(URLFetchServicePb.internal_static_apphosting_URLFetchRequest_Header_descriptor, new String[] { "Key", "Value" }, URLFetchServicePb.URLFetchRequest.Header.class, URLFetchServicePb.URLFetchRequest.Header.Builder.class));
/*      */ 
/* 2883 */         URLFetchServicePb.access$3002((Descriptors.Descriptor)URLFetchServicePb.getDescriptor().getMessageTypes().get(2));
/*      */ 
/* 2885 */         URLFetchServicePb.access$3102(new GeneratedMessage.FieldAccessorTable(URLFetchServicePb.internal_static_apphosting_URLFetchResponse_descriptor, new String[] { "Content", "StatusCode", "Header", "ContentWasTruncated", "ExternalBytesSent", "ExternalBytesReceived", "FinalUrl", "ApiCpuMilliseconds", "ApiBytesSent", "ApiBytesReceived" }, URLFetchServicePb.URLFetchResponse.class, URLFetchServicePb.URLFetchResponse.Builder.class));
/*      */ 
/* 2891 */         URLFetchServicePb.access$3202((Descriptors.Descriptor)URLFetchServicePb.internal_static_apphosting_URLFetchResponse_descriptor.getNestedTypes().get(0));
/*      */ 
/* 2893 */         URLFetchServicePb.access$3302(new GeneratedMessage.FieldAccessorTable(URLFetchServicePb.internal_static_apphosting_URLFetchResponse_Header_descriptor, new String[] { "Key", "Value" }, URLFetchServicePb.URLFetchResponse.Header.class, URLFetchServicePb.URLFetchResponse.Header.Builder.class));
/*      */ 
/* 2899 */         return null;
/*      */       }
/*      */     };
/* 2902 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/*      */   }
/*      */ 
/*      */   public static abstract class URLFetchService
/*      */     implements Service
/*      */   {
/*      */     public static Service newReflectiveService(Interface impl)
/*      */     {
/* 2586 */       return new URLFetchService(impl)
/*      */       {
/*      */         public void fetch(RpcController controller, URLFetchServicePb.URLFetchRequest request, RpcCallback<URLFetchServicePb.URLFetchResponse> done)
/*      */         {
/* 2592 */           this.val$impl.fetch(controller, request, done);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static BlockingService newReflectiveBlockingService(BlockingInterface impl)
/*      */     {
/* 2600 */       return new BlockingService(impl)
/*      */       {
/*      */         public final Descriptors.ServiceDescriptor getDescriptorForType() {
/* 2603 */           return URLFetchServicePb.URLFetchService.getDescriptor();
/*      */         }
/*      */ 
/*      */         public final Message callBlockingMethod(Descriptors.MethodDescriptor method, RpcController controller, Message request)
/*      */           throws ServiceException
/*      */         {
/* 2611 */           if (method.getService() != URLFetchServicePb.URLFetchService.getDescriptor()) {
/* 2612 */             throw new IllegalArgumentException("Service.callBlockingMethod() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 2616 */           switch (method.getIndex()) {
/*      */           case 0:
/* 2618 */             return this.val$impl.fetch(controller, (URLFetchServicePb.URLFetchRequest)request);
/*      */           }
/* 2620 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */ 
/*      */         public final Message getRequestPrototype(Descriptors.MethodDescriptor method)
/*      */         {
/* 2627 */           if (method.getService() != URLFetchServicePb.URLFetchService.getDescriptor()) {
/* 2628 */             throw new IllegalArgumentException("Service.getRequestPrototype() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 2632 */           switch (method.getIndex()) {
/*      */           case 0:
/* 2634 */             return URLFetchServicePb.URLFetchRequest.getDefaultInstance();
/*      */           }
/* 2636 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */ 
/*      */         public final Message getResponsePrototype(Descriptors.MethodDescriptor method)
/*      */         {
/* 2643 */           if (method.getService() != URLFetchServicePb.URLFetchService.getDescriptor()) {
/* 2644 */             throw new IllegalArgumentException("Service.getResponsePrototype() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 2648 */           switch (method.getIndex()) {
/*      */           case 0:
/* 2650 */             return URLFetchServicePb.URLFetchResponse.getDefaultInstance();
/*      */           }
/* 2652 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public abstract void fetch(RpcController paramRpcController, URLFetchServicePb.URLFetchRequest paramURLFetchRequest, RpcCallback<URLFetchServicePb.URLFetchResponse> paramRpcCallback);
/*      */ 
/*      */     public static final Descriptors.ServiceDescriptor getDescriptor()
/*      */     {
/* 2667 */       return (Descriptors.ServiceDescriptor)URLFetchServicePb.getDescriptor().getServices().get(0);
/*      */     }
/*      */ 
/*      */     public final Descriptors.ServiceDescriptor getDescriptorForType() {
/* 2671 */       return getDescriptor();
/*      */     }
/*      */ 
/*      */     public final void callMethod(Descriptors.MethodDescriptor method, RpcController controller, Message request, RpcCallback<Message> done)
/*      */     {
/* 2680 */       if (method.getService() != getDescriptor()) {
/* 2681 */         throw new IllegalArgumentException("Service.callMethod() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 2685 */       switch (method.getIndex()) {
/*      */       case 0:
/* 2687 */         fetch(controller, (URLFetchServicePb.URLFetchRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 2690 */         return;
/*      */       }
/* 2692 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public final Message getRequestPrototype(Descriptors.MethodDescriptor method)
/*      */     {
/* 2699 */       if (method.getService() != getDescriptor()) {
/* 2700 */         throw new IllegalArgumentException("Service.getRequestPrototype() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 2704 */       switch (method.getIndex()) {
/*      */       case 0:
/* 2706 */         return URLFetchServicePb.URLFetchRequest.getDefaultInstance();
/*      */       }
/* 2708 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public final Message getResponsePrototype(Descriptors.MethodDescriptor method)
/*      */     {
/* 2715 */       if (method.getService() != getDescriptor()) {
/* 2716 */         throw new IllegalArgumentException("Service.getResponsePrototype() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 2720 */       switch (method.getIndex()) {
/*      */       case 0:
/* 2722 */         return URLFetchServicePb.URLFetchResponse.getDefaultInstance();
/*      */       }
/* 2724 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcChannel channel)
/*      */     {
/* 2730 */       return new Stub(channel, null);
/*      */     }
/*      */ 
/*      */     public static BlockingInterface newBlockingStub(BlockingRpcChannel channel)
/*      */     {
/* 2762 */       return new BlockingStub(channel, null);
/*      */     }
/*      */ 
/*      */     private static final class BlockingStub
/*      */       implements URLFetchServicePb.URLFetchService.BlockingInterface
/*      */     {
/*      */       private final BlockingRpcChannel channel;
/*      */ 
/*      */       private BlockingStub(BlockingRpcChannel channel)
/*      */       {
/* 2774 */         this.channel = channel;
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchResponse fetch(RpcController controller, URLFetchServicePb.URLFetchRequest request)
/*      */         throws ServiceException
/*      */       {
/* 2783 */         return (URLFetchServicePb.URLFetchResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)URLFetchServicePb.URLFetchService.getDescriptor().getMethods().get(0), controller, request, URLFetchServicePb.URLFetchResponse.getDefaultInstance());
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface
/*      */     {
/*      */       public abstract URLFetchServicePb.URLFetchResponse fetch(RpcController paramRpcController, URLFetchServicePb.URLFetchRequest paramURLFetchRequest)
/*      */         throws ServiceException;
/*      */     }
/*      */ 
/*      */     public static final class Stub extends URLFetchServicePb.URLFetchService
/*      */       implements URLFetchServicePb.URLFetchService.Interface
/*      */     {
/*      */       private final RpcChannel channel;
/*      */ 
/*      */       private Stub(RpcChannel channel)
/*      */       {
/* 2735 */         this.channel = channel;
/*      */       }
/*      */ 
/*      */       public RpcChannel getChannel()
/*      */       {
/* 2741 */         return this.channel;
/*      */       }
/*      */ 
/*      */       public void fetch(RpcController controller, URLFetchServicePb.URLFetchRequest request, RpcCallback<URLFetchServicePb.URLFetchResponse> done)
/*      */       {
/* 2748 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(0), controller, request, URLFetchServicePb.URLFetchResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, URLFetchServicePb.URLFetchResponse.class, URLFetchServicePb.URLFetchResponse.getDefaultInstance()));
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface
/*      */     {
/*      */       public abstract void fetch(RpcController paramRpcController, URLFetchServicePb.URLFetchRequest paramURLFetchRequest, RpcCallback<URLFetchServicePb.URLFetchResponse> paramRpcCallback);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class URLFetchResponse extends GeneratedMessage
/*      */   {
/* 2564 */     private static final URLFetchResponse defaultInstance = new URLFetchResponse(true);
/*      */     public static final int CONTENT_FIELD_NUMBER = 1;
/*      */     private boolean hasContent;
/*      */     private ByteString content_;
/*      */     public static final int STATUSCODE_FIELD_NUMBER = 2;
/*      */     private boolean hasStatusCode;
/*      */     private int statusCode_;
/*      */     public static final int HEADER_FIELD_NUMBER = 3;
/*      */     private List<Header> header_;
/*      */     public static final int CONTENTWASTRUNCATED_FIELD_NUMBER = 6;
/*      */     private boolean hasContentWasTruncated;
/*      */     private boolean contentWasTruncated_;
/*      */     public static final int EXTERNALBYTESSENT_FIELD_NUMBER = 7;
/*      */     private boolean hasExternalBytesSent;
/*      */     private long externalBytesSent_;
/*      */     public static final int EXTERNALBYTESRECEIVED_FIELD_NUMBER = 8;
/*      */     private boolean hasExternalBytesReceived;
/*      */     private long externalBytesReceived_;
/*      */     public static final int FINALURL_FIELD_NUMBER = 9;
/*      */     private boolean hasFinalUrl;
/*      */     private String finalUrl_;
/*      */     public static final int APICPUMILLISECONDS_FIELD_NUMBER = 10;
/*      */     private boolean hasApiCpuMilliseconds;
/*      */     private long apiCpuMilliseconds_;
/*      */     public static final int APIBYTESSENT_FIELD_NUMBER = 11;
/*      */     private boolean hasApiBytesSent;
/*      */     private long apiBytesSent_;
/*      */     public static final int APIBYTESRECEIVED_FIELD_NUMBER = 12;
/*      */     private boolean hasApiBytesReceived;
/*      */     private long apiBytesReceived_;
/* 1953 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private URLFetchResponse(Builder builder)
/*      */     {
/* 1405 */       super();
/*      */     }
/*      */     private URLFetchResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse getDefaultInstance() {
/* 1411 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public URLFetchResponse getDefaultInstanceForType() {
/* 1415 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 1420 */       return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 1425 */       return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasContent()
/*      */     {
/* 1790 */       return this.hasContent;
/*      */     }
/*      */     public ByteString getContent() {
/* 1793 */       return this.content_;
/*      */     }
/*      */ 
/*      */     public boolean hasStatusCode()
/*      */     {
/* 1801 */       return this.hasStatusCode;
/*      */     }
/*      */     public int getStatusCode() {
/* 1804 */       return this.statusCode_;
/*      */     }
/*      */ 
/*      */     public List<Header> getHeaderList()
/*      */     {
/* 1811 */       return this.header_;
/*      */     }
/*      */     public int getHeaderCount() {
/* 1814 */       return this.header_.size();
/*      */     }
/*      */     public Header getHeader(int index) {
/* 1817 */       return (Header)this.header_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasContentWasTruncated()
/*      */     {
/* 1825 */       return this.hasContentWasTruncated;
/*      */     }
/*      */     public boolean getContentWasTruncated() {
/* 1828 */       return this.contentWasTruncated_;
/*      */     }
/*      */ 
/*      */     public boolean hasExternalBytesSent()
/*      */     {
/* 1836 */       return this.hasExternalBytesSent;
/*      */     }
/*      */     public long getExternalBytesSent() {
/* 1839 */       return this.externalBytesSent_;
/*      */     }
/*      */ 
/*      */     public boolean hasExternalBytesReceived()
/*      */     {
/* 1847 */       return this.hasExternalBytesReceived;
/*      */     }
/*      */     public long getExternalBytesReceived() {
/* 1850 */       return this.externalBytesReceived_;
/*      */     }
/*      */ 
/*      */     public boolean hasFinalUrl()
/*      */     {
/* 1858 */       return this.hasFinalUrl;
/*      */     }
/*      */     public String getFinalUrl() {
/* 1861 */       return this.finalUrl_;
/*      */     }
/*      */ 
/*      */     public boolean hasApiCpuMilliseconds()
/*      */     {
/* 1869 */       return this.hasApiCpuMilliseconds;
/*      */     }
/*      */     public long getApiCpuMilliseconds() {
/* 1872 */       return this.apiCpuMilliseconds_;
/*      */     }
/*      */ 
/*      */     public boolean hasApiBytesSent()
/*      */     {
/* 1880 */       return this.hasApiBytesSent;
/*      */     }
/*      */     public long getApiBytesSent() {
/* 1883 */       return this.apiBytesSent_;
/*      */     }
/*      */ 
/*      */     public boolean hasApiBytesReceived()
/*      */     {
/* 1891 */       return this.hasApiBytesReceived;
/*      */     }
/*      */     public long getApiBytesReceived() {
/* 1894 */       return this.apiBytesReceived_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 1898 */       this.content_ = ByteString.EMPTY;
/* 1899 */       this.statusCode_ = 0;
/* 1900 */       this.header_ = Collections.emptyList();
/* 1901 */       this.contentWasTruncated_ = false;
/* 1902 */       this.externalBytesSent_ = 0L;
/* 1903 */       this.externalBytesReceived_ = 0L;
/* 1904 */       this.finalUrl_ = "";
/* 1905 */       this.apiCpuMilliseconds_ = 0L;
/* 1906 */       this.apiBytesSent_ = 0L;
/* 1907 */       this.apiBytesReceived_ = 0L;
/*      */     }
/*      */     public final boolean isInitialized() {
/* 1910 */       if (!this.hasStatusCode) return false;
/* 1911 */       for (Header element : getHeaderList()) {
/* 1912 */         if (!element.isInitialized()) return false;
/*      */       }
/* 1914 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 1919 */       getSerializedSize();
/* 1920 */       if (hasContent()) {
/* 1921 */         output.writeBytes(1, getContent());
/*      */       }
/* 1923 */       if (hasStatusCode()) {
/* 1924 */         output.writeInt32(2, getStatusCode());
/*      */       }
/* 1926 */       for (Header element : getHeaderList()) {
/* 1927 */         output.writeGroup(3, element);
/*      */       }
/* 1929 */       if (hasContentWasTruncated()) {
/* 1930 */         output.writeBool(6, getContentWasTruncated());
/*      */       }
/* 1932 */       if (hasExternalBytesSent()) {
/* 1933 */         output.writeInt64(7, getExternalBytesSent());
/*      */       }
/* 1935 */       if (hasExternalBytesReceived()) {
/* 1936 */         output.writeInt64(8, getExternalBytesReceived());
/*      */       }
/* 1938 */       if (hasFinalUrl()) {
/* 1939 */         output.writeString(9, getFinalUrl());
/*      */       }
/* 1941 */       if (hasApiCpuMilliseconds()) {
/* 1942 */         output.writeInt64(10, getApiCpuMilliseconds());
/*      */       }
/* 1944 */       if (hasApiBytesSent()) {
/* 1945 */         output.writeInt64(11, getApiBytesSent());
/*      */       }
/* 1947 */       if (hasApiBytesReceived()) {
/* 1948 */         output.writeInt64(12, getApiBytesReceived());
/*      */       }
/* 1950 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 1955 */       int size = this.memoizedSerializedSize;
/* 1956 */       if (size != -1) return size;
/*      */ 
/* 1958 */       size = 0;
/* 1959 */       if (hasContent()) {
/* 1960 */         size += CodedOutputStream.computeBytesSize(1, getContent());
/*      */       }
/*      */ 
/* 1963 */       if (hasStatusCode()) {
/* 1964 */         size += CodedOutputStream.computeInt32Size(2, getStatusCode());
/*      */       }
/*      */ 
/* 1967 */       for (Header element : getHeaderList()) {
/* 1968 */         size += CodedOutputStream.computeGroupSize(3, element);
/*      */       }
/*      */ 
/* 1971 */       if (hasContentWasTruncated()) {
/* 1972 */         size += CodedOutputStream.computeBoolSize(6, getContentWasTruncated());
/*      */       }
/*      */ 
/* 1975 */       if (hasExternalBytesSent()) {
/* 1976 */         size += CodedOutputStream.computeInt64Size(7, getExternalBytesSent());
/*      */       }
/*      */ 
/* 1979 */       if (hasExternalBytesReceived()) {
/* 1980 */         size += CodedOutputStream.computeInt64Size(8, getExternalBytesReceived());
/*      */       }
/*      */ 
/* 1983 */       if (hasFinalUrl()) {
/* 1984 */         size += CodedOutputStream.computeStringSize(9, getFinalUrl());
/*      */       }
/*      */ 
/* 1987 */       if (hasApiCpuMilliseconds()) {
/* 1988 */         size += CodedOutputStream.computeInt64Size(10, getApiCpuMilliseconds());
/*      */       }
/*      */ 
/* 1991 */       if (hasApiBytesSent()) {
/* 1992 */         size += CodedOutputStream.computeInt64Size(11, getApiBytesSent());
/*      */       }
/*      */ 
/* 1995 */       if (hasApiBytesReceived()) {
/* 1996 */         size += CodedOutputStream.computeInt64Size(12, getApiBytesReceived());
/*      */       }
/*      */ 
/* 1999 */       size += getUnknownFields().getSerializedSize();
/* 2000 */       this.memoizedSerializedSize = size;
/* 2001 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 2006 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2012 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2018 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 2023 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2029 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 2034 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2040 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 2045 */       Builder builder = newBuilder();
/* 2046 */       if (builder.mergeDelimitedFrom(input)) {
/* 2047 */         return builder.buildParsed();
/*      */       }
/* 2049 */       return null;
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2056 */       Builder builder = newBuilder();
/* 2057 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 2058 */         return builder.buildParsed();
/*      */       }
/* 2060 */       return null;
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 2066 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2072 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 2076 */       return Builder.access$4200(); } 
/* 2077 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(URLFetchResponse prototype) {
/* 2079 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 2081 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2565 */       URLFetchServicePb.internalForceInit();
/* 2566 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasContent;
/* 2316 */       private ByteString content_ = ByteString.EMPTY;
/*      */       private boolean hasStatusCode;
/*      */       private int statusCode_;
/* 2358 */       private List<URLFetchServicePb.URLFetchResponse.Header> header_ = Collections.emptyList();
/*      */       private boolean isHeaderMutable;
/*      */       private boolean hasContentWasTruncated;
/*      */       private boolean contentWasTruncated_;
/*      */       private boolean hasExternalBytesSent;
/*      */       private long externalBytesSent_;
/*      */       private boolean hasExternalBytesReceived;
/*      */       private long externalBytesReceived_;
/*      */       private boolean hasFinalUrl;
/* 2479 */       private String finalUrl_ = "";
/*      */       private boolean hasApiCpuMilliseconds;
/*      */       private long apiCpuMilliseconds_;
/*      */       private boolean hasApiBytesSent;
/*      */       private long apiBytesSent_;
/*      */       private boolean hasApiBytesReceived;
/*      */       private long apiBytesReceived_;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 2087 */         return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 2092 */         return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 2100 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 2104 */         super.clear();
/* 2105 */         this.content_ = ByteString.EMPTY;
/* 2106 */         this.hasContent = false;
/* 2107 */         this.statusCode_ = 0;
/* 2108 */         this.hasStatusCode = false;
/* 2109 */         this.header_ = Collections.emptyList();
/* 2110 */         this.isHeaderMutable = false;
/* 2111 */         this.contentWasTruncated_ = false;
/* 2112 */         this.hasContentWasTruncated = false;
/* 2113 */         this.externalBytesSent_ = 0L;
/* 2114 */         this.hasExternalBytesSent = false;
/* 2115 */         this.externalBytesReceived_ = 0L;
/* 2116 */         this.hasExternalBytesReceived = false;
/* 2117 */         this.finalUrl_ = "";
/* 2118 */         this.hasFinalUrl = false;
/* 2119 */         this.apiCpuMilliseconds_ = 0L;
/* 2120 */         this.hasApiCpuMilliseconds = false;
/* 2121 */         this.apiBytesSent_ = 0L;
/* 2122 */         this.hasApiBytesSent = false;
/* 2123 */         this.apiBytesReceived_ = 0L;
/* 2124 */         this.hasApiBytesReceived = false;
/* 2125 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 2129 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 2134 */         return URLFetchServicePb.URLFetchResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchResponse getDefaultInstanceForType() {
/* 2138 */         return URLFetchServicePb.URLFetchResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchResponse build() {
/* 2142 */         URLFetchServicePb.URLFetchResponse result = buildPartial();
/* 2143 */         if (!result.isInitialized()) {
/* 2144 */           throw newUninitializedMessageException(result);
/*      */         }
/* 2146 */         return result;
/*      */       }
/*      */ 
/*      */       private URLFetchServicePb.URLFetchResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 2151 */         URLFetchServicePb.URLFetchResponse result = buildPartial();
/* 2152 */         if (!result.isInitialized()) {
/* 2153 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 2156 */         return result;
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchResponse buildPartial() {
/* 2160 */         URLFetchServicePb.URLFetchResponse result = new URLFetchServicePb.URLFetchResponse(this, null);
/* 2161 */         URLFetchServicePb.URLFetchResponse.access$4402(result, this.hasContent);
/* 2162 */         URLFetchServicePb.URLFetchResponse.access$4502(result, this.content_);
/* 2163 */         URLFetchServicePb.URLFetchResponse.access$4602(result, this.hasStatusCode);
/* 2164 */         URLFetchServicePb.URLFetchResponse.access$4702(result, this.statusCode_);
/* 2165 */         if (this.isHeaderMutable) {
/* 2166 */           this.header_ = Collections.unmodifiableList(this.header_);
/* 2167 */           this.isHeaderMutable = false;
/*      */         }
/* 2169 */         URLFetchServicePb.URLFetchResponse.access$4802(result, this.header_);
/* 2170 */         URLFetchServicePb.URLFetchResponse.access$4902(result, this.hasContentWasTruncated);
/* 2171 */         URLFetchServicePb.URLFetchResponse.access$5002(result, this.contentWasTruncated_);
/* 2172 */         URLFetchServicePb.URLFetchResponse.access$5102(result, this.hasExternalBytesSent);
/* 2173 */         URLFetchServicePb.URLFetchResponse.access$5202(result, this.externalBytesSent_);
/* 2174 */         URLFetchServicePb.URLFetchResponse.access$5302(result, this.hasExternalBytesReceived);
/* 2175 */         URLFetchServicePb.URLFetchResponse.access$5402(result, this.externalBytesReceived_);
/* 2176 */         URLFetchServicePb.URLFetchResponse.access$5502(result, this.hasFinalUrl);
/* 2177 */         URLFetchServicePb.URLFetchResponse.access$5602(result, this.finalUrl_);
/* 2178 */         URLFetchServicePb.URLFetchResponse.access$5702(result, this.hasApiCpuMilliseconds);
/* 2179 */         URLFetchServicePb.URLFetchResponse.access$5802(result, this.apiCpuMilliseconds_);
/* 2180 */         URLFetchServicePb.URLFetchResponse.access$5902(result, this.hasApiBytesSent);
/* 2181 */         URLFetchServicePb.URLFetchResponse.access$6002(result, this.apiBytesSent_);
/* 2182 */         URLFetchServicePb.URLFetchResponse.access$6102(result, this.hasApiBytesReceived);
/* 2183 */         URLFetchServicePb.URLFetchResponse.access$6202(result, this.apiBytesReceived_);
/* 2184 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 2188 */         if ((other instanceof URLFetchServicePb.URLFetchResponse)) {
/* 2189 */           return mergeFrom((URLFetchServicePb.URLFetchResponse)other);
/*      */         }
/* 2191 */         super.mergeFrom(other);
/* 2192 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(URLFetchServicePb.URLFetchResponse other)
/*      */       {
/* 2197 */         if (other == URLFetchServicePb.URLFetchResponse.getDefaultInstance()) return this;
/* 2198 */         if (other.hasContent()) {
/* 2199 */           setContent(other.getContent());
/*      */         }
/* 2201 */         if (other.hasStatusCode()) {
/* 2202 */           setStatusCode(other.getStatusCode());
/*      */         }
/* 2204 */         if (!other.header_.isEmpty()) {
/* 2205 */           if (this.header_.isEmpty()) {
/* 2206 */             this.header_ = other.header_;
/* 2207 */             this.isHeaderMutable = false;
/*      */           } else {
/* 2209 */             ensureHeaderIsMutable();
/* 2210 */             this.header_.addAll(other.header_);
/*      */           }
/*      */         }
/* 2213 */         if (other.hasContentWasTruncated()) {
/* 2214 */           setContentWasTruncated(other.getContentWasTruncated());
/*      */         }
/* 2216 */         if (other.hasExternalBytesSent()) {
/* 2217 */           setExternalBytesSent(other.getExternalBytesSent());
/*      */         }
/* 2219 */         if (other.hasExternalBytesReceived()) {
/* 2220 */           setExternalBytesReceived(other.getExternalBytesReceived());
/*      */         }
/* 2222 */         if (other.hasFinalUrl()) {
/* 2223 */           setFinalUrl(other.getFinalUrl());
/*      */         }
/* 2225 */         if (other.hasApiCpuMilliseconds()) {
/* 2226 */           setApiCpuMilliseconds(other.getApiCpuMilliseconds());
/*      */         }
/* 2228 */         if (other.hasApiBytesSent()) {
/* 2229 */           setApiBytesSent(other.getApiBytesSent());
/*      */         }
/* 2231 */         if (other.hasApiBytesReceived()) {
/* 2232 */           setApiBytesReceived(other.getApiBytesReceived());
/*      */         }
/* 2234 */         mergeUnknownFields(other.getUnknownFields());
/* 2235 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 2239 */         if (!this.hasStatusCode) return false;
/* 2240 */         for (URLFetchServicePb.URLFetchResponse.Header element : getHeaderList()) {
/* 2241 */           if (!element.isInitialized()) return false;
/*      */         }
/* 2243 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 2250 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 2254 */           int tag = input.readTag();
/* 2255 */           switch (tag) {
/*      */           case 0:
/* 2257 */             setUnknownFields(unknownFields.build());
/* 2258 */             return this;
/*      */           default:
/* 2260 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 2262 */             setUnknownFields(unknownFields.build());
/* 2263 */             return this;
/*      */           case 10:
/* 2268 */             setContent(input.readBytes());
/* 2269 */             break;
/*      */           case 16:
/* 2272 */             setStatusCode(input.readInt32());
/* 2273 */             break;
/*      */           case 27:
/* 2276 */             URLFetchServicePb.URLFetchResponse.Header.Builder subBuilder = URLFetchServicePb.URLFetchResponse.Header.newBuilder();
/* 2277 */             input.readGroup(3, subBuilder, extensionRegistry);
/* 2278 */             addHeader(subBuilder.buildPartial());
/* 2279 */             break;
/*      */           case 48:
/* 2282 */             setContentWasTruncated(input.readBool());
/* 2283 */             break;
/*      */           case 56:
/* 2286 */             setExternalBytesSent(input.readInt64());
/* 2287 */             break;
/*      */           case 64:
/* 2290 */             setExternalBytesReceived(input.readInt64());
/* 2291 */             break;
/*      */           case 74:
/* 2294 */             setFinalUrl(input.readString());
/* 2295 */             break;
/*      */           case 80:
/* 2298 */             setApiCpuMilliseconds(input.readInt64());
/* 2299 */             break;
/*      */           case 88:
/* 2302 */             setApiBytesSent(input.readInt64());
/* 2303 */             break;
/*      */           case 96:
/* 2306 */             setApiBytesReceived(input.readInt64());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasContent()
/*      */       {
/* 2318 */         return this.hasContent;
/*      */       }
/*      */       public ByteString getContent() {
/* 2321 */         return this.content_;
/*      */       }
/*      */       public Builder setContent(ByteString value) {
/* 2324 */         if (value == null) {
/* 2325 */           throw new NullPointerException();
/*      */         }
/* 2327 */         this.hasContent = true;
/* 2328 */         this.content_ = value;
/* 2329 */         return this;
/*      */       }
/*      */       public Builder clearContent() {
/* 2332 */         this.hasContent = false;
/* 2333 */         this.content_ = URLFetchServicePb.URLFetchResponse.getDefaultInstance().getContent();
/* 2334 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasStatusCode()
/*      */       {
/* 2341 */         return this.hasStatusCode;
/*      */       }
/*      */       public int getStatusCode() {
/* 2344 */         return this.statusCode_;
/*      */       }
/*      */       public Builder setStatusCode(int value) {
/* 2347 */         this.hasStatusCode = true;
/* 2348 */         this.statusCode_ = value;
/* 2349 */         return this;
/*      */       }
/*      */       public Builder clearStatusCode() {
/* 2352 */         this.hasStatusCode = false;
/* 2353 */         this.statusCode_ = 0;
/* 2354 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureHeaderIsMutable()
/*      */       {
/* 2362 */         if (!this.isHeaderMutable) {
/* 2363 */           this.header_ = new ArrayList(this.header_);
/* 2364 */           this.isHeaderMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<URLFetchServicePb.URLFetchResponse.Header> getHeaderList() {
/* 2368 */         return Collections.unmodifiableList(this.header_);
/*      */       }
/*      */       public int getHeaderCount() {
/* 2371 */         return this.header_.size();
/*      */       }
/*      */       public URLFetchServicePb.URLFetchResponse.Header getHeader(int index) {
/* 2374 */         return (URLFetchServicePb.URLFetchResponse.Header)this.header_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setHeader(int index, URLFetchServicePb.URLFetchResponse.Header value) {
/* 2378 */         if (value == null) {
/* 2379 */           throw new NullPointerException();
/*      */         }
/* 2381 */         ensureHeaderIsMutable();
/* 2382 */         this.header_.set(index, value);
/* 2383 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setHeader(int index, URLFetchServicePb.URLFetchResponse.Header.Builder builderForValue) {
/* 2387 */         ensureHeaderIsMutable();
/* 2388 */         this.header_.set(index, builderForValue.build());
/* 2389 */         return this;
/*      */       }
/*      */       public Builder addHeader(URLFetchServicePb.URLFetchResponse.Header value) {
/* 2392 */         if (value == null) {
/* 2393 */           throw new NullPointerException();
/*      */         }
/* 2395 */         ensureHeaderIsMutable();
/* 2396 */         this.header_.add(value);
/* 2397 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addHeader(URLFetchServicePb.URLFetchResponse.Header.Builder builderForValue) {
/* 2401 */         ensureHeaderIsMutable();
/* 2402 */         this.header_.add(builderForValue.build());
/* 2403 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllHeader(Iterable<? extends URLFetchServicePb.URLFetchResponse.Header> values) {
/* 2407 */         ensureHeaderIsMutable();
/* 2408 */         GeneratedMessage.Builder.addAll(values, this.header_);
/* 2409 */         return this;
/*      */       }
/*      */       public Builder clearHeader() {
/* 2412 */         this.header_ = Collections.emptyList();
/* 2413 */         this.isHeaderMutable = false;
/* 2414 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasContentWasTruncated()
/*      */       {
/* 2421 */         return this.hasContentWasTruncated;
/*      */       }
/*      */       public boolean getContentWasTruncated() {
/* 2424 */         return this.contentWasTruncated_;
/*      */       }
/*      */       public Builder setContentWasTruncated(boolean value) {
/* 2427 */         this.hasContentWasTruncated = true;
/* 2428 */         this.contentWasTruncated_ = value;
/* 2429 */         return this;
/*      */       }
/*      */       public Builder clearContentWasTruncated() {
/* 2432 */         this.hasContentWasTruncated = false;
/* 2433 */         this.contentWasTruncated_ = false;
/* 2434 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasExternalBytesSent()
/*      */       {
/* 2441 */         return this.hasExternalBytesSent;
/*      */       }
/*      */       public long getExternalBytesSent() {
/* 2444 */         return this.externalBytesSent_;
/*      */       }
/*      */       public Builder setExternalBytesSent(long value) {
/* 2447 */         this.hasExternalBytesSent = true;
/* 2448 */         this.externalBytesSent_ = value;
/* 2449 */         return this;
/*      */       }
/*      */       public Builder clearExternalBytesSent() {
/* 2452 */         this.hasExternalBytesSent = false;
/* 2453 */         this.externalBytesSent_ = 0L;
/* 2454 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasExternalBytesReceived()
/*      */       {
/* 2461 */         return this.hasExternalBytesReceived;
/*      */       }
/*      */       public long getExternalBytesReceived() {
/* 2464 */         return this.externalBytesReceived_;
/*      */       }
/*      */       public Builder setExternalBytesReceived(long value) {
/* 2467 */         this.hasExternalBytesReceived = true;
/* 2468 */         this.externalBytesReceived_ = value;
/* 2469 */         return this;
/*      */       }
/*      */       public Builder clearExternalBytesReceived() {
/* 2472 */         this.hasExternalBytesReceived = false;
/* 2473 */         this.externalBytesReceived_ = 0L;
/* 2474 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasFinalUrl()
/*      */       {
/* 2481 */         return this.hasFinalUrl;
/*      */       }
/*      */       public String getFinalUrl() {
/* 2484 */         return this.finalUrl_;
/*      */       }
/*      */       public Builder setFinalUrl(String value) {
/* 2487 */         if (value == null) {
/* 2488 */           throw new NullPointerException();
/*      */         }
/* 2490 */         this.hasFinalUrl = true;
/* 2491 */         this.finalUrl_ = value;
/* 2492 */         return this;
/*      */       }
/*      */       public Builder clearFinalUrl() {
/* 2495 */         this.hasFinalUrl = false;
/* 2496 */         this.finalUrl_ = URLFetchServicePb.URLFetchResponse.getDefaultInstance().getFinalUrl();
/* 2497 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasApiCpuMilliseconds()
/*      */       {
/* 2504 */         return this.hasApiCpuMilliseconds;
/*      */       }
/*      */       public long getApiCpuMilliseconds() {
/* 2507 */         return this.apiCpuMilliseconds_;
/*      */       }
/*      */       public Builder setApiCpuMilliseconds(long value) {
/* 2510 */         this.hasApiCpuMilliseconds = true;
/* 2511 */         this.apiCpuMilliseconds_ = value;
/* 2512 */         return this;
/*      */       }
/*      */       public Builder clearApiCpuMilliseconds() {
/* 2515 */         this.hasApiCpuMilliseconds = false;
/* 2516 */         this.apiCpuMilliseconds_ = 0L;
/* 2517 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasApiBytesSent()
/*      */       {
/* 2524 */         return this.hasApiBytesSent;
/*      */       }
/*      */       public long getApiBytesSent() {
/* 2527 */         return this.apiBytesSent_;
/*      */       }
/*      */       public Builder setApiBytesSent(long value) {
/* 2530 */         this.hasApiBytesSent = true;
/* 2531 */         this.apiBytesSent_ = value;
/* 2532 */         return this;
/*      */       }
/*      */       public Builder clearApiBytesSent() {
/* 2535 */         this.hasApiBytesSent = false;
/* 2536 */         this.apiBytesSent_ = 0L;
/* 2537 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasApiBytesReceived()
/*      */       {
/* 2544 */         return this.hasApiBytesReceived;
/*      */       }
/*      */       public long getApiBytesReceived() {
/* 2547 */         return this.apiBytesReceived_;
/*      */       }
/*      */       public Builder setApiBytesReceived(long value) {
/* 2550 */         this.hasApiBytesReceived = true;
/* 2551 */         this.apiBytesReceived_ = value;
/* 2552 */         return this;
/*      */       }
/*      */       public Builder clearApiBytesReceived() {
/* 2555 */         this.hasApiBytesReceived = false;
/* 2556 */         this.apiBytesReceived_ = 0L;
/* 2557 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static final class Header extends GeneratedMessage
/*      */     {
/* 1777 */       private static final Header defaultInstance = new Header(true);
/*      */       public static final int KEY_FIELD_NUMBER = 4;
/*      */       private boolean hasKey;
/*      */       private String key_;
/*      */       public static final int VALUE_FIELD_NUMBER = 5;
/*      */       private boolean hasValue;
/*      */       private String value_;
/* 1499 */       private int memoizedSerializedSize = -1;
/*      */ 
/*      */       private Header(Builder builder)
/*      */       {
/* 1432 */         super();
/*      */       }
/*      */       private Header(boolean noInit) {
/*      */       }
/*      */ 
/*      */       public static Header getDefaultInstance() {
/* 1438 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public Header getDefaultInstanceForType() {
/* 1442 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 1447 */         return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_Header_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 1452 */         return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_Header_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/* 1460 */         return this.hasKey;
/*      */       }
/*      */       public String getKey() {
/* 1463 */         return this.key_;
/*      */       }
/*      */ 
/*      */       public boolean hasValue()
/*      */       {
/* 1471 */         return this.hasValue;
/*      */       }
/*      */       public String getValue() {
/* 1474 */         return this.value_;
/*      */       }
/*      */ 
/*      */       private void initFields() {
/* 1478 */         this.key_ = "";
/* 1479 */         this.value_ = "";
/*      */       }
/*      */       public final boolean isInitialized() {
/* 1482 */         if (!this.hasKey) return false;
/* 1483 */         return this.hasValue;
/*      */       }
/*      */ 
/*      */       public void writeTo(CodedOutputStream output)
/*      */         throws IOException
/*      */       {
/* 1489 */         getSerializedSize();
/* 1490 */         if (hasKey()) {
/* 1491 */           output.writeString(4, getKey());
/*      */         }
/* 1493 */         if (hasValue()) {
/* 1494 */           output.writeString(5, getValue());
/*      */         }
/* 1496 */         getUnknownFields().writeTo(output);
/*      */       }
/*      */ 
/*      */       public int getSerializedSize()
/*      */       {
/* 1501 */         int size = this.memoizedSerializedSize;
/* 1502 */         if (size != -1) return size;
/*      */ 
/* 1504 */         size = 0;
/* 1505 */         if (hasKey()) {
/* 1506 */           size += CodedOutputStream.computeStringSize(4, getKey());
/*      */         }
/*      */ 
/* 1509 */         if (hasValue()) {
/* 1510 */           size += CodedOutputStream.computeStringSize(5, getValue());
/*      */         }
/*      */ 
/* 1513 */         size += getUnknownFields().getSerializedSize();
/* 1514 */         this.memoizedSerializedSize = size;
/* 1515 */         return size;
/*      */       }
/*      */ 
/*      */       protected Object writeReplace() throws ObjectStreamException
/*      */       {
/* 1520 */         return super.writeReplace();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(ByteString data)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 1526 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 1532 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */       {
/* 1537 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 1543 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(InputStream input) throws IOException
/*      */       {
/* 1548 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1554 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseDelimitedFrom(InputStream input) throws IOException
/*      */       {
/* 1559 */         Builder builder = newBuilder();
/* 1560 */         if (builder.mergeDelimitedFrom(input)) {
/* 1561 */           return builder.buildParsed();
/*      */         }
/* 1563 */         return null;
/*      */       }
/*      */ 
/*      */       public static Header parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1570 */         Builder builder = newBuilder();
/* 1571 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 1572 */           return builder.buildParsed();
/*      */         }
/* 1574 */         return null;
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(CodedInputStream input)
/*      */         throws IOException
/*      */       {
/* 1580 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1586 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Builder newBuilder() {
/* 1590 */         return Builder.access$3500(); } 
/* 1591 */       public Builder newBuilderForType() { return newBuilder(); } 
/*      */       public static Builder newBuilder(Header prototype) {
/* 1593 */         return newBuilder().mergeFrom(prototype);
/*      */       }
/* 1595 */       public Builder toBuilder() { return newBuilder(this);
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1778 */         URLFetchServicePb.internalForceInit();
/* 1779 */         defaultInstance.initFields();
/*      */       }
/*      */ 
/*      */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */       {
/*      */         private boolean hasKey;
/* 1729 */         private String key_ = "";
/*      */         private boolean hasValue;
/* 1752 */         private String value_ = "";
/*      */ 
/*      */         public static final Descriptors.Descriptor getDescriptor()
/*      */         {
/* 1601 */           return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_Header_descriptor;
/*      */         }
/*      */ 
/*      */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */         {
/* 1606 */           return URLFetchServicePb.internal_static_apphosting_URLFetchResponse_Header_fieldAccessorTable;
/*      */         }
/*      */ 
/*      */         private static Builder create()
/*      */         {
/* 1614 */           return new Builder();
/*      */         }
/*      */ 
/*      */         public Builder clear() {
/* 1618 */           super.clear();
/* 1619 */           this.key_ = "";
/* 1620 */           this.hasKey = false;
/* 1621 */           this.value_ = "";
/* 1622 */           this.hasValue = false;
/* 1623 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder clone() {
/* 1627 */           return create().mergeFrom(buildPartial());
/*      */         }
/*      */ 
/*      */         public Descriptors.Descriptor getDescriptorForType()
/*      */         {
/* 1632 */           return URLFetchServicePb.URLFetchResponse.Header.getDescriptor();
/*      */         }
/*      */ 
/*      */         public URLFetchServicePb.URLFetchResponse.Header getDefaultInstanceForType() {
/* 1636 */           return URLFetchServicePb.URLFetchResponse.Header.getDefaultInstance();
/*      */         }
/*      */ 
/*      */         public URLFetchServicePb.URLFetchResponse.Header build() {
/* 1640 */           URLFetchServicePb.URLFetchResponse.Header result = buildPartial();
/* 1641 */           if (!result.isInitialized()) {
/* 1642 */             throw newUninitializedMessageException(result);
/*      */           }
/* 1644 */           return result;
/*      */         }
/*      */ 
/*      */         private URLFetchServicePb.URLFetchResponse.Header buildParsed() throws InvalidProtocolBufferException
/*      */         {
/* 1649 */           URLFetchServicePb.URLFetchResponse.Header result = buildPartial();
/* 1650 */           if (!result.isInitialized()) {
/* 1651 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */           }
/*      */ 
/* 1654 */           return result;
/*      */         }
/*      */ 
/*      */         public URLFetchServicePb.URLFetchResponse.Header buildPartial() {
/* 1658 */           URLFetchServicePb.URLFetchResponse.Header result = new URLFetchServicePb.URLFetchResponse.Header(this, null);
/* 1659 */           URLFetchServicePb.URLFetchResponse.Header.access$3702(result, this.hasKey);
/* 1660 */           URLFetchServicePb.URLFetchResponse.Header.access$3802(result, this.key_);
/* 1661 */           URLFetchServicePb.URLFetchResponse.Header.access$3902(result, this.hasValue);
/* 1662 */           URLFetchServicePb.URLFetchResponse.Header.access$4002(result, this.value_);
/* 1663 */           return result;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(Message other) {
/* 1667 */           if ((other instanceof URLFetchServicePb.URLFetchResponse.Header)) {
/* 1668 */             return mergeFrom((URLFetchServicePb.URLFetchResponse.Header)other);
/*      */           }
/* 1670 */           super.mergeFrom(other);
/* 1671 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(URLFetchServicePb.URLFetchResponse.Header other)
/*      */         {
/* 1676 */           if (other == URLFetchServicePb.URLFetchResponse.Header.getDefaultInstance()) return this;
/* 1677 */           if (other.hasKey()) {
/* 1678 */             setKey(other.getKey());
/*      */           }
/* 1680 */           if (other.hasValue()) {
/* 1681 */             setValue(other.getValue());
/*      */           }
/* 1683 */           mergeUnknownFields(other.getUnknownFields());
/* 1684 */           return this;
/*      */         }
/*      */ 
/*      */         public final boolean isInitialized() {
/* 1688 */           if (!this.hasKey) return false;
/* 1689 */           return this.hasValue;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */           throws IOException
/*      */         {
/* 1697 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */           while (true)
/*      */           {
/* 1701 */             int tag = input.readTag();
/* 1702 */             switch (tag) {
/*      */             case 0:
/* 1704 */               setUnknownFields(unknownFields.build());
/* 1705 */               return this;
/*      */             default:
/* 1707 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */                 break;
/* 1709 */               setUnknownFields(unknownFields.build());
/* 1710 */               return this;
/*      */             case 34:
/* 1715 */               setKey(input.readString());
/* 1716 */               break;
/*      */             case 42:
/* 1719 */               setValue(input.readString());
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         public boolean hasKey()
/*      */         {
/* 1731 */           return this.hasKey;
/*      */         }
/*      */         public String getKey() {
/* 1734 */           return this.key_;
/*      */         }
/*      */         public Builder setKey(String value) {
/* 1737 */           if (value == null) {
/* 1738 */             throw new NullPointerException();
/*      */           }
/* 1740 */           this.hasKey = true;
/* 1741 */           this.key_ = value;
/* 1742 */           return this;
/*      */         }
/*      */         public Builder clearKey() {
/* 1745 */           this.hasKey = false;
/* 1746 */           this.key_ = URLFetchServicePb.URLFetchResponse.Header.getDefaultInstance().getKey();
/* 1747 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasValue()
/*      */         {
/* 1754 */           return this.hasValue;
/*      */         }
/*      */         public String getValue() {
/* 1757 */           return this.value_;
/*      */         }
/*      */         public Builder setValue(String value) {
/* 1760 */           if (value == null) {
/* 1761 */             throw new NullPointerException();
/*      */           }
/* 1763 */           this.hasValue = true;
/* 1764 */           this.value_ = value;
/* 1765 */           return this;
/*      */         }
/*      */         public Builder clearValue() {
/* 1768 */           this.hasValue = false;
/* 1769 */           this.value_ = URLFetchServicePb.URLFetchResponse.Header.getDefaultInstance().getValue();
/* 1770 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class URLFetchRequest extends GeneratedMessage
/*      */   {
/* 1393 */     private static final URLFetchRequest defaultInstance = new URLFetchRequest(true);
/*      */     public static final int METHOD_FIELD_NUMBER = 1;
/*      */     private boolean hasMethod;
/*      */     private RequestMethod method_;
/*      */     public static final int URL_FIELD_NUMBER = 2;
/*      */     private boolean hasUrl;
/*      */     private String url_;
/*      */     public static final int HEADER_FIELD_NUMBER = 3;
/*      */     private List<Header> header_;
/*      */     public static final int PAYLOAD_FIELD_NUMBER = 6;
/*      */     private boolean hasPayload;
/*      */     private ByteString payload_;
/*      */     public static final int FOLLOWREDIRECTS_FIELD_NUMBER = 7;
/*      */     private boolean hasFollowRedirects;
/*      */     private boolean followRedirects_;
/*      */     public static final int DEADLINE_FIELD_NUMBER = 8;
/*      */     private boolean hasDeadline;
/*      */     private double deadline_;
/*  912 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private URLFetchRequest(Builder builder)
/*      */     {
/*  344 */       super();
/*      */     }
/*      */     private URLFetchRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest getDefaultInstance() {
/*  350 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public URLFetchRequest getDefaultInstanceForType() {
/*  354 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  359 */       return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  364 */       return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasMethod()
/*      */     {
/*  808 */       return this.hasMethod;
/*      */     }
/*      */     public RequestMethod getMethod() {
/*  811 */       return this.method_;
/*      */     }
/*      */ 
/*      */     public boolean hasUrl()
/*      */     {
/*  819 */       return this.hasUrl;
/*      */     }
/*      */     public String getUrl() {
/*  822 */       return this.url_;
/*      */     }
/*      */ 
/*      */     public List<Header> getHeaderList()
/*      */     {
/*  829 */       return this.header_;
/*      */     }
/*      */     public int getHeaderCount() {
/*  832 */       return this.header_.size();
/*      */     }
/*      */     public Header getHeader(int index) {
/*  835 */       return (Header)this.header_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasPayload()
/*      */     {
/*  843 */       return this.hasPayload;
/*      */     }
/*      */     public ByteString getPayload() {
/*  846 */       return this.payload_;
/*      */     }
/*      */ 
/*      */     public boolean hasFollowRedirects()
/*      */     {
/*  854 */       return this.hasFollowRedirects;
/*      */     }
/*      */     public boolean getFollowRedirects() {
/*  857 */       return this.followRedirects_;
/*      */     }
/*      */ 
/*      */     public boolean hasDeadline()
/*      */     {
/*  865 */       return this.hasDeadline;
/*      */     }
/*      */     public double getDeadline() {
/*  868 */       return this.deadline_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*  872 */       this.method_ = RequestMethod.GET;
/*  873 */       this.url_ = "";
/*  874 */       this.header_ = Collections.emptyList();
/*  875 */       this.payload_ = ByteString.EMPTY;
/*  876 */       this.followRedirects_ = true;
/*  877 */       this.deadline_ = 0.0D;
/*      */     }
/*      */     public final boolean isInitialized() {
/*  880 */       if (!this.hasMethod) return false;
/*  881 */       if (!this.hasUrl) return false;
/*  882 */       for (Header element : getHeaderList()) {
/*  883 */         if (!element.isInitialized()) return false;
/*      */       }
/*  885 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/*  890 */       getSerializedSize();
/*  891 */       if (hasMethod()) {
/*  892 */         output.writeEnum(1, getMethod().getNumber());
/*      */       }
/*  894 */       if (hasUrl()) {
/*  895 */         output.writeString(2, getUrl());
/*      */       }
/*  897 */       for (Header element : getHeaderList()) {
/*  898 */         output.writeGroup(3, element);
/*      */       }
/*  900 */       if (hasPayload()) {
/*  901 */         output.writeBytes(6, getPayload());
/*      */       }
/*  903 */       if (hasFollowRedirects()) {
/*  904 */         output.writeBool(7, getFollowRedirects());
/*      */       }
/*  906 */       if (hasDeadline()) {
/*  907 */         output.writeDouble(8, getDeadline());
/*      */       }
/*  909 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  914 */       int size = this.memoizedSerializedSize;
/*  915 */       if (size != -1) return size;
/*      */ 
/*  917 */       size = 0;
/*  918 */       if (hasMethod()) {
/*  919 */         size += CodedOutputStream.computeEnumSize(1, getMethod().getNumber());
/*      */       }
/*      */ 
/*  922 */       if (hasUrl()) {
/*  923 */         size += CodedOutputStream.computeStringSize(2, getUrl());
/*      */       }
/*      */ 
/*  926 */       for (Header element : getHeaderList()) {
/*  927 */         size += CodedOutputStream.computeGroupSize(3, element);
/*      */       }
/*      */ 
/*  930 */       if (hasPayload()) {
/*  931 */         size += CodedOutputStream.computeBytesSize(6, getPayload());
/*      */       }
/*      */ 
/*  934 */       if (hasFollowRedirects()) {
/*  935 */         size += CodedOutputStream.computeBoolSize(7, getFollowRedirects());
/*      */       }
/*      */ 
/*  938 */       if (hasDeadline()) {
/*  939 */         size += CodedOutputStream.computeDoubleSize(8, getDeadline());
/*      */       }
/*      */ 
/*  942 */       size += getUnknownFields().getSerializedSize();
/*  943 */       this.memoizedSerializedSize = size;
/*  944 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  949 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  955 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  961 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  966 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  972 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(InputStream input) throws IOException
/*      */     {
/*  977 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  983 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  988 */       Builder builder = newBuilder();
/*  989 */       if (builder.mergeDelimitedFrom(input)) {
/*  990 */         return builder.buildParsed();
/*      */       }
/*  992 */       return null;
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  999 */       Builder builder = newBuilder();
/* 1000 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 1001 */         return builder.buildParsed();
/*      */       }
/* 1003 */       return null;
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 1009 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1015 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 1019 */       return Builder.access$1700(); } 
/* 1020 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(URLFetchRequest prototype) {
/* 1022 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 1024 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1394 */       URLFetchServicePb.internalForceInit();
/* 1395 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasMethod;
/* 1222 */       private URLFetchServicePb.URLFetchRequest.RequestMethod method_ = URLFetchServicePb.URLFetchRequest.RequestMethod.GET;
/*      */       private boolean hasUrl;
/* 1245 */       private String url_ = "";
/*      */ 
/* 1267 */       private List<URLFetchServicePb.URLFetchRequest.Header> header_ = Collections.emptyList();
/*      */       private boolean isHeaderMutable;
/*      */       private boolean hasPayload;
/* 1328 */       private ByteString payload_ = ByteString.EMPTY;
/*      */       private boolean hasFollowRedirects;
/* 1351 */       private boolean followRedirects_ = true;
/*      */       private boolean hasDeadline;
/*      */       private double deadline_;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 1030 */         return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 1035 */         return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 1043 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 1047 */         super.clear();
/* 1048 */         this.method_ = URLFetchServicePb.URLFetchRequest.RequestMethod.GET;
/* 1049 */         this.hasMethod = false;
/* 1050 */         this.url_ = "";
/* 1051 */         this.hasUrl = false;
/* 1052 */         this.header_ = Collections.emptyList();
/* 1053 */         this.isHeaderMutable = false;
/* 1054 */         this.payload_ = ByteString.EMPTY;
/* 1055 */         this.hasPayload = false;
/* 1056 */         this.followRedirects_ = true;
/* 1057 */         this.hasFollowRedirects = false;
/* 1058 */         this.deadline_ = 0.0D;
/* 1059 */         this.hasDeadline = false;
/* 1060 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 1064 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 1069 */         return URLFetchServicePb.URLFetchRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchRequest getDefaultInstanceForType() {
/* 1073 */         return URLFetchServicePb.URLFetchRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchRequest build() {
/* 1077 */         URLFetchServicePb.URLFetchRequest result = buildPartial();
/* 1078 */         if (!result.isInitialized()) {
/* 1079 */           throw newUninitializedMessageException(result);
/*      */         }
/* 1081 */         return result;
/*      */       }
/*      */ 
/*      */       private URLFetchServicePb.URLFetchRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 1086 */         URLFetchServicePb.URLFetchRequest result = buildPartial();
/* 1087 */         if (!result.isInitialized()) {
/* 1088 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 1091 */         return result;
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchRequest buildPartial() {
/* 1095 */         URLFetchServicePb.URLFetchRequest result = new URLFetchServicePb.URLFetchRequest(this, null);
/* 1096 */         URLFetchServicePb.URLFetchRequest.access$1902(result, this.hasMethod);
/* 1097 */         URLFetchServicePb.URLFetchRequest.access$2002(result, this.method_);
/* 1098 */         URLFetchServicePb.URLFetchRequest.access$2102(result, this.hasUrl);
/* 1099 */         URLFetchServicePb.URLFetchRequest.access$2202(result, this.url_);
/* 1100 */         if (this.isHeaderMutable) {
/* 1101 */           this.header_ = Collections.unmodifiableList(this.header_);
/* 1102 */           this.isHeaderMutable = false;
/*      */         }
/* 1104 */         URLFetchServicePb.URLFetchRequest.access$2302(result, this.header_);
/* 1105 */         URLFetchServicePb.URLFetchRequest.access$2402(result, this.hasPayload);
/* 1106 */         URLFetchServicePb.URLFetchRequest.access$2502(result, this.payload_);
/* 1107 */         URLFetchServicePb.URLFetchRequest.access$2602(result, this.hasFollowRedirects);
/* 1108 */         URLFetchServicePb.URLFetchRequest.access$2702(result, this.followRedirects_);
/* 1109 */         URLFetchServicePb.URLFetchRequest.access$2802(result, this.hasDeadline);
/* 1110 */         URLFetchServicePb.URLFetchRequest.access$2902(result, this.deadline_);
/* 1111 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 1115 */         if ((other instanceof URLFetchServicePb.URLFetchRequest)) {
/* 1116 */           return mergeFrom((URLFetchServicePb.URLFetchRequest)other);
/*      */         }
/* 1118 */         super.mergeFrom(other);
/* 1119 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(URLFetchServicePb.URLFetchRequest other)
/*      */       {
/* 1124 */         if (other == URLFetchServicePb.URLFetchRequest.getDefaultInstance()) return this;
/* 1125 */         if (other.hasMethod()) {
/* 1126 */           setMethod(other.getMethod());
/*      */         }
/* 1128 */         if (other.hasUrl()) {
/* 1129 */           setUrl(other.getUrl());
/*      */         }
/* 1131 */         if (!other.header_.isEmpty()) {
/* 1132 */           if (this.header_.isEmpty()) {
/* 1133 */             this.header_ = other.header_;
/* 1134 */             this.isHeaderMutable = false;
/*      */           } else {
/* 1136 */             ensureHeaderIsMutable();
/* 1137 */             this.header_.addAll(other.header_);
/*      */           }
/*      */         }
/* 1140 */         if (other.hasPayload()) {
/* 1141 */           setPayload(other.getPayload());
/*      */         }
/* 1143 */         if (other.hasFollowRedirects()) {
/* 1144 */           setFollowRedirects(other.getFollowRedirects());
/*      */         }
/* 1146 */         if (other.hasDeadline()) {
/* 1147 */           setDeadline(other.getDeadline());
/*      */         }
/* 1149 */         mergeUnknownFields(other.getUnknownFields());
/* 1150 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 1154 */         if (!this.hasMethod) return false;
/* 1155 */         if (!this.hasUrl) return false;
/* 1156 */         for (URLFetchServicePb.URLFetchRequest.Header element : getHeaderList()) {
/* 1157 */           if (!element.isInitialized()) return false;
/*      */         }
/* 1159 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1166 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 1170 */           int tag = input.readTag();
/* 1171 */           switch (tag) {
/*      */           case 0:
/* 1173 */             setUnknownFields(unknownFields.build());
/* 1174 */             return this;
/*      */           default:
/* 1176 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 1178 */             setUnknownFields(unknownFields.build());
/* 1179 */             return this;
/*      */           case 8:
/* 1184 */             int rawValue = input.readEnum();
/* 1185 */             URLFetchServicePb.URLFetchRequest.RequestMethod value = URLFetchServicePb.URLFetchRequest.RequestMethod.valueOf(rawValue);
/* 1186 */             if (value == null)
/* 1187 */               unknownFields.mergeVarintField(1, rawValue);
/*      */             else {
/* 1189 */               setMethod(value);
/*      */             }
/* 1191 */             break;
/*      */           case 18:
/* 1194 */             setUrl(input.readString());
/* 1195 */             break;
/*      */           case 27:
/* 1198 */             URLFetchServicePb.URLFetchRequest.Header.Builder subBuilder = URLFetchServicePb.URLFetchRequest.Header.newBuilder();
/* 1199 */             input.readGroup(3, subBuilder, extensionRegistry);
/* 1200 */             addHeader(subBuilder.buildPartial());
/* 1201 */             break;
/*      */           case 50:
/* 1204 */             setPayload(input.readBytes());
/* 1205 */             break;
/*      */           case 56:
/* 1208 */             setFollowRedirects(input.readBool());
/* 1209 */             break;
/*      */           case 65:
/* 1212 */             setDeadline(input.readDouble());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasMethod()
/*      */       {
/* 1224 */         return this.hasMethod;
/*      */       }
/*      */       public URLFetchServicePb.URLFetchRequest.RequestMethod getMethod() {
/* 1227 */         return this.method_;
/*      */       }
/*      */       public Builder setMethod(URLFetchServicePb.URLFetchRequest.RequestMethod value) {
/* 1230 */         if (value == null) {
/* 1231 */           throw new NullPointerException();
/*      */         }
/* 1233 */         this.hasMethod = true;
/* 1234 */         this.method_ = value;
/* 1235 */         return this;
/*      */       }
/*      */       public Builder clearMethod() {
/* 1238 */         this.hasMethod = false;
/* 1239 */         this.method_ = URLFetchServicePb.URLFetchRequest.RequestMethod.GET;
/* 1240 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasUrl()
/*      */       {
/* 1247 */         return this.hasUrl;
/*      */       }
/*      */       public String getUrl() {
/* 1250 */         return this.url_;
/*      */       }
/*      */       public Builder setUrl(String value) {
/* 1253 */         if (value == null) {
/* 1254 */           throw new NullPointerException();
/*      */         }
/* 1256 */         this.hasUrl = true;
/* 1257 */         this.url_ = value;
/* 1258 */         return this;
/*      */       }
/*      */       public Builder clearUrl() {
/* 1261 */         this.hasUrl = false;
/* 1262 */         this.url_ = URLFetchServicePb.URLFetchRequest.getDefaultInstance().getUrl();
/* 1263 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureHeaderIsMutable()
/*      */       {
/* 1271 */         if (!this.isHeaderMutable) {
/* 1272 */           this.header_ = new ArrayList(this.header_);
/* 1273 */           this.isHeaderMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<URLFetchServicePb.URLFetchRequest.Header> getHeaderList() {
/* 1277 */         return Collections.unmodifiableList(this.header_);
/*      */       }
/*      */       public int getHeaderCount() {
/* 1280 */         return this.header_.size();
/*      */       }
/*      */       public URLFetchServicePb.URLFetchRequest.Header getHeader(int index) {
/* 1283 */         return (URLFetchServicePb.URLFetchRequest.Header)this.header_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setHeader(int index, URLFetchServicePb.URLFetchRequest.Header value) {
/* 1287 */         if (value == null) {
/* 1288 */           throw new NullPointerException();
/*      */         }
/* 1290 */         ensureHeaderIsMutable();
/* 1291 */         this.header_.set(index, value);
/* 1292 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setHeader(int index, URLFetchServicePb.URLFetchRequest.Header.Builder builderForValue) {
/* 1296 */         ensureHeaderIsMutable();
/* 1297 */         this.header_.set(index, builderForValue.build());
/* 1298 */         return this;
/*      */       }
/*      */       public Builder addHeader(URLFetchServicePb.URLFetchRequest.Header value) {
/* 1301 */         if (value == null) {
/* 1302 */           throw new NullPointerException();
/*      */         }
/* 1304 */         ensureHeaderIsMutable();
/* 1305 */         this.header_.add(value);
/* 1306 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addHeader(URLFetchServicePb.URLFetchRequest.Header.Builder builderForValue) {
/* 1310 */         ensureHeaderIsMutable();
/* 1311 */         this.header_.add(builderForValue.build());
/* 1312 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllHeader(Iterable<? extends URLFetchServicePb.URLFetchRequest.Header> values) {
/* 1316 */         ensureHeaderIsMutable();
/* 1317 */         GeneratedMessage.Builder.addAll(values, this.header_);
/* 1318 */         return this;
/*      */       }
/*      */       public Builder clearHeader() {
/* 1321 */         this.header_ = Collections.emptyList();
/* 1322 */         this.isHeaderMutable = false;
/* 1323 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasPayload()
/*      */       {
/* 1330 */         return this.hasPayload;
/*      */       }
/*      */       public ByteString getPayload() {
/* 1333 */         return this.payload_;
/*      */       }
/*      */       public Builder setPayload(ByteString value) {
/* 1336 */         if (value == null) {
/* 1337 */           throw new NullPointerException();
/*      */         }
/* 1339 */         this.hasPayload = true;
/* 1340 */         this.payload_ = value;
/* 1341 */         return this;
/*      */       }
/*      */       public Builder clearPayload() {
/* 1344 */         this.hasPayload = false;
/* 1345 */         this.payload_ = URLFetchServicePb.URLFetchRequest.getDefaultInstance().getPayload();
/* 1346 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasFollowRedirects()
/*      */       {
/* 1353 */         return this.hasFollowRedirects;
/*      */       }
/*      */       public boolean getFollowRedirects() {
/* 1356 */         return this.followRedirects_;
/*      */       }
/*      */       public Builder setFollowRedirects(boolean value) {
/* 1359 */         this.hasFollowRedirects = true;
/* 1360 */         this.followRedirects_ = value;
/* 1361 */         return this;
/*      */       }
/*      */       public Builder clearFollowRedirects() {
/* 1364 */         this.hasFollowRedirects = false;
/* 1365 */         this.followRedirects_ = true;
/* 1366 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasDeadline()
/*      */       {
/* 1373 */         return this.hasDeadline;
/*      */       }
/*      */       public double getDeadline() {
/* 1376 */         return this.deadline_;
/*      */       }
/*      */       public Builder setDeadline(double value) {
/* 1379 */         this.hasDeadline = true;
/* 1380 */         this.deadline_ = value;
/* 1381 */         return this;
/*      */       }
/*      */       public Builder clearDeadline() {
/* 1384 */         this.hasDeadline = false;
/* 1385 */         this.deadline_ = 0.0D;
/* 1386 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static final class Header extends GeneratedMessage
/*      */     {
/*  795 */       private static final Header defaultInstance = new Header(true);
/*      */       public static final int KEY_FIELD_NUMBER = 4;
/*      */       private boolean hasKey;
/*      */       private String key_;
/*      */       public static final int VALUE_FIELD_NUMBER = 5;
/*      */       private boolean hasValue;
/*      */       private String value_;
/*  517 */       private int memoizedSerializedSize = -1;
/*      */ 
/*      */       private Header(Builder builder)
/*      */       {
/*  450 */         super();
/*      */       }
/*      */       private Header(boolean noInit) {
/*      */       }
/*      */ 
/*      */       public static Header getDefaultInstance() {
/*  456 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public Header getDefaultInstanceForType() {
/*  460 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  465 */         return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_Header_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  470 */         return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_Header_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/*  478 */         return this.hasKey;
/*      */       }
/*      */       public String getKey() {
/*  481 */         return this.key_;
/*      */       }
/*      */ 
/*      */       public boolean hasValue()
/*      */       {
/*  489 */         return this.hasValue;
/*      */       }
/*      */       public String getValue() {
/*  492 */         return this.value_;
/*      */       }
/*      */ 
/*      */       private void initFields() {
/*  496 */         this.key_ = "";
/*  497 */         this.value_ = "";
/*      */       }
/*      */       public final boolean isInitialized() {
/*  500 */         if (!this.hasKey) return false;
/*  501 */         return this.hasValue;
/*      */       }
/*      */ 
/*      */       public void writeTo(CodedOutputStream output)
/*      */         throws IOException
/*      */       {
/*  507 */         getSerializedSize();
/*  508 */         if (hasKey()) {
/*  509 */           output.writeString(4, getKey());
/*      */         }
/*  511 */         if (hasValue()) {
/*  512 */           output.writeString(5, getValue());
/*      */         }
/*  514 */         getUnknownFields().writeTo(output);
/*      */       }
/*      */ 
/*      */       public int getSerializedSize()
/*      */       {
/*  519 */         int size = this.memoizedSerializedSize;
/*  520 */         if (size != -1) return size;
/*      */ 
/*  522 */         size = 0;
/*  523 */         if (hasKey()) {
/*  524 */           size += CodedOutputStream.computeStringSize(4, getKey());
/*      */         }
/*      */ 
/*  527 */         if (hasValue()) {
/*  528 */           size += CodedOutputStream.computeStringSize(5, getValue());
/*      */         }
/*      */ 
/*  531 */         size += getUnknownFields().getSerializedSize();
/*  532 */         this.memoizedSerializedSize = size;
/*  533 */         return size;
/*      */       }
/*      */ 
/*      */       protected Object writeReplace() throws ObjectStreamException
/*      */       {
/*  538 */         return super.writeReplace();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(ByteString data)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/*  544 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/*  550 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */       {
/*  555 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/*  561 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(InputStream input) throws IOException
/*      */       {
/*  566 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  572 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseDelimitedFrom(InputStream input) throws IOException
/*      */       {
/*  577 */         Builder builder = newBuilder();
/*  578 */         if (builder.mergeDelimitedFrom(input)) {
/*  579 */           return builder.buildParsed();
/*      */         }
/*  581 */         return null;
/*      */       }
/*      */ 
/*      */       public static Header parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  588 */         Builder builder = newBuilder();
/*  589 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  590 */           return builder.buildParsed();
/*      */         }
/*  592 */         return null;
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(CodedInputStream input)
/*      */         throws IOException
/*      */       {
/*  598 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Header parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  604 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Builder newBuilder() {
/*  608 */         return Builder.access$1000(); } 
/*  609 */       public Builder newBuilderForType() { return newBuilder(); } 
/*      */       public static Builder newBuilder(Header prototype) {
/*  611 */         return newBuilder().mergeFrom(prototype);
/*      */       }
/*  613 */       public Builder toBuilder() { return newBuilder(this);
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  796 */         URLFetchServicePb.internalForceInit();
/*  797 */         defaultInstance.initFields();
/*      */       }
/*      */ 
/*      */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */       {
/*      */         private boolean hasKey;
/*  747 */         private String key_ = "";
/*      */         private boolean hasValue;
/*  770 */         private String value_ = "";
/*      */ 
/*      */         public static final Descriptors.Descriptor getDescriptor()
/*      */         {
/*  619 */           return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_Header_descriptor;
/*      */         }
/*      */ 
/*      */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */         {
/*  624 */           return URLFetchServicePb.internal_static_apphosting_URLFetchRequest_Header_fieldAccessorTable;
/*      */         }
/*      */ 
/*      */         private static Builder create()
/*      */         {
/*  632 */           return new Builder();
/*      */         }
/*      */ 
/*      */         public Builder clear() {
/*  636 */           super.clear();
/*  637 */           this.key_ = "";
/*  638 */           this.hasKey = false;
/*  639 */           this.value_ = "";
/*  640 */           this.hasValue = false;
/*  641 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder clone() {
/*  645 */           return create().mergeFrom(buildPartial());
/*      */         }
/*      */ 
/*      */         public Descriptors.Descriptor getDescriptorForType()
/*      */         {
/*  650 */           return URLFetchServicePb.URLFetchRequest.Header.getDescriptor();
/*      */         }
/*      */ 
/*      */         public URLFetchServicePb.URLFetchRequest.Header getDefaultInstanceForType() {
/*  654 */           return URLFetchServicePb.URLFetchRequest.Header.getDefaultInstance();
/*      */         }
/*      */ 
/*      */         public URLFetchServicePb.URLFetchRequest.Header build() {
/*  658 */           URLFetchServicePb.URLFetchRequest.Header result = buildPartial();
/*  659 */           if (!result.isInitialized()) {
/*  660 */             throw newUninitializedMessageException(result);
/*      */           }
/*  662 */           return result;
/*      */         }
/*      */ 
/*      */         private URLFetchServicePb.URLFetchRequest.Header buildParsed() throws InvalidProtocolBufferException
/*      */         {
/*  667 */           URLFetchServicePb.URLFetchRequest.Header result = buildPartial();
/*  668 */           if (!result.isInitialized()) {
/*  669 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */           }
/*      */ 
/*  672 */           return result;
/*      */         }
/*      */ 
/*      */         public URLFetchServicePb.URLFetchRequest.Header buildPartial() {
/*  676 */           URLFetchServicePb.URLFetchRequest.Header result = new URLFetchServicePb.URLFetchRequest.Header(this, null);
/*  677 */           URLFetchServicePb.URLFetchRequest.Header.access$1202(result, this.hasKey);
/*  678 */           URLFetchServicePb.URLFetchRequest.Header.access$1302(result, this.key_);
/*  679 */           URLFetchServicePb.URLFetchRequest.Header.access$1402(result, this.hasValue);
/*  680 */           URLFetchServicePb.URLFetchRequest.Header.access$1502(result, this.value_);
/*  681 */           return result;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(Message other) {
/*  685 */           if ((other instanceof URLFetchServicePb.URLFetchRequest.Header)) {
/*  686 */             return mergeFrom((URLFetchServicePb.URLFetchRequest.Header)other);
/*      */           }
/*  688 */           super.mergeFrom(other);
/*  689 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(URLFetchServicePb.URLFetchRequest.Header other)
/*      */         {
/*  694 */           if (other == URLFetchServicePb.URLFetchRequest.Header.getDefaultInstance()) return this;
/*  695 */           if (other.hasKey()) {
/*  696 */             setKey(other.getKey());
/*      */           }
/*  698 */           if (other.hasValue()) {
/*  699 */             setValue(other.getValue());
/*      */           }
/*  701 */           mergeUnknownFields(other.getUnknownFields());
/*  702 */           return this;
/*      */         }
/*      */ 
/*      */         public final boolean isInitialized() {
/*  706 */           if (!this.hasKey) return false;
/*  707 */           return this.hasValue;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */           throws IOException
/*      */         {
/*  715 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */           while (true)
/*      */           {
/*  719 */             int tag = input.readTag();
/*  720 */             switch (tag) {
/*      */             case 0:
/*  722 */               setUnknownFields(unknownFields.build());
/*  723 */               return this;
/*      */             default:
/*  725 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */                 break;
/*  727 */               setUnknownFields(unknownFields.build());
/*  728 */               return this;
/*      */             case 34:
/*  733 */               setKey(input.readString());
/*  734 */               break;
/*      */             case 42:
/*  737 */               setValue(input.readString());
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         public boolean hasKey()
/*      */         {
/*  749 */           return this.hasKey;
/*      */         }
/*      */         public String getKey() {
/*  752 */           return this.key_;
/*      */         }
/*      */         public Builder setKey(String value) {
/*  755 */           if (value == null) {
/*  756 */             throw new NullPointerException();
/*      */           }
/*  758 */           this.hasKey = true;
/*  759 */           this.key_ = value;
/*  760 */           return this;
/*      */         }
/*      */         public Builder clearKey() {
/*  763 */           this.hasKey = false;
/*  764 */           this.key_ = URLFetchServicePb.URLFetchRequest.Header.getDefaultInstance().getKey();
/*  765 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasValue()
/*      */         {
/*  772 */           return this.hasValue;
/*      */         }
/*      */         public String getValue() {
/*  775 */           return this.value_;
/*      */         }
/*      */         public Builder setValue(String value) {
/*  778 */           if (value == null) {
/*  779 */             throw new NullPointerException();
/*      */           }
/*  781 */           this.hasValue = true;
/*  782 */           this.value_ = value;
/*  783 */           return this;
/*      */         }
/*      */         public Builder clearValue() {
/*  786 */           this.hasValue = false;
/*  787 */           this.value_ = URLFetchServicePb.URLFetchRequest.Header.getDefaultInstance().getValue();
/*  788 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum RequestMethod
/*      */       implements ProtocolMessageEnum
/*      */     {
/*  369 */       GET(0, 1), 
/*  370 */       POST(1, 2), 
/*  371 */       HEAD(2, 3), 
/*  372 */       PUT(3, 4), 
/*  373 */       DELETE(4, 5);
/*      */ 
/*      */       public static final int GET_VALUE = 1;
/*      */       public static final int POST_VALUE = 2;
/*      */       public static final int HEAD_VALUE = 3;
/*      */       public static final int PUT_VALUE = 4;
/*      */       public static final int DELETE_VALUE = 5;
/*      */       private static Internal.EnumLiteMap<RequestMethod> internalValueMap;
/*      */       private static final RequestMethod[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/*  383 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static RequestMethod valueOf(int value) {
/*  386 */         switch (value) { case 1:
/*  387 */           return GET;
/*      */         case 2:
/*  388 */           return POST;
/*      */         case 3:
/*  389 */           return HEAD;
/*      */         case 4:
/*  390 */           return PUT;
/*      */         case 5:
/*  391 */           return DELETE; }
/*  392 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<RequestMethod> internalGetValueMap()
/*      */       {
/*  398 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/*  410 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  414 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  418 */         return (Descriptors.EnumDescriptor)URLFetchServicePb.URLFetchRequest.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static RequestMethod valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/*  426 */         if (desc.getType() != getDescriptor()) {
/*  427 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/*  430 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private RequestMethod(int index, int value)
/*      */       {
/*  435 */         this.index = index;
/*  436 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  401 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public URLFetchServicePb.URLFetchRequest.RequestMethod findValueByNumber(int number) {
/*  404 */             return URLFetchServicePb.URLFetchRequest.RequestMethod.valueOf(number);
/*      */           }
/*      */         };
/*  421 */         VALUES = new RequestMethod[] { GET, POST, HEAD, PUT, DELETE };
/*      */ 
/*  440 */         URLFetchServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class URLFetchServiceError extends GeneratedMessage
/*      */   {
/*  332 */     private static final URLFetchServiceError defaultInstance = new URLFetchServiceError(true);
/*      */ 
/*  132 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private URLFetchServiceError(Builder builder)
/*      */     {
/*   15 */       super();
/*      */     }
/*      */     private URLFetchServiceError(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError getDefaultInstance() {
/*   21 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public URLFetchServiceError getDefaultInstanceForType() {
/*   25 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*   30 */       return URLFetchServicePb.internal_static_apphosting_URLFetchServiceError_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*   35 */       return URLFetchServicePb.internal_static_apphosting_URLFetchServiceError_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     private void initFields()
/*      */     {
/*      */     }
/*      */ 
/*      */     public final boolean isInitialized()
/*      */     {
/*  123 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/*  128 */       getSerializedSize();
/*  129 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  134 */       int size = this.memoizedSerializedSize;
/*  135 */       if (size != -1) return size;
/*      */ 
/*  137 */       size = 0;
/*  138 */       size += getUnknownFields().getSerializedSize();
/*  139 */       this.memoizedSerializedSize = size;
/*  140 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  145 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  151 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  157 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  162 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  168 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(InputStream input) throws IOException
/*      */     {
/*  173 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  179 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  184 */       Builder builder = newBuilder();
/*  185 */       if (builder.mergeDelimitedFrom(input)) {
/*  186 */         return builder.buildParsed();
/*      */       }
/*  188 */       return null;
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  195 */       Builder builder = newBuilder();
/*  196 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  197 */         return builder.buildParsed();
/*      */       }
/*  199 */       return null;
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  205 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static URLFetchServiceError parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  211 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  215 */       return Builder.access$300(); } 
/*  216 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(URLFetchServiceError prototype) {
/*  218 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  220 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  333 */       URLFetchServicePb.internalForceInit();
/*  334 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  226 */         return URLFetchServicePb.internal_static_apphosting_URLFetchServiceError_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  231 */         return URLFetchServicePb.internal_static_apphosting_URLFetchServiceError_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  239 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  243 */         super.clear();
/*  244 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  248 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  253 */         return URLFetchServicePb.URLFetchServiceError.getDescriptor();
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchServiceError getDefaultInstanceForType() {
/*  257 */         return URLFetchServicePb.URLFetchServiceError.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchServiceError build() {
/*  261 */         URLFetchServicePb.URLFetchServiceError result = buildPartial();
/*  262 */         if (!result.isInitialized()) {
/*  263 */           throw newUninitializedMessageException(result);
/*      */         }
/*  265 */         return result;
/*      */       }
/*      */ 
/*      */       private URLFetchServicePb.URLFetchServiceError buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  270 */         URLFetchServicePb.URLFetchServiceError result = buildPartial();
/*  271 */         if (!result.isInitialized()) {
/*  272 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  275 */         return result;
/*      */       }
/*      */ 
/*      */       public URLFetchServicePb.URLFetchServiceError buildPartial() {
/*  279 */         URLFetchServicePb.URLFetchServiceError result = new URLFetchServicePb.URLFetchServiceError(this, null);
/*  280 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  284 */         if ((other instanceof URLFetchServicePb.URLFetchServiceError)) {
/*  285 */           return mergeFrom((URLFetchServicePb.URLFetchServiceError)other);
/*      */         }
/*  287 */         super.mergeFrom(other);
/*  288 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(URLFetchServicePb.URLFetchServiceError other)
/*      */       {
/*  293 */         if (other == URLFetchServicePb.URLFetchServiceError.getDefaultInstance()) return this;
/*  294 */         mergeUnknownFields(other.getUnknownFields());
/*  295 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  299 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  306 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  310 */           int tag = input.readTag();
/*  311 */           switch (tag) {
/*      */           case 0:
/*  313 */             setUnknownFields(unknownFields.build());
/*  314 */             return this;
/*      */           }
/*  316 */           if (!parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */           {
/*  318 */             setUnknownFields(unknownFields.build());
/*  319 */             return this;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   40 */       OK(0, 0), 
/*   41 */       INVALID_URL(1, 1), 
/*   42 */       FETCH_ERROR(2, 2), 
/*   43 */       UNSPECIFIED_ERROR(3, 3), 
/*   44 */       RESPONSE_TOO_LARGE(4, 4), 
/*   45 */       DEADLINE_EXCEEDED(5, 5);
/*      */ 
/*      */       public static final int OK_VALUE = 0;
/*      */       public static final int INVALID_URL_VALUE = 1;
/*      */       public static final int FETCH_ERROR_VALUE = 2;
/*      */       public static final int UNSPECIFIED_ERROR_VALUE = 3;
/*      */       public static final int RESPONSE_TOO_LARGE_VALUE = 4;
/*      */       public static final int DEADLINE_EXCEEDED_VALUE = 5;
/*      */       private static Internal.EnumLiteMap<ErrorCode> internalValueMap;
/*      */       private static final ErrorCode[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/*   56 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   59 */         switch (value) { case 0:
/*   60 */           return OK;
/*      */         case 1:
/*   61 */           return INVALID_URL;
/*      */         case 2:
/*   62 */           return FETCH_ERROR;
/*      */         case 3:
/*   63 */           return UNSPECIFIED_ERROR;
/*      */         case 4:
/*   64 */           return RESPONSE_TOO_LARGE;
/*      */         case 5:
/*   65 */           return DEADLINE_EXCEEDED; }
/*   66 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<ErrorCode> internalGetValueMap()
/*      */       {
/*   72 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/*   84 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*   88 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*   92 */         return (Descriptors.EnumDescriptor)URLFetchServicePb.URLFetchServiceError.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static ErrorCode valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/*  100 */         if (desc.getType() != getDescriptor()) {
/*  101 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/*  104 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private ErrorCode(int index, int value)
/*      */       {
/*  109 */         this.index = index;
/*  110 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   75 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public URLFetchServicePb.URLFetchServiceError.ErrorCode findValueByNumber(int number) {
/*   78 */             return URLFetchServicePb.URLFetchServiceError.ErrorCode.valueOf(number);
/*      */           }
/*      */         };
/*   95 */         VALUES = new ErrorCode[] { OK, INVALID_URL, FETCH_ERROR, UNSPECIFIED_ERROR, RESPONSE_TOO_LARGE, DEADLINE_EXCEEDED };
/*      */ 
/*  114 */         URLFetchServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.URLFetchServicePb
 * JD-Core Version:    0.6.0
 */