/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public class DatastoreNeedIndexException extends RuntimeException
/*    */ {
/*    */   static final long serialVersionUID = 9218197931741583584L;
/*    */   static final String NO_XML_MESSAGE = ".  An index is missing but we are unable to tell you which one due to a bug in the App Engine SDK.  If your query only contains equality filters you most likely need a composite index on all the properties referenced in those filters.";
/*    */   String xml;
/*    */ 
/*    */   public DatastoreNeedIndexException(String message)
/*    */   {
/* 23 */     super(message);
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 28 */     return super.getMessage() + (this.xml == null ? ".  An index is missing but we are unable to tell you which one due to a bug in the App Engine SDK.  If your query only contains equality filters you most likely need a composite index on all the properties referenced in those filters." : new StringBuilder().append(".  ").append(this.xml).toString());
/*    */   }
/*    */ 
/*    */   public String getMissingIndexDefinitionXml()
/*    */   {
/* 35 */     return this.xml;
/*    */   }
/*    */ 
/*    */   void setMissingIndexDefinitionXml(String xml) {
/* 39 */     this.xml = xml;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreNeedIndexException
 * JD-Core Version:    0.6.0
 */