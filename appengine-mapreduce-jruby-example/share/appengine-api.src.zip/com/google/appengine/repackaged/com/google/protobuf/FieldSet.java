/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ final class FieldSet<FieldDescriptorType extends FieldDescriptorLite<FieldDescriptorType>>
/*     */ {
/*     */   private Map<FieldDescriptorType, Object> fields;
/*     */   private boolean isImmutable;
/*  77 */   private static final FieldSet DEFAULT_INSTANCE = new FieldSet(true);
/*     */ 
/*     */   private FieldSet()
/*     */   {
/*  52 */     this.fields = new TreeMap();
/*     */   }
/*     */ 
/*     */   private FieldSet(boolean dummy)
/*     */   {
/*  60 */     this.fields = Collections.emptyMap();
/*  61 */     this.isImmutable = true;
/*     */   }
/*     */ 
/*     */   public static <T extends FieldDescriptorLite<T>> FieldSet<T> newFieldSet()
/*     */   {
/*  67 */     return new FieldSet();
/*     */   }
/*     */ 
/*     */   public static <T extends FieldDescriptorLite<T>> FieldSet<T> emptySet()
/*     */   {
/*  74 */     return DEFAULT_INSTANCE;
/*     */   }
/*     */ 
/*     */   public void makeImmutable()
/*     */   {
/*  82 */     if (this.isImmutable) {
/*  83 */       return;
/*     */     }
/*     */ 
/*  86 */     for (Map.Entry entry : this.fields.entrySet()) {
/*  87 */       if (((FieldDescriptorLite)entry.getKey()).isRepeated()) {
/*  88 */         List value = (List)entry.getValue();
/*  89 */         entry.setValue(Collections.unmodifiableList(value));
/*     */       }
/*     */     }
/*  92 */     this.fields = Collections.unmodifiableMap(this.fields);
/*  93 */     this.isImmutable = true;
/*     */   }
/*     */ 
/*     */   public boolean isImmutable()
/*     */   {
/* 103 */     return this.isImmutable;
/*     */   }
/*     */ 
/*     */   public FieldSet<FieldDescriptorType> clone()
/*     */   {
/* 116 */     FieldSet clone = newFieldSet();
/* 117 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 118 */       FieldDescriptorLite descriptor = (FieldDescriptorLite)entry.getKey();
/* 119 */       clone.setField(descriptor, entry.getValue());
/*     */     }
/* 121 */     return clone;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 128 */     this.fields.clear();
/*     */   }
/*     */ 
/*     */   public Map<FieldDescriptorType, Object> getAllFields()
/*     */   {
/* 135 */     return Collections.unmodifiableMap(this.fields);
/*     */   }
/*     */ 
/*     */   public Iterator<Map.Entry<FieldDescriptorType, Object>> iterator()
/*     */   {
/* 143 */     return this.fields.entrySet().iterator();
/*     */   }
/*     */ 
/*     */   public boolean hasField(FieldDescriptorType descriptor)
/*     */   {
/* 151 */     if (descriptor.isRepeated()) {
/* 152 */       throw new IllegalArgumentException("hasField() can only be called on non-repeated fields.");
/*     */     }
/*     */ 
/* 156 */     return this.fields.get(descriptor) != null;
/*     */   }
/*     */ 
/*     */   public Object getField(FieldDescriptorType descriptor)
/*     */   {
/* 166 */     return this.fields.get(descriptor);
/*     */   }
/*     */ 
/*     */   public void setField(FieldDescriptorType descriptor, Object value)
/*     */   {
/* 176 */     if (descriptor.isRepeated()) {
/* 177 */       if (!(value instanceof List)) {
/* 178 */         throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
/*     */       }
/*     */ 
/* 184 */       List newList = new ArrayList();
/* 185 */       newList.addAll((List)value);
/* 186 */       for (Iterator i$ = newList.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 187 */         verifyType(descriptor.getLiteType(), element);
/*     */       }
/* 189 */       value = newList;
/*     */     } else {
/* 191 */       verifyType(descriptor.getLiteType(), value);
/*     */     }
/*     */ 
/* 194 */     this.fields.put(descriptor, value);
/*     */   }
/*     */ 
/*     */   public void clearField(FieldDescriptorType descriptor)
/*     */   {
/* 202 */     this.fields.remove(descriptor);
/*     */   }
/*     */ 
/*     */   public int getRepeatedFieldCount(FieldDescriptorType descriptor)
/*     */   {
/* 210 */     if (!descriptor.isRepeated()) {
/* 211 */       throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
/*     */     }
/*     */ 
/* 215 */     Object value = this.fields.get(descriptor);
/* 216 */     if (value == null) {
/* 217 */       return 0;
/*     */     }
/* 219 */     return ((List)value).size();
/*     */   }
/*     */ 
/*     */   public Object getRepeatedField(FieldDescriptorType descriptor, int index)
/*     */   {
/* 229 */     if (!descriptor.isRepeated()) {
/* 230 */       throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
/*     */     }
/*     */ 
/* 234 */     Object value = this.fields.get(descriptor);
/*     */ 
/* 236 */     if (value == null) {
/* 237 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 239 */     return ((List)value).get(index);
/*     */   }
/*     */ 
/*     */   public void setRepeatedField(FieldDescriptorType descriptor, int index, Object value)
/*     */   {
/* 251 */     if (!descriptor.isRepeated()) {
/* 252 */       throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
/*     */     }
/*     */ 
/* 256 */     Object list = this.fields.get(descriptor);
/* 257 */     if (list == null) {
/* 258 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */ 
/* 261 */     verifyType(descriptor.getLiteType(), value);
/* 262 */     ((List)list).set(index, value);
/*     */   }
/*     */ 
/*     */   public void addRepeatedField(FieldDescriptorType descriptor, Object value)
/*     */   {
/* 272 */     if (!descriptor.isRepeated()) {
/* 273 */       throw new IllegalArgumentException("addRepeatedField() can only be called on repeated fields.");
/*     */     }
/*     */ 
/* 277 */     verifyType(descriptor.getLiteType(), value);
/*     */ 
/* 279 */     Object existingValue = this.fields.get(descriptor);
/*     */     List list;
/* 281 */     if (existingValue == null) {
/* 282 */       List list = new ArrayList();
/* 283 */       this.fields.put(descriptor, list);
/*     */     } else {
/* 285 */       list = (List)existingValue;
/*     */     }
/*     */ 
/* 288 */     list.add(value);
/*     */   }
/*     */ 
/*     */   private static void verifyType(WireFormat.FieldType type, Object value)
/*     */   {
/* 300 */     if (value == null) {
/* 301 */       throw new NullPointerException();
/*     */     }
/*     */ 
/* 304 */     boolean isValid = false;
/* 305 */     switch (1.$SwitchMap$com$google$protobuf$WireFormat$JavaType[type.getJavaType().ordinal()]) { case 1:
/* 306 */       isValid = value instanceof Integer; break;
/*     */     case 2:
/* 307 */       isValid = value instanceof Long; break;
/*     */     case 3:
/* 308 */       isValid = value instanceof Float; break;
/*     */     case 4:
/* 309 */       isValid = value instanceof Double; break;
/*     */     case 5:
/* 310 */       isValid = value instanceof Boolean; break;
/*     */     case 6:
/* 311 */       isValid = value instanceof String; break;
/*     */     case 7:
/* 312 */       isValid = value instanceof ByteString; break;
/*     */     case 8:
/* 315 */       isValid = value instanceof Internal.EnumLite;
/* 316 */       break;
/*     */     case 9:
/* 319 */       isValid = value instanceof MessageLite;
/*     */     }
/*     */ 
/* 323 */     if (!isValid)
/*     */     {
/* 331 */       throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/* 348 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 349 */       FieldDescriptorLite descriptor = (FieldDescriptorLite)entry.getKey();
/* 350 */       if (descriptor.getLiteJavaType() == WireFormat.JavaType.MESSAGE) {
/* 351 */         if (descriptor.isRepeated())
/*     */         {
/* 353 */           for (MessageLite element : (List)entry.getValue()) {
/* 354 */             if (!element.isInitialized()) {
/* 355 */               return false;
/*     */             }
/*     */           }
/*     */         }
/* 359 */         else if (!((MessageLite)entry.getValue()).isInitialized()) {
/* 360 */           return false;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 366 */     return true;
/*     */   }
/*     */ 
/*     */   static int getWireFormatForFieldType(WireFormat.FieldType type, boolean isPacked)
/*     */   {
/* 377 */     if (isPacked) {
/* 378 */       return 2;
/*     */     }
/* 380 */     return type.getWireType();
/*     */   }
/*     */ 
/*     */   public void mergeFrom(FieldSet<FieldDescriptorType> other)
/*     */   {
/* 390 */     for (Map.Entry entry : other.fields.entrySet()) {
/* 391 */       FieldDescriptorLite descriptor = (FieldDescriptorLite)entry.getKey();
/* 392 */       Object otherValue = entry.getValue();
/*     */ 
/* 394 */       if (descriptor.isRepeated()) {
/* 395 */         Object value = this.fields.get(descriptor);
/* 396 */         if (value == null)
/*     */         {
/* 400 */           this.fields.put(descriptor, new ArrayList((List)otherValue));
/*     */         }
/*     */         else
/* 403 */           ((List)value).addAll((List)otherValue);
/*     */       }
/* 405 */       else if (descriptor.getLiteJavaType() == WireFormat.JavaType.MESSAGE) {
/* 406 */         Object value = this.fields.get(descriptor);
/* 407 */         if (value == null) {
/* 408 */           this.fields.put(descriptor, otherValue);
/*     */         }
/*     */         else {
/* 411 */           this.fields.put(descriptor, descriptor.internalMergeFrom(((MessageLite)value).toBuilder(), (MessageLite)otherValue).build());
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 418 */         this.fields.put(descriptor, otherValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object readPrimitiveField(CodedInputStream input, WireFormat.FieldType type)
/*     */     throws IOException
/*     */   {
/* 440 */     switch (1.$SwitchMap$com$google$protobuf$WireFormat$FieldType[type.ordinal()]) { case 1:
/* 441 */       return Double.valueOf(input.readDouble());
/*     */     case 2:
/* 442 */       return Float.valueOf(input.readFloat());
/*     */     case 3:
/* 443 */       return Long.valueOf(input.readInt64());
/*     */     case 4:
/* 444 */       return Long.valueOf(input.readUInt64());
/*     */     case 5:
/* 445 */       return Integer.valueOf(input.readInt32());
/*     */     case 6:
/* 446 */       return Long.valueOf(input.readFixed64());
/*     */     case 7:
/* 447 */       return Integer.valueOf(input.readFixed32());
/*     */     case 8:
/* 448 */       return Boolean.valueOf(input.readBool());
/*     */     case 9:
/* 449 */       return input.readString();
/*     */     case 10:
/* 450 */       return input.readBytes();
/*     */     case 11:
/* 451 */       return Integer.valueOf(input.readUInt32());
/*     */     case 12:
/* 452 */       return Integer.valueOf(input.readSFixed32());
/*     */     case 13:
/* 453 */       return Long.valueOf(input.readSFixed64());
/*     */     case 14:
/* 454 */       return Integer.valueOf(input.readSInt32());
/*     */     case 15:
/* 455 */       return Long.valueOf(input.readSInt64());
/*     */     case 16:
/* 458 */       throw new IllegalArgumentException("readPrimitiveField() cannot handle nested groups.");
/*     */     case 17:
/* 461 */       throw new IllegalArgumentException("readPrimitiveField() cannot handle embedded messages.");
/*     */     case 18:
/* 466 */       throw new IllegalArgumentException("readPrimitiveField() cannot handle enums.");
/*     */     }
/*     */ 
/* 470 */     throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
/*     */   }
/*     */ 
/*     */   public void writeTo(CodedOutputStream output)
/*     */     throws IOException
/*     */   {
/* 478 */     for (Map.Entry entry : this.fields.entrySet())
/* 479 */       writeField((FieldDescriptorLite)entry.getKey(), entry.getValue(), output);
/*     */   }
/*     */ 
/*     */   public void writeMessageSetTo(CodedOutputStream output)
/*     */     throws IOException
/*     */   {
/* 489 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 490 */       FieldDescriptorLite descriptor = (FieldDescriptorLite)entry.getKey();
/* 491 */       if ((descriptor.getLiteJavaType() == WireFormat.JavaType.MESSAGE) && (!descriptor.isRepeated()) && (!descriptor.isPacked()))
/*     */       {
/* 493 */         output.writeMessageSetExtension(((FieldDescriptorLite)entry.getKey()).getNumber(), (MessageLite)entry.getValue());
/*     */       }
/*     */       else
/* 496 */         writeField(descriptor, entry.getValue(), output);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void writeElement(CodedOutputStream output, WireFormat.FieldType type, int number, Object value)
/*     */     throws IOException
/*     */   {
/* 518 */     if (type == WireFormat.FieldType.GROUP) {
/* 519 */       output.writeGroup(number, (MessageLite)value);
/*     */     } else {
/* 521 */       output.writeTag(number, getWireFormatForFieldType(type, false));
/* 522 */       writeElementNoTag(output, type, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void writeElementNoTag(CodedOutputStream output, WireFormat.FieldType type, Object value)
/*     */     throws IOException
/*     */   {
/* 540 */     switch (1.$SwitchMap$com$google$protobuf$WireFormat$FieldType[type.ordinal()]) { case 1:
/* 541 */       output.writeDoubleNoTag(((Double)value).doubleValue()); break;
/*     */     case 2:
/* 542 */       output.writeFloatNoTag(((Float)value).floatValue()); break;
/*     */     case 3:
/* 543 */       output.writeInt64NoTag(((Long)value).longValue()); break;
/*     */     case 4:
/* 544 */       output.writeUInt64NoTag(((Long)value).longValue()); break;
/*     */     case 5:
/* 545 */       output.writeInt32NoTag(((Integer)value).intValue()); break;
/*     */     case 6:
/* 546 */       output.writeFixed64NoTag(((Long)value).longValue()); break;
/*     */     case 7:
/* 547 */       output.writeFixed32NoTag(((Integer)value).intValue()); break;
/*     */     case 8:
/* 548 */       output.writeBoolNoTag(((Boolean)value).booleanValue()); break;
/*     */     case 9:
/* 549 */       output.writeStringNoTag((String)value); break;
/*     */     case 16:
/* 550 */       output.writeGroupNoTag((MessageLite)value); break;
/*     */     case 17:
/* 551 */       output.writeMessageNoTag((MessageLite)value); break;
/*     */     case 10:
/* 552 */       output.writeBytesNoTag((ByteString)value); break;
/*     */     case 11:
/* 553 */       output.writeUInt32NoTag(((Integer)value).intValue()); break;
/*     */     case 12:
/* 554 */       output.writeSFixed32NoTag(((Integer)value).intValue()); break;
/*     */     case 13:
/* 555 */       output.writeSFixed64NoTag(((Long)value).longValue()); break;
/*     */     case 14:
/* 556 */       output.writeSInt32NoTag(((Integer)value).intValue()); break;
/*     */     case 15:
/* 557 */       output.writeSInt64NoTag(((Long)value).longValue()); break;
/*     */     case 18:
/* 560 */       output.writeEnumNoTag(((Internal.EnumLite)value).getNumber());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void writeField(FieldDescriptorLite<?> descriptor, Object value, CodedOutputStream output)
/*     */     throws IOException
/*     */   {
/* 570 */     WireFormat.FieldType type = descriptor.getLiteType();
/* 571 */     int number = descriptor.getNumber();
/*     */     Iterator i$;
/* 572 */     if (descriptor.isRepeated()) {
/* 573 */       List valueList = (List)value;
/*     */       Iterator i$;
/* 574 */       if (descriptor.isPacked()) {
/* 575 */         output.writeTag(number, 2);
/*     */ 
/* 577 */         int dataSize = 0;
/* 578 */         for (Iterator i$ = valueList.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 579 */           dataSize += computeElementSizeNoTag(type, element);
/*     */         }
/* 581 */         output.writeRawVarint32(dataSize);
/*     */ 
/* 583 */         for (i$ = valueList.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 584 */           writeElementNoTag(output, type, element); }
/*     */       }
/*     */       else {
/* 587 */         for (i$ = valueList.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 588 */           writeElement(output, type, number, element); }
/*     */       }
/*     */     }
/*     */     else {
/* 592 */       writeElement(output, type, number, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getSerializedSize()
/*     */   {
/* 601 */     int size = 0;
/*     */ 
/* 603 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 604 */       size += computeFieldSize((FieldDescriptorLite)entry.getKey(), entry.getValue());
/*     */     }
/* 606 */     return size;
/*     */   }
/*     */ 
/*     */   public int getMessageSetSerializedSize()
/*     */   {
/* 613 */     int size = 0;
/*     */ 
/* 615 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 616 */       FieldDescriptorLite descriptor = (FieldDescriptorLite)entry.getKey();
/* 617 */       if ((descriptor.getLiteJavaType() == WireFormat.JavaType.MESSAGE) && (!descriptor.isRepeated()) && (!descriptor.isPacked()))
/*     */       {
/* 619 */         size += CodedOutputStream.computeMessageSetExtensionSize(((FieldDescriptorLite)entry.getKey()).getNumber(), (MessageLite)entry.getValue());
/*     */       }
/*     */       else {
/* 622 */         size += computeFieldSize(descriptor, entry.getValue());
/*     */       }
/*     */     }
/* 625 */     return size;
/*     */   }
/*     */ 
/*     */   private static int computeElementSize(WireFormat.FieldType type, int number, Object value)
/*     */   {
/* 642 */     int tagSize = CodedOutputStream.computeTagSize(number);
/* 643 */     if (type == WireFormat.FieldType.GROUP) {
/* 644 */       tagSize *= 2;
/*     */     }
/* 646 */     return tagSize + computeElementSizeNoTag(type, value);
/*     */   }
/*     */ 
/*     */   private static int computeElementSizeNoTag(WireFormat.FieldType type, Object value)
/*     */   {
/* 661 */     switch (1.$SwitchMap$com$google$protobuf$WireFormat$FieldType[type.ordinal()])
/*     */     {
/*     */     case 1:
/* 664 */       return CodedOutputStream.computeDoubleSizeNoTag(((Double)value).doubleValue());
/*     */     case 2:
/* 665 */       return CodedOutputStream.computeFloatSizeNoTag(((Float)value).floatValue());
/*     */     case 3:
/* 666 */       return CodedOutputStream.computeInt64SizeNoTag(((Long)value).longValue());
/*     */     case 4:
/* 667 */       return CodedOutputStream.computeUInt64SizeNoTag(((Long)value).longValue());
/*     */     case 5:
/* 668 */       return CodedOutputStream.computeInt32SizeNoTag(((Integer)value).intValue());
/*     */     case 6:
/* 669 */       return CodedOutputStream.computeFixed64SizeNoTag(((Long)value).longValue());
/*     */     case 7:
/* 670 */       return CodedOutputStream.computeFixed32SizeNoTag(((Integer)value).intValue());
/*     */     case 8:
/* 671 */       return CodedOutputStream.computeBoolSizeNoTag(((Boolean)value).booleanValue());
/*     */     case 9:
/* 672 */       return CodedOutputStream.computeStringSizeNoTag((String)value);
/*     */     case 16:
/* 673 */       return CodedOutputStream.computeGroupSizeNoTag((MessageLite)value);
/*     */     case 17:
/* 674 */       return CodedOutputStream.computeMessageSizeNoTag((MessageLite)value);
/*     */     case 10:
/* 675 */       return CodedOutputStream.computeBytesSizeNoTag((ByteString)value);
/*     */     case 11:
/* 676 */       return CodedOutputStream.computeUInt32SizeNoTag(((Integer)value).intValue());
/*     */     case 12:
/* 677 */       return CodedOutputStream.computeSFixed32SizeNoTag(((Integer)value).intValue());
/*     */     case 13:
/* 678 */       return CodedOutputStream.computeSFixed64SizeNoTag(((Long)value).longValue());
/*     */     case 14:
/* 679 */       return CodedOutputStream.computeSInt32SizeNoTag(((Integer)value).intValue());
/*     */     case 15:
/* 680 */       return CodedOutputStream.computeSInt64SizeNoTag(((Long)value).longValue());
/*     */     case 18:
/* 683 */       return CodedOutputStream.computeEnumSizeNoTag(((Internal.EnumLite)value).getNumber());
/*     */     }
/*     */ 
/* 687 */     throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
/*     */   }
/*     */ 
/*     */   public static int computeFieldSize(FieldDescriptorLite<?> descriptor, Object value)
/*     */   {
/* 696 */     WireFormat.FieldType type = descriptor.getLiteType();
/* 697 */     int number = descriptor.getNumber();
/* 698 */     if (descriptor.isRepeated()) {
/* 699 */       if (descriptor.isPacked()) {
/* 700 */         int dataSize = 0;
/* 701 */         for (Iterator i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 702 */           dataSize += computeElementSizeNoTag(type, element);
/*     */         }
/* 704 */         return dataSize + CodedOutputStream.computeTagSize(number) + CodedOutputStream.computeRawVarint32Size(dataSize);
/*     */       }
/*     */ 
/* 708 */       int size = 0;
/* 709 */       for (Iterator i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 710 */         size += computeElementSize(type, number, element);
/*     */       }
/* 712 */       return size;
/*     */     }
/*     */ 
/* 715 */     return computeElementSize(type, number, value);
/*     */   }
/*     */ 
/*     */   public static abstract interface FieldDescriptorLite<T extends FieldDescriptorLite<T>> extends Comparable<T>
/*     */   {
/*     */     public abstract int getNumber();
/*     */ 
/*     */     public abstract WireFormat.FieldType getLiteType();
/*     */ 
/*     */     public abstract WireFormat.JavaType getLiteJavaType();
/*     */ 
/*     */     public abstract boolean isRepeated();
/*     */ 
/*     */     public abstract boolean isPacked();
/*     */ 
/*     */     public abstract Internal.EnumLiteMap<?> getEnumType();
/*     */ 
/*     */     public abstract MessageLite.Builder internalMergeFrom(MessageLite.Builder paramBuilder, MessageLite paramMessageLite);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.FieldSet
 * JD-Core Version:    0.6.0
 */