package com.google.appengine.repackaged.com.google.common.base;

import com.google.common.annotations.GoogleInternal;
import java.util.Properties;
import java.util.logging.Handler;

@GoogleInternal
public abstract interface ConfigurableHandler
{
  public abstract Handler configure(String paramString, Properties paramProperties);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.ConfigurableHandler
 * JD-Core Version:    0.6.0
 */