/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ 
/*    */ @GoogleInternal
/*    */ public abstract class Promise<T>
/*    */   implements Supplier<T>
/*    */ {
/*    */   private final Supplier<T> delegate;
/*    */ 
/*    */   public Promise()
/*    */   {
/* 24 */     this.delegate = Suppliers.memoize(new Supplier() {
/*    */       public T get() {
/* 26 */         return Promise.this.compute();
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   protected abstract T compute();
/*    */ 
/*    */   public T get()
/*    */   {
/* 42 */     return this.delegate.get();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Promise
 * JD-Core Version:    0.6.0
 */