/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Joiner.MapJoiner;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public abstract class ImmutableMap<K, V>
/*     */   implements Map<K, V>, Serializable
/*     */ {
/*     */   public static <K, V> ImmutableMap<K, V> of()
/*     */   {
/*  63 */     return EmptyImmutableMap.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1)
/*     */   {
/*  73 */     return new SingletonImmutableMap(Preconditions.checkNotNull(k1), Preconditions.checkNotNull(v1));
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2)
/*     */   {
/*  83 */     return new RegularImmutableMap(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*     */   {
/*  93 */     return new RegularImmutableMap(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*     */   {
/* 104 */     return new RegularImmutableMap(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*     */   {
/* 115 */     return new RegularImmutableMap(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*     */   }
/*     */ 
/*     */   public static <K, V> Builder<K, V> builder()
/*     */   {
/* 126 */     return new Builder();
/*     */   }
/*     */ 
/*     */   static <K, V> Map.Entry<K, V> entryOf(K key, V value)
/*     */   {
/* 137 */     return Maps.immutableEntry(Preconditions.checkNotNull(key), Preconditions.checkNotNull(value));
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/*     */   {
/* 231 */     if (((map instanceof ImmutableMap)) && (!(map instanceof ImmutableSortedMap)))
/*     */     {
/* 233 */       ImmutableMap kvMap = (ImmutableMap)map;
/* 234 */       return kvMap;
/*     */     }
/*     */ 
/* 238 */     Map.Entry[] entries = (Map.Entry[])map.entrySet().toArray(new Map.Entry[0]);
/* 239 */     switch (entries.length) {
/*     */     case 0:
/* 241 */       return of();
/*     */     case 1:
/* 243 */       return new SingletonImmutableMap(entryOf(entries[0].getKey(), entries[0].getValue()));
/*     */     }
/*     */ 
/* 246 */     for (int i = 0; i < entries.length; i++) {
/* 247 */       Object k = entries[i].getKey();
/* 248 */       Object v = entries[i].getValue();
/* 249 */       entries[i] = entryOf(k, v);
/*     */     }
/* 251 */     return new RegularImmutableMap(entries);
/*     */   }
/*     */ 
/*     */   public final V put(K k, V v)
/*     */   {
/* 263 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final V remove(Object o)
/*     */   {
/* 272 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final void putAll(Map<? extends K, ? extends V> map)
/*     */   {
/* 281 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final void clear()
/*     */   {
/* 290 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 294 */     return size() == 0;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(@Nullable Object key) {
/* 298 */     return get(key) != null;
/*     */   }
/*     */ 
/*     */   public abstract boolean containsValue(@Nullable Object paramObject);
/*     */ 
/*     */   public abstract V get(@Nullable Object paramObject);
/*     */ 
/*     */   public abstract ImmutableSet<Map.Entry<K, V>> entrySet();
/*     */ 
/*     */   public abstract ImmutableSet<K> keySet();
/*     */ 
/*     */   public abstract ImmutableCollection<V> values();
/*     */ 
/*     */   public boolean equals(@Nullable Object object)
/*     */   {
/* 326 */     if (object == this) {
/* 327 */       return true;
/*     */     }
/* 329 */     if ((object instanceof Map)) {
/* 330 */       Map that = (Map)object;
/* 331 */       return entrySet().equals(that.entrySet());
/*     */     }
/* 333 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 339 */     return entrySet().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 343 */     StringBuilder result = new StringBuilder(size() * 16).append('{');
/* 344 */     Maps.standardJoiner.appendTo(result, this);
/* 345 */     return '}';
/*     */   }
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 380 */     return new SerializedForm(this);
/*     */   }
/*     */ 
/*     */   static class SerializedForm
/*     */     implements Serializable
/*     */   {
/*     */     private final Object[] keys;
/*     */     private final Object[] values;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SerializedForm(ImmutableMap<?, ?> map)
/*     */     {
/* 357 */       this.keys = new Object[map.size()];
/* 358 */       this.values = new Object[map.size()];
/* 359 */       int i = 0;
/* 360 */       for (Map.Entry entry : map.entrySet()) {
/* 361 */         this.keys[i] = entry.getKey();
/* 362 */         this.values[i] = entry.getValue();
/* 363 */         i++;
/*     */       }
/*     */     }
/*     */ 
/*     */     Object readResolve() {
/* 367 */       ImmutableMap.Builder builder = new ImmutableMap.Builder();
/* 368 */       return createMap(builder);
/*     */     }
/*     */     Object createMap(ImmutableMap.Builder<Object, Object> builder) {
/* 371 */       for (int i = 0; i < this.keys.length; i++) {
/* 372 */         builder.put(this.keys[i], this.values[i]);
/*     */       }
/* 374 */       return builder.build();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Builder<K, V>
/*     */   {
/* 159 */     final List<Map.Entry<K, V>> entries = Lists.newArrayList();
/*     */ 
/*     */     public Builder<K, V> put(K key, V value)
/*     */     {
/* 172 */       this.entries.add(ImmutableMap.entryOf(key, value));
/* 173 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/*     */     {
/* 183 */       for (Map.Entry entry : map.entrySet()) {
/* 184 */         put(entry.getKey(), entry.getValue());
/*     */       }
/* 186 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableMap<K, V> build()
/*     */     {
/* 198 */       return fromEntryList(this.entries);
/*     */     }
/*     */ 
/*     */     private static <K, V> ImmutableMap<K, V> fromEntryList(List<Map.Entry<K, V>> entries)
/*     */     {
/* 203 */       int size = entries.size();
/* 204 */       switch (size) {
/*     */       case 0:
/* 206 */         return ImmutableMap.of();
/*     */       case 1:
/* 208 */         return new SingletonImmutableMap((Map.Entry)Iterables.getOnlyElement(entries));
/*     */       }
/* 210 */       Map.Entry[] entryArray = (Map.Entry[])entries.toArray(new Map.Entry[entries.size()]);
/*     */ 
/* 212 */       return new RegularImmutableMap(entryArray);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableMap
 * JD-Core Version:    0.6.0
 */