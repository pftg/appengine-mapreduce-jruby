/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ public final class Presence
/*    */ {
/*    */   private final boolean isAvailable;
/*    */ 
/*    */   public Presence(boolean isAvailable)
/*    */   {
/* 15 */     this.isAvailable = isAvailable;
/*    */   }
/*    */ 
/*    */   public boolean isAvailable() {
/* 19 */     return this.isAvailable;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.Presence
 * JD-Core Version:    0.6.0
 */