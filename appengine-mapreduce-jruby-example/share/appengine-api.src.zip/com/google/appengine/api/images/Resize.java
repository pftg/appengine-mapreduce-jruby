/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ final class Resize extends Transform
/*    */ {
/*    */   private final int width;
/*    */   private final int height;
/*    */ 
/*    */   Resize(int width, int height)
/*    */   {
/* 25 */     if ((width > 4000) || (height > 4000))
/*    */     {
/* 27 */       throw new IllegalArgumentException("width and height must be <= 4000");
/*    */     }
/*    */ 
/* 30 */     if ((width < 0) || (height < 0)) {
/* 31 */       throw new IllegalArgumentException("width and height must be >= 0");
/*    */     }
/* 33 */     if ((width == 0) && (height == 0)) {
/* 34 */       throw new IllegalArgumentException("width and height must not both be == 0");
/*    */     }
/* 36 */     this.width = width;
/* 37 */     this.height = height;
/*    */   }
/*    */ 
/*    */   void apply(ImagesServicePb.ImagesTransformRequest request)
/*    */   {
/* 42 */     ImagesServicePb.Transform transform = request.addTransform();
/* 43 */     transform.setWidth(this.width);
/* 44 */     transform.setHeight(this.height);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.Resize
 * JD-Core Version:    0.6.0
 */