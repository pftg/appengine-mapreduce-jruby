/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.SortedSet;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public final class DiscreteRange<C extends Comparable> extends Range<C>
/*     */ {
/*     */   private final DiscreteType<C> typeDescriptor;
/*     */ 
/*     */   DiscreteRange(Cut<C> lowerBound, Cut<C> upperBound, DiscreteType<C> typeDescriptor)
/*     */   {
/*  55 */     super(lowerBound, upperBound);
/*  56 */     this.typeDescriptor = ((DiscreteType)Preconditions.checkNotNull(typeDescriptor));
/*     */   }
/*     */ 
/*     */   DiscreteRange<C> create(Cut<C> lower, Cut<C> upper) {
/*  60 */     return new DiscreteRange(lower, upper, this.typeDescriptor);
/*     */   }
/*     */ 
/*     */   public DiscreteRange<C> intersection(Range<C> other) {
/*  64 */     return (DiscreteRange)super.intersection(other);
/*     */   }
/*     */ 
/*     */   public DiscreteRange<C> span(Range<C> other) {
/*  68 */     return (DiscreteRange)super.span(other);
/*     */   }
/*     */ 
/*     */   public DiscreteRange<C> canonical()
/*     */   {
/* 103 */     Cut lower = this.lowerBound.canonical(this.typeDescriptor);
/* 104 */     Cut upper = this.upperBound.canonical(this.typeDescriptor);
/* 105 */     return (lower == this.lowerBound) && (upper == this.upperBound) ? this : create(lower, upper);
/*     */   }
/*     */ 
/*     */   public SortedSet<C> asSet()
/*     */   {
/* 135 */     DiscreteRange canonical = canonical();
/* 136 */     Preconditions.checkState(canonical.hasLowerBound(), "cannot view " + this + " as a Set because it has no least value");
/*     */ 
/* 138 */     return canonical.isEmpty() ? ImmutableSortedSet.of() : new DiscreteRangeAsSet(canonical);
/*     */   }
/*     */ 
/*     */   private C greatestValue()
/*     */   {
/*     */     try
/*     */     {
/* 145 */       return this.upperBound.greatestValueBelow(this.typeDescriptor); } catch (NoSuchElementException e) {
/*     */     }
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   private static int compareOrThrow(Comparable left, Comparable right)
/*     */   {
/* 277 */     return left.compareTo(right);
/*     */   }
/*     */ 
/*     */   private static final class DiscreteRangeAsSet<C extends Comparable> extends AbstractSet<C>
/*     */     implements SortedSet<C>
/*     */   {
/*     */     final DiscreteRange<C> range;
/*     */ 
/*     */     DiscreteRangeAsSet(DiscreteRange<C> range)
/*     */     {
/* 157 */       this.range = range;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 161 */       Comparable last = this.range.greatestValue();
/* 162 */       if (last == null) {
/* 163 */         return 2147483647;
/*     */       }
/* 165 */       long distance = this.range.typeDescriptor.distance(first(), last);
/* 166 */       if (distance >= 2147483647L) {
/* 167 */         return 2147483647;
/*     */       }
/* 169 */       return (int)distance + 1;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 173 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean contains(Object value) {
/* 177 */       if (value == null) {
/* 178 */         return false;
/*     */       }
/*     */       try
/*     */       {
/* 182 */         Comparable c = (Comparable)value;
/* 183 */         return this.range.contains(c); } catch (ClassCastException e) {
/*     */       }
/* 185 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection<?> values)
/*     */     {
/*     */       try
/*     */       {
/* 192 */         Collection cs = values;
/* 193 */         return this.range.containsAll(cs); } catch (ClassCastException e) {
/*     */       }
/* 195 */       return false;
/*     */     }
/*     */ 
/*     */     public Iterator<C> iterator()
/*     */     {
/* 200 */       return new UnmodifiableIterator() {
/* 201 */         C next = DiscreteRange.DiscreteRangeAsSet.this.first();
/* 202 */         final C last = DiscreteRange.DiscreteRangeAsSet.this.range.greatestValue();
/*     */ 
/*     */         public boolean hasNext() {
/* 205 */           return this.next != null;
/*     */         }
/*     */ 
/*     */         public C next() {
/* 209 */           Comparable result = this.next;
/* 210 */           if (result == null) {
/* 211 */             throw new NoSuchElementException();
/*     */           }
/* 213 */           this.next = (DiscreteRange.DiscreteRangeAsSet.equalsOrThrow(result, this.last) ? null : DiscreteRange.DiscreteRangeAsSet.this.range.typeDescriptor.next(result));
/*     */ 
/* 215 */           return result;
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     static boolean equalsOrThrow(Comparable left, @Nullable Comparable right) {
/* 222 */       return (right != null) && (DiscreteRange.access$200(left, right) == 0);
/*     */     }
/*     */ 
/*     */     public Comparator<? super C> comparator() {
/* 226 */       return Ordering.natural();
/*     */     }
/*     */ 
/*     */     public SortedSet<C> subSet(C fromElement, C toElement) {
/* 230 */       Preconditions.checkArgument(DiscreteRange.access$200(fromElement, toElement) <= 0);
/* 231 */       Cut lower = (Cut)Ordering.natural().max(this.range.lowerBound, new Cut.BelowValue(fromElement));
/*     */ 
/* 233 */       Cut upper = (Cut)Ordering.natural().min(this.range.upperBound, new Cut.BelowValue(toElement));
/*     */ 
/* 235 */       return createSet(lower, upper);
/*     */     }
/*     */ 
/*     */     public SortedSet<C> headSet(C toElement) {
/* 239 */       Cut upper = (Cut)Ordering.natural().min(this.range.upperBound, new Cut.BelowValue(toElement));
/*     */ 
/* 241 */       return createSet(this.range.lowerBound, upper);
/*     */     }
/*     */ 
/*     */     public SortedSet<C> tailSet(C fromElement) {
/* 245 */       Cut lower = (Cut)Ordering.natural().max(this.range.lowerBound, new Cut.BelowValue(fromElement));
/*     */ 
/* 247 */       return createSet(lower, this.range.upperBound);
/*     */     }
/*     */ 
/*     */     private SortedSet<C> createSet(Cut<C> lower, Cut<C> upper) {
/* 251 */       if (lower.compareTo(upper) >= 0) {
/* 252 */         return ImmutableSortedSet.of();
/*     */       }
/* 254 */       return new DiscreteRangeAsSet(this.range.create(lower, upper));
/*     */     }
/*     */ 
/*     */     public C first() {
/* 258 */       return this.range.lowerBound.endpoint();
/*     */     }
/*     */ 
/*     */     public C last() {
/* 262 */       Comparable last = this.range.greatestValue();
/* 263 */       if (last == null) {
/* 264 */         throw new IllegalStateException();
/*     */       }
/* 266 */       return last;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 271 */       return "{" + size() + " values in the range " + this.range + "}";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.DiscreteRange
 * JD-Core Version:    0.6.0
 */