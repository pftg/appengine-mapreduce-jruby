/*    */ package javax.mail;
/*    */ 
/*    */ public class Header
/*    */ {
/*    */   protected String name;
/*    */   protected String value;
/*    */ 
/*    */   public Header(String name, String value)
/*    */   {
/* 44 */     this.name = name;
/* 45 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 54 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 63 */     return this.value;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Header
 * JD-Core Version:    0.6.0
 */