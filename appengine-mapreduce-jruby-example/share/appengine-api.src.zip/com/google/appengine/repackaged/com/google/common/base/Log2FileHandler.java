/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Formatter;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.LogRecord;
/*     */ 
/*     */ @Deprecated
/*     */ @GoogleInternal
/*     */ public final class Log2FileHandler extends Handler
/*     */   implements ConfigurableHandler
/*     */ {
/*     */   static final String LIMIT_PROP = "limit";
/*     */   static final String BASENAME_PROP = "baseName";
/*     */   static final String QUALIFY_BASENAME_PROP = "qualifyBaseName";
/*     */   static final String RECORD_TS_FORMAT_PROP = "recordTsFormat";
/*     */   static final String FILENAME_TS_FORMAT_PROP = "fileNameTsFormat";
/*     */   static final String LINKNAME_PROP = "linkName";
/*     */   static final String EXTENSION_PROP = "extension";
/*     */   static final String FORMATTER_PROP = "formatter";
/*     */   private static final long MB = 1048576L;
/*     */   private static final long DEFAULT_ROTATION_UNIT_SIZE_MB = 1800L;
/*     */   private static final String DEFAULT_BASE_FILE_NAME = "/export/hda3/tmp/Log2Trace";
/*     */   private static final String DEFAULT_RECORD_TS_FORMAT_STR = "yyMMdd HH:mm:ss ";
/*     */   private static final String DEFAULT_FILENAME_TS_FORMAT_STR = "-yyyy_MM_dd_HH_mm_ss";
/*     */   private String baseFileName;
/*     */   private boolean qualifyBaseFileName;
/*     */   private String linkName;
/*     */   private String extension;
/*     */   private long rotateSize;
/*     */   private DateFormat recordTsFormat;
/*     */   private DateFormat fileNameTsFormat;
/*     */   private Writer logFileWriter;
/*     */   private String formatterClass;
/* 441 */   private static String LOG_DIR_ENV = "GOOGLE_LOG_DIR";
/* 442 */   private static String LOG_DIR_PROP = "google.logDir";
/* 443 */   private static String BACKUP_LOG_DIR = "/export/hda3/tmp";
/*     */ 
/*     */   Log2FileHandler(String baseFileName, String linkName, String extension, DateFormat recordTsFormat, DateFormat fileNameTsFormat, long rotateSize)
/*     */   {
/* 151 */     this.baseFileName = baseFileName;
/* 152 */     this.qualifyBaseFileName = true;
/* 153 */     this.linkName = linkName;
/* 154 */     this.extension = extension;
/* 155 */     this.recordTsFormat = recordTsFormat;
/* 156 */     this.fileNameTsFormat = fileNameTsFormat;
/* 157 */     this.rotateSize = rotateSize;
/* 158 */     this.logFileWriter = null;
/*     */ 
/* 160 */     this.formatterClass = "com.google.appengine.repackaged.com.google.common.base.Log2Formatter";
/* 161 */     setFormatter(new Log2Formatter(recordTsFormat));
/*     */   }
/*     */ 
/*     */   public Log2FileHandler(String fileName)
/*     */   {
/* 170 */     this(fileName, fileName, null, new SimpleDateFormat("yyMMdd HH:mm:ss "), new SimpleDateFormat("-yyyy_MM_dd_HH_mm_ss"), getRotationUnitSize());
/*     */   }
/*     */ 
/*     */   public Log2FileHandler()
/*     */   {
/* 184 */     this("/export/hda3/tmp/Log2Trace", null, null, new SimpleDateFormat("yyMMdd HH:mm:ss "), new SimpleDateFormat("-yyyy_MM_dd_HH_mm_ss"), getRotationUnitSize());
/*     */   }
/*     */ 
/*     */   public Handler configure(String instanceName, Properties configProps)
/*     */   {
/* 202 */     close();
/* 203 */     this.baseFileName = configProps.getProperty(qualifyPropName(instanceName, "baseName"), "/export/hda3/tmp/Log2Trace");
/*     */ 
/* 206 */     this.qualifyBaseFileName = Boolean.valueOf(configProps.getProperty(qualifyPropName(instanceName, "qualifyBaseName"), "true")).booleanValue();
/*     */ 
/* 211 */     this.rotateSize = Long.parseLong(configProps.getProperty(qualifyPropName(instanceName, "limit"), "0"));
/*     */ 
/* 215 */     if (this.rotateSize <= 0L) {
/* 216 */       this.rotateSize = getRotationUnitSize();
/*     */     }
/*     */ 
/* 219 */     String recordTsFormatStr = configProps.getProperty(qualifyPropName(instanceName, "recordTsFormat"), "yyMMdd HH:mm:ss ");
/*     */ 
/* 224 */     this.recordTsFormat = new SimpleDateFormat(recordTsFormatStr);
/*     */ 
/* 226 */     String fileNameTsFormatStr = configProps.getProperty(qualifyPropName(instanceName, "fileNameTsFormat"), "-yyyy_MM_dd_HH_mm_ss");
/*     */ 
/* 231 */     this.fileNameTsFormat = new SimpleDateFormat(fileNameTsFormatStr);
/*     */ 
/* 233 */     this.linkName = configProps.getProperty(qualifyPropName(instanceName, "linkName"), null);
/*     */ 
/* 237 */     this.extension = configProps.getProperty(qualifyPropName(instanceName, "extension"), null);
/*     */ 
/* 241 */     this.formatterClass = configProps.getProperty(qualifyPropName(instanceName, "formatter"), "");
/*     */ 
/* 245 */     if (!this.formatterClass.equals("")) {
/* 246 */       Formatter fmt = null;
/*     */       try {
/* 248 */         if (this.formatterClass.equals(Log2Formatter.class.getName()))
/*     */         {
/* 256 */           fmt = new Log2Formatter(this.recordTsFormat);
/*     */         }
/* 258 */         else fmt = (Formatter)Class.forName(this.formatterClass).newInstance(); 
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/* 261 */         System.err.println("Error loading formatter class specified by: " + qualifyPropName(instanceName, "formatter") + "value: " + this.formatterClass);
/*     */       }
/*     */       catch (InstantiationException e)
/*     */       {
/* 266 */         System.err.println("Error instantiating formatter class specified by: " + qualifyPropName(instanceName, "formatter") + "value: " + this.formatterClass);
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 271 */         System.err.println("Error instantiating formatter class specified by: " + qualifyPropName(instanceName, "formatter") + "value: " + this.formatterClass);
/*     */       }
/*     */ 
/* 276 */       if (fmt != null)
/* 277 */         setFormatter(fmt);
/*     */     }
/*     */     else
/*     */     {
/* 281 */       setFormatter(new Log2Formatter(this.recordTsFormat));
/*     */     }
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */   private static long getRotationUnitSize()
/*     */   {
/* 294 */     String maxLogSizeMbStr = System.getenv("GOOGLE_MAX_LOG_MB");
/* 295 */     if (maxLogSizeMbStr != null) {
/*     */       try {
/* 297 */         long maxLogSizeMb = Long.parseLong(maxLogSizeMbStr);
/* 298 */         if (maxLogSizeMb > 0L)
/* 299 */           return maxLogSizeMb * 1048576L;
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/*     */       }
/*     */     }
/* 305 */     return 1887436800L;
/*     */   }
/*     */ 
/*     */   public void publish(LogRecord rec) {
/* 309 */     String logMsg = getFormatter().format(rec);
/* 310 */     if (this.logFileWriter == null)
/* 311 */       openWriter();
/*     */     try
/*     */     {
/* 314 */       this.logFileWriter.write(logMsg);
/* 315 */       this.logFileWriter.flush();
/*     */     } catch (IOException e) {
/* 317 */       System.err.println("Log2FileHandler#publish : error in writing to log!\n Exception thrown: " + e.getMessage() + "\nlog entry: " + logMsg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/* 326 */     if (this.logFileWriter != null)
/*     */       try {
/* 328 */         this.logFileWriter.flush();
/*     */       } catch (IOException e) {
/* 330 */         System.err.println("Log2FileHandler#flush : error in flushing log!\n Exception thrown: " + e.getMessage());
/*     */       }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 338 */     if (this.logFileWriter != null)
/*     */       try {
/* 340 */         this.logFileWriter.close();
/* 341 */         this.logFileWriter = null;
/*     */       } catch (IOException e) {
/* 343 */         System.err.println("Log2FileHandler#flush : error in closing log!\n Exception thrown: " + e.getMessage());
/*     */ 
/* 346 */         this.logFileWriter = null;
/*     */       }
/*     */   }
/*     */ 
/*     */   private String qualifyPropName(String instanceName, String propName)
/*     */   {
/* 353 */     return instanceName + "." + propName;
/*     */   }
/*     */ 
/*     */   private void openWriter()
/*     */   {
/*     */     try
/*     */     {
/* 362 */       String qualifiedFileName = this.baseFileName;
/* 363 */       String qualifiedLinkName = this.linkName;
/*     */ 
/* 365 */       if ((this.qualifyBaseFileName) && (!new File(this.baseFileName).isAbsolute())) {
/* 366 */         qualifiedFileName = getLoggingDirectory() + File.separator + this.baseFileName;
/*     */       }
/*     */ 
/* 370 */       if ((this.qualifyBaseFileName) && (!new File(this.linkName).isAbsolute())) {
/* 371 */         qualifiedLinkName = getLoggingDirectory() + File.separator + this.linkName;
/*     */       }
/*     */ 
/* 374 */       RotatingLogStream rls = new RotatingLogStream(qualifiedFileName, qualifiedLinkName, this.extension, this.fileNameTsFormat);
/*     */ 
/* 379 */       rls.setRotateSize(this.rotateSize);
/* 380 */       this.logFileWriter = new BufferedWriter(new OutputStreamWriter(rls));
/*     */     } catch (IOException e) {
/* 382 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean directoryExists(String dir) {
/* 387 */     File f = new File(dir);
/* 388 */     return (f.exists()) && (f.isDirectory());
/*     */   }
/*     */ 
/*     */   private static String getLoggingDirectory()
/*     */   {
/* 395 */     String dir = System.getenv(LOG_DIR_ENV);
/* 396 */     if ((dir != null) && (directoryExists(dir))) {
/* 397 */       return dir;
/*     */     }
/* 399 */     dir = System.getProperty(LOG_DIR_PROP);
/* 400 */     if ((dir != null) && (directoryExists(dir))) {
/* 401 */       return dir;
/*     */     }
/* 403 */     if (directoryExists(BACKUP_LOG_DIR)) {
/* 404 */       return dir;
/*     */     }
/* 406 */     return getTempDirectory();
/*     */   }
/*     */ 
/*     */   private static String getTempDirectory()
/*     */   {
/* 413 */     String tmpDir = System.getProperty("java.io.tmpdir");
/* 414 */     if (tmpDir == null) {
/* 415 */       tmpDir = System.getProperty("user.home");
/*     */     }
/* 417 */     return tmpDir;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Log2FileHandler
 * JD-Core Version:    0.6.0
 */