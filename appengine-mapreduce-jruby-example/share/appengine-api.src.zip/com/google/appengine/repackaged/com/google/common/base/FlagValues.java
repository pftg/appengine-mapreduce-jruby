/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ @GoogleInternal
/*    */ public class FlagValues
/*    */ {
/*    */   private final Map<String, String> values;
/*    */ 
/*    */   public FlagValues()
/*    */   {
/* 24 */     this.values = new HashMap();
/*    */   }
/*    */ 
/*    */   public void addFlag(String flag, String value)
/*    */   {
/* 35 */     this.values.put(flag, value);
/*    */   }
/*    */ 
/*    */   public String getFlagValue(String flag)
/*    */   {
/* 45 */     return (String)this.values.get(flag);
/*    */   }
/*    */ 
/*    */   public String[] getAllFlagsAsStringArray()
/*    */   {
/* 58 */     ArrayList toReturn = new ArrayList();
/* 59 */     for (String flagName : this.values.keySet()) {
/* 60 */       String flagValue = (String)this.values.get(flagName);
/* 61 */       toReturn.add("--" + flagName + ("".equals(flagValue) ? "" : new StringBuilder().append("=").append(flagValue).toString()));
/*    */     }
/* 63 */     return (String[])toReturn.toArray(new String[0]);
/*    */   }
/*    */ 
/*    */   public String getAllFlagsAsString()
/*    */   {
/* 73 */     String[] flagsArray = getAllFlagsAsStringArray();
/* 74 */     String toReturn = "";
/* 75 */     for (int i = 0; i < flagsArray.length; i++) {
/* 76 */       toReturn = toReturn + " " + flagsArray[i];
/*    */     }
/* 78 */     return toReturn;
/*    */   }
/*    */ 
/*    */   public void addAll(FlagValues toAdd)
/*    */   {
/* 89 */     this.values.putAll(toAdd.values);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.FlagValues
 * JD-Core Version:    0.6.0
 */