/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public enum RegionCode
/*     */ {
/*  97 */   AD, 
/*  98 */   AE, 
/*  99 */   AF, 
/* 100 */   AG, 
/* 101 */   AI, 
/* 102 */   AL, 
/* 103 */   AM, 
/* 104 */   AN, 
/* 105 */   AO, 
/* 106 */   AQ, 
/* 107 */   AR, 
/* 108 */   AS, 
/* 109 */   AT, 
/* 110 */   AU, 
/* 111 */   AW, 
/* 112 */   AX, 
/* 113 */   AZ, 
/* 114 */   BA, 
/* 115 */   BB, 
/* 116 */   BD, 
/* 117 */   BE, 
/* 118 */   BF, 
/* 119 */   BG, 
/* 120 */   BH, 
/* 121 */   BI, 
/* 122 */   BJ, 
/* 123 */   BL, 
/* 124 */   BM, 
/* 125 */   BN, 
/* 126 */   BO, 
/* 127 */   BR, 
/* 128 */   BS, 
/* 129 */   BT, 
/*     */ 
/* 131 */   BU, 
/* 132 */   BV, 
/* 133 */   BW, 
/* 134 */   BY, 
/* 135 */   BZ, 
/* 136 */   CA, 
/* 137 */   CC, 
/* 138 */   CD, 
/* 139 */   CF, 
/* 140 */   CG, 
/* 141 */   CH, 
/* 142 */   CI, 
/* 143 */   CK, 
/* 144 */   CL, 
/* 145 */   CM, 
/* 146 */   CN, 
/* 147 */   CO, 
/* 148 */   CR, 
/*     */ 
/* 151 */   CS, 
/* 152 */   CU, 
/* 153 */   CV, 
/* 154 */   CX, 
/* 155 */   CY, 
/* 156 */   CZ, 
/*     */ 
/* 158 */   DD, 
/* 159 */   DE, 
/* 160 */   DJ, 
/* 161 */   DK, 
/* 162 */   DM, 
/* 163 */   DO, 
/* 164 */   DZ, 
/* 165 */   EC, 
/* 166 */   EE, 
/* 167 */   EG, 
/* 168 */   EH, 
/* 169 */   ER, 
/* 170 */   ES, 
/* 171 */   ET, 
/* 172 */   FI, 
/* 173 */   FJ, 
/* 174 */   FK, 
/* 175 */   FM, 
/* 176 */   FO, 
/* 177 */   FR, 
/*     */ 
/* 179 */   FX, 
/* 180 */   GA, 
/* 181 */   GB, 
/* 182 */   GD, 
/* 183 */   GE, 
/* 184 */   GF, 
/* 185 */   GG, 
/* 186 */   GH, 
/* 187 */   GI, 
/* 188 */   GL, 
/* 189 */   GM, 
/* 190 */   GN, 
/* 191 */   GP, 
/* 192 */   GQ, 
/* 193 */   GR, 
/* 194 */   GS, 
/* 195 */   GT, 
/* 196 */   GU, 
/* 197 */   GW, 
/* 198 */   GY, 
/* 199 */   HK, 
/* 200 */   HM, 
/* 201 */   HN, 
/* 202 */   HR, 
/* 203 */   HT, 
/* 204 */   HU, 
/* 205 */   ID, 
/* 206 */   IE, 
/* 207 */   IL, 
/* 208 */   IM, 
/* 209 */   IN, 
/* 210 */   IO, 
/* 211 */   IQ, 
/* 212 */   IR, 
/* 213 */   IS, 
/* 214 */   IT, 
/* 215 */   JE, 
/* 216 */   JM, 
/* 217 */   JO, 
/* 218 */   JP, 
/* 219 */   KE, 
/* 220 */   KG, 
/* 221 */   KH, 
/* 222 */   KI, 
/* 223 */   KM, 
/* 224 */   KN, 
/* 225 */   KP, 
/* 226 */   KR, 
/* 227 */   KW, 
/* 228 */   KY, 
/* 229 */   KZ, 
/* 230 */   LA, 
/* 231 */   LB, 
/* 232 */   LC, 
/* 233 */   LI, 
/* 234 */   LK, 
/* 235 */   LR, 
/* 236 */   LS, 
/* 237 */   LT, 
/* 238 */   LU, 
/* 239 */   LV, 
/* 240 */   LY, 
/* 241 */   MA, 
/* 242 */   MC, 
/* 243 */   MD, 
/* 244 */   ME, 
/* 245 */   MF, 
/* 246 */   MG, 
/* 247 */   MH, 
/* 248 */   MK, 
/* 249 */   ML, 
/* 250 */   MM, 
/* 251 */   MN, 
/* 252 */   MO, 
/* 253 */   MP, 
/* 254 */   MQ, 
/* 255 */   MR, 
/* 256 */   MS, 
/* 257 */   MT, 
/* 258 */   MU, 
/* 259 */   MV, 
/* 260 */   MW, 
/* 261 */   MX, 
/* 262 */   MY, 
/* 263 */   MZ, 
/* 264 */   NA, 
/* 265 */   NC, 
/* 266 */   NE, 
/* 267 */   NF, 
/* 268 */   NG, 
/* 269 */   NI, 
/* 270 */   NL, 
/* 271 */   NO, 
/* 272 */   NP, 
/* 273 */   NR, 
/*     */ 
/* 276 */   NT, 
/* 277 */   NU, 
/* 278 */   NZ, 
/* 279 */   OM, 
/* 280 */   PA, 
/* 281 */   PE, 
/* 282 */   PF, 
/* 283 */   PG, 
/* 284 */   PH, 
/* 285 */   PK, 
/* 286 */   PL, 
/* 287 */   PM, 
/* 288 */   PN, 
/* 289 */   PR, 
/* 290 */   PS, 
/* 291 */   PT, 
/* 292 */   PW, 
/* 293 */   PY, 
/* 294 */   QA, 
/* 295 */   QO, 
/* 296 */   QU, 
/* 297 */   RE, 
/* 298 */   RO, 
/* 299 */   RS, 
/* 300 */   RU, 
/* 301 */   RW, 
/* 302 */   SA, 
/* 303 */   SB, 
/* 304 */   SC, 
/* 305 */   SD, 
/* 306 */   SE, 
/* 307 */   SG, 
/* 308 */   SH, 
/* 309 */   SI, 
/* 310 */   SJ, 
/* 311 */   SK, 
/* 312 */   SL, 
/* 313 */   SM, 
/* 314 */   SN, 
/* 315 */   SO, 
/* 316 */   SR, 
/* 317 */   ST, 
/*     */ 
/* 324 */   SU, 
/* 325 */   SV, 
/* 326 */   SY, 
/* 327 */   SZ, 
/* 328 */   TC, 
/* 329 */   TD, 
/* 330 */   TF, 
/* 331 */   TG, 
/* 332 */   TH, 
/* 333 */   TJ, 
/* 334 */   TK, 
/* 335 */   TL, 
/* 336 */   TM, 
/* 337 */   TN, 
/* 338 */   TO, 
/*     */ 
/* 340 */   TP, 
/* 341 */   TR, 
/* 342 */   TT, 
/* 343 */   TV, 
/* 344 */   TW, 
/* 345 */   TZ, 
/* 346 */   UA, 
/* 347 */   UG, 
/* 348 */   UM, 
/* 349 */   US, 
/* 350 */   UY, 
/* 351 */   UZ, 
/* 352 */   VA, 
/* 353 */   VC, 
/* 354 */   VE, 
/* 355 */   VG, 
/* 356 */   VI, 
/* 357 */   VN, 
/* 358 */   VU, 
/* 359 */   WF, 
/* 360 */   WS, 
/*     */ 
/* 362 */   YD, 
/* 363 */   YE, 
/* 364 */   YT, 
/*     */ 
/* 367 */   YU, 
/* 368 */   ZA, 
/* 369 */   ZM, 
/*     */ 
/* 371 */   ZR, 
/* 372 */   ZW, 
/* 373 */   ZZ, 
/*     */ 
/* 375 */   UN001, 
/* 376 */   UN002, 
/* 377 */   UN003, 
/* 378 */   UN005, 
/* 379 */   UN009, 
/* 380 */   UN011, 
/* 381 */   UN013, 
/* 382 */   UN014, 
/* 383 */   UN015, 
/* 384 */   UN017, 
/* 385 */   UN018, 
/* 386 */   UN019, 
/* 387 */   UN021, 
/* 388 */   UN029, 
/* 389 */   UN030, 
/* 390 */   UN034, 
/* 391 */   UN035, 
/* 392 */   UN039, 
/* 393 */   UN053, 
/* 394 */   UN054, 
/* 395 */   UN057, 
/* 396 */   UN061, 
/* 397 */   UN142, 
/* 398 */   UN143, 
/* 399 */   UN145, 
/* 400 */   UN150, 
/* 401 */   UN151, 
/* 402 */   UN154, 
/* 403 */   UN155, 
/* 404 */   UN419;
/*     */ 
/*     */   private static final Set<RegionCode> NON_CANONICAL;
/*     */   private final String stringForm;
/*     */ 
/*     */   @Deprecated
/*     */   private void removeWhenCompilerFixed()
/*     */   {
/*     */   }
/*     */ 
/*     */   private RegionCode()
/*     */   {
/* 449 */     this.stringForm = name().replaceFirst("^UN", "");
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 459 */     return this.stringForm;
/*     */   }
/*     */ 
/*     */   public static RegionCode forString(String cldrCode)
/*     */   {
/* 470 */     if (cldrCode.matches("[A-Z]{2}")) {
/* 471 */       return valueOf(cldrCode);
/*     */     }
/* 473 */     if (cldrCode.matches("[0-9]{3}")) {
/*     */       try {
/* 475 */         return valueOf("UN" + cldrCode);
/*     */       }
/*     */       catch (IllegalArgumentException ignored)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 484 */     throw new IllegalArgumentException("'" + cldrCode + "' is not a valid CLDR region code.");
/*     */   }
/*     */ 
/*     */   public static RegionCode getUnknown()
/*     */   {
/* 496 */     return ZZ;
/*     */   }
/*     */ 
/*     */   public boolean isCanonical()
/*     */   {
/* 505 */     return !NON_CANONICAL.contains(this);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 438 */     Set tempSet = new HashSet();
/* 439 */     Collections.addAll(tempSet, new RegionCode[] { BU, CS, DD, FX, NT, SU, TP, YD, YU, ZR });
/*     */ 
/* 443 */     NON_CANONICAL = Collections.unmodifiableSet(tempSet);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.RegionCode
 * JD-Core Version:    0.6.0
 */