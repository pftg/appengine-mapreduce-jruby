/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import B;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.ImmutableList;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Interner;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Interners;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Iterators;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Lists;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public final class ProtocolSupport
/*     */ {
/*  42 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*  43 */   public static final int[] EMPTY_INT_ARRAY = new int[0];
/*  44 */   public static final long[] EMPTY_LONG_ARRAY = new long[0];
/*  45 */   public static final float[] EMPTY_FLOAT_ARRAY = new float[0];
/*  46 */   public static final double[] EMPTY_DOUBLE_ARRAY = new double[0];
/*  47 */   public static final boolean[] EMPTY_BOOLEAN_ARRAY = new boolean[0];
/*     */   public static final String UNINTERPRETED_TAGS_FIELD = "uninterpreted";
/*  55 */   private static final Interner<String> STRING_INTERNER = Interners.newWeakInterner();
/*     */   private static final int ENSURE_CAPACITY_EXTRA = 10;
/*     */ 
/*     */   public static String internString(String s)
/*     */   {
/*  66 */     Preconditions.checkNotNull(s);
/*  67 */     return (String)STRING_INTERNER.intern(s);
/*     */   }
/*     */ 
/*     */   public static <T> T unsupportedOperation() {
/*  71 */     throw new UnsupportedOperationException("Modifying immutable object");
/*     */   }
/*     */ 
/*     */   public static int hashCode(boolean b) {
/*  75 */     return b ? 1 : 0;
/*     */   }
/*     */ 
/*     */   public static int hashCode(int i) {
/*  79 */     return i;
/*     */   }
/*     */ 
/*     */   public static int hashCode(long l) {
/*  83 */     return (int)(l + (l >>> 32));
/*     */   }
/*     */ 
/*     */   public static int hashCode(float f) {
/*  87 */     return Float.floatToIntBits(f);
/*     */   }
/*     */ 
/*     */   public static int hashCode(double d) {
/*  91 */     long l = Double.doubleToLongBits(d);
/*  92 */     return (int)(l + (l >>> 32));
/*     */   }
/*     */ 
/*     */   public static <T> T[] growArray(T[] array)
/*     */   {
/* 100 */     int newLength = Math.max(4, array.length * 2);
/* 101 */     Class newType = array.getClass();
/* 102 */     Object[] copy = newType == [Ljava.lang.Object.class ? (Object[])new Object[newLength] : (Object[])(Object[])Array.newInstance(newType.getComponentType(), newLength);
/*     */ 
/* 105 */     System.arraycopy(array, 0, copy, 0, Math.min(array.length, newLength));
/*     */ 
/* 107 */     Object[] arr = copy;
/* 108 */     return (Object[])arr;
/*     */   }
/*     */ 
/*     */   public static boolean[] growArray(boolean[] array) {
/* 112 */     int newLength = Math.max(4, array.length * 2);
/* 113 */     boolean[] copy = new boolean[newLength];
/* 114 */     System.arraycopy(array, 0, copy, 0, Math.min(array.length, newLength));
/*     */ 
/* 116 */     return copy;
/*     */   }
/*     */ 
/*     */   public static int[] growArray(int[] array) {
/* 120 */     int newLength = Math.max(4, array.length * 2);
/* 121 */     int[] copy = new int[newLength];
/* 122 */     System.arraycopy(array, 0, copy, 0, Math.min(array.length, newLength));
/*     */ 
/* 124 */     return copy;
/*     */   }
/*     */ 
/*     */   public static long[] growArray(long[] array) {
/* 128 */     int newLength = Math.max(4, array.length * 2);
/* 129 */     long[] copy = new long[newLength];
/* 130 */     System.arraycopy(array, 0, copy, 0, Math.min(array.length, newLength));
/*     */ 
/* 132 */     return copy;
/*     */   }
/*     */ 
/*     */   public static float[] growArray(float[] array) {
/* 136 */     int newLength = Math.max(4, array.length * 2);
/* 137 */     float[] copy = new float[newLength];
/* 138 */     System.arraycopy(array, 0, copy, 0, Math.min(array.length, newLength));
/*     */ 
/* 140 */     return copy;
/*     */   }
/*     */ 
/*     */   public static double[] growArray(double[] array) {
/* 144 */     int newLength = Math.max(4, array.length * 2);
/* 145 */     double[] copy = new double[newLength];
/* 146 */     System.arraycopy(array, 0, copy, 0, Math.min(array.length, newLength));
/*     */ 
/* 148 */     return copy;
/*     */   }
/*     */ 
/*     */   public static boolean[] ensureCapacity(boolean[] array, int size)
/*     */   {
/* 169 */     if (size > array.length) {
/* 170 */       return Arrays.copyOf(array, size + 10);
/*     */     }
/* 172 */     return array;
/*     */   }
/*     */ 
/*     */   public static int[] ensureCapacity(int[] array, int size)
/*     */   {
/* 188 */     if (size > array.length) {
/* 189 */       return Arrays.copyOf(array, size + 10);
/*     */     }
/* 191 */     return array;
/*     */   }
/*     */ 
/*     */   public static long[] ensureCapacity(long[] array, int size)
/*     */   {
/* 207 */     if (size > array.length) {
/* 208 */       return Arrays.copyOf(array, size + 10);
/*     */     }
/* 210 */     return array;
/*     */   }
/*     */ 
/*     */   public static float[] ensureCapacity(float[] array, int size)
/*     */   {
/* 226 */     if (size > array.length) {
/* 227 */       return Arrays.copyOf(array, size + 10);
/*     */     }
/* 229 */     return array;
/*     */   }
/*     */ 
/*     */   public static double[] ensureCapacity(double[] array, int size)
/*     */   {
/* 245 */     if (size > array.length) {
/* 246 */       return Arrays.copyOf(array, size + 10);
/*     */     }
/* 248 */     return array;
/*     */   }
/*     */ 
/*     */   public static List<Integer> asList(int[] array, int start, int end)
/*     */   {
/* 263 */     return new AbstractList(end, start, array) {
/* 264 */       private int listSize = this.val$end - this.val$start;
/*     */ 
/* 265 */       public int size() { return this.listSize; } 
/*     */       public Integer get(int i) {
/* 267 */         if ((i < 0) || (i >= this.listSize)) {
/* 268 */           throw new ArrayIndexOutOfBoundsException();
/*     */         }
/* 270 */         return Integer.valueOf(this.val$array[(i + this.val$start)]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static List<Long> asList(long[] array, int start, int end)
/*     */   {
/* 287 */     return new AbstractList(end, start, array) {
/* 288 */       private int listSize = this.val$end - this.val$start;
/*     */ 
/* 289 */       public int size() { return this.listSize; } 
/*     */       public Long get(int i) {
/* 291 */         if ((i < 0) || (i >= this.listSize)) {
/* 292 */           throw new ArrayIndexOutOfBoundsException();
/*     */         }
/* 294 */         return Long.valueOf(this.val$array[(i + this.val$start)]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static List<Float> asList(float[] array, int start, int end)
/*     */   {
/* 311 */     return new AbstractList(end, start, array) {
/* 312 */       private int listSize = this.val$end - this.val$start;
/*     */ 
/* 313 */       public int size() { return this.listSize; } 
/*     */       public Float get(int i) {
/* 315 */         if ((i < 0) || (i >= this.listSize)) {
/* 316 */           throw new ArrayIndexOutOfBoundsException();
/*     */         }
/* 318 */         return Float.valueOf(this.val$array[(i + this.val$start)]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static List<Double> asList(double[] array, int start, int end)
/*     */   {
/* 335 */     return new AbstractList(end, start, array) {
/* 336 */       private int listSize = this.val$end - this.val$start;
/*     */ 
/* 337 */       public int size() { return this.listSize; } 
/*     */       public Double get(int i) {
/* 339 */         if ((i < 0) || (i >= this.listSize)) {
/* 340 */           throw new ArrayIndexOutOfBoundsException();
/*     */         }
/* 342 */         return Double.valueOf(this.val$array[(i + this.val$start)]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static List<Boolean> asList(boolean[] array, int start, int end)
/*     */   {
/* 358 */     return new AbstractList(end, start, array) {
/* 359 */       private int listSize = this.val$end - this.val$start;
/*     */ 
/* 360 */       public int size() { return this.listSize; } 
/*     */       public Boolean get(int i) {
/* 362 */         if ((i < 0) || (i >= this.listSize)) {
/* 363 */           throw new ArrayIndexOutOfBoundsException();
/*     */         }
/* 365 */         return Boolean.valueOf(this.val$array[(i + this.val$start)]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static Iterator<String> byteArrayToUnicodeIterator(List<byte[]> data)
/*     */   {
/* 378 */     return ByteArrayToUnicodeFunction.getInstance().asList(data).iterator();
/*     */   }
/*     */ 
/*     */   public static Iterator<String> byteArrayToUnicodeIterator(List<byte[]> data, Charset cs)
/*     */   {
/* 391 */     return ByteArrayToUnicodeFunction.getInstance(cs).asList(data).iterator();
/*     */   }
/*     */ 
/*     */   public static <T> Iterator<T> emptyIterator()
/*     */   {
/* 402 */     return Iterators.emptyIterator();
/*     */   }
/*     */ 
/*     */   public static List<String> byteArrayToUnicodeList(List<byte[]> data)
/*     */   {
/* 413 */     return ByteArrayToUnicodeFunction.getInstance().asList(data);
/*     */   }
/*     */ 
/*     */   public static List<String> byteArrayToUnicodeList(List<byte[]> data, Charset cs)
/*     */   {
/* 426 */     return ByteArrayToUnicodeFunction.getInstance(cs).asList(data);
/*     */   }
/*     */ 
/*     */   public static byte[] toBytes(String str, Charset charset)
/*     */   {
/*     */     try
/*     */     {
/* 471 */       return str != null ? str.getBytes(charset.name()) : null; } catch (UnsupportedEncodingException e) {
/*     */     }
/* 473 */     throw new RuntimeException("Charset " + charset + " not supported by JVM: ", e);
/*     */   }
/*     */ 
/*     */   public static byte[] toBytesUtf8(String str)
/*     */   {
/*     */     try
/*     */     {
/* 480 */       return str != null ? str.getBytes("UTF-8") : null;
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 483 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   public static String toString(byte[] data, Charset charset)
/*     */   {
/*     */     try {
/* 489 */       return data != null ? new String(data, charset.name()) : null; } catch (UnsupportedEncodingException e) {
/*     */     }
/* 491 */     throw new RuntimeException("Charset " + charset + " not supported by JVM: ", e);
/*     */   }
/*     */ 
/*     */   public static String toStringUtf8(byte[] data)
/*     */   {
/* 503 */     return toStringUtf8(data, 0, data.length);
/*     */   }
/*     */ 
/*     */   public static String toStringUtf8(byte[] data, int offset, int length)
/*     */   {
/*     */     try
/*     */     {
/* 516 */       return data != null ? new String(data, offset, length, "UTF-8") : null;
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 519 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   public static <T extends ProtocolMessage> T newInstance(Class<T> clazz)
/*     */   {
/*     */     try
/*     */     {
/* 531 */       return (ProtocolMessage)clazz.newInstance();
/*     */     } catch (InstantiationException e) {
/* 533 */       if (clazz == ProtocolMessage.class) {
/* 534 */         throw new IllegalArgumentException("ProtocolMessage.class cannot be instantiated");
/*     */       }
/*     */ 
/* 537 */       throw new AssertionError("Protocol messages should always be instantiable");
/*     */     }
/*     */     catch (IllegalAccessException e) {
/*     */     }
/* 541 */     throw new AssertionError("Protocol messages constructors should always be public");
/*     */   }
/*     */ 
/*     */   public static UninterpretedTags getUninterpreted(ProtocolMessage pb)
/*     */   {
/* 554 */     if (pb == null) {
/* 555 */       return null;
/*     */     }
/*     */ 
/* 558 */     Class clazz = pb.getClass();
/*     */     try {
/* 560 */       Field utagsField = clazz.getDeclaredField("uninterpreted");
/*     */ 
/* 562 */       utagsField.setAccessible(true);
/* 563 */       UninterpretedTags utags = (UninterpretedTags)utagsField.get(pb);
/* 564 */       if (utags == null)
/*     */       {
/* 566 */         return null;
/*     */       }
/*     */ 
/* 569 */       UninterpretedTags utagsClone = new UninterpretedTags();
/* 570 */       for (Map.Entry message : utags.entries()) {
/* 571 */         utagsClone.put(new Integer(((Integer)message.getKey()).intValue()), ((byte[])message.getValue()).clone());
/*     */       }
/*     */ 
/* 575 */       return utagsClone;
/*     */     }
/*     */     catch (SecurityException e) {
/* 578 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (NoSuchFieldException e)
/*     */     {
/* 582 */       return new UninterpretedTags();
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 585 */       throw new RuntimeException(e);
/*     */     } catch (IllegalAccessException e) {
/*     */     }
/* 588 */     throw new RuntimeException(e);
/*     */   }
/*     */ 
/*     */   public static int[] freezeArray(int[] arg, int size)
/*     */   {
/* 600 */     if (size == 0)
/* 601 */       return EMPTY_INT_ARRAY;
/* 602 */     if (isArrayTooBig(arg.length, size)) {
/* 603 */       return Arrays.copyOf(arg, size);
/*     */     }
/* 605 */     return arg;
/*     */   }
/*     */ 
/*     */   public static long[] freezeArray(long[] arg, int size)
/*     */   {
/* 617 */     if (size == 0)
/* 618 */       return EMPTY_LONG_ARRAY;
/* 619 */     if (isArrayTooBig(arg.length, size)) {
/* 620 */       return Arrays.copyOf(arg, size);
/*     */     }
/* 622 */     return arg;
/*     */   }
/*     */ 
/*     */   public static float[] freezeArray(float[] arg, int size)
/*     */   {
/* 634 */     if (size == 0)
/* 635 */       return EMPTY_FLOAT_ARRAY;
/* 636 */     if (isArrayTooBig(arg.length, size)) {
/* 637 */       return Arrays.copyOf(arg, size);
/*     */     }
/* 639 */     return arg;
/*     */   }
/*     */ 
/*     */   public static double[] freezeArray(double[] arg, int size)
/*     */   {
/* 651 */     if (size == 0)
/* 652 */       return EMPTY_DOUBLE_ARRAY;
/* 653 */     if (isArrayTooBig(arg.length, size)) {
/* 654 */       return Arrays.copyOf(arg, size);
/*     */     }
/* 656 */     return arg;
/*     */   }
/*     */ 
/*     */   public static boolean[] freezeArray(boolean[] arg, int size)
/*     */   {
/* 668 */     if (size == 0)
/* 669 */       return EMPTY_BOOLEAN_ARRAY;
/* 670 */     if (isArrayTooBig(arg.length, size)) {
/* 671 */       return Arrays.copyOf(arg, size);
/*     */     }
/* 673 */     return arg;
/*     */   }
/*     */ 
/*     */   public static <T extends ProtocolMessage<T>> List<T> freezeMessages(List<T> list)
/*     */   {
/* 684 */     if (list == null)
/*     */     {
/* 686 */       return null;
/* 687 */     }if (list.size() == 0) {
/* 688 */       return ImmutableList.of();
/*     */     }
/* 690 */     for (ProtocolMessage item : list) {
/* 691 */       item.freeze();
/*     */     }
/* 693 */     return list;
/*     */   }
/*     */ 
/*     */   public static <T> List<T> freezeStrings(List<T> list)
/*     */   {
/* 704 */     if (list == null)
/*     */     {
/* 706 */       return null;
/*     */     }
/* 708 */     if (list.size() == 0) {
/* 709 */       return ImmutableList.of();
/*     */     }
/* 711 */     return list;
/*     */   }
/*     */ 
/*     */   public static byte[] freezeString(byte[] arg)
/*     */   {
/* 723 */     if (arg.length == 0) {
/* 724 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 726 */     return arg;
/*     */   }
/*     */ 
/*     */   public static String freezeString(String arg)
/*     */   {
/* 738 */     return internString(arg);
/*     */   }
/*     */ 
/*     */   private static boolean isArrayTooBig(int capacity, int size)
/*     */   {
/* 743 */     return (capacity - size >= 10) && (size * 4 <= capacity * 3);
/*     */   }
/*     */ 
/*     */   public static <T extends ProtocolMessage<T>> List<T> unfreezeMessages(List<T> list)
/*     */   {
/* 754 */     if (list == null)
/*     */     {
/* 756 */       return null;
/*     */     }
/* 758 */     if ((list instanceof ImmutableList)) {
/* 759 */       list = new ArrayList(list);
/*     */     }
/* 761 */     for (ProtocolMessage item : list) {
/* 762 */       item.unfreeze();
/*     */     }
/* 764 */     return list;
/*     */   }
/*     */ 
/*     */   public static <T> List<T> unfreezeStrings(List<T> list)
/*     */   {
/* 775 */     if (list == null)
/*     */     {
/* 777 */       return null;
/*     */     }
/* 779 */     if ((list instanceof ImmutableList)) {
/* 780 */       list = new ArrayList(4);
/*     */     }
/* 782 */     return list;
/*     */   }
/*     */ 
/*     */   public static <T extends ProtocolMessage<T>> boolean isFrozenMessages(List<T> list)
/*     */   {
/* 792 */     if (list == null)
/*     */     {
/* 796 */       return false;
/*     */     }
/* 798 */     if ((list instanceof ImmutableList)) {
/* 799 */       return true;
/*     */     }
/* 801 */     for (ProtocolMessage message : list) {
/* 802 */       if (message.isFrozen()) return true;
/*     */     }
/* 804 */     return false;
/*     */   }
/*     */ 
/*     */   public static <T> boolean isFrozenStrings(List<T> list)
/*     */   {
/* 814 */     return list instanceof ImmutableList;
/*     */   }
/*     */ 
/*     */   public static <T> List<T> unmodifiableList(List<T> list)
/*     */   {
/* 828 */     if (list == null) {
/* 829 */       return ImmutableList.of();
/*     */     }
/* 831 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */   private static class ByteArrayToUnicodeFunction
/*     */     implements Function<byte[], String>
/*     */   {
/* 434 */     static final ByteArrayToUnicodeFunction defaultFunction = new ByteArrayToUnicodeFunction(Charset.forName("UTF-8"));
/*     */     private final Charset cs;
/*     */ 
/*     */     static ByteArrayToUnicodeFunction getInstance()
/*     */     {
/* 442 */       return defaultFunction;
/*     */     }
/*     */ 
/*     */     static ByteArrayToUnicodeFunction getInstance(Charset cs)
/*     */     {
/* 447 */       return new ByteArrayToUnicodeFunction(cs);
/*     */     }
/*     */ 
/*     */     private ByteArrayToUnicodeFunction(Charset cs)
/*     */     {
/* 452 */       this.cs = cs;
/*     */     }
/*     */ 
/*     */     public String apply(byte[] object)
/*     */     {
/* 457 */       return Protocol.toString(object, this.cs);
/*     */     }
/*     */ 
/*     */     List<String> asList(List<byte[]> data)
/*     */     {
/* 462 */       if (data == null) {
/* 463 */         return ImmutableList.of();
/*     */       }
/* 465 */       return Collections.unmodifiableList(Lists.transform(data, this));
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport
 * JD-Core Version:    0.6.0
 */