/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.Beta;
/*    */ 
/*    */ @Beta
/*    */ public final class Equivalences
/*    */ {
/*    */   public static Equivalence<Object> equals()
/*    */   {
/* 36 */     return Impl.EQUALS;
/*    */   }
/*    */ 
/*    */   public static Equivalence<Object> nullAwareEquals()
/*    */   {
/* 46 */     return Impl.NULL_AWARE_EQUALS;
/*    */   }
/*    */ 
/*    */   public static Equivalence<Object> identity()
/*    */   {
/* 57 */     return Impl.IDENTITY;
/*    */   }
/*    */ 
/*    */   private static abstract enum Impl implements Equivalence<Object> {
/* 61 */     EQUALS, 
/*    */ 
/* 70 */     IDENTITY, 
/*    */ 
/* 79 */     NULL_AWARE_EQUALS;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Equivalences
 * JD-Core Version:    0.6.0
 */