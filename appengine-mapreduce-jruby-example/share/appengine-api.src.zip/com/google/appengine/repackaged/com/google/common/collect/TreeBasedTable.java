/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ @GwtCompatible(serializable=true)
/*     */ @GoogleInternal
/*     */ public class TreeBasedTable<R, C, V> extends StandardRowSortedTable<R, C, V>
/*     */ {
/*     */   private final Comparator<? super C> columnComparator;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <R extends Comparable, C extends Comparable, V> TreeBasedTable<R, C, V> create()
/*     */   {
/*  94 */     return new TreeBasedTable(Ordering.natural(), Ordering.natural());
/*     */   }
/*     */ 
/*     */   public static <R, C, V> TreeBasedTable<R, C, V> create(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator)
/*     */   {
/* 108 */     Preconditions.checkNotNull(rowComparator);
/* 109 */     Preconditions.checkNotNull(columnComparator);
/* 110 */     return new TreeBasedTable(rowComparator, columnComparator);
/*     */   }
/*     */ 
/*     */   public static <R, C, V> TreeBasedTable<R, C, V> create(TreeBasedTable<R, C, ? extends V> table)
/*     */   {
/* 119 */     TreeBasedTable result = new TreeBasedTable(table.rowComparator(), table.columnComparator());
/*     */ 
/* 122 */     result.putAll(table);
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */   TreeBasedTable(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator)
/*     */   {
/* 128 */     super(new TreeMap(rowComparator), new Factory(columnComparator));
/*     */ 
/* 130 */     this.columnComparator = columnComparator;
/*     */   }
/*     */ 
/*     */   public Comparator<? super R> rowComparator()
/*     */   {
/* 140 */     return rowKeySet().comparator();
/*     */   }
/*     */ 
/*     */   public Comparator<? super C> columnComparator()
/*     */   {
/* 148 */     return this.columnComparator;
/*     */   }
/*     */ 
/*     */   public SortedSet<R> rowKeySet()
/*     */   {
/* 154 */     return super.rowKeySet();
/*     */   }
/*     */ 
/*     */   public SortedMap<R, Map<C, V>> rowMap() {
/* 158 */     return super.rowMap();
/*     */   }
/*     */ 
/*     */   private static class Factory<C, V>
/*     */     implements Supplier<TreeMap<C, V>>, Serializable
/*     */   {
/*     */     final Comparator<? super C> comparator;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     Factory(Comparator<? super C> comparator)
/*     */     {
/*  74 */       this.comparator = comparator;
/*     */     }
/*     */     public TreeMap<C, V> get() {
/*  77 */       return new TreeMap(this.comparator);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.TreeBasedTable
 * JD-Core Version:    0.6.0
 */