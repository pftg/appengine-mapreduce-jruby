/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Primitives;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public final class ImmutableClassToInstanceMap<B> extends ForwardingMap<Class<? extends B>, B>
/*     */   implements ClassToInstanceMap<B>
/*     */ {
/*     */   private final ImmutableMap<Class<? extends B>, B> delegate;
/*     */ 
/*     */   public static <B> Builder<B> builder()
/*     */   {
/*  37 */     return new Builder();
/*     */   }
/*     */ 
/*     */   public static <B, S extends B> ImmutableClassToInstanceMap<B> copyOf(Map<? extends Class<? extends S>, ? extends S> map)
/*     */   {
/* 118 */     if ((map instanceof ImmutableClassToInstanceMap)) {
/* 119 */       return (ImmutableClassToInstanceMap)map;
/*     */     }
/* 121 */     return new Builder().putAll(map).build();
/*     */   }
/*     */ 
/*     */   private ImmutableClassToInstanceMap(ImmutableMap<Class<? extends B>, B> delegate)
/*     */   {
/* 128 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   protected Map<Class<? extends B>, B> delegate() {
/* 132 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   public <T extends B> T getInstance(Class<T> type)
/*     */   {
/* 137 */     return this.delegate.get(type);
/*     */   }
/*     */ 
/*     */   public <T extends B> T putInstance(Class<T> type, T value)
/*     */   {
/* 146 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public static final class Builder<B>
/*     */   {
/*  56 */     private final ImmutableMap.Builder<Class<? extends B>, B> mapBuilder = ImmutableMap.builder();
/*     */ 
/*     */     public <T extends B> Builder<B> put(Class<T> type, T value)
/*     */     {
/*  64 */       this.mapBuilder.put(type, value);
/*  65 */       return this;
/*     */     }
/*     */ 
/*     */     public <T extends B> Builder<B> putAll(Map<? extends Class<? extends T>, ? extends T> map)
/*     */     {
/*  79 */       for (Map.Entry entry : map.entrySet()) {
/*  80 */         Class type = (Class)entry.getKey();
/*  81 */         Object value = entry.getValue();
/*  82 */         this.mapBuilder.put(type, cast(type, value));
/*     */       }
/*  84 */       return this;
/*     */     }
/*     */ 
/*     */     private static <B, T extends B> T cast(Class<T> type, B value) {
/*  88 */       return Primitives.wrap(type).cast(value);
/*     */     }
/*     */ 
/*     */     public ImmutableClassToInstanceMap<B> build()
/*     */     {
/*  98 */       return new ImmutableClassToInstanceMap(this.mapBuilder.build(), null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableClassToInstanceMap
 * JD-Core Version:    0.6.0
 */