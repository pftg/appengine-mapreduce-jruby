/*     */ package javax.mail;
/*     */ 
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ class Service$TerminatorEvent extends MailEvent
/*     */ {
/*     */   private static final long serialVersionUID = 5542172141759168416L;
/*     */ 
/*     */   Service$TerminatorEvent()
/*     */   {
/* 588 */     super(new Object());
/*     */   }
/*     */ 
/*     */   public void dispatch(Object listener)
/*     */   {
/* 593 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Service.TerminatorEvent
 * JD-Core Version:    0.6.0
 */