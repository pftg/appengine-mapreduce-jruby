/*     */ package com.google.appengine.api.urlfetch;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public final class FetchOptions
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 3904557385413253999L;
/*     */   public static final boolean DEFAULT_ALLOW_TRUNCATE = false;
/*     */   public static final boolean DEFAULT_FOLLOW_REDIRECTS = true;
/*  54 */   public static final Double DEFAULT_DEADLINE = null;
/*     */ 
/*  56 */   private boolean allowTruncate = false;
/*  57 */   private boolean followRedirects = true;
/*  58 */   private Double deadline = DEFAULT_DEADLINE;
/*     */ 
/*     */   public FetchOptions allowTruncate()
/*     */   {
/*  69 */     this.allowTruncate = true;
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions disallowTruncate()
/*     */   {
/*  79 */     this.allowTruncate = false;
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions followRedirects()
/*     */   {
/*  89 */     this.followRedirects = true;
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions setDeadline(Double deadline)
/*     */   {
/*  99 */     if ((deadline != null) && (deadline.doubleValue() <= 0.0D)) {
/* 100 */       throw new IllegalArgumentException("Deadline must be > 0, got " + deadline);
/*     */     }
/* 102 */     this.deadline = deadline;
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions doNotFollowRedirects()
/*     */   {
/* 112 */     this.followRedirects = false;
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */   boolean getAllowTruncate() {
/* 117 */     return this.allowTruncate;
/*     */   }
/*     */ 
/*     */   boolean getFollowRedirects() {
/* 121 */     return this.followRedirects;
/*     */   }
/*     */ 
/*     */   Double getDeadline() {
/* 125 */     return this.deadline;
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*     */     public static FetchOptions allowTruncate()
/*     */     {
/* 141 */       return withDefaults().allowTruncate();
/*     */     }
/*     */ 
/*     */     public static FetchOptions disallowTruncate()
/*     */     {
/* 153 */       return withDefaults().disallowTruncate();
/*     */     }
/*     */ 
/*     */     public static FetchOptions followRedirects()
/*     */     {
/* 165 */       return withDefaults().followRedirects();
/*     */     }
/*     */ 
/*     */     public static FetchOptions doNotFollowRedirects()
/*     */     {
/* 177 */       return withDefaults().doNotFollowRedirects();
/*     */     }
/*     */ 
/*     */     public static FetchOptions withDeadline(double deadline)
/*     */     {
/* 187 */       return withDefaults().setDeadline(Double.valueOf(deadline));
/*     */     }
/*     */ 
/*     */     public static FetchOptions withDefaults()
/*     */     {
/* 199 */       return new FetchOptions(null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.FetchOptions
 * JD-Core Version:    0.6.0
 */