/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.flags.DocLevel;
/*     */ import com.google.appengine.repackaged.com.google.common.flags.InvalidFlagValueException;
/*     */ import com.google.appengine.repackaged.com.google.common.flags.InvalidFlagsException;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ @Deprecated
/*     */ @GoogleInternal
/*     */ public class Flags
/*     */ {
/*  39 */   private static final Logger LOGGER = Logger.getLogger(Flags.class.getName());
/*     */ 
/* 162 */   private static Set<Field> registeredFields = new HashSet();
/*     */ 
/* 202 */   private static Collection<Flag> allFlags = new ArrayList();
/*     */ 
/* 320 */   private static Set<Pair<String, String>> registeredMethods = new HashSet();
/*     */ 
/* 415 */   private static Set<Class<?>> alreadyRegistered = new HashSet();
/*     */ 
/*     */   public Flags()
/*     */   {
/*  45 */     LOGGER.fine("Note: com.google.common.base.Flags is deprecated.  Use com.google.common.flags instead.");
/*     */     try
/*     */     {
/*  48 */       registeredFields.clear();
/*  49 */       registeredMethods.clear();
/*  50 */       alreadyRegistered.clear();
/*     */ 
/*  52 */       Class newFlags = com.google.appengine.repackaged.com.google.common.flags.Flags.class;
/*  53 */       Method reset = newFlags.getDeclaredMethod("clearFlagMapsForTesting", new Class[0]);
/*  54 */       reset.setAccessible(true);
/*  55 */       reset.invoke(null, new Object[0]);
/*  56 */       allFlags.clear();
/*     */     } catch (Exception ex) {
/*  58 */       throw new AssertionError(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Flags(Object[] registerClasses)
/*     */   {
/*  66 */     this();
/*  67 */     for (int i = 0; i < registerClasses.length; i++)
/*  68 */       register(registerClasses[i]);
/*     */   }
/*     */ 
/*     */   public void usage()
/*     */   {
/*  76 */     com.google.appengine.repackaged.com.google.common.flags.Flags.usage(System.err);
/*     */   }
/*     */ 
/*     */   public void register(Class<?> cl)
/*     */   {
/*  83 */     register(cl, null);
/*     */   }
/*     */ 
/*     */   public void register(Object o)
/*     */   {
/*  90 */     if ((o instanceof Class))
/*  91 */       register((Class)o);
/*     */     else
/*  93 */       register(o.getClass(), o);
/*     */   }
/*     */ 
/*     */   public void registerIncludeDerived(Class<?> cl)
/*     */   {
/* 101 */     register(cl, null, true);
/*     */   }
/*     */ 
/*     */   private void register(Class<?> cl, Object object)
/*     */   {
/* 108 */     register(cl, object, false);
/*     */   }
/*     */ 
/*     */   private void register(Class<?> cl, Object object, boolean forceInherited)
/*     */   {
/* 118 */     if (object == null)
/*     */     {
/* 123 */       com.google.appengine.repackaged.com.google.common.flags.Flags.addPreferredClass(cl.getName());
/*     */     }
/*     */ 
/* 127 */     registerUpdateFlags(cl, object);
/*     */     Field[] fields;
/*     */     Field[] fields;
/* 130 */     if ((object == null) && (!forceInherited)) {
/* 131 */       fields = cl.getDeclaredFields();
/*     */     }
/*     */     else {
/* 134 */       fields = cl.getFields();
/*     */     }
/*     */ 
/* 137 */     for (int i = 0; i < fields.length; i++) {
/* 138 */       Field f = fields[i];
/* 139 */       if ((object == null) != Modifier.isStatic(f.getModifiers()))
/*     */       {
/*     */         continue;
/*     */       }
/* 143 */       String name = f.getName();
/* 144 */       if ((!name.startsWith("FLAG_")) || 
/* 145 */         (f.getAnnotation(DisableFlag.class) != null))
/*     */         continue;
/*     */       try
/*     */       {
/* 149 */         if (registeredFields.add(f))
/* 150 */           registerField(f.getDeclaringClass(), object, name, docForField(object, f, name));
/*     */       }
/*     */       catch (NoSuchFieldException ex) {
/* 153 */         throw new AssertionError(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Object parseDirectValue(Class<?> cl, String value)
/*     */     throws InvalidFlagValueException
/*     */   {
/*     */     try
/*     */     {
/* 172 */       if (cl == Integer.TYPE)
/* 173 */         return Integer.decode(value);
/* 174 */       if (cl == Long.TYPE)
/* 175 */         return Long.decode(value);
/* 176 */       if (cl == Float.TYPE)
/* 177 */         return Float.valueOf(value);
/* 178 */       if (cl == Double.TYPE)
/* 179 */         return Double.valueOf(value);
/* 180 */       if (cl == Boolean.TYPE)
/* 181 */         return Boolean.valueOf(value);
/* 182 */       if (cl == String.class) {
/* 183 */         return value;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 190 */         return cl.getDeclaredMethod("valueOf", new Class[] { String.class }).invoke(null, new Object[] { value });
/*     */       } catch (InvocationTargetException e) {
/* 192 */         throw new InvalidFlagValueException("'" + value + "' for type " + cl);
/*     */       } catch (Exception e) {
/* 194 */         throw new InvalidFlagValueException("'" + value + "' for type " + cl);
/*     */       }
/*     */     } catch (NumberFormatException ex) {
/*     */     }
/* 198 */     throw new InvalidFlagValueException("'" + value + "' for type " + cl);
/*     */   }
/*     */ 
/*     */   private String docForField(Object object, Field field, String name)
/*     */   {
/*     */     try
/*     */     {
/* 209 */       if (Flag.class.isAssignableFrom(field.getType()))
/*     */       {
/* 211 */         Flag flag = (Flag)field.get(object);
/* 212 */         allFlags.add(flag);
/* 213 */         flag.setRegistered();
/* 214 */         return flag.getHelpString();
/*     */       }
/*     */ 
/* 217 */       String helpFieldName = "HELP_" + name;
/* 218 */       if (name.startsWith("FLAG_")) {
/* 219 */         helpFieldName = "HELP_" + name.substring(5, name.length());
/*     */       }
/* 221 */       Field h = field.getDeclaringClass().getField(helpFieldName);
/* 222 */       if (h.getType() != String.class) {
/* 223 */         LOGGER.log(Level.SEVERE, "Wrong type for " + h);
/* 224 */         return "";
/*     */       }
/* 226 */       if (Modifier.isStatic(h.getModifiers()) != (object == null)) {
/* 227 */         return "";
/*     */       }
/* 229 */       return (String)h.get(object);
/*     */     }
/*     */     catch (NoSuchFieldException ex) {
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 234 */       LOGGER.log(Level.SEVERE, ex.toString(), ex);
/*     */     }
/* 236 */     return "";
/*     */   }
/*     */ 
/*     */   private static com.google.appengine.repackaged.com.google.common.flags.Flag<?> flagForField(Object object, Field field)
/*     */   {
/* 245 */     Class fieldType = field.getType();
/* 246 */     if (Flag.class.isAssignableFrom(fieldType)) {
/*     */       try {
/* 248 */         Flag oldFlag = (Flag)field.get(object);
/* 249 */         return oldFlag.newFlag();
/*     */       }
/*     */       catch (IllegalAccessException ex) {
/* 252 */         throw new AssertionError(ex);
/*     */       }
/*     */     }
/* 255 */     return new com.google.appengine.repackaged.com.google.common.flags.Flag(null, fieldType, field, object) {
/*     */       protected Object parse(String text) throws InvalidFlagValueException {
/* 257 */         Object value = Flags.access$000(this.val$fieldType, text);
/*     */         try {
/* 259 */           this.val$field.set(this.val$object, value);
/*     */         } catch (IllegalAccessException ex) {
/* 261 */           throw new AssertionError(ex);
/*     */         }
/* 263 */         return value;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private void registerField(Class<?> cl, Object object, String fieldName, String doc)
/*     */     throws NoSuchFieldException
/*     */   {
/* 274 */     registerUpdateFlags(cl, object);
/*     */ 
/* 277 */     Field field = cl.getField(fieldName);
/*     */ 
/* 283 */     if (com.google.appengine.repackaged.com.google.common.flags.Flag.class.isAssignableFrom(field.getType())) {
/* 284 */       return;
/*     */     }
/*     */ 
/* 287 */     String flagName = fieldName.startsWith("FLAG_") ? fieldName.substring(5) : fieldName;
/*     */ 
/* 289 */     com.google.appengine.repackaged.com.google.common.flags.Flags.registerFlag(cl.getName(), flagName, doc != null ? doc : docForField(object, field, fieldName), null, DocLevel.PUBLIC, typeForField(object, field), flagForField(object, field));
/*     */   }
/*     */ 
/*     */   private static String typeForField(Object object, Field field)
/*     */   {
/*     */     String result;
/* 303 */     if (Flag.class.isAssignableFrom(field.getType()))
/*     */       try {
/* 305 */         Flag flag = (Flag)field.get(object);
/* 306 */         result = flag.getType().getName();
/*     */       } catch (IllegalAccessException ex) {
/* 308 */         throw new AssertionError(ex);
/*     */       }
/*     */     else {
/* 311 */       result = field.getType().getName();
/*     */     }
/* 313 */     if (result.equals("boolean")) {
/* 314 */       result = "java.lang.Boolean";
/*     */     }
/* 316 */     return result;
/*     */   }
/*     */ 
/*     */   public void registerMethod(Object object, String methodName, String component, String flagName, String help, boolean isBoolean)
/*     */     throws NoSuchMethodException, SecurityException
/*     */   {
/* 330 */     if (!registeredMethods.add(Pair.of(object.getClass().getName() + "." + methodName, flagName))) {
/* 331 */       return;
/*     */     }
/*     */ 
/* 335 */     registerUpdateFlags(object.getClass(), object);
/*     */ 
/* 338 */     Method method = object.getClass().getMethod(methodName, new Class[] { String.class, String.class });
/*     */ 
/* 340 */     com.google.appengine.repackaged.com.google.common.flags.Flags.registerFlag(object.getClass().getName(), flagName, help, null, DocLevel.PUBLIC, isBoolean ? "java.lang.Boolean" : "java.lang.String", new com.google.appengine.repackaged.com.google.common.flags.Flag(null, method, object, flagName)
/*     */     {
/*     */       public String parse(String value)
/*     */       {
/*     */         try
/*     */         {
/* 350 */           this.val$method.invoke(this.val$object, new Object[] { this.val$flagName, value });
/* 351 */           return value;
/*     */         } catch (IllegalAccessException ex) {
/* 353 */           throw new AssertionError(ex);
/*     */         } catch (IllegalArgumentException ex) {
/* 355 */           throw new AssertionError(ex); } catch (InvocationTargetException ex) {
/*     */         }
/* 357 */         throw new AssertionError(ex.getCause());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public String[] parse(String[] arguments)
/*     */   {
/* 368 */     boolean oldChecking = Flag.setStateCheckingDisabled(true);
/*     */     try {
/* 370 */       String[] arrayOfString = com.google.appengine.repackaged.com.google.common.flags.Flags.parse(arguments);
/*     */       return arrayOfString;
/*     */     }
/*     */     catch (InvalidFlagsException ex)
/*     */     {
/* 372 */       throw new UsageError(ex.getMessage(), ex);
/*     */     } finally {
/* 374 */       Flag.setStateCheckingDisabled(oldChecking); } throw localObject;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public String[] parse(String[] arguments, boolean helpAnywhere)
/*     */   {
/* 390 */     return parse(arguments);
/*     */   }
/*     */ 
/*     */   private static void registerUpdateFlags(Class<?> cl, Object object)
/*     */   {
/* 418 */     if (!alreadyRegistered.add(cl))
/* 419 */       return;
/*     */     try
/*     */     {
/* 422 */       Method m = cl.getMethod("updateFlags", new Class[0]);
/* 423 */       if ((object == null) != Modifier.isStatic(m.getModifiers())) {
/* 424 */         return;
/*     */       }
/* 426 */       Runnable completionHook = new Runnable(m, object)
/*     */       {
/*     */         public void run() {
/*     */           try {
/* 430 */             this.val$m.invoke(this.val$object, new Object[0]);
/*     */           } catch (IllegalAccessException exc) {
/* 432 */             throw new Flags.FlagUpdateError(exc.getCause());
/*     */           } catch (InvocationTargetException exc) {
/* 434 */             throw new Flags.FlagUpdateError(exc.getCause());
/*     */           }
/*     */         }
/*     */       };
/* 438 */       com.google.appengine.repackaged.com.google.common.flags.Flags.registerCompletionHook(completionHook);
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/*     */     }
/*     */   }
/*     */ 
/*     */   static {
/* 445 */     com.google.appengine.repackaged.com.google.common.flags.Flags.registerCompletionHook(new Runnable()
/*     */     {
/*     */       public void run() {
/* 448 */         for (Flag f : Flags.allFlags)
/* 449 */           f.setParsed();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static class UsageError extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public UsageError(String msg)
/*     */     {
/* 405 */       super();
/*     */     }
/*     */ 
/*     */     public UsageError(String msg, Throwable t) {
/* 409 */       super(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class FlagUpdateError extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public FlagUpdateError(Throwable cause)
/*     */     {
/* 396 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Flags
 * JD-Core Version:    0.6.0
 */