/*    */ package javax.mail;
/*    */ 
/*    */ public class MessageContext
/*    */ {
/*    */   private final Part part;
/*    */ 
/*    */   public MessageContext(Part part)
/*    */   {
/* 36 */     this.part = part;
/*    */   }
/*    */ 
/*    */   public Part getPart()
/*    */   {
/* 45 */     return this.part;
/*    */   }
/*    */ 
/*    */   public Message getMessage()
/*    */   {
/* 55 */     return getMessageFrom(this.part);
/*    */   }
/*    */ 
/*    */   public Session getSession()
/*    */   {
/* 64 */     Message message = getMessage();
/* 65 */     if (message == null) {
/* 66 */       return null;
/*    */     }
/* 68 */     return message.session;
/*    */   }
/*    */ 
/*    */   private Message getMessageFrom(Part p)
/*    */   {
/* 81 */     while (p != null) {
/* 82 */       if ((p instanceof Message)) {
/* 83 */         return (Message)p;
/*    */       }
/* 85 */       Multipart mp = ((BodyPart)p).getParent();
/* 86 */       if (mp == null) {
/* 87 */         return null;
/*    */       }
/* 89 */       p = mp.getParent();
/*    */     }
/* 91 */     return null;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.MessageContext
 * JD-Core Version:    0.6.0
 */