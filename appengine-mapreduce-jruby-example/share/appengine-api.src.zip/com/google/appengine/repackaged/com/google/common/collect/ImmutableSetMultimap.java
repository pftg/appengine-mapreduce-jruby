/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public class ImmutableSetMultimap<K, V> extends ImmutableMultimap<K, V>
/*     */   implements SetMultimap<K, V>
/*     */ {
/*     */   private transient ImmutableSet<Map.Entry<K, V>> entries;
/*     */ 
/*     */   @GwtIncompatible("not needed in emulated source.")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> of()
/*     */   {
/*  63 */     return EmptyImmutableSetMultimap.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1)
/*     */   {
/*  70 */     Builder builder = builder();
/*  71 */     builder.put(k1, v1);
/*  72 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2)
/*     */   {
/*  81 */     Builder builder = builder();
/*  82 */     builder.put(k1, v1);
/*  83 */     builder.put(k2, v2);
/*  84 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*     */   {
/*  94 */     Builder builder = builder();
/*  95 */     builder.put(k1, v1);
/*  96 */     builder.put(k2, v2);
/*  97 */     builder.put(k3, v3);
/*  98 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*     */   {
/* 108 */     Builder builder = builder();
/* 109 */     builder.put(k1, v1);
/* 110 */     builder.put(k2, v2);
/* 111 */     builder.put(k3, v3);
/* 112 */     builder.put(k4, v4);
/* 113 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*     */   {
/* 123 */     Builder builder = builder();
/* 124 */     builder.put(k1, v1);
/* 125 */     builder.put(k2, v2);
/* 126 */     builder.put(k3, v3);
/* 127 */     builder.put(k4, v4);
/* 128 */     builder.put(k5, v5);
/* 129 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> Builder<K, V> builder()
/*     */   {
/* 138 */     return new Builder();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap)
/*     */   {
/* 257 */     if (multimap.isEmpty()) {
/* 258 */       return of();
/*     */     }
/*     */ 
/* 261 */     if ((multimap instanceof ImmutableSetMultimap))
/*     */     {
/* 263 */       ImmutableSetMultimap kvMultimap = (ImmutableSetMultimap)multimap;
/*     */ 
/* 265 */       return kvMultimap;
/*     */     }
/*     */ 
/* 268 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/* 269 */     int size = 0;
/*     */ 
/* 272 */     for (Map.Entry entry : multimap.asMap().entrySet()) {
/* 273 */       Object key = entry.getKey();
/* 274 */       Collection values = (Collection)entry.getValue();
/* 275 */       ImmutableSet set = ImmutableSet.copyOf(values);
/* 276 */       if (!set.isEmpty()) {
/* 277 */         builder.put(key, set);
/* 278 */         size += set.size();
/*     */       }
/*     */     }
/*     */ 
/* 282 */     return new ImmutableSetMultimap(builder.build(), size);
/*     */   }
/*     */ 
/*     */   ImmutableSetMultimap(ImmutableMap<K, ImmutableSet<V>> map, int size) {
/* 286 */     super(map, size);
/*     */   }
/*     */ 
/*     */   public ImmutableSet<V> get(@Nullable K key)
/*     */   {
/* 299 */     ImmutableSet set = (ImmutableSet)this.map.get(key);
/* 300 */     return set == null ? ImmutableSet.of() : set;
/*     */   }
/*     */ 
/*     */   public ImmutableSet<V> removeAll(Object key)
/*     */   {
/* 309 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public ImmutableSet<V> replaceValues(K key, Iterable<? extends V> values)
/*     */   {
/* 319 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public ImmutableSet<Map.Entry<K, V>> entries()
/*     */   {
/* 331 */     ImmutableSet result = this.entries;
/* 332 */     return result == null ? (this.entries = ImmutableSet.copyOf(super.entries())) : result;
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 343 */     stream.defaultWriteObject();
/* 344 */     Serialization.writeMultimap(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 350 */     stream.defaultReadObject();
/* 351 */     int keyCount = stream.readInt();
/* 352 */     if (keyCount < 0) {
/* 353 */       throw new InvalidObjectException("Invalid key count " + keyCount);
/*     */     }
/* 355 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/*     */ 
/* 357 */     int tmpSize = 0;
/*     */ 
/* 359 */     for (int i = 0; i < keyCount; i++) {
/* 360 */       Object key = stream.readObject();
/* 361 */       int valueCount = stream.readInt();
/* 362 */       if (valueCount <= 0) {
/* 363 */         throw new InvalidObjectException("Invalid value count " + valueCount);
/*     */       }
/*     */ 
/* 366 */       Object[] array = new Object[valueCount];
/* 367 */       for (int j = 0; j < valueCount; j++) {
/* 368 */         array[j] = stream.readObject();
/*     */       }
/* 370 */       ImmutableSet valueSet = ImmutableSet.copyOf(array);
/* 371 */       if (valueSet.size() != array.length) {
/* 372 */         throw new InvalidObjectException("Duplicate key-value pairs exist for key " + key);
/*     */       }
/*     */ 
/* 375 */       builder.put(key, valueSet);
/* 376 */       tmpSize += valueCount;
/*     */     }
/*     */     ImmutableMap tmpMap;
/*     */     try {
/* 381 */       tmpMap = builder.build();
/*     */     } catch (IllegalArgumentException e) {
/* 383 */       throw ((InvalidObjectException)new InvalidObjectException(e.getMessage()).initCause(e));
/*     */     }
/*     */ 
/* 387 */     ImmutableMultimap.FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
/* 388 */     ImmutableMultimap.FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
/*     */   }
/*     */ 
/*     */   public static final class Builder<K, V> extends ImmutableMultimap.Builder<K, V>
/*     */   {
/* 173 */     private final Multimap<K, V> builderMultimap = new ImmutableSetMultimap.BuilderMultimap();
/*     */ 
/*     */     public Builder<K, V> put(K key, V value)
/*     */     {
/* 186 */       this.builderMultimap.put(Preconditions.checkNotNull(key), Preconditions.checkNotNull(value));
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(K key, Iterable<? extends V> values)
/*     */     {
/* 198 */       Collection collection = this.builderMultimap.get(Preconditions.checkNotNull(key));
/* 199 */       for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 200 */         collection.add(Preconditions.checkNotNull(value));
/*     */       }
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(K key, V[] values)
/*     */     {
/* 212 */       return putAll(key, Arrays.asList(values));
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(Multimap<? extends K, ? extends V> multimap)
/*     */     {
/* 227 */       for (Map.Entry entry : multimap.asMap().entrySet()) {
/* 228 */         putAll(entry.getKey(), (Iterable)entry.getValue());
/*     */       }
/* 230 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableSetMultimap<K, V> build()
/*     */     {
/* 237 */       return ImmutableSetMultimap.copyOf(this.builderMultimap);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BuilderMultimap<K, V> extends AbstractMultimap<K, V>
/*     */   {
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     BuilderMultimap()
/*     */     {
/* 147 */       super();
/*     */     }
/*     */     Collection<V> createCollection() {
/* 150 */       return Sets.newLinkedHashSet();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableSetMultimap
 * JD-Core Version:    0.6.0
 */