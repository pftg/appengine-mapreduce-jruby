/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public final class Session
/*     */ {
/*  57 */   private static final Class[] PARAM_TYPES = { Session.class, URLName.class };
/*  58 */   private static final WeakHashMap addressMapsByClassLoader = new WeakHashMap();
/*     */   private static Session DEFAULT_SESSION;
/*  61 */   private Map passwordAuthentications = new HashMap();
/*     */   private final Properties properties;
/*     */   private final Authenticator authenticator;
/*     */   private boolean debug;
/*  66 */   private PrintStream debugOut = System.out;
/*     */ 
/*  68 */   private static final WeakHashMap providersByClassLoader = new WeakHashMap();
/*     */ 
/*     */   private Session(Properties properties, Authenticator authenticator)
/*     */   {
/*  74 */     this.properties = properties;
/*  75 */     this.authenticator = authenticator;
/*  76 */     this.debug = Boolean.valueOf(properties.getProperty("mail.debug")).booleanValue();
/*     */   }
/*     */ 
/*     */   public static Session getInstance(Properties properties, Authenticator authenticator)
/*     */   {
/*  97 */     return new Session(new Properties(properties), authenticator);
/*     */   }
/*     */ 
/*     */   public static Session getInstance(Properties properties)
/*     */   {
/* 108 */     return getInstance(properties, null);
/*     */   }
/*     */ 
/*     */   public static synchronized Session getDefaultInstance(Properties properties)
/*     */   {
/* 119 */     return getDefaultInstance(properties, null);
/*     */   }
/*     */ 
/*     */   public static synchronized Session getDefaultInstance(Properties properties, Authenticator authenticator)
/*     */   {
/* 132 */     if (DEFAULT_SESSION == null) {
/* 133 */       DEFAULT_SESSION = getInstance(properties, authenticator);
/*     */     }
/* 135 */     else if ((authenticator != DEFAULT_SESSION.authenticator) && (
/* 136 */       (authenticator == null) || (DEFAULT_SESSION.authenticator == null) || (authenticator.getClass().getClassLoader() != DEFAULT_SESSION.authenticator.getClass().getClassLoader()))) {
/* 137 */       throw new SecurityException();
/*     */     }
/*     */ 
/* 142 */     return DEFAULT_SESSION;
/*     */   }
/*     */ 
/*     */   public void setDebug(boolean debug)
/*     */   {
/* 153 */     this.debug = debug;
/*     */   }
/*     */ 
/*     */   public boolean getDebug()
/*     */   {
/* 162 */     return this.debug;
/*     */   }
/*     */ 
/*     */   public void setDebugOut(PrintStream out)
/*     */   {
/* 172 */     this.debugOut = (out == null ? System.out : out);
/*     */   }
/*     */ 
/*     */   public PrintStream getDebugOut()
/*     */   {
/* 181 */     return this.debugOut;
/*     */   }
/*     */ 
/*     */   public Provider[] getProviders()
/*     */   {
/* 196 */     ProviderInfo info = getProviderInfo();
/* 197 */     return (Provider[])(Provider[])info.all.toArray(new Provider[info.all.size()]);
/*     */   }
/*     */ 
/*     */   public Provider getProvider(String protocol)
/*     */     throws NoSuchProviderException
/*     */   {
/* 213 */     ProviderInfo info = getProviderInfo();
/* 214 */     Provider provider = null;
/* 215 */     String providerName = this.properties.getProperty("mail." + protocol + ".class");
/* 216 */     if (providerName != null) {
/* 217 */       provider = (Provider)info.byClassName.get(providerName);
/* 218 */       if (this.debug) {
/* 219 */         writeDebug("DEBUG: new provider loaded: " + provider.toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 224 */     if (provider == null) {
/* 225 */       provider = (Provider)info.byProtocol.get(protocol);
/*     */     }
/*     */ 
/* 228 */     if (provider == null) {
/* 229 */       throw new NoSuchProviderException("Unable to locate provider for protocol: " + protocol);
/*     */     }
/* 231 */     if (this.debug) {
/* 232 */       writeDebug("DEBUG: getProvider() returning provider " + provider.toString());
/*     */     }
/* 234 */     return provider;
/*     */   }
/*     */ 
/*     */   public void setProvider(Provider provider)
/*     */     throws NoSuchProviderException
/*     */   {
/* 244 */     ProviderInfo info = getProviderInfo();
/* 245 */     info.byProtocol.put(provider.getProtocol(), provider);
/*     */   }
/*     */ 
/*     */   public Store getStore()
/*     */     throws NoSuchProviderException
/*     */   {
/* 255 */     String protocol = this.properties.getProperty("mail.store.protocol");
/* 256 */     if (protocol == null) {
/* 257 */       throw new NoSuchProviderException("mail.store.protocol property is not set");
/*     */     }
/* 259 */     return getStore(protocol);
/*     */   }
/*     */ 
/*     */   public Store getStore(String protocol)
/*     */     throws NoSuchProviderException
/*     */   {
/* 270 */     Provider provider = getProvider(protocol);
/* 271 */     return getStore(provider);
/*     */   }
/*     */ 
/*     */   public Store getStore(URLName url)
/*     */     throws NoSuchProviderException
/*     */   {
/* 282 */     return (Store)getService(getProvider(url.getProtocol()), url);
/*     */   }
/*     */ 
/*     */   public Store getStore(Provider provider)
/*     */     throws NoSuchProviderException
/*     */   {
/* 293 */     if (Provider.Type.STORE != provider.getType()) {
/* 294 */       throw new NoSuchProviderException("Not a Store Provider: " + provider);
/*     */     }
/* 296 */     return (Store)getService(provider, null);
/*     */   }
/*     */ 
/*     */   public Folder getFolder(URLName name)
/*     */     throws MessagingException
/*     */   {
/* 311 */     Store store = getStore(name);
/* 312 */     return store.getFolder(name);
/*     */   }
/*     */ 
/*     */   public Transport getTransport()
/*     */     throws NoSuchProviderException
/*     */   {
/* 323 */     String protocol = this.properties.getProperty("mail.transport.protocol");
/* 324 */     if (protocol == null) {
/* 325 */       throw new NoSuchProviderException("mail.transport.protocol property is not set");
/*     */     }
/* 327 */     return getTransport(protocol);
/*     */   }
/*     */ 
/*     */   public Transport getTransport(String protocol)
/*     */     throws NoSuchProviderException
/*     */   {
/* 338 */     Provider provider = getProvider(protocol);
/* 339 */     return getTransport(provider);
/*     */   }
/*     */ 
/*     */   public Transport getTransport(URLName name)
/*     */     throws NoSuchProviderException
/*     */   {
/* 350 */     return (Transport)getService(getProvider(name.getProtocol()), name);
/*     */   }
/*     */ 
/*     */   public Transport getTransport(Address address)
/*     */     throws NoSuchProviderException
/*     */   {
/* 361 */     String type = address.getType();
/*     */ 
/* 363 */     Map addressMap = getAddressMap();
/* 364 */     String protocolName = (String)addressMap.get(type);
/* 365 */     if (protocolName == null) {
/* 366 */       throw new NoSuchProviderException("No provider for address type " + type);
/*     */     }
/* 368 */     return getTransport(protocolName);
/*     */   }
/*     */ 
/*     */   public Transport getTransport(Provider provider)
/*     */     throws NoSuchProviderException
/*     */   {
/* 379 */     return (Transport)getService(provider, null);
/*     */   }
/*     */ 
/*     */   public void setPasswordAuthentication(URLName name, PasswordAuthentication authenticator)
/*     */   {
/* 389 */     if (authenticator == null)
/* 390 */       this.passwordAuthentications.remove(name);
/*     */     else
/* 392 */       this.passwordAuthentications.put(name, authenticator);
/*     */   }
/*     */ 
/*     */   public PasswordAuthentication getPasswordAuthentication(URLName name)
/*     */   {
/* 403 */     return (PasswordAuthentication)this.passwordAuthentications.get(name);
/*     */   }
/*     */ 
/*     */   public PasswordAuthentication requestPasswordAuthentication(InetAddress host, int port, String protocol, String prompt, String defaultUserName)
/*     */   {
/* 417 */     if (this.authenticator == null) {
/* 418 */       return null;
/*     */     }
/* 420 */     return this.authenticator.authenticate(host, port, protocol, prompt, defaultUserName);
/*     */   }
/*     */ 
/*     */   public Properties getProperties()
/*     */   {
/* 429 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public String getProperty(String property)
/*     */   {
/* 439 */     return getProperties().getProperty(property);
/*     */   }
/*     */ 
/*     */   public synchronized void addProvider(Provider provider)
/*     */   {
/* 449 */     ProviderInfo info = getProviderInfo();
/* 450 */     info.addProvider(provider);
/*     */   }
/*     */ 
/*     */   public void setProtocolForAddress(String addressType, String protocol)
/*     */   {
/* 464 */     Map addressMap = getAddressMap();
/*     */ 
/* 467 */     if (protocol == null) {
/* 468 */       addressMap.remove(addressType);
/*     */     }
/*     */     else
/* 471 */       addressMap.put(addressType, protocol);
/*     */   }
/*     */ 
/*     */   private Service getService(Provider provider, URLName name) throws NoSuchProviderException
/*     */   {
/*     */     try
/*     */     {
/* 478 */       if (name == null) {
/* 479 */         name = new URLName(provider.getProtocol(), null, -1, null, null, null);
/*     */       }
/* 481 */       ClassLoader cl = getClassLoader();
/* 482 */       Class clazz = cl.loadClass(provider.getClassName());
/* 483 */       Constructor ctr = clazz.getConstructor(PARAM_TYPES);
/* 484 */       return (Service)ctr.newInstance(new Object[] { this, name });
/*     */     } catch (ClassNotFoundException e) {
/* 486 */       throw ((NoSuchProviderException)new NoSuchProviderException("Unable to load class for provider: " + provider).initCause(e));
/*     */     } catch (NoSuchMethodException e) {
/* 488 */       throw ((NoSuchProviderException)new NoSuchProviderException("Provider class does not have a constructor(Session, URLName): " + provider).initCause(e));
/*     */     } catch (InstantiationException e) {
/* 490 */       throw ((NoSuchProviderException)new NoSuchProviderException("Unable to instantiate provider class: " + provider).initCause(e));
/*     */     } catch (IllegalAccessException e) {
/* 492 */       throw ((NoSuchProviderException)new NoSuchProviderException("Unable to instantiate provider class: " + provider).initCause(e)); } catch (InvocationTargetException e) {
/*     */     }
/* 494 */     throw ((NoSuchProviderException)new NoSuchProviderException("Exception from constructor of provider class: " + provider).initCause(e.getCause()));
/*     */   }
/*     */ 
/*     */   private ProviderInfo getProviderInfo()
/*     */   {
/* 499 */     ClassLoader cl = getClassLoader();
/* 500 */     synchronized (providersByClassLoader) {
/* 501 */       ProviderInfo info = (ProviderInfo)providersByClassLoader.get(cl);
/* 502 */       if (info == null) {
/* 503 */         info = loadProviders(cl);
/*     */       }
/* 505 */       return info;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Map getAddressMap() {
/* 510 */     ClassLoader cl = getClassLoader();
/* 511 */     Map addressMap = (Map)addressMapsByClassLoader.get(cl);
/* 512 */     if (addressMap == null) {
/* 513 */       addressMap = loadAddressMap(cl);
/*     */     }
/* 515 */     return addressMap;
/*     */   }
/*     */ 
/*     */   private ClassLoader getClassLoader()
/*     */   {
/* 529 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 530 */     if (cl == null) {
/* 531 */       if (this.authenticator != null) {
/* 532 */         cl = this.authenticator.getClass().getClassLoader();
/*     */       }
/*     */       else {
/* 535 */         cl = getClass().getClassLoader();
/*     */       }
/*     */     }
/* 538 */     return cl;
/*     */   }
/*     */ 
/*     */   private ProviderInfo loadProviders(ClassLoader cl)
/*     */   {
/* 548 */     ProviderInfo info = new ProviderInfo(null);
/*     */     try
/*     */     {
/* 554 */       File file = new File(System.getProperty("java.home"), "lib/javamail.providers");
/* 555 */       InputStream is = new FileInputStream(file);
/*     */       try {
/* 557 */         loadProviders(info, is);
/* 558 */         if (this.debug)
/* 559 */           writeDebug("Loaded lib/javamail.providers from " + file.toString());
/*     */       }
/*     */       finally {
/* 562 */         is.close();
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e) {
/*     */     }
/*     */     try {
/* 571 */       Enumeration e = cl.getResources("META-INF/javamail.providers");
/* 572 */       while (e.hasMoreElements()) {
/* 573 */         URL url = (URL)e.nextElement();
/* 574 */         if (this.debug) {
/* 575 */           writeDebug("Loading META-INF/javamail.providers from " + url.toString());
/*     */         }
/* 577 */         InputStream is = url.openStream();
/*     */         try {
/* 579 */           loadProviders(info, is);
/*     */         } finally {
/* 581 */           is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e) {
/*     */     }
/*     */     try {
/* 591 */       Enumeration e = cl.getResources("META-INF/javamail.default.providers");
/* 592 */       while (e.hasMoreElements()) {
/* 593 */         URL url = (URL)e.nextElement();
/* 594 */         if (this.debug) {
/* 595 */           writeDebug("Loading javamail.default.providers from " + url.toString());
/*     */         }
/*     */ 
/* 598 */         InputStream is = url.openStream();
/*     */         try {
/* 600 */           loadProviders(info, is);
/*     */         } finally {
/* 602 */           is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/* 612 */     providersByClassLoader.put(cl, info);
/*     */ 
/* 614 */     return info;
/*     */   }
/*     */ 
/*     */   private void loadProviders(ProviderInfo info, InputStream is) throws IOException {
/* 618 */     BufferedReader reader = new BufferedReader(new InputStreamReader(is));
/*     */     String line;
/* 620 */     while ((line = reader.readLine()) != null)
/*     */     {
/* 622 */       if (line.startsWith("#"))
/*     */       {
/*     */         continue;
/*     */       }
/* 626 */       StringTokenizer tok = new StringTokenizer(line, ";");
/* 627 */       String protocol = null;
/* 628 */       Provider.Type type = null;
/* 629 */       String className = null;
/* 630 */       String vendor = null;
/* 631 */       String version = null;
/* 632 */       while (tok.hasMoreTokens()) {
/* 633 */         String property = tok.nextToken();
/* 634 */         int index = property.indexOf('=');
/* 635 */         if (index == -1) {
/*     */           continue;
/*     */         }
/* 638 */         String key = property.substring(0, index).trim().toLowerCase();
/* 639 */         String value = property.substring(index + 1).trim();
/* 640 */         if ((protocol == null) && ("protocol".equals(key)))
/* 641 */           protocol = value;
/* 642 */         else if ((type == null) && ("type".equals(key))) {
/* 643 */           if ("store".equals(value))
/* 644 */             type = Provider.Type.STORE;
/* 645 */           else if ("transport".equals(value))
/* 646 */             type = Provider.Type.TRANSPORT;
/*     */         }
/* 648 */         else if ((className == null) && ("class".equals(key)))
/* 649 */           className = value;
/* 650 */         else if ("vendor".equals(key))
/* 651 */           vendor = value;
/* 652 */         else if ("version".equals(key)) {
/* 653 */           version = value;
/*     */         }
/*     */       }
/* 656 */       if ((protocol == null) || (type == null) || (className == null))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 661 */       if (this.debug) {
/* 662 */         writeDebug("DEBUG: loading new provider protocol=" + protocol + ", className=" + className + ", vendor=" + vendor + ", version=" + version);
/*     */       }
/* 664 */       Provider provider = new Provider(type, protocol, className, vendor, version);
/*     */ 
/* 666 */       info.addProvider(provider);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map loadAddressMap(ClassLoader cl)
/*     */   {
/* 690 */     Properties addressMap = new Properties();
/*     */ 
/* 693 */     addressMapsByClassLoader.put(cl, addressMap);
/*     */     try
/*     */     {
/* 699 */       Enumeration e = cl.getResources("META-INF/javamail.default.address.map");
/* 700 */       while (e.hasMoreElements()) {
/* 701 */         URL url = (URL)e.nextElement();
/* 702 */         InputStream is = url.openStream();
/*     */         try
/*     */         {
/* 705 */           addressMap.load(is);
/*     */         } finally {
/* 707 */           is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     try {
/* 718 */       Enumeration e = cl.getResources("META-INF/javamail.address.map");
/* 719 */       while (e.hasMoreElements()) {
/* 720 */         URL url = (URL)e.nextElement();
/* 721 */         InputStream is = url.openStream();
/*     */         try
/*     */         {
/* 724 */           addressMap.load(is);
/*     */         } finally {
/* 726 */           is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     try {
/* 737 */       File file = new File(System.getProperty("java.home"), "lib/javamail.address.map");
/* 738 */       InputStream is = new FileInputStream(file);
/*     */       try
/*     */       {
/* 741 */         addressMap.load(is);
/*     */       } finally {
/* 743 */         is.close();
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e) {
/*     */     }
/*     */     try {
/* 752 */       Enumeration e = cl.getResources("META-INF/javamail.address.map");
/* 753 */       while (e.hasMoreElements()) {
/* 754 */         URL url = (URL)e.nextElement();
/* 755 */         InputStream is = url.openStream();
/*     */         try
/*     */         {
/* 758 */           addressMap.load(is);
/*     */         } finally {
/* 760 */           is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */ 
/* 771 */     if (addressMap.isEmpty()) {
/* 772 */       addressMap.put("rfc822", "smtp");
/*     */     }
/*     */ 
/* 775 */     return addressMap;
/*     */   }
/*     */ 
/*     */   private void writeDebug(String msg)
/*     */   {
/* 784 */     this.debugOut.println(msg);
/*     */   }
/*     */ 
/*     */   private static class ProviderInfo
/*     */   {
/* 789 */     private final Map byClassName = new HashMap();
/* 790 */     private final Map byProtocol = new HashMap();
/* 791 */     private final List all = new ArrayList();
/*     */ 
/*     */     public void addProvider(Provider provider) {
/* 794 */       String className = provider.getClassName();
/*     */ 
/* 796 */       if (!this.byClassName.containsKey(className)) {
/* 797 */         this.byClassName.put(className, provider);
/*     */       }
/*     */ 
/* 800 */       String protocol = provider.getProtocol();
/* 801 */       if (!this.byProtocol.containsKey(protocol)) {
/* 802 */         this.byProtocol.put(protocol, provider);
/*     */       }
/* 804 */       this.all.add(provider);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Session
 * JD-Core Version:    0.6.0
 */