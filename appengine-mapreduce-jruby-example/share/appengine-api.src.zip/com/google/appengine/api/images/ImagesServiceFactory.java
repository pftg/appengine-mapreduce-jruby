/*     */ package com.google.appengine.api.images;
/*     */ 
/*     */ import com.google.appengine.api.blobstore.BlobKey;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public final class ImagesServiceFactory
/*     */ {
/*     */   public static ImagesService getImagesService()
/*     */   {
/*  22 */     return new ImagesServiceImpl();
/*     */   }
/*     */ 
/*     */   public static Image makeImage(byte[] imageData)
/*     */   {
/*  32 */     return new ImageImpl(imageData);
/*     */   }
/*     */ 
/*     */   public static Image makeImageFromBlob(BlobKey blobKey)
/*     */   {
/*  46 */     return new ImageImpl(blobKey);
/*     */   }
/*     */ 
/*     */   public static Transform makeResize(int width, int height)
/*     */   {
/*  60 */     return new Resize(width, height);
/*     */   }
/*     */ 
/*     */   public static Transform makeCrop(float leftX, float topY, float rightX, float bottomY)
/*     */   {
/*  80 */     return new Crop(leftX, topY, rightX, bottomY);
/*     */   }
/*     */ 
/*     */   public static Transform makeCrop(double leftX, double topY, double rightX, double bottomY)
/*     */   {
/* 100 */     return makeCrop((float)leftX, (float)topY, (float)rightX, (float)bottomY);
/*     */   }
/*     */ 
/*     */   public static Transform makeVerticalFlip()
/*     */   {
/* 108 */     return new VerticalFlip();
/*     */   }
/*     */ 
/*     */   public static Transform makeHorizontalFlip()
/*     */   {
/* 116 */     return new HorizontalFlip();
/*     */   }
/*     */ 
/*     */   public static Transform makeRotate(int degrees)
/*     */   {
/* 129 */     return new Rotate(degrees);
/*     */   }
/*     */ 
/*     */   public static Transform makeImFeelingLucky()
/*     */   {
/* 139 */     return new ImFeelingLucky();
/*     */   }
/*     */ 
/*     */   public static CompositeTransform makeCompositeTransform(Collection<Transform> transforms)
/*     */   {
/* 151 */     return new CompositeTransform(transforms);
/*     */   }
/*     */ 
/*     */   public static CompositeTransform makeCompositeTransform()
/*     */   {
/* 160 */     return new CompositeTransform();
/*     */   }
/*     */ 
/*     */   public static Composite makeComposite(Image image, int xOffset, int yOffset, float opacity, Composite.Anchor anchor)
/*     */   {
/* 184 */     return new CompositeImpl(image, xOffset, yOffset, opacity, anchor);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImagesServiceFactory
 * JD-Core Version:    0.6.0
 */