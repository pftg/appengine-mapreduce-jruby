/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ public final class JID
/*    */ {
/*    */   private final String id;
/*    */ 
/*    */   public JID(String id)
/*    */   {
/* 16 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 20 */     return this.id;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 24 */     return "<JID: " + this.id + ">";
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.JID
 * JD-Core Version:    0.6.0
 */