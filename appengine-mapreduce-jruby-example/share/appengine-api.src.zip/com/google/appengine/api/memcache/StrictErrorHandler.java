/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ public class StrictErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/*    */   public void handleDeserializationError(InvalidValueException t)
/*    */   {
/* 19 */     throw t;
/*    */   }
/*    */ 
/*    */   public void handleServiceError(MemcacheServiceException t)
/*    */   {
/* 29 */     throw t;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.StrictErrorHandler
 * JD-Core Version:    0.6.0
 */