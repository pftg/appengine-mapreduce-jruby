/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.Beta;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ public final class Throwables
/*     */ {
/*     */   public static <X extends Throwable> void propagateIfInstanceOf(@Nullable Throwable throwable, Class<X> declaredType)
/*     */     throws Throwable
/*     */   {
/*  58 */     if (declaredType.isInstance(throwable))
/*  59 */       throw ((Throwable)declaredType.cast(throwable));
/*     */   }
/*     */ 
/*     */   public static void propagateIfPossible(@Nullable Throwable throwable)
/*     */   {
/*  78 */     propagateIfInstanceOf(throwable, Error.class);
/*  79 */     propagateIfInstanceOf(throwable, RuntimeException.class);
/*     */   }
/*     */ 
/*     */   public static <X extends Throwable> void propagateIfPossible(@Nullable Throwable throwable, Class<X> declaredType)
/*     */     throws Throwable
/*     */   {
/* 103 */     propagateIfInstanceOf(throwable, declaredType);
/* 104 */     propagateIfPossible(throwable);
/*     */   }
/*     */ 
/*     */   public static <X1 extends Throwable, X2 extends Throwable> void propagateIfPossible(@Nullable Throwable throwable, Class<X1> declaredType1, Class<X2> declaredType2)
/*     */     throws Throwable, Throwable
/*     */   {
/* 124 */     Preconditions.checkNotNull(declaredType2);
/* 125 */     propagateIfInstanceOf(throwable, declaredType1);
/* 126 */     propagateIfPossible(throwable, declaredType2);
/*     */   }
/*     */ 
/*     */   public static RuntimeException propagate(Throwable throwable)
/*     */   {
/* 154 */     propagateIfPossible((Throwable)Preconditions.checkNotNull(throwable));
/* 155 */     throw new RuntimeException(throwable);
/*     */   }
/*     */ 
/*     */   public static Throwable getRootCause(Throwable throwable)
/*     */   {
/*     */     Throwable cause;
/* 169 */     while ((cause = throwable.getCause()) != null) {
/* 170 */       throwable = cause;
/*     */     }
/* 172 */     return throwable;
/*     */   }
/*     */ 
/*     */   @Beta
/*     */   public static List<Throwable> getCausalChain(Throwable throwable)
/*     */   {
/* 194 */     Preconditions.checkNotNull(throwable);
/* 195 */     List causes = new ArrayList(4);
/* 196 */     while (throwable != null) {
/* 197 */       causes.add(throwable);
/* 198 */       throwable = throwable.getCause();
/*     */     }
/* 200 */     return Collections.unmodifiableList(causes);
/*     */   }
/*     */ 
/*     */   public static String getStackTraceAsString(Throwable throwable)
/*     */   {
/* 211 */     StringWriter stringWriter = new StringWriter();
/* 212 */     throwable.printStackTrace(new PrintWriter(stringWriter));
/* 213 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */   @Beta
/*     */   public static Exception throwCause(Exception exception, boolean combineStackTraces)
/*     */     throws Exception
/*     */   {
/* 231 */     Throwable cause = exception.getCause();
/* 232 */     if (cause == null) {
/* 233 */       throw exception;
/*     */     }
/* 235 */     if (combineStackTraces) {
/* 236 */       StackTraceElement[] causeTrace = cause.getStackTrace();
/* 237 */       StackTraceElement[] outerTrace = exception.getStackTrace();
/* 238 */       StackTraceElement[] combined = new StackTraceElement[causeTrace.length + outerTrace.length];
/*     */ 
/* 240 */       System.arraycopy(causeTrace, 0, combined, 0, causeTrace.length);
/* 241 */       System.arraycopy(outerTrace, 0, combined, causeTrace.length, outerTrace.length);
/*     */ 
/* 243 */       cause.setStackTrace(combined);
/*     */     }
/* 245 */     if ((cause instanceof Exception)) {
/* 246 */       throw ((Exception)cause);
/*     */     }
/* 248 */     if ((cause instanceof Error)) {
/* 249 */       throw ((Error)cause);
/*     */     }
/*     */ 
/* 252 */     throw exception;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Throwables
 * JD-Core Version:    0.6.0
 */