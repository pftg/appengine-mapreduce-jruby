/*    */ package com.google.appengine.api.utils;
/*    */ 
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.TimeoutException;
/*    */ 
/*    */ public abstract class FutureWrapper<K, V>
/*    */   implements Future<V>
/*    */ {
/*    */   private final Future<K> parent;
/*    */ 
/*    */   public FutureWrapper(Future<K> parent)
/*    */   {
/* 20 */     this.parent = parent;
/*    */   }
/*    */ 
/*    */   public boolean cancel(boolean mayInterruptIfRunning)
/*    */   {
/* 25 */     return this.parent.cancel(mayInterruptIfRunning);
/*    */   }
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 30 */     return this.parent.isCancelled();
/*    */   }
/*    */ 
/*    */   public boolean isDone()
/*    */   {
/* 35 */     return this.parent.isDone();
/*    */   }
/*    */ 
/*    */   public V get() throws InterruptedException, ExecutionException {
/*    */     Object data;
/*    */     try {
/* 42 */       data = this.parent.get();
/*    */     } catch (ExecutionException ex) {
/* 44 */       throw new ExecutionException(convertException(ex.getCause()));
/*    */     }
/*    */     try {
/* 47 */       return wrap(data); } catch (Exception ex) {
/*    */     }
/* 49 */     throw new ExecutionException(ex);
/*    */   }
/*    */ 
/*    */   public V get(long timeout, TimeUnit unit) throws InterruptedException, TimeoutException, ExecutionException
/*    */   {
/*    */     Object data;
/*    */     try
/*    */     {
/* 58 */       data = this.parent.get(timeout, unit);
/*    */     } catch (ExecutionException ex) {
/* 60 */       throw new ExecutionException(convertException(ex.getCause()));
/*    */     }
/*    */     try {
/* 63 */       return wrap(data); } catch (Exception ex) {
/*    */     }
/* 65 */     throw new ExecutionException(ex);
/*    */   }
/*    */ 
/*    */   public final int hashCode()
/*    */   {
/* 73 */     return super.hashCode();
/*    */   }
/*    */ 
/*    */   public final boolean equals(Object obj)
/*    */   {
/* 80 */     return super.equals(obj);
/*    */   }
/*    */ 
/*    */   protected abstract V wrap(K paramK)
/*    */     throws Exception;
/*    */ 
/*    */   protected abstract Throwable convertException(Throwable paramThrowable);
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.utils.FutureWrapper
 * JD-Core Version:    0.6.0
 */