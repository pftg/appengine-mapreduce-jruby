package com.google.appengine.repackaged.com.google.io.protocol;

public abstract interface MessageAppender
{
  public abstract void addLengthDelimited(int paramInt, byte[] paramArrayOfByte);

  public abstract void addMessage(int paramInt, ProtocolMessage paramProtocolMessage);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.MessageAppender
 * JD-Core Version:    0.6.0
 */