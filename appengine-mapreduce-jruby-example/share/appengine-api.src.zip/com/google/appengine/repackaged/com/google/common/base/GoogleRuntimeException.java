/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ 
/*     */ @GoogleInternal
/*     */ public class GoogleRuntimeException extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String internalMessage;
/*  22 */   private String externalMessage = "A system error has occurred";
/*     */ 
/*     */   public GoogleRuntimeException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GoogleRuntimeException(String internalMessage)
/*     */   {
/*  32 */     super(internalMessage);
/*  33 */     setInternalMessage(internalMessage);
/*     */   }
/*     */ 
/*     */   public GoogleRuntimeException(String externalMessage, Throwable t)
/*     */   {
/*  46 */     super(externalMessage, t);
/*  47 */     setInternalMessage(Throwables.getStackTraceAsString(t));
/*  48 */     setExternalMessage(externalMessage);
/*     */   }
/*     */ 
/*     */   public GoogleRuntimeException(GoogleException e)
/*     */   {
/*  63 */     super(e);
/*  64 */     setInternalMessage(e.getInternalMessage());
/*  65 */     setExternalMessage(e.getExternalMessage());
/*     */   }
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/*  74 */     return -999;
/*     */   }
/*     */ 
/*     */   public String getInternalMessage()
/*     */   {
/*  83 */     return this.internalMessage;
/*     */   }
/*     */ 
/*     */   public void setInternalMessage(String s) {
/*  87 */     this.internalMessage = s;
/*     */   }
/*     */ 
/*     */   public String getExternalMessage()
/*     */   {
/*  95 */     return this.externalMessage;
/*     */   }
/*     */ 
/*     */   public void setExternalMessage(String s) {
/*  99 */     this.externalMessage = s;
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 107 */     return getInternalMessage();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.GoogleRuntimeException
 * JD-Core Version:    0.6.0
 */