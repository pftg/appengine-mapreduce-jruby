/*     */ package com.google.appengine.api.xmpp;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ class XMPPServiceImpl
/*     */   implements XMPPService
/*     */ {
/*     */   static final String PACKAGE = "xmpp";
/*     */ 
/*     */   public Presence getPresence(JID jabberId)
/*     */   {
/*  29 */     return getPresence(jabberId, null);
/*     */   }
/*     */ 
/*     */   public Presence getPresence(JID jabberId, JID fromJid)
/*     */   {
/*  34 */     checkArgument(jabberId != null, "Jabber ID cannot be null");
/*     */ 
/*  36 */     XMPPServicePb.PresenceRequest request = new XMPPServicePb.PresenceRequest();
/*  37 */     request.setJid(jabberId.getId());
/*  38 */     if (fromJid != null)
/*  39 */       request.setFromJid(fromJid.getId());
/*     */     byte[] responseBytes;
/*     */     try
/*     */     {
/*  44 */       responseBytes = ApiProxy.makeSyncCall("xmpp", "GetPresence", request.toByteArray());
/*     */     } catch (ApiProxy.ApplicationException ex) {
/*  46 */       switch (1.$SwitchMap$com$google$appengine$api$xmpp$XMPPServicePb$XmppServiceError$ErrorCode[XMPPServicePb.XmppServiceError.ErrorCode.valueOf(ex.getApplicationError()).ordinal()]) {
/*     */       case 1:
/*  48 */         throw new IllegalArgumentException("Invalid jabber ID: " + jabberId);
/*     */       case 2:
/*     */       case 3:
/*     */       }
/*     */     }
/*  52 */     throw new XMPPFailureException("Unknown error retrieving presence for jabber ID: " + jabberId);
/*     */ 
/*  57 */     XMPPServicePb.PresenceResponse response = new XMPPServicePb.PresenceResponse();
/*  58 */     response.mergeFrom(responseBytes);
/*  59 */     return new Presence(response.isIsAvailable());
/*     */   }
/*     */ 
/*     */   public void sendInvitation(JID jabberId)
/*     */   {
/*  64 */     sendInvitation(jabberId, null);
/*     */   }
/*     */ 
/*     */   public void sendInvitation(JID jabberId, JID fromJid)
/*     */   {
/*  69 */     checkArgument(jabberId != null, "Jabber ID cannot be null");
/*  70 */     XMPPServicePb.XmppInviteRequest request = new XMPPServicePb.XmppInviteRequest();
/*  71 */     request.setJid(jabberId.getId());
/*  72 */     if (fromJid != null)
/*  73 */       request.setFromJid(fromJid.getId());
/*     */     byte[] responseBytes;
/*     */     try
/*     */     {
/*  78 */       responseBytes = ApiProxy.makeSyncCall("xmpp", "SendInvite", request.toByteArray());
/*     */     } catch (ApiProxy.ApplicationException ex) {
/*  80 */       switch (XMPPServicePb.XmppServiceError.ErrorCode.valueOf(ex.getApplicationError())) {
/*     */       case INVALID_JID:
/*  82 */         throw new IllegalArgumentException("Invalid jabber ID: " + jabberId);
/*     */       case UNSPECIFIED_ERROR:
/*     */       }
/*     */     }
/*  85 */     throw new XMPPFailureException("Unknown error sending invitation to jabber ID: " + jabberId);
/*     */ 
/*  90 */     XMPPServicePb.XmppInviteResponse response = new XMPPServicePb.XmppInviteResponse();
/*  91 */     response.mergeFrom(responseBytes);
/*     */   }
/*     */ 
/*     */   public SendResponse sendMessage(Message message)
/*     */   {
/*  99 */     checkArgument(message != null, "Message cannot be null");
/* 100 */     checkArgument((message.getBody() != null) && (!message.getBody().equals("")), "Body cannot be null or empty");
/*     */ 
/* 102 */     checkArgument((message.getRecipientJids() != null) && (message.getRecipientJids().length > 0), "Must provide at least one recipient");
/*     */ 
/* 105 */     XMPPServicePb.XmppMessageRequest request = createMessageRequest(message);
/* 106 */     XMPPServicePb.XmppMessageResponse response = doMessageRpc(request);
/* 107 */     return translateMessageResponse(response, message.getRecipientJids());
/*     */   }
/*     */ 
/*     */   public Message parseMessage(HttpServletRequest request) throws IOException {
/* 111 */     return InboundMessageParser.parseMessage(request);
/*     */   }
/*     */ 
/*     */   private XMPPServicePb.XmppMessageRequest createMessageRequest(Message message)
/*     */   {
/* 118 */     XMPPServicePb.XmppMessageRequest request = new XMPPServicePb.XmppMessageRequest();
/* 119 */     for (JID jabberId : message.getRecipientJids()) {
/* 120 */       request.addJid(jabberId.getId());
/*     */     }
/* 122 */     request.setBody(message.getBody());
/* 123 */     request.setRawXml(message.isXml());
/* 124 */     request.setType(message.getMessageType().getInternalName());
/* 125 */     if (message.getFromJid() != null) {
/* 126 */       request.setFromJid(message.getFromJid().getId());
/*     */     }
/* 128 */     return request;
/*     */   }
/*     */ 
/*     */   private SendResponse translateMessageResponse(XMPPServicePb.XmppMessageResponse response, JID[] jabberIds)
/*     */   {
/* 136 */     SendResponse retVal = new SendResponse();
/* 137 */     for (int i = 0; i < jabberIds.length; i++) {
/* 138 */       switch (1.$SwitchMap$com$google$appengine$api$xmpp$XMPPServicePb$XmppMessageResponse$XmppMessageStatus[XMPPServicePb.XmppMessageResponse.XmppMessageStatus.valueOf(response.getStatus(i)).ordinal()]) {
/*     */       case 1:
/* 140 */         retVal.addStatus(jabberIds[i], SendResponse.Status.INVALID_ID);
/* 141 */         break;
/*     */       case 2:
/* 143 */         retVal.addStatus(jabberIds[i], SendResponse.Status.SUCCESS);
/* 144 */         break;
/*     */       case 3:
/* 146 */         retVal.addStatus(jabberIds[i], SendResponse.Status.OTHER_ERROR);
/*     */       }
/*     */     }
/*     */ 
/* 150 */     return retVal;
/*     */   }
/*     */ 
/*     */   private XMPPServicePb.XmppMessageResponse doMessageRpc(XMPPServicePb.XmppMessageRequest request)
/*     */   {
/*     */     byte[] responseBytes;
/*     */     try
/*     */     {
/* 160 */       responseBytes = ApiProxy.makeSyncCall("xmpp", "SendMessage", request.toByteArray());
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 162 */       switch (1.$SwitchMap$com$google$appengine$api$xmpp$XMPPServicePb$XmppServiceError$ErrorCode[XMPPServicePb.XmppServiceError.ErrorCode.valueOf(ex.getApplicationError()).ordinal()])
/*     */       {
/*     */       case 1:
/* 167 */         throw new IllegalArgumentException("Invalid jabber ID");
/*     */       case 2:
/* 172 */         throw new IllegalArgumentException("Missing message body");
/*     */       case 4:
/*     */       case 5:
/* 174 */       case 3: }  } throw new IllegalArgumentException("XML was invalid");
/*     */ 
/* 176 */     throw new IllegalArgumentException("Type attribute is invalid");
/*     */ 
/* 179 */     throw new XMPPFailureException("Unknown error sending message");
/*     */ 
/* 183 */     XMPPServicePb.XmppMessageResponse response = new XMPPServicePb.XmppMessageResponse();
/* 184 */     response.mergeFrom(responseBytes);
/* 185 */     return response;
/*     */   }
/*     */ 
/*     */   private void checkArgument(boolean expression, String message)
/*     */   {
/* 192 */     if (!expression)
/* 193 */       throw new IllegalArgumentException(message);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.XMPPServiceImpl
 * JD-Core Version:    0.6.0
 */