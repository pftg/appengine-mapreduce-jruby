package com.google.appengine.api.datastore;

public abstract interface Transaction
{
  public abstract void commit();

  public abstract void rollback();

  public abstract String getId();

  public abstract String getApp();

  public abstract boolean isActive();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Transaction
 * JD-Core Version:    0.6.0
 */