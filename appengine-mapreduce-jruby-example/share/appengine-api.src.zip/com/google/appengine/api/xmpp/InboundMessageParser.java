/*     */ package com.google.appengine.api.xmpp;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.io.ByteStreams;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.ContentDisposition;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ class InboundMessageParser
/*     */ {
/*     */   static Message parseMessage(HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/*     */     IOException ex2;
/*     */     try
/*     */     {
/*  33 */       MimeMultipart multipart = parseMultipartRequest(request);
/*     */ 
/*  35 */       MessageBuilder builder = new MessageBuilder();
/*  36 */       builder.withMessageType(MessageType.CHAT);
/*     */ 
/*  38 */       int parts = multipart.getCount();
/*  39 */       for (int i = 0; i < parts; i++) {
/*  40 */         BodyPart part = multipart.getBodyPart(i);
/*  41 */         String fieldName = getFieldName(part);
/*  42 */         if ("from".equals(fieldName))
/*  43 */           builder.withFromJid(new JID(getTextContent(part)));
/*  44 */         else if ("to".equals(fieldName))
/*  45 */           builder.withRecipientJids(new JID[] { new JID(getTextContent(part)) });
/*  46 */         else if ("body".equals(fieldName))
/*  47 */           builder.withBody(getTextContent(part));
/*  48 */         else if ("stanza".equals(fieldName)) {
/*  49 */           builder.withStanza(getTextContent(part));
/*     */         }
/*     */       }
/*     */ 
/*  53 */       return builder.build();
/*     */     }
/*     */     catch (MessagingException ex) {
/*  56 */       ex2 = new IOException("Could not parse incoming request.");
/*  57 */       ex2.initCause(ex);
/*  58 */     }throw ex2;
/*     */   }
/*     */ 
/*     */   private static MimeMultipart parseMultipartRequest(HttpServletRequest req)
/*     */     throws IOException, MessagingException
/*     */   {
/*  64 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  65 */     ByteStreams.copy(req.getInputStream(), baos);
/*     */ 
/*  67 */     return new MimeMultipart(new StaticDataSource(req.getContentType(), baos.toByteArray()));
/*     */   }
/*     */ 
/*     */   private static String getFieldName(BodyPart part) throws MessagingException {
/*  71 */     String[] values = part.getHeader("Content-Disposition");
/*  72 */     String name = null;
/*  73 */     if ((values != null) && (values.length > 0)) {
/*  74 */       name = new ContentDisposition(values[0]).getParameter("name");
/*     */     }
/*  76 */     return name != null ? name : "unknown";
/*     */   }
/*     */ 
/*     */   private static String getTextContent(BodyPart part) throws MessagingException, IOException {
/*  80 */     ContentType contentType = new ContentType(part.getContentType());
/*  81 */     String charset = contentType.getParameter("charset");
/*  82 */     if (charset == null)
/*     */     {
/*  86 */       charset = "ISO-8859-1";
/*     */     }
/*     */ 
/*  89 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  90 */     ByteStreams.copy(part.getInputStream(), baos);
/*     */     try {
/*  92 */       return new String(baos.toByteArray(), charset); } catch (UnsupportedEncodingException ex) {
/*     */     }
/*  94 */     return new String(baos.toByteArray());
/*     */   }
/*     */ 
/*     */   private static class StaticDataSource
/*     */     implements DataSource
/*     */   {
/*     */     private final String contentType;
/*     */     private final byte[] bytes;
/*     */ 
/*     */     public StaticDataSource(String contentType, byte[] bytes)
/*     */     {
/* 107 */       this.contentType = contentType;
/* 108 */       this.bytes = bytes;
/*     */     }
/*     */ 
/*     */     public String getContentType() {
/* 112 */       return this.contentType;
/*     */     }
/*     */ 
/*     */     public InputStream getInputStream() {
/* 116 */       return new ByteArrayInputStream(this.bytes);
/*     */     }
/*     */ 
/*     */     public OutputStream getOutputStream() {
/* 120 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 124 */       return "request";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.InboundMessageParser
 * JD-Core Version:    0.6.0
 */