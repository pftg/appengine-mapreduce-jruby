/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ public final class CodedOutputStream
/*     */ {
/*     */   private final byte[] buffer;
/*     */   private final int limit;
/*     */   private int position;
/*     */   private final OutputStream output;
/*     */   public static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   public static final int LITTLE_ENDIAN_32_SIZE = 4;
/*     */   public static final int LITTLE_ENDIAN_64_SIZE = 8;
/*     */ 
/*     */   static int computePreferredBufferSize(int dataLength)
/*     */   {
/*  43 */     if (dataLength > 4096) return 4096;
/*  44 */     return dataLength;
/*     */   }
/*     */ 
/*     */   private CodedOutputStream(byte[] buffer, int offset, int length)
/*     */   {
/*  49 */     this.output = null;
/*  50 */     this.buffer = buffer;
/*  51 */     this.position = offset;
/*  52 */     this.limit = (offset + length);
/*     */   }
/*     */ 
/*     */   private CodedOutputStream(OutputStream output, byte[] buffer) {
/*  56 */     this.output = output;
/*  57 */     this.buffer = buffer;
/*  58 */     this.position = 0;
/*  59 */     this.limit = buffer.length;
/*     */   }
/*     */ 
/*     */   public static CodedOutputStream newInstance(OutputStream output)
/*     */   {
/*  67 */     return newInstance(output, 4096);
/*     */   }
/*     */ 
/*     */   public static CodedOutputStream newInstance(OutputStream output, int bufferSize)
/*     */   {
/*  76 */     return new CodedOutputStream(output, new byte[bufferSize]);
/*     */   }
/*     */ 
/*     */   public static CodedOutputStream newInstance(byte[] flatArray)
/*     */   {
/*  87 */     return newInstance(flatArray, 0, flatArray.length);
/*     */   }
/*     */ 
/*     */   public static CodedOutputStream newInstance(byte[] flatArray, int offset, int length)
/*     */   {
/* 100 */     return new CodedOutputStream(flatArray, offset, length);
/*     */   }
/*     */ 
/*     */   public void writeDouble(int fieldNumber, double value)
/*     */     throws IOException
/*     */   {
/* 108 */     writeTag(fieldNumber, 1);
/* 109 */     writeDoubleNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeFloat(int fieldNumber, float value)
/*     */     throws IOException
/*     */   {
/* 115 */     writeTag(fieldNumber, 5);
/* 116 */     writeFloatNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeUInt64(int fieldNumber, long value)
/*     */     throws IOException
/*     */   {
/* 122 */     writeTag(fieldNumber, 0);
/* 123 */     writeUInt64NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeInt64(int fieldNumber, long value)
/*     */     throws IOException
/*     */   {
/* 129 */     writeTag(fieldNumber, 0);
/* 130 */     writeInt64NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeInt32(int fieldNumber, int value)
/*     */     throws IOException
/*     */   {
/* 136 */     writeTag(fieldNumber, 0);
/* 137 */     writeInt32NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeFixed64(int fieldNumber, long value)
/*     */     throws IOException
/*     */   {
/* 143 */     writeTag(fieldNumber, 1);
/* 144 */     writeFixed64NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeFixed32(int fieldNumber, int value)
/*     */     throws IOException
/*     */   {
/* 150 */     writeTag(fieldNumber, 5);
/* 151 */     writeFixed32NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeBool(int fieldNumber, boolean value)
/*     */     throws IOException
/*     */   {
/* 157 */     writeTag(fieldNumber, 0);
/* 158 */     writeBoolNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeString(int fieldNumber, String value)
/*     */     throws IOException
/*     */   {
/* 164 */     writeTag(fieldNumber, 2);
/* 165 */     writeStringNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeGroup(int fieldNumber, MessageLite value)
/*     */     throws IOException
/*     */   {
/* 171 */     writeTag(fieldNumber, 3);
/* 172 */     writeGroupNoTag(value);
/* 173 */     writeTag(fieldNumber, 4);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void writeUnknownGroup(int fieldNumber, MessageLite value)
/*     */     throws IOException
/*     */   {
/* 186 */     writeGroup(fieldNumber, value);
/*     */   }
/*     */ 
/*     */   public void writeMessage(int fieldNumber, MessageLite value)
/*     */     throws IOException
/*     */   {
/* 192 */     writeTag(fieldNumber, 2);
/* 193 */     writeMessageNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeBytes(int fieldNumber, ByteString value)
/*     */     throws IOException
/*     */   {
/* 199 */     writeTag(fieldNumber, 2);
/* 200 */     writeBytesNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeUInt32(int fieldNumber, int value)
/*     */     throws IOException
/*     */   {
/* 206 */     writeTag(fieldNumber, 0);
/* 207 */     writeUInt32NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeEnum(int fieldNumber, int value)
/*     */     throws IOException
/*     */   {
/* 216 */     writeTag(fieldNumber, 0);
/* 217 */     writeEnumNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeSFixed32(int fieldNumber, int value)
/*     */     throws IOException
/*     */   {
/* 223 */     writeTag(fieldNumber, 5);
/* 224 */     writeSFixed32NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeSFixed64(int fieldNumber, long value)
/*     */     throws IOException
/*     */   {
/* 230 */     writeTag(fieldNumber, 1);
/* 231 */     writeSFixed64NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeSInt32(int fieldNumber, int value)
/*     */     throws IOException
/*     */   {
/* 237 */     writeTag(fieldNumber, 0);
/* 238 */     writeSInt32NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeSInt64(int fieldNumber, long value)
/*     */     throws IOException
/*     */   {
/* 244 */     writeTag(fieldNumber, 0);
/* 245 */     writeSInt64NoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeMessageSetExtension(int fieldNumber, MessageLite value)
/*     */     throws IOException
/*     */   {
/* 255 */     writeTag(1, 3);
/* 256 */     writeUInt32(2, fieldNumber);
/* 257 */     writeMessage(3, value);
/* 258 */     writeTag(1, 4);
/*     */   }
/*     */ 
/*     */   public void writeRawMessageSetExtension(int fieldNumber, ByteString value)
/*     */     throws IOException
/*     */   {
/* 268 */     writeTag(1, 3);
/* 269 */     writeUInt32(2, fieldNumber);
/* 270 */     writeBytes(3, value);
/* 271 */     writeTag(1, 4);
/*     */   }
/*     */ 
/*     */   public void writeDoubleNoTag(double value)
/*     */     throws IOException
/*     */   {
/* 278 */     writeRawLittleEndian64(Double.doubleToRawLongBits(value));
/*     */   }
/*     */ 
/*     */   public void writeFloatNoTag(float value) throws IOException
/*     */   {
/* 283 */     writeRawLittleEndian32(Float.floatToRawIntBits(value));
/*     */   }
/*     */ 
/*     */   public void writeUInt64NoTag(long value) throws IOException
/*     */   {
/* 288 */     writeRawVarint64(value);
/*     */   }
/*     */ 
/*     */   public void writeInt64NoTag(long value) throws IOException
/*     */   {
/* 293 */     writeRawVarint64(value);
/*     */   }
/*     */ 
/*     */   public void writeInt32NoTag(int value) throws IOException
/*     */   {
/* 298 */     if (value >= 0) {
/* 299 */       writeRawVarint32(value);
/*     */     }
/*     */     else
/* 302 */       writeRawVarint64(value);
/*     */   }
/*     */ 
/*     */   public void writeFixed64NoTag(long value)
/*     */     throws IOException
/*     */   {
/* 308 */     writeRawLittleEndian64(value);
/*     */   }
/*     */ 
/*     */   public void writeFixed32NoTag(int value) throws IOException
/*     */   {
/* 313 */     writeRawLittleEndian32(value);
/*     */   }
/*     */ 
/*     */   public void writeBoolNoTag(boolean value) throws IOException
/*     */   {
/* 318 */     writeRawByte(value ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public void writeStringNoTag(String value)
/*     */     throws IOException
/*     */   {
/* 326 */     byte[] bytes = value.getBytes("UTF-8");
/* 327 */     writeRawVarint32(bytes.length);
/* 328 */     writeRawBytes(bytes);
/*     */   }
/*     */ 
/*     */   public void writeGroupNoTag(MessageLite value) throws IOException
/*     */   {
/* 333 */     value.writeTo(this);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void writeUnknownGroupNoTag(MessageLite value)
/*     */     throws IOException
/*     */   {
/* 345 */     writeGroupNoTag(value);
/*     */   }
/*     */ 
/*     */   public void writeMessageNoTag(MessageLite value) throws IOException
/*     */   {
/* 350 */     writeRawVarint32(value.getSerializedSize());
/* 351 */     value.writeTo(this);
/*     */   }
/*     */ 
/*     */   public void writeBytesNoTag(ByteString value) throws IOException
/*     */   {
/* 356 */     byte[] bytes = value.toByteArray();
/* 357 */     writeRawVarint32(bytes.length);
/* 358 */     writeRawBytes(bytes);
/*     */   }
/*     */ 
/*     */   public void writeUInt32NoTag(int value) throws IOException
/*     */   {
/* 363 */     writeRawVarint32(value);
/*     */   }
/*     */ 
/*     */   public void writeEnumNoTag(int value)
/*     */     throws IOException
/*     */   {
/* 371 */     writeRawVarint32(value);
/*     */   }
/*     */ 
/*     */   public void writeSFixed32NoTag(int value) throws IOException
/*     */   {
/* 376 */     writeRawLittleEndian32(value);
/*     */   }
/*     */ 
/*     */   public void writeSFixed64NoTag(long value) throws IOException
/*     */   {
/* 381 */     writeRawLittleEndian64(value);
/*     */   }
/*     */ 
/*     */   public void writeSInt32NoTag(int value) throws IOException
/*     */   {
/* 386 */     writeRawVarint32(encodeZigZag32(value));
/*     */   }
/*     */ 
/*     */   public void writeSInt64NoTag(long value) throws IOException
/*     */   {
/* 391 */     writeRawVarint64(encodeZigZag64(value));
/*     */   }
/*     */ 
/*     */   public static int computeDoubleSize(int fieldNumber, double value)
/*     */   {
/* 402 */     return computeTagSize(fieldNumber) + computeDoubleSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeFloatSize(int fieldNumber, float value)
/*     */   {
/* 410 */     return computeTagSize(fieldNumber) + computeFloatSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeUInt64Size(int fieldNumber, long value)
/*     */   {
/* 418 */     return computeTagSize(fieldNumber) + computeUInt64SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeInt64Size(int fieldNumber, long value)
/*     */   {
/* 426 */     return computeTagSize(fieldNumber) + computeInt64SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeInt32Size(int fieldNumber, int value)
/*     */   {
/* 434 */     return computeTagSize(fieldNumber) + computeInt32SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeFixed64Size(int fieldNumber, long value)
/*     */   {
/* 443 */     return computeTagSize(fieldNumber) + computeFixed64SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeFixed32Size(int fieldNumber, int value)
/*     */   {
/* 452 */     return computeTagSize(fieldNumber) + computeFixed32SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeBoolSize(int fieldNumber, boolean value)
/*     */   {
/* 461 */     return computeTagSize(fieldNumber) + computeBoolSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeStringSize(int fieldNumber, String value)
/*     */   {
/* 470 */     return computeTagSize(fieldNumber) + computeStringSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeGroupSize(int fieldNumber, MessageLite value)
/*     */   {
/* 479 */     return computeTagSize(fieldNumber) * 2 + computeGroupSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static int computeUnknownGroupSize(int fieldNumber, MessageLite value)
/*     */   {
/* 493 */     return computeGroupSize(fieldNumber, value);
/*     */   }
/*     */ 
/*     */   public static int computeMessageSize(int fieldNumber, MessageLite value)
/*     */   {
/* 502 */     return computeTagSize(fieldNumber) + computeMessageSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeBytesSize(int fieldNumber, ByteString value)
/*     */   {
/* 511 */     return computeTagSize(fieldNumber) + computeBytesSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeUInt32Size(int fieldNumber, int value)
/*     */   {
/* 519 */     return computeTagSize(fieldNumber) + computeUInt32SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeEnumSize(int fieldNumber, int value)
/*     */   {
/* 528 */     return computeTagSize(fieldNumber) + computeEnumSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeSFixed32Size(int fieldNumber, int value)
/*     */   {
/* 537 */     return computeTagSize(fieldNumber) + computeSFixed32SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeSFixed64Size(int fieldNumber, long value)
/*     */   {
/* 546 */     return computeTagSize(fieldNumber) + computeSFixed64SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeSInt32Size(int fieldNumber, int value)
/*     */   {
/* 554 */     return computeTagSize(fieldNumber) + computeSInt32SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeSInt64Size(int fieldNumber, long value)
/*     */   {
/* 562 */     return computeTagSize(fieldNumber) + computeSInt64SizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeMessageSetExtensionSize(int fieldNumber, MessageLite value)
/*     */   {
/* 572 */     return computeTagSize(1) * 2 + computeUInt32Size(2, fieldNumber) + computeMessageSize(3, value);
/*     */   }
/*     */ 
/*     */   public static int computeRawMessageSetExtensionSize(int fieldNumber, ByteString value)
/*     */   {
/* 584 */     return computeTagSize(1) * 2 + computeUInt32Size(2, fieldNumber) + computeBytesSize(3, value);
/*     */   }
/*     */ 
/*     */   public static int computeDoubleSizeNoTag(double value)
/*     */   {
/* 596 */     return 8;
/*     */   }
/*     */ 
/*     */   public static int computeFloatSizeNoTag(float value)
/*     */   {
/* 604 */     return 4;
/*     */   }
/*     */ 
/*     */   public static int computeUInt64SizeNoTag(long value)
/*     */   {
/* 612 */     return computeRawVarint64Size(value);
/*     */   }
/*     */ 
/*     */   public static int computeInt64SizeNoTag(long value)
/*     */   {
/* 620 */     return computeRawVarint64Size(value);
/*     */   }
/*     */ 
/*     */   public static int computeInt32SizeNoTag(int value)
/*     */   {
/* 628 */     if (value >= 0) {
/* 629 */       return computeRawVarint32Size(value);
/*     */     }
/*     */ 
/* 632 */     return 10;
/*     */   }
/*     */ 
/*     */   public static int computeFixed64SizeNoTag(long value)
/*     */   {
/* 641 */     return 8;
/*     */   }
/*     */ 
/*     */   public static int computeFixed32SizeNoTag(int value)
/*     */   {
/* 649 */     return 4;
/*     */   }
/*     */ 
/*     */   public static int computeBoolSizeNoTag(boolean value)
/*     */   {
/* 657 */     return 1;
/*     */   }
/*     */ 
/*     */   public static int computeStringSizeNoTag(String value)
/*     */   {
/*     */     try
/*     */     {
/* 666 */       byte[] bytes = value.getBytes("UTF-8");
/* 667 */       return computeRawVarint32Size(bytes.length) + bytes.length;
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 670 */     throw new RuntimeException("UTF-8 not supported.", e);
/*     */   }
/*     */ 
/*     */   public static int computeGroupSizeNoTag(MessageLite value)
/*     */   {
/* 679 */     return value.getSerializedSize();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static int computeUnknownGroupSizeNoTag(MessageLite value)
/*     */   {
/* 692 */     return computeGroupSizeNoTag(value);
/*     */   }
/*     */ 
/*     */   public static int computeMessageSizeNoTag(MessageLite value)
/*     */   {
/* 700 */     int size = value.getSerializedSize();
/* 701 */     return computeRawVarint32Size(size) + size;
/*     */   }
/*     */ 
/*     */   public static int computeBytesSizeNoTag(ByteString value)
/*     */   {
/* 709 */     return computeRawVarint32Size(value.size()) + value.size();
/*     */   }
/*     */ 
/*     */   public static int computeUInt32SizeNoTag(int value)
/*     */   {
/* 718 */     return computeRawVarint32Size(value);
/*     */   }
/*     */ 
/*     */   public static int computeEnumSizeNoTag(int value)
/*     */   {
/* 726 */     return computeRawVarint32Size(value);
/*     */   }
/*     */ 
/*     */   public static int computeSFixed32SizeNoTag(int value)
/*     */   {
/* 734 */     return 4;
/*     */   }
/*     */ 
/*     */   public static int computeSFixed64SizeNoTag(long value)
/*     */   {
/* 742 */     return 8;
/*     */   }
/*     */ 
/*     */   public static int computeSInt32SizeNoTag(int value)
/*     */   {
/* 750 */     return computeRawVarint32Size(encodeZigZag32(value));
/*     */   }
/*     */ 
/*     */   public static int computeSInt64SizeNoTag(long value)
/*     */   {
/* 758 */     return computeRawVarint64Size(encodeZigZag64(value));
/*     */   }
/*     */ 
/*     */   private void refreshBuffer()
/*     */     throws IOException
/*     */   {
/* 768 */     if (this.output == null)
/*     */     {
/* 770 */       throw new OutOfSpaceException();
/*     */     }
/*     */ 
/* 775 */     this.output.write(this.buffer, 0, this.position);
/* 776 */     this.position = 0;
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 784 */     if (this.output != null)
/* 785 */       refreshBuffer();
/*     */   }
/*     */ 
/*     */   public int spaceLeft()
/*     */   {
/* 794 */     if (this.output == null) {
/* 795 */       return this.limit - this.position;
/*     */     }
/* 797 */     throw new UnsupportedOperationException("spaceLeft() can only be called on CodedOutputStreams that are writing to a flat array.");
/*     */   }
/*     */ 
/*     */   public void checkNoSpaceLeft()
/*     */   {
/* 811 */     if (spaceLeft() != 0)
/* 812 */       throw new IllegalStateException("Did not write as much data as expected.");
/*     */   }
/*     */ 
/*     */   public void writeRawByte(byte value)
/*     */     throws IOException
/*     */   {
/* 833 */     if (this.position == this.limit) {
/* 834 */       refreshBuffer();
/*     */     }
/*     */ 
/* 837 */     this.buffer[(this.position++)] = value;
/*     */   }
/*     */ 
/*     */   public void writeRawByte(int value) throws IOException
/*     */   {
/* 842 */     writeRawByte((byte)value);
/*     */   }
/*     */ 
/*     */   public void writeRawBytes(byte[] value) throws IOException
/*     */   {
/* 847 */     writeRawBytes(value, 0, value.length);
/*     */   }
/*     */ 
/*     */   public void writeRawBytes(byte[] value, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 853 */     if (this.limit - this.position >= length)
/*     */     {
/* 855 */       System.arraycopy(value, offset, this.buffer, this.position, length);
/* 856 */       this.position += length;
/*     */     }
/*     */     else
/*     */     {
/* 860 */       int bytesWritten = this.limit - this.position;
/* 861 */       System.arraycopy(value, offset, this.buffer, this.position, bytesWritten);
/* 862 */       offset += bytesWritten;
/* 863 */       length -= bytesWritten;
/* 864 */       this.position = this.limit;
/* 865 */       refreshBuffer();
/*     */ 
/* 870 */       if (length <= this.limit)
/*     */       {
/* 872 */         System.arraycopy(value, offset, this.buffer, 0, length);
/* 873 */         this.position = length;
/*     */       }
/*     */       else {
/* 876 */         this.output.write(value, offset, length);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeTag(int fieldNumber, int wireType)
/*     */     throws IOException
/*     */   {
/* 884 */     writeRawVarint32(WireFormat.makeTag(fieldNumber, wireType));
/*     */   }
/*     */ 
/*     */   public static int computeTagSize(int fieldNumber)
/*     */   {
/* 889 */     return computeRawVarint32Size(WireFormat.makeTag(fieldNumber, 0));
/*     */   }
/*     */ 
/*     */   public void writeRawVarint32(int value)
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/* 898 */       if ((value & 0xFFFFFF80) == 0) {
/* 899 */         writeRawByte(value);
/* 900 */         return;
/*     */       }
/* 902 */       writeRawByte(value & 0x7F | 0x80);
/* 903 */       value >>>= 7;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int computeRawVarint32Size(int value)
/*     */   {
/* 914 */     if ((value & 0xFFFFFF80) == 0) return 1;
/* 915 */     if ((value & 0xFFFFC000) == 0) return 2;
/* 916 */     if ((value & 0xFFE00000) == 0) return 3;
/* 917 */     if ((value & 0xF0000000) == 0) return 4;
/* 918 */     return 5;
/*     */   }
/*     */ 
/*     */   public void writeRawVarint64(long value) throws IOException
/*     */   {
/*     */     while (true) {
/* 924 */       if ((value & 0xFFFFFF80) == 0L) {
/* 925 */         writeRawByte((int)value);
/* 926 */         return;
/*     */       }
/* 928 */       writeRawByte((int)value & 0x7F | 0x80);
/* 929 */       value >>>= 7;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int computeRawVarint64Size(long value)
/*     */   {
/* 936 */     if ((value & 0xFFFFFF80) == 0L) return 1;
/* 937 */     if ((value & 0xFFFFC000) == 0L) return 2;
/* 938 */     if ((value & 0xFFE00000) == 0L) return 3;
/* 939 */     if ((value & 0xF0000000) == 0L) return 4;
/* 940 */     if ((value & 0x0) == 0L) return 5;
/* 941 */     if ((value & 0x0) == 0L) return 6;
/* 942 */     if ((value & 0x0) == 0L) return 7;
/* 943 */     if ((value & 0x0) == 0L) return 8;
/* 944 */     if ((value & 0x0) == 0L) return 9;
/* 945 */     return 10;
/*     */   }
/*     */ 
/*     */   public void writeRawLittleEndian32(int value) throws IOException
/*     */   {
/* 950 */     writeRawByte(value & 0xFF);
/* 951 */     writeRawByte(value >> 8 & 0xFF);
/* 952 */     writeRawByte(value >> 16 & 0xFF);
/* 953 */     writeRawByte(value >> 24 & 0xFF);
/*     */   }
/*     */ 
/*     */   public void writeRawLittleEndian64(long value)
/*     */     throws IOException
/*     */   {
/* 960 */     writeRawByte((int)value & 0xFF);
/* 961 */     writeRawByte((int)(value >> 8) & 0xFF);
/* 962 */     writeRawByte((int)(value >> 16) & 0xFF);
/* 963 */     writeRawByte((int)(value >> 24) & 0xFF);
/* 964 */     writeRawByte((int)(value >> 32) & 0xFF);
/* 965 */     writeRawByte((int)(value >> 40) & 0xFF);
/* 966 */     writeRawByte((int)(value >> 48) & 0xFF);
/* 967 */     writeRawByte((int)(value >> 56) & 0xFF);
/*     */   }
/*     */ 
/*     */   public static int encodeZigZag32(int n)
/*     */   {
/* 984 */     return n << 1 ^ n >> 31;
/*     */   }
/*     */ 
/*     */   public static long encodeZigZag64(long n)
/*     */   {
/* 999 */     return n << 1 ^ n >> 63;
/*     */   }
/*     */ 
/*     */   public static class OutOfSpaceException extends IOException
/*     */   {
/*     */     private static final long serialVersionUID = -6947486886997889499L;
/*     */ 
/*     */     OutOfSpaceException()
/*     */     {
/* 826 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream
 * JD-Core Version:    0.6.0
 */