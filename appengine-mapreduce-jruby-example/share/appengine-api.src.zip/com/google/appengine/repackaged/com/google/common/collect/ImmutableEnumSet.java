/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ final class ImmutableEnumSet<E extends Enum<E>> extends ImmutableSet<E>
/*     */ {
/*     */   private final transient EnumSet<E> delegate;
/*     */   private transient int hashCode;
/*     */ 
/*     */   ImmutableEnumSet(EnumSet<E> delegate)
/*     */   {
/*  45 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   public UnmodifiableIterator<E> iterator() {
/*  49 */     return Iterators.unmodifiableIterator(this.delegate.iterator());
/*     */   }
/*     */ 
/*     */   public int size() {
/*  53 */     return this.delegate.size();
/*     */   }
/*     */ 
/*     */   public boolean contains(Object object) {
/*  57 */     return this.delegate.contains(object);
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection<?> collection) {
/*  61 */     return this.delegate.containsAll(collection);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  65 */     return this.delegate.isEmpty();
/*     */   }
/*     */ 
/*     */   public Object[] toArray() {
/*  69 */     return this.delegate.toArray();
/*     */   }
/*     */ 
/*     */   public <T> T[] toArray(T[] array) {
/*  73 */     return this.delegate.toArray(array);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/*  77 */     return (object == this) || (this.delegate.equals(object));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  83 */     int result = this.hashCode;
/*  84 */     return result == 0 ? (this.hashCode = this.delegate.hashCode()) : result;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  88 */     return this.delegate.toString();
/*     */   }
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/*  93 */     return new EnumSerializedForm(this.delegate);
/*     */   }
/*     */ 
/*     */   private static class EnumSerializedForm<E extends Enum<E>> implements Serializable {
/*     */     final EnumSet<E> delegate;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     EnumSerializedForm(EnumSet<E> delegate) {
/* 103 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     Object readResolve() {
/* 107 */       return new ImmutableEnumSet(this.delegate.clone());
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableEnumSet
 * JD-Core Version:    0.6.0
 */