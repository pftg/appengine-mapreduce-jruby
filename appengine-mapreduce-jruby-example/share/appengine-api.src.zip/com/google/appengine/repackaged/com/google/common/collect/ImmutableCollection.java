/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Joiner;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(emulated=true)
/*     */ public abstract class ImmutableCollection<E>
/*     */   implements Collection<E>, Serializable
/*     */ {
/*  44 */   static final ImmutableCollection<Object> EMPTY_IMMUTABLE_COLLECTION = new EmptyImmutableCollection(null);
/*     */   private transient ImmutableList<E> asList;
/*     */ 
/*     */   public abstract UnmodifiableIterator<E> iterator();
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/*  55 */     Object[] newArray = new Object[size()];
/*  56 */     return toArray(newArray);
/*     */   }
/*     */ 
/*     */   public <T> T[] toArray(T[] other) {
/*  60 */     int size = size();
/*  61 */     if (other.length < size)
/*  62 */       other = ObjectArrays.newArray(other, size);
/*  63 */     else if (other.length > size) {
/*  64 */       other[size] = null;
/*     */     }
/*     */ 
/*  68 */     Object[] otherAsObjectArray = other;
/*  69 */     int index = 0;
/*  70 */     for (Iterator i$ = iterator(); i$.hasNext(); ) { Object element = i$.next();
/*  71 */       otherAsObjectArray[(index++)] = element;
/*     */     }
/*  73 */     return other;
/*     */   }
/*     */ 
/*     */   public boolean contains(@Nullable Object object) {
/*  77 */     if (object == null) {
/*  78 */       return false;
/*     */     }
/*  80 */     for (Iterator i$ = iterator(); i$.hasNext(); ) { Object element = i$.next();
/*  81 */       if (element.equals(object)) {
/*  82 */         return true;
/*     */       }
/*     */     }
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection<?> targets) {
/*  89 */     for (Iterator i$ = targets.iterator(); i$.hasNext(); ) { Object target = i$.next();
/*  90 */       if (!contains(target)) {
/*  91 */         return false;
/*     */       }
/*     */     }
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  98 */     return size() == 0;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 102 */     StringBuilder sb = new StringBuilder(size() * 16).append('[');
/* 103 */     Collections2.standardJoiner.appendTo(sb, this);
/* 104 */     return ']';
/*     */   }
/*     */ 
/*     */   public final boolean add(E e)
/*     */   {
/* 113 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final boolean remove(Object object)
/*     */   {
/* 122 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final boolean addAll(Collection<? extends E> newElements)
/*     */   {
/* 131 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final boolean removeAll(Collection<?> oldElements)
/*     */   {
/* 140 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final boolean retainAll(Collection<?> elementsToKeep)
/*     */   {
/* 149 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final void clear()
/*     */   {
/* 158 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=false)
/*     */   public ImmutableList<E> asList()
/*     */   {
/* 172 */     ImmutableList list = this.asList;
/* 173 */     return list == null ? (this.asList = createAsList()) : list;
/*     */   }
/*     */ 
/*     */   ImmutableList<E> createAsList() {
/* 177 */     switch (size()) {
/*     */     case 0:
/* 179 */       return ImmutableList.of();
/*     */     case 1:
/* 181 */       return ImmutableList.of(iterator().next());
/*     */     }
/* 183 */     return new ImmutableAsList(toArray(), this);
/*     */   }
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 258 */     return new SerializedForm(toArray());
/*     */   }
/*     */ 
/*     */   static abstract class Builder<E>
/*     */   {
/*     */     public abstract Builder<E> add(E paramE);
/*     */ 
/*     */     public Builder<E> add(E[] elements)
/*     */     {
/* 290 */       for (Object element : elements) {
/* 291 */         add(element);
/*     */       }
/* 293 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterable<? extends E> elements)
/*     */     {
/* 309 */       for (Iterator i$ = elements.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 310 */         add(element);
/*     */       }
/* 312 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterator<? extends E> elements)
/*     */     {
/* 328 */       while (elements.hasNext()) {
/* 329 */         add(elements.next());
/*     */       }
/* 331 */       return this;
/*     */     }
/*     */ 
/*     */     public abstract ImmutableCollection<E> build();
/*     */   }
/*     */ 
/*     */   private static class SerializedForm
/*     */     implements Serializable
/*     */   {
/*     */     final Object[] elements;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SerializedForm(Object[] elements)
/*     */     {
/* 247 */       this.elements = elements;
/*     */     }
/*     */     Object readResolve() {
/* 250 */       return this.elements.length == 0 ? ImmutableCollection.EMPTY_IMMUTABLE_COLLECTION : new ImmutableCollection.ArrayImmutableCollection(Platform.clone(this.elements));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ArrayImmutableCollection<E> extends ImmutableCollection<E>
/*     */   {
/*     */     private final E[] elements;
/*     */ 
/*     */     ArrayImmutableCollection(E[] elements)
/*     */     {
/* 224 */       this.elements = elements;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 228 */       return this.elements.length;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 232 */       return false;
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<E> iterator() {
/* 236 */       return Iterators.forArray(this.elements);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EmptyImmutableCollection extends ImmutableCollection<Object>
/*     */   {
/* 205 */     private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */ 
/*     */     public int size()
/*     */     {
/* 190 */       return 0;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 194 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean contains(@Nullable Object object) {
/* 198 */       return false;
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<Object> iterator() {
/* 202 */       return Iterators.EMPTY_ITERATOR;
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 208 */       return EMPTY_ARRAY;
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 212 */       if (array.length > 0) {
/* 213 */         array[0] = null;
/*     */       }
/* 215 */       return array;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableCollection
 * JD-Core Version:    0.6.0
 */