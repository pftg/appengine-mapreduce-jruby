/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ final class Rotate extends Transform
/*    */ {
/*    */   private final int degrees;
/*    */ 
/*    */   Rotate(int degrees)
/*    */   {
/* 20 */     if (degrees % 90 != 0) {
/* 21 */       throw new IllegalArgumentException("degrees must be a multiple of 90");
/*    */     }
/*    */ 
/* 25 */     this.degrees = ((degrees % 360 + 360) % 360);
/*    */   }
/*    */ 
/*    */   void apply(ImagesServicePb.ImagesTransformRequest request)
/*    */   {
/* 30 */     ImagesServicePb.Transform transform = request.addTransform();
/* 31 */     transform.setRotate(this.degrees);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.Rotate
 * JD-Core Version:    0.6.0
 */