/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Predicate;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Comparator;
/*     */ import java.util.SortedSet;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public class Range<C extends Comparable>
/*     */ {
/*     */   final Cut<C> lowerBound;
/*     */   final Cut<C> upperBound;
/*     */ 
/*     */   Range(Cut<C> lowerBound, Cut<C> upperBound)
/*     */   {
/* 129 */     Preconditions.checkArgument(lowerBound.compareTo(upperBound) <= 0);
/* 130 */     this.lowerBound = lowerBound;
/* 131 */     this.upperBound = upperBound;
/*     */   }
/*     */ 
/*     */   public boolean hasLowerBound()
/*     */   {
/* 138 */     return this.lowerBound != Cut.BELOW_ALL;
/*     */   }
/*     */ 
/*     */   public C lowerEndpoint()
/*     */   {
/* 148 */     return this.lowerBound.endpoint();
/*     */   }
/*     */ 
/*     */   public BoundType lowerBoundType()
/*     */   {
/* 160 */     return this.lowerBound.typeAsLowerBound();
/*     */   }
/*     */ 
/*     */   public boolean hasUpperBound()
/*     */   {
/* 167 */     return this.upperBound != Cut.ABOVE_ALL;
/*     */   }
/*     */ 
/*     */   public C upperEndpoint()
/*     */   {
/* 177 */     return this.upperBound.endpoint();
/*     */   }
/*     */ 
/*     */   public BoundType upperBoundType()
/*     */   {
/* 189 */     return this.upperBound.typeAsUpperBound();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 202 */     return this.lowerBound.equals(this.upperBound);
/*     */   }
/*     */ 
/*     */   public boolean contains(C value)
/*     */   {
/* 211 */     Preconditions.checkNotNull(value);
/*     */ 
/* 213 */     return (this.lowerBound.isLessThan(value)) && (!this.upperBound.isLessThan(value));
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Iterable<? extends C> values)
/*     */   {
/* 221 */     if (Iterables.isEmpty(values)) {
/* 222 */       return true;
/*     */     }
/*     */ 
/* 226 */     if ((values instanceof SortedSet))
/*     */     {
/* 228 */       SortedSet set = (SortedSet)values;
/* 229 */       Comparator comparator = set.comparator();
/* 230 */       if ((Ordering.natural().equals(comparator)) || (comparator == null)) {
/* 231 */         return (contains((Comparable)set.first())) && (contains((Comparable)set.last()));
/*     */       }
/*     */     }
/*     */ 
/* 235 */     for (Comparable value : values) {
/* 236 */       if (!contains(value)) {
/* 237 */         return false;
/*     */       }
/*     */     }
/* 240 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean encloses(Range<C> other)
/*     */   {
/* 280 */     return (this.lowerBound.compareTo(other.lowerBound) <= 0) && (this.upperBound.compareTo(other.upperBound) >= 0);
/*     */   }
/*     */ 
/*     */   public Range<C> intersection(Range<C> other)
/*     */   {
/* 307 */     Cut newLower = (Cut)Ordering.natural().max(this.lowerBound, other.lowerBound);
/* 308 */     Cut newUpper = (Cut)Ordering.natural().min(this.upperBound, other.upperBound);
/* 309 */     return create(newLower, newUpper);
/*     */   }
/*     */ 
/*     */   public Range<C> span(Range<C> other)
/*     */   {
/* 329 */     Cut newLower = (Cut)Ordering.natural().min(this.lowerBound, other.lowerBound);
/* 330 */     Cut newUpper = (Cut)Ordering.natural().max(this.upperBound, other.upperBound);
/* 331 */     return create(newLower, newUpper);
/*     */   }
/*     */ 
/*     */   Range<C> create(Cut<C> lower, Cut<C> upper) {
/* 335 */     return new Range(lower, upper);
/*     */   }
/*     */ 
/*     */   public Predicate<C> asPredicate()
/*     */   {
/* 343 */     return new Predicate() {
/*     */       public boolean apply(C input) {
/* 345 */         return Range.this.contains(input);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object)
/*     */   {
/* 360 */     if ((object instanceof Range)) {
/* 361 */       Range other = (Range)object;
/* 362 */       return (this.lowerBound.equals(other.lowerBound)) && (this.upperBound.equals(other.upperBound));
/*     */     }
/*     */ 
/* 365 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 372 */     return this.lowerBound.hashCode() * 31 + this.upperBound.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 380 */     StringBuilder sb = new StringBuilder();
/* 381 */     this.lowerBound.describeAsLowerBound(sb);
/* 382 */     sb.append("..");
/* 383 */     this.upperBound.describeAsUpperBound(sb);
/* 384 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static enum BoundType
/*     */   {
/* 117 */     OPEN, 
/*     */ 
/* 122 */     CLOSED;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Range
 * JD-Core Version:    0.6.0
 */