/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.LinkedHashMap;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public final class LinkedHashMultiset<E> extends AbstractMapBasedMultiset<E>
/*     */ {
/*     */ 
/*     */   @GwtIncompatible("not needed in emulated source")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <E> LinkedHashMultiset<E> create()
/*     */   {
/*  49 */     return new LinkedHashMultiset();
/*     */   }
/*     */ 
/*     */   public static <E> LinkedHashMultiset<E> create(int distinctElements)
/*     */   {
/*  60 */     return new LinkedHashMultiset(distinctElements);
/*     */   }
/*     */ 
/*     */   public static <E> LinkedHashMultiset<E> create(Iterable<? extends E> elements)
/*     */   {
/*  70 */     LinkedHashMultiset multiset = create(Multisets.inferDistinctElements(elements));
/*     */ 
/*  72 */     Iterables.addAll(multiset, elements);
/*  73 */     return multiset;
/*     */   }
/*     */ 
/*     */   private LinkedHashMultiset() {
/*  77 */     super(new LinkedHashMap());
/*     */   }
/*     */ 
/*     */   private LinkedHashMultiset(int distinctElements)
/*     */   {
/*  82 */     super(new LinkedHashMap(Maps.capacity(distinctElements)));
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/*  91 */     stream.defaultWriteObject();
/*  92 */     Serialization.writeMultiset(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/*  98 */     stream.defaultReadObject();
/*  99 */     int distinctElements = Serialization.readCount(stream);
/* 100 */     setBackingMap(new LinkedHashMap(Maps.capacity(distinctElements)));
/*     */ 
/* 102 */     Serialization.populateMultiset(this, stream, distinctElements);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.LinkedHashMultiset
 * JD-Core Version:    0.6.0
 */