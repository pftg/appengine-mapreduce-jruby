/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Lists;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class LazyParsingExtension
/*     */ {
/*     */   List<ByteBuffer> raw;
/*     */   Extensions.Extension parsedAs;
/*     */   volatile Object parsed;
/*     */ 
/*     */   static LazyParsingExtension raw(ByteBuffer raw)
/*     */   {
/*  45 */     return new LazyParsingExtension(Lists.newArrayList(new ByteBuffer[] { raw }), null, null);
/*     */   }
/*     */ 
/*     */   static LazyParsingExtension empty(Extensions.Extension singleParsedAs)
/*     */   {
/*  50 */     return new LazyParsingExtension(null, singleParsedAs, singleParsedAs.newValue());
/*     */   }
/*     */ 
/*     */   static <T> LazyParsingExtension parsed(Extensions.Extension<?, T> parsedAs, T parsed)
/*     */   {
/*  55 */     return new LazyParsingExtension(null, parsedAs, parsed);
/*     */   }
/*     */ 
/*     */   private LazyParsingExtension(List<ByteBuffer> raw, Extensions.Extension parsedAs, Object parsed)
/*     */   {
/*  60 */     this.raw = raw;
/*  61 */     this.parsedAs = parsedAs;
/*  62 */     this.parsed = parsed;
/*     */   }
/*     */ 
/*     */   public final void addRaw(ByteBuffer buffer) {
/*  66 */     Preconditions.checkState(!isParsed());
/*  67 */     this.raw.add(buffer);
/*     */   }
/*     */ 
/*     */   public final void merge(LazyParsingExtension other)
/*     */   {
/*  72 */     if ((isParsed()) && (other.isParsed()))
/*  73 */       this.parsed = this.parsedAs.merge(this.parsed, other.parsed);
/*  74 */     else if ((isParsed()) && (!other.isParsed()))
/*  75 */       this.parsed = this.parsedAs.merge(this.parsed, other.read(this.parsedAs));
/*  76 */     else if ((!isParsed()) && (other.isParsed()))
/*  77 */       this.parsed = other.parsedAs.merge(read(other.parsedAs), other.parsed);
/*     */     else
/*  79 */       this.raw.addAll(other.raw);
/*     */   }
/*     */ 
/*     */   public final <T> T read(Extensions.Extension<?, T> extension)
/*     */   {
/*  85 */     parseIfNeeded(extension);
/*  86 */     return this.parsed;
/*     */   }
/*     */ 
/*     */   public final boolean isParsed() {
/*  90 */     return this.parsed != null;
/*     */   }
/*     */   @VisibleForTesting
/*     */   final <T> void parseIfNeeded(Extensions.Extension<?, T> extension) {
/*  95 */     if (!isParsed()) {
/*  96 */       synchronized (this) {
/*  97 */         if (!isParsed()) {
/*  98 */           this.parsedAs = extension;
/*  99 */           this.parsed = extension.readFromRepeatedTags(this.raw);
/* 100 */           this.raw = null;
/*     */         }
/*     */       }
/*     */     }
/* 104 */     Preconditions.checkState(this.parsedAs != null);
/* 105 */     Preconditions.checkState(this.parsed != null);
/* 106 */     Preconditions.checkArgument(this.parsedAs == extension, new StringBuilder("Already parsed as a different extension. Parsed as: ").append(this.parsedAs).append(", attempting to parse as ").append(extension).append("."));
/*     */ 
/* 109 */     Preconditions.checkState(isParsed(), "isParsed() should be true right after data is parsed.");
/*     */   }
/*     */ 
/*     */   public final boolean equals(Object obj)
/*     */   {
/* 115 */     if ((obj instanceof LazyParsingExtension)) {
/* 116 */       LazyParsingExtension other = (LazyParsingExtension)obj;
/* 117 */       if ((isParsed()) && (other.isParsed())) {
/* 118 */         return (this.parsedAs == other.parsedAs) && (this.parsed.equals(other.parsed));
/*     */       }
/* 120 */       if ((!isParsed()) && (!other.isParsed())) {
/* 121 */         return this.raw.equals(other.raw);
/*     */       }
/*     */ 
/* 126 */       if (isParsed()) {
/* 127 */         return this.parsed.equals(this.parsedAs.readFromRepeatedTags(other.raw));
/*     */       }
/* 129 */       return other.parsed.equals(other.parsedAs.readFromRepeatedTags(this.raw));
/*     */     }
/*     */ 
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 146 */     throw new UnsupportedOperationException("hashCode is not supported for LazyParsingExtension");
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.LazyParsingExtension
 * JD-Core Version:    0.6.0
 */