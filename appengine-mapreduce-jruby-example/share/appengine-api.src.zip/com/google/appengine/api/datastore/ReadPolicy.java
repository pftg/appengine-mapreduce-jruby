/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public final class ReadPolicy
/*    */ {
/*    */   private final Consistency consistency;
/*    */ 
/*    */   public ReadPolicy(Consistency consistency)
/*    */   {
/* 36 */     if (consistency == null) {
/* 37 */       throw new NullPointerException("consistency must not be null");
/*    */     }
/* 39 */     this.consistency = consistency;
/*    */   }
/*    */ 
/*    */   public Consistency getConsistency() {
/* 43 */     return this.consistency;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 48 */     if (this == o) {
/* 49 */       return true;
/*    */     }
/* 51 */     if ((o == null) || (getClass() != o.getClass())) {
/* 52 */       return false;
/*    */     }
/*    */ 
/* 55 */     ReadPolicy that = (ReadPolicy)o;
/*    */ 
/* 58 */     return this.consistency == that.consistency;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 66 */     return this.consistency.hashCode();
/*    */   }
/*    */ 
/*    */   public static enum Consistency
/*    */   {
/* 23 */     STRONG, 
/*    */ 
/* 30 */     EVENTUAL;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.ReadPolicy
 * JD-Core Version:    0.6.0
 */