package com.google.appengine.repackaged.com.google.protobuf;

public abstract interface RpcController
{
  public abstract void reset();

  public abstract boolean failed();

  public abstract String errorText();

  public abstract void startCancel();

  public abstract void setFailed(String paramString);

  public abstract boolean isCanceled();

  public abstract void notifyOnCancel(RpcCallback<Object> paramRpcCallback);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.RpcController
 * JD-Core Version:    0.6.0
 */