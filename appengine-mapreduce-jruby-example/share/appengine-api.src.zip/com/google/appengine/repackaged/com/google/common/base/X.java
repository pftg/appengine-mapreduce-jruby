/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ 
/*    */ @GoogleInternal
/*    */ public final class X
/*    */ {
/*    */   public static void assertTrue(boolean b)
/*    */   {
/* 35 */     if (!b)
/* 36 */       throw new RuntimeException("Assertion failed");
/*    */   }
/*    */ 
/*    */   public static void assertTrue(boolean b, String msg)
/*    */   {
/* 45 */     if (!b)
/* 46 */       throw new RuntimeException("Assertion failed: " + msg);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.X
 * JD-Core Version:    0.6.0
 */