/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ 
/*     */ public class URLName
/*     */ {
/*     */   private static final String nonEncodedChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-.*";
/*     */   private String file;
/*     */   private String host;
/*     */   private String password;
/*     */   private int port;
/*     */   private String protocol;
/*     */   private String ref;
/*     */   private String username;
/*     */   protected String fullURL;
/*     */   private int hashCode;
/*     */ 
/*     */   public URLName(String url)
/*     */   {
/*  45 */     parseString(url);
/*     */   }
/*     */ 
/*     */   protected void parseString(String url)
/*     */   {
/*     */     URI uri;
/*     */     try
/*     */     {
/*     */       URI uri;
/*  51 */       if (url == null)
/*  52 */         uri = null;
/*     */       else
/*  54 */         uri = new URI(url);
/*     */     }
/*     */     catch (URISyntaxException e) {
/*  57 */       uri = null;
/*     */     }
/*  59 */     if (uri == null) {
/*  60 */       this.protocol = null;
/*  61 */       this.host = null;
/*  62 */       this.port = -1;
/*  63 */       this.file = null;
/*  64 */       this.ref = null;
/*  65 */       this.username = null;
/*  66 */       this.password = null;
/*  67 */       return;
/*     */     }
/*     */ 
/*  70 */     this.protocol = checkBlank(uri.getScheme());
/*  71 */     this.host = checkBlank(uri.getHost());
/*  72 */     this.port = uri.getPort();
/*  73 */     this.file = checkBlank(uri.getPath());
/*     */ 
/*  77 */     if ((this.file != null) && (this.file.length() > 1) && (this.file.startsWith("/"))) {
/*  78 */       this.file = checkBlank(this.file.substring(1));
/*     */     }
/*     */ 
/*  81 */     this.ref = checkBlank(uri.getFragment());
/*  82 */     String userInfo = checkBlank(uri.getUserInfo());
/*  83 */     if (userInfo == null) {
/*  84 */       this.username = null;
/*  85 */       this.password = null;
/*     */     } else {
/*  87 */       int pos = userInfo.indexOf(':');
/*  88 */       if (pos == -1) {
/*  89 */         this.username = userInfo;
/*  90 */         this.password = null;
/*     */       } else {
/*  92 */         this.username = userInfo.substring(0, pos);
/*  93 */         this.password = userInfo.substring(pos + 1);
/*     */       }
/*     */     }
/*  96 */     updateFullURL();
/*     */   }
/*     */ 
/*     */   public URLName(String protocol, String host, int port, String file, String username, String password) {
/* 100 */     this.protocol = checkBlank(protocol);
/* 101 */     this.host = checkBlank(host);
/* 102 */     this.port = port;
/* 103 */     if ((file == null) || (file.length() == 0)) {
/* 104 */       this.file = null;
/* 105 */       this.ref = null;
/*     */     } else {
/* 107 */       int pos = file.indexOf('#');
/* 108 */       if (pos == -1) {
/* 109 */         this.file = file;
/* 110 */         this.ref = null;
/*     */       } else {
/* 112 */         this.file = file.substring(0, pos);
/* 113 */         this.ref = file.substring(pos + 1);
/*     */       }
/*     */     }
/* 116 */     this.username = checkBlank(username);
/* 117 */     if (this.username != null)
/* 118 */       this.password = checkBlank(password);
/*     */     else {
/* 120 */       this.password = null;
/*     */     }
/* 122 */     username = encode(username);
/* 123 */     password = encode(password);
/* 124 */     updateFullURL();
/*     */   }
/*     */ 
/*     */   public URLName(URL url) {
/* 128 */     this.protocol = checkBlank(url.getProtocol());
/* 129 */     this.host = checkBlank(url.getHost());
/* 130 */     this.port = url.getPort();
/* 131 */     this.file = checkBlank(url.getFile());
/* 132 */     this.ref = checkBlank(url.getRef());
/* 133 */     String userInfo = checkBlank(url.getUserInfo());
/* 134 */     if (userInfo == null) {
/* 135 */       this.username = null;
/* 136 */       this.password = null;
/*     */     } else {
/* 138 */       int pos = userInfo.indexOf(':');
/* 139 */       if (pos == -1) {
/* 140 */         this.username = userInfo;
/* 141 */         this.password = null;
/*     */       } else {
/* 143 */         this.username = userInfo.substring(0, pos);
/* 144 */         this.password = userInfo.substring(pos + 1);
/*     */       }
/*     */     }
/* 147 */     updateFullURL();
/*     */   }
/*     */ 
/*     */   private static String checkBlank(String target) {
/* 151 */     if ((target == null) || (target.length() == 0)) {
/* 152 */       return null;
/*     */     }
/* 154 */     return target;
/*     */   }
/*     */ 
/*     */   private void updateFullURL()
/*     */   {
/* 159 */     this.hashCode = 0;
/* 160 */     StringBuffer buf = new StringBuffer(100);
/* 161 */     if (this.protocol != null) {
/* 162 */       buf.append(this.protocol).append(':');
/* 163 */       if (this.host != null) {
/* 164 */         buf.append("//");
/* 165 */         if (this.username != null) {
/* 166 */           buf.append(encode(this.username));
/* 167 */           if (this.password != null) {
/* 168 */             buf.append(':').append(encode(this.password));
/*     */           }
/* 170 */           buf.append('@');
/*     */         }
/* 172 */         buf.append(this.host);
/* 173 */         if (this.port != -1) {
/* 174 */           buf.append(':').append(this.port);
/*     */         }
/* 176 */         if (this.file != null) {
/* 177 */           buf.append('/').append(this.file);
/*     */         }
/* 179 */         this.hashCode = buf.toString().hashCode();
/* 180 */         if (this.ref != null) {
/* 181 */           buf.append('#').append(this.ref);
/*     */         }
/*     */       }
/*     */     }
/* 185 */     this.fullURL = buf.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/* 189 */     if (!(o instanceof URLName)) {
/* 190 */       return false;
/*     */     }
/* 192 */     URLName other = (URLName)o;
/*     */ 
/* 194 */     if ((this.protocol == null) || (other.protocol == null) || (!this.protocol.equals(other.protocol))) {
/* 195 */       return false;
/*     */     }
/*     */ 
/* 198 */     if (this.port != other.port) {
/* 199 */       return false;
/*     */     }
/*     */ 
/* 203 */     return (areSame(this.host, other.host)) && (areSame(this.file, other.file)) && (areSame(this.username, other.username)) && (areSame(this.password, other.password));
/*     */   }
/*     */ 
/*     */   private static boolean areSame(String s1, String s2) {
/* 207 */     if (s1 == null) {
/* 208 */       return s2 == null;
/*     */     }
/* 210 */     return s1.equals(s2);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 215 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 219 */     return this.fullURL;
/*     */   }
/*     */ 
/*     */   public String getFile() {
/* 223 */     return this.file;
/*     */   }
/*     */ 
/*     */   public String getHost() {
/* 227 */     return this.host;
/*     */   }
/*     */ 
/*     */   public String getPassword() {
/* 231 */     return this.password;
/*     */   }
/*     */ 
/*     */   public int getPort() {
/* 235 */     return this.port;
/*     */   }
/*     */ 
/*     */   public String getProtocol() {
/* 239 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public String getRef() {
/* 243 */     return this.ref;
/*     */   }
/*     */ 
/*     */   public URL getURL() throws MalformedURLException {
/* 247 */     return new URL(this.fullURL);
/*     */   }
/*     */ 
/*     */   public String getUsername() {
/* 251 */     return this.username;
/*     */   }
/*     */ 
/*     */   private static String encode(String v)
/*     */   {
/* 264 */     if (v == null) {
/* 265 */       return null;
/*     */     }
/* 267 */     boolean needsEncoding = false;
/* 268 */     for (int i = 0; i < v.length(); i++)
/*     */     {
/* 270 */       if ("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-.*".indexOf(v.charAt(i)) != -1)
/*     */         continue;
/* 272 */       needsEncoding = true;
/* 273 */       break;
/*     */     }
/*     */ 
/* 277 */     if (!needsEncoding) {
/* 278 */       return v;
/*     */     }
/*     */ 
/* 283 */     StringBuffer encoded = new StringBuffer(v.length() + 10);
/*     */ 
/* 287 */     byte[] data = v.getBytes();
/*     */ 
/* 289 */     for (int i = 0; i < data.length; i++)
/*     */     {
/* 292 */       char ch = (char)(data[i] & 0xFF);
/*     */ 
/* 294 */       if (ch == ' ') {
/* 295 */         encoded.append('+');
/*     */       }
/* 298 */       else if ("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-.*".indexOf(ch) == -1)
/*     */       {
/* 301 */         char firstChar = Character.toUpperCase(Character.forDigit(ch >> '\004' & 0xF, 16));
/* 302 */         char secondChar = Character.toUpperCase(Character.forDigit(ch & 0xF, 16));
/*     */ 
/* 305 */         encoded.append('%');
/* 306 */         encoded.append(firstChar);
/* 307 */         encoded.append(secondChar);
/*     */       }
/*     */       else
/*     */       {
/* 311 */         encoded.append(ch);
/*     */       }
/*     */     }
/*     */ 
/* 315 */     return encoded.toString();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.URLName
 * JD-Core Version:    0.6.0
 */