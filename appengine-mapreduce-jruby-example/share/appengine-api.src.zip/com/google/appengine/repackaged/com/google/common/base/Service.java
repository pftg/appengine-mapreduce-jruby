/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.Beta;
/*     */ import java.util.concurrent.Future;
/*     */ 
/*     */ @Beta
/*     */ public abstract interface Service
/*     */ {
/*     */   public abstract Future<State> start();
/*     */ 
/*     */   public abstract State startAndWait();
/*     */ 
/*     */   public abstract boolean isRunning();
/*     */ 
/*     */   public abstract State state();
/*     */ 
/*     */   public abstract Future<State> stop();
/*     */ 
/*     */   public abstract State stopAndWait();
/*     */ 
/*     */   public static enum State
/*     */   {
/* 131 */     NEW, 
/*     */ 
/* 136 */     STARTING, 
/*     */ 
/* 141 */     RUNNING, 
/*     */ 
/* 146 */     STOPPING, 
/*     */ 
/* 152 */     TERMINATED, 
/*     */ 
/* 158 */     FAILED;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Service
 * JD-Core Version:    0.6.0
 */