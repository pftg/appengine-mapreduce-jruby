/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ abstract class BaseQuerySplitter
/*    */   implements QuerySplitter
/*    */ {
/* 17 */   protected static final Comparator<ComparableValue> VALUE_COMPARATOR_ASC = new Comparator()
/*    */   {
/*    */     public int compare(BaseQuerySplitter.ComparableValue o1, BaseQuerySplitter.ComparableValue o2)
/*    */     {
/* 21 */       return EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(o1.comparableValue, o2.comparableValue);
/*    */     }
/* 17 */   };
/*    */ 
/* 26 */   protected static final Comparator<ComparableValue> VALUE_COMPARATOR_DESC = new Comparator()
/*    */   {
/*    */     public int compare(BaseQuerySplitter.ComparableValue o1, BaseQuerySplitter.ComparableValue o2)
/*    */     {
/* 30 */       return -BaseQuerySplitter.VALUE_COMPARATOR_ASC.compare(o1, o2);
/*    */     }
/* 26 */   };
/*    */ 
/*    */   protected static Comparator<ComparableValue> getValueComparator(Query.SortDirection sortDirection)
/*    */   {
/* 60 */     if (sortDirection == Query.SortDirection.DESCENDING) {
/* 61 */       return VALUE_COMPARATOR_DESC;
/*    */     }
/* 63 */     return VALUE_COMPARATOR_ASC;
/*    */   }
/*    */ 
/*    */   protected static class ComparableValue
/*    */   {
/*    */     private final Comparable<Object> comparableValue;
/*    */     private final Object originalValue;
/*    */ 
/*    */     public ComparableValue(Object value)
/*    */     {
/* 50 */       this.comparableValue = DataTypeTranslator.getComparablePropertyValue(value);
/* 51 */       this.originalValue = value;
/*    */     }
/*    */ 
/*    */     public Object getValue() {
/* 55 */       return this.originalValue;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.BaseQuerySplitter
 * JD-Core Version:    0.6.0
 */