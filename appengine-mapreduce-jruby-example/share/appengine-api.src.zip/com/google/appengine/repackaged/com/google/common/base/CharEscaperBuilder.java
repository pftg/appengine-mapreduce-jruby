/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public class CharEscaperBuilder
/*     */ {
/*     */   private final Map<Character, String> map;
/*  59 */   private int max = -1;
/*     */ 
/*     */   public CharEscaperBuilder()
/*     */   {
/*  65 */     this.map = new HashMap();
/*     */   }
/*     */ 
/*     */   public CharEscaperBuilder addEscape(char c, String r)
/*     */   {
/*  72 */     this.map.put(Character.valueOf(c), r);
/*  73 */     if (c > this.max) {
/*  74 */       this.max = c;
/*     */     }
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   public CharEscaperBuilder addEscapes(char[] cs, String r)
/*     */   {
/*  83 */     for (char c : cs) {
/*  84 */       addEscape(c, r);
/*     */     }
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   public char[][] toArray()
/*     */   {
/*  97 */     char[][] result = new char[this.max + 1][];
/*  98 */     for (Map.Entry entry : this.map.entrySet()) {
/*  99 */       result[((Character)entry.getKey()).charValue()] = ((String)entry.getValue()).toCharArray();
/*     */     }
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   public CharEscaper toEscaper()
/*     */   {
/* 111 */     return new CharArrayDecorator(toArray());
/*     */   }
/*     */ 
/*     */   private static class CharArrayDecorator extends CharEscaper
/*     */   {
/*     */     private final char[][] replacements;
/*     */     private final int replaceLength;
/*     */ 
/*     */     CharArrayDecorator(char[][] replacements)
/*     */     {
/*  31 */       this.replacements = replacements;
/*  32 */       this.replaceLength = replacements.length;
/*     */     }
/*     */ 
/*     */     public String escape(String s)
/*     */     {
/*  40 */       int slen = s.length();
/*  41 */       for (int index = 0; index < slen; index++) {
/*  42 */         char c = s.charAt(index);
/*  43 */         if ((c < this.replacements.length) && (this.replacements[c] != null)) {
/*  44 */           return escapeSlow(s, index);
/*     */         }
/*     */       }
/*  47 */       return s;
/*     */     }
/*     */ 
/*     */     protected char[] escape(char c) {
/*  51 */       return c < this.replaceLength ? this.replacements[c] : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.CharEscaperBuilder
 * JD-Core Version:    0.6.0
 */