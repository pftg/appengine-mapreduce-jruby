/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ public final class GrowableProtocolSink
/*     */ {
/*     */   private byte[] buf;
/*     */   private int pos;
/*     */ 
/*     */   public GrowableProtocolSink(byte[] array, int offset)
/*     */   {
/*  28 */     this.buf = array;
/*  29 */     this.pos = offset;
/*     */   }
/*     */ 
/*     */   public GrowableProtocolSink(byte[] array)
/*     */   {
/*  38 */     this(array, 0);
/*     */   }
/*     */ 
/*     */   public GrowableProtocolSink(int size)
/*     */   {
/*  47 */     this(new byte[size], 0);
/*     */   }
/*     */ 
/*     */   public GrowableProtocolSink()
/*     */   {
/*  54 */     this(new byte[''], 0);
/*     */   }
/*     */ 
/*     */   public final void reset()
/*     */   {
/*  62 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   public final int position()
/*     */   {
/*  69 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public final void skip(int n)
/*     */   {
/*  78 */     if ((n > 0) && (this.buf.length - this.pos < n)) {
/*  79 */       increaseCapacityBy(n);
/*     */     }
/*  81 */     this.pos += n;
/*     */   }
/*     */ 
/*     */   public final byte[] array()
/*     */   {
/*  90 */     return this.buf;
/*     */   }
/*     */ 
/*     */   public final byte[] toArray()
/*     */   {
/*  98 */     byte[] copy = new byte[this.pos];
/*  99 */     System.arraycopy(this.buf, 0, copy, 0, this.pos);
/* 100 */     return copy;
/*     */   }
/*     */ 
/*     */   private void increaseCapacityBy(int needed)
/*     */   {
/* 109 */     int size = Math.max(this.pos + needed, 64);
/*     */ 
/* 111 */     size = Integer.highestOneBit(size) * 2;
/* 112 */     byte[] newbuf = new byte[size];
/* 113 */     System.arraycopy(this.buf, 0, newbuf, 0, this.pos);
/* 114 */     this.buf = newbuf;
/*     */   }
/*     */ 
/*     */   public final void putBytes(byte[] src, int offset, int length)
/*     */   {
/* 126 */     if (this.buf.length - this.pos < length) {
/* 127 */       increaseCapacityBy(length);
/*     */     }
/* 129 */     System.arraycopy(src, offset, this.buf, this.pos, length);
/* 130 */     this.pos += length;
/*     */   }
/*     */ 
/*     */   public final void putBytes(byte[] src)
/*     */   {
/* 140 */     putBytes(src, 0, src.length);
/*     */   }
/*     */ 
/*     */   public final void putByte(byte v)
/*     */   {
/* 150 */     if (this.buf.length - this.pos < 1) {
/* 151 */       increaseCapacityBy(1);
/*     */     }
/* 153 */     this.buf[(this.pos++)] = v;
/*     */   }
/*     */ 
/*     */   public final void putShort(short v)
/*     */   {
/* 163 */     if (this.buf.length - this.pos < 2) {
/* 164 */       increaseCapacityBy(2);
/*     */     }
/* 166 */     this.buf[(this.pos++)] = (byte)v;
/* 167 */     this.buf[(this.pos++)] = (byte)(v >> 8);
/*     */   }
/*     */ 
/*     */   public final void putInt(int v)
/*     */   {
/* 177 */     if (this.buf.length - this.pos < 4) {
/* 178 */       increaseCapacityBy(4);
/*     */     }
/* 180 */     this.buf[(this.pos++)] = (byte)v;
/* 181 */     this.buf[(this.pos++)] = (byte)(v >> 8);
/* 182 */     this.buf[(this.pos++)] = (byte)(v >> 16);
/* 183 */     this.buf[(this.pos++)] = (byte)(v >> 24);
/*     */   }
/*     */ 
/*     */   public final void putLong(long v)
/*     */   {
/* 193 */     if (this.buf.length - this.pos < 8) {
/* 194 */       increaseCapacityBy(8);
/*     */     }
/* 196 */     this.buf[(this.pos++)] = (byte)(int)v;
/* 197 */     this.buf[(this.pos++)] = (byte)(int)(v >> 8);
/* 198 */     this.buf[(this.pos++)] = (byte)(int)(v >> 16);
/* 199 */     this.buf[(this.pos++)] = (byte)(int)(v >> 24);
/* 200 */     this.buf[(this.pos++)] = (byte)(int)(v >> 32);
/* 201 */     this.buf[(this.pos++)] = (byte)(int)(v >> 40);
/* 202 */     this.buf[(this.pos++)] = (byte)(int)(v >> 48);
/* 203 */     this.buf[(this.pos++)] = (byte)(int)(v >> 56);
/*     */   }
/*     */ 
/*     */   public final void putVarInt(int v)
/*     */   {
/* 214 */     if (this.buf.length - this.pos < 5)
/* 215 */       increaseCapacityBy(5);
/*     */     while (true)
/*     */     {
/* 218 */       int bits = v & 0x7F;
/* 219 */       v >>>= 7;
/* 220 */       if (v == 0) {
/* 221 */         putByte((byte)bits);
/* 222 */         return;
/*     */       }
/* 224 */       putByte((byte)(bits | 0x80));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void putVarLong(long v)
/*     */   {
/* 236 */     if (this.buf.length - this.pos < 10)
/* 237 */       increaseCapacityBy(10);
/*     */     while (true)
/*     */     {
/* 240 */       int bits = (int)v & 0x7F;
/* 241 */       v >>>= 7;
/* 242 */       if (v == 0L) {
/* 243 */         putByte((byte)bits);
/* 244 */         return;
/*     */       }
/* 246 */       putByte((byte)(bits | 0x80));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void putBoolean(boolean v)
/*     */   {
/* 257 */     if (this.buf.length - this.pos < 1) {
/* 258 */       increaseCapacityBy(1);
/*     */     }
/* 260 */     if (v)
/* 261 */       putByte(1);
/*     */     else
/* 263 */       putByte(0);
/*     */   }
/*     */ 
/*     */   public final void putFloat(float v)
/*     */   {
/* 275 */     putInt(Float.floatToIntBits(v));
/*     */   }
/*     */ 
/*     */   public final void putDouble(double v)
/*     */   {
/* 286 */     putLong(Double.doubleToLongBits(v));
/*     */   }
/*     */ 
/*     */   public final void putPrefixedData(byte[] v)
/*     */   {
/* 296 */     if (this.buf.length - this.pos < 5 + v.length) {
/* 297 */       increaseCapacityBy(5 + v.length);
/*     */     }
/* 299 */     putVarInt(v.length);
/* 300 */     putBytes(v, 0, v.length);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.GrowableProtocolSink
 * JD-Core Version:    0.6.0
 */