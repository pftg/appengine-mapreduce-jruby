/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ @GwtCompatible
/*     */ public abstract class AbstractIterator<T> extends UnmodifiableIterator<T>
/*     */ {
/*     */   private State state;
/*     */   private T next;
/*     */ 
/*     */   public AbstractIterator()
/*     */   {
/*  63 */     this.state = State.NOT_READY;
/*     */   }
/*     */ 
/*     */   protected abstract T computeNext();
/*     */ 
/*     */   protected final T endOfData()
/*     */   {
/* 119 */     this.state = State.DONE;
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   public final boolean hasNext() {
/* 124 */     Preconditions.checkState(this.state != State.FAILED);
/* 125 */     switch (1.$SwitchMap$com$google$common$collect$AbstractIterator$State[this.state.ordinal()]) {
/*     */     case 1:
/* 127 */       return false;
/*     */     case 2:
/* 129 */       return true;
/*     */     }
/*     */ 
/* 132 */     return tryToComputeNext();
/*     */   }
/*     */ 
/*     */   private boolean tryToComputeNext() {
/* 136 */     this.state = State.FAILED;
/* 137 */     this.next = computeNext();
/* 138 */     if (this.state != State.DONE) {
/* 139 */       this.state = State.READY;
/* 140 */       return true;
/*     */     }
/* 142 */     return false;
/*     */   }
/*     */ 
/*     */   public final T next() {
/* 146 */     if (!hasNext()) {
/* 147 */       throw new NoSuchElementException();
/*     */     }
/* 149 */     this.state = State.NOT_READY;
/* 150 */     return this.next;
/*     */   }
/*     */ 
/*     */   public final T peek()
/*     */   {
/* 161 */     if (!hasNext()) {
/* 162 */       throw new NoSuchElementException();
/*     */     }
/* 164 */     return this.next;
/*     */   }
/*     */ 
/*     */   private static enum State
/*     */   {
/*  67 */     READY, 
/*     */ 
/*  70 */     NOT_READY, 
/*     */ 
/*  73 */     DONE, 
/*     */ 
/*  76 */     FAILED;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.AbstractIterator
 * JD-Core Version:    0.6.0
 */