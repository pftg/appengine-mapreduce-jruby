package com.google.appengine.api.oauth;

import com.google.appengine.api.users.User;

public abstract interface OAuthService
{
  public abstract User getCurrentUser()
    throws OAuthRequestException;

  public abstract boolean isUserAdmin()
    throws OAuthRequestException;

  public abstract String getOAuthConsumerKey()
    throws OAuthRequestException;
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.oauth.OAuthService
 * JD-Core Version:    0.6.0
 */