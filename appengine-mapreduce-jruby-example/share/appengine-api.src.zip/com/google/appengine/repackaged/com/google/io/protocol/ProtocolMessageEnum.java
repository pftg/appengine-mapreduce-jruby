package com.google.appengine.repackaged.com.google.io.protocol;

public abstract interface ProtocolMessageEnum
{
  public abstract int getValue();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum
 * JD-Core Version:    0.6.0
 */