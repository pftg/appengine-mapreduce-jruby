/*     */ package com.google.appengine.api.images;
/*     */ 
/*     */ import com.google.appengine.api.blobstore.BlobKey;
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ final class ImagesServiceImpl
/*     */   implements ImagesService
/*     */ {
/*     */   public Image applyTransform(Transform transform, Image image)
/*     */   {
/*  33 */     return applyTransform(transform, image, ImagesService.OutputEncoding.PNG);
/*     */   }
/*     */ 
/*     */   public Image applyTransform(Transform transform, Image image, ImagesService.OutputEncoding encoding)
/*     */   {
/*  39 */     ImagesServicePb.ImagesTransformRequest request = new ImagesServicePb.ImagesTransformRequest();
/*  40 */     ImagesServicePb.ImagesTransformResponse response = new ImagesServicePb.ImagesTransformResponse();
/*  41 */     convertImageData(image, request.getMutableImage());
/*     */     ImagesServicePb.OutputSettings.MIME_TYPE mimeType;
/*  43 */     switch (1.$SwitchMap$com$google$appengine$api$images$ImagesService$OutputEncoding[encoding.ordinal()]) {
/*     */     case 1:
/*  45 */       mimeType = ImagesServicePb.OutputSettings.MIME_TYPE.PNG;
/*  46 */       break;
/*     */     case 2:
/*  48 */       mimeType = ImagesServicePb.OutputSettings.MIME_TYPE.JPEG;
/*  49 */       break;
/*     */     default:
/*  51 */       throw new IllegalArgumentException("Invalid output encoding requested");
/*     */     }
/*     */ 
/*  54 */     request.getMutableOutput().setMimeType(mimeType);
/*     */ 
/*  56 */     transform.apply(request);
/*  57 */     if (request.transformSize() > 10) {
/*  58 */       throw new IllegalArgumentException("A maximum of 10 basic transforms can be requested in a single transform request");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  63 */       byte[] responseBytes = ApiProxy.makeSyncCall("images", "Transform", request.toByteArray());
/*  64 */       response.mergeFrom(responseBytes);
/*     */     } catch (ApiProxy.ApplicationException ex) {
/*  66 */       ImagesServicePb.ImagesServiceError.ErrorCode code = ImagesServicePb.ImagesServiceError.ErrorCode.valueOf(ex.getApplicationError());
/*  67 */       if ((code != null) && (code != ImagesServicePb.ImagesServiceError.ErrorCode.UNSPECIFIED_ERROR)) {
/*  68 */         throw new IllegalArgumentException(ex.getErrorDetail());
/*     */       }
/*  70 */       throw new ImagesServiceFailureException(ex.getErrorDetail());
/*     */     }
/*     */ 
/*  74 */     image.setImageData(response.getMutableImage().getContentAsBytes());
/*  75 */     return image;
/*     */   }
/*     */ 
/*     */   public Image composite(Collection<Composite> composites, int width, int height, long color)
/*     */   {
/*  81 */     return composite(composites, width, height, color, ImagesService.OutputEncoding.PNG);
/*     */   }
/*     */ 
/*     */   public Image composite(Collection<Composite> composites, int width, int height, long color, ImagesService.OutputEncoding encoding)
/*     */   {
/*  88 */     ImagesServicePb.ImagesCompositeRequest request = new ImagesServicePb.ImagesCompositeRequest();
/*  89 */     ImagesServicePb.ImagesCompositeResponse response = new ImagesServicePb.ImagesCompositeResponse();
/*  90 */     if (composites.size() > 16) {
/*  91 */       throw new IllegalArgumentException("A maximum of 16 composites can be applied in a single request");
/*     */     }
/*     */ 
/*  95 */     if ((width > 4000) || (width <= 0) || (height > 4000) || (height <= 0))
/*     */     {
/*  97 */       throw new IllegalArgumentException("Width and height must <= 4000 and > 0");
/*     */     }
/*     */ 
/* 100 */     if ((color > 4294967295L) || (color < 0L)) {
/* 101 */       throw new IllegalArgumentException("Color must be in the range [0, 0xffffffff]");
/*     */     }
/*     */ 
/* 105 */     if (color >= -2147483648L) {
/* 106 */       color -= 4294967296L;
/*     */     }
/* 108 */     int fixedColor = (int)color;
/* 109 */     request.getCanvas().setWidth(width);
/* 110 */     request.getCanvas().setHeight(height);
/* 111 */     request.getCanvas().setColor(fixedColor);
/*     */     ImagesServicePb.OutputSettings.MIME_TYPE mimeType;
/* 113 */     switch (1.$SwitchMap$com$google$appengine$api$images$ImagesService$OutputEncoding[encoding.ordinal()]) {
/*     */     case 1:
/* 115 */       mimeType = ImagesServicePb.OutputSettings.MIME_TYPE.PNG;
/* 116 */       break;
/*     */     case 2:
/* 118 */       mimeType = ImagesServicePb.OutputSettings.MIME_TYPE.JPEG;
/* 119 */       break;
/*     */     default:
/* 121 */       throw new IllegalArgumentException("Invalid output encoding requested");
/*     */     }
/*     */ 
/* 124 */     request.getCanvas().getOutput().setMimeType(mimeType);
/* 125 */     Map imageIdMap = new HashMap();
/* 126 */     for (Composite composite : composites) {
/* 127 */       composite.apply(request, imageIdMap);
/*     */     }
/*     */     try
/*     */     {
/* 131 */       byte[] responseBytes = ApiProxy.makeSyncCall("images", "Composite", request.toByteArray());
/* 132 */       response.mergeFrom(responseBytes);
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 134 */       ImagesServicePb.ImagesServiceError.ErrorCode code = ImagesServicePb.ImagesServiceError.ErrorCode.valueOf(ex.getApplicationError());
/* 135 */       if ((code != null) && (code != ImagesServicePb.ImagesServiceError.ErrorCode.UNSPECIFIED_ERROR)) {
/* 136 */         throw new IllegalArgumentException(ex.getErrorDetail());
/*     */       }
/* 138 */       throw new ImagesServiceFailureException(ex.getErrorDetail());
/*     */     }
/*     */ 
/* 142 */     return ImagesServiceFactory.makeImage(response.getMutableImage().getContentAsBytes());
/*     */   }
/*     */ 
/*     */   public int[][] histogram(Image image)
/*     */   {
/* 148 */     ImagesServicePb.ImagesHistogramRequest request = new ImagesServicePb.ImagesHistogramRequest();
/* 149 */     ImagesServicePb.ImagesHistogramResponse response = new ImagesServicePb.ImagesHistogramResponse();
/* 150 */     convertImageData(image, request.getMutableImage());
/*     */     try {
/* 152 */       byte[] responseBytes = ApiProxy.makeSyncCall("images", "Histogram", request.toByteArray());
/* 153 */       response.mergeFrom(responseBytes);
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 155 */       ImagesServicePb.ImagesServiceError.ErrorCode code = ImagesServicePb.ImagesServiceError.ErrorCode.valueOf(ex.getApplicationError());
/* 156 */       if ((code != null) && (code != ImagesServicePb.ImagesServiceError.ErrorCode.UNSPECIFIED_ERROR)) {
/* 157 */         throw new IllegalArgumentException(ex.getErrorDetail());
/*     */       }
/* 159 */       throw new ImagesServiceFailureException(ex.getErrorDetail());
/*     */     }
/*     */ 
/* 162 */     ImagesServicePb.ImagesHistogram histogram = response.getHistogram();
/* 163 */     int[][] result = new int[3][];
/* 164 */     for (int i = 0; i < 3; i++) {
/* 165 */       result[i] = new int[256];
/*     */     }
/* 167 */     for (int i = 0; i < 256; i++) {
/* 168 */       result[0][i] = histogram.getRed(i);
/* 169 */       result[1][i] = histogram.getGreen(i);
/* 170 */       result[2][i] = histogram.getBlue(i);
/*     */     }
/* 172 */     return result;
/*     */   }
/*     */ 
/*     */   public String getServingUrl(BlobKey blobKey)
/*     */   {
/* 177 */     ImagesServicePb.ImagesGetUrlBaseRequest request = new ImagesServicePb.ImagesGetUrlBaseRequest();
/* 178 */     ImagesServicePb.ImagesGetUrlBaseResponse response = new ImagesServicePb.ImagesGetUrlBaseResponse();
/* 179 */     if (blobKey == null) {
/* 180 */       throw new NullPointerException();
/*     */     }
/* 182 */     request.setBlobKey(blobKey.getKeyString());
/*     */     try {
/* 184 */       byte[] responseBytes = ApiProxy.makeSyncCall("images", "GetUrlBase", request.toByteArray());
/* 185 */       response.mergeFrom(responseBytes);
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 187 */       ImagesServicePb.ImagesServiceError.ErrorCode code = ImagesServicePb.ImagesServiceError.ErrorCode.valueOf(ex.getApplicationError());
/* 188 */       if ((code != null) && (code != ImagesServicePb.ImagesServiceError.ErrorCode.UNSPECIFIED_ERROR)) {
/* 189 */         throw new IllegalArgumentException(ex.getErrorDetail());
/*     */       }
/* 191 */       throw new ImagesServiceFailureException(ex.getErrorDetail());
/*     */     }
/*     */ 
/* 194 */     return response.getUrl();
/*     */   }
/*     */ 
/*     */   public String getServingUrl(BlobKey blobKey, int imageSize, boolean crop)
/*     */   {
/* 200 */     if ((crop) && (!SERVING_CROP_SIZES.contains(Integer.valueOf(imageSize)))) {
/* 201 */       throw new IllegalArgumentException("Unsupported crop size: " + imageSize + ". Valid sizes: " + SERVING_CROP_SIZES);
/*     */     }
/*     */ 
/* 204 */     if ((!crop) && (!SERVING_SIZES.contains(Integer.valueOf(imageSize)))) {
/* 205 */       throw new IllegalArgumentException("Unsupported size: " + imageSize + ". Valid sizes: " + SERVING_SIZES);
/*     */     }
/*     */ 
/* 209 */     StringBuilder url = new StringBuilder(getServingUrl(blobKey));
/* 210 */     url.append("=s");
/* 211 */     url.append(imageSize);
/* 212 */     if (crop) {
/* 213 */       url.append("-c");
/*     */     }
/* 215 */     return url.toString();
/*     */   }
/*     */ 
/*     */   static void convertImageData(Image image, ImagesServicePb.ImageData imageDataPb) {
/* 219 */     BlobKey blobKey = image.getBlobKey();
/* 220 */     if (blobKey != null)
/* 221 */       imageDataPb.setBlobKey(image.getBlobKey().getKeyString());
/*     */     else
/* 223 */       imageDataPb.setContentAsBytes(image.getImageData());
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImagesServiceImpl
 * JD-Core Version:    0.6.0
 */