/*    */ package com.google.appengine.api.users;
/*    */ 
/*    */ public final class UserServiceFactory
/*    */ {
/*    */   public static UserService getUserService()
/*    */   {
/* 15 */     return new UserServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.users.UserServiceFactory
 * JD-Core Version:    0.6.0
 */