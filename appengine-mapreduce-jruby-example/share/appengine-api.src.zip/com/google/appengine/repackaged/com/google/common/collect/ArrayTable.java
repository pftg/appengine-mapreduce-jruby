/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class ArrayTable<R, C, V>
/*     */   implements Table<R, C, V>, Serializable
/*     */ {
/*     */   private final ImmutableList<R> rowList;
/*     */   private final ImmutableList<C> columnList;
/*     */   private final ImmutableMap<R, Integer> rowKeyToIndex;
/*     */   private final ImmutableMap<C, Integer> columnKeyToIndex;
/*     */   private final V[][] array;
/*     */   private transient ArrayTable<R, C, V>.CellSet cellSet;
/*     */   private transient ArrayTable<R, C, V>.ColumnMap columnMap;
/*     */   private transient ArrayTable<R, C, V>.RowMap rowMap;
/*     */   private transient Collection<V> values;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <R, C, V> ArrayTable<R, C, V> create(Iterable<? extends R> rowKeys, Iterable<? extends C> columnKeys)
/*     */   {
/*  92 */     return new ArrayTable(rowKeys, columnKeys);
/*     */   }
/*     */ 
/*     */   public static <R, C, V> ArrayTable<R, C, V> create(Table<R, C, V> table)
/*     */   {
/* 122 */     return new ArrayTable(table);
/*     */   }
/*     */ 
/*     */   public static <R, C, V> ArrayTable<R, C, V> create(ArrayTable<R, C, V> table)
/*     */   {
/* 131 */     return new ArrayTable(table);
/*     */   }
/*     */ 
/*     */   private ArrayTable(Iterable<? extends R> rowKeys, Iterable<? extends C> columnKeys)
/*     */   {
/* 143 */     this.rowList = ImmutableList.copyOf(rowKeys);
/* 144 */     this.columnList = ImmutableList.copyOf(columnKeys);
/* 145 */     Preconditions.checkArgument(!this.rowList.isEmpty());
/* 146 */     Preconditions.checkArgument(!this.columnList.isEmpty());
/*     */ 
/* 151 */     ImmutableMap.Builder rowBuilder = ImmutableMap.builder();
/* 152 */     for (int i = 0; i < this.rowList.size(); i++) {
/* 153 */       rowBuilder.put(this.rowList.get(i), Integer.valueOf(i));
/*     */     }
/* 155 */     this.rowKeyToIndex = rowBuilder.build();
/*     */ 
/* 157 */     ImmutableMap.Builder columnBuilder = ImmutableMap.builder();
/* 158 */     for (int i = 0; i < this.columnList.size(); i++) {
/* 159 */       columnBuilder.put(this.columnList.get(i), Integer.valueOf(i));
/*     */     }
/* 161 */     this.columnKeyToIndex = columnBuilder.build();
/*     */ 
/* 164 */     Object[][] tmpArray = (Object[][])new Object[this.rowList.size()][this.columnList.size()];
/*     */ 
/* 166 */     this.array = tmpArray;
/*     */   }
/*     */ 
/*     */   private ArrayTable(Table<R, C, V> table) {
/* 170 */     this(table.rowKeySet(), table.columnKeySet());
/* 171 */     putAll(table);
/*     */   }
/*     */ 
/*     */   private ArrayTable(ArrayTable<R, C, V> table) {
/* 175 */     this.rowList = table.rowList;
/* 176 */     this.columnList = table.columnList;
/* 177 */     this.rowKeyToIndex = table.rowKeyToIndex;
/* 178 */     this.columnKeyToIndex = table.columnKeyToIndex;
/*     */ 
/* 180 */     Object[][] copy = (Object[][])new Object[this.rowList.size()][this.columnList.size()];
/* 181 */     this.array = copy;
/* 182 */     for (int i = 0; i < this.rowList.size(); i++)
/* 183 */       System.arraycopy(table.array[i], 0, copy[i], 0, table.array[i].length);
/*     */   }
/*     */ 
/*     */   public ImmutableList<R> rowKeyList()
/*     */   {
/* 192 */     return this.rowList;
/*     */   }
/*     */ 
/*     */   public ImmutableList<C> columnKeyList()
/*     */   {
/* 200 */     return this.columnList;
/*     */   }
/*     */ 
/*     */   public V at(int rowIndex, int columnIndex)
/*     */   {
/* 218 */     return this.array[rowIndex][columnIndex];
/*     */   }
/*     */ 
/*     */   public V set(int rowIndex, int columnIndex, @Nullable V value)
/*     */   {
/* 237 */     Object oldValue = this.array[rowIndex][columnIndex];
/* 238 */     this.array[rowIndex][columnIndex] = value;
/* 239 */     return oldValue;
/*     */   }
/*     */ 
/*     */   public V[][] toArray(Class<V> valueClass)
/*     */   {
/* 254 */     Object[][] copy = (Object[][])(Object[][])Array.newInstance(valueClass, new int[] { this.rowList.size(), this.columnList.size() });
/*     */ 
/* 256 */     for (int i = 0; i < this.rowList.size(); i++) {
/* 257 */       System.arraycopy(this.array[i], 0, copy[i], 0, this.array[i].length);
/*     */     }
/* 259 */     return copy;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void clear()
/*     */   {
/* 269 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void eraseAll()
/*     */   {
/* 277 */     for (Object[] row : this.array)
/* 278 */       Arrays.fill(row, null);
/*     */   }
/*     */ 
/*     */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*     */   {
/* 287 */     return (containsRow(rowKey)) && (containsColumn(columnKey));
/*     */   }
/*     */ 
/*     */   public boolean containsColumn(@Nullable Object columnKey)
/*     */   {
/* 295 */     return this.columnKeyToIndex.containsKey(columnKey);
/*     */   }
/*     */ 
/*     */   public boolean containsRow(@Nullable Object rowKey)
/*     */   {
/* 303 */     return this.rowKeyToIndex.containsKey(rowKey);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(@Nullable Object value) {
/* 307 */     for (Object[] row : this.array) {
/* 308 */       for (Object element : row) {
/* 309 */         if (Objects.equal(value, element)) {
/* 310 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 314 */     return false;
/*     */   }
/*     */ 
/*     */   public V get(@Nullable Object rowKey, @Nullable Object columnKey) {
/* 318 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 319 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 320 */     return getIndexed(rowIndex, columnIndex);
/*     */   }
/*     */ 
/*     */   private V getIndexed(Integer rowIndex, Integer columnIndex) {
/* 324 */     return (rowIndex == null) || (columnIndex == null) ? null : this.array[rowIndex.intValue()][columnIndex.intValue()];
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 332 */     return false;
/*     */   }
/*     */ 
/*     */   public V put(R rowKey, C columnKey, @Nullable V value)
/*     */   {
/* 342 */     Preconditions.checkNotNull(rowKey);
/* 343 */     Preconditions.checkNotNull(columnKey);
/* 344 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 345 */     Preconditions.checkArgument(rowIndex != null, "Row %s not in %s", new Object[] { rowKey, this.rowList });
/* 346 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 347 */     Preconditions.checkArgument(columnIndex != null, "Column %s not in %s", new Object[] { columnKey, this.columnList });
/*     */ 
/* 349 */     return set(rowIndex.intValue(), columnIndex.intValue(), value);
/*     */   }
/*     */ 
/*     */   public void putAll(Table<? extends R, ? extends C, ? extends V> table)
/*     */   {
/* 367 */     for (Table.Cell cell : table.cellSet())
/* 368 */       put(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public V remove(Object rowKey, Object columnKey)
/*     */   {
/* 379 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public V erase(@Nullable Object rowKey, @Nullable Object columnKey)
/*     */   {
/* 396 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 397 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 398 */     if ((rowIndex == null) || (columnIndex == null)) {
/* 399 */       return null;
/*     */     }
/* 401 */     return set(rowIndex.intValue(), columnIndex.intValue(), null);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 407 */     return this.rowList.size() * this.columnList.size();
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object obj) {
/* 411 */     if ((obj instanceof Table)) {
/* 412 */       Table other = (Table)obj;
/* 413 */       return cellSet().equals(other.cellSet());
/*     */     }
/* 415 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 419 */     return cellSet().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 426 */     return rowMap().toString();
/*     */   }
/*     */ 
/*     */   public Set<Table.Cell<R, C, V>> cellSet()
/*     */   {
/* 441 */     CellSet set = this.cellSet;
/* 442 */     return set == null ? (this.cellSet = new CellSet(null)) : set;
/*     */   }
/*     */ 
/*     */   public Map<R, V> column(C columnKey)
/*     */   {
/* 497 */     Preconditions.checkNotNull(columnKey);
/* 498 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 499 */     return columnIndex == null ? ImmutableMap.of() : new Column(columnIndex.intValue());
/*     */   }
/*     */ 
/*     */   public ImmutableSet<C> columnKeySet()
/*     */   {
/* 575 */     return this.columnKeyToIndex.keySet();
/*     */   }
/*     */ 
/*     */   public Map<C, Map<R, V>> columnMap()
/*     */   {
/* 581 */     ColumnMap map = this.columnMap;
/* 582 */     return map == null ? (this.columnMap = new ColumnMap(null)) : map;
/*     */   }
/*     */ 
/*     */   public Map<C, V> row(R rowKey)
/*     */   {
/* 640 */     Preconditions.checkNotNull(rowKey);
/* 641 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 642 */     return rowIndex == null ? ImmutableMap.of() : new Row(rowIndex.intValue());
/*     */   }
/*     */ 
/*     */   public ImmutableSet<R> rowKeySet()
/*     */   {
/* 718 */     return this.rowKeyToIndex.keySet();
/*     */   }
/*     */ 
/*     */   public Map<R, Map<C, V>> rowMap()
/*     */   {
/* 724 */     RowMap map = this.rowMap;
/* 725 */     return map == null ? (this.rowMap = new RowMap(null)) : map;
/*     */   }
/*     */ 
/*     */   public Collection<V> values()
/*     */   {
/* 778 */     Collection v = this.values;
/* 779 */     return v == null ? (this.values = new Values(null)) : v;
/*     */   }
/*     */   private class Values extends AbstractCollection<V> {
/*     */     private Values() {
/*     */     }
/* 784 */     public Iterator<V> iterator() { return new AbstractIndexedIterator(size()) {
/*     */         protected V get(int index) {
/* 786 */           int rowIndex = index / ArrayTable.this.columnList.size();
/* 787 */           int columnIndex = index % ArrayTable.this.columnList.size();
/* 788 */           return ArrayTable.this.array[rowIndex][columnIndex];
/*     */         }
/*     */       }; }
/*     */ 
/*     */     public int size() {
/* 794 */       return ArrayTable.this.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object value) {
/* 798 */       return ArrayTable.this.containsValue(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class RowMapEntrySet extends AbstractSet<Map.Entry<R, Map<C, V>>>
/*     */   {
/*     */     private RowMapEntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<R, Map<C, V>>> iterator()
/*     */     {
/* 756 */       return new AbstractIndexedIterator(size()) {
/*     */         protected Map.Entry<R, Map<C, V>> get(int index) {
/* 758 */           return Maps.immutableEntry(ArrayTable.this.rowList.get(index), new ArrayTable.Row(ArrayTable.this, index));
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public int size() {
/* 765 */       return ArrayTable.this.rowList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class RowMap extends AbstractMap<R, Map<C, V>>
/*     */   {
/*     */     transient ArrayTable<R, C, V>.RowMapEntrySet entrySet;
/*     */ 
/*     */     private RowMap()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<R, Map<C, V>>> entrySet()
/*     */     {
/* 732 */       ArrayTable.RowMapEntrySet set = this.entrySet;
/* 733 */       return set == null ? (this.entrySet = new ArrayTable.RowMapEntrySet(ArrayTable.this, null)) : set;
/*     */     }
/*     */ 
/*     */     public Map<C, V> get(Object rowKey) {
/* 737 */       Integer rowIndex = (Integer)ArrayTable.this.rowKeyToIndex.get(rowKey);
/* 738 */       return rowIndex == null ? null : new ArrayTable.Row(ArrayTable.this, rowIndex.intValue());
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object rowKey) {
/* 742 */       return ArrayTable.this.containsRow(rowKey);
/*     */     }
/*     */ 
/*     */     public Set<R> keySet() {
/* 746 */       return ArrayTable.this.rowKeySet();
/*     */     }
/*     */ 
/*     */     public Map<C, V> remove(Object rowKey) {
/* 750 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class RowEntrySet extends AbstractSet<Map.Entry<C, V>>
/*     */   {
/*     */     final int rowIndex;
/*     */ 
/*     */     RowEntrySet(int rowIndex)
/*     */     {
/* 685 */       this.rowIndex = rowIndex;
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<C, V>> iterator() {
/* 689 */       return new AbstractIndexedIterator(size()) {
/*     */         protected Map.Entry<C, V> get(int columnIndex) {
/* 691 */           return new AbstractMapEntry(columnIndex) {
/*     */             public C getKey() {
/* 693 */               return ArrayTable.this.columnList.get(this.val$columnIndex);
/*     */             }
/*     */             public V getValue() {
/* 696 */               return ArrayTable.this.array[ArrayTable.RowEntrySet.this.rowIndex][this.val$columnIndex];
/*     */             }
/*     */             public V setValue(V value) {
/* 699 */               return ArrayTable.this.set(ArrayTable.RowEntrySet.this.rowIndex, this.val$columnIndex, value);
/*     */             } } ;
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 707 */       return ArrayTable.this.columnList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Row extends AbstractMap<C, V>
/*     */   {
/*     */     final int rowIndex;
/*     */     ArrayTable<R, C, V>.RowEntrySet entrySet;
/*     */ 
/*     */     Row(int rowIndex)
/*     */     {
/* 649 */       this.rowIndex = rowIndex;
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<C, V>> entrySet()
/*     */     {
/* 655 */       ArrayTable.RowEntrySet set = this.entrySet;
/* 656 */       return set == null ? (this.entrySet = new ArrayTable.RowEntrySet(ArrayTable.this, this.rowIndex)) : set;
/*     */     }
/*     */ 
/*     */     public V get(Object columnKey) {
/* 660 */       Integer columnIndex = (Integer)ArrayTable.this.columnKeyToIndex.get(columnKey);
/* 661 */       return ArrayTable.this.getIndexed(Integer.valueOf(this.rowIndex), columnIndex);
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object columnKey) {
/* 665 */       return ArrayTable.this.containsColumn(columnKey);
/*     */     }
/*     */ 
/*     */     public V put(C columnKey, V value) {
/* 669 */       Preconditions.checkNotNull(columnKey);
/* 670 */       Integer columnIndex = (Integer)ArrayTable.this.columnKeyToIndex.get(columnKey);
/* 671 */       Preconditions.checkArgument(columnIndex != null, "Column %s not in %s", new Object[] { columnKey, ArrayTable.access$100(ArrayTable.this) });
/*     */ 
/* 673 */       return ArrayTable.this.set(this.rowIndex, columnIndex.intValue(), value);
/*     */     }
/*     */ 
/*     */     public Set<C> keySet() {
/* 677 */       return ArrayTable.this.columnKeySet();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ColumnMapEntrySet extends AbstractSet<Map.Entry<C, Map<R, V>>>
/*     */   {
/*     */     private ColumnMapEntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<C, Map<R, V>>> iterator()
/*     */     {
/* 613 */       return new AbstractIndexedIterator(size()) {
/*     */         protected Map.Entry<C, Map<R, V>> get(int index) {
/* 615 */           return Maps.immutableEntry(ArrayTable.this.columnList.get(index), new ArrayTable.Column(ArrayTable.this, index));
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public int size() {
/* 622 */       return ArrayTable.this.columnList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ColumnMap extends AbstractMap<C, Map<R, V>>
/*     */   {
/*     */     transient ArrayTable<R, C, V>.ColumnMapEntrySet entrySet;
/*     */ 
/*     */     private ColumnMap()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<C, Map<R, V>>> entrySet()
/*     */     {
/* 589 */       ArrayTable.ColumnMapEntrySet set = this.entrySet;
/* 590 */       return set == null ? (this.entrySet = new ArrayTable.ColumnMapEntrySet(ArrayTable.this, null)) : set;
/*     */     }
/*     */ 
/*     */     public Map<R, V> get(Object columnKey) {
/* 594 */       Integer columnIndex = (Integer)ArrayTable.this.columnKeyToIndex.get(columnKey);
/* 595 */       return columnIndex == null ? null : new ArrayTable.Column(ArrayTable.this, columnIndex.intValue());
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object columnKey) {
/* 599 */       return ArrayTable.this.containsColumn(columnKey);
/*     */     }
/*     */ 
/*     */     public Set<C> keySet() {
/* 603 */       return ArrayTable.this.columnKeySet();
/*     */     }
/*     */ 
/*     */     public Map<R, V> remove(Object columnKey) {
/* 607 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ColumnEntrySet extends AbstractSet<Map.Entry<R, V>>
/*     */   {
/*     */     final int columnIndex;
/*     */ 
/*     */     ColumnEntrySet(int columnIndex)
/*     */     {
/* 542 */       this.columnIndex = columnIndex;
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<R, V>> iterator() {
/* 546 */       return new AbstractIndexedIterator(size()) {
/*     */         protected Map.Entry<R, V> get(int rowIndex) {
/* 548 */           return new AbstractMapEntry(rowIndex) {
/*     */             public R getKey() {
/* 550 */               return ArrayTable.this.rowList.get(this.val$rowIndex);
/*     */             }
/*     */             public V getValue() {
/* 553 */               return ArrayTable.this.array[this.val$rowIndex][ArrayTable.ColumnEntrySet.this.columnIndex];
/*     */             }
/*     */             public V setValue(V value) {
/* 556 */               return ArrayTable.this.set(this.val$rowIndex, ArrayTable.ColumnEntrySet.this.columnIndex, value);
/*     */             } } ;
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 564 */       return ArrayTable.this.rowList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Column extends AbstractMap<R, V>
/*     */   {
/*     */     final int columnIndex;
/*     */     ArrayTable<R, C, V>.ColumnEntrySet entrySet;
/*     */ 
/*     */     Column(int columnIndex)
/*     */     {
/* 507 */       this.columnIndex = columnIndex;
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<R, V>> entrySet()
/*     */     {
/* 513 */       ArrayTable.ColumnEntrySet set = this.entrySet;
/* 514 */       return set == null ? (this.entrySet = new ArrayTable.ColumnEntrySet(ArrayTable.this, this.columnIndex)) : set;
/*     */     }
/*     */ 
/*     */     public V get(Object rowKey) {
/* 518 */       Integer rowIndex = (Integer)ArrayTable.this.rowKeyToIndex.get(rowKey);
/* 519 */       return ArrayTable.this.getIndexed(rowIndex, Integer.valueOf(this.columnIndex));
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object rowKey) {
/* 523 */       return ArrayTable.this.rowKeyToIndex.containsKey(rowKey);
/*     */     }
/*     */ 
/*     */     public V put(R rowKey, V value) {
/* 527 */       Preconditions.checkNotNull(rowKey);
/* 528 */       Integer rowIndex = (Integer)ArrayTable.this.rowKeyToIndex.get(rowKey);
/* 529 */       Preconditions.checkArgument(rowIndex != null, "Row %s not in %s", new Object[] { rowKey, ArrayTable.access$200(ArrayTable.this) });
/* 530 */       return ArrayTable.this.set(rowIndex.intValue(), this.columnIndex, value);
/*     */     }
/*     */ 
/*     */     public Set<R> keySet() {
/* 534 */       return ArrayTable.this.rowKeySet();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class CellSet extends AbstractSet<Table.Cell<R, C, V>>
/*     */   {
/*     */     private CellSet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Table.Cell<R, C, V>> iterator()
/*     */     {
/* 448 */       return new AbstractIndexedIterator(size()) {
/*     */         protected Table.Cell<R, C, V> get(int index) {
/* 450 */           return new Tables.AbstractCell(index) {
/* 451 */             final int rowIndex = this.val$index / ArrayTable.this.columnList.size();
/* 452 */             final int columnIndex = this.val$index % ArrayTable.this.columnList.size();
/*     */ 
/* 454 */             public R getRowKey() { return ArrayTable.this.rowList.get(this.rowIndex); }
/*     */ 
/*     */             public C getColumnKey() {
/* 457 */               return ArrayTable.this.columnList.get(this.columnIndex);
/*     */             }
/*     */             public V getValue() {
/* 460 */               return ArrayTable.this.array[this.rowIndex][this.columnIndex];
/*     */             } } ;
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 468 */       return ArrayTable.this.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object obj) {
/* 472 */       if ((obj instanceof Table.Cell)) {
/* 473 */         Table.Cell cell = (Table.Cell)obj;
/* 474 */         Integer rowIndex = (Integer)ArrayTable.this.rowKeyToIndex.get(cell.getRowKey());
/* 475 */         Integer columnIndex = (Integer)ArrayTable.this.columnKeyToIndex.get(cell.getColumnKey());
/* 476 */         return (rowIndex != null) && (columnIndex != null) && (Objects.equal(ArrayTable.this.array[rowIndex.intValue()][columnIndex.intValue()], cell.getValue()));
/*     */       }
/*     */ 
/* 480 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ArrayTable
 * JD-Core Version:    0.6.0
 */