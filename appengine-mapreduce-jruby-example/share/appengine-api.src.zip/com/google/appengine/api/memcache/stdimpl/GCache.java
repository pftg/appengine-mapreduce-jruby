/*     */ package com.google.appengine.api.memcache.stdimpl;
/*     */ 
/*     */ import com.google.appengine.api.memcache.Expiration;
/*     */ import com.google.appengine.api.memcache.MemcacheService;
/*     */ import com.google.appengine.api.memcache.MemcacheService.SetPolicy;
/*     */ import com.google.appengine.api.memcache.MemcacheServiceFactory;
/*     */ import com.google.appengine.api.memcache.Stats;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.cache.Cache;
/*     */ import javax.cache.CacheEntry;
/*     */ import javax.cache.CacheListener;
/*     */ import javax.cache.CacheStatistics;
/*     */ 
/*     */ public class GCache
/*     */   implements Cache
/*     */ {
/*     */   private final MemcacheService service;
/*     */   private final List<CacheListener> listeners;
/*     */   private final Expiration expiration;
/*     */   private final MemcacheService.SetPolicy setPolicy;
/*     */ 
/*     */   public GCache(Map properties)
/*     */   {
/*  40 */     this.listeners = new LinkedList();
/*  41 */     if (properties != null)
/*     */     {
/*  43 */       Object expirationProperty = properties.get(Integer.valueOf(0));
/*     */ 
/*  45 */       int millis = 0;
/*  46 */       if ((expirationProperty instanceof Integer)) {
/*  47 */         millis = ((Integer)expirationProperty).intValue() * 1000;
/*     */       }
/*     */ 
/*  50 */       expirationProperty = properties.get(Integer.valueOf(1));
/*     */ 
/*  52 */       if ((expirationProperty instanceof Integer)) {
/*  53 */         millis = ((Integer)expirationProperty).intValue();
/*     */       }
/*  55 */       if (millis != 0) {
/*  56 */         this.expiration = Expiration.byDeltaMillis(millis);
/*     */       } else {
/*  58 */         expirationProperty = properties.get(Integer.valueOf(2));
/*  59 */         if ((expirationProperty instanceof Date))
/*  60 */           this.expiration = Expiration.onDate((Date)expirationProperty);
/*     */         else {
/*  62 */           this.expiration = null;
/*     */         }
/*     */       }
/*  65 */       Object setProperty = properties.get(Integer.valueOf(3));
/*  66 */       if ((setProperty instanceof MemcacheService.SetPolicy))
/*  67 */         this.setPolicy = ((MemcacheService.SetPolicy)setProperty);
/*     */       else {
/*  69 */         this.setPolicy = MemcacheService.SetPolicy.SET_ALWAYS;
/*     */       }
/*  71 */       Object memcacheService = properties.get(Integer.valueOf(4));
/*  72 */       if ((memcacheService instanceof MemcacheService)) {
/*  73 */         this.service = ((MemcacheService)memcacheService);
/*     */       } else {
/*  75 */         Object namespace = properties.get(Integer.valueOf(5));
/*  76 */         if (!(namespace instanceof String)) {
/*  77 */           namespace = null;
/*     */         }
/*  79 */         this.service = MemcacheServiceFactory.getMemcacheService((String)namespace);
/*     */       }
/*     */     }
/*     */     else {
/*  83 */       this.expiration = null;
/*  84 */       this.setPolicy = MemcacheService.SetPolicy.SET_ALWAYS;
/*  85 */       this.service = MemcacheServiceFactory.getMemcacheService();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addListener(CacheListener cacheListener) {
/*  90 */     this.listeners.add(cacheListener);
/*     */   }
/*     */ 
/*     */   public void evict()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Map getAll(Collection collection)
/*     */   {
/*  99 */     return this.service.getAll(collection);
/*     */   }
/*     */ 
/*     */   public CacheEntry getCacheEntry(Object o) {
/* 103 */     Object value = this.service.get(o);
/* 104 */     if ((value == null) && (!this.service.contains(o))) {
/* 105 */       return null;
/*     */     }
/* 107 */     return new GCacheEntry(this, o, value);
/*     */   }
/*     */ 
/*     */   public CacheStatistics getCacheStatistics() {
/* 111 */     return new GCacheStats(this.service.getStatistics(), null);
/*     */   }
/*     */ 
/*     */   public void load(Object o)
/*     */   {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void loadAll(Collection collection)
/*     */   {
/* 127 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object peek(Object o) {
/* 131 */     return get(o);
/*     */   }
/*     */ 
/*     */   public void removeListener(CacheListener cacheListener) {
/* 135 */     this.listeners.remove(cacheListener);
/*     */   }
/*     */ 
/*     */   public int size() {
/* 139 */     return getCacheStatistics().getObjectCount();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 143 */     return size() == 0;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/* 147 */     return this.service.contains(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 154 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/* 158 */     return this.service.get(key);
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value) {
/* 162 */     for (CacheListener listener : this.listeners) {
/* 163 */       listener.onPut(value);
/*     */     }
/* 165 */     if (!this.service.put(key, value, this.expiration, this.setPolicy)) {
/* 166 */       throw new GCacheException("Policy prevented put operation");
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   public Object remove(Object key) {
/* 172 */     for (CacheListener listener : this.listeners) {
/* 173 */       listener.onRmove(key);
/*     */     }
/* 175 */     Object value = this.service.get(key);
/* 176 */     this.service.delete(key);
/* 177 */     return value;
/*     */   }
/*     */ 
/*     */   public void putAll(Map m)
/*     */   {
/* 182 */     Set added = this.service.putAll(m, this.expiration, this.setPolicy);
/* 183 */     added.removeAll(m.keySet());
/* 184 */     if (!added.isEmpty())
/* 185 */       throw new GCacheException("Policy prevented some put operations");
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 190 */     for (CacheListener listener : this.listeners) {
/* 191 */       listener.onClear();
/*     */     }
/* 193 */     this.service.clearAll();
/*     */   }
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 200 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 207 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/* 214 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   private static class GCacheStats
/*     */     implements CacheStatistics
/*     */   {
/*     */     private Stats stats;
/*     */ 
/*     */     private GCacheStats(Stats stats)
/*     */     {
/* 230 */       this.stats = stats;
/*     */     }
/*     */ 
/*     */     public void clearStatistics() {
/* 234 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int getCacheHits() {
/* 238 */       return (int)this.stats.getHitCount();
/*     */     }
/*     */ 
/*     */     public int getCacheMisses() {
/* 242 */       return (int)this.stats.getMissCount();
/*     */     }
/*     */ 
/*     */     public int getObjectCount() {
/* 246 */       return (int)this.stats.getItemCount();
/*     */     }
/*     */ 
/*     */     public int getStatisticsAccuracy() {
/* 250 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 254 */       return this.stats.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.stdimpl.GCache
 * JD-Core Version:    0.6.0
 */