/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ @GwtCompatible
/*    */ abstract class AbstractIndexedIterator<E> extends UnmodifiableIterator<E>
/*    */ {
/*    */   private final int size;
/*    */   private int position;
/*    */ 
/*    */   protected abstract E get(int paramInt);
/*    */ 
/*    */   protected AbstractIndexedIterator(int size)
/*    */   {
/* 46 */     this.size = size;
/*    */   }
/*    */ 
/*    */   public final boolean hasNext() {
/* 50 */     return this.position < this.size;
/*    */   }
/*    */ 
/*    */   public final E next() {
/* 54 */     if (!hasNext()) {
/* 55 */       throw new NoSuchElementException();
/*    */     }
/* 57 */     return get(this.position++);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.AbstractIndexedIterator
 * JD-Core Version:    0.6.0
 */