/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(emulated=true)
/*     */ abstract class AbstractMapBasedMultiset<E> extends AbstractMultiset<E>
/*     */   implements Serializable
/*     */ {
/*     */   private transient Map<E, AtomicInteger> backingMap;
/*     */   private transient long size;
/*     */   private transient AbstractMapBasedMultiset<E>.EntrySet entrySet;
/*     */ 
/*     */   @GwtIncompatible("not needed in emulated source.")
/*     */   private static final long serialVersionUID = -2250766705698539974L;
/*     */ 
/*     */   protected AbstractMapBasedMultiset(Map<E, AtomicInteger> backingMap)
/*     */   {
/*  67 */     this.backingMap = ((Map)Preconditions.checkNotNull(backingMap));
/*  68 */     this.size = super.size();
/*     */   }
/*     */ 
/*     */   Map<E, AtomicInteger> backingMap() {
/*  72 */     return this.backingMap;
/*     */   }
/*     */ 
/*     */   void setBackingMap(Map<E, AtomicInteger> backingMap)
/*     */   {
/*  77 */     this.backingMap = backingMap;
/*     */   }
/*     */ 
/*     */   public Set<Multiset.Entry<E>> entrySet()
/*     */   {
/*  92 */     EntrySet result = this.entrySet;
/*  93 */     if (result == null) {
/*  94 */       this.entrySet = (result = new EntrySet(null));
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 178 */     return Ints.saturatedCast(this.size);
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator() {
/* 182 */     return new MapBasedMultisetIterator();
/*     */   }
/*     */ 
/*     */   public int count(@Nullable Object element)
/*     */   {
/* 230 */     AtomicInteger frequency = (AtomicInteger)this.backingMap.get(element);
/* 231 */     return frequency == null ? 0 : frequency.get();
/*     */   }
/*     */ 
/*     */   public int add(@Nullable E element, int occurrences)
/*     */   {
/* 244 */     if (occurrences == 0) {
/* 245 */       return count(element);
/*     */     }
/* 247 */     Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", new Object[] { Integer.valueOf(occurrences) });
/*     */ 
/* 249 */     AtomicInteger frequency = (AtomicInteger)this.backingMap.get(element);
/*     */     int oldCount;
/* 251 */     if (frequency == null) {
/* 252 */       int oldCount = 0;
/* 253 */       this.backingMap.put(element, new AtomicInteger(occurrences));
/*     */     } else {
/* 255 */       oldCount = frequency.get();
/* 256 */       long newCount = oldCount + occurrences;
/* 257 */       Preconditions.checkArgument(newCount <= 2147483647L, "too many occurrences: %s", new Object[] { Long.valueOf(newCount) });
/*     */ 
/* 259 */       frequency.getAndAdd(occurrences);
/*     */     }
/* 261 */     this.size += occurrences;
/* 262 */     return oldCount;
/*     */   }
/*     */ 
/*     */   public int remove(@Nullable Object element, int occurrences) {
/* 266 */     if (occurrences == 0) {
/* 267 */       return count(element);
/*     */     }
/* 269 */     Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", new Object[] { Integer.valueOf(occurrences) });
/*     */ 
/* 271 */     AtomicInteger frequency = (AtomicInteger)this.backingMap.get(element);
/* 272 */     if (frequency == null) {
/* 273 */       return 0;
/*     */     }
/*     */ 
/* 276 */     int oldCount = frequency.get();
/*     */     int numberRemoved;
/*     */     int numberRemoved;
/* 279 */     if (oldCount > occurrences) {
/* 280 */       numberRemoved = occurrences;
/*     */     } else {
/* 282 */       numberRemoved = oldCount;
/* 283 */       this.backingMap.remove(element);
/*     */     }
/*     */ 
/* 286 */     frequency.addAndGet(-numberRemoved);
/* 287 */     this.size -= numberRemoved;
/* 288 */     return oldCount;
/*     */   }
/*     */ 
/*     */   public int setCount(E element, int count)
/*     */   {
/* 293 */     Multisets.checkNonnegative(count, "count");
/*     */     int oldCount;
/*     */     int oldCount;
/* 297 */     if (count == 0) {
/* 298 */       AtomicInteger existingCounter = (AtomicInteger)this.backingMap.remove(element);
/* 299 */       oldCount = getAndSet(existingCounter, count);
/*     */     } else {
/* 301 */       AtomicInteger existingCounter = (AtomicInteger)this.backingMap.get(element);
/* 302 */       oldCount = getAndSet(existingCounter, count);
/*     */ 
/* 304 */       if (existingCounter == null) {
/* 305 */         this.backingMap.put(element, new AtomicInteger(count));
/*     */       }
/*     */     }
/*     */ 
/* 309 */     this.size += count - oldCount;
/* 310 */     return oldCount;
/*     */   }
/*     */ 
/*     */   private static int getAndSet(AtomicInteger i, int count) {
/* 314 */     if (i == null) {
/* 315 */       return 0;
/*     */     }
/*     */ 
/* 318 */     return i.getAndSet(count);
/*     */   }
/*     */ 
/*     */   private int removeAllOccurrences(@Nullable Object element, Map<E, AtomicInteger> map)
/*     */   {
/* 323 */     AtomicInteger frequency = (AtomicInteger)map.remove(element);
/* 324 */     if (frequency == null) {
/* 325 */       return 0;
/*     */     }
/* 327 */     int numberRemoved = frequency.getAndSet(0);
/* 328 */     this.size -= numberRemoved;
/* 329 */     return numberRemoved;
/*     */   }
/*     */ 
/*     */   Set<E> createElementSet()
/*     */   {
/* 335 */     return new MapBasedElementSet(this.backingMap);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectStreamException")
/*     */   private void readObjectNoData()
/*     */     throws ObjectStreamException
/*     */   {
/* 414 */     throw new InvalidObjectException("Stream data required");
/*     */   }
/*     */ 
/*     */   class MapBasedElementSet extends ForwardingSet<E>
/*     */   {
/*     */     private final Map<E, AtomicInteger> map;
/*     */     private final Set<E> delegate;
/*     */ 
/*     */     MapBasedElementSet()
/*     */     {
/* 346 */       this.map = map;
/* 347 */       this.delegate = map.keySet();
/*     */     }
/*     */ 
/*     */     protected Set<E> delegate() {
/* 351 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     public Iterator<E> iterator()
/*     */     {
/* 357 */       Iterator entries = this.map.entrySet().iterator();
/*     */ 
/* 359 */       return new Iterator(entries) {
/*     */         Map.Entry<E, AtomicInteger> toRemove;
/*     */ 
/* 363 */         public boolean hasNext() { return this.val$entries.hasNext(); }
/*     */ 
/*     */         public E next()
/*     */         {
/* 367 */           this.toRemove = ((Map.Entry)this.val$entries.next());
/* 368 */           return this.toRemove.getKey();
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 372 */           Preconditions.checkState(this.toRemove != null, "no calls to next() since the last call to remove()");
/*     */ 
/* 374 */           AbstractMapBasedMultiset.access$222(AbstractMapBasedMultiset.this, ((AtomicInteger)this.toRemove.getValue()).getAndSet(0));
/* 375 */           this.val$entries.remove();
/* 376 */           this.toRemove = null;
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public boolean remove(Object element) {
/* 382 */       return AbstractMapBasedMultiset.this.removeAllOccurrences(element, this.map) != 0;
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> elementsToRemove) {
/* 386 */       return Iterators.removeAll(iterator(), elementsToRemove);
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> elementsToRetain) {
/* 390 */       return Iterators.retainAll(iterator(), elementsToRetain);
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 394 */       if (this.map == AbstractMapBasedMultiset.this.backingMap) {
/* 395 */         AbstractMapBasedMultiset.this.clear();
/*     */       } else {
/* 397 */         Iterator i = iterator();
/* 398 */         while (i.hasNext()) {
/* 399 */           i.next();
/* 400 */           i.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public Map<E, AtomicInteger> getMap() {
/* 406 */       return this.map;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MapBasedMultisetIterator
/*     */     implements Iterator<E>
/*     */   {
/*     */     final Iterator<Map.Entry<E, AtomicInteger>> entryIterator;
/*     */     Map.Entry<E, AtomicInteger> currentEntry;
/*     */     int occurrencesLeft;
/*     */     boolean canRemove;
/*     */ 
/*     */     MapBasedMultisetIterator()
/*     */     {
/* 197 */       this.entryIterator = AbstractMapBasedMultiset.this.backingMap.entrySet().iterator();
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 201 */       return (this.occurrencesLeft > 0) || (this.entryIterator.hasNext());
/*     */     }
/*     */ 
/*     */     public E next() {
/* 205 */       if (this.occurrencesLeft == 0) {
/* 206 */         this.currentEntry = ((Map.Entry)this.entryIterator.next());
/* 207 */         this.occurrencesLeft = ((AtomicInteger)this.currentEntry.getValue()).get();
/*     */       }
/* 209 */       this.occurrencesLeft -= 1;
/* 210 */       this.canRemove = true;
/* 211 */       return this.currentEntry.getKey();
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 215 */       Preconditions.checkState(this.canRemove, "no calls to next() since the last call to remove()");
/*     */ 
/* 217 */       int frequency = ((AtomicInteger)this.currentEntry.getValue()).get();
/* 218 */       if (frequency <= 0) {
/* 219 */         throw new ConcurrentModificationException();
/*     */       }
/* 221 */       if (((AtomicInteger)this.currentEntry.getValue()).addAndGet(-1) == 0) {
/* 222 */         this.entryIterator.remove();
/*     */       }
/* 224 */       AbstractMapBasedMultiset.access$210(AbstractMapBasedMultiset.this);
/* 225 */       this.canRemove = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EntrySet extends AbstractSet<Multiset.Entry<E>>
/*     */   {
/*     */     private EntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Multiset.Entry<E>> iterator()
/*     */     {
/* 101 */       Iterator backingEntries = AbstractMapBasedMultiset.this.backingMap.entrySet().iterator();
/*     */ 
/* 103 */       return new Iterator(backingEntries) {
/*     */         Map.Entry<E, AtomicInteger> toRemove;
/*     */ 
/* 107 */         public boolean hasNext() { return this.val$backingEntries.hasNext(); }
/*     */ 
/*     */         public Multiset.Entry<E> next()
/*     */         {
/* 111 */           Map.Entry mapEntry = (Map.Entry)this.val$backingEntries.next();
/* 112 */           this.toRemove = mapEntry;
/* 113 */           return new Multisets.AbstractEntry(mapEntry) {
/*     */             public E getElement() {
/* 115 */               return this.val$mapEntry.getKey();
/*     */             }
/*     */             public int getCount() {
/* 118 */               int count = ((AtomicInteger)this.val$mapEntry.getValue()).get();
/* 119 */               if (count == 0) {
/* 120 */                 AtomicInteger frequency = (AtomicInteger)AbstractMapBasedMultiset.this.backingMap.get(getElement());
/* 121 */                 if (frequency != null) {
/* 122 */                   count = frequency.get();
/*     */                 }
/*     */               }
/* 125 */               return count;
/*     */             } } ;
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 131 */           Preconditions.checkState(this.toRemove != null, "no calls to next() since the last call to remove()");
/*     */ 
/* 133 */           AbstractMapBasedMultiset.access$222(AbstractMapBasedMultiset.this, ((AtomicInteger)this.toRemove.getValue()).getAndSet(0));
/* 134 */           this.val$backingEntries.remove();
/* 135 */           this.toRemove = null;
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 141 */       return AbstractMapBasedMultiset.this.backingMap.size();
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 147 */       for (AtomicInteger frequency : AbstractMapBasedMultiset.this.backingMap.values()) {
/* 148 */         frequency.set(0);
/*     */       }
/* 150 */       AbstractMapBasedMultiset.this.backingMap.clear();
/* 151 */       AbstractMapBasedMultiset.access$202(AbstractMapBasedMultiset.this, 0L);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 155 */       if ((o instanceof Multiset.Entry)) {
/* 156 */         Multiset.Entry entry = (Multiset.Entry)o;
/* 157 */         int count = AbstractMapBasedMultiset.this.count(entry.getElement());
/* 158 */         return (count == entry.getCount()) && (count > 0);
/*     */       }
/* 160 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 164 */       if (contains(o)) {
/* 165 */         Multiset.Entry entry = (Multiset.Entry)o;
/* 166 */         AtomicInteger frequency = (AtomicInteger)AbstractMapBasedMultiset.this.backingMap.remove(entry.getElement());
/* 167 */         int numberRemoved = frequency.getAndSet(0);
/* 168 */         AbstractMapBasedMultiset.access$222(AbstractMapBasedMultiset.this, numberRemoved);
/* 169 */         return true;
/*     */       }
/* 171 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.AbstractMapBasedMultiset
 * JD-Core Version:    0.6.0
 */