/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import java.util.Collection;
/*    */ 
/*    */ @GoogleInternal
/*    */ public final class Receivers
/*    */ {
/* 36 */   private static final Receiver<Object> IGNORING_RECEIVER = new Receiver() {
/*    */     public void accept(Object object) {  } } ;
/*    */ 
/*    */   public static <T> Receiver<T> ignore()
/*    */   {
/* 46 */     return IGNORING_RECEIVER;
/*    */   }
/*    */ 
/*    */   public static <T> Receiver<T> collect(Collection<? super T> collection)
/*    */   {
/* 58 */     return new Receiver(collection) {
/*    */       public void accept(T object) {
/* 60 */         this.val$collection.add(object);
/*    */       }
/*    */     };
/*    */   }
/*    */ 
/*    */   public static <T> Receiver<T> compose(Receiver<? super T>[] receivers)
/*    */   {
/* 77 */     return new Receiver(receivers) {
/*    */       public void accept(T object) {
/* 79 */         for (Receiver receiver : this.val$receivers)
/* 80 */           receiver.accept(object);
/*    */       }
/*    */     };
/*    */   }
/*    */ 
/*    */   public static <T> Receiver<T> compose(Iterable<Receiver<T>> receivers)
/*    */   {
/* 97 */     return new Receiver(receivers) {
/*    */       public void accept(T object) {
/* 99 */         for (Receiver receiver : this.val$receivers)
/* 100 */           receiver.accept(object);
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Receivers
 * JD-Core Version:    0.6.0
 */