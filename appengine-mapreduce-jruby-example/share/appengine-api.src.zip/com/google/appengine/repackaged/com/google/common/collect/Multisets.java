/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Multisets
/*     */ {
/*     */   public static <E> Multiset<E> unmodifiableMultiset(Multiset<? extends E> multiset)
/*     */   {
/*  61 */     return new UnmodifiableMultiset((Multiset)Preconditions.checkNotNull(multiset));
/*     */   }
/*     */ 
/*     */   public static <E> Multiset.Entry<E> immutableEntry(@Nullable E e, int n)
/*     */   {
/* 157 */     Preconditions.checkArgument(n >= 0);
/* 158 */     return new AbstractEntry(e, n) {
/*     */       public E getElement() {
/* 160 */         return this.val$e;
/*     */       }
/*     */       public int getCount() {
/* 163 */         return this.val$n;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   static <E> Multiset<E> forSet(Set<E> set)
/*     */   {
/* 186 */     return new SetMultiset(set);
/*     */   }
/*     */ 
/*     */   static int inferDistinctElements(Iterable<?> elements)
/*     */   {
/* 321 */     if ((elements instanceof Multiset)) {
/* 322 */       return ((Multiset)elements).elementSet().size();
/*     */     }
/* 324 */     return 11;
/*     */   }
/*     */ 
/*     */   public static <E> Multiset<E> intersection(Multiset<E> multiset1, Multiset<?> multiset2)
/*     */   {
/* 342 */     Preconditions.checkNotNull(multiset1);
/* 343 */     Preconditions.checkNotNull(multiset2);
/*     */ 
/* 345 */     return new AbstractMultiset(multiset1, multiset2)
/*     */     {
/* 360 */       final Set<Multiset.Entry<E>> entrySet = new AbstractSet() {
/*     */         public Iterator<Multiset.Entry<E>> iterator() {
/* 362 */           Iterator iterator1 = Multisets.2.this.val$multiset1.entrySet().iterator();
/* 363 */           return new AbstractIterator(iterator1) {
/*     */             protected Multiset.Entry<E> computeNext() {
/* 365 */               while (this.val$iterator1.hasNext()) {
/* 366 */                 Multiset.Entry entry1 = (Multiset.Entry)this.val$iterator1.next();
/* 367 */                 Object element = entry1.getElement();
/* 368 */                 int count = Math.min(entry1.getCount(), Multisets.2.this.val$multiset2.count(element));
/*     */ 
/* 370 */                 if (count > 0) {
/* 371 */                   return Multisets.immutableEntry(element, count);
/*     */                 }
/*     */               }
/* 374 */               return (Multiset.Entry)endOfData();
/*     */             } } ;
/*     */         }
/*     */ 
/*     */         public int size() {
/* 380 */           return Multisets.2.this.elementSet().size();
/*     */         }
/*     */ 
/*     */         public boolean contains(Object o) {
/* 384 */           if ((o instanceof Multiset.Entry)) {
/* 385 */             Multiset.Entry entry = (Multiset.Entry)o;
/* 386 */             int entryCount = entry.getCount();
/* 387 */             return (entryCount > 0) && (Multisets.2.this.count(entry.getElement()) == entryCount);
/*     */           }
/*     */ 
/* 390 */           return false;
/*     */         }
/*     */ 
/*     */         public boolean isEmpty() {
/* 394 */           return Multisets.2.this.elementSet().isEmpty();
/*     */         }
/* 360 */       };
/*     */ 
/*     */       public int count(Object element)
/*     */       {
/* 347 */         int count1 = this.val$multiset1.count(element);
/* 348 */         return count1 == 0 ? 0 : Math.min(count1, this.val$multiset2.count(element));
/*     */       }
/*     */ 
/*     */       Set<E> createElementSet() {
/* 352 */         return Sets.intersection(this.val$multiset1.elementSet(), this.val$multiset2.elementSet());
/*     */       }
/*     */ 
/*     */       public Set<Multiset.Entry<E>> entrySet()
/*     */       {
/* 357 */         return this.entrySet;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   static <E> int setCountImpl(Multiset<E> self, E element, int count)
/*     */   {
/* 442 */     checkNonnegative(count, "count");
/*     */ 
/* 444 */     int oldCount = self.count(element);
/*     */ 
/* 446 */     int delta = count - oldCount;
/* 447 */     if (delta > 0)
/* 448 */       self.add(element, delta);
/* 449 */     else if (delta < 0) {
/* 450 */       self.remove(element, -delta);
/*     */     }
/*     */ 
/* 453 */     return oldCount;
/*     */   }
/*     */ 
/*     */   static <E> boolean setCountImpl(Multiset<E> self, E element, int oldCount, int newCount)
/*     */   {
/* 458 */     checkNonnegative(oldCount, "oldCount");
/* 459 */     checkNonnegative(newCount, "newCount");
/*     */ 
/* 461 */     if (self.count(element) == oldCount) {
/* 462 */       self.setCount(element, newCount);
/* 463 */       return true;
/*     */     }
/* 465 */     return false;
/*     */   }
/*     */ 
/*     */   static void checkNonnegative(int count, String name)
/*     */   {
/* 470 */     Preconditions.checkArgument(count >= 0, "%s cannot be negative: %s", new Object[] { name, Integer.valueOf(count) });
/*     */   }
/*     */ 
/*     */   static abstract class AbstractEntry<E>
/*     */     implements Multiset.Entry<E>
/*     */   {
/*     */     public boolean equals(@Nullable Object object)
/*     */     {
/* 410 */       if ((object instanceof Multiset.Entry)) {
/* 411 */         Multiset.Entry that = (Multiset.Entry)object;
/* 412 */         return (getCount() == that.getCount()) && (Objects.equal(getElement(), that.getElement()));
/*     */       }
/*     */ 
/* 415 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 423 */       Object e = getElement();
/* 424 */       return (e == null ? 0 : e.hashCode()) ^ getCount();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 435 */       String text = String.valueOf(getElement());
/* 436 */       int n = getCount();
/* 437 */       return text + " x " + n;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SetMultiset<E> extends ForwardingCollection<E>
/*     */     implements Multiset<E>, Serializable
/*     */   {
/*     */     final Set<E> delegate;
/*     */     transient Set<E> elementSet;
/*     */     transient Set<Multiset.Entry<E>> entrySet;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SetMultiset(Set<E> set)
/*     */     {
/* 195 */       this.delegate = ((Set)Preconditions.checkNotNull(set));
/*     */     }
/*     */ 
/*     */     protected Set<E> delegate() {
/* 199 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     public int count(Object element) {
/* 203 */       return this.delegate.contains(element) ? 1 : 0;
/*     */     }
/*     */ 
/*     */     public int add(E element, int occurrences) {
/* 207 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int remove(Object element, int occurrences) {
/* 211 */       if (occurrences == 0) {
/* 212 */         return count(element);
/*     */       }
/* 214 */       Preconditions.checkArgument(occurrences > 0);
/* 215 */       return this.delegate.remove(element) ? 1 : 0;
/*     */     }
/*     */ 
/*     */     public Set<E> elementSet()
/*     */     {
/* 221 */       Set es = this.elementSet;
/* 222 */       return es == null ? (this.elementSet = new ElementSet()) : es;
/*     */     }
/*     */ 
/*     */     public Set<Multiset.Entry<E>> entrySet()
/*     */     {
/* 228 */       Set es = this.entrySet;
/* 229 */       return es == null ? (this.entrySet = new EntrySet()) : es;
/*     */     }
/*     */ 
/*     */     public boolean add(E o) {
/* 233 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection<? extends E> c) {
/* 237 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int setCount(E element, int count) {
/* 241 */       Multisets.checkNonnegative(count, "count");
/*     */ 
/* 243 */       if (count == count(element))
/* 244 */         return count;
/* 245 */       if (count == 0) {
/* 246 */         remove(element);
/* 247 */         return 1;
/*     */       }
/* 249 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean setCount(E element, int oldCount, int newCount)
/*     */     {
/* 254 */       return Multisets.setCountImpl(this, element, oldCount, newCount);
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object object) {
/* 258 */       if ((object instanceof Multiset)) {
/* 259 */         Multiset that = (Multiset)object;
/* 260 */         return (size() == that.size()) && (this.delegate.equals(that.elementSet()));
/*     */       }
/* 262 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 266 */       int sum = 0;
/* 267 */       for (Iterator i$ = iterator(); i$.hasNext(); ) { Object e = i$.next();
/* 268 */         sum += ((e == null ? 0 : e.hashCode()) ^ 0x1);
/*     */       }
/* 270 */       return sum;
/*     */     }
/*     */ 
/*     */     class EntrySet extends AbstractSet<Multiset.Entry<E>>
/*     */     {
/*     */       EntrySet()
/*     */       {
/*     */       }
/*     */ 
/*     */       public int size()
/*     */       {
/* 291 */         return Multisets.SetMultiset.this.delegate.size();
/*     */       }
/*     */       public Iterator<Multiset.Entry<E>> iterator() {
/* 294 */         return new Iterator() {
/* 295 */           final Iterator<E> elements = Multisets.SetMultiset.this.delegate.iterator();
/*     */ 
/*     */           public boolean hasNext() {
/* 298 */             return this.elements.hasNext();
/*     */           }
/*     */           public Multiset.Entry<E> next() {
/* 301 */             return Multisets.immutableEntry(this.elements.next(), 1);
/*     */           }
/*     */           public void remove() {
/* 304 */             this.elements.remove();
/*     */           }
/*     */         };
/*     */       }
/*     */     }
/*     */ 
/*     */     class ElementSet extends ForwardingSet<E>
/*     */     {
/*     */       ElementSet()
/*     */       {
/*     */       }
/*     */ 
/*     */       protected Set<E> delegate()
/*     */       {
/* 276 */         return Multisets.SetMultiset.this.delegate;
/*     */       }
/*     */ 
/*     */       public boolean add(E o) {
/* 280 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       public boolean addAll(Collection<? extends E> c) {
/* 284 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class UnmodifiableMultiset<E> extends ForwardingMultiset<E>
/*     */     implements Serializable
/*     */   {
/*     */     final Multiset<? extends E> delegate;
/*     */     transient Set<E> elementSet;
/*     */     transient Set<Multiset.Entry<E>> entrySet;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     UnmodifiableMultiset(Multiset<? extends E> delegate)
/*     */     {
/*  69 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     protected Multiset<E> delegate()
/*     */     {
/*  75 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     public Set<E> elementSet()
/*     */     {
/*  81 */       Set es = this.elementSet;
/*  82 */       return es == null ? (this.elementSet = Collections.unmodifiableSet(this.delegate.elementSet())) : es;
/*     */     }
/*     */ 
/*     */     public Set<Multiset.Entry<E>> entrySet()
/*     */     {
/*  91 */       Set es = this.entrySet;
/*  92 */       return es == null ? (this.entrySet = Collections.unmodifiableSet(this.delegate.entrySet())) : es;
/*     */     }
/*     */ 
/*     */     public Iterator<E> iterator()
/*     */     {
/* 102 */       return Iterators.unmodifiableIterator(this.delegate.iterator());
/*     */     }
/*     */ 
/*     */     public boolean add(E element) {
/* 106 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int add(E element, int occurences) {
/* 110 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection<? extends E> elementsToAdd) {
/* 114 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object element) {
/* 118 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int remove(Object element, int occurrences) {
/* 122 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> elementsToRemove) {
/* 126 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> elementsToRetain) {
/* 130 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 134 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int setCount(E element, int count) {
/* 138 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean setCount(E element, int oldCount, int newCount) {
/* 142 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Multisets
 * JD-Core Version:    0.6.0
 */