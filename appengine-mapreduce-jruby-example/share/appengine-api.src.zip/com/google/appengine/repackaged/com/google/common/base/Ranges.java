/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public final class Ranges
/*     */ {
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <V extends Comparable<? super V>> Range<V> newRange(V min, V max)
/*     */   {
/*  36 */     if (max.compareTo(min) > -1) {
/*  37 */       return new RangeClosed(min, max);
/*     */     }
/*  39 */     return emptyRange();
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <V extends Comparable<? super V>> Range<V> emptyRange()
/*     */   {
/*  55 */     return EmptyRange.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <V extends Comparable<? super V>> Range<V> intersect(Range<V> aRange, Range<V>[] moreRanges)
/*     */   {
/*  66 */     Range result = aRange;
/*  67 */     for (Range range : moreRanges) {
/*  68 */       result = result.intersection(range);
/*     */     }
/*  70 */     return result;
/*     */   }
/*     */ 
/*     */   public static <V extends Comparable<? super V>> Range<V> enclose(Range<V> aRange, Range<V>[] moreRanges)
/*     */   {
/*  81 */     Range result = aRange;
/*  82 */     for (Range range : moreRanges) {
/*  83 */       result = result.enclosure(range);
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <V extends Comparable<? super V>> Range<V> rangeOf(V[] values)
/*     */   {
/*  96 */     Comparable min = null;
/*  97 */     Comparable max = null;
/*  98 */     boolean isEmpty = true;
/*  99 */     for (Comparable value : values) {
/* 100 */       if (value != null) {
/* 101 */         if (isEmpty) {
/* 102 */           isEmpty = false;
/* 103 */           min = value;
/* 104 */           max = value;
/*     */         } else {
/* 106 */           if (value.compareTo(min) < 0) {
/* 107 */             min = value;
/*     */           }
/* 109 */           if (value.compareTo(max) > 0) {
/* 110 */             max = value;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 115 */     return isEmpty ? emptyRange() : newRange(min, max);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static Range<Integer> encloseInts(int[] values)
/*     */   {
/* 123 */     if (values.length == 0) {
/* 124 */       return emptyRange();
/*     */     }
/* 126 */     int min = values[0];
/* 127 */     int max = values[0];
/* 128 */     for (int value : values) {
/* 129 */       if (min > value) {
/* 130 */         min = value;
/*     */       }
/* 132 */       if (max < value) {
/* 133 */         max = value;
/*     */       }
/*     */     }
/* 136 */     return newRange(Integer.valueOf(min), Integer.valueOf(max));
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static Range<Long> encloseLongs(long[] values)
/*     */   {
/* 144 */     if (values.length == 0) {
/* 145 */       return emptyRange();
/*     */     }
/* 147 */     long min = values[0];
/* 148 */     long max = values[0];
/* 149 */     for (long value : values) {
/* 150 */       if (min > value) {
/* 151 */         min = value;
/*     */       }
/* 153 */       if (max < value) {
/* 154 */         max = value;
/*     */       }
/*     */     }
/* 157 */     return newRange(Long.valueOf(min), Long.valueOf(max));
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static Range<Double> encloseDoubles(double[] values)
/*     */   {
/* 165 */     if (values.length == 0) {
/* 166 */       return emptyRange();
/*     */     }
/* 168 */     double min = values[0];
/* 169 */     double max = values[0];
/* 170 */     for (double value : values) {
/* 171 */       if (min > value) {
/* 172 */         min = value;
/*     */       }
/* 174 */       if (max < value) {
/* 175 */         max = value;
/*     */       }
/*     */     }
/* 178 */     return newRange(Double.valueOf(min), Double.valueOf(max));
/*     */   }
/*     */ 
/*     */   static class EmptyRange<V extends Comparable<? super V>> implements Range<V>, Serializable
/*     */   {
/* 186 */     private static final EmptyRange<Comparable<Object>> INSTANCE = new EmptyRange();
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     public boolean contains(V value)
/*     */     {
/* 192 */       return false;
/*     */     }
/*     */ 
/*     */     public Range<V> enclose(V value) {
/* 196 */       return Ranges.newRange(value, value);
/*     */     }
/*     */ 
/*     */     public Range<V> enclosure(Range<V> range) {
/* 200 */       return range;
/*     */     }
/*     */ 
/*     */     public V max() {
/* 204 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/* 208 */       return ((o instanceof Range)) && (((Range)o).isEmpty());
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 212 */       return 0;
/*     */     }
/*     */ 
/*     */     public Range<V> intersection(Range<V> range) {
/* 216 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean intersects(Range<V> range) {
/* 220 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 224 */       return true;
/*     */     }
/*     */ 
/*     */     public V min() {
/* 228 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 232 */       return "[Empty Range]";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Ranges
 * JD-Core Version:    0.6.0
 */