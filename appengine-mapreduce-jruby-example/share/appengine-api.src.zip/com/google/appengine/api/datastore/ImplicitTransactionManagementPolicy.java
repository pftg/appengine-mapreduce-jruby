/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public enum ImplicitTransactionManagementPolicy
/*    */ {
/* 30 */   NONE, 
/*    */ 
/* 43 */   AUTO;
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.ImplicitTransactionManagementPolicy
 * JD-Core Version:    0.6.0
 */