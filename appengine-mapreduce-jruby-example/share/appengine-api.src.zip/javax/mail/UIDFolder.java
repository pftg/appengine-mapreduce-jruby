/*     */ package javax.mail;
/*     */ 
/*     */ public abstract interface UIDFolder
/*     */ {
/*     */   public static final long LASTUID = -1L;
/*     */ 
/*     */   public abstract long getUIDValidity()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Message getMessageByUID(long paramLong)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Message[] getMessagesByUID(long paramLong1, long paramLong2)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Message[] getMessagesByUID(long[] paramArrayOfLong)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract long getUID(Message paramMessage)
/*     */     throws MessagingException;
/*     */ 
/*     */   public static class FetchProfileItem extends FetchProfile.Item
/*     */   {
/* 103 */     public static final FetchProfileItem UID = new FetchProfileItem("UID");
/*     */ 
/*     */     protected FetchProfileItem(String name) {
/* 106 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.UIDFolder
 * JD-Core Version:    0.6.0
 */