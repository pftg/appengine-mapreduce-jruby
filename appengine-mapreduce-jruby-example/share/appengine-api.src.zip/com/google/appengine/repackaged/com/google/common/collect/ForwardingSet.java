/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Set;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingSet<E> extends ForwardingCollection<E>
/*    */   implements Set<E>
/*    */ {
/*    */   protected abstract Set<E> delegate();
/*    */ 
/*    */   public boolean equals(@Nullable Object object)
/*    */   {
/* 44 */     return (object == this) || (delegate().equals(object));
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 48 */     return delegate().hashCode();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingSet
 * JD-Core Version:    0.6.0
 */