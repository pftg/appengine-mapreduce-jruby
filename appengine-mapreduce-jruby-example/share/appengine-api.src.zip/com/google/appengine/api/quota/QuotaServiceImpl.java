/*    */ package com.google.appengine.api.quota;
/*    */ 
/*    */ import com.google.apphosting.api.ApiProxy;
/*    */ import com.google.apphosting.api.ApiProxy.Environment;
/*    */ import com.google.apphosting.api.ApiStats;
/*    */ 
/*    */ class QuotaServiceImpl
/*    */   implements QuotaService
/*    */ {
/*    */   private static final double MCYCLES_PER_SECOND = 1200.0D;
/*    */ 
/*    */   private static ApiStats getStats()
/*    */   {
/* 23 */     ApiProxy.Environment env = ApiProxy.getCurrentEnvironment();
/* 24 */     if (env == null) {
/* 25 */       return null;
/*    */     }
/* 27 */     return ApiStats.get(env);
/*    */   }
/*    */ 
/*    */   public boolean supports(QuotaService.DataType type)
/*    */   {
/* 35 */     return getStats() != null;
/*    */   }
/*    */ 
/*    */   public long getApiTimeInMegaCycles() {
/* 39 */     ApiStats stats = getStats();
/* 40 */     return stats == null ? 0L : stats.getApiTimeInMegaCycles();
/*    */   }
/*    */ 
/*    */   public long getCpuTimeInMegaCycles() {
/* 44 */     ApiStats stats = getStats();
/* 45 */     return stats == null ? 0L : stats.getCpuTimeInMegaCycles();
/*    */   }
/*    */ 
/*    */   public long convertCpuSecondsToMegacycles(double cpuSeconds)
/*    */   {
/* 50 */     return ()(cpuSeconds * 1200.0D);
/*    */   }
/*    */ 
/*    */   public double convertMegacyclesToCpuSeconds(long megaCycles)
/*    */   {
/* 55 */     return megaCycles / 1200.0D;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.quota.QuotaServiceImpl
 * JD-Core Version:    0.6.0
 */