/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class Composite
/*    */ {
/*    */   abstract void apply(ImagesServicePb.ImagesCompositeRequest paramImagesCompositeRequest, Map<Image, Integer> paramMap);
/*    */ 
/*    */   public static enum Anchor
/*    */   {
/* 19 */     TOP_LEFT, TOP_CENTER, TOP_RIGHT, CENTER_LEFT, 
/* 20 */     CENTER_CENTER, CENTER_RIGHT, BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.Composite
 * JD-Core Version:    0.6.0
 */