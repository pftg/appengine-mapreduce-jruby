package com.google.appengine.repackaged.com.google.common.base;

import com.google.common.annotations.GoogleInternal;
import com.google.common.annotations.GwtCompatible;
import javax.annotation.Nullable;

@GoogleInternal
@GwtCompatible
public abstract interface BinaryPredicate<X, Y>
{
  public abstract boolean apply(@Nullable X paramX, @Nullable Y paramY);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.BinaryPredicate
 * JD-Core Version:    0.6.0
 */