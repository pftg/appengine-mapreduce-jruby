/*      */ package com.google.appengine.api.xmpp;
/*      */ 
/*      */ import B;
/*      */ import com.google.appengine.api.channel.ChannelServicePb.CreateChannelRequest;
/*      */ import com.google.appengine.api.channel.ChannelServicePb.CreateChannelResponse;
/*      */ import com.google.appengine.api.channel.ChannelServicePb.SendMessageRequest;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import com.google.apphosting.api.ApiBasePb.VoidProto;
/*      */ import com.google.net.rpc.DefaultStubCreationFilter;
/*      */ import com.google.net.rpc.RPC;
/*      */ import com.google.net.rpc.RpcCallback;
/*      */ import com.google.net.rpc.RpcCancelCallback;
/*      */ import com.google.net.rpc.RpcException;
/*      */ import com.google.net.rpc.RpcInterface;
/*      */ import com.google.net.rpc.RpcServerParameters;
/*      */ import com.google.net.rpc.RpcService;
/*      */ import com.google.net.rpc.RpcStub;
/*      */ import com.google.net.rpc.RpcStubFactory;
/*      */ import com.google.net.rpc.RpcStubParameters;
/*      */ import com.google.net.rpc.StubCreationFilter;
/*      */ import com.google.net.rpc.impl.ApplicationHandler;
/*      */ import com.google.net.rpc.impl.BlockingApplicationHandler;
/*      */ import com.google.net.rpc.impl.RpcHandlerRegistry;
/*      */ import com.google.net.rpc.impl.RpcServerConfig;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1CompatibilityStub;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1HandlerRegistry;
/*      */ import com.google.net.rpc3.server.RpcServer.Builder;
/*      */ import com.google.net.ssl.SslSecurityLevel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ public class XMPPServicePb
/*      */ {
/*      */   public static final class XmppService
/*      */   {
/* 3410 */     private static volatile StubCreationFilter stubCreationFilter_ = new DefaultStubCreationFilter();
/*      */ 
/* 3416 */     private static final RpcStubFactory stubFactory_ = new RpcStubFactory() {
/*      */       public RpcStub newRpcStub(RpcStubParameters params) {
/* 3418 */         return new XMPPServicePb.XmppService.SimpleStub(XMPPServicePb.XmppService.stubCreationFilter_.filterStubParameters("XmppService", params));
/*      */       }
/* 3416 */     };
/*      */ 
/*      */     public static void setStubCreationFilter(StubCreationFilter filter)
/*      */     {
/* 3413 */       stubCreationFilter_ = filter == null ? new DefaultStubCreationFilter() : filter;
/*      */     }
/*      */ 
/*      */     public static RpcStubFactory stubFactory()
/*      */     {
/* 3422 */       return stubFactory_;
/*      */     }
/*      */ 
/*      */     public static BlockingStub newBlockingStub(RpcStubParameters params)
/*      */     {
/* 3505 */       return new BlockingStub(stubCreationFilter_.filterStubParameters("XmppService", params));
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcStubParameters params)
/*      */     {
/* 3548 */       return new Stub(stubCreationFilter_.filterStubParameters("XmppService", params));
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcHandlerRegistry registry)
/*      */     {
/* 3653 */       ServerConfig config = new ServerConfig();
/* 3654 */       exportServiceUsingConfig(service, registry, config);
/* 3655 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 3661 */       registry.registerHandler(config.serviceName(), "GetPresence", new XMPPServicePb.PresenceRequest(), new XMPPServicePb.PresenceResponse(), null, config.GetPresence_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 3665 */           this.val$service.getPresence(rpc, (XMPPServicePb.PresenceRequest)rpc.internalRequest(), (XMPPServicePb.PresenceResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 3669 */       registry.registerHandler(config.serviceName(), "SendMessage", new XMPPServicePb.XmppMessageRequest(), new XMPPServicePb.XmppMessageResponse(), null, config.SendMessage_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 3673 */           this.val$service.sendMessage(rpc, (XMPPServicePb.XmppMessageRequest)rpc.internalRequest(), (XMPPServicePb.XmppMessageResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 3677 */       registry.registerHandler(config.serviceName(), "SendInvite", new XMPPServicePb.XmppInviteRequest(), new XMPPServicePb.XmppInviteResponse(), null, config.SendInvite_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 3681 */           this.val$service.sendInvite(rpc, (XMPPServicePb.XmppInviteRequest)rpc.internalRequest(), (XMPPServicePb.XmppInviteResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 3685 */       registry.registerHandler(config.serviceName(), "SendPresence", new XMPPServicePb.XmppSendPresenceRequest(), new XMPPServicePb.XmppSendPresenceResponse(), null, config.SendPresence_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 3689 */           this.val$service.sendPresence(rpc, (XMPPServicePb.XmppSendPresenceRequest)rpc.internalRequest(), (XMPPServicePb.XmppSendPresenceResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 3693 */       registry.registerHandler(config.serviceName(), "CreateChannel", new ChannelServicePb.CreateChannelRequest(), new ChannelServicePb.CreateChannelResponse(), null, config.CreateChannel_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 3697 */           this.val$service.createChannel(rpc, (ChannelServicePb.CreateChannelRequest)rpc.internalRequest(), (ChannelServicePb.CreateChannelResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 3701 */       registry.registerHandler(config.serviceName(), "SendChannelMessage", new ChannelServicePb.SendMessageRequest(), new ApiBasePb.VoidProto(), null, config.SendChannelMessage_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 3705 */           this.val$service.sendChannelMessage(rpc, (ChannelServicePb.SendMessageRequest)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     public static RpcService newService(Interface impl) {
/* 3712 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 3714 */           return XMPPServicePb.XmppService.exportService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcServer.Builder builder) {
/* 3721 */       ServerConfig config = new ServerConfig();
/* 3722 */       exportServiceUsingConfig(service, builder, config);
/* 3723 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 3729 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 3730 */       exportServiceUsingConfig(service, registry, config);
/* 3731 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcHandlerRegistry registry)
/*      */     {
/* 3736 */       ServerConfig config = new ServerConfig();
/* 3737 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 3738 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 3744 */       registry.registerHandler(config.serviceName(), "GetPresence", new XMPPServicePb.PresenceRequest(), new XMPPServicePb.PresenceResponse(), null, config.GetPresence_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public XMPPServicePb.PresenceResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 3748 */           return this.val$service.getPresence(rpc, (XMPPServicePb.PresenceRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 3751 */       registry.registerHandler(config.serviceName(), "SendMessage", new XMPPServicePb.XmppMessageRequest(), new XMPPServicePb.XmppMessageResponse(), null, config.SendMessage_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public XMPPServicePb.XmppMessageResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 3755 */           return this.val$service.sendMessage(rpc, (XMPPServicePb.XmppMessageRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 3758 */       registry.registerHandler(config.serviceName(), "SendInvite", new XMPPServicePb.XmppInviteRequest(), new XMPPServicePb.XmppInviteResponse(), null, config.SendInvite_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public XMPPServicePb.XmppInviteResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 3762 */           return this.val$service.sendInvite(rpc, (XMPPServicePb.XmppInviteRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 3765 */       registry.registerHandler(config.serviceName(), "SendPresence", new XMPPServicePb.XmppSendPresenceRequest(), new XMPPServicePb.XmppSendPresenceResponse(), null, config.SendPresence_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public XMPPServicePb.XmppSendPresenceResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 3769 */           return this.val$service.sendPresence(rpc, (XMPPServicePb.XmppSendPresenceRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 3772 */       registry.registerHandler(config.serviceName(), "CreateChannel", new ChannelServicePb.CreateChannelRequest(), new ChannelServicePb.CreateChannelResponse(), null, config.CreateChannel_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ChannelServicePb.CreateChannelResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 3776 */           return this.val$service.createChannel(rpc, (ChannelServicePb.CreateChannelRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 3779 */       registry.registerHandler(config.serviceName(), "SendChannelMessage", new ChannelServicePb.SendMessageRequest(), new ApiBasePb.VoidProto(), null, config.SendChannelMessage_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 3783 */           return this.val$service.sendChannelMessage(rpc, (ChannelServicePb.SendMessageRequest)rpc.internalRequest());
/*      */         } } );
/*      */     }
/*      */ 
/*      */     public static RpcService newBlockingService(BlockingInterface impl) {
/* 3789 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 3791 */           return XMPPServicePb.XmppService.exportBlockingService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcServer.Builder builder) {
/* 3798 */       ServerConfig config = new ServerConfig();
/* 3799 */       exportBlockingServiceUsingConfig(service, builder, config);
/* 3800 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 3806 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 3807 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 3808 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static void unexport(RpcHandlerRegistry registry) {
/* 3812 */       registry.unregisterService("XmppService");
/*      */     }
/*      */ 
/*      */     public static class ServerConfig extends RpcServerConfig
/*      */     {
/* 3552 */       final RpcServerParameters GetPresence_parameters_ = new RpcServerParameters();
/* 3553 */       final RpcServerParameters SendMessage_parameters_ = new RpcServerParameters();
/* 3554 */       final RpcServerParameters SendInvite_parameters_ = new RpcServerParameters();
/* 3555 */       final RpcServerParameters SendPresence_parameters_ = new RpcServerParameters();
/* 3556 */       final RpcServerParameters CreateChannel_parameters_ = new RpcServerParameters();
/* 3557 */       final RpcServerParameters SendChannelMessage_parameters_ = new RpcServerParameters();
/*      */ 
/*      */       public ServerConfig() {
/* 3560 */         this("XmppService");
/*      */       }
/*      */       public ServerConfig(String serviceName) {
/* 3563 */         super();
/*      */       }
/*      */       public void setRpcRunner(Executor t) {
/* 3566 */         setRpcRunner_GetPresence(t);
/* 3567 */         setRpcRunner_SendMessage(t);
/* 3568 */         setRpcRunner_SendInvite(t);
/* 3569 */         setRpcRunner_SendPresence(t);
/* 3570 */         setRpcRunner_CreateChannel(t);
/* 3571 */         setRpcRunner_SendChannelMessage(t);
/*      */       }
/*      */ 
/*      */       public void setRpcRunner_GetPresence(Executor t) {
/* 3575 */         this.GetPresence_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_SendMessage(Executor t) {
/* 3578 */         this.SendMessage_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_SendInvite(Executor t) {
/* 3581 */         this.SendInvite_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_SendPresence(Executor t) {
/* 3584 */         this.SendPresence_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_CreateChannel(Executor t) {
/* 3587 */         this.CreateChannel_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_SendChannelMessage(Executor t) {
/* 3590 */         this.SendChannelMessage_parameters_.setRpcRunner(t);
/*      */       }
/*      */ 
/*      */       public void setServerLogging_GetPresence(int t) {
/* 3594 */         this.GetPresence_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_SendMessage(int t) {
/* 3597 */         this.SendMessage_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_SendInvite(int t) {
/* 3600 */         this.SendInvite_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_SendPresence(int t) {
/* 3603 */         this.SendPresence_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_CreateChannel(int t) {
/* 3606 */         this.CreateChannel_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_SendChannelMessage(int t) {
/* 3609 */         this.SendChannelMessage_parameters_.setServerLogging(t);
/*      */       }
/*      */ 
/*      */       public void setSecurityLevel_GetPresence(SslSecurityLevel t) {
/* 3613 */         this.GetPresence_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_SendMessage(SslSecurityLevel t) {
/* 3616 */         this.SendMessage_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_SendInvite(SslSecurityLevel t) {
/* 3619 */         this.SendInvite_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_SendPresence(SslSecurityLevel t) {
/* 3622 */         this.SendPresence_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_CreateChannel(SslSecurityLevel t) {
/* 3625 */         this.CreateChannel_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_SendChannelMessage(SslSecurityLevel t) {
/* 3628 */         this.SendChannelMessage_parameters_.setSecurityLevel(t);
/*      */       }
/*      */ 
/*      */       public void setRpcCancelCallback_GetPresence(RpcCancelCallback t) {
/* 3632 */         this.GetPresence_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_SendMessage(RpcCancelCallback t) {
/* 3635 */         this.SendMessage_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_SendInvite(RpcCancelCallback t) {
/* 3638 */         this.SendInvite_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_SendPresence(RpcCancelCallback t) {
/* 3641 */         this.SendPresence_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_CreateChannel(RpcCancelCallback t) {
/* 3644 */         this.CreateChannel_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_SendChannelMessage(RpcCancelCallback t) {
/* 3647 */         this.SendChannelMessage_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class Stub extends XMPPServicePb.XmppService.BlockingStub
/*      */       implements XMPPServicePb.XmppService.Interface
/*      */     {
/*      */       Stub(RpcStubParameters params)
/*      */       {
/* 3519 */         super();
/*      */       }
/*      */       public void getPresence(RPC rpc, XMPPServicePb.PresenceRequest req, XMPPServicePb.PresenceResponse reply, RpcCallback cb) {
/* 3522 */         startNonBlockingRpc(rpc, this.GetPresence_method_, "GetPresence", req, reply, cb, this.GetPresence_parameters_);
/*      */       }
/*      */ 
/*      */       public void sendMessage(RPC rpc, XMPPServicePb.XmppMessageRequest req, XMPPServicePb.XmppMessageResponse reply, RpcCallback cb) {
/* 3526 */         startNonBlockingRpc(rpc, this.SendMessage_method_, "SendMessage", req, reply, cb, this.SendMessage_parameters_);
/*      */       }
/*      */ 
/*      */       public void sendInvite(RPC rpc, XMPPServicePb.XmppInviteRequest req, XMPPServicePb.XmppInviteResponse reply, RpcCallback cb) {
/* 3530 */         startNonBlockingRpc(rpc, this.SendInvite_method_, "SendInvite", req, reply, cb, this.SendInvite_parameters_);
/*      */       }
/*      */ 
/*      */       public void sendPresence(RPC rpc, XMPPServicePb.XmppSendPresenceRequest req, XMPPServicePb.XmppSendPresenceResponse reply, RpcCallback cb) {
/* 3534 */         startNonBlockingRpc(rpc, this.SendPresence_method_, "SendPresence", req, reply, cb, this.SendPresence_parameters_);
/*      */       }
/*      */ 
/*      */       public void createChannel(RPC rpc, ChannelServicePb.CreateChannelRequest req, ChannelServicePb.CreateChannelResponse reply, RpcCallback cb) {
/* 3538 */         startNonBlockingRpc(rpc, this.CreateChannel_method_, "CreateChannel", req, reply, cb, this.CreateChannel_parameters_);
/*      */       }
/*      */ 
/*      */       public void sendChannelMessage(RPC rpc, ChannelServicePb.SendMessageRequest req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 3542 */         startNonBlockingRpc(rpc, this.SendChannelMessage_method_, "SendChannelMessage", req, reply, cb, this.SendChannelMessage_parameters_);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface extends RpcInterface
/*      */     {
/*      */       public abstract void getPresence(RPC paramRPC, XMPPServicePb.PresenceRequest paramPresenceRequest, XMPPServicePb.PresenceResponse paramPresenceResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void sendMessage(RPC paramRPC, XMPPServicePb.XmppMessageRequest paramXmppMessageRequest, XMPPServicePb.XmppMessageResponse paramXmppMessageResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void sendInvite(RPC paramRPC, XMPPServicePb.XmppInviteRequest paramXmppInviteRequest, XMPPServicePb.XmppInviteResponse paramXmppInviteResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void sendPresence(RPC paramRPC, XMPPServicePb.XmppSendPresenceRequest paramXmppSendPresenceRequest, XMPPServicePb.XmppSendPresenceResponse paramXmppSendPresenceResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void createChannel(RPC paramRPC, ChannelServicePb.CreateChannelRequest paramCreateChannelRequest, ChannelServicePb.CreateChannelResponse paramCreateChannelResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void sendChannelMessage(RPC paramRPC, ChannelServicePb.SendMessageRequest paramSendMessageRequest, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*      */     }
/*      */ 
/*      */     public static class BlockingStub extends XMPPServicePb.XmppService.BaseStub
/*      */       implements XMPPServicePb.XmppService.BlockingInterface
/*      */     {
/*      */       BlockingStub(RpcStubParameters params)
/*      */       {
/* 3464 */         super();
/*      */       }
/*      */       public XMPPServicePb.PresenceResponse getPresence(RPC rpc, XMPPServicePb.PresenceRequest req) throws RpcException {
/* 3467 */         XMPPServicePb.PresenceResponse reply = new XMPPServicePb.PresenceResponse();
/* 3468 */         startBlockingRpc(rpc, this.GetPresence_method_, "GetPresence", req, reply, this.GetPresence_parameters_);
/*      */ 
/* 3470 */         return reply;
/*      */       }
/*      */       public XMPPServicePb.XmppMessageResponse sendMessage(RPC rpc, XMPPServicePb.XmppMessageRequest req) throws RpcException {
/* 3473 */         XMPPServicePb.XmppMessageResponse reply = new XMPPServicePb.XmppMessageResponse();
/* 3474 */         startBlockingRpc(rpc, this.SendMessage_method_, "SendMessage", req, reply, this.SendMessage_parameters_);
/*      */ 
/* 3476 */         return reply;
/*      */       }
/*      */       public XMPPServicePb.XmppInviteResponse sendInvite(RPC rpc, XMPPServicePb.XmppInviteRequest req) throws RpcException {
/* 3479 */         XMPPServicePb.XmppInviteResponse reply = new XMPPServicePb.XmppInviteResponse();
/* 3480 */         startBlockingRpc(rpc, this.SendInvite_method_, "SendInvite", req, reply, this.SendInvite_parameters_);
/*      */ 
/* 3482 */         return reply;
/*      */       }
/*      */       public XMPPServicePb.XmppSendPresenceResponse sendPresence(RPC rpc, XMPPServicePb.XmppSendPresenceRequest req) throws RpcException {
/* 3485 */         XMPPServicePb.XmppSendPresenceResponse reply = new XMPPServicePb.XmppSendPresenceResponse();
/* 3486 */         startBlockingRpc(rpc, this.SendPresence_method_, "SendPresence", req, reply, this.SendPresence_parameters_);
/*      */ 
/* 3488 */         return reply;
/*      */       }
/*      */       public ChannelServicePb.CreateChannelResponse createChannel(RPC rpc, ChannelServicePb.CreateChannelRequest req) throws RpcException {
/* 3491 */         ChannelServicePb.CreateChannelResponse reply = new ChannelServicePb.CreateChannelResponse();
/* 3492 */         startBlockingRpc(rpc, this.CreateChannel_method_, "CreateChannel", req, reply, this.CreateChannel_parameters_);
/*      */ 
/* 3494 */         return reply;
/*      */       }
/*      */       public ApiBasePb.VoidProto sendChannelMessage(RPC rpc, ChannelServicePb.SendMessageRequest req) throws RpcException {
/* 3497 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 3498 */         startBlockingRpc(rpc, this.SendChannelMessage_method_, "SendChannelMessage", req, reply, this.SendChannelMessage_parameters_);
/*      */ 
/* 3500 */         return reply;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface extends RpcInterface
/*      */     {
/*      */       public abstract XMPPServicePb.PresenceResponse getPresence(RPC paramRPC, XMPPServicePb.PresenceRequest paramPresenceRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract XMPPServicePb.XmppMessageResponse sendMessage(RPC paramRPC, XMPPServicePb.XmppMessageRequest paramXmppMessageRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract XMPPServicePb.XmppInviteResponse sendInvite(RPC paramRPC, XMPPServicePb.XmppInviteRequest paramXmppInviteRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract XMPPServicePb.XmppSendPresenceResponse sendPresence(RPC paramRPC, XMPPServicePb.XmppSendPresenceRequest paramXmppSendPresenceRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ChannelServicePb.CreateChannelResponse createChannel(RPC paramRPC, ChannelServicePb.CreateChannelRequest paramCreateChannelRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ApiBasePb.VoidProto sendChannelMessage(RPC paramRPC, ChannelServicePb.SendMessageRequest paramSendMessageRequest)
/*      */         throws RpcException;
/*      */     }
/*      */ 
/*      */     private static class BaseStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       protected final String GetPresence_method_;
/* 3440 */       protected final RPC GetPresence_parameters_ = newRpcPrototype(XMPPServicePb.XmppService.Method.GetPresence);
/*      */       protected final String SendMessage_method_;
/* 3442 */       protected final RPC SendMessage_parameters_ = newRpcPrototype(XMPPServicePb.XmppService.Method.SendMessage);
/*      */       protected final String SendInvite_method_;
/* 3444 */       protected final RPC SendInvite_parameters_ = newRpcPrototype(XMPPServicePb.XmppService.Method.SendInvite);
/*      */       protected final String SendPresence_method_;
/* 3446 */       protected final RPC SendPresence_parameters_ = newRpcPrototype(XMPPServicePb.XmppService.Method.SendPresence);
/*      */       protected final String CreateChannel_method_;
/* 3448 */       protected final RPC CreateChannel_parameters_ = newRpcPrototype(XMPPServicePb.XmppService.Method.CreateChannel);
/*      */       protected final String SendChannelMessage_method_;
/* 3450 */       protected final RPC SendChannelMessage_parameters_ = newRpcPrototype(XMPPServicePb.XmppService.Method.SendChannelMessage);
/*      */ 
/*      */       protected BaseStub(RpcStubParameters params)
/*      */       {
/* 3430 */         super(params, XMPPServicePb.XmppService.Method.class);
/* 3431 */         this.GetPresence_method_ = makeFullMethodName("GetPresence");
/* 3432 */         this.SendMessage_method_ = makeFullMethodName("SendMessage");
/* 3433 */         this.SendInvite_method_ = makeFullMethodName("SendInvite");
/* 3434 */         this.SendPresence_method_ = makeFullMethodName("SendPresence");
/* 3435 */         this.CreateChannel_method_ = makeFullMethodName("CreateChannel");
/* 3436 */         this.SendChannelMessage_method_ = makeFullMethodName("SendChannelMessage");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class SimpleStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       public SimpleStub(RpcStubParameters params)
/*      */       {
/* 3425 */         super(params, XMPPServicePb.XmppService.Method.class);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Method
/*      */     {
/* 3402 */       GetPresence, 
/* 3403 */       SendMessage, 
/* 3404 */       SendInvite, 
/* 3405 */       SendPresence, 
/* 3406 */       CreateChannel, 
/* 3407 */       SendChannelMessage;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppInviteResponse extends ProtocolMessage<XmppInviteResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final XmppInviteResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public XmppInviteResponse mergeFrom(XmppInviteResponse that)
/*      */     {
/* 3232 */       assert (that != this);
/*      */ 
/* 3234 */       if (that.uninterpreted != null) {
/* 3235 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3237 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppInviteResponse that) {
/* 3241 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppInviteResponse that) {
/* 3245 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppInviteResponse that, boolean ignoreUninterpreted) {
/* 3249 */       if (that == null) return false;
/* 3250 */       if (that == this) return true;
/*      */ 
/* 3252 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3257 */       return ((that instanceof XmppInviteResponse)) && (equals((XmppInviteResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3261 */       int hash = 777877264;
/* 3262 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3263 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3265 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3269 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 3273 */       int n = 0;
/*      */ 
/* 3275 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3280 */       int n = 0;
/*      */ 
/* 3282 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3287 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3291 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppInviteResponse newInstance() {
/* 3295 */       return new XmppInviteResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3299 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3314 */       if (this.uninterpreted != null)
/* 3315 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3320 */       boolean result = true;
/*      */ 
/* 3322 */       while (source.hasRemaining()) {
/* 3323 */         int tt = source.getVarInt();
/* 3324 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3328 */           result = false;
/* 3329 */           break;
/*      */         default:
/* 3331 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3336 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppInviteResponse getDefaultInstanceForType()
/*      */     {
/* 3341 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppInviteResponse getDefaultInstance() {
/* 3345 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 3375 */       if (this.uninterpreted == null) {
/* 3376 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3378 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3349 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppInviteResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppInviteResponse mergeFrom(XMPPServicePb.XmppInviteResponse that)
/*      */         {
/* 3356 */           ProtocolSupport.unsupportedOperation();
/* 3357 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3360 */           ProtocolSupport.unsupportedOperation();
/* 3361 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteResponse freeze() {
/* 3364 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteResponse unfreeze() {
/* 3367 */           ProtocolSupport.unsupportedOperation();
/* 3368 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3371 */           return true;
/*      */         }
/*      */       };
/* 3382 */       text = new String[1];
/*      */ 
/* 3384 */       text[0] = "ErrorCode";
/*      */ 
/* 3387 */       types = new int[1];
/*      */ 
/* 3389 */       Arrays.fill(types, 6);
/* 3390 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3303 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppInviteResponse.class, "Z&apphosting/api/xmpp/xmpp_service.proto\n\035apphosting.XmppInviteResponse", new ProtocolType.FieldType[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppInviteRequest extends ProtocolMessage<XmppInviteRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2855 */     private byte[] jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2856 */     private byte[] from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final XmppInviteRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kjid = 1;
/*      */     public static final int kfrom_jid = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getJidAsBytes()
/*      */     {
/* 2862 */       return this.jid_;
/*      */     }
/*      */     public final boolean hasJid() {
/* 2865 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public XmppInviteRequest clearJid() {
/* 2868 */       this.optional_0_ &= -2;
/* 2869 */       this.jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2870 */       return this;
/*      */     }
/*      */     public XmppInviteRequest setJidAsBytes(byte[] x) {
/* 2873 */       this.optional_0_ |= 1;
/* 2874 */       this.jid_ = x;
/* 2875 */       return this;
/*      */     }
/*      */     public final String getJid() {
/* 2878 */       return ProtocolSupport.toStringUtf8(this.jid_);
/*      */     }
/*      */     public XmppInviteRequest setJid(String v) {
/* 2881 */       if (v == null) throw new NullPointerException();
/* 2882 */       this.optional_0_ |= 1;
/* 2883 */       this.jid_ = ProtocolSupport.toBytesUtf8(v);
/* 2884 */       return this;
/*      */     }
/*      */     public final String getJid(Charset cs) {
/* 2887 */       return ProtocolSupport.toString(this.jid_, cs);
/*      */     }
/*      */     public XmppInviteRequest setJid(String v, Charset cs) {
/* 2890 */       if (v == null) throw new NullPointerException();
/* 2891 */       this.optional_0_ |= 1;
/* 2892 */       this.jid_ = ProtocolSupport.toBytes(v, cs);
/* 2893 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFromJidAsBytes()
/*      */     {
/* 2898 */       return this.from_jid_;
/*      */     }
/*      */     public final boolean hasFromJid() {
/* 2901 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public XmppInviteRequest clearFromJid() {
/* 2904 */       this.optional_0_ &= -3;
/* 2905 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2906 */       return this;
/*      */     }
/*      */     public XmppInviteRequest setFromJidAsBytes(byte[] x) {
/* 2909 */       this.optional_0_ |= 2;
/* 2910 */       this.from_jid_ = x;
/* 2911 */       return this;
/*      */     }
/*      */     public final String getFromJid() {
/* 2914 */       return ProtocolSupport.toStringUtf8(this.from_jid_);
/*      */     }
/*      */     public XmppInviteRequest setFromJid(String v) {
/* 2917 */       if (v == null) throw new NullPointerException();
/* 2918 */       this.optional_0_ |= 2;
/* 2919 */       this.from_jid_ = ProtocolSupport.toBytesUtf8(v);
/* 2920 */       return this;
/*      */     }
/*      */     public final String getFromJid(Charset cs) {
/* 2923 */       return ProtocolSupport.toString(this.from_jid_, cs);
/*      */     }
/*      */     public XmppInviteRequest setFromJid(String v, Charset cs) {
/* 2926 */       if (v == null) throw new NullPointerException();
/* 2927 */       this.optional_0_ |= 2;
/* 2928 */       this.from_jid_ = ProtocolSupport.toBytes(v, cs);
/* 2929 */       return this;
/*      */     }
/*      */ 
/*      */     public XmppInviteRequest mergeFrom(XmppInviteRequest that)
/*      */     {
/* 2936 */       assert (that != this);
/* 2937 */       int this_t0 = this.optional_0_;
/* 2938 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2940 */       if ((that_t0 & 0x1) != 0) {
/* 2941 */         this_t0 |= 1;
/* 2942 */         this.jid_ = that.jid_;
/*      */       }
/*      */ 
/* 2945 */       if ((that_t0 & 0x2) != 0) {
/* 2946 */         this_t0 |= 2;
/* 2947 */         this.from_jid_ = that.from_jid_;
/*      */       }
/*      */ 
/* 2950 */       if (that.uninterpreted != null) {
/* 2951 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2953 */       this.optional_0_ = this_t0;
/* 2954 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppInviteRequest that) {
/* 2958 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppInviteRequest that) {
/* 2962 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppInviteRequest that, boolean ignoreUninterpreted) {
/* 2966 */       if (that == null) return false;
/* 2967 */       if (that == this) return true;
/* 2968 */       int this_t0 = this.optional_0_;
/* 2969 */       int that_t0 = that.optional_0_;
/* 2970 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2972 */       if (((this_t0 & 0x1) != 0) && 
/* 2973 */         (!Arrays.equals(this.jid_, that.jid_))) return false;
/*      */ 
/* 2976 */       if (((this_t0 & 0x2) != 0) && 
/* 2977 */         (!Arrays.equals(this.from_jid_, that.from_jid_))) return false;
/*      */ 
/* 2980 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2985 */       return ((that instanceof XmppInviteRequest)) && (equals((XmppInviteRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2989 */       int hash = 1179139582;
/*      */ 
/* 2991 */       int this_t0 = this.optional_0_;
/* 2992 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.jid_) : -113);
/*      */ 
/* 2994 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.from_jid_) : -113);
/* 2995 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2996 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2998 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3002 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3004 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3011 */       int n = 1 + Protocol.stringSize(this.jid_.length);
/* 3012 */       int this_t0 = this.optional_0_;
/* 3013 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 3015 */         n += 1 + Protocol.stringSize(this.from_jid_.length);
/*      */       }
/*      */ 
/* 3018 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3024 */       int n = 6 + this.jid_.length;
/* 3025 */       int this_t0 = this.optional_0_;
/* 3026 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 3028 */         n += 6 + this.from_jid_.length;
/*      */       }
/*      */ 
/* 3031 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3036 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3040 */       this.optional_0_ = 0;
/* 3041 */       this.jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3042 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3043 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppInviteRequest newInstance() {
/* 3047 */       return new XmppInviteRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3051 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3072 */       sink.putByte(10);
/* 3073 */       sink.putPrefixedData(this.jid_);
/*      */ 
/* 3075 */       int this_t0 = this.optional_0_;
/* 3076 */       if ((this_t0 & 0x2) != 0) {
/* 3077 */         sink.putByte(18);
/* 3078 */         sink.putPrefixedData(this.from_jid_);
/*      */       }
/*      */ 
/* 3081 */       if (this.uninterpreted != null)
/* 3082 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3087 */       boolean result = true;
/* 3088 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3090 */       while (source.hasRemaining()) {
/* 3091 */         int tt = source.getVarInt();
/* 3092 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3096 */           result = false;
/* 3097 */           break;
/*      */         case 10:
/* 3100 */           this.jid_ = source.getPrefixedData();
/* 3101 */           this_t0 |= 1;
/* 3102 */           break;
/*      */         case 18:
/* 3105 */           this.from_jid_ = source.getPrefixedData();
/* 3106 */           this_t0 |= 2;
/* 3107 */           break;
/*      */         default:
/* 3109 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3114 */       this.optional_0_ = this_t0;
/* 3115 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppInviteRequest getDefaultInstanceForType()
/*      */     {
/* 3120 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppInviteRequest getDefaultInstance() {
/* 3124 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public XmppInviteRequest freeze()
/*      */     {
/* 3189 */       this.jid_ = ProtocolSupport.freezeString(this.jid_);
/* 3190 */       this.from_jid_ = ProtocolSupport.freezeString(this.from_jid_);
/* 3191 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 3194 */       if (this.uninterpreted == null) {
/* 3195 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3197 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3128 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppInviteRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppInviteRequest clearJid()
/*      */         {
/* 3136 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest setJidAsBytes(byte[] x) {
/* 3139 */           ProtocolSupport.unsupportedOperation();
/* 3140 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest setJid(String v) {
/* 3143 */           ProtocolSupport.unsupportedOperation();
/* 3144 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest setJid(String v, Charset cs) {
/* 3147 */           ProtocolSupport.unsupportedOperation();
/* 3148 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppInviteRequest clearFromJid()
/*      */         {
/* 3153 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest setFromJidAsBytes(byte[] x) {
/* 3156 */           ProtocolSupport.unsupportedOperation();
/* 3157 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest setFromJid(String v) {
/* 3160 */           ProtocolSupport.unsupportedOperation();
/* 3161 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest setFromJid(String v, Charset cs) {
/* 3164 */           ProtocolSupport.unsupportedOperation();
/* 3165 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppInviteRequest mergeFrom(XMPPServicePb.XmppInviteRequest that) {
/* 3169 */           ProtocolSupport.unsupportedOperation();
/* 3170 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3173 */           ProtocolSupport.unsupportedOperation();
/* 3174 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest freeze() {
/* 3177 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppInviteRequest unfreeze() {
/* 3180 */           ProtocolSupport.unsupportedOperation();
/* 3181 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3184 */           return true;
/*      */         }
/*      */       };
/* 3203 */       text = new String[3];
/*      */ 
/* 3205 */       text[0] = "ErrorCode";
/* 3206 */       text[1] = "jid";
/* 3207 */       text[2] = "from_jid";
/*      */ 
/* 3210 */       types = new int[3];
/*      */ 
/* 3212 */       Arrays.fill(types, 6);
/* 3213 */       types[0] = 0;
/* 3214 */       types[1] = 2;
/* 3215 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3055 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppInviteRequest.class, "Z&apphosting/api/xmpp/xmpp_service.proto\n\034apphosting.XmppInviteRequest\023\032\003jid \001(\0020\t8\002\024\023\032\bfrom_jid \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("jid", "jid", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("from_jid", "from_jid", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppSendPresenceResponse extends ProtocolMessage<XmppSendPresenceResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final XmppSendPresenceResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public XmppSendPresenceResponse mergeFrom(XmppSendPresenceResponse that)
/*      */     {
/* 2684 */       assert (that != this);
/*      */ 
/* 2686 */       if (that.uninterpreted != null) {
/* 2687 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2689 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppSendPresenceResponse that) {
/* 2693 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppSendPresenceResponse that) {
/* 2697 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppSendPresenceResponse that, boolean ignoreUninterpreted) {
/* 2701 */       if (that == null) return false;
/* 2702 */       if (that == this) return true;
/*      */ 
/* 2704 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2709 */       return ((that instanceof XmppSendPresenceResponse)) && (equals((XmppSendPresenceResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2713 */       int hash = -185513675;
/* 2714 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2715 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2717 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2721 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 2725 */       int n = 0;
/*      */ 
/* 2727 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2732 */       int n = 0;
/*      */ 
/* 2734 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2739 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2743 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppSendPresenceResponse newInstance() {
/* 2747 */       return new XmppSendPresenceResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2751 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2767 */       if (this.uninterpreted != null)
/* 2768 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2773 */       boolean result = true;
/*      */ 
/* 2775 */       while (source.hasRemaining()) {
/* 2776 */         int tt = source.getVarInt();
/* 2777 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2781 */           result = false;
/* 2782 */           break;
/*      */         default:
/* 2784 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2789 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppSendPresenceResponse getDefaultInstanceForType()
/*      */     {
/* 2794 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppSendPresenceResponse getDefaultInstance() {
/* 2798 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 2828 */       if (this.uninterpreted == null) {
/* 2829 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2831 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2802 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppSendPresenceResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceResponse mergeFrom(XMPPServicePb.XmppSendPresenceResponse that)
/*      */         {
/* 2809 */           ProtocolSupport.unsupportedOperation();
/* 2810 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2813 */           ProtocolSupport.unsupportedOperation();
/* 2814 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceResponse freeze() {
/* 2817 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceResponse unfreeze() {
/* 2820 */           ProtocolSupport.unsupportedOperation();
/* 2821 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2824 */           return true;
/*      */         }
/*      */       };
/* 2835 */       text = new String[1];
/*      */ 
/* 2837 */       text[0] = "ErrorCode";
/*      */ 
/* 2840 */       types = new int[1];
/*      */ 
/* 2842 */       Arrays.fill(types, 6);
/* 2843 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2755 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppSendPresenceResponse.class, "Z&apphosting/api/xmpp/xmpp_service.proto\n#apphosting.XmppSendPresenceResponse", new ProtocolType.FieldType[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppSendPresenceRequest extends ProtocolMessage<XmppSendPresenceRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2029 */     private byte[] jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2030 */     private byte[] type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2031 */     private byte[] show_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2032 */     private byte[] status_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2033 */     private byte[] from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final XmppSendPresenceRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kjid = 1;
/*      */     public static final int ktype = 2;
/*      */     public static final int kshow = 3;
/*      */     public static final int kstatus = 4;
/*      */     public static final int kfrom_jid = 5;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getJidAsBytes()
/*      */     {
/* 2039 */       return this.jid_;
/*      */     }
/*      */     public final boolean hasJid() {
/* 2042 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public XmppSendPresenceRequest clearJid() {
/* 2045 */       this.optional_0_ &= -2;
/* 2046 */       this.jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2047 */       return this;
/*      */     }
/*      */     public XmppSendPresenceRequest setJidAsBytes(byte[] x) {
/* 2050 */       this.optional_0_ |= 1;
/* 2051 */       this.jid_ = x;
/* 2052 */       return this;
/*      */     }
/*      */     public final String getJid() {
/* 2055 */       return ProtocolSupport.toStringUtf8(this.jid_);
/*      */     }
/*      */     public XmppSendPresenceRequest setJid(String v) {
/* 2058 */       if (v == null) throw new NullPointerException();
/* 2059 */       this.optional_0_ |= 1;
/* 2060 */       this.jid_ = ProtocolSupport.toBytesUtf8(v);
/* 2061 */       return this;
/*      */     }
/*      */     public final String getJid(Charset cs) {
/* 2064 */       return ProtocolSupport.toString(this.jid_, cs);
/*      */     }
/*      */     public XmppSendPresenceRequest setJid(String v, Charset cs) {
/* 2067 */       if (v == null) throw new NullPointerException();
/* 2068 */       this.optional_0_ |= 1;
/* 2069 */       this.jid_ = ProtocolSupport.toBytes(v, cs);
/* 2070 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getTypeAsBytes()
/*      */     {
/* 2075 */       return this.type_;
/*      */     }
/*      */     public final boolean hasType() {
/* 2078 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public XmppSendPresenceRequest clearType() {
/* 2081 */       this.optional_0_ &= -3;
/* 2082 */       this.type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2083 */       return this;
/*      */     }
/*      */     public XmppSendPresenceRequest setTypeAsBytes(byte[] x) {
/* 2086 */       this.optional_0_ |= 2;
/* 2087 */       this.type_ = x;
/* 2088 */       return this;
/*      */     }
/*      */     public final String getType() {
/* 2091 */       return ProtocolSupport.toStringUtf8(this.type_);
/*      */     }
/*      */     public XmppSendPresenceRequest setType(String v) {
/* 2094 */       if (v == null) throw new NullPointerException();
/* 2095 */       this.optional_0_ |= 2;
/* 2096 */       this.type_ = ProtocolSupport.toBytesUtf8(v);
/* 2097 */       return this;
/*      */     }
/*      */     public final String getType(Charset cs) {
/* 2100 */       return ProtocolSupport.toString(this.type_, cs);
/*      */     }
/*      */     public XmppSendPresenceRequest setType(String v, Charset cs) {
/* 2103 */       if (v == null) throw new NullPointerException();
/* 2104 */       this.optional_0_ |= 2;
/* 2105 */       this.type_ = ProtocolSupport.toBytes(v, cs);
/* 2106 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getShowAsBytes()
/*      */     {
/* 2111 */       return this.show_;
/*      */     }
/*      */     public final boolean hasShow() {
/* 2114 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public XmppSendPresenceRequest clearShow() {
/* 2117 */       this.optional_0_ &= -5;
/* 2118 */       this.show_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2119 */       return this;
/*      */     }
/*      */     public XmppSendPresenceRequest setShowAsBytes(byte[] x) {
/* 2122 */       this.optional_0_ |= 4;
/* 2123 */       this.show_ = x;
/* 2124 */       return this;
/*      */     }
/*      */     public final String getShow() {
/* 2127 */       return ProtocolSupport.toStringUtf8(this.show_);
/*      */     }
/*      */     public XmppSendPresenceRequest setShow(String v) {
/* 2130 */       if (v == null) throw new NullPointerException();
/* 2131 */       this.optional_0_ |= 4;
/* 2132 */       this.show_ = ProtocolSupport.toBytesUtf8(v);
/* 2133 */       return this;
/*      */     }
/*      */     public final String getShow(Charset cs) {
/* 2136 */       return ProtocolSupport.toString(this.show_, cs);
/*      */     }
/*      */     public XmppSendPresenceRequest setShow(String v, Charset cs) {
/* 2139 */       if (v == null) throw new NullPointerException();
/* 2140 */       this.optional_0_ |= 4;
/* 2141 */       this.show_ = ProtocolSupport.toBytes(v, cs);
/* 2142 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getStatusAsBytes()
/*      */     {
/* 2147 */       return this.status_;
/*      */     }
/*      */     public final boolean hasStatus() {
/* 2150 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public XmppSendPresenceRequest clearStatus() {
/* 2153 */       this.optional_0_ &= -9;
/* 2154 */       this.status_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2155 */       return this;
/*      */     }
/*      */     public XmppSendPresenceRequest setStatusAsBytes(byte[] x) {
/* 2158 */       this.optional_0_ |= 8;
/* 2159 */       this.status_ = x;
/* 2160 */       return this;
/*      */     }
/*      */     public final String getStatus() {
/* 2163 */       return ProtocolSupport.toStringUtf8(this.status_);
/*      */     }
/*      */     public XmppSendPresenceRequest setStatus(String v) {
/* 2166 */       if (v == null) throw new NullPointerException();
/* 2167 */       this.optional_0_ |= 8;
/* 2168 */       this.status_ = ProtocolSupport.toBytesUtf8(v);
/* 2169 */       return this;
/*      */     }
/*      */     public final String getStatus(Charset cs) {
/* 2172 */       return ProtocolSupport.toString(this.status_, cs);
/*      */     }
/*      */     public XmppSendPresenceRequest setStatus(String v, Charset cs) {
/* 2175 */       if (v == null) throw new NullPointerException();
/* 2176 */       this.optional_0_ |= 8;
/* 2177 */       this.status_ = ProtocolSupport.toBytes(v, cs);
/* 2178 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFromJidAsBytes()
/*      */     {
/* 2183 */       return this.from_jid_;
/*      */     }
/*      */     public final boolean hasFromJid() {
/* 2186 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public XmppSendPresenceRequest clearFromJid() {
/* 2189 */       this.optional_0_ &= -17;
/* 2190 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2191 */       return this;
/*      */     }
/*      */     public XmppSendPresenceRequest setFromJidAsBytes(byte[] x) {
/* 2194 */       this.optional_0_ |= 16;
/* 2195 */       this.from_jid_ = x;
/* 2196 */       return this;
/*      */     }
/*      */     public final String getFromJid() {
/* 2199 */       return ProtocolSupport.toStringUtf8(this.from_jid_);
/*      */     }
/*      */     public XmppSendPresenceRequest setFromJid(String v) {
/* 2202 */       if (v == null) throw new NullPointerException();
/* 2203 */       this.optional_0_ |= 16;
/* 2204 */       this.from_jid_ = ProtocolSupport.toBytesUtf8(v);
/* 2205 */       return this;
/*      */     }
/*      */     public final String getFromJid(Charset cs) {
/* 2208 */       return ProtocolSupport.toString(this.from_jid_, cs);
/*      */     }
/*      */     public XmppSendPresenceRequest setFromJid(String v, Charset cs) {
/* 2211 */       if (v == null) throw new NullPointerException();
/* 2212 */       this.optional_0_ |= 16;
/* 2213 */       this.from_jid_ = ProtocolSupport.toBytes(v, cs);
/* 2214 */       return this;
/*      */     }
/*      */ 
/*      */     public XmppSendPresenceRequest mergeFrom(XmppSendPresenceRequest that)
/*      */     {
/* 2221 */       assert (that != this);
/* 2222 */       int this_t0 = this.optional_0_;
/* 2223 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2225 */       if ((that_t0 & 0x1) != 0) {
/* 2226 */         this_t0 |= 1;
/* 2227 */         this.jid_ = that.jid_;
/*      */       }
/*      */ 
/* 2230 */       if ((that_t0 & 0x2) != 0) {
/* 2231 */         this_t0 |= 2;
/* 2232 */         this.type_ = that.type_;
/*      */       }
/*      */ 
/* 2235 */       if ((that_t0 & 0x4) != 0) {
/* 2236 */         this_t0 |= 4;
/* 2237 */         this.show_ = that.show_;
/*      */       }
/*      */ 
/* 2240 */       if ((that_t0 & 0x8) != 0) {
/* 2241 */         this_t0 |= 8;
/* 2242 */         this.status_ = that.status_;
/*      */       }
/*      */ 
/* 2245 */       if ((that_t0 & 0x10) != 0) {
/* 2246 */         this_t0 |= 16;
/* 2247 */         this.from_jid_ = that.from_jid_;
/*      */       }
/*      */ 
/* 2250 */       if (that.uninterpreted != null) {
/* 2251 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2253 */       this.optional_0_ = this_t0;
/* 2254 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppSendPresenceRequest that) {
/* 2258 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppSendPresenceRequest that) {
/* 2262 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppSendPresenceRequest that, boolean ignoreUninterpreted) {
/* 2266 */       if (that == null) return false;
/* 2267 */       if (that == this) return true;
/* 2268 */       int this_t0 = this.optional_0_;
/* 2269 */       int that_t0 = that.optional_0_;
/* 2270 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2272 */       if (((this_t0 & 0x1) != 0) && 
/* 2273 */         (!Arrays.equals(this.jid_, that.jid_))) return false;
/*      */ 
/* 2276 */       if (((this_t0 & 0x2) != 0) && 
/* 2277 */         (!Arrays.equals(this.type_, that.type_))) return false;
/*      */ 
/* 2280 */       if (((this_t0 & 0x4) != 0) && 
/* 2281 */         (!Arrays.equals(this.show_, that.show_))) return false;
/*      */ 
/* 2284 */       if (((this_t0 & 0x8) != 0) && 
/* 2285 */         (!Arrays.equals(this.status_, that.status_))) return false;
/*      */ 
/* 2288 */       if (((this_t0 & 0x10) != 0) && 
/* 2289 */         (!Arrays.equals(this.from_jid_, that.from_jid_))) return false;
/*      */ 
/* 2292 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2297 */       return ((that instanceof XmppSendPresenceRequest)) && (equals((XmppSendPresenceRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2301 */       int hash = 650409308;
/*      */ 
/* 2303 */       int this_t0 = this.optional_0_;
/* 2304 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.jid_) : -113);
/*      */ 
/* 2306 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.type_) : -113);
/*      */ 
/* 2308 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.show_) : -113);
/*      */ 
/* 2310 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Arrays.hashCode(this.status_) : -113);
/*      */ 
/* 2312 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? Arrays.hashCode(this.from_jid_) : -113);
/* 2313 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2314 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2316 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2320 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2322 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2329 */       int n = 1 + Protocol.stringSize(this.jid_.length);
/* 2330 */       int this_t0 = this.optional_0_;
/* 2331 */       if ((this_t0 & 0x1E) != 0) {
/* 2332 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 2334 */           n += 1 + Protocol.stringSize(this.type_.length);
/*      */         }
/* 2336 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 2338 */           n += 1 + Protocol.stringSize(this.show_.length);
/*      */         }
/* 2340 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 2342 */           n += 1 + Protocol.stringSize(this.status_.length);
/*      */         }
/* 2344 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 2346 */           n += 1 + Protocol.stringSize(this.from_jid_.length);
/*      */         }
/*      */       }
/*      */ 
/* 2350 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2356 */       int n = 6 + this.jid_.length;
/* 2357 */       int this_t0 = this.optional_0_;
/* 2358 */       if ((this_t0 & 0x1E) != 0) {
/* 2359 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 2361 */           n += 6 + this.type_.length;
/*      */         }
/* 2363 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 2365 */           n += 6 + this.show_.length;
/*      */         }
/* 2367 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 2369 */           n += 6 + this.status_.length;
/*      */         }
/* 2371 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 2373 */           n += 6 + this.from_jid_.length;
/*      */         }
/*      */       }
/*      */ 
/* 2377 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2382 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2386 */       this.optional_0_ = 0;
/* 2387 */       this.jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2388 */       this.type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2389 */       this.show_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2390 */       this.status_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2391 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2392 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppSendPresenceRequest newInstance() {
/* 2396 */       return new XmppSendPresenceRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2400 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2431 */       sink.putByte(10);
/* 2432 */       sink.putPrefixedData(this.jid_);
/*      */ 
/* 2434 */       int this_t0 = this.optional_0_;
/* 2435 */       if ((this_t0 & 0x2) != 0) {
/* 2436 */         sink.putByte(18);
/* 2437 */         sink.putPrefixedData(this.type_);
/*      */       }
/*      */ 
/* 2440 */       if ((this_t0 & 0x4) != 0) {
/* 2441 */         sink.putByte(26);
/* 2442 */         sink.putPrefixedData(this.show_);
/*      */       }
/*      */ 
/* 2445 */       if ((this_t0 & 0x8) != 0) {
/* 2446 */         sink.putByte(34);
/* 2447 */         sink.putPrefixedData(this.status_);
/*      */       }
/*      */ 
/* 2450 */       if ((this_t0 & 0x10) != 0) {
/* 2451 */         sink.putByte(42);
/* 2452 */         sink.putPrefixedData(this.from_jid_);
/*      */       }
/*      */ 
/* 2455 */       if (this.uninterpreted != null)
/* 2456 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2461 */       boolean result = true;
/* 2462 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2464 */       while (source.hasRemaining()) {
/* 2465 */         int tt = source.getVarInt();
/* 2466 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2470 */           result = false;
/* 2471 */           break;
/*      */         case 10:
/* 2474 */           this.jid_ = source.getPrefixedData();
/* 2475 */           this_t0 |= 1;
/* 2476 */           break;
/*      */         case 18:
/* 2479 */           this.type_ = source.getPrefixedData();
/* 2480 */           this_t0 |= 2;
/* 2481 */           break;
/*      */         case 26:
/* 2484 */           this.show_ = source.getPrefixedData();
/* 2485 */           this_t0 |= 4;
/* 2486 */           break;
/*      */         case 34:
/* 2489 */           this.status_ = source.getPrefixedData();
/* 2490 */           this_t0 |= 8;
/* 2491 */           break;
/*      */         case 42:
/* 2494 */           this.from_jid_ = source.getPrefixedData();
/* 2495 */           this_t0 |= 16;
/* 2496 */           break;
/*      */         default:
/* 2498 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2503 */       this.optional_0_ = this_t0;
/* 2504 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppSendPresenceRequest getDefaultInstanceForType()
/*      */     {
/* 2509 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppSendPresenceRequest getDefaultInstance() {
/* 2513 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public XmppSendPresenceRequest freeze()
/*      */     {
/* 2629 */       this.jid_ = ProtocolSupport.freezeString(this.jid_);
/* 2630 */       this.type_ = ProtocolSupport.freezeString(this.type_);
/* 2631 */       this.show_ = ProtocolSupport.freezeString(this.show_);
/* 2632 */       this.status_ = ProtocolSupport.freezeString(this.status_);
/* 2633 */       this.from_jid_ = ProtocolSupport.freezeString(this.from_jid_);
/* 2634 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 2637 */       if (this.uninterpreted == null) {
/* 2638 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2640 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2517 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppSendPresenceRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceRequest clearJid()
/*      */         {
/* 2525 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setJidAsBytes(byte[] x) {
/* 2528 */           ProtocolSupport.unsupportedOperation();
/* 2529 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setJid(String v) {
/* 2532 */           ProtocolSupport.unsupportedOperation();
/* 2533 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setJid(String v, Charset cs) {
/* 2536 */           ProtocolSupport.unsupportedOperation();
/* 2537 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceRequest clearType()
/*      */         {
/* 2542 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setTypeAsBytes(byte[] x) {
/* 2545 */           ProtocolSupport.unsupportedOperation();
/* 2546 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setType(String v) {
/* 2549 */           ProtocolSupport.unsupportedOperation();
/* 2550 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setType(String v, Charset cs) {
/* 2553 */           ProtocolSupport.unsupportedOperation();
/* 2554 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceRequest clearShow()
/*      */         {
/* 2559 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setShowAsBytes(byte[] x) {
/* 2562 */           ProtocolSupport.unsupportedOperation();
/* 2563 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setShow(String v) {
/* 2566 */           ProtocolSupport.unsupportedOperation();
/* 2567 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setShow(String v, Charset cs) {
/* 2570 */           ProtocolSupport.unsupportedOperation();
/* 2571 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceRequest clearStatus()
/*      */         {
/* 2576 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setStatusAsBytes(byte[] x) {
/* 2579 */           ProtocolSupport.unsupportedOperation();
/* 2580 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setStatus(String v) {
/* 2583 */           ProtocolSupport.unsupportedOperation();
/* 2584 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setStatus(String v, Charset cs) {
/* 2587 */           ProtocolSupport.unsupportedOperation();
/* 2588 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceRequest clearFromJid()
/*      */         {
/* 2593 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setFromJidAsBytes(byte[] x) {
/* 2596 */           ProtocolSupport.unsupportedOperation();
/* 2597 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setFromJid(String v) {
/* 2600 */           ProtocolSupport.unsupportedOperation();
/* 2601 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest setFromJid(String v, Charset cs) {
/* 2604 */           ProtocolSupport.unsupportedOperation();
/* 2605 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppSendPresenceRequest mergeFrom(XMPPServicePb.XmppSendPresenceRequest that) {
/* 2609 */           ProtocolSupport.unsupportedOperation();
/* 2610 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2613 */           ProtocolSupport.unsupportedOperation();
/* 2614 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest freeze() {
/* 2617 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppSendPresenceRequest unfreeze() {
/* 2620 */           ProtocolSupport.unsupportedOperation();
/* 2621 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2624 */           return true;
/*      */         }
/*      */       };
/* 2649 */       text = new String[6];
/*      */ 
/* 2651 */       text[0] = "ErrorCode";
/* 2652 */       text[1] = "jid";
/* 2653 */       text[2] = "type";
/* 2654 */       text[3] = "show";
/* 2655 */       text[4] = "status";
/* 2656 */       text[5] = "from_jid";
/*      */ 
/* 2659 */       types = new int[6];
/*      */ 
/* 2661 */       Arrays.fill(types, 6);
/* 2662 */       types[0] = 0;
/* 2663 */       types[1] = 2;
/* 2664 */       types[2] = 2;
/* 2665 */       types[3] = 2;
/* 2666 */       types[4] = 2;
/* 2667 */       types[5] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2404 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppSendPresenceRequest.class, "Z&apphosting/api/xmpp/xmpp_service.proto\n\"apphosting.XmppSendPresenceRequest\023\032\003jid \001(\0020\t8\002\024\023\032\004type \002(\0020\t8\001\024\023\032\004show \003(\0020\t8\001\024\023\032\006status \004(\0020\t8\001\024\023\032\bfrom_jid \005(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("jid", "jid", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("type", "type", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("show", "show", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("status", "status", 4, 3, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("from_jid", "from_jid", 5, 4, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppMessageResponse extends ProtocolMessage<XmppMessageResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1697 */     private int[] status_ = ProtocolSupport.EMPTY_INT_ARRAY;
/*      */     private int status_elts_;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final XmppMessageResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kstatus = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int statusSize()
/*      */     {
/* 1726 */       return this.status_elts_;
/*      */     }
/*      */     public final int getStatus(int i) {
/* 1729 */       assert ((i >= 0) && (i < this.status_elts_));
/* 1730 */       return this.status_[i];
/*      */     }
/*      */     public XmppMessageResponse clearStatus() {
/* 1733 */       this.status_elts_ = 0;
/* 1734 */       this.status_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 1735 */       return this;
/*      */     }
/*      */     public XmppMessageResponse setStatus(int i, int v) {
/* 1738 */       assert ((i >= 0) && (i < this.status_elts_));
/* 1739 */       this.status_[i] = v;
/* 1740 */       return this;
/*      */     }
/*      */     public XmppMessageResponse addStatus(int v) {
/* 1743 */       if (this.status_elts_ == this.status_.length) {
/* 1744 */         this.status_ = ProtocolSupport.growArray(this.status_);
/*      */       }
/* 1746 */       this.status_[(this.status_elts_++)] = v;
/* 1747 */       return this;
/*      */     }
/*      */     public final Iterator<Integer> statusIterator() {
/* 1750 */       return ProtocolSupport.asList(this.status_, 0, this.status_elts_).iterator();
/*      */     }
/*      */     public final List<Integer> statuss() {
/* 1753 */       return ProtocolSupport.asList(this.status_, 0, this.status_elts_);
/*      */     }
/*      */     public final List<Integer> mutableStatuss() {
/* 1756 */       return new AbstractList() {
/* 1757 */         public int size() { return XMPPServicePb.XmppMessageResponse.this.status_elts_; } 
/*      */         public Integer get(int i) {
/* 1759 */           if ((i < 0) || (i >= size())) {
/* 1760 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 1762 */           return Integer.valueOf(XMPPServicePb.XmppMessageResponse.this.status_[i]);
/*      */         }
/*      */         public Integer set(int i, Integer elt) {
/* 1765 */           Integer result = get(i);
/* 1766 */           XMPPServicePb.XmppMessageResponse.this.setStatus(i, elt.intValue());
/* 1767 */           return result;
/*      */         }
/*      */         public boolean add(Integer elt) {
/* 1770 */           XMPPServicePb.XmppMessageResponse.this.addStatus(elt.intValue());
/* 1771 */           return true;
/*      */         }
/*      */         public Integer remove(int i) {
/* 1774 */           if ((i < 0) || (i >= size())) {
/* 1775 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 1777 */           Integer result = get(i);
/* 1778 */           for (int j = i + 1; j < size(); j++) {
/* 1779 */             XMPPServicePb.XmppMessageResponse.this.status_[(j - 1)] = XMPPServicePb.XmppMessageResponse.access$500(XMPPServicePb.XmppMessageResponse.this)[j];
/*      */           }
/* 1781 */           XMPPServicePb.XmppMessageResponse.access$410(XMPPServicePb.XmppMessageResponse.this);
/* 1782 */           return result;
/*      */         }
/* 1784 */         public void clear() { XMPPServicePb.XmppMessageResponse.access$402(XMPPServicePb.XmppMessageResponse.this, 0);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public XmppMessageResponse mergeFrom(XmppMessageResponse that)
/*      */     {
/* 1792 */       assert (that != this);
/*      */ 
/* 1794 */       if (that.status_elts_ > 0) {
/* 1795 */         this.status_ = ProtocolSupport.ensureCapacity(this.status_, this.status_elts_ + that.status_elts_);
/* 1796 */         System.arraycopy(that.status_, 0, this.status_, this.status_elts_, that.status_elts_);
/* 1797 */         this.status_elts_ += that.status_elts_;
/*      */       }
/*      */ 
/* 1800 */       if (that.uninterpreted != null) {
/* 1801 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1803 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppMessageResponse that) {
/* 1807 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppMessageResponse that) {
/* 1811 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppMessageResponse that, boolean ignoreUninterpreted) {
/* 1815 */       if (that == null) return false;
/* 1816 */       if (that == this) return true;
/* 1819 */       int n;
/* 1819 */       if ((n = this.status_elts_) != that.status_elts_) return false;
/* 1820 */       for (int i = 0; i < n; i++) {
/* 1821 */         if (this.status_[i] != that.status_[i]) return false;
/*      */       }
/*      */ 
/* 1824 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1829 */       return ((that instanceof XmppMessageResponse)) && (equals((XmppMessageResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1833 */       int hash = -21064635;
/*      */ 
/* 1835 */       hash *= 31;
/* 1836 */       int i = 0; for (int n = this.status_elts_; i < n; i++) {
/* 1837 */         hash = hash * 31 + this.status_[i];
/*      */       }
/* 1839 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1840 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1842 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1846 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 1850 */       int n = 0;
/*      */       int m;
/* 1853 */       n += (m = this.status_elts_);
/* 1854 */       for (int i = 0; i < m; i++) {
/* 1855 */         n += Protocol.varLongSize(this.status_[i]);
/*      */       }
/*      */ 
/* 1858 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1863 */       int n = 0;
/*      */ 
/* 1865 */       n += 11 * this.status_elts_;
/*      */ 
/* 1867 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1872 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1876 */       this.status_elts_ = 0;
/* 1877 */       this.status_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 1878 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppMessageResponse newInstance() {
/* 1882 */       return new XmppMessageResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1886 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1910 */       int i = 0; for (int m = this.status_elts_; i < m; i++) {
/* 1911 */         int v = this.status_[i];
/* 1912 */         sink.putByte(8);
/* 1913 */         sink.putVarLong(v);
/*      */       }
/*      */ 
/* 1916 */       if (this.uninterpreted != null)
/* 1917 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1922 */       boolean result = true;
/*      */ 
/* 1924 */       while (source.hasRemaining()) {
/* 1925 */         int tt = source.getVarInt();
/* 1926 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1930 */           result = false;
/* 1931 */           break;
/*      */         case 8:
/* 1934 */           addStatus(source.getVarInt());
/* 1935 */           break;
/*      */         default:
/* 1937 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1942 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppMessageResponse getDefaultInstanceForType()
/*      */     {
/* 1947 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppMessageResponse getDefaultInstance() {
/* 1951 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public XmppMessageResponse freeze()
/*      */     {
/* 1995 */       this.status_ = ProtocolSupport.freezeArray(this.status_, this.status_elts_);
/* 1996 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1999 */       if (this.uninterpreted == null) {
/* 2000 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2002 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1955 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppMessageResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppMessageResponse clearStatus()
/*      */         {
/* 1963 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageResponse setStatus(int i, int v) {
/* 1966 */           ProtocolSupport.unsupportedOperation();
/* 1967 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageResponse addStatus(int v) {
/* 1970 */           ProtocolSupport.unsupportedOperation();
/* 1971 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageResponse mergeFrom(XMPPServicePb.XmppMessageResponse that) {
/* 1975 */           ProtocolSupport.unsupportedOperation();
/* 1976 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1979 */           ProtocolSupport.unsupportedOperation();
/* 1980 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageResponse freeze() {
/* 1983 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageResponse unfreeze() {
/* 1986 */           ProtocolSupport.unsupportedOperation();
/* 1987 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1990 */           return true;
/*      */         }
/*      */       };
/* 2007 */       text = new String[2];
/*      */ 
/* 2009 */       text[0] = "ErrorCode";
/* 2010 */       text[1] = "status";
/*      */ 
/* 2013 */       types = new int[2];
/*      */ 
/* 2015 */       Arrays.fill(types, 6);
/* 2016 */       types[0] = 0;
/* 2017 */       types[1] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1890 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppMessageResponse.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("status", "status", 1, -1, ProtocolType.Presence.REPEATED, XMPPServicePb.XmppMessageResponse.XmppMessageStatus.class) });
/*      */     }
/*      */ 
/*      */     public static enum XmppMessageStatus
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 1702 */       NO_ERROR(0), 
/* 1703 */       INVALID_JID(1), 
/* 1704 */       OTHER_ERROR(2);
/*      */ 
/*      */       public static final XmppMessageStatus XmppMessageStatus_MIN;
/*      */       public static final XmppMessageStatus XmppMessageStatus_MAX;
/*      */       private final int value;
/*      */ 
/* 1709 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static XmppMessageStatus valueOf(int value) {
/* 1712 */         switch (value) { case 0:
/* 1713 */           return NO_ERROR;
/*      */         case 1:
/* 1714 */           return INVALID_JID;
/*      */         case 2:
/* 1715 */           return OTHER_ERROR;
/*      */         }
/* 1717 */         return null;
/*      */       }
/*      */ 
/*      */       private XmppMessageStatus(int v) {
/* 1721 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1706 */         XmppMessageStatus_MIN = NO_ERROR;
/* 1707 */         XmppMessageStatus_MAX = OTHER_ERROR;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppMessageRequest extends ProtocolMessage<XmppMessageRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  995 */     private List<byte[]> jid_ = null;
/*  996 */     private byte[] body_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  997 */     private boolean raw_xml_ = false;
/*      */     private static final byte[] type_DEFAULT_;
/*  999 */     private byte[] type_ = type_DEFAULT_;
/* 1000 */     private byte[] from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final XmppMessageRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kjid = 1;
/*      */     public static final int kbody = 2;
/*      */     public static final int kraw_xml = 3;
/*      */     public static final int ktype = 4;
/*      */     public static final int kfrom_jid = 5;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int jidSize()
/*      */     {
/* 1006 */       return this.jid_ != null ? this.jid_.size() : 0;
/*      */     }
/*      */     public final byte[] getJidAsBytes(int i) {
/* 1009 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.jid_ != null ? this.jid_.size() : 0)); } else throw new AssertionError();
/* 1010 */       return (byte[])this.jid_.get(i);
/*      */     }
/*      */     public XmppMessageRequest clearJid() {
/* 1013 */       if (this.jid_ != null) this.jid_.clear();
/* 1014 */       return this;
/*      */     }
/*      */     public final String getJid(int i) {
/* 1017 */       return ProtocolSupport.toStringUtf8((byte[])this.jid_.get(i));
/*      */     }
/*      */     public XmppMessageRequest setJidAsBytes(int i, byte[] v) {
/* 1020 */       this.jid_.set(i, v);
/* 1021 */       return this;
/*      */     }
/*      */     public XmppMessageRequest setJid(int i, String v) {
/* 1024 */       if (v == null) throw new NullPointerException();
/* 1025 */       this.jid_.set(i, ProtocolSupport.toBytesUtf8(v));
/* 1026 */       return this;
/*      */     }
/*      */     public XmppMessageRequest addJidAsBytes(byte[] v) {
/* 1029 */       if (this.jid_ == null) this.jid_ = new ArrayList(4);
/* 1030 */       this.jid_.add(v);
/* 1031 */       return this;
/*      */     }
/*      */     public XmppMessageRequest addJid(String v) {
/* 1034 */       if (v == null) throw new NullPointerException();
/* 1035 */       if (this.jid_ == null) this.jid_ = new ArrayList(4);
/* 1036 */       this.jid_.add(ProtocolSupport.toBytesUtf8(v));
/* 1037 */       return this;
/*      */     }
/*      */     public final Iterator<String> jidIterator() {
/* 1040 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.jid_);
/*      */     }
/*      */     public final List<String> jids() {
/* 1043 */       return ProtocolSupport.byteArrayToUnicodeList(this.jid_);
/*      */     }
/*      */     public final Iterator<byte[]> jidAsBytesIterator() {
/* 1046 */       return this.jid_ == null ? ProtocolSupport.emptyIterator() : this.jid_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> jidsAsBytes()
/*      */     {
/* 1051 */       return ProtocolSupport.unmodifiableList(this.jid_);
/*      */     }
/*      */     public final List<byte[]> mutableJidsAsBytes() {
/* 1054 */       if (this.jid_ == null) this.jid_ = new ArrayList(4);
/* 1055 */       return this.jid_;
/*      */     }
/*      */     public final String getJid(int i, Charset cs) {
/* 1058 */       return ProtocolSupport.toString((byte[])this.jid_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest setJid(int i, String v, Charset cs) {
/* 1062 */       if (v == null) throw new NullPointerException();
/* 1063 */       this.jid_.set(i, ProtocolSupport.toBytes(v, cs));
/* 1064 */       return this;
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest addJid(String v, Charset cs) {
/* 1068 */       if (v == null) throw new NullPointerException();
/* 1069 */       if (this.jid_ == null) this.jid_ = new ArrayList(4);
/* 1070 */       this.jid_.add(ProtocolSupport.toBytes(v, cs));
/* 1071 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> jidIterator(Charset cs) {
/* 1075 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.jid_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> jids(Charset cs) {
/* 1079 */       return ProtocolSupport.byteArrayToUnicodeList(this.jid_, cs);
/*      */     }
/*      */ 
/*      */     public final byte[] getBodyAsBytes()
/*      */     {
/* 1084 */       return this.body_;
/*      */     }
/*      */     public final boolean hasBody() {
/* 1087 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public XmppMessageRequest clearBody() {
/* 1090 */       this.optional_0_ &= -2;
/* 1091 */       this.body_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1092 */       return this;
/*      */     }
/*      */     public XmppMessageRequest setBodyAsBytes(byte[] x) {
/* 1095 */       this.optional_0_ |= 1;
/* 1096 */       this.body_ = x;
/* 1097 */       return this;
/*      */     }
/*      */     public final String getBody() {
/* 1100 */       return ProtocolSupport.toStringUtf8(this.body_);
/*      */     }
/*      */     public XmppMessageRequest setBody(String v) {
/* 1103 */       if (v == null) throw new NullPointerException();
/* 1104 */       this.optional_0_ |= 1;
/* 1105 */       this.body_ = ProtocolSupport.toBytesUtf8(v);
/* 1106 */       return this;
/*      */     }
/*      */     public final String getBody(Charset cs) {
/* 1109 */       return ProtocolSupport.toString(this.body_, cs);
/*      */     }
/*      */     public XmppMessageRequest setBody(String v, Charset cs) {
/* 1112 */       if (v == null) throw new NullPointerException();
/* 1113 */       this.optional_0_ |= 1;
/* 1114 */       this.body_ = ProtocolSupport.toBytes(v, cs);
/* 1115 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isRawXml()
/*      */     {
/* 1120 */       return this.raw_xml_;
/*      */     }
/*      */     public final boolean hasRawXml() {
/* 1123 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public XmppMessageRequest clearRawXml() {
/* 1126 */       this.optional_0_ &= -3;
/* 1127 */       this.raw_xml_ = false;
/* 1128 */       return this;
/*      */     }
/*      */     public XmppMessageRequest setRawXml(boolean x) {
/* 1131 */       this.optional_0_ |= 2;
/* 1132 */       this.raw_xml_ = x;
/* 1133 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getTypeAsBytes()
/*      */     {
/* 1138 */       return this.type_;
/*      */     }
/*      */     public final boolean hasType() {
/* 1141 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public XmppMessageRequest clearType() {
/* 1144 */       this.optional_0_ &= -5;
/* 1145 */       this.type_ = ((byte[])type_DEFAULT_.clone());
/* 1146 */       return this;
/*      */     }
/*      */     public XmppMessageRequest setTypeAsBytes(byte[] x) {
/* 1149 */       this.optional_0_ |= 4;
/* 1150 */       this.type_ = x;
/* 1151 */       return this;
/*      */     }
/*      */     public final String getType() {
/* 1154 */       return ProtocolSupport.toStringUtf8(this.type_);
/*      */     }
/*      */     public XmppMessageRequest setType(String v) {
/* 1157 */       if (v == null) throw new NullPointerException();
/* 1158 */       this.optional_0_ |= 4;
/* 1159 */       this.type_ = ProtocolSupport.toBytesUtf8(v);
/* 1160 */       return this;
/*      */     }
/*      */     public final String getType(Charset cs) {
/* 1163 */       return ProtocolSupport.toString(this.type_, cs);
/*      */     }
/*      */     public XmppMessageRequest setType(String v, Charset cs) {
/* 1166 */       if (v == null) throw new NullPointerException();
/* 1167 */       this.optional_0_ |= 4;
/* 1168 */       this.type_ = ProtocolSupport.toBytes(v, cs);
/* 1169 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFromJidAsBytes()
/*      */     {
/* 1174 */       return this.from_jid_;
/*      */     }
/*      */     public final boolean hasFromJid() {
/* 1177 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public XmppMessageRequest clearFromJid() {
/* 1180 */       this.optional_0_ &= -9;
/* 1181 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1182 */       return this;
/*      */     }
/*      */     public XmppMessageRequest setFromJidAsBytes(byte[] x) {
/* 1185 */       this.optional_0_ |= 8;
/* 1186 */       this.from_jid_ = x;
/* 1187 */       return this;
/*      */     }
/*      */     public final String getFromJid() {
/* 1190 */       return ProtocolSupport.toStringUtf8(this.from_jid_);
/*      */     }
/*      */     public XmppMessageRequest setFromJid(String v) {
/* 1193 */       if (v == null) throw new NullPointerException();
/* 1194 */       this.optional_0_ |= 8;
/* 1195 */       this.from_jid_ = ProtocolSupport.toBytesUtf8(v);
/* 1196 */       return this;
/*      */     }
/*      */     public final String getFromJid(Charset cs) {
/* 1199 */       return ProtocolSupport.toString(this.from_jid_, cs);
/*      */     }
/*      */     public XmppMessageRequest setFromJid(String v, Charset cs) {
/* 1202 */       if (v == null) throw new NullPointerException();
/* 1203 */       this.optional_0_ |= 8;
/* 1204 */       this.from_jid_ = ProtocolSupport.toBytes(v, cs);
/* 1205 */       return this;
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest mergeFrom(XmppMessageRequest that)
/*      */     {
/* 1212 */       assert (that != this);
/* 1213 */       int this_t0 = this.optional_0_;
/* 1214 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1216 */       if ((that.jid_ != null) && (that.jid_.size() > 0)) {
/* 1217 */         if (this.jid_ == null)
/* 1218 */           this.jid_ = new ArrayList(that.jid_);
/*      */         else {
/* 1220 */           this.jid_.addAll(that.jid_);
/*      */         }
/*      */       }
/*      */ 
/* 1224 */       if ((that_t0 & 0x1) != 0) {
/* 1225 */         this_t0 |= 1;
/* 1226 */         this.body_ = that.body_;
/*      */       }
/*      */ 
/* 1229 */       if ((that_t0 & 0x2) != 0) {
/* 1230 */         this_t0 |= 2;
/* 1231 */         this.raw_xml_ = that.raw_xml_;
/*      */       }
/*      */ 
/* 1234 */       if ((that_t0 & 0x4) != 0) {
/* 1235 */         this_t0 |= 4;
/* 1236 */         this.type_ = that.type_;
/*      */       }
/*      */ 
/* 1239 */       if ((that_t0 & 0x8) != 0) {
/* 1240 */         this_t0 |= 8;
/* 1241 */         this.from_jid_ = that.from_jid_;
/*      */       }
/*      */ 
/* 1244 */       if (that.uninterpreted != null) {
/* 1245 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1247 */       this.optional_0_ = this_t0;
/* 1248 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppMessageRequest that) {
/* 1252 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppMessageRequest that) {
/* 1256 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppMessageRequest that, boolean ignoreUninterpreted) {
/* 1260 */       if (that == null) return false;
/* 1261 */       if (that == this) return true;
/* 1262 */       int this_t0 = this.optional_0_;
/* 1263 */       int that_t0 = that.optional_0_;
/* 1264 */       if (this_t0 != that_t0) return false;
/* 1267 */       int n;
/* 1267 */       if ((n = this.jid_ != null ? this.jid_.size() : 0) != (that.jid_ != null ? that.jid_.size() : 0)) return false;
/* 1268 */       for (int i = 0; i < n; i++) {
/* 1269 */         if (!Arrays.equals((byte[])this.jid_.get(i), (byte[])that.jid_.get(i))) return false;
/*      */       }
/*      */ 
/* 1272 */       if (((this_t0 & 0x1) != 0) && 
/* 1273 */         (!Arrays.equals(this.body_, that.body_))) return false;
/*      */ 
/* 1276 */       if (((this_t0 & 0x2) != 0) && 
/* 1277 */         (this.raw_xml_ != that.raw_xml_)) return false;
/*      */ 
/* 1280 */       if (((this_t0 & 0x4) != 0) && 
/* 1281 */         (!Arrays.equals(this.type_, that.type_))) return false;
/*      */ 
/* 1284 */       if (((this_t0 & 0x8) != 0) && 
/* 1285 */         (!Arrays.equals(this.from_jid_, that.from_jid_))) return false;
/*      */ 
/* 1288 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1293 */       return ((that instanceof XmppMessageRequest)) && (equals((XmppMessageRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1297 */       int hash = -1032797480;
/*      */ 
/* 1299 */       hash *= 31;
/* 1300 */       int i = 0; for (int n = this.jid_ != null ? this.jid_.size() : 0; i < n; i++) {
/* 1301 */         hash = hash * 31 + Arrays.hashCode((byte[])this.jid_.get(i));
/*      */       }
/*      */ 
/* 1304 */       int this_t0 = this.optional_0_;
/* 1305 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.body_) : -113);
/*      */ 
/* 1307 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? 1237 : this.raw_xml_ ? 1231 : -113);
/*      */ 
/* 1309 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.type_) : -113);
/*      */ 
/* 1311 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Arrays.hashCode(this.from_jid_) : -113);
/* 1312 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1313 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1315 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1319 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1321 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1328 */       int n = 1 + Protocol.stringSize(this.body_.length);
/*      */       int m;
/* 1331 */       n += (m = this.jid_ != null ? this.jid_.size() : 0);
/* 1332 */       for (int i = 0; i < m; i++) {
/* 1333 */         n += Protocol.stringSize(((byte[])this.jid_.get(i)).length);
/*      */       }
/* 1335 */       int this_t0 = this.optional_0_;
/* 1336 */       if ((this_t0 & 0xE) != 0) {
/* 1337 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 1339 */           n += 2;
/*      */         }
/* 1341 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 1343 */           n += 1 + Protocol.stringSize(this.type_.length);
/*      */         }
/* 1345 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 1347 */           n += 1 + Protocol.stringSize(this.from_jid_.length);
/*      */         }
/*      */       }
/*      */ 
/* 1351 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1358 */       int n = 8 + this.body_.length;
/*      */       int m;
/* 1361 */       n += 6 * (m = this.jid_ != null ? this.jid_.size() : 0);
/* 1362 */       for (int i = 0; i < m; i++) {
/* 1363 */         n += ((byte[])this.jid_.get(i)).length;
/*      */       }
/* 1365 */       int this_t0 = this.optional_0_;
/* 1366 */       if ((this_t0 & 0xC) != 0) {
/* 1367 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 1369 */           n += 6 + this.type_.length;
/*      */         }
/* 1371 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 1373 */           n += 6 + this.from_jid_.length;
/*      */         }
/*      */       }
/*      */ 
/* 1377 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1382 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1386 */       this.optional_0_ = 0;
/* 1387 */       if (this.jid_ != null) this.jid_.clear();
/* 1388 */       this.body_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1389 */       this.raw_xml_ = false;
/* 1390 */       this.type_ = ((byte[])type_DEFAULT_.clone());
/* 1391 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1392 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest newInstance() {
/* 1396 */       return new XmppMessageRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1400 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1435 */       int i = 0; for (int m = this.jid_ != null ? this.jid_.size() : 0; i < m; i++) {
/* 1436 */         byte[] v = (byte[])this.jid_.get(i);
/* 1437 */         sink.putByte(10);
/* 1438 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 1441 */       sink.putByte(18);
/* 1442 */       sink.putPrefixedData(this.body_);
/*      */ 
/* 1444 */       int this_t0 = this.optional_0_;
/* 1445 */       if ((this_t0 & 0x2) != 0) {
/* 1446 */         sink.putByte(24);
/* 1447 */         sink.putBoolean(this.raw_xml_);
/*      */       }
/*      */ 
/* 1450 */       if ((this_t0 & 0x4) != 0) {
/* 1451 */         sink.putByte(34);
/* 1452 */         sink.putPrefixedData(this.type_);
/*      */       }
/*      */ 
/* 1455 */       if ((this_t0 & 0x8) != 0) {
/* 1456 */         sink.putByte(42);
/* 1457 */         sink.putPrefixedData(this.from_jid_);
/*      */       }
/*      */ 
/* 1460 */       if (this.uninterpreted != null)
/* 1461 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1466 */       boolean result = true;
/* 1467 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1469 */       while (source.hasRemaining()) {
/* 1470 */         int tt = source.getVarInt();
/* 1471 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1475 */           result = false;
/* 1476 */           break;
/*      */         case 10:
/* 1479 */           addJidAsBytes(source.getPrefixedData());
/* 1480 */           break;
/*      */         case 18:
/* 1483 */           this.body_ = source.getPrefixedData();
/* 1484 */           this_t0 |= 1;
/* 1485 */           break;
/*      */         case 24:
/* 1488 */           this.raw_xml_ = source.getBoolean();
/* 1489 */           this_t0 |= 2;
/* 1490 */           break;
/*      */         case 34:
/* 1493 */           this.type_ = source.getPrefixedData();
/* 1494 */           this_t0 |= 4;
/* 1495 */           break;
/*      */         case 42:
/* 1498 */           this.from_jid_ = source.getPrefixedData();
/* 1499 */           this_t0 |= 8;
/* 1500 */           break;
/*      */         default:
/* 1502 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1507 */       this.optional_0_ = this_t0;
/* 1508 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest getDefaultInstanceForType()
/*      */     {
/* 1513 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppMessageRequest getDefaultInstance() {
/* 1517 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest freeze()
/*      */     {
/* 1639 */       this.jid_ = ProtocolSupport.freezeStrings(this.jid_);
/* 1640 */       this.body_ = ProtocolSupport.freezeString(this.body_);
/* 1641 */       this.type_ = ProtocolSupport.freezeString(this.type_);
/* 1642 */       this.from_jid_ = ProtocolSupport.freezeString(this.from_jid_);
/* 1643 */       return this;
/*      */     }
/*      */ 
/*      */     public XmppMessageRequest unfreeze() {
/* 1647 */       this.jid_ = ProtocolSupport.unfreezeStrings(this.jid_);
/* 1648 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 1652 */       return ProtocolSupport.isFrozenStrings(this.jid_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1655 */       if (this.uninterpreted == null) {
/* 1656 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1658 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  998 */       type_DEFAULT_ = new byte[] { 99, 104, 97, 116 };
/*      */ 
/* 1521 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppMessageRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest clearJid()
/*      */         {
/* 1529 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setJidAsBytes(int i, byte[] v) {
/* 1532 */           ProtocolSupport.unsupportedOperation();
/* 1533 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setJid(int i, String v) {
/* 1536 */           ProtocolSupport.unsupportedOperation();
/* 1537 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest addJidAsBytes(byte[] v) {
/* 1540 */           ProtocolSupport.unsupportedOperation();
/* 1541 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest addJid(String v) {
/* 1544 */           ProtocolSupport.unsupportedOperation();
/* 1545 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest setJid(int i, String v, Charset cs) {
/* 1549 */           ProtocolSupport.unsupportedOperation();
/* 1550 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest addJid(String v, Charset cs) {
/* 1554 */           ProtocolSupport.unsupportedOperation();
/* 1555 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest clearBody()
/*      */         {
/* 1560 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setBodyAsBytes(byte[] x) {
/* 1563 */           ProtocolSupport.unsupportedOperation();
/* 1564 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setBody(String v) {
/* 1567 */           ProtocolSupport.unsupportedOperation();
/* 1568 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setBody(String v, Charset cs) {
/* 1571 */           ProtocolSupport.unsupportedOperation();
/* 1572 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest clearRawXml()
/*      */         {
/* 1577 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setRawXml(boolean x) {
/* 1580 */           ProtocolSupport.unsupportedOperation();
/* 1581 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest clearType()
/*      */         {
/* 1586 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setTypeAsBytes(byte[] x) {
/* 1589 */           ProtocolSupport.unsupportedOperation();
/* 1590 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setType(String v) {
/* 1593 */           ProtocolSupport.unsupportedOperation();
/* 1594 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setType(String v, Charset cs) {
/* 1597 */           ProtocolSupport.unsupportedOperation();
/* 1598 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest clearFromJid()
/*      */         {
/* 1603 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setFromJidAsBytes(byte[] x) {
/* 1606 */           ProtocolSupport.unsupportedOperation();
/* 1607 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setFromJid(String v) {
/* 1610 */           ProtocolSupport.unsupportedOperation();
/* 1611 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest setFromJid(String v, Charset cs) {
/* 1614 */           ProtocolSupport.unsupportedOperation();
/* 1615 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.XmppMessageRequest mergeFrom(XMPPServicePb.XmppMessageRequest that) {
/* 1619 */           ProtocolSupport.unsupportedOperation();
/* 1620 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1623 */           ProtocolSupport.unsupportedOperation();
/* 1624 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest freeze() {
/* 1627 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppMessageRequest unfreeze() {
/* 1630 */           ProtocolSupport.unsupportedOperation();
/* 1631 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1634 */           return true;
/*      */         }
/*      */       };
/* 1667 */       text = new String[6];
/*      */ 
/* 1669 */       text[0] = "ErrorCode";
/* 1670 */       text[1] = "jid";
/* 1671 */       text[2] = "body";
/* 1672 */       text[3] = "raw_xml";
/* 1673 */       text[4] = "type";
/* 1674 */       text[5] = "from_jid";
/*      */ 
/* 1677 */       types = new int[6];
/*      */ 
/* 1679 */       Arrays.fill(types, 6);
/* 1680 */       types[0] = 0;
/* 1681 */       types[1] = 2;
/* 1682 */       types[2] = 2;
/* 1683 */       types[3] = 0;
/* 1684 */       types[4] = 2;
/* 1685 */       types[5] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1404 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppMessageRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("jid", "jid", 1, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("body", "body", 2, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("raw_xml", "raw_xml", 3, 1, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("type", "type", 4, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("from_jid", "from_jid", 5, 3, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PresenceResponse extends ProtocolMessage<PresenceResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  638 */     private boolean is_available_ = false;
/*  639 */     private int presence_ = 0;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final PresenceResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kis_available = 1;
/*      */     public static final int kpresence = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final boolean isIsAvailable()
/*      */     {
/*  672 */       return this.is_available_;
/*      */     }
/*      */     public final boolean hasIsAvailable() {
/*  675 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public PresenceResponse clearIsAvailable() {
/*  678 */       this.optional_0_ &= -2;
/*  679 */       this.is_available_ = false;
/*  680 */       return this;
/*      */     }
/*      */     public PresenceResponse setIsAvailable(boolean x) {
/*  683 */       this.optional_0_ |= 1;
/*  684 */       this.is_available_ = x;
/*  685 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getPresence()
/*      */     {
/*  690 */       return this.presence_;
/*      */     }
/*      */     public SHOW getPresenceEnum() {
/*  693 */       return SHOW.valueOf(getPresence());
/*      */     }
/*      */     public final boolean hasPresence() {
/*  696 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public PresenceResponse clearPresence() {
/*  699 */       this.optional_0_ &= -3;
/*  700 */       this.presence_ = 0;
/*  701 */       return this;
/*      */     }
/*      */     public PresenceResponse setPresence(int x) {
/*  704 */       this.optional_0_ |= 2;
/*  705 */       this.presence_ = x;
/*  706 */       return this;
/*      */     }
/*      */     public PresenceResponse setPresence(SHOW x) {
/*  709 */       if (x == null) {
/*  710 */         this.optional_0_ &= -3;
/*  711 */         this.presence_ = 0;
/*      */       } else {
/*  713 */         setPresence(x.getValue());
/*      */       }
/*  715 */       return this;
/*      */     }
/*      */ 
/*      */     public PresenceResponse mergeFrom(PresenceResponse that)
/*      */     {
/*  722 */       assert (that != this);
/*  723 */       int this_t0 = this.optional_0_;
/*  724 */       int that_t0 = that.optional_0_;
/*      */ 
/*  726 */       if ((that_t0 & 0x1) != 0) {
/*  727 */         this_t0 |= 1;
/*  728 */         this.is_available_ = that.is_available_;
/*      */       }
/*      */ 
/*  731 */       if ((that_t0 & 0x2) != 0) {
/*  732 */         this_t0 |= 2;
/*  733 */         this.presence_ = that.presence_;
/*      */       }
/*      */ 
/*  736 */       if (that.uninterpreted != null) {
/*  737 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  739 */       this.optional_0_ = this_t0;
/*  740 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(PresenceResponse that) {
/*  744 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(PresenceResponse that) {
/*  748 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(PresenceResponse that, boolean ignoreUninterpreted) {
/*  752 */       if (that == null) return false;
/*  753 */       if (that == this) return true;
/*  754 */       int this_t0 = this.optional_0_;
/*  755 */       int that_t0 = that.optional_0_;
/*  756 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  758 */       if (((this_t0 & 0x1) != 0) && 
/*  759 */         (this.is_available_ != that.is_available_)) return false;
/*      */ 
/*  762 */       if (((this_t0 & 0x2) != 0) && 
/*  763 */         (this.presence_ != that.presence_)) return false;
/*      */ 
/*  766 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  771 */       return ((that instanceof PresenceResponse)) && (equals((PresenceResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  775 */       int hash = 384658789;
/*      */ 
/*  777 */       int this_t0 = this.optional_0_;
/*  778 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? 1237 : this.is_available_ ? 1231 : -113);
/*      */ 
/*  780 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.presence_ : -113);
/*  781 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  782 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  784 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  788 */       int this_t0 = this.optional_0_;
/*      */ 
/*  790 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  797 */       int n = 2;
/*  798 */       int this_t0 = this.optional_0_;
/*  799 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/*  801 */         n += 1 + Protocol.varLongSize(this.presence_);
/*      */       }
/*      */ 
/*  804 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  811 */       int n = 13;
/*      */ 
/*  813 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  818 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  822 */       this.optional_0_ = 0;
/*  823 */       this.is_available_ = false;
/*  824 */       this.presence_ = 0;
/*  825 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public PresenceResponse newInstance() {
/*  829 */       return new PresenceResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  833 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  862 */       sink.putByte(8);
/*  863 */       sink.putBoolean(this.is_available_);
/*      */ 
/*  865 */       int this_t0 = this.optional_0_;
/*  866 */       if ((this_t0 & 0x2) != 0) {
/*  867 */         sink.putByte(16);
/*  868 */         sink.putVarLong(this.presence_);
/*      */       }
/*      */ 
/*  871 */       if (this.uninterpreted != null)
/*  872 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  877 */       boolean result = true;
/*  878 */       int this_t0 = this.optional_0_;
/*      */ 
/*  880 */       while (source.hasRemaining()) {
/*  881 */         int tt = source.getVarInt();
/*  882 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  886 */           result = false;
/*  887 */           break;
/*      */         case 8:
/*  890 */           this.is_available_ = source.getBoolean();
/*  891 */           this_t0 |= 1;
/*  892 */           break;
/*      */         case 16:
/*  895 */           this.presence_ = source.getVarInt();
/*  896 */           this_t0 |= 2;
/*  897 */           break;
/*      */         default:
/*  899 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  904 */       this.optional_0_ = this_t0;
/*  905 */       return result;
/*      */     }
/*      */ 
/*      */     public PresenceResponse getDefaultInstanceForType()
/*      */     {
/*  910 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final PresenceResponse getDefaultInstance() {
/*  914 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  962 */       if (this.uninterpreted == null) {
/*  963 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  965 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  918 */       IMMUTABLE_DEFAULT_INSTANCE = new PresenceResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.PresenceResponse clearIsAvailable()
/*      */         {
/*  926 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceResponse setIsAvailable(boolean x) {
/*  929 */           ProtocolSupport.unsupportedOperation();
/*  930 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.PresenceResponse clearPresence()
/*      */         {
/*  935 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceResponse setPresence(int x) {
/*  938 */           ProtocolSupport.unsupportedOperation();
/*  939 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.PresenceResponse mergeFrom(XMPPServicePb.PresenceResponse that) {
/*  943 */           ProtocolSupport.unsupportedOperation();
/*  944 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  947 */           ProtocolSupport.unsupportedOperation();
/*  948 */           return false;
/*      */         }
/*      */         public XMPPServicePb.PresenceResponse freeze() {
/*  951 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceResponse unfreeze() {
/*  954 */           ProtocolSupport.unsupportedOperation();
/*  955 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  958 */           return true;
/*      */         }
/*      */       };
/*  971 */       text = new String[3];
/*      */ 
/*  973 */       text[0] = "ErrorCode";
/*  974 */       text[1] = "is_available";
/*  975 */       text[2] = "presence";
/*      */ 
/*  978 */       types = new int[3];
/*      */ 
/*  980 */       Arrays.fill(types, 6);
/*  981 */       types[0] = 0;
/*  982 */       types[1] = 0;
/*  983 */       types[2] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  837 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.PresenceResponse.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("is_available", "is_available", 1, 0, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("presence", "presence", 2, 1, ProtocolType.Presence.OPTIONAL, XMPPServicePb.PresenceResponse.SHOW.class) });
/*      */     }
/*      */ 
/*      */     public static enum SHOW
/*      */       implements ProtocolMessageEnum
/*      */     {
/*  644 */       NORMAL(0), 
/*  645 */       AWAY(1), 
/*  646 */       DO_NOT_DISTURB(2), 
/*  647 */       CHAT(3), 
/*  648 */       EXTENDED_AWAY(4);
/*      */ 
/*      */       public static final SHOW SHOW_MIN;
/*      */       public static final SHOW SHOW_MAX;
/*      */       private final int value;
/*      */ 
/*  653 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static SHOW valueOf(int value) {
/*  656 */         switch (value) { case 0:
/*  657 */           return NORMAL;
/*      */         case 1:
/*  658 */           return AWAY;
/*      */         case 2:
/*  659 */           return DO_NOT_DISTURB;
/*      */         case 3:
/*  660 */           return CHAT;
/*      */         case 4:
/*  661 */           return EXTENDED_AWAY;
/*      */         }
/*  663 */         return null;
/*      */       }
/*      */ 
/*      */       private SHOW(int v) {
/*  667 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  650 */         SHOW_MIN = NORMAL;
/*  651 */         SHOW_MAX = EXTENDED_AWAY;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PresenceRequest extends ProtocolMessage<PresenceRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  266 */     private byte[] jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  267 */     private byte[] from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final PresenceRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kjid = 1;
/*      */     public static final int kfrom_jid = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getJidAsBytes()
/*      */     {
/*  273 */       return this.jid_;
/*      */     }
/*      */     public final boolean hasJid() {
/*  276 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public PresenceRequest clearJid() {
/*  279 */       this.optional_0_ &= -2;
/*  280 */       this.jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  281 */       return this;
/*      */     }
/*      */     public PresenceRequest setJidAsBytes(byte[] x) {
/*  284 */       this.optional_0_ |= 1;
/*  285 */       this.jid_ = x;
/*  286 */       return this;
/*      */     }
/*      */     public final String getJid() {
/*  289 */       return ProtocolSupport.toStringUtf8(this.jid_);
/*      */     }
/*      */     public PresenceRequest setJid(String v) {
/*  292 */       if (v == null) throw new NullPointerException();
/*  293 */       this.optional_0_ |= 1;
/*  294 */       this.jid_ = ProtocolSupport.toBytesUtf8(v);
/*  295 */       return this;
/*      */     }
/*      */     public final String getJid(Charset cs) {
/*  298 */       return ProtocolSupport.toString(this.jid_, cs);
/*      */     }
/*      */     public PresenceRequest setJid(String v, Charset cs) {
/*  301 */       if (v == null) throw new NullPointerException();
/*  302 */       this.optional_0_ |= 1;
/*  303 */       this.jid_ = ProtocolSupport.toBytes(v, cs);
/*  304 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFromJidAsBytes()
/*      */     {
/*  309 */       return this.from_jid_;
/*      */     }
/*      */     public final boolean hasFromJid() {
/*  312 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public PresenceRequest clearFromJid() {
/*  315 */       this.optional_0_ &= -3;
/*  316 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  317 */       return this;
/*      */     }
/*      */     public PresenceRequest setFromJidAsBytes(byte[] x) {
/*  320 */       this.optional_0_ |= 2;
/*  321 */       this.from_jid_ = x;
/*  322 */       return this;
/*      */     }
/*      */     public final String getFromJid() {
/*  325 */       return ProtocolSupport.toStringUtf8(this.from_jid_);
/*      */     }
/*      */     public PresenceRequest setFromJid(String v) {
/*  328 */       if (v == null) throw new NullPointerException();
/*  329 */       this.optional_0_ |= 2;
/*  330 */       this.from_jid_ = ProtocolSupport.toBytesUtf8(v);
/*  331 */       return this;
/*      */     }
/*      */     public final String getFromJid(Charset cs) {
/*  334 */       return ProtocolSupport.toString(this.from_jid_, cs);
/*      */     }
/*      */     public PresenceRequest setFromJid(String v, Charset cs) {
/*  337 */       if (v == null) throw new NullPointerException();
/*  338 */       this.optional_0_ |= 2;
/*  339 */       this.from_jid_ = ProtocolSupport.toBytes(v, cs);
/*  340 */       return this;
/*      */     }
/*      */ 
/*      */     public PresenceRequest mergeFrom(PresenceRequest that)
/*      */     {
/*  347 */       assert (that != this);
/*  348 */       int this_t0 = this.optional_0_;
/*  349 */       int that_t0 = that.optional_0_;
/*      */ 
/*  351 */       if ((that_t0 & 0x1) != 0) {
/*  352 */         this_t0 |= 1;
/*  353 */         this.jid_ = that.jid_;
/*      */       }
/*      */ 
/*  356 */       if ((that_t0 & 0x2) != 0) {
/*  357 */         this_t0 |= 2;
/*  358 */         this.from_jid_ = that.from_jid_;
/*      */       }
/*      */ 
/*  361 */       if (that.uninterpreted != null) {
/*  362 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  364 */       this.optional_0_ = this_t0;
/*  365 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(PresenceRequest that) {
/*  369 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(PresenceRequest that) {
/*  373 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(PresenceRequest that, boolean ignoreUninterpreted) {
/*  377 */       if (that == null) return false;
/*  378 */       if (that == this) return true;
/*  379 */       int this_t0 = this.optional_0_;
/*  380 */       int that_t0 = that.optional_0_;
/*  381 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  383 */       if (((this_t0 & 0x1) != 0) && 
/*  384 */         (!Arrays.equals(this.jid_, that.jid_))) return false;
/*      */ 
/*  387 */       if (((this_t0 & 0x2) != 0) && 
/*  388 */         (!Arrays.equals(this.from_jid_, that.from_jid_))) return false;
/*      */ 
/*  391 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  396 */       return ((that instanceof PresenceRequest)) && (equals((PresenceRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  400 */       int hash = 1072279583;
/*      */ 
/*  402 */       int this_t0 = this.optional_0_;
/*  403 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.jid_) : -113);
/*      */ 
/*  405 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.from_jid_) : -113);
/*  406 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  407 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  409 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  413 */       int this_t0 = this.optional_0_;
/*      */ 
/*  415 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  422 */       int n = 1 + Protocol.stringSize(this.jid_.length);
/*  423 */       int this_t0 = this.optional_0_;
/*  424 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/*  426 */         n += 1 + Protocol.stringSize(this.from_jid_.length);
/*      */       }
/*      */ 
/*  429 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  435 */       int n = 6 + this.jid_.length;
/*  436 */       int this_t0 = this.optional_0_;
/*  437 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/*  439 */         n += 6 + this.from_jid_.length;
/*      */       }
/*      */ 
/*  442 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  447 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  451 */       this.optional_0_ = 0;
/*  452 */       this.jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  453 */       this.from_jid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  454 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public PresenceRequest newInstance() {
/*  458 */       return new PresenceRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  462 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  483 */       sink.putByte(10);
/*  484 */       sink.putPrefixedData(this.jid_);
/*      */ 
/*  486 */       int this_t0 = this.optional_0_;
/*  487 */       if ((this_t0 & 0x2) != 0) {
/*  488 */         sink.putByte(18);
/*  489 */         sink.putPrefixedData(this.from_jid_);
/*      */       }
/*      */ 
/*  492 */       if (this.uninterpreted != null)
/*  493 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  498 */       boolean result = true;
/*  499 */       int this_t0 = this.optional_0_;
/*      */ 
/*  501 */       while (source.hasRemaining()) {
/*  502 */         int tt = source.getVarInt();
/*  503 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  507 */           result = false;
/*  508 */           break;
/*      */         case 10:
/*  511 */           this.jid_ = source.getPrefixedData();
/*  512 */           this_t0 |= 1;
/*  513 */           break;
/*      */         case 18:
/*  516 */           this.from_jid_ = source.getPrefixedData();
/*  517 */           this_t0 |= 2;
/*  518 */           break;
/*      */         default:
/*  520 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  525 */       this.optional_0_ = this_t0;
/*  526 */       return result;
/*      */     }
/*      */ 
/*      */     public PresenceRequest getDefaultInstanceForType()
/*      */     {
/*  531 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final PresenceRequest getDefaultInstance() {
/*  535 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public PresenceRequest freeze()
/*      */     {
/*  600 */       this.jid_ = ProtocolSupport.freezeString(this.jid_);
/*  601 */       this.from_jid_ = ProtocolSupport.freezeString(this.from_jid_);
/*  602 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  605 */       if (this.uninterpreted == null) {
/*  606 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  608 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  539 */       IMMUTABLE_DEFAULT_INSTANCE = new PresenceRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.PresenceRequest clearJid()
/*      */         {
/*  547 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest setJidAsBytes(byte[] x) {
/*  550 */           ProtocolSupport.unsupportedOperation();
/*  551 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest setJid(String v) {
/*  554 */           ProtocolSupport.unsupportedOperation();
/*  555 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest setJid(String v, Charset cs) {
/*  558 */           ProtocolSupport.unsupportedOperation();
/*  559 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.PresenceRequest clearFromJid()
/*      */         {
/*  564 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest setFromJidAsBytes(byte[] x) {
/*  567 */           ProtocolSupport.unsupportedOperation();
/*  568 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest setFromJid(String v) {
/*  571 */           ProtocolSupport.unsupportedOperation();
/*  572 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest setFromJid(String v, Charset cs) {
/*  575 */           ProtocolSupport.unsupportedOperation();
/*  576 */           return this;
/*      */         }
/*      */ 
/*      */         public XMPPServicePb.PresenceRequest mergeFrom(XMPPServicePb.PresenceRequest that) {
/*  580 */           ProtocolSupport.unsupportedOperation();
/*  581 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  584 */           ProtocolSupport.unsupportedOperation();
/*  585 */           return false;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest freeze() {
/*  588 */           return this;
/*      */         }
/*      */         public XMPPServicePb.PresenceRequest unfreeze() {
/*  591 */           ProtocolSupport.unsupportedOperation();
/*  592 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  595 */           return true;
/*      */         }
/*      */       };
/*  614 */       text = new String[3];
/*      */ 
/*  616 */       text[0] = "ErrorCode";
/*  617 */       text[1] = "jid";
/*  618 */       text[2] = "from_jid";
/*      */ 
/*  621 */       types = new int[3];
/*      */ 
/*  623 */       Arrays.fill(types, 6);
/*  624 */       types[0] = 0;
/*  625 */       types[1] = 2;
/*  626 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  466 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.PresenceRequest.class, "Z&apphosting/api/xmpp/xmpp_service.proto\n\032apphosting.PresenceRequest\023\032\003jid \001(\0020\t8\002\024\023\032\bfrom_jid \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("jid", "jid", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("from_jid", "from_jid", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class XmppServiceError extends ProtocolMessage<XmppServiceError>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final XmppServiceError IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public XmppServiceError mergeFrom(XmppServiceError that)
/*      */     {
/*   85 */       assert (that != this);
/*      */ 
/*   87 */       if (that.uninterpreted != null) {
/*   88 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   90 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(XmppServiceError that) {
/*   94 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppServiceError that) {
/*   98 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(XmppServiceError that, boolean ignoreUninterpreted) {
/*  102 */       if (that == null) return false;
/*  103 */       if (that == this) return true;
/*      */ 
/*  105 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  110 */       return ((that instanceof XmppServiceError)) && (equals((XmppServiceError)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  114 */       int hash = -2138676254;
/*  115 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  116 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  118 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  122 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  126 */       int n = 0;
/*      */ 
/*  128 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  133 */       int n = 0;
/*      */ 
/*  135 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  140 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  144 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public XmppServiceError newInstance() {
/*  148 */       return new XmppServiceError();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  152 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  178 */       if (this.uninterpreted != null)
/*  179 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  184 */       boolean result = true;
/*      */ 
/*  186 */       while (source.hasRemaining()) {
/*  187 */         int tt = source.getVarInt();
/*  188 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  192 */           result = false;
/*  193 */           break;
/*      */         default:
/*  195 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  200 */       return result;
/*      */     }
/*      */ 
/*      */     public XmppServiceError getDefaultInstanceForType()
/*      */     {
/*  205 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final XmppServiceError getDefaultInstance() {
/*  209 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  239 */       if (this.uninterpreted == null) {
/*  240 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  242 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  213 */       IMMUTABLE_DEFAULT_INSTANCE = new XmppServiceError()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public XMPPServicePb.XmppServiceError mergeFrom(XMPPServicePb.XmppServiceError that)
/*      */         {
/*  220 */           ProtocolSupport.unsupportedOperation();
/*  221 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  224 */           ProtocolSupport.unsupportedOperation();
/*  225 */           return false;
/*      */         }
/*      */         public XMPPServicePb.XmppServiceError freeze() {
/*  228 */           return this;
/*      */         }
/*      */         public XMPPServicePb.XmppServiceError unfreeze() {
/*  231 */           ProtocolSupport.unsupportedOperation();
/*  232 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  235 */           return true;
/*      */         }
/*      */       };
/*  246 */       text = new String[1];
/*      */ 
/*  248 */       text[0] = "ErrorCode";
/*      */ 
/*  251 */       types = new int[1];
/*      */ 
/*  253 */       Arrays.fill(types, 6);
/*  254 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  156 */       private static final ProtocolType protocolType = new ProtocolType(XMPPServicePb.XmppServiceError.class, "Z&apphosting/api/xmpp/xmpp_service.proto\n\033apphosting.XmppServiceErrorsz\tErrorCode\001\001\021UNSPECIFIED_ERROR\001\001\001\001\001\013INVALID_JID\001\002\001\001\001\007NO_BODY\001\003\001\001\001\013INVALID_XML\001\004\001\001\001\fINVALID_TYPE\001\005\001\001\001\fINVALID_SHOW\001\006\001\001\001\021EXCEEDED_MAX_SIZE\001\007\001t", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   51 */       UNSPECIFIED_ERROR(1), 
/*   52 */       INVALID_JID(2), 
/*   53 */       NO_BODY(3), 
/*   54 */       INVALID_XML(4), 
/*   55 */       INVALID_TYPE(5), 
/*   56 */       INVALID_SHOW(6), 
/*   57 */       EXCEEDED_MAX_SIZE(7);
/*      */ 
/*      */       public static final ErrorCode ErrorCode_MIN;
/*      */       public static final ErrorCode ErrorCode_MAX;
/*      */       private final int value;
/*      */ 
/*   62 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   65 */         switch (value) { case 1:
/*   66 */           return UNSPECIFIED_ERROR;
/*      */         case 2:
/*   67 */           return INVALID_JID;
/*      */         case 3:
/*   68 */           return NO_BODY;
/*      */         case 4:
/*   69 */           return INVALID_XML;
/*      */         case 5:
/*   70 */           return INVALID_TYPE;
/*      */         case 6:
/*   71 */           return INVALID_SHOW;
/*      */         case 7:
/*   72 */           return EXCEEDED_MAX_SIZE;
/*      */         }
/*   74 */         return null;
/*      */       }
/*      */ 
/*      */       private ErrorCode(int v) {
/*   78 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   59 */         ErrorCode_MIN = UNSPECIFIED_ERROR;
/*   60 */         ErrorCode_MAX = EXCEEDED_MAX_SIZE;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.XMPPServicePb
 * JD-Core Version:    0.6.0
 */