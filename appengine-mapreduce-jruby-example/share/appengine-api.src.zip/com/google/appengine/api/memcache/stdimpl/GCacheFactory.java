/*    */ package com.google.appengine.api.memcache.stdimpl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.cache.Cache;
/*    */ import javax.cache.CacheFactory;
/*    */ 
/*    */ public class GCacheFactory
/*    */   implements CacheFactory
/*    */ {
/*    */   public static final int EXPIRATION_DELTA = 0;
/*    */   public static final int EXPIRATION_DELTA_MILLIS = 1;
/*    */   public static final int EXPIRATION = 2;
/*    */   public static final int SET_POLICY = 3;
/*    */   public static final int MEMCACHE_SERVICE = 4;
/*    */   public static final int NAMESPACE = 5;
/*    */ 
/*    */   public Cache createCache(Map map)
/*    */   {
/* 64 */     return new GCache(map);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.stdimpl.GCacheFactory
 * JD-Core Version:    0.6.0
 */