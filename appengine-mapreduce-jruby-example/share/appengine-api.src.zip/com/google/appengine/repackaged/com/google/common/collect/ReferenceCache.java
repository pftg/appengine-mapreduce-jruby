/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.ReferenceType;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ @GoogleInternal
/*     */ public abstract class ReferenceCache<K, V> extends ForwardingConcurrentMap<K, V>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 0L;
/*     */   private final ConcurrentMap<K, V> map;
/*     */ 
/*     */   @Deprecated
/*     */   public ReferenceCache(ReferenceType keyReferenceType, ReferenceType valueReferenceType)
/*     */   {
/*  67 */     MapMaker maker = new MapMaker();
/*  68 */     switch (2.$SwitchMap$com$google$common$base$ReferenceType[keyReferenceType.ordinal()]) { case 1:
/*  69 */       throw new IllegalArgumentException("Phantom references are not supported.");
/*     */     case 2:
/*  71 */       maker.softKeys(); break;
/*     */     case 3:
/*  72 */       maker.weakKeys();
/*     */     }
/*  74 */     switch (2.$SwitchMap$com$google$common$base$ReferenceType[valueReferenceType.ordinal()]) { case 1:
/*  75 */       throw new IllegalArgumentException("Phantom references are not supported.");
/*     */     case 2:
/*  77 */       maker.softValues(); break;
/*     */     case 3:
/*  78 */       maker.weakValues();
/*     */     }
/*  80 */     this.map = maker.makeComputingMap(new FunctionAdapter(null));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ReferenceCache()
/*     */   {
/*  90 */     this.map = new MapMaker().makeComputingMap(new FunctionAdapter(null));
/*     */   }
/*     */ 
/*     */   protected ConcurrentMap<K, V> delegate() {
/*  94 */     return this.map;
/*     */   }
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/*     */     try
/*     */     {
/* 112 */       return this.map.get(key);
/*     */     }
/*     */     catch (NullOutputException e) {
/* 115 */       return null;
/*     */     } catch (ComputationException e) {
/* 117 */       UncheckedThrower.throwAsUnchecked(e.getCause());
/* 118 */     }throw new AssertionError();
/*     */   }
/*     */ 
/*     */   protected abstract V create(K paramK);
/*     */ 
/*     */   @Deprecated
/*     */   public static <K, V> ReferenceCache<K, V> of(ReferenceType keyReferenceType, ReferenceType valueReferenceType, Function<? super K, ? extends V> function)
/*     */   {
/* 157 */     Preconditions.checkNotNull(function);
/* 158 */     return new ReferenceCache(keyReferenceType, valueReferenceType, function) { private static final long serialVersionUID = 0L;
/*     */ 
/* 161 */       protected V create(K key) { return this.val$function.apply(key); }  } ;
/*     */   }
/*     */   private class FunctionAdapter implements Function<K, V>, Serializable {
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private FunctionAdapter() {
/*     */     }
/* 169 */     public V apply(K key) { return ReferenceCache.this.create(key);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ReferenceCache
 * JD-Core Version:    0.6.0
 */