/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Queue;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingQueue<E> extends ForwardingCollection<E>
/*    */   implements Queue<E>
/*    */ {
/*    */   protected abstract Queue<E> delegate();
/*    */ 
/*    */   public boolean offer(E o)
/*    */   {
/* 42 */     return delegate().offer(o);
/*    */   }
/*    */ 
/*    */   public E poll() {
/* 46 */     return delegate().poll();
/*    */   }
/*    */ 
/*    */   public E remove() {
/* 50 */     return delegate().remove();
/*    */   }
/*    */ 
/*    */   public E peek() {
/* 54 */     return delegate().peek();
/*    */   }
/*    */ 
/*    */   public E element() {
/* 58 */     return delegate().element();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingQueue
 * JD-Core Version:    0.6.0
 */