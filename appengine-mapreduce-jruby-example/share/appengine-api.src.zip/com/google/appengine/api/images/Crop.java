/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ final class Crop extends Transform
/*    */ {
/*    */   private final float leftX;
/*    */   private final float topY;
/*    */   private final float rightX;
/*    */   private final float bottomY;
/*    */ 
/*    */   Crop(float leftX, float topY, float rightX, float bottomY)
/*    */   {
/* 27 */     checkCropArgument(leftX);
/* 28 */     checkCropArgument(topY);
/* 29 */     checkCropArgument(rightX);
/* 30 */     checkCropArgument(bottomY);
/* 31 */     if (leftX >= rightX) {
/* 32 */       throw new IllegalArgumentException("leftX must be < rightX");
/*    */     }
/* 34 */     if (topY >= bottomY) {
/* 35 */       throw new IllegalArgumentException("topY must be < bottomY");
/*    */     }
/* 37 */     this.leftX = leftX;
/* 38 */     this.topY = topY;
/* 39 */     this.rightX = rightX;
/* 40 */     this.bottomY = bottomY;
/*    */   }
/*    */ 
/*    */   void apply(ImagesServicePb.ImagesTransformRequest request)
/*    */   {
/* 46 */     ImagesServicePb.Transform transform = request.addTransform();
/* 47 */     transform.setCropLeftX(this.leftX);
/* 48 */     transform.setCropTopY(this.topY);
/* 49 */     transform.setCropRightX(this.rightX);
/* 50 */     transform.setCropBottomY(this.bottomY);
/*    */   }
/*    */ 
/*    */   private void checkCropArgument(float arg)
/*    */   {
/* 58 */     if (arg < 0.0D) {
/* 59 */       throw new IllegalArgumentException("Crop arguments must be >= 0");
/*    */     }
/* 61 */     if (arg > 1.0D)
/* 62 */       throw new IllegalArgumentException("Crop arguments must be <= 1");
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.Crop
 * JD-Core Version:    0.6.0
 */