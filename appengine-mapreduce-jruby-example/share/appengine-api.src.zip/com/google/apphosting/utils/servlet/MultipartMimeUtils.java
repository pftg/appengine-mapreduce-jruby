/*     */ package com.google.apphosting.utils.servlet;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.io.ByteStreams;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.ContentDisposition;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class MultipartMimeUtils
/*     */ {
/*     */   public static MimeMultipart parseMultipartRequest(HttpServletRequest req)
/*     */     throws IOException, MessagingException
/*     */   {
/*  38 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  39 */     ByteStreams.copy(req.getInputStream(), baos);
/*     */ 
/*  41 */     return new MimeMultipart(createDataSource(req.getContentType(), baos.toByteArray()));
/*     */   }
/*     */ 
/*     */   public static DataSource createDataSource(String contentType, byte[] data)
/*     */   {
/*  48 */     return new StaticDataSource(contentType, data);
/*     */   }
/*     */ 
/*     */   public static String getFieldName(BodyPart part)
/*     */     throws MessagingException
/*     */   {
/*  56 */     String[] values = part.getHeader("Content-Disposition");
/*  57 */     String name = null;
/*  58 */     if ((values != null) && (values.length > 0)) {
/*  59 */       name = new ContentDisposition(values[0]).getParameter("name");
/*     */     }
/*  61 */     return name != null ? name : "unknown";
/*     */   }
/*     */ 
/*     */   public static String getTextContent(BodyPart part)
/*     */     throws MessagingException, IOException
/*     */   {
/*  69 */     ContentType contentType = new ContentType(part.getContentType());
/*  70 */     String charset = contentType.getParameter("charset");
/*  71 */     if (charset == null)
/*     */     {
/*  75 */       charset = "ISO-8859-1";
/*     */     }
/*     */ 
/*  78 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  79 */     ByteStreams.copy(part.getInputStream(), baos);
/*     */     try {
/*  81 */       return new String(baos.toByteArray(), charset); } catch (UnsupportedEncodingException ex) {
/*     */     }
/*  83 */     return new String(baos.toByteArray());
/*     */   }
/*     */ 
/*     */   private static class StaticDataSource
/*     */     implements DataSource
/*     */   {
/*     */     private final String contentType;
/*     */     private final byte[] bytes;
/*     */ 
/*     */     public StaticDataSource(String contentType, byte[] bytes)
/*     */     {
/*  96 */       this.contentType = contentType;
/*  97 */       this.bytes = bytes;
/*     */     }
/*     */ 
/*     */     public String getContentType() {
/* 101 */       return this.contentType;
/*     */     }
/*     */ 
/*     */     public InputStream getInputStream() {
/* 105 */       return new ByteArrayInputStream(this.bytes);
/*     */     }
/*     */ 
/*     */     public OutputStream getOutputStream() {
/* 109 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 113 */       return "request";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.utils.servlet.MultipartMimeUtils
 * JD-Core Version:    0.6.0
 */