/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Random;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class Randoms
/*     */ {
/*  37 */   private static final Random RANDOM = new ReadOnlyRandom(null);
/*  38 */   private static final SecureRandom SECURE_RANDOM = new SecureRandom();
/*     */ 
/*     */   public static SecureRandom secureRandom()
/*     */   {
/*  50 */     return SECURE_RANDOM;
/*     */   }
/*     */ 
/*     */   public static SecureRandom secureRandom(byte[] seed)
/*     */   {
/*  68 */     return new SecureRandom(seed);
/*     */   }
/*     */ 
/*     */   public static Random insecureRandom()
/*     */   {
/*  84 */     return RANDOM;
/*     */   }
/*     */ 
/*     */   public static Random insecureRandom(long seed)
/*     */   {
/* 102 */     return new Random(seed);
/*     */   }
/*     */ 
/*     */   private static class ReadOnlyRandom extends Random
/*     */   {
/*     */     private static final long serialVersionUID = 898001275432099254L;
/* 111 */     private boolean initializationComplete = false;
/*     */ 
/*     */     private ReadOnlyRandom()
/*     */     {
/* 115 */       this.initializationComplete = true;
/*     */     }
/*     */ 
/*     */     public void setSeed(long seed)
/*     */     {
/* 120 */       if (this.initializationComplete) {
/* 121 */         throw new UnsupportedOperationException("Setting the seed on the shared Random object is not permitted");
/*     */       }
/*     */ 
/* 124 */       super.setSeed(seed);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Randoms
 * JD-Core Version:    0.6.0
 */