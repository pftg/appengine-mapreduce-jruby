/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ @GwtCompatible(emulated=true)
/*     */ class Platform
/*     */ {
/*  34 */   private static final Logger logger = Logger.getLogger(Platform.class.getCanonicalName());
/*     */ 
/*     */   static <T> T[] clone(T[] array)
/*     */   {
/*  42 */     return (Object[])array.clone();
/*     */   }
/*     */ 
/*     */   static void unsafeArrayCopy(Object[] src, int srcPos, Object[] dest, int destPos, int length)
/*     */   {
/*  59 */     System.arraycopy(src, srcPos, dest, destPos, length);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("Array.newInstance(Class, int)")
/*     */   static <T> T[] newArray(Class<T> type, int length)
/*     */   {
/*  71 */     return (Object[])(Object[])Array.newInstance(type, length);
/*     */   }
/*     */ 
/*     */   static <T> T[] newArray(T[] reference, int length)
/*     */   {
/*  82 */     Class type = reference.getClass().getComponentType();
/*     */ 
/*  87 */     Object[] result = (Object[])(Object[])Array.newInstance(type, length);
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   @GwtIncompatible("java.util.logging.Logger")
/*     */   static void logWarning(String message, Throwable exception)
/*     */   {
/* 100 */     logger.log(Level.WARNING, message, exception);
/*     */   }
/*     */ 
/*     */   static MapMaker tryWeakKeys(MapMaker mapMaker)
/*     */   {
/* 110 */     return mapMaker.weakKeys();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Platform
 * JD-Core Version:    0.6.0
 */