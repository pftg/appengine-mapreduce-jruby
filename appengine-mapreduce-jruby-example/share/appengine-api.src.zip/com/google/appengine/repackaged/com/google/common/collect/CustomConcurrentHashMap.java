/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Equivalence;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Equivalences;
/*      */ import com.google.appengine.repackaged.com.google.common.base.FinalizableReferenceQueue;
/*      */ import com.google.appengine.repackaged.com.google.common.base.FinalizableSoftReference;
/*      */ import com.google.appengine.repackaged.com.google.common.base.FinalizableWeakReference;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import javax.annotation.Nullable;
/*      */ import javax.annotation.concurrent.GuardedBy;
/*      */ 
/*      */ class CustomConcurrentHashMap<K, V> extends AbstractMap<K, V>
/*      */   implements ConcurrentMap<K, V>, Serializable
/*      */ {
/*      */   static final int MAXIMUM_CAPACITY = 1073741824;
/*      */   static final int MAX_SEGMENTS = 65536;
/*      */   static final int RETRIES_BEFORE_LOCK = 2;
/*      */   final transient int segmentMask;
/*      */   final transient int segmentShift;
/*      */   final transient CustomConcurrentHashMap<K, V>[].Segment segments;
/*      */   final Equivalence<Object> keyEquivalence;
/*      */   final Equivalence<Object> valueEquivalence;
/*      */   final Strength keyStrength;
/*      */   final Strength valueStrength;
/*      */   final long expirationNanos;
/*      */   final boolean expires;
/*      */   final int maximumSize;
/*      */   final boolean evicts;
/*      */   final int concurrencyLevel;
/*      */   final transient EntryFactory entryFactory;
/*  523 */   static final ValueReference<Object, Object> UNSET = new ValueReference()
/*      */   {
/*      */     public Object get() {
/*  526 */       return null;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<Object, Object> copyFor(CustomConcurrentHashMap.ReferenceEntry<Object, Object> entry) {
/*  530 */       throw new AssertionError();
/*      */     }
/*      */     public Object waitForValue() {
/*  533 */       throw new AssertionError();
/*      */     }
/*  523 */   };
/*      */   Set<K> keySet;
/*      */   Collection<V> values;
/*      */   Set<Map.Entry<K, V>> entrySet;
/*      */   private static final long serialVersionUID = 2L;
/*      */ 
/*      */   CustomConcurrentHashMap(MapMaker builder)
/*      */   {
/*  152 */     this.keyStrength = builder.getKeyStrength();
/*  153 */     this.valueStrength = builder.getValueStrength();
/*      */ 
/*  155 */     this.keyEquivalence = builder.getKeyEquivalence();
/*  156 */     this.valueEquivalence = builder.getValueEquivalence();
/*      */ 
/*  158 */     this.expirationNanos = builder.getExpirationNanos();
/*  159 */     this.maximumSize = builder.maximumSize;
/*      */ 
/*  161 */     this.evicts = (this.maximumSize != -1);
/*  162 */     this.expires = (this.expirationNanos > 0L);
/*      */ 
/*  164 */     this.entryFactory = EntryFactory.getFactory(this.keyStrength, this.expires, this.evicts);
/*      */ 
/*  166 */     this.concurrencyLevel = filterConcurrencyLevel(builder.getConcurrencyLevel());
/*      */ 
/*  169 */     int initialCapacity = builder.getInitialCapacity();
/*  170 */     if (initialCapacity > 1073741824) {
/*  171 */       initialCapacity = 1073741824;
/*      */     }
/*      */ 
/*  175 */     int segmentShift = 0;
/*  176 */     int segmentCount = 1;
/*  177 */     while (segmentCount < this.concurrencyLevel) {
/*  178 */       segmentShift++;
/*  179 */       segmentCount <<= 1;
/*      */     }
/*  181 */     this.segmentShift = (32 - segmentShift);
/*  182 */     this.segmentMask = (segmentCount - 1);
/*      */ 
/*  184 */     this.segments = newSegmentArray(segmentCount);
/*      */ 
/*  186 */     int segmentCapacity = initialCapacity / segmentCount;
/*  187 */     if (segmentCapacity * segmentCount < initialCapacity) {
/*  188 */       segmentCapacity++;
/*      */     }
/*      */ 
/*  191 */     int segmentSize = 1;
/*  192 */     while (segmentSize < segmentCapacity) {
/*  193 */       segmentSize <<= 1;
/*      */     }
/*      */ 
/*  196 */     if (this.evicts)
/*      */     {
/*  198 */       int maximumSegmentSize = this.maximumSize / segmentCount + 1;
/*  199 */       int remainder = this.maximumSize % segmentCount;
/*  200 */       for (int i = 0; i < this.segments.length; i++) {
/*  201 */         if (i == remainder) {
/*  202 */           maximumSegmentSize--;
/*      */         }
/*  204 */         this.segments[i] = new Segment(segmentSize, maximumSegmentSize);
/*      */       }
/*      */     } else {
/*  207 */       for (int i = 0; i < this.segments.length; i++)
/*  208 */         this.segments[i] = new Segment(segmentSize, -1);
/*      */     }
/*      */   }
/*      */ 
/*      */   static int filterConcurrencyLevel(int concurrenyLevel)
/*      */   {
/*  219 */     return Math.min(concurrenyLevel, 65536);
/*      */   }
/*      */ 
/*      */   private static <K, V> ValueReference<K, V> unset()
/*      */   {
/*  543 */     return UNSET;
/*      */   }
/*      */ 
/*      */   private static int rehash(int h)
/*      */   {
/* 1176 */     h += (h << 15 ^ 0xFFFFCD7D);
/* 1177 */     h ^= h >>> 10;
/* 1178 */     h += (h << 3);
/* 1179 */     h ^= h >>> 6;
/* 1180 */     h += (h << 2) + (h << 14);
/* 1181 */     return h ^ h >>> 16;
/*      */   }
/*      */ 
/*      */   void setValueReference(ReferenceEntry<K, V> entry, ValueReference<K, V> valueReference)
/*      */   {
/* 1189 */     entry.setValueReference(valueReference);
/*      */   }
/*      */ 
/*      */   @GuardedBy("Segment.this")
/*      */   ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext) {
/* 1195 */     ValueReference valueReference = original.getValueReference();
/* 1196 */     ReferenceEntry newEntry = this.entryFactory.copyEntry(this, original, newNext);
/*      */ 
/* 1198 */     newEntry.setValueReference(valueReference.copyFor(newEntry));
/* 1199 */     return newEntry;
/*      */   }
/*      */ 
/*      */   int hash(Object key)
/*      */   {
/* 1205 */     int h = this.keyEquivalence.hash(Preconditions.checkNotNull(key));
/* 1206 */     return rehash(h);
/*      */   }
/*      */ 
/*      */   boolean reclaimValue(ReferenceEntry<K, V> entry) {
/* 1210 */     int hash = entry.getHash();
/* 1211 */     return segmentFor(hash).reclaimValue(entry, hash);
/*      */   }
/*      */ 
/*      */   boolean removeEntry(ReferenceEntry<K, V> entry) {
/* 1215 */     int hash = entry.getHash();
/* 1216 */     return segmentFor(hash).removeEntry(entry, hash);
/*      */   }
/*      */   @GuardedBy("Segment.this")
/*      */   static void connectExpirable(Expirable previous, Expirable next) {
/* 1221 */     previous.setNextExpirable(next);
/* 1222 */     next.setPreviousExpirable(previous);
/*      */   }
/*      */   @GuardedBy("Segment.this")
/*      */   static void nullifyExpirable(Expirable nulled) {
/* 1227 */     nulled.setNextExpirable(NullExpirable.INSTANCE);
/* 1228 */     nulled.setPreviousExpirable(NullExpirable.INSTANCE);
/*      */   }
/*      */ 
/*      */   boolean isExpired(ReferenceEntry<K, V> entry)
/*      */   {
/* 1235 */     return isExpired((Expirable)entry, System.nanoTime());
/*      */   }
/*      */ 
/*      */   boolean isExpired(Expirable expirable, long now)
/*      */   {
/* 1243 */     return now - expirable.getWriteTime() > this.expirationNanos;
/*      */   }
/*      */ 
/*      */   V getUnexpiredValue(ReferenceEntry<K, V> e)
/*      */   {
/* 1253 */     Object value = e.getValueReference().get();
/* 1254 */     return (this.expires) && (isExpired(e)) ? null : value;
/*      */   }
/*      */ 
/*      */   final CustomConcurrentHashMap<K, V>[].Segment newSegmentArray(int ssize)
/*      */   {
/* 1264 */     return (Segment[])(Segment[])Array.newInstance(Segment.class, ssize);
/*      */   }
/*      */ 
/*      */   CustomConcurrentHashMap<K, V>.Segment segmentFor(int hash)
/*      */   {
/* 1277 */     return this.segments[(hash >>> this.segmentShift & this.segmentMask)];
/*      */   }
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/* 1929 */     Segment[] segments = this.segments;
/*      */ 
/* 1939 */     int[] mc = new int[segments.length];
/* 1940 */     int mcsum = 0;
/* 1941 */     for (int i = 0; i < segments.length; i++) {
/* 1942 */       if (segments[i].count != 0) {
/* 1943 */         return false;
/*      */       }
/* 1945 */       mcsum += (mc[i] = segments[i].modCount);
/*      */     }
/*      */ 
/* 1951 */     if (mcsum != 0) {
/* 1952 */       for (int i = 0; i < segments.length; i++) {
/* 1953 */         if ((segments[i].count != 0) || (mc[i] != segments[i].modCount))
/*      */         {
/* 1955 */           return false;
/*      */         }
/*      */       }
/*      */     }
/* 1959 */     return true;
/*      */   }
/*      */ 
/*      */   public int size() {
/* 1963 */     Segment[] segments = this.segments;
/* 1964 */     long sum = 0L;
/* 1965 */     long check = 0L;
/* 1966 */     int[] mc = new int[segments.length];
/*      */ 
/* 1969 */     for (int k = 0; k < 2; k++) {
/* 1970 */       check = 0L;
/* 1971 */       sum = 0L;
/* 1972 */       int mcsum = 0;
/* 1973 */       for (int i = 0; i < segments.length; i++) {
/* 1974 */         sum += segments[i].count;
/* 1975 */         mcsum += (mc[i] = segments[i].modCount);
/*      */       }
/* 1977 */       if (mcsum != 0) {
/* 1978 */         for (int i = 0; i < segments.length; i++) {
/* 1979 */           check += segments[i].count;
/* 1980 */           if (mc[i] != segments[i].modCount) {
/* 1981 */             check = -1L;
/* 1982 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1986 */       if (check == sum) {
/*      */         break;
/*      */       }
/*      */     }
/* 1990 */     if (check != sum) {
/* 1991 */       sum = 0L;
/* 1992 */       for (Segment segment : segments) {
/* 1993 */         segment.lock();
/*      */       }
/* 1995 */       for (Segment segment : segments) {
/* 1996 */         sum += segment.count;
/*      */       }
/* 1998 */       for (Segment segment : segments) {
/* 1999 */         segment.unlock();
/*      */       }
/*      */     }
/* 2002 */     return Ints.saturatedCast(sum);
/*      */   }
/*      */ 
/*      */   public V get(Object key) {
/* 2006 */     int hash = hash(key);
/* 2007 */     return segmentFor(hash).get(key, hash);
/*      */   }
/*      */ 
/*      */   public boolean containsKey(Object key) {
/* 2011 */     int hash = hash(key);
/* 2012 */     return segmentFor(hash).containsKey(key, hash);
/*      */   }
/*      */ 
/*      */   public boolean containsValue(Object value)
/*      */   {
/* 2017 */     Preconditions.checkNotNull(value, "value");
/*      */ 
/* 2021 */     Segment[] segments = this.segments;
/* 2022 */     int[] mc = new int[segments.length];
/*      */     int c;
/* 2025 */     for (int k = 0; k < 2; k++) {
/* 2026 */       int mcsum = 0;
/* 2027 */       for (int i = 0; i < segments.length; i++)
/*      */       {
/* 2030 */         int c = segments[i].count;
/* 2031 */         mcsum += (mc[i] = segments[i].modCount);
/* 2032 */         if (segments[i].containsValue(value)) {
/* 2033 */           return true;
/*      */         }
/*      */       }
/* 2036 */       boolean cleanSweep = true;
/* 2037 */       if (mcsum != 0) {
/* 2038 */         for (int i = 0; i < segments.length; i++)
/*      */         {
/* 2041 */           c = segments[i].count;
/* 2042 */           if (mc[i] != segments[i].modCount) {
/* 2043 */             cleanSweep = false;
/* 2044 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 2048 */       if (cleanSweep) {
/* 2049 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2054 */     for (Segment segment : segments)
/* 2055 */       segment.lock();
/*      */     try
/*      */     {
/* 2058 */       for (Segment segment : segments)
/* 2059 */         if (segment.containsValue(value)) {
/* 2060 */           c = 1;
/*      */           Segment[] arr$;
/*      */           int len$;
/*      */           int i$;
/*      */           Segment segment;
/*      */           return c;
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/*      */       Segment[] arr$;
/*      */       int len$;
/*      */       int i$;
/*      */       Segment segment;
/* 2064 */       for (Segment segment : segments) {
/* 2065 */         segment.unlock();
/*      */       }
/*      */     }
/* 2068 */     return false;
/*      */   }
/*      */ 
/*      */   public V put(K key, V value) {
/* 2072 */     int hash = hash(key);
/* 2073 */     return segmentFor(hash).put(key, hash, value, false);
/*      */   }
/*      */ 
/*      */   public V putIfAbsent(K key, V value) {
/* 2077 */     int hash = hash(key);
/* 2078 */     return segmentFor(hash).put(key, hash, value, true);
/*      */   }
/*      */ 
/*      */   public void putAll(Map<? extends K, ? extends V> m) {
/* 2082 */     for (Map.Entry e : m.entrySet())
/* 2083 */       put(e.getKey(), e.getValue());
/*      */   }
/*      */ 
/*      */   public V remove(Object key)
/*      */   {
/* 2088 */     int hash = hash(key);
/* 2089 */     return segmentFor(hash).remove(key, hash, this.expires);
/*      */   }
/*      */ 
/*      */   public boolean remove(Object key, Object value)
/*      */   {
/* 2098 */     int hash = hash(key);
/* 2099 */     return segmentFor(hash).remove(key, hash, value);
/*      */   }
/*      */ 
/*      */   public boolean replace(K key, V oldValue, V newValue)
/*      */   {
/* 2108 */     int hash = hash(key);
/* 2109 */     return segmentFor(hash).replace(key, hash, oldValue, newValue);
/*      */   }
/*      */ 
/*      */   public V replace(K key, V value)
/*      */   {
/* 2120 */     int hash = hash(key);
/* 2121 */     return segmentFor(hash).replace(key, hash, value);
/*      */   }
/*      */ 
/*      */   public void clear() {
/* 2125 */     for (Segment segment : this.segments)
/* 2126 */       segment.clear();
/*      */   }
/*      */ 
/*      */   public Set<K> keySet()
/*      */   {
/* 2133 */     Set ks = this.keySet;
/* 2134 */     return this.keySet = new KeySet();
/*      */   }
/*      */ 
/*      */   public Collection<V> values()
/*      */   {
/* 2140 */     Collection vs = this.values;
/* 2141 */     return this.values = new Values();
/*      */   }
/*      */ 
/*      */   public Set<Map.Entry<K, V>> entrySet()
/*      */   {
/* 2147 */     Set es = this.entrySet;
/* 2148 */     return this.entrySet = new EntrySet();
/*      */   }
/*      */ 
/*      */   Object writeReplace()
/*      */   {
/* 2421 */     return new SerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence, this.expirationNanos, this.maximumSize, this.concurrencyLevel, this);
/*      */   }
/*      */ 
/*      */   private static class SerializationProxy<K, V> extends CustomConcurrentHashMap.AbstractSerializationProxy<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SerializationProxy(CustomConcurrentHashMap.Strength keyStrength, CustomConcurrentHashMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expirationNanos, int maximumSize, int concurrencyLevel, ConcurrentMap<K, V> delegate)
/*      */     {
/* 2526 */       super(valueStrength, keyEquivalence, valueEquivalence, expirationNanos, maximumSize, concurrencyLevel, delegate);
/*      */     }
/*      */ 
/*      */     private void writeObject(ObjectOutputStream out)
/*      */       throws IOException
/*      */     {
/* 2532 */       out.defaultWriteObject();
/* 2533 */       writeMapTo(out);
/*      */     }
/*      */ 
/*      */     private void readObject(ObjectInputStream in)
/*      */       throws IOException, ClassNotFoundException
/*      */     {
/* 2539 */       in.defaultReadObject();
/* 2540 */       MapMaker mapMaker = readMapMaker(in);
/* 2541 */       this.delegate = mapMaker.makeMap();
/* 2542 */       readEntries(in);
/*      */     }
/*      */ 
/*      */     private Object readResolve() {
/* 2546 */       return this.delegate;
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract class AbstractSerializationProxy<K, V> extends ForwardingConcurrentMap<K, V>
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */     final CustomConcurrentHashMap.Strength keyStrength;
/*      */     final CustomConcurrentHashMap.Strength valueStrength;
/*      */     final Equivalence<Object> keyEquivalence;
/*      */     final Equivalence<Object> valueEquivalence;
/*      */     final long expirationNanos;
/*      */     final int maximumSize;
/*      */     final int concurrencyLevel;
/*      */     transient ConcurrentMap<K, V> delegate;
/*      */ 
/*      */     AbstractSerializationProxy(CustomConcurrentHashMap.Strength keyStrength, CustomConcurrentHashMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expirationNanos, int maximumSize, int concurrencyLevel, ConcurrentMap<K, V> delegate)
/*      */     {
/* 2451 */       this.keyStrength = keyStrength;
/* 2452 */       this.valueStrength = valueStrength;
/* 2453 */       this.keyEquivalence = keyEquivalence;
/* 2454 */       this.valueEquivalence = valueEquivalence;
/* 2455 */       this.expirationNanos = expirationNanos;
/* 2456 */       this.maximumSize = maximumSize;
/* 2457 */       this.concurrencyLevel = concurrencyLevel;
/* 2458 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     protected ConcurrentMap<K, V> delegate() {
/* 2462 */       return this.delegate;
/*      */     }
/*      */ 
/*      */     void writeMapTo(ObjectOutputStream out) throws IOException {
/* 2466 */       out.writeInt(this.delegate.size());
/*      */ 
/* 2468 */       for (Map.Entry entry : this.delegate.entrySet()) {
/* 2469 */         out.writeObject(entry.getKey());
/* 2470 */         out.writeObject(entry.getValue());
/*      */       }
/* 2472 */       out.writeObject(null);
/*      */     }
/*      */ 
/*      */     MapMaker readMapMaker(ObjectInputStream in) throws IOException, ClassNotFoundException
/*      */     {
/* 2477 */       int size = in.readInt();
/* 2478 */       MapMaker mapMaker = new MapMaker().initialCapacity(size).setKeyStrength(this.keyStrength).setValueStrength(this.valueStrength).privateKeyEquivalence(this.keyEquivalence).privateValueEquivalence(this.valueEquivalence).concurrencyLevel(this.concurrencyLevel);
/*      */ 
/* 2485 */       if (this.expirationNanos != 0L)
/*      */       {
/* 2487 */         mapMaker.expiration(this.expirationNanos, TimeUnit.NANOSECONDS);
/*      */       }
/* 2489 */       if (this.maximumSize != -1) {
/* 2490 */         mapMaker.maximumSize(this.maximumSize);
/*      */       }
/* 2492 */       return mapMaker;
/*      */     }
/*      */ 
/*      */     void readEntries(ObjectInputStream in) throws IOException, ClassNotFoundException
/*      */     {
/*      */       while (true)
/*      */       {
/* 2499 */         Object key = in.readObject();
/* 2500 */         if (key == null) {
/*      */           break;
/*      */         }
/* 2503 */         Object value = in.readObject();
/* 2504 */         this.delegate.put(key, value);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   final class EntrySet extends AbstractSet<Map.Entry<K, V>>
/*      */   {
/*      */     EntrySet()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Iterator<Map.Entry<K, V>> iterator()
/*      */     {
/* 2376 */       return new CustomConcurrentHashMap.EntryIterator(CustomConcurrentHashMap.this);
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/* 2380 */       if (!(o instanceof Map.Entry)) {
/* 2381 */         return false;
/*      */       }
/* 2383 */       Map.Entry e = (Map.Entry)o;
/* 2384 */       Object key = e.getKey();
/* 2385 */       if (key == null) {
/* 2386 */         return false;
/*      */       }
/* 2388 */       Object v = CustomConcurrentHashMap.this.get(key);
/*      */ 
/* 2390 */       return (v != null) && (CustomConcurrentHashMap.this.valueEquivalence.equivalent(v, e.getValue()));
/*      */     }
/*      */ 
/*      */     public boolean remove(Object o) {
/* 2394 */       if (!(o instanceof Map.Entry)) {
/* 2395 */         return false;
/*      */       }
/* 2397 */       Map.Entry e = (Map.Entry)o;
/* 2398 */       Object key = e.getKey();
/* 2399 */       return (key != null) && (CustomConcurrentHashMap.this.remove(key, e.getValue()));
/*      */     }
/*      */ 
/*      */     public int size()
/*      */     {
/* 2404 */       return CustomConcurrentHashMap.this.size();
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/* 2408 */       return CustomConcurrentHashMap.this.isEmpty();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2412 */       CustomConcurrentHashMap.this.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   final class Values extends AbstractCollection<V>
/*      */   {
/*      */     Values()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Iterator<V> iterator()
/*      */     {
/* 2353 */       return new CustomConcurrentHashMap.ValueIterator(CustomConcurrentHashMap.this);
/*      */     }
/*      */ 
/*      */     public int size() {
/* 2357 */       return CustomConcurrentHashMap.this.size();
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/* 2361 */       return CustomConcurrentHashMap.this.isEmpty();
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/* 2365 */       return CustomConcurrentHashMap.this.containsValue(o);
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2369 */       CustomConcurrentHashMap.this.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   final class KeySet extends AbstractSet<K>
/*      */   {
/*      */     KeySet()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Iterator<K> iterator()
/*      */     {
/* 2326 */       return new CustomConcurrentHashMap.KeyIterator(CustomConcurrentHashMap.this);
/*      */     }
/*      */ 
/*      */     public int size() {
/* 2330 */       return CustomConcurrentHashMap.this.size();
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/* 2334 */       return CustomConcurrentHashMap.this.isEmpty();
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/* 2338 */       return CustomConcurrentHashMap.this.containsKey(o);
/*      */     }
/*      */ 
/*      */     public boolean remove(Object o) {
/* 2342 */       return CustomConcurrentHashMap.this.remove(o) != null;
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2346 */       CustomConcurrentHashMap.this.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   final class EntryIterator extends CustomConcurrentHashMap<K, V>.HashIterator
/*      */     implements Iterator<Map.Entry<K, V>>
/*      */   {
/*      */     EntryIterator()
/*      */     {
/* 2315 */       super();
/*      */     }
/*      */ 
/*      */     public Map.Entry<K, V> next() {
/* 2319 */       return nextEntry();
/*      */     }
/*      */   }
/*      */ 
/*      */   final class WriteThroughEntry extends AbstractMapEntry<K, V>
/*      */   {
/*      */     final K key;
/*      */     V value;
/*      */ 
/*      */     WriteThroughEntry(V key)
/*      */     {
/* 2281 */       this.key = key;
/* 2282 */       this.value = value;
/*      */     }
/*      */ 
/*      */     public K getKey() {
/* 2286 */       return this.key;
/*      */     }
/*      */ 
/*      */     public V getValue() {
/* 2290 */       return this.value;
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object)
/*      */     {
/* 2295 */       if ((object instanceof Map.Entry)) {
/* 2296 */         Map.Entry that = (Map.Entry)object;
/* 2297 */         return (this.key.equals(that.getKey())) && (this.value.equals(that.getValue()));
/*      */       }
/*      */ 
/* 2300 */       return false;
/*      */     }
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 2305 */       return this.key.hashCode() ^ this.value.hashCode();
/*      */     }
/*      */ 
/*      */     public V setValue(V newValue) {
/* 2309 */       Object oldValue = CustomConcurrentHashMap.this.put(this.key, newValue);
/* 2310 */       this.value = newValue;
/* 2311 */       return oldValue;
/*      */     }
/*      */   }
/*      */ 
/*      */   final class ValueIterator extends CustomConcurrentHashMap<K, V>.HashIterator
/*      */     implements Iterator<V>
/*      */   {
/*      */     ValueIterator()
/*      */     {
/* 2265 */       super();
/*      */     }
/*      */     public V next() {
/* 2268 */       return nextEntry().getValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   final class KeyIterator extends CustomConcurrentHashMap<K, V>.HashIterator
/*      */     implements Iterator<K>
/*      */   {
/*      */     KeyIterator()
/*      */     {
/* 2258 */       super();
/*      */     }
/*      */     public K next() {
/* 2261 */       return nextEntry().getKey();
/*      */     }
/*      */   }
/*      */ 
/*      */   abstract class HashIterator
/*      */   {
/*      */     int nextSegmentIndex;
/*      */     int nextTableIndex;
/*      */     AtomicReferenceArray<CustomConcurrentHashMap.ReferenceEntry<K, V>> currentTable;
/*      */     CustomConcurrentHashMap.ReferenceEntry<K, V> nextEntry;
/*      */     CustomConcurrentHashMap<K, V>.WriteThroughEntry nextExternal;
/*      */     CustomConcurrentHashMap<K, V>.WriteThroughEntry lastReturned;
/*      */ 
/*      */     HashIterator()
/*      */     {
/* 2163 */       this.nextSegmentIndex = (CustomConcurrentHashMap.this.segments.length - 1);
/* 2164 */       this.nextTableIndex = -1;
/* 2165 */       advance();
/*      */     }
/*      */ 
/*      */     final void advance() {
/* 2169 */       this.nextExternal = null;
/*      */ 
/* 2171 */       if (nextInChain()) {
/* 2172 */         return;
/*      */       }
/*      */ 
/* 2175 */       if (nextInTable()) {
/* 2176 */         return;
/*      */       }
/*      */ 
/* 2179 */       while (this.nextSegmentIndex >= 0) {
/* 2180 */         CustomConcurrentHashMap.Segment seg = CustomConcurrentHashMap.this.segments[(this.nextSegmentIndex--)];
/* 2181 */         if (seg.count != 0) {
/* 2182 */           this.currentTable = seg.table;
/* 2183 */           this.nextTableIndex = (this.currentTable.length() - 1);
/* 2184 */           if (nextInTable())
/* 2185 */             return;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     boolean nextInChain()
/*      */     {
/* 2196 */       if (this.nextEntry != null) {
/* 2197 */         for (this.nextEntry = this.nextEntry.getNext(); this.nextEntry != null; )
/*      */         {
/* 2199 */           if (advanceTo(this.nextEntry))
/* 2200 */             return true;
/* 2198 */           this.nextEntry = this.nextEntry.getNext();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2204 */       return false;
/*      */     }
/*      */ 
/*      */     boolean nextInTable()
/*      */     {
/* 2212 */       while (this.nextTableIndex >= 0) {
/* 2213 */         if (((this.nextEntry = (CustomConcurrentHashMap.ReferenceEntry)this.currentTable.get(this.nextTableIndex--)) != null) && (
/* 2214 */           (advanceTo(this.nextEntry)) || (nextInChain()))) {
/* 2215 */           return true;
/*      */         }
/*      */       }
/*      */ 
/* 2219 */       return false;
/*      */     }
/*      */ 
/*      */     boolean advanceTo(CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*      */     {
/* 2227 */       Object key = entry.getKey();
/* 2228 */       Object value = CustomConcurrentHashMap.this.getUnexpiredValue(entry);
/* 2229 */       if ((key != null) && (value != null)) {
/* 2230 */         this.nextExternal = new CustomConcurrentHashMap.WriteThroughEntry(CustomConcurrentHashMap.this, key, value);
/* 2231 */         return true;
/*      */       }
/*      */ 
/* 2234 */       return false;
/*      */     }
/*      */ 
/*      */     public boolean hasNext()
/*      */     {
/* 2239 */       return this.nextExternal != null;
/*      */     }
/*      */ 
/*      */     CustomConcurrentHashMap<K, V>.WriteThroughEntry nextEntry() {
/* 2243 */       if (this.nextExternal == null) {
/* 2244 */         throw new NoSuchElementException();
/*      */       }
/* 2246 */       this.lastReturned = this.nextExternal;
/* 2247 */       advance();
/* 2248 */       return this.lastReturned;
/*      */     }
/*      */ 
/*      */     public void remove() {
/* 2252 */       Preconditions.checkState(this.lastReturned != null);
/* 2253 */       CustomConcurrentHashMap.this.remove(this.lastReturned.getKey());
/* 2254 */       this.lastReturned = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   final class Segment extends ReentrantLock
/*      */   {
/*      */     volatile int count;
/*      */     int modCount;
/*      */     int threshold;
/*      */     volatile AtomicReferenceArray<CustomConcurrentHashMap.ReferenceEntry<K, V>> table;
/*      */     final int maxSegmentSize;
/* 1364 */     final CustomConcurrentHashMap.Expirable expirationHead = new CustomConcurrentHashMap.Expirable()
/*      */     {
/*      */ 
/*      */       @GuardedBy("Segment.this")
/* 1370 */       CustomConcurrentHashMap.Expirable next = this;
/*      */ 
/*      */       @GuardedBy("Segment.this")
/* 1379 */       CustomConcurrentHashMap.Expirable previous = this;
/*      */ 
/*      */       public long getWriteTime()
/*      */       {
/* 1366 */         return 9223372036854775807L;
/*      */       }
/*      */ 
/*      */       public void setWriteTime(long writeTime) {
/*      */       }
/*      */ 
/*      */       public CustomConcurrentHashMap.Expirable getNextExpirable() {
/* 1373 */         return this.next;
/*      */       }
/*      */       public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/* 1376 */         this.next = next;
/*      */       }
/*      */ 
/*      */       public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */       {
/* 1382 */         return this.previous;
/*      */       }
/*      */       public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/* 1385 */         this.previous = previous;
/*      */       }
/* 1364 */     };
/*      */ 
/*      */     Segment(int initialCapacity, int maxSegmentSize)
/*      */     {
/* 1390 */       setTable(newEntryArray(initialCapacity));
/* 1391 */       this.maxSegmentSize = maxSegmentSize;
/*      */     }
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     void setValue(CustomConcurrentHashMap.ReferenceEntry<K, V> entry, V value, boolean inserted)
/*      */     {
/* 1401 */       if (CustomConcurrentHashMap.this.expires) {
/* 1402 */         CustomConcurrentHashMap.Expirable expirable = (CustomConcurrentHashMap.Expirable)entry;
/* 1403 */         addExpirable(expirable);
/*      */       }
/* 1405 */       CustomConcurrentHashMap.this.setValueReference(entry, CustomConcurrentHashMap.this.valueStrength.referenceValue(entry, value));
/*      */     }
/*      */     @GuardedBy("Segment.this")
/*      */     void addExpirable(CustomConcurrentHashMap.Expirable added) {
/* 1410 */       CustomConcurrentHashMap.connectExpirable(added.getPreviousExpirable(), added.getNextExpirable());
/*      */ 
/* 1413 */       added.setWriteTime(System.nanoTime());
/*      */ 
/* 1415 */       CustomConcurrentHashMap.connectExpirable(this.expirationHead.getPreviousExpirable(), added);
/* 1416 */       CustomConcurrentHashMap.connectExpirable(added, this.expirationHead);
/*      */     }
/*      */     @GuardedBy("Segment.this")
/*      */     void removeExpirable(CustomConcurrentHashMap.Expirable removed) {
/* 1421 */       CustomConcurrentHashMap.connectExpirable(removed.getPreviousExpirable(), removed.getNextExpirable());
/*      */ 
/* 1423 */       CustomConcurrentHashMap.nullifyExpirable(removed);
/*      */     }
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     void expireEntries()
/*      */     {
/* 1431 */       CustomConcurrentHashMap.Expirable expirable = this.expirationHead.getNextExpirable();
/* 1432 */       if (expirable == this.expirationHead)
/*      */       {
/* 1435 */         return;
/*      */       }
/* 1437 */       long now = System.nanoTime();
/* 1438 */       while ((expirable != this.expirationHead) && (CustomConcurrentHashMap.this.isExpired(expirable, now)))
/*      */       {
/* 1440 */         CustomConcurrentHashMap.ReferenceEntry entry = (CustomConcurrentHashMap.ReferenceEntry)expirable;
/* 1441 */         removeEntry(entry, entry.getHash());
/*      */ 
/* 1443 */         removeExpirable(expirable);
/* 1444 */         expirable = this.expirationHead.getNextExpirable();
/*      */       }
/*      */     }
/*      */ 
/*      */     AtomicReferenceArray<CustomConcurrentHashMap.ReferenceEntry<K, V>> newEntryArray(int size) {
/* 1449 */       return new AtomicReferenceArray(size);
/*      */     }
/*      */     @GuardedBy("Segment.this")
/*      */     void clearExpirationQueue() {
/* 1454 */       CustomConcurrentHashMap.Expirable expirable = this.expirationHead.getNextExpirable();
/* 1455 */       while (expirable != this.expirationHead) {
/* 1456 */         CustomConcurrentHashMap.Expirable next = expirable.getNextExpirable();
/* 1457 */         CustomConcurrentHashMap.nullifyExpirable(expirable);
/* 1458 */         expirable = next;
/*      */       }
/*      */ 
/* 1461 */       this.expirationHead.setNextExpirable(this.expirationHead);
/* 1462 */       this.expirationHead.setPreviousExpirable(this.expirationHead);
/*      */     }
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     void setTable(AtomicReferenceArray<CustomConcurrentHashMap.ReferenceEntry<K, V>> newTable)
/*      */     {
/* 1470 */       this.threshold = (newTable.length() * 3 / 4);
/* 1471 */       this.table = newTable;
/*      */     }
/*      */ 
/*      */     CustomConcurrentHashMap.ReferenceEntry<K, V> getFirst(int hash)
/*      */     {
/* 1479 */       AtomicReferenceArray table = this.table;
/* 1480 */       return (CustomConcurrentHashMap.ReferenceEntry)table.get(hash & table.length() - 1);
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ReferenceEntry<K, V> getEntry(Object key, int hash)
/*      */     {
/*      */       CustomConcurrentHashMap.ReferenceEntry e;
/* 1486 */       if (this.count != 0) {
/* 1487 */         for (e = getFirst(hash); e != null; )
/*      */         {
/* 1489 */           if (e.getHash() == hash)
/*      */           {
/* 1493 */             Object entryKey = e.getKey();
/* 1494 */             if (entryKey != null)
/*      */             {
/* 1498 */               if ((CustomConcurrentHashMap.this.keyEquivalence.equivalent(entryKey, key)) && (
/* 1499 */                 (!CustomConcurrentHashMap.this.expires) || (!CustomConcurrentHashMap.this.isExpired(e))))
/*      */               {
/* 1502 */                 return e;
/*      */               }
/*      */             }
/*      */           }
/* 1488 */           e = e.getNext();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1507 */       return null;
/*      */     }
/*      */ 
/*      */     V get(Object key, int hash) {
/* 1511 */       CustomConcurrentHashMap.ReferenceEntry entry = getEntry(key, hash);
/* 1512 */       if (entry == null) {
/* 1513 */         return null;
/*      */       }
/*      */ 
/* 1516 */       return entry.getValueReference().get();
/*      */     }
/*      */ 
/*      */     boolean containsKey(Object key, int hash)
/*      */     {
/*      */       CustomConcurrentHashMap.ReferenceEntry e;
/* 1520 */       if (this.count != 0) {
/* 1521 */         for (e = getFirst(hash); e != null; )
/*      */         {
/* 1523 */           if (e.getHash() == hash)
/*      */           {
/* 1527 */             Object entryKey = e.getKey();
/* 1528 */             if (entryKey != null)
/*      */             {
/* 1532 */               if (CustomConcurrentHashMap.this.keyEquivalence.equivalent(entryKey, key))
/* 1533 */                 return CustomConcurrentHashMap.this.getUnexpiredValue(e) != null;
/*      */             }
/*      */           }
/* 1522 */           e = e.getNext();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1538 */       return false;
/*      */     }
/*      */ 
/*      */     boolean containsValue(Object value) {
/* 1542 */       if (this.count != 0) {
/* 1543 */         AtomicReferenceArray table = this.table;
/* 1544 */         int length = table.length();
/*      */         CustomConcurrentHashMap.ReferenceEntry e;
/* 1545 */         for (int i = 0; i < length; i++) {
/* 1546 */           for (e = (CustomConcurrentHashMap.ReferenceEntry)table.get(i); e != null; )
/*      */           {
/* 1548 */             Object entryValue = CustomConcurrentHashMap.this.getUnexpiredValue(e);
/* 1549 */             if (entryValue != null)
/*      */             {
/* 1552 */               if (CustomConcurrentHashMap.this.valueEquivalence.equivalent(entryValue, value))
/* 1553 */                 return true;
/*      */             }
/* 1547 */             e = e.getNext();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1559 */       return false;
/*      */     }
/*      */ 
/*      */     boolean replace(K key, int hash, V oldValue, V newValue) {
/* 1563 */       Preconditions.checkNotNull(newValue);
/* 1564 */       lock();
/*      */       try {
/* 1566 */         if (CustomConcurrentHashMap.this.expires) {
/* 1567 */           expireEntries();
/*      */         }
/*      */ 
/* 1570 */         for (CustomConcurrentHashMap.ReferenceEntry e = getFirst(hash); e != null; )
/*      */         {
/* 1572 */           Object entryKey = e.getKey();
/* 1573 */           if ((e.getHash() == hash) && (entryKey != null) && (CustomConcurrentHashMap.this.keyEquivalence.equivalent(key, entryKey)))
/*      */           {
/* 1577 */             Object entryValue = e.getValueReference().get();
/*      */             int i;
/* 1578 */             if (entryValue == null) {
/* 1579 */               i = 0;
/*      */               return i;
/*      */             }
/* 1582 */             if (CustomConcurrentHashMap.this.valueEquivalence.equivalent(entryValue, oldValue)) {
/* 1583 */               setValue(e, newValue, false);
/* 1584 */               i = 1;
/*      */               return i;
/*      */             }
/*      */           }
/* 1571 */           e = e.getNext();
/*      */         }
/*      */ 
/* 1589 */         e = 0;
/*      */         return e; } finally { unlock(); } throw localObject1;
/*      */     }
/*      */ 
/*      */     V replace(K key, int hash, V newValue)
/*      */     {
/* 1596 */       Preconditions.checkNotNull(newValue);
/* 1597 */       lock();
/*      */       try {
/* 1599 */         if (CustomConcurrentHashMap.this.expires) {
/* 1600 */           expireEntries();
/*      */         }
/*      */ 
/* 1603 */         for (CustomConcurrentHashMap.ReferenceEntry e = getFirst(hash); e != null; )
/*      */         {
/* 1605 */           Object entryKey = e.getKey();
/* 1606 */           if ((e.getHash() == hash) && (entryKey != null) && (CustomConcurrentHashMap.this.keyEquivalence.equivalent(key, entryKey)))
/*      */           {
/* 1610 */             Object entryValue = e.getValueReference().get();
/* 1611 */             if (entryValue == null) {
/* 1612 */               localObject1 = null;
/*      */               return localObject1;
/*      */             }
/* 1615 */             setValue(e, newValue, false);
/* 1616 */             Object localObject1 = entryValue;
/*      */             return localObject1;
/*      */           }
/* 1604 */           e = e.getNext();
/*      */         }
/*      */ 
/* 1620 */         e = null;
/*      */         return e; } finally { unlock(); } throw localObject2;
/*      */     }
/*      */ 
/*      */     V put(K key, int hash, V value, boolean onlyIfAbsent)
/*      */     {
/* 1627 */       Preconditions.checkNotNull(value);
/* 1628 */       lock();
/*      */       try {
/* 1630 */         if (CustomConcurrentHashMap.this.expires) {
/* 1631 */           expireEntries();
/*      */         }
/*      */ 
/* 1634 */         int newCount = this.count + 1;
/* 1635 */         if (newCount > this.threshold) {
/* 1636 */           expand();
/*      */         }
/*      */ 
/* 1640 */         AtomicReferenceArray table = this.table;
/* 1641 */         int index = hash & table.length() - 1;
/* 1642 */         CustomConcurrentHashMap.ReferenceEntry first = (CustomConcurrentHashMap.ReferenceEntry)table.get(index);
/*      */ 
/* 1645 */         for (CustomConcurrentHashMap.ReferenceEntry e = first; e != null; e = e.getNext()) {
/* 1646 */           entryKey = e.getKey();
/* 1647 */           if ((e.getHash() != hash) || (entryKey == null) || (!CustomConcurrentHashMap.this.keyEquivalence.equivalent(key, entryKey)))
/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 1653 */           Object entryValue = e.getValueReference().get();
/* 1654 */           boolean absent = entryValue == null;
/* 1655 */           if ((onlyIfAbsent) && (!absent)) {
/* 1656 */             localObject1 = entryValue;
/*      */             return localObject1;
/*      */           }
/* 1659 */           setValue(e, value, absent);
/* 1660 */           Object localObject1 = entryValue;
/*      */           return localObject1;
/*      */         }
/* 1665 */         this.modCount += 1;
/* 1666 */         CustomConcurrentHashMap.ReferenceEntry newEntry = CustomConcurrentHashMap.this.entryFactory.newEntry(CustomConcurrentHashMap.this, key, hash, first);
/*      */ 
/* 1668 */         setValue(newEntry, value, true);
/* 1669 */         table.set(index, newEntry);
/* 1670 */         this.count = newCount;
/* 1671 */         Object entryKey = null;
/*      */         return entryKey; } finally { unlock(); } throw localObject2;
/*      */     }
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     void expand()
/*      */     {
/* 1682 */       AtomicReferenceArray oldTable = this.table;
/* 1683 */       int oldCapacity = oldTable.length();
/* 1684 */       if (oldCapacity >= 1073741824) {
/* 1685 */         return;
/*      */       }
/*      */ 
/* 1702 */       AtomicReferenceArray newTable = newEntryArray(oldCapacity << 1);
/*      */ 
/* 1704 */       this.threshold = (newTable.length() * 3 / 4);
/* 1705 */       int newMask = newTable.length() - 1;
/* 1706 */       for (int oldIndex = 0; oldIndex < oldCapacity; oldIndex++)
/*      */       {
/* 1709 */         CustomConcurrentHashMap.ReferenceEntry head = (CustomConcurrentHashMap.ReferenceEntry)oldTable.get(oldIndex);
/*      */ 
/* 1711 */         if (head != null) {
/* 1712 */           CustomConcurrentHashMap.ReferenceEntry next = head.getNext();
/* 1713 */           int headIndex = head.getHash() & newMask;
/*      */ 
/* 1716 */           if (next == null) {
/* 1717 */             newTable.set(headIndex, head);
/*      */           }
/*      */           else
/*      */           {
/* 1722 */             CustomConcurrentHashMap.ReferenceEntry tail = head;
/* 1723 */             int tailIndex = headIndex;
/* 1724 */             for (CustomConcurrentHashMap.ReferenceEntry e = next; e != null; e = e.getNext()) {
/* 1725 */               int newIndex = e.getHash() & newMask;
/* 1726 */               if (newIndex == tailIndex)
/*      */                 continue;
/* 1728 */               tailIndex = newIndex;
/* 1729 */               tail = e;
/*      */             }
/*      */ 
/* 1732 */             newTable.set(tailIndex, tail);
/*      */ 
/* 1735 */             for (CustomConcurrentHashMap.ReferenceEntry e = head; e != tail; e = e.getNext()) {
/* 1736 */               Object key = e.getKey();
/* 1737 */               if (key != null) {
/* 1738 */                 int newIndex = e.getHash() & newMask;
/* 1739 */                 CustomConcurrentHashMap.ReferenceEntry newNext = (CustomConcurrentHashMap.ReferenceEntry)newTable.get(newIndex);
/* 1740 */                 newTable.set(newIndex, CustomConcurrentHashMap.this.copyEntry(e, newNext));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1746 */       this.table = newTable;
/*      */     }
/*      */ 
/*      */     V remove(Object key, int hash, boolean expire) {
/* 1750 */       lock();
/*      */       try {
/* 1752 */         if (expire) {
/* 1753 */           expireEntries();
/*      */         }
/*      */ 
/* 1756 */         int newCount = this.count - 1;
/* 1757 */         AtomicReferenceArray table = this.table;
/* 1758 */         int index = hash & table.length() - 1;
/* 1759 */         CustomConcurrentHashMap.ReferenceEntry first = (CustomConcurrentHashMap.ReferenceEntry)table.get(index);
/*      */ 
/* 1761 */         for (CustomConcurrentHashMap.ReferenceEntry e = first; e != null; e = e.getNext()) {
/* 1762 */           Object entryKey = e.getKey();
/* 1763 */           if ((e.getHash() != hash) || (entryKey == null) || (!CustomConcurrentHashMap.this.keyEquivalence.equivalent(entryKey, key)))
/*      */             continue;
/* 1765 */           Object entryValue = e.getValueReference().get();
/* 1766 */           this.modCount += 1;
/* 1767 */           CustomConcurrentHashMap.ReferenceEntry newFirst = removeFromTable(first, e);
/* 1768 */           table.set(index, newFirst);
/* 1769 */           this.count = newCount;
/* 1770 */           Object localObject1 = entryValue;
/*      */           return localObject1;
/*      */         }
/* 1774 */         e = null;
/*      */         return e; } finally { unlock(); } throw localObject2;
/*      */     }
/*      */ 
/*      */     boolean remove(Object key, int hash, Object value)
/*      */     {
/* 1781 */       lock();
/*      */       try {
/* 1783 */         if (CustomConcurrentHashMap.this.expires) {
/* 1784 */           expireEntries();
/*      */         }
/*      */ 
/* 1787 */         int newCount = this.count - 1;
/* 1788 */         AtomicReferenceArray table = this.table;
/* 1789 */         int index = hash & table.length() - 1;
/* 1790 */         CustomConcurrentHashMap.ReferenceEntry first = (CustomConcurrentHashMap.ReferenceEntry)table.get(index);
/*      */ 
/* 1792 */         for (CustomConcurrentHashMap.ReferenceEntry e = first; e != null; e = e.getNext()) {
/* 1793 */           Object entryKey = e.getKey();
/* 1794 */           if ((e.getHash() != hash) || (entryKey == null) || (!CustomConcurrentHashMap.this.keyEquivalence.equivalent(entryKey, key)))
/*      */             continue;
/* 1796 */           Object entryValue = e.getValueReference().get();
/* 1797 */           if ((value == entryValue) || ((value != null) && (entryValue != null) && (CustomConcurrentHashMap.this.valueEquivalence.equivalent(entryValue, value))))
/*      */           {
/* 1799 */             this.modCount += 1;
/* 1800 */             newFirst = removeFromTable(first, e);
/* 1801 */             table.set(index, newFirst);
/* 1802 */             this.count = newCount;
/* 1803 */             int i = 1;
/*      */             return i;
/*      */           }
/* 1805 */           CustomConcurrentHashMap.ReferenceEntry newFirst = 0;
/*      */           return newFirst;
/*      */         }
/* 1810 */         e = 0;
/*      */         return e; } finally { unlock(); } throw localObject1;
/*      */     }
/*      */ 
/*      */     boolean reclaimValue(CustomConcurrentHashMap.ReferenceEntry<K, V> entry, int hash)
/*      */     {
/* 1826 */       lock();
/*      */       try {
/* 1828 */         int newCount = this.count - 1;
/* 1829 */         AtomicReferenceArray table = this.table;
/* 1830 */         int index = hash & table.length() - 1;
/* 1831 */         CustomConcurrentHashMap.ReferenceEntry first = (CustomConcurrentHashMap.ReferenceEntry)table.get(index);
/*      */ 
/* 1833 */         for (CustomConcurrentHashMap.ReferenceEntry e = first; e != null; e = e.getNext())
/* 1834 */           if (e == entry) {
/* 1835 */             Object entryValue = e.getValueReference().get();
/* 1836 */             if (entryValue == null) {
/* 1837 */               this.modCount += 1;
/* 1838 */               newFirst = removeFromTable(first, e);
/* 1839 */               table.set(index, newFirst);
/* 1840 */               this.count = newCount;
/* 1841 */               int i = 1;
/*      */               return i;
/*      */             }
/* 1843 */             CustomConcurrentHashMap.ReferenceEntry newFirst = 0;
/*      */             return newFirst;
/*      */           }
/* 1848 */         e = 0;
/*      */         return e; } finally { unlock(); } throw localObject1;
/*      */     }
/*      */ 
/*      */     boolean removeEntry(CustomConcurrentHashMap.ReferenceEntry<K, V> entry, int hash)
/*      */     {
/* 1859 */       lock();
/*      */       try {
/* 1861 */         int newCount = this.count - 1;
/* 1862 */         AtomicReferenceArray table = this.table;
/* 1863 */         int index = hash & table.length() - 1;
/* 1864 */         CustomConcurrentHashMap.ReferenceEntry first = (CustomConcurrentHashMap.ReferenceEntry)table.get(index);
/*      */ 
/* 1866 */         for (CustomConcurrentHashMap.ReferenceEntry e = first; e != null; e = e.getNext())
/* 1867 */           if (e == entry) {
/* 1868 */             this.modCount += 1;
/* 1869 */             CustomConcurrentHashMap.ReferenceEntry newFirst = removeFromTable(first, e);
/* 1870 */             table.set(index, newFirst);
/* 1871 */             this.count = newCount;
/* 1872 */             int i = 1;
/*      */             return i;
/*      */           }
/* 1876 */         e = 0;
/*      */         return e; } finally { unlock(); } throw localObject;
/*      */     }
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     private CustomConcurrentHashMap.ReferenceEntry<K, V> removeFromTable(CustomConcurrentHashMap.ReferenceEntry<K, V> first, CustomConcurrentHashMap.ReferenceEntry<K, V> removed)
/*      */     {
/* 1893 */       if (CustomConcurrentHashMap.this.expires) {
/* 1894 */         removeExpirable((CustomConcurrentHashMap.Expirable)removed);
/*      */       }
/*      */ 
/* 1897 */       CustomConcurrentHashMap.ReferenceEntry newFirst = removed.getNext();
/* 1898 */       for (CustomConcurrentHashMap.ReferenceEntry p = first; p != removed; p = p.getNext()) {
/* 1899 */         Object pKey = p.getKey();
/* 1900 */         if (pKey != null) {
/* 1901 */           newFirst = CustomConcurrentHashMap.this.copyEntry(p, newFirst);
/*      */         }
/*      */       }
/* 1904 */       return newFirst;
/*      */     }
/*      */ 
/*      */     void clear() {
/* 1908 */       if (this.count != 0) {
/* 1909 */         lock();
/*      */         try {
/* 1911 */           AtomicReferenceArray table = this.table;
/* 1912 */           for (int i = 0; i < table.length(); i++) {
/* 1913 */             table.set(i, null);
/*      */           }
/* 1915 */           clearExpirationQueue();
/*      */ 
/* 1917 */           this.modCount += 1;
/* 1918 */           this.count = 0;
/*      */         } finally {
/* 1920 */           unlock();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class StrongValueReference<K, V>
/*      */     implements CustomConcurrentHashMap.ValueReference<K, V>
/*      */   {
/*      */     final V referent;
/*      */ 
/*      */     StrongValueReference(V referent)
/*      */     {
/* 1146 */       this.referent = referent;
/*      */     }
/*      */ 
/*      */     public V get() {
/* 1150 */       return this.referent;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*      */     {
/* 1155 */       return this;
/*      */     }
/*      */ 
/*      */     public V waitForValue() {
/* 1159 */       return get();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SoftValueReference<K, V> extends FinalizableSoftReference<V>
/*      */     implements CustomConcurrentHashMap.ValueReference<K, V>
/*      */   {
/*      */     final CustomConcurrentHashMap.ReferenceEntry<K, V> entry;
/*      */ 
/*      */     SoftValueReference(V referent, CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*      */     {
/* 1122 */       super(CustomConcurrentHashMap.QueueHolder.queue);
/* 1123 */       this.entry = entry;
/*      */     }
/*      */ 
/*      */     public void finalizeReferent() {
/* 1127 */       this.entry.valueReclaimed();
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*      */     {
/* 1132 */       return new SoftValueReference(get(), entry);
/*      */     }
/*      */ 
/*      */     public V waitForValue() {
/* 1136 */       return get();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class WeakValueReference<K, V> extends FinalizableWeakReference<V>
/*      */     implements CustomConcurrentHashMap.ValueReference<K, V>
/*      */   {
/*      */     final CustomConcurrentHashMap.ReferenceEntry<K, V> entry;
/*      */ 
/*      */     WeakValueReference(V referent, CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*      */     {
/* 1097 */       super(CustomConcurrentHashMap.QueueHolder.queue);
/* 1098 */       this.entry = entry;
/*      */     }
/*      */ 
/*      */     public void finalizeReferent() {
/* 1102 */       this.entry.valueReclaimed();
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*      */     {
/* 1107 */       return new WeakValueReference(get(), entry);
/*      */     }
/*      */ 
/*      */     public V waitForValue() {
/* 1111 */       return get();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class WeakExpirableEvictableEntry<K, V> extends CustomConcurrentHashMap.WeakEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Expirable, CustomConcurrentHashMap.Evictable
/*      */   {
/* 1053 */     volatile long writeTime = 9223372036854775807L;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/* 1061 */     CustomConcurrentHashMap.Expirable next = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/* 1070 */     CustomConcurrentHashMap.Expirable previous = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */     volatile int lastUsage;
/*      */ 
/*      */     WeakExpirableEvictableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/* 1048 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/* 1055 */       return this.writeTime;
/*      */     }
/*      */     public void setWriteTime(long writeTime) {
/* 1058 */       this.writeTime = writeTime;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable()
/*      */     {
/* 1064 */       return this.next;
/*      */     }
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/* 1067 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */     {
/* 1073 */       return this.previous;
/*      */     }
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/* 1076 */       this.previous = previous;
/*      */     }
/*      */ 
/*      */     public int getLastUsage()
/*      */     {
/* 1083 */       return this.lastUsage;
/*      */     }
/*      */     public void setLastUsage(int lastUsage) {
/* 1086 */       this.lastUsage = lastUsage;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class WeakEvictableEntry<K, V> extends CustomConcurrentHashMap.WeakEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Evictable
/*      */   {
/*      */     volatile int lastUsage;
/*      */ 
/*      */     WeakEvictableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/* 1030 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public int getLastUsage()
/*      */     {
/* 1037 */       return this.lastUsage;
/*      */     }
/*      */     public void setLastUsage(int lastUsage) {
/* 1040 */       this.lastUsage = lastUsage;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class WeakExpirableEntry<K, V> extends CustomConcurrentHashMap.WeakEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Expirable
/*      */   {
/*  999 */     volatile long writeTime = 9223372036854775807L;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/* 1007 */     CustomConcurrentHashMap.Expirable next = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/* 1016 */     CustomConcurrentHashMap.Expirable previous = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     WeakExpirableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  994 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/* 1001 */       return this.writeTime;
/*      */     }
/*      */     public void setWriteTime(long writeTime) {
/* 1004 */       this.writeTime = writeTime;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable()
/*      */     {
/* 1010 */       return this.next;
/*      */     }
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/* 1013 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */     {
/* 1019 */       return this.previous;
/*      */     }
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/* 1022 */       this.previous = previous;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class WeakEntry<K, V> extends FinalizableWeakReference<K>
/*      */     implements CustomConcurrentHashMap.ReferenceEntry<K, V>
/*      */   {
/*      */     final CustomConcurrentHashMap<K, V> map;
/*      */     final int hash;
/*      */     final CustomConcurrentHashMap.ReferenceEntry<K, V> next;
/*  970 */     volatile CustomConcurrentHashMap.ValueReference<K, V> valueReference = CustomConcurrentHashMap.access$200();
/*      */ 
/*      */     WeakEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  951 */       super(CustomConcurrentHashMap.QueueHolder.queue);
/*  952 */       this.map = map;
/*  953 */       this.hash = hash;
/*  954 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public K getKey() {
/*  958 */       return get();
/*      */     }
/*      */ 
/*      */     public void finalizeReferent() {
/*  962 */       this.map.removeEntry(this);
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<K, V> getValueReference()
/*      */     {
/*  973 */       return this.valueReference;
/*      */     }
/*      */ 
/*      */     public void setValueReference(CustomConcurrentHashMap.ValueReference<K, V> valueReference) {
/*  977 */       this.valueReference = valueReference;
/*      */     }
/*      */     public void valueReclaimed() {
/*  980 */       this.map.reclaimValue(this);
/*      */     }
/*      */     public int getHash() {
/*  983 */       return this.hash;
/*      */     }
/*      */     public CustomConcurrentHashMap.ReferenceEntry<K, V> getNext() {
/*  986 */       return this.next;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SoftExpirableEvictableEntry<K, V> extends CustomConcurrentHashMap.SoftEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Expirable, CustomConcurrentHashMap.Evictable
/*      */   {
/*  907 */     volatile long writeTime = 9223372036854775807L;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  915 */     CustomConcurrentHashMap.Expirable next = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  924 */     CustomConcurrentHashMap.Expirable previous = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */     volatile int lastUsage;
/*      */ 
/*      */     SoftExpirableEvictableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  902 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/*  909 */       return this.writeTime;
/*      */     }
/*      */     public void setWriteTime(long writeTime) {
/*  912 */       this.writeTime = writeTime;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable()
/*      */     {
/*  918 */       return this.next;
/*      */     }
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/*  921 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */     {
/*  927 */       return this.previous;
/*      */     }
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/*  930 */       this.previous = previous;
/*      */     }
/*      */ 
/*      */     public int getLastUsage()
/*      */     {
/*  937 */       return this.lastUsage;
/*      */     }
/*      */     public void setLastUsage(int lastUsage) {
/*  940 */       this.lastUsage = lastUsage;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SoftEvictableEntry<K, V> extends CustomConcurrentHashMap.SoftEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Evictable
/*      */   {
/*      */     volatile int lastUsage;
/*      */ 
/*      */     SoftEvictableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  884 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public int getLastUsage()
/*      */     {
/*  891 */       return this.lastUsage;
/*      */     }
/*      */     public void setLastUsage(int lastUsage) {
/*  894 */       this.lastUsage = lastUsage;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SoftExpirableEntry<K, V> extends CustomConcurrentHashMap.SoftEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Expirable
/*      */   {
/*  853 */     volatile long writeTime = 9223372036854775807L;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  861 */     CustomConcurrentHashMap.Expirable next = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  870 */     CustomConcurrentHashMap.Expirable previous = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     SoftExpirableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  848 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/*  855 */       return this.writeTime;
/*      */     }
/*      */     public void setWriteTime(long writeTime) {
/*  858 */       this.writeTime = writeTime;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable()
/*      */     {
/*  864 */       return this.next;
/*      */     }
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/*  867 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */     {
/*  873 */       return this.previous;
/*      */     }
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/*  876 */       this.previous = previous;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SoftEntry<K, V> extends FinalizableSoftReference<K>
/*      */     implements CustomConcurrentHashMap.ReferenceEntry<K, V>
/*      */   {
/*      */     final CustomConcurrentHashMap<K, V> map;
/*      */     final int hash;
/*      */     final CustomConcurrentHashMap.ReferenceEntry<K, V> next;
/*  824 */     volatile CustomConcurrentHashMap.ValueReference<K, V> valueReference = CustomConcurrentHashMap.access$200();
/*      */ 
/*      */     SoftEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  805 */       super(CustomConcurrentHashMap.QueueHolder.queue);
/*  806 */       this.map = map;
/*  807 */       this.hash = hash;
/*  808 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public K getKey() {
/*  812 */       return get();
/*      */     }
/*      */ 
/*      */     public void finalizeReferent() {
/*  816 */       this.map.removeEntry(this);
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<K, V> getValueReference()
/*      */     {
/*  827 */       return this.valueReference;
/*      */     }
/*      */ 
/*      */     public void setValueReference(CustomConcurrentHashMap.ValueReference<K, V> valueReference) {
/*  831 */       this.valueReference = valueReference;
/*      */     }
/*      */     public void valueReclaimed() {
/*  834 */       this.map.reclaimValue(this);
/*      */     }
/*      */     public int getHash() {
/*  837 */       return this.hash;
/*      */     }
/*      */     public CustomConcurrentHashMap.ReferenceEntry<K, V> getNext() {
/*  840 */       return this.next;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class StrongExpirableEvictableEntry<K, V> extends CustomConcurrentHashMap.StrongEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Expirable, CustomConcurrentHashMap.Evictable
/*      */   {
/*  761 */     volatile long writeTime = 9223372036854775807L;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  769 */     CustomConcurrentHashMap.Expirable next = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  778 */     CustomConcurrentHashMap.Expirable previous = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */     volatile int lastUsage;
/*      */ 
/*      */     StrongExpirableEvictableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  756 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/*  763 */       return this.writeTime;
/*      */     }
/*      */     public void setWriteTime(long writeTime) {
/*  766 */       this.writeTime = writeTime;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable()
/*      */     {
/*  772 */       return this.next;
/*      */     }
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/*  775 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */     {
/*  781 */       return this.previous;
/*      */     }
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/*  784 */       this.previous = previous;
/*      */     }
/*      */ 
/*      */     public int getLastUsage()
/*      */     {
/*  791 */       return this.lastUsage;
/*      */     }
/*      */     public void setLastUsage(int lastUsage) {
/*  794 */       this.lastUsage = lastUsage;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class StrongEvictableEntry<K, V> extends CustomConcurrentHashMap.StrongEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Evictable
/*      */   {
/*      */     volatile int lastUsage;
/*      */ 
/*      */     StrongEvictableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  738 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public int getLastUsage()
/*      */     {
/*  745 */       return this.lastUsage;
/*      */     }
/*      */     public void setLastUsage(int lastUsage) {
/*  748 */       this.lastUsage = lastUsage;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class StrongExpirableEntry<K, V> extends CustomConcurrentHashMap.StrongEntry<K, V>
/*      */     implements CustomConcurrentHashMap.Expirable
/*      */   {
/*  707 */     volatile long writeTime = 9223372036854775807L;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  715 */     CustomConcurrentHashMap.Expirable next = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*  724 */     CustomConcurrentHashMap.Expirable previous = CustomConcurrentHashMap.NullExpirable.INSTANCE;
/*      */ 
/*      */     StrongExpirableEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  702 */       super(key, hash, next);
/*      */     }
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/*  709 */       return this.writeTime;
/*      */     }
/*      */     public void setWriteTime(long writeTime) {
/*  712 */       this.writeTime = writeTime;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable()
/*      */     {
/*  718 */       return this.next;
/*      */     }
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/*  721 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable()
/*      */     {
/*  727 */       return this.previous;
/*      */     }
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous) {
/*  730 */       this.previous = previous;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class StrongEntry<K, V>
/*      */     implements CustomConcurrentHashMap.ReferenceEntry<K, V>
/*      */   {
/*      */     final K key;
/*      */     final CustomConcurrentHashMap<K, V> map;
/*      */     final int hash;
/*      */     final CustomConcurrentHashMap.ReferenceEntry<K, V> next;
/*  678 */     volatile CustomConcurrentHashMap.ValueReference<K, V> valueReference = CustomConcurrentHashMap.access$200();
/*      */ 
/*      */     StrongEntry(CustomConcurrentHashMap<K, V> map, K key, int hash, CustomConcurrentHashMap.ReferenceEntry<K, V> next)
/*      */     {
/*  663 */       this.map = map;
/*  664 */       this.key = key;
/*  665 */       this.hash = hash;
/*  666 */       this.next = next;
/*      */     }
/*      */ 
/*      */     public K getKey() {
/*  670 */       return this.key;
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.ValueReference<K, V> getValueReference()
/*      */     {
/*  681 */       return this.valueReference;
/*      */     }
/*      */ 
/*      */     public void setValueReference(CustomConcurrentHashMap.ValueReference<K, V> valueReference) {
/*  685 */       this.valueReference = valueReference;
/*      */     }
/*      */     public void valueReclaimed() {
/*  688 */       this.map.reclaimValue(this);
/*      */     }
/*      */     public int getHash() {
/*  691 */       return this.hash;
/*      */     }
/*      */     public CustomConcurrentHashMap.ReferenceEntry<K, V> getNext() {
/*  694 */       return this.next;
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract interface Evictable
/*      */   {
/*      */     public abstract void setLastUsage(int paramInt);
/*      */ 
/*      */     public abstract int getLastUsage();
/*      */   }
/*      */ 
/*      */   private static enum NullExpirable
/*      */     implements CustomConcurrentHashMap.Expirable
/*      */   {
/*  611 */     INSTANCE;
/*      */ 
/*      */     public long getWriteTime()
/*      */     {
/*  615 */       return 0L;
/*      */     }
/*      */ 
/*      */     public void setWriteTime(long writeTime) {
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getNextExpirable() {
/*  622 */       return this;
/*      */     }
/*      */ 
/*      */     public void setNextExpirable(CustomConcurrentHashMap.Expirable next) {
/*      */     }
/*      */ 
/*      */     public CustomConcurrentHashMap.Expirable getPreviousExpirable() {
/*  629 */       return this;
/*      */     }
/*      */ 
/*      */     public void setPreviousExpirable(CustomConcurrentHashMap.Expirable previous)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract interface Expirable
/*      */   {
/*      */     public abstract long getWriteTime();
/*      */ 
/*      */     public abstract void setWriteTime(long paramLong);
/*      */ 
/*      */     public abstract Expirable getNextExpirable();
/*      */ 
/*      */     public abstract void setNextExpirable(Expirable paramExpirable);
/*      */ 
/*      */     public abstract Expirable getPreviousExpirable();
/*      */ 
/*      */     public abstract void setPreviousExpirable(Expirable paramExpirable);
/*      */   }
/*      */ 
/*      */   static abstract interface ReferenceEntry<K, V>
/*      */   {
/*      */     public abstract CustomConcurrentHashMap.ValueReference<K, V> getValueReference();
/*      */ 
/*      */     public abstract void setValueReference(CustomConcurrentHashMap.ValueReference<K, V> paramValueReference);
/*      */ 
/*      */     public abstract void valueReclaimed();
/*      */ 
/*      */     public abstract ReferenceEntry<K, V> getNext();
/*      */ 
/*      */     public abstract int getHash();
/*      */ 
/*      */     public abstract K getKey();
/*      */   }
/*      */ 
/*      */   private static class QueueHolder
/*      */   {
/*  548 */     static final FinalizableReferenceQueue queue = new FinalizableReferenceQueue();
/*      */   }
/*      */ 
/*      */   static abstract interface ValueReference<K, V>
/*      */   {
/*      */     public abstract V get();
/*      */ 
/*      */     public abstract ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> paramReferenceEntry);
/*      */ 
/*      */     public abstract V waitForValue()
/*      */       throws InterruptedException;
/*      */   }
/*      */ 
/*      */   static abstract enum EntryFactory
/*      */   {
/*  280 */     STRONG, 
/*      */ 
/*  287 */     STRONG_EXPIRABLE, 
/*      */ 
/*  301 */     STRONG_EVICTABLE, 
/*      */ 
/*  315 */     STRONG_EXPIRABLE_EVICTABLE, 
/*      */ 
/*  331 */     SOFT, 
/*      */ 
/*  338 */     SOFT_EXPIRABLE, 
/*      */ 
/*  352 */     SOFT_EVICTABLE, 
/*      */ 
/*  366 */     SOFT_EXPIRABLE_EVICTABLE, 
/*      */ 
/*  382 */     WEAK, 
/*      */ 
/*  389 */     WEAK_EXPIRABLE, 
/*      */ 
/*  403 */     WEAK_EVICTABLE, 
/*      */ 
/*  417 */     WEAK_EXPIRABLE_EVICTABLE;
/*      */ 
/*      */     static final int EXPIRABLE_MASK = 1;
/*      */     static final int EVICTABLE_MASK = 2;
/*      */     static final EntryFactory[][] FACTORIES;
/*      */ 
/*      */     static EntryFactory getFactory(CustomConcurrentHashMap.Strength keyStrength, boolean expires, boolean evicts)
/*      */     {
/*  451 */       int flags = (expires ? 1 : 0) | (evicts ? 2 : 0);
/*      */ 
/*  453 */       return FACTORIES[keyStrength.ordinal()][flags];
/*      */     }
/*      */ 
/*      */     abstract <K, V> CustomConcurrentHashMap.ReferenceEntry<K, V> newEntry(CustomConcurrentHashMap<K, V> paramCustomConcurrentHashMap, K paramK, int paramInt, CustomConcurrentHashMap.ReferenceEntry<K, V> paramReferenceEntry);
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     <K, V> CustomConcurrentHashMap.ReferenceEntry<K, V> copyEntry(CustomConcurrentHashMap<K, V> map, CustomConcurrentHashMap.ReferenceEntry<K, V> original, CustomConcurrentHashMap.ReferenceEntry<K, V> newNext)
/*      */     {
/*  478 */       return newEntry(map, original.getKey(), original.getHash(), newNext);
/*      */     }
/*      */ 
/*      */     @GuardedBy("Segment.this")
/*      */     <K, V> void copyExpirableEntry(CustomConcurrentHashMap.ReferenceEntry<K, V> original, CustomConcurrentHashMap.ReferenceEntry<K, V> newEntry) {
/*  484 */       CustomConcurrentHashMap.Expirable originalExpirable = (CustomConcurrentHashMap.Expirable)original;
/*  485 */       CustomConcurrentHashMap.Expirable newExpirable = (CustomConcurrentHashMap.Expirable)newEntry;
/*  486 */       newExpirable.setWriteTime(originalExpirable.getWriteTime());
/*      */ 
/*  488 */       CustomConcurrentHashMap.connectExpirable(originalExpirable.getPreviousExpirable(), newExpirable);
/*  489 */       CustomConcurrentHashMap.connectExpirable(newExpirable, originalExpirable.getNextExpirable());
/*      */ 
/*  491 */       CustomConcurrentHashMap.nullifyExpirable(originalExpirable);
/*      */     }
/*      */ 
/*      */     <K, V> void copyEvictableEntry(CustomConcurrentHashMap.ReferenceEntry<K, V> original, CustomConcurrentHashMap.ReferenceEntry<K, V> newEntry)
/*      */     {
/*  496 */       CustomConcurrentHashMap.Evictable originalEvictable = (CustomConcurrentHashMap.Evictable)original;
/*  497 */       CustomConcurrentHashMap.Evictable newEvictable = (CustomConcurrentHashMap.Evictable)newEntry;
/*  498 */       newEvictable.setLastUsage(originalEvictable.getLastUsage());
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  443 */       FACTORIES = new EntryFactory[][] { { STRONG, STRONG_EXPIRABLE, STRONG_EVICTABLE, STRONG_EXPIRABLE_EVICTABLE }, { SOFT, SOFT_EXPIRABLE, SOFT_EVICTABLE, SOFT_EXPIRABLE_EVICTABLE }, { WEAK, WEAK_EXPIRABLE, WEAK_EVICTABLE, WEAK_EXPIRABLE_EVICTABLE } };
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract enum Strength
/*      */   {
/*  228 */     STRONG, 
/*      */ 
/*  238 */     SOFT, 
/*      */ 
/*  248 */     WEAK;
/*      */ 
/*      */     abstract <K, V> CustomConcurrentHashMap.ValueReference<K, V> referenceValue(CustomConcurrentHashMap.ReferenceEntry<K, V> paramReferenceEntry, V paramV);
/*      */ 
/*      */     abstract Equivalence<Object> defaultEquivalence();
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.CustomConcurrentHashMap
 * JD-Core Version:    0.6.0
 */