/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Lists;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.MessageLite;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.MessageLite.Builder;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ final class Proto2BuilderAdapter<T extends ProtocolMessage<T>>
/*     */   implements MessageLite.Builder
/*     */ {
/*     */   private T proto;
/*     */   private static final String PARSING_ERROR = "Error parsing protocol message";
/*     */ 
/*     */   Proto2BuilderAdapter(T proto)
/*     */   {
/*  32 */     this.proto = proto;
/*     */   }
/*     */ 
/*     */   public MessageLite getDefaultInstanceForType()
/*     */   {
/*  37 */     return this.proto.getDefaultInstanceForType();
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder clear()
/*     */   {
/*  42 */     this.proto.clear();
/*  43 */     return this;
/*     */   }
/*     */ 
/*     */   public MessageLite build()
/*     */   {
/*  48 */     if (!this.proto.isInitialized()) {
/*  49 */       throw new UninitializedMessageException(Lists.newArrayList(new String[] { this.proto.findInitializationError() }));
/*     */     }
/*     */ 
/*  52 */     MessageLite result = this.proto;
/*  53 */     this.proto = null;
/*  54 */     return result;
/*     */   }
/*     */ 
/*     */   public MessageLite buildPartial()
/*     */   {
/*  59 */     return this.proto;
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder clone()
/*     */   {
/*  64 */     return new Proto2BuilderAdapter(this.proto.clone());
/*     */   }
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/*  69 */     return this.proto.isInitialized();
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(CodedInputStream input)
/*     */     throws IOException
/*     */   {
/*  86 */     int messageSize = input.getBytesUntilLimit();
/*     */     byte[] bytes;
/*  87 */     if (messageSize == -1)
/*     */     {
/*  93 */       int pos = 0;
/*  94 */       byte[] bytes = new byte[1024];
/*  95 */       while (!input.isAtEnd()) {
/*  96 */         bytes[(pos++)] = input.readRawByte();
/*  97 */         if (pos == bytes.length) {
/*  98 */           byte[] oldBytes = bytes;
/*  99 */           bytes = new byte[oldBytes.length * 2];
/* 100 */           System.arraycopy(oldBytes, 0, bytes, 0, oldBytes.length);
/*     */         }
/*     */       }
/* 103 */       messageSize = pos;
/*     */     }
/*     */     else {
/* 106 */       bytes = input.readRawBytes(messageSize);
/*     */     }
/*     */ 
/* 109 */     return mergeFrom(bytes, 0, messageSize);
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*     */     throws IOException
/*     */   {
/* 125 */     return mergeFrom(input);
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(ByteString data)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 139 */     InputStream input = data.newInput();
/*     */     try
/*     */     {
/* 144 */       return mergeFrom(input);
/*     */     } catch (InvalidProtocolBufferException ex) {
/* 146 */       throw ex;
/*     */     } catch (IOException ex) {
/*     */     }
/* 149 */     throw new IllegalStateException(ex);
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 167 */     return mergeFrom(data);
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(byte[] data)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 173 */     if (!this.proto.mergeFrom(data)) {
/* 174 */       throw new InvalidProtocolBufferException("Error parsing protocol message");
/*     */     }
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(byte[] data, int off, int len)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 182 */     if (!this.proto.mergeFrom(data, off, len)) {
/* 183 */       throw new InvalidProtocolBufferException("Error parsing protocol message");
/*     */     }
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 198 */     return mergeFrom(data);
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(byte[] data, int off, int len, ExtensionRegistryLite extensionRegistry)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 211 */     return mergeFrom(data, off, len);
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(InputStream input) throws IOException
/*     */   {
/* 216 */     if (!this.proto.mergeFrom(input)) {
/* 217 */       throw new IOException("Error parsing protocol message");
/*     */     }
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   public MessageLite.Builder mergeFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */     throws IOException
/*     */   {
/* 231 */     return mergeFrom(input);
/*     */   }
/*     */ 
/*     */   public boolean mergeDelimitedFrom(InputStream input)
/*     */     throws IOException
/*     */   {
/* 246 */     int firstByte = input.read();
/* 247 */     if (firstByte == -1) {
/* 248 */       return false;
/*     */     }
/*     */ 
/* 251 */     int size = CodedInputStream.readRawVarint32(firstByte, input);
/* 252 */     if (size < 0) {
/* 253 */       throw new IOException("Negative message size read from stream: " + size);
/*     */     }
/*     */ 
/* 256 */     byte[] bytes = new byte[size];
/* 257 */     int remaining = size;
/* 258 */     int off = 0;
/* 259 */     while (remaining > 0) {
/* 260 */       int bytesRead = input.read(bytes, off, remaining);
/* 261 */       if (bytesRead == -1) {
/* 262 */         throw new IOException("EOF reached unexpectedly at position " + off);
/*     */       }
/* 264 */       remaining -= bytesRead;
/* 265 */       off += bytesRead;
/*     */     }
/*     */ 
/* 268 */     mergeFrom(bytes);
/* 269 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean mergeDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */     throws IOException
/*     */   {
/* 284 */     return mergeDelimitedFrom(input);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.Proto2BuilderAdapter
 * JD-Core Version:    0.6.0
 */