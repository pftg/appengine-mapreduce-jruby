/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible
/*    */ @GoogleInternal
/*    */ public final class BackDoorsForLabs
/*    */ {
/*    */   public static <K, V> Multimap<K, V> synchronizedMultimap(Multimap<K, V> multimap, @Nullable Object mutex)
/*    */   {
/* 28 */     return Synchronized.multimap(multimap, mutex);
/*    */   }
/*    */ 
/*    */   public static abstract class BadAbstractMultiset<E> extends AbstractMultiset<E>
/*    */   {
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.BackDoorsForLabs
 * JD-Core Version:    0.6.0
 */