/*      */ package com.google.apphosting.api;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import com.google.net.rpc.DefaultStubCreationFilter;
/*      */ import com.google.net.rpc.RPC;
/*      */ import com.google.net.rpc.RpcCallback;
/*      */ import com.google.net.rpc.RpcCancelCallback;
/*      */ import com.google.net.rpc.RpcException;
/*      */ import com.google.net.rpc.RpcInterface;
/*      */ import com.google.net.rpc.RpcServerParameters;
/*      */ import com.google.net.rpc.RpcService;
/*      */ import com.google.net.rpc.RpcStub;
/*      */ import com.google.net.rpc.RpcStubFactory;
/*      */ import com.google.net.rpc.RpcStubParameters;
/*      */ import com.google.net.rpc.StubCreationFilter;
/*      */ import com.google.net.rpc.impl.ApplicationHandler;
/*      */ import com.google.net.rpc.impl.BlockingApplicationHandler;
/*      */ import com.google.net.rpc.impl.RpcHandlerRegistry;
/*      */ import com.google.net.rpc.impl.RpcServerConfig;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1CompatibilityStub;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1HandlerRegistry;
/*      */ import com.google.net.rpc3.server.RpcServer.Builder;
/*      */ import com.google.net.ssl.SslSecurityLevel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Arrays;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ public class UserServicePb
/*      */ {
/*      */   public static final class UserService
/*      */   {
/* 4212 */     private static volatile StubCreationFilter stubCreationFilter_ = new DefaultStubCreationFilter();
/*      */ 
/* 4218 */     private static final RpcStubFactory stubFactory_ = new RpcStubFactory() {
/*      */       public RpcStub newRpcStub(RpcStubParameters params) {
/* 4220 */         return new UserServicePb.UserService.SimpleStub(UserServicePb.UserService.stubCreationFilter_.filterStubParameters("UserService", params));
/*      */       }
/* 4218 */     };
/*      */ 
/*      */     public static void setStubCreationFilter(StubCreationFilter filter)
/*      */     {
/* 4215 */       stubCreationFilter_ = filter == null ? new DefaultStubCreationFilter() : filter;
/*      */     }
/*      */ 
/*      */     public static RpcStubFactory stubFactory()
/*      */     {
/* 4224 */       return stubFactory_;
/*      */     }
/*      */ 
/*      */     public static BlockingStub newBlockingStub(RpcStubParameters params)
/*      */     {
/* 4307 */       return new BlockingStub(stubCreationFilter_.filterStubParameters("UserService", params));
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcStubParameters params)
/*      */     {
/* 4350 */       return new Stub(stubCreationFilter_.filterStubParameters("UserService", params));
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcHandlerRegistry registry)
/*      */     {
/* 4455 */       ServerConfig config = new ServerConfig();
/* 4456 */       exportServiceUsingConfig(service, registry, config);
/* 4457 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 4463 */       registry.registerHandler(config.serviceName(), "CreateLoginURL", new UserServicePb.CreateLoginURLRequest(), new UserServicePb.CreateLoginURLResponse(), null, config.CreateLoginURL_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 4467 */           this.val$service.createLoginURL(rpc, (UserServicePb.CreateLoginURLRequest)rpc.internalRequest(), (UserServicePb.CreateLoginURLResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 4471 */       registry.registerHandler(config.serviceName(), "CreateLogoutURL", new UserServicePb.CreateLogoutURLRequest(), new UserServicePb.CreateLogoutURLResponse(), null, config.CreateLogoutURL_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 4475 */           this.val$service.createLogoutURL(rpc, (UserServicePb.CreateLogoutURLRequest)rpc.internalRequest(), (UserServicePb.CreateLogoutURLResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 4479 */       registry.registerHandler(config.serviceName(), "GetOAuthUser", new UserServicePb.GetOAuthUserRequest(), new UserServicePb.GetOAuthUserResponse(), null, config.GetOAuthUser_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 4483 */           this.val$service.getOAuthUser(rpc, (UserServicePb.GetOAuthUserRequest)rpc.internalRequest(), (UserServicePb.GetOAuthUserResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 4487 */       registry.registerHandler(config.serviceName(), "CheckOAuthSignature", new UserServicePb.CheckOAuthSignatureRequest(), new UserServicePb.CheckOAuthSignatureResponse(), null, config.CheckOAuthSignature_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 4491 */           this.val$service.checkOAuthSignature(rpc, (UserServicePb.CheckOAuthSignatureRequest)rpc.internalRequest(), (UserServicePb.CheckOAuthSignatureResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 4495 */       registry.registerHandler(config.serviceName(), "CreateFederatedLoginURL", new UserServicePb.CreateFederatedLoginRequest(), new UserServicePb.CreateFederatedLoginResponse(), null, config.CreateFederatedLoginURL_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 4499 */           this.val$service.createFederatedLoginURL(rpc, (UserServicePb.CreateFederatedLoginRequest)rpc.internalRequest(), (UserServicePb.CreateFederatedLoginResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 4503 */       registry.registerHandler(config.serviceName(), "CreateFederatedLogoutURL", new UserServicePb.CreateFederatedLogoutRequest(), new UserServicePb.CreateFederatedLogoutResponse(), null, config.CreateFederatedLogoutURL_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 4507 */           this.val$service.createFederatedLogoutURL(rpc, (UserServicePb.CreateFederatedLogoutRequest)rpc.internalRequest(), (UserServicePb.CreateFederatedLogoutResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     public static RpcService newService(Interface impl) {
/* 4514 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 4516 */           return UserServicePb.UserService.exportService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcServer.Builder builder) {
/* 4523 */       ServerConfig config = new ServerConfig();
/* 4524 */       exportServiceUsingConfig(service, builder, config);
/* 4525 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 4531 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 4532 */       exportServiceUsingConfig(service, registry, config);
/* 4533 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcHandlerRegistry registry)
/*      */     {
/* 4538 */       ServerConfig config = new ServerConfig();
/* 4539 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 4540 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 4546 */       registry.registerHandler(config.serviceName(), "CreateLoginURL", new UserServicePb.CreateLoginURLRequest(), new UserServicePb.CreateLoginURLResponse(), null, config.CreateLoginURL_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public UserServicePb.CreateLoginURLResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 4550 */           return this.val$service.createLoginURL(rpc, (UserServicePb.CreateLoginURLRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 4553 */       registry.registerHandler(config.serviceName(), "CreateLogoutURL", new UserServicePb.CreateLogoutURLRequest(), new UserServicePb.CreateLogoutURLResponse(), null, config.CreateLogoutURL_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public UserServicePb.CreateLogoutURLResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 4557 */           return this.val$service.createLogoutURL(rpc, (UserServicePb.CreateLogoutURLRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 4560 */       registry.registerHandler(config.serviceName(), "GetOAuthUser", new UserServicePb.GetOAuthUserRequest(), new UserServicePb.GetOAuthUserResponse(), null, config.GetOAuthUser_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public UserServicePb.GetOAuthUserResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 4564 */           return this.val$service.getOAuthUser(rpc, (UserServicePb.GetOAuthUserRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 4567 */       registry.registerHandler(config.serviceName(), "CheckOAuthSignature", new UserServicePb.CheckOAuthSignatureRequest(), new UserServicePb.CheckOAuthSignatureResponse(), null, config.CheckOAuthSignature_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public UserServicePb.CheckOAuthSignatureResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 4571 */           return this.val$service.checkOAuthSignature(rpc, (UserServicePb.CheckOAuthSignatureRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 4574 */       registry.registerHandler(config.serviceName(), "CreateFederatedLoginURL", new UserServicePb.CreateFederatedLoginRequest(), new UserServicePb.CreateFederatedLoginResponse(), null, config.CreateFederatedLoginURL_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public UserServicePb.CreateFederatedLoginResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 4578 */           return this.val$service.createFederatedLoginURL(rpc, (UserServicePb.CreateFederatedLoginRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 4581 */       registry.registerHandler(config.serviceName(), "CreateFederatedLogoutURL", new UserServicePb.CreateFederatedLogoutRequest(), new UserServicePb.CreateFederatedLogoutResponse(), null, config.CreateFederatedLogoutURL_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public UserServicePb.CreateFederatedLogoutResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 4585 */           return this.val$service.createFederatedLogoutURL(rpc, (UserServicePb.CreateFederatedLogoutRequest)rpc.internalRequest());
/*      */         } } );
/*      */     }
/*      */ 
/*      */     public static RpcService newBlockingService(BlockingInterface impl) {
/* 4591 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 4593 */           return UserServicePb.UserService.exportBlockingService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcServer.Builder builder) {
/* 4600 */       ServerConfig config = new ServerConfig();
/* 4601 */       exportBlockingServiceUsingConfig(service, builder, config);
/* 4602 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 4608 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 4609 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 4610 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static void unexport(RpcHandlerRegistry registry) {
/* 4614 */       registry.unregisterService("UserService");
/*      */     }
/*      */ 
/*      */     public static class ServerConfig extends RpcServerConfig
/*      */     {
/* 4354 */       final RpcServerParameters CreateLoginURL_parameters_ = new RpcServerParameters();
/* 4355 */       final RpcServerParameters CreateLogoutURL_parameters_ = new RpcServerParameters();
/* 4356 */       final RpcServerParameters GetOAuthUser_parameters_ = new RpcServerParameters();
/* 4357 */       final RpcServerParameters CheckOAuthSignature_parameters_ = new RpcServerParameters();
/* 4358 */       final RpcServerParameters CreateFederatedLoginURL_parameters_ = new RpcServerParameters();
/* 4359 */       final RpcServerParameters CreateFederatedLogoutURL_parameters_ = new RpcServerParameters();
/*      */ 
/*      */       public ServerConfig() {
/* 4362 */         this("UserService");
/*      */       }
/*      */       public ServerConfig(String serviceName) {
/* 4365 */         super();
/*      */       }
/*      */       public void setRpcRunner(Executor t) {
/* 4368 */         setRpcRunner_CreateLoginURL(t);
/* 4369 */         setRpcRunner_CreateLogoutURL(t);
/* 4370 */         setRpcRunner_GetOAuthUser(t);
/* 4371 */         setRpcRunner_CheckOAuthSignature(t);
/* 4372 */         setRpcRunner_CreateFederatedLoginURL(t);
/* 4373 */         setRpcRunner_CreateFederatedLogoutURL(t);
/*      */       }
/*      */ 
/*      */       public void setRpcRunner_CreateLoginURL(Executor t) {
/* 4377 */         this.CreateLoginURL_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_CreateLogoutURL(Executor t) {
/* 4380 */         this.CreateLogoutURL_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_GetOAuthUser(Executor t) {
/* 4383 */         this.GetOAuthUser_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_CheckOAuthSignature(Executor t) {
/* 4386 */         this.CheckOAuthSignature_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_CreateFederatedLoginURL(Executor t) {
/* 4389 */         this.CreateFederatedLoginURL_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_CreateFederatedLogoutURL(Executor t) {
/* 4392 */         this.CreateFederatedLogoutURL_parameters_.setRpcRunner(t);
/*      */       }
/*      */ 
/*      */       public void setServerLogging_CreateLoginURL(int t) {
/* 4396 */         this.CreateLoginURL_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_CreateLogoutURL(int t) {
/* 4399 */         this.CreateLogoutURL_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_GetOAuthUser(int t) {
/* 4402 */         this.GetOAuthUser_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_CheckOAuthSignature(int t) {
/* 4405 */         this.CheckOAuthSignature_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_CreateFederatedLoginURL(int t) {
/* 4408 */         this.CreateFederatedLoginURL_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_CreateFederatedLogoutURL(int t) {
/* 4411 */         this.CreateFederatedLogoutURL_parameters_.setServerLogging(t);
/*      */       }
/*      */ 
/*      */       public void setSecurityLevel_CreateLoginURL(SslSecurityLevel t) {
/* 4415 */         this.CreateLoginURL_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_CreateLogoutURL(SslSecurityLevel t) {
/* 4418 */         this.CreateLogoutURL_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_GetOAuthUser(SslSecurityLevel t) {
/* 4421 */         this.GetOAuthUser_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_CheckOAuthSignature(SslSecurityLevel t) {
/* 4424 */         this.CheckOAuthSignature_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_CreateFederatedLoginURL(SslSecurityLevel t) {
/* 4427 */         this.CreateFederatedLoginURL_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_CreateFederatedLogoutURL(SslSecurityLevel t) {
/* 4430 */         this.CreateFederatedLogoutURL_parameters_.setSecurityLevel(t);
/*      */       }
/*      */ 
/*      */       public void setRpcCancelCallback_CreateLoginURL(RpcCancelCallback t) {
/* 4434 */         this.CreateLoginURL_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_CreateLogoutURL(RpcCancelCallback t) {
/* 4437 */         this.CreateLogoutURL_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_GetOAuthUser(RpcCancelCallback t) {
/* 4440 */         this.GetOAuthUser_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_CheckOAuthSignature(RpcCancelCallback t) {
/* 4443 */         this.CheckOAuthSignature_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_CreateFederatedLoginURL(RpcCancelCallback t) {
/* 4446 */         this.CreateFederatedLoginURL_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_CreateFederatedLogoutURL(RpcCancelCallback t) {
/* 4449 */         this.CreateFederatedLogoutURL_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class Stub extends UserServicePb.UserService.BlockingStub
/*      */       implements UserServicePb.UserService.Interface
/*      */     {
/*      */       Stub(RpcStubParameters params)
/*      */       {
/* 4321 */         super();
/*      */       }
/*      */       public void createLoginURL(RPC rpc, UserServicePb.CreateLoginURLRequest req, UserServicePb.CreateLoginURLResponse reply, RpcCallback cb) {
/* 4324 */         startNonBlockingRpc(rpc, this.CreateLoginURL_method_, "CreateLoginURL", req, reply, cb, this.CreateLoginURL_parameters_);
/*      */       }
/*      */ 
/*      */       public void createLogoutURL(RPC rpc, UserServicePb.CreateLogoutURLRequest req, UserServicePb.CreateLogoutURLResponse reply, RpcCallback cb) {
/* 4328 */         startNonBlockingRpc(rpc, this.CreateLogoutURL_method_, "CreateLogoutURL", req, reply, cb, this.CreateLogoutURL_parameters_);
/*      */       }
/*      */ 
/*      */       public void getOAuthUser(RPC rpc, UserServicePb.GetOAuthUserRequest req, UserServicePb.GetOAuthUserResponse reply, RpcCallback cb) {
/* 4332 */         startNonBlockingRpc(rpc, this.GetOAuthUser_method_, "GetOAuthUser", req, reply, cb, this.GetOAuthUser_parameters_);
/*      */       }
/*      */ 
/*      */       public void checkOAuthSignature(RPC rpc, UserServicePb.CheckOAuthSignatureRequest req, UserServicePb.CheckOAuthSignatureResponse reply, RpcCallback cb) {
/* 4336 */         startNonBlockingRpc(rpc, this.CheckOAuthSignature_method_, "CheckOAuthSignature", req, reply, cb, this.CheckOAuthSignature_parameters_);
/*      */       }
/*      */ 
/*      */       public void createFederatedLoginURL(RPC rpc, UserServicePb.CreateFederatedLoginRequest req, UserServicePb.CreateFederatedLoginResponse reply, RpcCallback cb) {
/* 4340 */         startNonBlockingRpc(rpc, this.CreateFederatedLoginURL_method_, "CreateFederatedLoginURL", req, reply, cb, this.CreateFederatedLoginURL_parameters_);
/*      */       }
/*      */ 
/*      */       public void createFederatedLogoutURL(RPC rpc, UserServicePb.CreateFederatedLogoutRequest req, UserServicePb.CreateFederatedLogoutResponse reply, RpcCallback cb) {
/* 4344 */         startNonBlockingRpc(rpc, this.CreateFederatedLogoutURL_method_, "CreateFederatedLogoutURL", req, reply, cb, this.CreateFederatedLogoutURL_parameters_);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface extends RpcInterface
/*      */     {
/*      */       public abstract void createLoginURL(RPC paramRPC, UserServicePb.CreateLoginURLRequest paramCreateLoginURLRequest, UserServicePb.CreateLoginURLResponse paramCreateLoginURLResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void createLogoutURL(RPC paramRPC, UserServicePb.CreateLogoutURLRequest paramCreateLogoutURLRequest, UserServicePb.CreateLogoutURLResponse paramCreateLogoutURLResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void getOAuthUser(RPC paramRPC, UserServicePb.GetOAuthUserRequest paramGetOAuthUserRequest, UserServicePb.GetOAuthUserResponse paramGetOAuthUserResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void checkOAuthSignature(RPC paramRPC, UserServicePb.CheckOAuthSignatureRequest paramCheckOAuthSignatureRequest, UserServicePb.CheckOAuthSignatureResponse paramCheckOAuthSignatureResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void createFederatedLoginURL(RPC paramRPC, UserServicePb.CreateFederatedLoginRequest paramCreateFederatedLoginRequest, UserServicePb.CreateFederatedLoginResponse paramCreateFederatedLoginResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void createFederatedLogoutURL(RPC paramRPC, UserServicePb.CreateFederatedLogoutRequest paramCreateFederatedLogoutRequest, UserServicePb.CreateFederatedLogoutResponse paramCreateFederatedLogoutResponse, RpcCallback paramRpcCallback);
/*      */     }
/*      */ 
/*      */     public static class BlockingStub extends UserServicePb.UserService.BaseStub
/*      */       implements UserServicePb.UserService.BlockingInterface
/*      */     {
/*      */       BlockingStub(RpcStubParameters params)
/*      */       {
/* 4266 */         super();
/*      */       }
/*      */       public UserServicePb.CreateLoginURLResponse createLoginURL(RPC rpc, UserServicePb.CreateLoginURLRequest req) throws RpcException {
/* 4269 */         UserServicePb.CreateLoginURLResponse reply = new UserServicePb.CreateLoginURLResponse();
/* 4270 */         startBlockingRpc(rpc, this.CreateLoginURL_method_, "CreateLoginURL", req, reply, this.CreateLoginURL_parameters_);
/*      */ 
/* 4272 */         return reply;
/*      */       }
/*      */       public UserServicePb.CreateLogoutURLResponse createLogoutURL(RPC rpc, UserServicePb.CreateLogoutURLRequest req) throws RpcException {
/* 4275 */         UserServicePb.CreateLogoutURLResponse reply = new UserServicePb.CreateLogoutURLResponse();
/* 4276 */         startBlockingRpc(rpc, this.CreateLogoutURL_method_, "CreateLogoutURL", req, reply, this.CreateLogoutURL_parameters_);
/*      */ 
/* 4278 */         return reply;
/*      */       }
/*      */       public UserServicePb.GetOAuthUserResponse getOAuthUser(RPC rpc, UserServicePb.GetOAuthUserRequest req) throws RpcException {
/* 4281 */         UserServicePb.GetOAuthUserResponse reply = new UserServicePb.GetOAuthUserResponse();
/* 4282 */         startBlockingRpc(rpc, this.GetOAuthUser_method_, "GetOAuthUser", req, reply, this.GetOAuthUser_parameters_);
/*      */ 
/* 4284 */         return reply;
/*      */       }
/*      */       public UserServicePb.CheckOAuthSignatureResponse checkOAuthSignature(RPC rpc, UserServicePb.CheckOAuthSignatureRequest req) throws RpcException {
/* 4287 */         UserServicePb.CheckOAuthSignatureResponse reply = new UserServicePb.CheckOAuthSignatureResponse();
/* 4288 */         startBlockingRpc(rpc, this.CheckOAuthSignature_method_, "CheckOAuthSignature", req, reply, this.CheckOAuthSignature_parameters_);
/*      */ 
/* 4290 */         return reply;
/*      */       }
/*      */       public UserServicePb.CreateFederatedLoginResponse createFederatedLoginURL(RPC rpc, UserServicePb.CreateFederatedLoginRequest req) throws RpcException {
/* 4293 */         UserServicePb.CreateFederatedLoginResponse reply = new UserServicePb.CreateFederatedLoginResponse();
/* 4294 */         startBlockingRpc(rpc, this.CreateFederatedLoginURL_method_, "CreateFederatedLoginURL", req, reply, this.CreateFederatedLoginURL_parameters_);
/*      */ 
/* 4296 */         return reply;
/*      */       }
/*      */       public UserServicePb.CreateFederatedLogoutResponse createFederatedLogoutURL(RPC rpc, UserServicePb.CreateFederatedLogoutRequest req) throws RpcException {
/* 4299 */         UserServicePb.CreateFederatedLogoutResponse reply = new UserServicePb.CreateFederatedLogoutResponse();
/* 4300 */         startBlockingRpc(rpc, this.CreateFederatedLogoutURL_method_, "CreateFederatedLogoutURL", req, reply, this.CreateFederatedLogoutURL_parameters_);
/*      */ 
/* 4302 */         return reply;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface extends RpcInterface
/*      */     {
/*      */       public abstract UserServicePb.CreateLoginURLResponse createLoginURL(RPC paramRPC, UserServicePb.CreateLoginURLRequest paramCreateLoginURLRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract UserServicePb.CreateLogoutURLResponse createLogoutURL(RPC paramRPC, UserServicePb.CreateLogoutURLRequest paramCreateLogoutURLRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract UserServicePb.GetOAuthUserResponse getOAuthUser(RPC paramRPC, UserServicePb.GetOAuthUserRequest paramGetOAuthUserRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract UserServicePb.CheckOAuthSignatureResponse checkOAuthSignature(RPC paramRPC, UserServicePb.CheckOAuthSignatureRequest paramCheckOAuthSignatureRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract UserServicePb.CreateFederatedLoginResponse createFederatedLoginURL(RPC paramRPC, UserServicePb.CreateFederatedLoginRequest paramCreateFederatedLoginRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract UserServicePb.CreateFederatedLogoutResponse createFederatedLogoutURL(RPC paramRPC, UserServicePb.CreateFederatedLogoutRequest paramCreateFederatedLogoutRequest)
/*      */         throws RpcException;
/*      */     }
/*      */ 
/*      */     private static class BaseStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       protected final String CreateLoginURL_method_;
/* 4242 */       protected final RPC CreateLoginURL_parameters_ = newRpcPrototype(UserServicePb.UserService.Method.CreateLoginURL);
/*      */       protected final String CreateLogoutURL_method_;
/* 4244 */       protected final RPC CreateLogoutURL_parameters_ = newRpcPrototype(UserServicePb.UserService.Method.CreateLogoutURL);
/*      */       protected final String GetOAuthUser_method_;
/* 4246 */       protected final RPC GetOAuthUser_parameters_ = newRpcPrototype(UserServicePb.UserService.Method.GetOAuthUser);
/*      */       protected final String CheckOAuthSignature_method_;
/* 4248 */       protected final RPC CheckOAuthSignature_parameters_ = newRpcPrototype(UserServicePb.UserService.Method.CheckOAuthSignature);
/*      */       protected final String CreateFederatedLoginURL_method_;
/* 4250 */       protected final RPC CreateFederatedLoginURL_parameters_ = newRpcPrototype(UserServicePb.UserService.Method.CreateFederatedLoginURL);
/*      */       protected final String CreateFederatedLogoutURL_method_;
/* 4252 */       protected final RPC CreateFederatedLogoutURL_parameters_ = newRpcPrototype(UserServicePb.UserService.Method.CreateFederatedLogoutURL);
/*      */ 
/*      */       protected BaseStub(RpcStubParameters params)
/*      */       {
/* 4232 */         super(params, UserServicePb.UserService.Method.class);
/* 4233 */         this.CreateLoginURL_method_ = makeFullMethodName("CreateLoginURL");
/* 4234 */         this.CreateLogoutURL_method_ = makeFullMethodName("CreateLogoutURL");
/* 4235 */         this.GetOAuthUser_method_ = makeFullMethodName("GetOAuthUser");
/* 4236 */         this.CheckOAuthSignature_method_ = makeFullMethodName("CheckOAuthSignature");
/* 4237 */         this.CreateFederatedLoginURL_method_ = makeFullMethodName("CreateFederatedLoginURL");
/* 4238 */         this.CreateFederatedLogoutURL_method_ = makeFullMethodName("CreateFederatedLogoutURL");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class SimpleStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       public SimpleStub(RpcStubParameters params)
/*      */       {
/* 4227 */         super(params, UserServicePb.UserService.Method.class);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Method
/*      */     {
/* 4204 */       CreateLoginURL, 
/* 4205 */       CreateLogoutURL, 
/* 4206 */       GetOAuthUser, 
/* 4207 */       CheckOAuthSignature, 
/* 4208 */       CreateFederatedLoginURL, 
/* 4209 */       CreateFederatedLogoutURL;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateFederatedLogoutResponse extends ProtocolMessage<CreateFederatedLogoutResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 3925 */     private byte[] logout_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateFederatedLogoutResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int klogout_url = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getLogoutUrlAsBytes()
/*      */     {
/* 3931 */       return this.logout_url_;
/*      */     }
/*      */     public final boolean hasLogoutUrl() {
/* 3934 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateFederatedLogoutResponse clearLogoutUrl() {
/* 3937 */       this.optional_0_ &= -2;
/* 3938 */       this.logout_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3939 */       return this;
/*      */     }
/*      */     public CreateFederatedLogoutResponse setLogoutUrlAsBytes(byte[] x) {
/* 3942 */       this.optional_0_ |= 1;
/* 3943 */       this.logout_url_ = x;
/* 3944 */       return this;
/*      */     }
/*      */     public final String getLogoutUrl() {
/* 3947 */       return ProtocolSupport.toStringUtf8(this.logout_url_);
/*      */     }
/*      */     public CreateFederatedLogoutResponse setLogoutUrl(String v) {
/* 3950 */       if (v == null) throw new NullPointerException();
/* 3951 */       this.optional_0_ |= 1;
/* 3952 */       this.logout_url_ = ProtocolSupport.toBytesUtf8(v);
/* 3953 */       return this;
/*      */     }
/*      */     public final String getLogoutUrl(Charset cs) {
/* 3956 */       return ProtocolSupport.toString(this.logout_url_, cs);
/*      */     }
/*      */     public CreateFederatedLogoutResponse setLogoutUrl(String v, Charset cs) {
/* 3959 */       if (v == null) throw new NullPointerException();
/* 3960 */       this.optional_0_ |= 1;
/* 3961 */       this.logout_url_ = ProtocolSupport.toBytes(v, cs);
/* 3962 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutResponse mergeFrom(CreateFederatedLogoutResponse that)
/*      */     {
/* 3969 */       assert (that != this);
/* 3970 */       int this_t0 = this.optional_0_;
/* 3971 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3973 */       if ((that_t0 & 0x1) != 0) {
/* 3974 */         this_t0 |= 1;
/* 3975 */         this.logout_url_ = that.logout_url_;
/*      */       }
/*      */ 
/* 3978 */       if (that.uninterpreted != null) {
/* 3979 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3981 */       this.optional_0_ = this_t0;
/* 3982 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateFederatedLogoutResponse that) {
/* 3986 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLogoutResponse that) {
/* 3990 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLogoutResponse that, boolean ignoreUninterpreted) {
/* 3994 */       if (that == null) return false;
/* 3995 */       if (that == this) return true;
/* 3996 */       int this_t0 = this.optional_0_;
/* 3997 */       int that_t0 = that.optional_0_;
/* 3998 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 4000 */       if (((this_t0 & 0x1) != 0) && 
/* 4001 */         (!Arrays.equals(this.logout_url_, that.logout_url_))) return false;
/*      */ 
/* 4004 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 4009 */       return ((that instanceof CreateFederatedLogoutResponse)) && (equals((CreateFederatedLogoutResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 4013 */       int hash = -1484865764;
/*      */ 
/* 4015 */       int this_t0 = this.optional_0_;
/* 4016 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.logout_url_) : -113);
/* 4017 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 4018 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 4020 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 4024 */       int this_t0 = this.optional_0_;
/*      */ 
/* 4026 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 4033 */       int n = 1 + Protocol.stringSize(this.logout_url_.length);
/*      */ 
/* 4035 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 4041 */       int n = 6 + this.logout_url_.length;
/*      */ 
/* 4043 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 4048 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 4052 */       this.optional_0_ = 0;
/* 4053 */       this.logout_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4054 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutResponse newInstance() {
/* 4058 */       return new CreateFederatedLogoutResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 4062 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 4081 */       sink.putByte(10);
/* 4082 */       sink.putPrefixedData(this.logout_url_);
/*      */ 
/* 4084 */       if (this.uninterpreted != null)
/* 4085 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 4090 */       boolean result = true;
/* 4091 */       int this_t0 = this.optional_0_;
/*      */ 
/* 4093 */       while (source.hasRemaining()) {
/* 4094 */         int tt = source.getVarInt();
/* 4095 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 4099 */           result = false;
/* 4100 */           break;
/*      */         case 10:
/* 4103 */           this.logout_url_ = source.getPrefixedData();
/* 4104 */           this_t0 |= 1;
/* 4105 */           break;
/*      */         default:
/* 4107 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4112 */       this.optional_0_ = this_t0;
/* 4113 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutResponse getDefaultInstanceForType()
/*      */     {
/* 4118 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateFederatedLogoutResponse getDefaultInstance() {
/* 4122 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutResponse freeze()
/*      */     {
/* 4170 */       this.logout_url_ = ProtocolSupport.freezeString(this.logout_url_);
/* 4171 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 4174 */       if (this.uninterpreted == null) {
/* 4175 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 4177 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4126 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateFederatedLogoutResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateFederatedLogoutResponse clearLogoutUrl()
/*      */         {
/* 4134 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutResponse setLogoutUrlAsBytes(byte[] x) {
/* 4137 */           ProtocolSupport.unsupportedOperation();
/* 4138 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutResponse setLogoutUrl(String v) {
/* 4141 */           ProtocolSupport.unsupportedOperation();
/* 4142 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutResponse setLogoutUrl(String v, Charset cs) {
/* 4145 */           ProtocolSupport.unsupportedOperation();
/* 4146 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateFederatedLogoutResponse mergeFrom(UserServicePb.CreateFederatedLogoutResponse that) {
/* 4150 */           ProtocolSupport.unsupportedOperation();
/* 4151 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 4154 */           ProtocolSupport.unsupportedOperation();
/* 4155 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutResponse freeze() {
/* 4158 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutResponse unfreeze() {
/* 4161 */           ProtocolSupport.unsupportedOperation();
/* 4162 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 4165 */           return true;
/*      */         }
/*      */       };
/* 4182 */       text = new String[2];
/*      */ 
/* 4184 */       text[0] = "ErrorCode";
/* 4185 */       text[1] = "logout_url";
/*      */ 
/* 4188 */       types = new int[2];
/*      */ 
/* 4190 */       Arrays.fill(types, 6);
/* 4191 */       types[0] = 0;
/* 4192 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 4066 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateFederatedLogoutResponse.class, "Z!apphosting/api/user_service.proto\n(apphosting.CreateFederatedLogoutResponse\023\032\nlogout_url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("logout_url", "logout_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateFederatedLogoutRequest extends ProtocolMessage<CreateFederatedLogoutRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 3646 */     private byte[] destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateFederatedLogoutRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kdestination_url = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getDestinationUrlAsBytes()
/*      */     {
/* 3652 */       return this.destination_url_;
/*      */     }
/*      */     public final boolean hasDestinationUrl() {
/* 3655 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateFederatedLogoutRequest clearDestinationUrl() {
/* 3658 */       this.optional_0_ &= -2;
/* 3659 */       this.destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3660 */       return this;
/*      */     }
/*      */     public CreateFederatedLogoutRequest setDestinationUrlAsBytes(byte[] x) {
/* 3663 */       this.optional_0_ |= 1;
/* 3664 */       this.destination_url_ = x;
/* 3665 */       return this;
/*      */     }
/*      */     public final String getDestinationUrl() {
/* 3668 */       return ProtocolSupport.toStringUtf8(this.destination_url_);
/*      */     }
/*      */     public CreateFederatedLogoutRequest setDestinationUrl(String v) {
/* 3671 */       if (v == null) throw new NullPointerException();
/* 3672 */       this.optional_0_ |= 1;
/* 3673 */       this.destination_url_ = ProtocolSupport.toBytesUtf8(v);
/* 3674 */       return this;
/*      */     }
/*      */     public final String getDestinationUrl(Charset cs) {
/* 3677 */       return ProtocolSupport.toString(this.destination_url_, cs);
/*      */     }
/*      */     public CreateFederatedLogoutRequest setDestinationUrl(String v, Charset cs) {
/* 3680 */       if (v == null) throw new NullPointerException();
/* 3681 */       this.optional_0_ |= 1;
/* 3682 */       this.destination_url_ = ProtocolSupport.toBytes(v, cs);
/* 3683 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutRequest mergeFrom(CreateFederatedLogoutRequest that)
/*      */     {
/* 3690 */       assert (that != this);
/* 3691 */       int this_t0 = this.optional_0_;
/* 3692 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3694 */       if ((that_t0 & 0x1) != 0) {
/* 3695 */         this_t0 |= 1;
/* 3696 */         this.destination_url_ = that.destination_url_;
/*      */       }
/*      */ 
/* 3699 */       if (that.uninterpreted != null) {
/* 3700 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3702 */       this.optional_0_ = this_t0;
/* 3703 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateFederatedLogoutRequest that) {
/* 3707 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLogoutRequest that) {
/* 3711 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLogoutRequest that, boolean ignoreUninterpreted) {
/* 3715 */       if (that == null) return false;
/* 3716 */       if (that == this) return true;
/* 3717 */       int this_t0 = this.optional_0_;
/* 3718 */       int that_t0 = that.optional_0_;
/* 3719 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 3721 */       if (((this_t0 & 0x1) != 0) && 
/* 3722 */         (!Arrays.equals(this.destination_url_, that.destination_url_))) return false;
/*      */ 
/* 3725 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3730 */       return ((that instanceof CreateFederatedLogoutRequest)) && (equals((CreateFederatedLogoutRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3734 */       int hash = -2026799978;
/*      */ 
/* 3736 */       int this_t0 = this.optional_0_;
/* 3737 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.destination_url_) : -113);
/* 3738 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3739 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3741 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3745 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3747 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3754 */       int n = 1 + Protocol.stringSize(this.destination_url_.length);
/*      */ 
/* 3756 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3762 */       int n = 6 + this.destination_url_.length;
/*      */ 
/* 3764 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3769 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3773 */       this.optional_0_ = 0;
/* 3774 */       this.destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3775 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutRequest newInstance() {
/* 3779 */       return new CreateFederatedLogoutRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3783 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3802 */       sink.putByte(10);
/* 3803 */       sink.putPrefixedData(this.destination_url_);
/*      */ 
/* 3805 */       if (this.uninterpreted != null)
/* 3806 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3811 */       boolean result = true;
/* 3812 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3814 */       while (source.hasRemaining()) {
/* 3815 */         int tt = source.getVarInt();
/* 3816 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3820 */           result = false;
/* 3821 */           break;
/*      */         case 10:
/* 3824 */           this.destination_url_ = source.getPrefixedData();
/* 3825 */           this_t0 |= 1;
/* 3826 */           break;
/*      */         default:
/* 3828 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3833 */       this.optional_0_ = this_t0;
/* 3834 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutRequest getDefaultInstanceForType()
/*      */     {
/* 3839 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateFederatedLogoutRequest getDefaultInstance() {
/* 3843 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLogoutRequest freeze()
/*      */     {
/* 3891 */       this.destination_url_ = ProtocolSupport.freezeString(this.destination_url_);
/* 3892 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 3895 */       if (this.uninterpreted == null) {
/* 3896 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3898 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3847 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateFederatedLogoutRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateFederatedLogoutRequest clearDestinationUrl()
/*      */         {
/* 3855 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutRequest setDestinationUrlAsBytes(byte[] x) {
/* 3858 */           ProtocolSupport.unsupportedOperation();
/* 3859 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutRequest setDestinationUrl(String v) {
/* 3862 */           ProtocolSupport.unsupportedOperation();
/* 3863 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutRequest setDestinationUrl(String v, Charset cs) {
/* 3866 */           ProtocolSupport.unsupportedOperation();
/* 3867 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateFederatedLogoutRequest mergeFrom(UserServicePb.CreateFederatedLogoutRequest that) {
/* 3871 */           ProtocolSupport.unsupportedOperation();
/* 3872 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3875 */           ProtocolSupport.unsupportedOperation();
/* 3876 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutRequest freeze() {
/* 3879 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLogoutRequest unfreeze() {
/* 3882 */           ProtocolSupport.unsupportedOperation();
/* 3883 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3886 */           return true;
/*      */         }
/*      */       };
/* 3903 */       text = new String[2];
/*      */ 
/* 3905 */       text[0] = "ErrorCode";
/* 3906 */       text[1] = "destination_url";
/*      */ 
/* 3909 */       types = new int[2];
/*      */ 
/* 3911 */       Arrays.fill(types, 6);
/* 3912 */       types[0] = 0;
/* 3913 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3787 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateFederatedLogoutRequest.class, "Z!apphosting/api/user_service.proto\n'apphosting.CreateFederatedLogoutRequest\023\032\017destination_url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("destination_url", "destination_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateFederatedLoginResponse extends ProtocolMessage<CreateFederatedLoginResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 3367 */     private byte[] redirected_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateFederatedLoginResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kredirected_url = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getRedirectedUrlAsBytes()
/*      */     {
/* 3373 */       return this.redirected_url_;
/*      */     }
/*      */     public final boolean hasRedirectedUrl() {
/* 3376 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateFederatedLoginResponse clearRedirectedUrl() {
/* 3379 */       this.optional_0_ &= -2;
/* 3380 */       this.redirected_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3381 */       return this;
/*      */     }
/*      */     public CreateFederatedLoginResponse setRedirectedUrlAsBytes(byte[] x) {
/* 3384 */       this.optional_0_ |= 1;
/* 3385 */       this.redirected_url_ = x;
/* 3386 */       return this;
/*      */     }
/*      */     public final String getRedirectedUrl() {
/* 3389 */       return ProtocolSupport.toStringUtf8(this.redirected_url_);
/*      */     }
/*      */     public CreateFederatedLoginResponse setRedirectedUrl(String v) {
/* 3392 */       if (v == null) throw new NullPointerException();
/* 3393 */       this.optional_0_ |= 1;
/* 3394 */       this.redirected_url_ = ProtocolSupport.toBytesUtf8(v);
/* 3395 */       return this;
/*      */     }
/*      */     public final String getRedirectedUrl(Charset cs) {
/* 3398 */       return ProtocolSupport.toString(this.redirected_url_, cs);
/*      */     }
/*      */     public CreateFederatedLoginResponse setRedirectedUrl(String v, Charset cs) {
/* 3401 */       if (v == null) throw new NullPointerException();
/* 3402 */       this.optional_0_ |= 1;
/* 3403 */       this.redirected_url_ = ProtocolSupport.toBytes(v, cs);
/* 3404 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginResponse mergeFrom(CreateFederatedLoginResponse that)
/*      */     {
/* 3411 */       assert (that != this);
/* 3412 */       int this_t0 = this.optional_0_;
/* 3413 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3415 */       if ((that_t0 & 0x1) != 0) {
/* 3416 */         this_t0 |= 1;
/* 3417 */         this.redirected_url_ = that.redirected_url_;
/*      */       }
/*      */ 
/* 3420 */       if (that.uninterpreted != null) {
/* 3421 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3423 */       this.optional_0_ = this_t0;
/* 3424 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateFederatedLoginResponse that) {
/* 3428 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLoginResponse that) {
/* 3432 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLoginResponse that, boolean ignoreUninterpreted) {
/* 3436 */       if (that == null) return false;
/* 3437 */       if (that == this) return true;
/* 3438 */       int this_t0 = this.optional_0_;
/* 3439 */       int that_t0 = that.optional_0_;
/* 3440 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 3442 */       if (((this_t0 & 0x1) != 0) && 
/* 3443 */         (!Arrays.equals(this.redirected_url_, that.redirected_url_))) return false;
/*      */ 
/* 3446 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3451 */       return ((that instanceof CreateFederatedLoginResponse)) && (equals((CreateFederatedLoginResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3455 */       int hash = -1406707323;
/*      */ 
/* 3457 */       int this_t0 = this.optional_0_;
/* 3458 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.redirected_url_) : -113);
/* 3459 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3460 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3462 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3466 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3468 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3475 */       int n = 1 + Protocol.stringSize(this.redirected_url_.length);
/*      */ 
/* 3477 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3483 */       int n = 6 + this.redirected_url_.length;
/*      */ 
/* 3485 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3490 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3494 */       this.optional_0_ = 0;
/* 3495 */       this.redirected_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3496 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginResponse newInstance() {
/* 3500 */       return new CreateFederatedLoginResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3504 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3523 */       sink.putByte(10);
/* 3524 */       sink.putPrefixedData(this.redirected_url_);
/*      */ 
/* 3526 */       if (this.uninterpreted != null)
/* 3527 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3532 */       boolean result = true;
/* 3533 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3535 */       while (source.hasRemaining()) {
/* 3536 */         int tt = source.getVarInt();
/* 3537 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3541 */           result = false;
/* 3542 */           break;
/*      */         case 10:
/* 3545 */           this.redirected_url_ = source.getPrefixedData();
/* 3546 */           this_t0 |= 1;
/* 3547 */           break;
/*      */         default:
/* 3549 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3554 */       this.optional_0_ = this_t0;
/* 3555 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginResponse getDefaultInstanceForType()
/*      */     {
/* 3560 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateFederatedLoginResponse getDefaultInstance() {
/* 3564 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginResponse freeze()
/*      */     {
/* 3612 */       this.redirected_url_ = ProtocolSupport.freezeString(this.redirected_url_);
/* 3613 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 3616 */       if (this.uninterpreted == null) {
/* 3617 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3619 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3568 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateFederatedLoginResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateFederatedLoginResponse clearRedirectedUrl()
/*      */         {
/* 3576 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginResponse setRedirectedUrlAsBytes(byte[] x) {
/* 3579 */           ProtocolSupport.unsupportedOperation();
/* 3580 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginResponse setRedirectedUrl(String v) {
/* 3583 */           ProtocolSupport.unsupportedOperation();
/* 3584 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginResponse setRedirectedUrl(String v, Charset cs) {
/* 3587 */           ProtocolSupport.unsupportedOperation();
/* 3588 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateFederatedLoginResponse mergeFrom(UserServicePb.CreateFederatedLoginResponse that) {
/* 3592 */           ProtocolSupport.unsupportedOperation();
/* 3593 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3596 */           ProtocolSupport.unsupportedOperation();
/* 3597 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginResponse freeze() {
/* 3600 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginResponse unfreeze() {
/* 3603 */           ProtocolSupport.unsupportedOperation();
/* 3604 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3607 */           return true;
/*      */         }
/*      */       };
/* 3624 */       text = new String[2];
/*      */ 
/* 3626 */       text[0] = "ErrorCode";
/* 3627 */       text[1] = "redirected_url";
/*      */ 
/* 3630 */       types = new int[2];
/*      */ 
/* 3632 */       Arrays.fill(types, 6);
/* 3633 */       types[0] = 0;
/* 3634 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3508 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateFederatedLoginResponse.class, "Z!apphosting/api/user_service.proto\n'apphosting.CreateFederatedLoginResponse\023\032\016redirected_url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("redirected_url", "redirected_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateFederatedLoginRequest extends ProtocolMessage<CreateFederatedLoginRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2905 */     private byte[] claimed_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2906 */     private byte[] continue_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2907 */     private byte[] authority_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateFederatedLoginRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kclaimed_id = 1;
/*      */     public static final int kcontinue_url = 2;
/*      */     public static final int kauthority = 3;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getClaimedIdAsBytes()
/*      */     {
/* 2913 */       return this.claimed_id_;
/*      */     }
/*      */     public final boolean hasClaimedId() {
/* 2916 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateFederatedLoginRequest clearClaimedId() {
/* 2919 */       this.optional_0_ &= -2;
/* 2920 */       this.claimed_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2921 */       return this;
/*      */     }
/*      */     public CreateFederatedLoginRequest setClaimedIdAsBytes(byte[] x) {
/* 2924 */       this.optional_0_ |= 1;
/* 2925 */       this.claimed_id_ = x;
/* 2926 */       return this;
/*      */     }
/*      */     public final String getClaimedId() {
/* 2929 */       return ProtocolSupport.toStringUtf8(this.claimed_id_);
/*      */     }
/*      */     public CreateFederatedLoginRequest setClaimedId(String v) {
/* 2932 */       if (v == null) throw new NullPointerException();
/* 2933 */       this.optional_0_ |= 1;
/* 2934 */       this.claimed_id_ = ProtocolSupport.toBytesUtf8(v);
/* 2935 */       return this;
/*      */     }
/*      */     public final String getClaimedId(Charset cs) {
/* 2938 */       return ProtocolSupport.toString(this.claimed_id_, cs);
/*      */     }
/*      */     public CreateFederatedLoginRequest setClaimedId(String v, Charset cs) {
/* 2941 */       if (v == null) throw new NullPointerException();
/* 2942 */       this.optional_0_ |= 1;
/* 2943 */       this.claimed_id_ = ProtocolSupport.toBytes(v, cs);
/* 2944 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getContinueUrlAsBytes()
/*      */     {
/* 2949 */       return this.continue_url_;
/*      */     }
/*      */     public final boolean hasContinueUrl() {
/* 2952 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public CreateFederatedLoginRequest clearContinueUrl() {
/* 2955 */       this.optional_0_ &= -3;
/* 2956 */       this.continue_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2957 */       return this;
/*      */     }
/*      */     public CreateFederatedLoginRequest setContinueUrlAsBytes(byte[] x) {
/* 2960 */       this.optional_0_ |= 2;
/* 2961 */       this.continue_url_ = x;
/* 2962 */       return this;
/*      */     }
/*      */     public final String getContinueUrl() {
/* 2965 */       return ProtocolSupport.toStringUtf8(this.continue_url_);
/*      */     }
/*      */     public CreateFederatedLoginRequest setContinueUrl(String v) {
/* 2968 */       if (v == null) throw new NullPointerException();
/* 2969 */       this.optional_0_ |= 2;
/* 2970 */       this.continue_url_ = ProtocolSupport.toBytesUtf8(v);
/* 2971 */       return this;
/*      */     }
/*      */     public final String getContinueUrl(Charset cs) {
/* 2974 */       return ProtocolSupport.toString(this.continue_url_, cs);
/*      */     }
/*      */     public CreateFederatedLoginRequest setContinueUrl(String v, Charset cs) {
/* 2977 */       if (v == null) throw new NullPointerException();
/* 2978 */       this.optional_0_ |= 2;
/* 2979 */       this.continue_url_ = ProtocolSupport.toBytes(v, cs);
/* 2980 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getAuthorityAsBytes()
/*      */     {
/* 2985 */       return this.authority_;
/*      */     }
/*      */     public final boolean hasAuthority() {
/* 2988 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public CreateFederatedLoginRequest clearAuthority() {
/* 2991 */       this.optional_0_ &= -5;
/* 2992 */       this.authority_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2993 */       return this;
/*      */     }
/*      */     public CreateFederatedLoginRequest setAuthorityAsBytes(byte[] x) {
/* 2996 */       this.optional_0_ |= 4;
/* 2997 */       this.authority_ = x;
/* 2998 */       return this;
/*      */     }
/*      */     public final String getAuthority() {
/* 3001 */       return ProtocolSupport.toStringUtf8(this.authority_);
/*      */     }
/*      */     public CreateFederatedLoginRequest setAuthority(String v) {
/* 3004 */       if (v == null) throw new NullPointerException();
/* 3005 */       this.optional_0_ |= 4;
/* 3006 */       this.authority_ = ProtocolSupport.toBytesUtf8(v);
/* 3007 */       return this;
/*      */     }
/*      */     public final String getAuthority(Charset cs) {
/* 3010 */       return ProtocolSupport.toString(this.authority_, cs);
/*      */     }
/*      */     public CreateFederatedLoginRequest setAuthority(String v, Charset cs) {
/* 3013 */       if (v == null) throw new NullPointerException();
/* 3014 */       this.optional_0_ |= 4;
/* 3015 */       this.authority_ = ProtocolSupport.toBytes(v, cs);
/* 3016 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginRequest mergeFrom(CreateFederatedLoginRequest that)
/*      */     {
/* 3023 */       assert (that != this);
/* 3024 */       int this_t0 = this.optional_0_;
/* 3025 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3027 */       if ((that_t0 & 0x1) != 0) {
/* 3028 */         this_t0 |= 1;
/* 3029 */         this.claimed_id_ = that.claimed_id_;
/*      */       }
/*      */ 
/* 3032 */       if ((that_t0 & 0x2) != 0) {
/* 3033 */         this_t0 |= 2;
/* 3034 */         this.continue_url_ = that.continue_url_;
/*      */       }
/*      */ 
/* 3037 */       if ((that_t0 & 0x4) != 0) {
/* 3038 */         this_t0 |= 4;
/* 3039 */         this.authority_ = that.authority_;
/*      */       }
/*      */ 
/* 3042 */       if (that.uninterpreted != null) {
/* 3043 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3045 */       this.optional_0_ = this_t0;
/* 3046 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateFederatedLoginRequest that) {
/* 3050 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLoginRequest that) {
/* 3054 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateFederatedLoginRequest that, boolean ignoreUninterpreted) {
/* 3058 */       if (that == null) return false;
/* 3059 */       if (that == this) return true;
/* 3060 */       int this_t0 = this.optional_0_;
/* 3061 */       int that_t0 = that.optional_0_;
/* 3062 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 3064 */       if (((this_t0 & 0x1) != 0) && 
/* 3065 */         (!Arrays.equals(this.claimed_id_, that.claimed_id_))) return false;
/*      */ 
/* 3068 */       if (((this_t0 & 0x2) != 0) && 
/* 3069 */         (!Arrays.equals(this.continue_url_, that.continue_url_))) return false;
/*      */ 
/* 3072 */       if (((this_t0 & 0x4) != 0) && 
/* 3073 */         (!Arrays.equals(this.authority_, that.authority_))) return false;
/*      */ 
/* 3076 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3081 */       return ((that instanceof CreateFederatedLoginRequest)) && (equals((CreateFederatedLoginRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3085 */       int hash = 2019558603;
/*      */ 
/* 3087 */       int this_t0 = this.optional_0_;
/* 3088 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.claimed_id_) : -113);
/*      */ 
/* 3090 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.continue_url_) : -113);
/*      */ 
/* 3092 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.authority_) : -113);
/* 3093 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3094 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3096 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3100 */       int this_t0 = this.optional_0_;
/* 3101 */       if ((this_t0 & 0x3) != 3)
/*      */       {
/* 3103 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/* 3107 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3113 */       int n = 2 + Protocol.stringSize(this.claimed_id_.length) + Protocol.stringSize(this.continue_url_.length);
/*      */ 
/* 3115 */       int this_t0 = this.optional_0_;
/* 3116 */       if ((this_t0 & 0x4) != 0)
/*      */       {
/* 3118 */         n += 1 + Protocol.stringSize(this.authority_.length);
/*      */       }
/*      */ 
/* 3121 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3128 */       int n = 12 + this.claimed_id_.length + this.continue_url_.length;
/* 3129 */       int this_t0 = this.optional_0_;
/* 3130 */       if ((this_t0 & 0x4) != 0)
/*      */       {
/* 3132 */         n += 6 + this.authority_.length;
/*      */       }
/*      */ 
/* 3135 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3140 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3144 */       this.optional_0_ = 0;
/* 3145 */       this.claimed_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3146 */       this.continue_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3147 */       this.authority_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3148 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginRequest newInstance() {
/* 3152 */       return new CreateFederatedLoginRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3156 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3183 */       sink.putByte(10);
/* 3184 */       sink.putPrefixedData(this.claimed_id_);
/*      */ 
/* 3186 */       sink.putByte(18);
/* 3187 */       sink.putPrefixedData(this.continue_url_);
/*      */ 
/* 3189 */       int this_t0 = this.optional_0_;
/* 3190 */       if ((this_t0 & 0x4) != 0) {
/* 3191 */         sink.putByte(26);
/* 3192 */         sink.putPrefixedData(this.authority_);
/*      */       }
/*      */ 
/* 3195 */       if (this.uninterpreted != null)
/* 3196 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3201 */       boolean result = true;
/* 3202 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3204 */       while (source.hasRemaining()) {
/* 3205 */         int tt = source.getVarInt();
/* 3206 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3210 */           result = false;
/* 3211 */           break;
/*      */         case 10:
/* 3214 */           this.claimed_id_ = source.getPrefixedData();
/* 3215 */           this_t0 |= 1;
/* 3216 */           break;
/*      */         case 18:
/* 3219 */           this.continue_url_ = source.getPrefixedData();
/* 3220 */           this_t0 |= 2;
/* 3221 */           break;
/*      */         case 26:
/* 3224 */           this.authority_ = source.getPrefixedData();
/* 3225 */           this_t0 |= 4;
/* 3226 */           break;
/*      */         default:
/* 3228 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3233 */       this.optional_0_ = this_t0;
/* 3234 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginRequest getDefaultInstanceForType()
/*      */     {
/* 3239 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateFederatedLoginRequest getDefaultInstance() {
/* 3243 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateFederatedLoginRequest freeze()
/*      */     {
/* 3325 */       this.claimed_id_ = ProtocolSupport.freezeString(this.claimed_id_);
/* 3326 */       this.continue_url_ = ProtocolSupport.freezeString(this.continue_url_);
/* 3327 */       this.authority_ = ProtocolSupport.freezeString(this.authority_);
/* 3328 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 3331 */       if (this.uninterpreted == null) {
/* 3332 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3334 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3247 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateFederatedLoginRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateFederatedLoginRequest clearClaimedId()
/*      */         {
/* 3255 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setClaimedIdAsBytes(byte[] x) {
/* 3258 */           ProtocolSupport.unsupportedOperation();
/* 3259 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setClaimedId(String v) {
/* 3262 */           ProtocolSupport.unsupportedOperation();
/* 3263 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setClaimedId(String v, Charset cs) {
/* 3266 */           ProtocolSupport.unsupportedOperation();
/* 3267 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateFederatedLoginRequest clearContinueUrl()
/*      */         {
/* 3272 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setContinueUrlAsBytes(byte[] x) {
/* 3275 */           ProtocolSupport.unsupportedOperation();
/* 3276 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setContinueUrl(String v) {
/* 3279 */           ProtocolSupport.unsupportedOperation();
/* 3280 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setContinueUrl(String v, Charset cs) {
/* 3283 */           ProtocolSupport.unsupportedOperation();
/* 3284 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateFederatedLoginRequest clearAuthority()
/*      */         {
/* 3289 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setAuthorityAsBytes(byte[] x) {
/* 3292 */           ProtocolSupport.unsupportedOperation();
/* 3293 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setAuthority(String v) {
/* 3296 */           ProtocolSupport.unsupportedOperation();
/* 3297 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest setAuthority(String v, Charset cs) {
/* 3300 */           ProtocolSupport.unsupportedOperation();
/* 3301 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateFederatedLoginRequest mergeFrom(UserServicePb.CreateFederatedLoginRequest that) {
/* 3305 */           ProtocolSupport.unsupportedOperation();
/* 3306 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3309 */           ProtocolSupport.unsupportedOperation();
/* 3310 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest freeze() {
/* 3313 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateFederatedLoginRequest unfreeze() {
/* 3316 */           ProtocolSupport.unsupportedOperation();
/* 3317 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3320 */           return true;
/*      */         }
/*      */       };
/* 3341 */       text = new String[4];
/*      */ 
/* 3343 */       text[0] = "ErrorCode";
/* 3344 */       text[1] = "claimed_id";
/* 3345 */       text[2] = "continue_url";
/* 3346 */       text[3] = "authority";
/*      */ 
/* 3349 */       types = new int[4];
/*      */ 
/* 3351 */       Arrays.fill(types, 6);
/* 3352 */       types[0] = 0;
/* 3353 */       types[1] = 2;
/* 3354 */       types[2] = 2;
/* 3355 */       types[3] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3160 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateFederatedLoginRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("claimed_id", "claimed_id", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("continue_url", "continue_url", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("authority", "authority", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CheckOAuthSignatureResponse extends ProtocolMessage<CheckOAuthSignatureResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2626 */     private byte[] oauth_consumer_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CheckOAuthSignatureResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int koauth_consumer_key = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getOauthConsumerKeyAsBytes()
/*      */     {
/* 2632 */       return this.oauth_consumer_key_;
/*      */     }
/*      */     public final boolean hasOauthConsumerKey() {
/* 2635 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CheckOAuthSignatureResponse clearOauthConsumerKey() {
/* 2638 */       this.optional_0_ &= -2;
/* 2639 */       this.oauth_consumer_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2640 */       return this;
/*      */     }
/*      */     public CheckOAuthSignatureResponse setOauthConsumerKeyAsBytes(byte[] x) {
/* 2643 */       this.optional_0_ |= 1;
/* 2644 */       this.oauth_consumer_key_ = x;
/* 2645 */       return this;
/*      */     }
/*      */     public final String getOauthConsumerKey() {
/* 2648 */       return ProtocolSupport.toStringUtf8(this.oauth_consumer_key_);
/*      */     }
/*      */     public CheckOAuthSignatureResponse setOauthConsumerKey(String v) {
/* 2651 */       if (v == null) throw new NullPointerException();
/* 2652 */       this.optional_0_ |= 1;
/* 2653 */       this.oauth_consumer_key_ = ProtocolSupport.toBytesUtf8(v);
/* 2654 */       return this;
/*      */     }
/*      */     public final String getOauthConsumerKey(Charset cs) {
/* 2657 */       return ProtocolSupport.toString(this.oauth_consumer_key_, cs);
/*      */     }
/*      */     public CheckOAuthSignatureResponse setOauthConsumerKey(String v, Charset cs) {
/* 2660 */       if (v == null) throw new NullPointerException();
/* 2661 */       this.optional_0_ |= 1;
/* 2662 */       this.oauth_consumer_key_ = ProtocolSupport.toBytes(v, cs);
/* 2663 */       return this;
/*      */     }
/*      */ 
/*      */     public CheckOAuthSignatureResponse mergeFrom(CheckOAuthSignatureResponse that)
/*      */     {
/* 2670 */       assert (that != this);
/* 2671 */       int this_t0 = this.optional_0_;
/* 2672 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2674 */       if ((that_t0 & 0x1) != 0) {
/* 2675 */         this_t0 |= 1;
/* 2676 */         this.oauth_consumer_key_ = that.oauth_consumer_key_;
/*      */       }
/*      */ 
/* 2679 */       if (that.uninterpreted != null) {
/* 2680 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2682 */       this.optional_0_ = this_t0;
/* 2683 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CheckOAuthSignatureResponse that) {
/* 2687 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CheckOAuthSignatureResponse that) {
/* 2691 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CheckOAuthSignatureResponse that, boolean ignoreUninterpreted) {
/* 2695 */       if (that == null) return false;
/* 2696 */       if (that == this) return true;
/* 2697 */       int this_t0 = this.optional_0_;
/* 2698 */       int that_t0 = that.optional_0_;
/* 2699 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2701 */       if (((this_t0 & 0x1) != 0) && 
/* 2702 */         (!Arrays.equals(this.oauth_consumer_key_, that.oauth_consumer_key_))) return false;
/*      */ 
/* 2705 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2710 */       return ((that instanceof CheckOAuthSignatureResponse)) && (equals((CheckOAuthSignatureResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2714 */       int hash = 1632074259;
/*      */ 
/* 2716 */       int this_t0 = this.optional_0_;
/* 2717 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.oauth_consumer_key_) : -113);
/* 2718 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2719 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2721 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2725 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2727 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2734 */       int n = 1 + Protocol.stringSize(this.oauth_consumer_key_.length);
/*      */ 
/* 2736 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2742 */       int n = 6 + this.oauth_consumer_key_.length;
/*      */ 
/* 2744 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2749 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2753 */       this.optional_0_ = 0;
/* 2754 */       this.oauth_consumer_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2755 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CheckOAuthSignatureResponse newInstance() {
/* 2759 */       return new CheckOAuthSignatureResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2763 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2782 */       sink.putByte(10);
/* 2783 */       sink.putPrefixedData(this.oauth_consumer_key_);
/*      */ 
/* 2785 */       if (this.uninterpreted != null)
/* 2786 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2791 */       boolean result = true;
/* 2792 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2794 */       while (source.hasRemaining()) {
/* 2795 */         int tt = source.getVarInt();
/* 2796 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2800 */           result = false;
/* 2801 */           break;
/*      */         case 10:
/* 2804 */           this.oauth_consumer_key_ = source.getPrefixedData();
/* 2805 */           this_t0 |= 1;
/* 2806 */           break;
/*      */         default:
/* 2808 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2813 */       this.optional_0_ = this_t0;
/* 2814 */       return result;
/*      */     }
/*      */ 
/*      */     public CheckOAuthSignatureResponse getDefaultInstanceForType()
/*      */     {
/* 2819 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CheckOAuthSignatureResponse getDefaultInstance() {
/* 2823 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CheckOAuthSignatureResponse freeze()
/*      */     {
/* 2871 */       this.oauth_consumer_key_ = ProtocolSupport.freezeString(this.oauth_consumer_key_);
/* 2872 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 2875 */       if (this.uninterpreted == null) {
/* 2876 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2878 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2827 */       IMMUTABLE_DEFAULT_INSTANCE = new CheckOAuthSignatureResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CheckOAuthSignatureResponse clearOauthConsumerKey()
/*      */         {
/* 2835 */           return this;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureResponse setOauthConsumerKeyAsBytes(byte[] x) {
/* 2838 */           ProtocolSupport.unsupportedOperation();
/* 2839 */           return this;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureResponse setOauthConsumerKey(String v) {
/* 2842 */           ProtocolSupport.unsupportedOperation();
/* 2843 */           return this;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureResponse setOauthConsumerKey(String v, Charset cs) {
/* 2846 */           ProtocolSupport.unsupportedOperation();
/* 2847 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CheckOAuthSignatureResponse mergeFrom(UserServicePb.CheckOAuthSignatureResponse that) {
/* 2851 */           ProtocolSupport.unsupportedOperation();
/* 2852 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2855 */           ProtocolSupport.unsupportedOperation();
/* 2856 */           return false;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureResponse freeze() {
/* 2859 */           return this;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureResponse unfreeze() {
/* 2862 */           ProtocolSupport.unsupportedOperation();
/* 2863 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2866 */           return true;
/*      */         }
/*      */       };
/* 2883 */       text = new String[2];
/*      */ 
/* 2885 */       text[0] = "ErrorCode";
/* 2886 */       text[1] = "oauth_consumer_key";
/*      */ 
/* 2889 */       types = new int[2];
/*      */ 
/* 2891 */       Arrays.fill(types, 6);
/* 2892 */       types[0] = 0;
/* 2893 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2767 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CheckOAuthSignatureResponse.class, "Z!apphosting/api/user_service.proto\n&apphosting.CheckOAuthSignatureResponse\023\032\022oauth_consumer_key \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("oauth_consumer_key", "oauth_consumer_key", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CheckOAuthSignatureRequest extends ProtocolMessage<CheckOAuthSignatureRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final CheckOAuthSignatureRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public CheckOAuthSignatureRequest mergeFrom(CheckOAuthSignatureRequest that)
/*      */     {
/* 2456 */       assert (that != this);
/*      */ 
/* 2458 */       if (that.uninterpreted != null) {
/* 2459 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2461 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CheckOAuthSignatureRequest that) {
/* 2465 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CheckOAuthSignatureRequest that) {
/* 2469 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CheckOAuthSignatureRequest that, boolean ignoreUninterpreted) {
/* 2473 */       if (that == null) return false;
/* 2474 */       if (that == this) return true;
/*      */ 
/* 2476 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2481 */       return ((that instanceof CheckOAuthSignatureRequest)) && (equals((CheckOAuthSignatureRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2485 */       int hash = 323463287;
/* 2486 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2487 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2489 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2493 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 2497 */       int n = 0;
/*      */ 
/* 2499 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2504 */       int n = 0;
/*      */ 
/* 2506 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2511 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2515 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CheckOAuthSignatureRequest newInstance() {
/* 2519 */       return new CheckOAuthSignatureRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2523 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2538 */       if (this.uninterpreted != null)
/* 2539 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2544 */       boolean result = true;
/*      */ 
/* 2546 */       while (source.hasRemaining()) {
/* 2547 */         int tt = source.getVarInt();
/* 2548 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2552 */           result = false;
/* 2553 */           break;
/*      */         default:
/* 2555 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2560 */       return result;
/*      */     }
/*      */ 
/*      */     public CheckOAuthSignatureRequest getDefaultInstanceForType()
/*      */     {
/* 2565 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CheckOAuthSignatureRequest getDefaultInstance() {
/* 2569 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 2599 */       if (this.uninterpreted == null) {
/* 2600 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2602 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2573 */       IMMUTABLE_DEFAULT_INSTANCE = new CheckOAuthSignatureRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CheckOAuthSignatureRequest mergeFrom(UserServicePb.CheckOAuthSignatureRequest that)
/*      */         {
/* 2580 */           ProtocolSupport.unsupportedOperation();
/* 2581 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2584 */           ProtocolSupport.unsupportedOperation();
/* 2585 */           return false;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureRequest freeze() {
/* 2588 */           return this;
/*      */         }
/*      */         public UserServicePb.CheckOAuthSignatureRequest unfreeze() {
/* 2591 */           ProtocolSupport.unsupportedOperation();
/* 2592 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2595 */           return true;
/*      */         }
/*      */       };
/* 2606 */       text = new String[1];
/*      */ 
/* 2608 */       text[0] = "ErrorCode";
/*      */ 
/* 2611 */       types = new int[1];
/*      */ 
/* 2613 */       Arrays.fill(types, 6);
/* 2614 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2527 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CheckOAuthSignatureRequest.class, "Z!apphosting/api/user_service.proto\n%apphosting.CheckOAuthSignatureRequest", new ProtocolType.FieldType[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetOAuthUserResponse extends ProtocolMessage<GetOAuthUserResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1836 */     private byte[] email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1837 */     private byte[] user_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1838 */     private byte[] auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1839 */     private byte[] user_organization_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1840 */     private boolean is_admin_ = false;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final GetOAuthUserResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kemail = 1;
/*      */     public static final int kuser_id = 2;
/*      */     public static final int kauth_domain = 3;
/*      */     public static final int kuser_organization = 4;
/*      */     public static final int kis_admin = 5;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getEmailAsBytes()
/*      */     {
/* 1846 */       return this.email_;
/*      */     }
/*      */     public final boolean hasEmail() {
/* 1849 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public GetOAuthUserResponse clearEmail() {
/* 1852 */       this.optional_0_ &= -2;
/* 1853 */       this.email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1854 */       return this;
/*      */     }
/*      */     public GetOAuthUserResponse setEmailAsBytes(byte[] x) {
/* 1857 */       this.optional_0_ |= 1;
/* 1858 */       this.email_ = x;
/* 1859 */       return this;
/*      */     }
/*      */     public final String getEmail() {
/* 1862 */       return ProtocolSupport.toStringUtf8(this.email_);
/*      */     }
/*      */     public GetOAuthUserResponse setEmail(String v) {
/* 1865 */       if (v == null) throw new NullPointerException();
/* 1866 */       this.optional_0_ |= 1;
/* 1867 */       this.email_ = ProtocolSupport.toBytesUtf8(v);
/* 1868 */       return this;
/*      */     }
/*      */     public final String getEmail(Charset cs) {
/* 1871 */       return ProtocolSupport.toString(this.email_, cs);
/*      */     }
/*      */     public GetOAuthUserResponse setEmail(String v, Charset cs) {
/* 1874 */       if (v == null) throw new NullPointerException();
/* 1875 */       this.optional_0_ |= 1;
/* 1876 */       this.email_ = ProtocolSupport.toBytes(v, cs);
/* 1877 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getUserIdAsBytes()
/*      */     {
/* 1882 */       return this.user_id_;
/*      */     }
/*      */     public final boolean hasUserId() {
/* 1885 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public GetOAuthUserResponse clearUserId() {
/* 1888 */       this.optional_0_ &= -3;
/* 1889 */       this.user_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1890 */       return this;
/*      */     }
/*      */     public GetOAuthUserResponse setUserIdAsBytes(byte[] x) {
/* 1893 */       this.optional_0_ |= 2;
/* 1894 */       this.user_id_ = x;
/* 1895 */       return this;
/*      */     }
/*      */     public final String getUserId() {
/* 1898 */       return ProtocolSupport.toStringUtf8(this.user_id_);
/*      */     }
/*      */     public GetOAuthUserResponse setUserId(String v) {
/* 1901 */       if (v == null) throw new NullPointerException();
/* 1902 */       this.optional_0_ |= 2;
/* 1903 */       this.user_id_ = ProtocolSupport.toBytesUtf8(v);
/* 1904 */       return this;
/*      */     }
/*      */     public final String getUserId(Charset cs) {
/* 1907 */       return ProtocolSupport.toString(this.user_id_, cs);
/*      */     }
/*      */     public GetOAuthUserResponse setUserId(String v, Charset cs) {
/* 1910 */       if (v == null) throw new NullPointerException();
/* 1911 */       this.optional_0_ |= 2;
/* 1912 */       this.user_id_ = ProtocolSupport.toBytes(v, cs);
/* 1913 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getAuthDomainAsBytes()
/*      */     {
/* 1918 */       return this.auth_domain_;
/*      */     }
/*      */     public final boolean hasAuthDomain() {
/* 1921 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public GetOAuthUserResponse clearAuthDomain() {
/* 1924 */       this.optional_0_ &= -5;
/* 1925 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1926 */       return this;
/*      */     }
/*      */     public GetOAuthUserResponse setAuthDomainAsBytes(byte[] x) {
/* 1929 */       this.optional_0_ |= 4;
/* 1930 */       this.auth_domain_ = x;
/* 1931 */       return this;
/*      */     }
/*      */     public final String getAuthDomain() {
/* 1934 */       return ProtocolSupport.toStringUtf8(this.auth_domain_);
/*      */     }
/*      */     public GetOAuthUserResponse setAuthDomain(String v) {
/* 1937 */       if (v == null) throw new NullPointerException();
/* 1938 */       this.optional_0_ |= 4;
/* 1939 */       this.auth_domain_ = ProtocolSupport.toBytesUtf8(v);
/* 1940 */       return this;
/*      */     }
/*      */     public final String getAuthDomain(Charset cs) {
/* 1943 */       return ProtocolSupport.toString(this.auth_domain_, cs);
/*      */     }
/*      */     public GetOAuthUserResponse setAuthDomain(String v, Charset cs) {
/* 1946 */       if (v == null) throw new NullPointerException();
/* 1947 */       this.optional_0_ |= 4;
/* 1948 */       this.auth_domain_ = ProtocolSupport.toBytes(v, cs);
/* 1949 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getUserOrganizationAsBytes()
/*      */     {
/* 1954 */       return this.user_organization_;
/*      */     }
/*      */     public final boolean hasUserOrganization() {
/* 1957 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public GetOAuthUserResponse clearUserOrganization() {
/* 1960 */       this.optional_0_ &= -9;
/* 1961 */       this.user_organization_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1962 */       return this;
/*      */     }
/*      */     public GetOAuthUserResponse setUserOrganizationAsBytes(byte[] x) {
/* 1965 */       this.optional_0_ |= 8;
/* 1966 */       this.user_organization_ = x;
/* 1967 */       return this;
/*      */     }
/*      */     public final String getUserOrganization() {
/* 1970 */       return ProtocolSupport.toStringUtf8(this.user_organization_);
/*      */     }
/*      */     public GetOAuthUserResponse setUserOrganization(String v) {
/* 1973 */       if (v == null) throw new NullPointerException();
/* 1974 */       this.optional_0_ |= 8;
/* 1975 */       this.user_organization_ = ProtocolSupport.toBytesUtf8(v);
/* 1976 */       return this;
/*      */     }
/*      */     public final String getUserOrganization(Charset cs) {
/* 1979 */       return ProtocolSupport.toString(this.user_organization_, cs);
/*      */     }
/*      */     public GetOAuthUserResponse setUserOrganization(String v, Charset cs) {
/* 1982 */       if (v == null) throw new NullPointerException();
/* 1983 */       this.optional_0_ |= 8;
/* 1984 */       this.user_organization_ = ProtocolSupport.toBytes(v, cs);
/* 1985 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isIsAdmin()
/*      */     {
/* 1990 */       return this.is_admin_;
/*      */     }
/*      */     public final boolean hasIsAdmin() {
/* 1993 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public GetOAuthUserResponse clearIsAdmin() {
/* 1996 */       this.optional_0_ &= -17;
/* 1997 */       this.is_admin_ = false;
/* 1998 */       return this;
/*      */     }
/*      */     public GetOAuthUserResponse setIsAdmin(boolean x) {
/* 2001 */       this.optional_0_ |= 16;
/* 2002 */       this.is_admin_ = x;
/* 2003 */       return this;
/*      */     }
/*      */ 
/*      */     public GetOAuthUserResponse mergeFrom(GetOAuthUserResponse that)
/*      */     {
/* 2010 */       assert (that != this);
/* 2011 */       int this_t0 = this.optional_0_;
/* 2012 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2014 */       if ((that_t0 & 0x1) != 0) {
/* 2015 */         this_t0 |= 1;
/* 2016 */         this.email_ = that.email_;
/*      */       }
/*      */ 
/* 2019 */       if ((that_t0 & 0x2) != 0) {
/* 2020 */         this_t0 |= 2;
/* 2021 */         this.user_id_ = that.user_id_;
/*      */       }
/*      */ 
/* 2024 */       if ((that_t0 & 0x4) != 0) {
/* 2025 */         this_t0 |= 4;
/* 2026 */         this.auth_domain_ = that.auth_domain_;
/*      */       }
/*      */ 
/* 2029 */       if ((that_t0 & 0x8) != 0) {
/* 2030 */         this_t0 |= 8;
/* 2031 */         this.user_organization_ = that.user_organization_;
/*      */       }
/*      */ 
/* 2034 */       if ((that_t0 & 0x10) != 0) {
/* 2035 */         this_t0 |= 16;
/* 2036 */         this.is_admin_ = that.is_admin_;
/*      */       }
/*      */ 
/* 2039 */       if (that.uninterpreted != null) {
/* 2040 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2042 */       this.optional_0_ = this_t0;
/* 2043 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(GetOAuthUserResponse that) {
/* 2047 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(GetOAuthUserResponse that) {
/* 2051 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(GetOAuthUserResponse that, boolean ignoreUninterpreted) {
/* 2055 */       if (that == null) return false;
/* 2056 */       if (that == this) return true;
/* 2057 */       int this_t0 = this.optional_0_;
/* 2058 */       int that_t0 = that.optional_0_;
/* 2059 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2061 */       if (((this_t0 & 0x1) != 0) && 
/* 2062 */         (!Arrays.equals(this.email_, that.email_))) return false;
/*      */ 
/* 2065 */       if (((this_t0 & 0x2) != 0) && 
/* 2066 */         (!Arrays.equals(this.user_id_, that.user_id_))) return false;
/*      */ 
/* 2069 */       if (((this_t0 & 0x4) != 0) && 
/* 2070 */         (!Arrays.equals(this.auth_domain_, that.auth_domain_))) return false;
/*      */ 
/* 2073 */       if (((this_t0 & 0x8) != 0) && 
/* 2074 */         (!Arrays.equals(this.user_organization_, that.user_organization_))) return false;
/*      */ 
/* 2077 */       if (((this_t0 & 0x10) != 0) && 
/* 2078 */         (this.is_admin_ != that.is_admin_)) return false;
/*      */ 
/* 2081 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2086 */       return ((that instanceof GetOAuthUserResponse)) && (equals((GetOAuthUserResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2090 */       int hash = 1880174053;
/*      */ 
/* 2092 */       int this_t0 = this.optional_0_;
/* 2093 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.email_) : -113);
/*      */ 
/* 2095 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.user_id_) : -113);
/*      */ 
/* 2097 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.auth_domain_) : -113);
/*      */ 
/* 2099 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Arrays.hashCode(this.user_organization_) : -113);
/*      */ 
/* 2101 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? 1237 : this.is_admin_ ? 1231 : -113);
/* 2102 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2103 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2105 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2109 */       int this_t0 = this.optional_0_;
/* 2110 */       if ((this_t0 & 0x7) != 7) {
/* 2111 */         if ((this_t0 & 0x1) == 0) {
/* 2112 */           return false;
/*      */         }
/*      */ 
/* 2115 */         return (this_t0 & 0x2) != 0;
/*      */       }
/*      */ 
/* 2119 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2126 */       int n = 3 + Protocol.stringSize(this.email_.length) + Protocol.stringSize(this.user_id_.length) + Protocol.stringSize(this.auth_domain_.length);
/*      */ 
/* 2129 */       int this_t0 = this.optional_0_;
/* 2130 */       if ((this_t0 & 0x18) != 0) {
/* 2131 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 2133 */           n += 1 + Protocol.stringSize(this.user_organization_.length);
/*      */         }
/* 2135 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 2137 */           n += 2;
/*      */         }
/*      */       }
/*      */ 
/* 2141 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2150 */       int n = 20 + this.email_.length + this.user_id_.length + this.auth_domain_.length;
/* 2151 */       int this_t0 = this.optional_0_;
/* 2152 */       if ((this_t0 & 0x8) != 0)
/*      */       {
/* 2154 */         n += 6 + this.user_organization_.length;
/*      */       }
/*      */ 
/* 2157 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2162 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2166 */       this.optional_0_ = 0;
/* 2167 */       this.email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2168 */       this.user_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2169 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2170 */       this.user_organization_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2171 */       this.is_admin_ = false;
/* 2172 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public GetOAuthUserResponse newInstance() {
/* 2176 */       return new GetOAuthUserResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2180 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2216 */       sink.putByte(10);
/* 2217 */       sink.putPrefixedData(this.email_);
/*      */ 
/* 2219 */       sink.putByte(18);
/* 2220 */       sink.putPrefixedData(this.user_id_);
/*      */ 
/* 2222 */       sink.putByte(26);
/* 2223 */       sink.putPrefixedData(this.auth_domain_);
/*      */ 
/* 2225 */       int this_t0 = this.optional_0_;
/* 2226 */       if ((this_t0 & 0x8) != 0) {
/* 2227 */         sink.putByte(34);
/* 2228 */         sink.putPrefixedData(this.user_organization_);
/*      */       }
/*      */ 
/* 2231 */       if ((this_t0 & 0x10) != 0) {
/* 2232 */         sink.putByte(40);
/* 2233 */         sink.putBoolean(this.is_admin_);
/*      */       }
/*      */ 
/* 2236 */       if (this.uninterpreted != null)
/* 2237 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2242 */       boolean result = true;
/* 2243 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2245 */       while (source.hasRemaining()) {
/* 2246 */         int tt = source.getVarInt();
/* 2247 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2251 */           result = false;
/* 2252 */           break;
/*      */         case 10:
/* 2255 */           this.email_ = source.getPrefixedData();
/* 2256 */           this_t0 |= 1;
/* 2257 */           break;
/*      */         case 18:
/* 2260 */           this.user_id_ = source.getPrefixedData();
/* 2261 */           this_t0 |= 2;
/* 2262 */           break;
/*      */         case 26:
/* 2265 */           this.auth_domain_ = source.getPrefixedData();
/* 2266 */           this_t0 |= 4;
/* 2267 */           break;
/*      */         case 34:
/* 2270 */           this.user_organization_ = source.getPrefixedData();
/* 2271 */           this_t0 |= 8;
/* 2272 */           break;
/*      */         case 40:
/* 2275 */           this.is_admin_ = source.getBoolean();
/* 2276 */           this_t0 |= 16;
/* 2277 */           break;
/*      */         default:
/* 2279 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2284 */       this.optional_0_ = this_t0;
/* 2285 */       return result;
/*      */     }
/*      */ 
/*      */     public GetOAuthUserResponse getDefaultInstanceForType()
/*      */     {
/* 2290 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final GetOAuthUserResponse getDefaultInstance() {
/* 2294 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public GetOAuthUserResponse freeze()
/*      */     {
/* 2402 */       this.email_ = ProtocolSupport.freezeString(this.email_);
/* 2403 */       this.user_id_ = ProtocolSupport.freezeString(this.user_id_);
/* 2404 */       this.auth_domain_ = ProtocolSupport.freezeString(this.auth_domain_);
/* 2405 */       this.user_organization_ = ProtocolSupport.freezeString(this.user_organization_);
/* 2406 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 2409 */       if (this.uninterpreted == null) {
/* 2410 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2412 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2298 */       IMMUTABLE_DEFAULT_INSTANCE = new GetOAuthUserResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.GetOAuthUserResponse clearEmail()
/*      */         {
/* 2306 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setEmailAsBytes(byte[] x) {
/* 2309 */           ProtocolSupport.unsupportedOperation();
/* 2310 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setEmail(String v) {
/* 2313 */           ProtocolSupport.unsupportedOperation();
/* 2314 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setEmail(String v, Charset cs) {
/* 2317 */           ProtocolSupport.unsupportedOperation();
/* 2318 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.GetOAuthUserResponse clearUserId()
/*      */         {
/* 2323 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setUserIdAsBytes(byte[] x) {
/* 2326 */           ProtocolSupport.unsupportedOperation();
/* 2327 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setUserId(String v) {
/* 2330 */           ProtocolSupport.unsupportedOperation();
/* 2331 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setUserId(String v, Charset cs) {
/* 2334 */           ProtocolSupport.unsupportedOperation();
/* 2335 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.GetOAuthUserResponse clearAuthDomain()
/*      */         {
/* 2340 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setAuthDomainAsBytes(byte[] x) {
/* 2343 */           ProtocolSupport.unsupportedOperation();
/* 2344 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setAuthDomain(String v) {
/* 2347 */           ProtocolSupport.unsupportedOperation();
/* 2348 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setAuthDomain(String v, Charset cs) {
/* 2351 */           ProtocolSupport.unsupportedOperation();
/* 2352 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.GetOAuthUserResponse clearUserOrganization()
/*      */         {
/* 2357 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setUserOrganizationAsBytes(byte[] x) {
/* 2360 */           ProtocolSupport.unsupportedOperation();
/* 2361 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setUserOrganization(String v) {
/* 2364 */           ProtocolSupport.unsupportedOperation();
/* 2365 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setUserOrganization(String v, Charset cs) {
/* 2368 */           ProtocolSupport.unsupportedOperation();
/* 2369 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.GetOAuthUserResponse clearIsAdmin()
/*      */         {
/* 2374 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse setIsAdmin(boolean x) {
/* 2377 */           ProtocolSupport.unsupportedOperation();
/* 2378 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.GetOAuthUserResponse mergeFrom(UserServicePb.GetOAuthUserResponse that) {
/* 2382 */           ProtocolSupport.unsupportedOperation();
/* 2383 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2386 */           ProtocolSupport.unsupportedOperation();
/* 2387 */           return false;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse freeze() {
/* 2390 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserResponse unfreeze() {
/* 2393 */           ProtocolSupport.unsupportedOperation();
/* 2394 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2397 */           return true;
/*      */         }
/*      */       };
/* 2421 */       text = new String[6];
/*      */ 
/* 2423 */       text[0] = "ErrorCode";
/* 2424 */       text[1] = "email";
/* 2425 */       text[2] = "user_id";
/* 2426 */       text[3] = "auth_domain";
/* 2427 */       text[4] = "user_organization";
/* 2428 */       text[5] = "is_admin";
/*      */ 
/* 2431 */       types = new int[6];
/*      */ 
/* 2433 */       Arrays.fill(types, 6);
/* 2434 */       types[0] = 0;
/* 2435 */       types[1] = 2;
/* 2436 */       types[2] = 2;
/* 2437 */       types[3] = 2;
/* 2438 */       types[4] = 2;
/* 2439 */       types[5] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2184 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.GetOAuthUserResponse.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("email", "email", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("user_id", "user_id", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("auth_domain", "auth_domain", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("user_organization", "user_organization", 4, 3, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("is_admin", "is_admin", 5, 4, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class GetOAuthUserRequest extends ProtocolMessage<GetOAuthUserRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final GetOAuthUserRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public GetOAuthUserRequest mergeFrom(GetOAuthUserRequest that)
/*      */     {
/* 1666 */       assert (that != this);
/*      */ 
/* 1668 */       if (that.uninterpreted != null) {
/* 1669 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1671 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(GetOAuthUserRequest that) {
/* 1675 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(GetOAuthUserRequest that) {
/* 1679 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(GetOAuthUserRequest that, boolean ignoreUninterpreted) {
/* 1683 */       if (that == null) return false;
/* 1684 */       if (that == this) return true;
/*      */ 
/* 1686 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1691 */       return ((that instanceof GetOAuthUserRequest)) && (equals((GetOAuthUserRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1695 */       int hash = -818578662;
/* 1696 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1697 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1699 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1703 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 1707 */       int n = 0;
/*      */ 
/* 1709 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1714 */       int n = 0;
/*      */ 
/* 1716 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1721 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1725 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public GetOAuthUserRequest newInstance() {
/* 1729 */       return new GetOAuthUserRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1733 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1748 */       if (this.uninterpreted != null)
/* 1749 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1754 */       boolean result = true;
/*      */ 
/* 1756 */       while (source.hasRemaining()) {
/* 1757 */         int tt = source.getVarInt();
/* 1758 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1762 */           result = false;
/* 1763 */           break;
/*      */         default:
/* 1765 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1770 */       return result;
/*      */     }
/*      */ 
/*      */     public GetOAuthUserRequest getDefaultInstanceForType()
/*      */     {
/* 1775 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final GetOAuthUserRequest getDefaultInstance() {
/* 1779 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1809 */       if (this.uninterpreted == null) {
/* 1810 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1812 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1783 */       IMMUTABLE_DEFAULT_INSTANCE = new GetOAuthUserRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.GetOAuthUserRequest mergeFrom(UserServicePb.GetOAuthUserRequest that)
/*      */         {
/* 1790 */           ProtocolSupport.unsupportedOperation();
/* 1791 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1794 */           ProtocolSupport.unsupportedOperation();
/* 1795 */           return false;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserRequest freeze() {
/* 1798 */           return this;
/*      */         }
/*      */         public UserServicePb.GetOAuthUserRequest unfreeze() {
/* 1801 */           ProtocolSupport.unsupportedOperation();
/* 1802 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1805 */           return true;
/*      */         }
/*      */       };
/* 1816 */       text = new String[1];
/*      */ 
/* 1818 */       text[0] = "ErrorCode";
/*      */ 
/* 1821 */       types = new int[1];
/*      */ 
/* 1823 */       Arrays.fill(types, 6);
/* 1824 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1737 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.GetOAuthUserRequest.class, "Z!apphosting/api/user_service.proto\n\036apphosting.GetOAuthUserRequest", new ProtocolType.FieldType[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateLogoutURLResponse extends ProtocolMessage<CreateLogoutURLResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1382 */     private byte[] logout_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateLogoutURLResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int klogout_url = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getLogoutUrlAsBytes()
/*      */     {
/* 1388 */       return this.logout_url_;
/*      */     }
/*      */     public final boolean hasLogoutUrl() {
/* 1391 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateLogoutURLResponse clearLogoutUrl() {
/* 1394 */       this.optional_0_ &= -2;
/* 1395 */       this.logout_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1396 */       return this;
/*      */     }
/*      */     public CreateLogoutURLResponse setLogoutUrlAsBytes(byte[] x) {
/* 1399 */       this.optional_0_ |= 1;
/* 1400 */       this.logout_url_ = x;
/* 1401 */       return this;
/*      */     }
/*      */     public final String getLogoutUrl() {
/* 1404 */       return ProtocolSupport.toStringUtf8(this.logout_url_);
/*      */     }
/*      */     public CreateLogoutURLResponse setLogoutUrl(String v) {
/* 1407 */       if (v == null) throw new NullPointerException();
/* 1408 */       this.optional_0_ |= 1;
/* 1409 */       this.logout_url_ = ProtocolSupport.toBytesUtf8(v);
/* 1410 */       return this;
/*      */     }
/*      */     public final String getLogoutUrl(Charset cs) {
/* 1413 */       return ProtocolSupport.toString(this.logout_url_, cs);
/*      */     }
/*      */     public CreateLogoutURLResponse setLogoutUrl(String v, Charset cs) {
/* 1416 */       if (v == null) throw new NullPointerException();
/* 1417 */       this.optional_0_ |= 1;
/* 1418 */       this.logout_url_ = ProtocolSupport.toBytes(v, cs);
/* 1419 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLResponse mergeFrom(CreateLogoutURLResponse that)
/*      */     {
/* 1426 */       assert (that != this);
/* 1427 */       int this_t0 = this.optional_0_;
/* 1428 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1430 */       if ((that_t0 & 0x1) != 0) {
/* 1431 */         this_t0 |= 1;
/* 1432 */         this.logout_url_ = that.logout_url_;
/*      */       }
/*      */ 
/* 1435 */       if (that.uninterpreted != null) {
/* 1436 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1438 */       this.optional_0_ = this_t0;
/* 1439 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateLogoutURLResponse that) {
/* 1443 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLogoutURLResponse that) {
/* 1447 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLogoutURLResponse that, boolean ignoreUninterpreted) {
/* 1451 */       if (that == null) return false;
/* 1452 */       if (that == this) return true;
/* 1453 */       int this_t0 = this.optional_0_;
/* 1454 */       int that_t0 = that.optional_0_;
/* 1455 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1457 */       if (((this_t0 & 0x1) != 0) && 
/* 1458 */         (!Arrays.equals(this.logout_url_, that.logout_url_))) return false;
/*      */ 
/* 1461 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1466 */       return ((that instanceof CreateLogoutURLResponse)) && (equals((CreateLogoutURLResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1470 */       int hash = 786861354;
/*      */ 
/* 1472 */       int this_t0 = this.optional_0_;
/* 1473 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.logout_url_) : -113);
/* 1474 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1475 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1477 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1481 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1483 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1490 */       int n = 1 + Protocol.stringSize(this.logout_url_.length);
/*      */ 
/* 1492 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1498 */       int n = 6 + this.logout_url_.length;
/*      */ 
/* 1500 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1505 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1509 */       this.optional_0_ = 0;
/* 1510 */       this.logout_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1511 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLResponse newInstance() {
/* 1515 */       return new CreateLogoutURLResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1519 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1538 */       sink.putByte(10);
/* 1539 */       sink.putPrefixedData(this.logout_url_);
/*      */ 
/* 1541 */       if (this.uninterpreted != null)
/* 1542 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1547 */       boolean result = true;
/* 1548 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1550 */       while (source.hasRemaining()) {
/* 1551 */         int tt = source.getVarInt();
/* 1552 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1556 */           result = false;
/* 1557 */           break;
/*      */         case 10:
/* 1560 */           this.logout_url_ = source.getPrefixedData();
/* 1561 */           this_t0 |= 1;
/* 1562 */           break;
/*      */         default:
/* 1564 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1569 */       this.optional_0_ = this_t0;
/* 1570 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLResponse getDefaultInstanceForType()
/*      */     {
/* 1575 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateLogoutURLResponse getDefaultInstance() {
/* 1579 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLResponse freeze()
/*      */     {
/* 1627 */       this.logout_url_ = ProtocolSupport.freezeString(this.logout_url_);
/* 1628 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1631 */       if (this.uninterpreted == null) {
/* 1632 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1634 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1583 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateLogoutURLResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateLogoutURLResponse clearLogoutUrl()
/*      */         {
/* 1591 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLResponse setLogoutUrlAsBytes(byte[] x) {
/* 1594 */           ProtocolSupport.unsupportedOperation();
/* 1595 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLResponse setLogoutUrl(String v) {
/* 1598 */           ProtocolSupport.unsupportedOperation();
/* 1599 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLResponse setLogoutUrl(String v, Charset cs) {
/* 1602 */           ProtocolSupport.unsupportedOperation();
/* 1603 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLogoutURLResponse mergeFrom(UserServicePb.CreateLogoutURLResponse that) {
/* 1607 */           ProtocolSupport.unsupportedOperation();
/* 1608 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1611 */           ProtocolSupport.unsupportedOperation();
/* 1612 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLResponse freeze() {
/* 1615 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLResponse unfreeze() {
/* 1618 */           ProtocolSupport.unsupportedOperation();
/* 1619 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1622 */           return true;
/*      */         }
/*      */       };
/* 1639 */       text = new String[2];
/*      */ 
/* 1641 */       text[0] = "ErrorCode";
/* 1642 */       text[1] = "logout_url";
/*      */ 
/* 1645 */       types = new int[2];
/*      */ 
/* 1647 */       Arrays.fill(types, 6);
/* 1648 */       types[0] = 0;
/* 1649 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1523 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateLogoutURLResponse.class, "Z!apphosting/api/user_service.proto\n\"apphosting.CreateLogoutURLResponse\023\032\nlogout_url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("logout_url", "logout_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateLogoutURLRequest extends ProtocolMessage<CreateLogoutURLRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1009 */     private byte[] destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1010 */     private byte[] auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateLogoutURLRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kdestination_url = 1;
/*      */     public static final int kauth_domain = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getDestinationUrlAsBytes()
/*      */     {
/* 1016 */       return this.destination_url_;
/*      */     }
/*      */     public final boolean hasDestinationUrl() {
/* 1019 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateLogoutURLRequest clearDestinationUrl() {
/* 1022 */       this.optional_0_ &= -2;
/* 1023 */       this.destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1024 */       return this;
/*      */     }
/*      */     public CreateLogoutURLRequest setDestinationUrlAsBytes(byte[] x) {
/* 1027 */       this.optional_0_ |= 1;
/* 1028 */       this.destination_url_ = x;
/* 1029 */       return this;
/*      */     }
/*      */     public final String getDestinationUrl() {
/* 1032 */       return ProtocolSupport.toStringUtf8(this.destination_url_);
/*      */     }
/*      */     public CreateLogoutURLRequest setDestinationUrl(String v) {
/* 1035 */       if (v == null) throw new NullPointerException();
/* 1036 */       this.optional_0_ |= 1;
/* 1037 */       this.destination_url_ = ProtocolSupport.toBytesUtf8(v);
/* 1038 */       return this;
/*      */     }
/*      */     public final String getDestinationUrl(Charset cs) {
/* 1041 */       return ProtocolSupport.toString(this.destination_url_, cs);
/*      */     }
/*      */     public CreateLogoutURLRequest setDestinationUrl(String v, Charset cs) {
/* 1044 */       if (v == null) throw new NullPointerException();
/* 1045 */       this.optional_0_ |= 1;
/* 1046 */       this.destination_url_ = ProtocolSupport.toBytes(v, cs);
/* 1047 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getAuthDomainAsBytes()
/*      */     {
/* 1052 */       return this.auth_domain_;
/*      */     }
/*      */     public final boolean hasAuthDomain() {
/* 1055 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public CreateLogoutURLRequest clearAuthDomain() {
/* 1058 */       this.optional_0_ &= -3;
/* 1059 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1060 */       return this;
/*      */     }
/*      */     public CreateLogoutURLRequest setAuthDomainAsBytes(byte[] x) {
/* 1063 */       this.optional_0_ |= 2;
/* 1064 */       this.auth_domain_ = x;
/* 1065 */       return this;
/*      */     }
/*      */     public final String getAuthDomain() {
/* 1068 */       return ProtocolSupport.toStringUtf8(this.auth_domain_);
/*      */     }
/*      */     public CreateLogoutURLRequest setAuthDomain(String v) {
/* 1071 */       if (v == null) throw new NullPointerException();
/* 1072 */       this.optional_0_ |= 2;
/* 1073 */       this.auth_domain_ = ProtocolSupport.toBytesUtf8(v);
/* 1074 */       return this;
/*      */     }
/*      */     public final String getAuthDomain(Charset cs) {
/* 1077 */       return ProtocolSupport.toString(this.auth_domain_, cs);
/*      */     }
/*      */     public CreateLogoutURLRequest setAuthDomain(String v, Charset cs) {
/* 1080 */       if (v == null) throw new NullPointerException();
/* 1081 */       this.optional_0_ |= 2;
/* 1082 */       this.auth_domain_ = ProtocolSupport.toBytes(v, cs);
/* 1083 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLRequest mergeFrom(CreateLogoutURLRequest that)
/*      */     {
/* 1090 */       assert (that != this);
/* 1091 */       int this_t0 = this.optional_0_;
/* 1092 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1094 */       if ((that_t0 & 0x1) != 0) {
/* 1095 */         this_t0 |= 1;
/* 1096 */         this.destination_url_ = that.destination_url_;
/*      */       }
/*      */ 
/* 1099 */       if ((that_t0 & 0x2) != 0) {
/* 1100 */         this_t0 |= 2;
/* 1101 */         this.auth_domain_ = that.auth_domain_;
/*      */       }
/*      */ 
/* 1104 */       if (that.uninterpreted != null) {
/* 1105 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1107 */       this.optional_0_ = this_t0;
/* 1108 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateLogoutURLRequest that) {
/* 1112 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLogoutURLRequest that) {
/* 1116 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLogoutURLRequest that, boolean ignoreUninterpreted) {
/* 1120 */       if (that == null) return false;
/* 1121 */       if (that == this) return true;
/* 1122 */       int this_t0 = this.optional_0_;
/* 1123 */       int that_t0 = that.optional_0_;
/* 1124 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1126 */       if (((this_t0 & 0x1) != 0) && 
/* 1127 */         (!Arrays.equals(this.destination_url_, that.destination_url_))) return false;
/*      */ 
/* 1130 */       if (((this_t0 & 0x2) != 0) && 
/* 1131 */         (!Arrays.equals(this.auth_domain_, that.auth_domain_))) return false;
/*      */ 
/* 1134 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1139 */       return ((that instanceof CreateLogoutURLRequest)) && (equals((CreateLogoutURLRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1143 */       int hash = 265628058;
/*      */ 
/* 1145 */       int this_t0 = this.optional_0_;
/* 1146 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.destination_url_) : -113);
/*      */ 
/* 1148 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.auth_domain_) : -113);
/* 1149 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1150 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1152 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1156 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1158 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1165 */       int n = 1 + Protocol.stringSize(this.destination_url_.length);
/* 1166 */       int this_t0 = this.optional_0_;
/* 1167 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 1169 */         n += 1 + Protocol.stringSize(this.auth_domain_.length);
/*      */       }
/*      */ 
/* 1172 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1178 */       int n = 6 + this.destination_url_.length;
/* 1179 */       int this_t0 = this.optional_0_;
/* 1180 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 1182 */         n += 6 + this.auth_domain_.length;
/*      */       }
/*      */ 
/* 1185 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1190 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1194 */       this.optional_0_ = 0;
/* 1195 */       this.destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1196 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1197 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLRequest newInstance() {
/* 1201 */       return new CreateLogoutURLRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1205 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1227 */       sink.putByte(10);
/* 1228 */       sink.putPrefixedData(this.destination_url_);
/*      */ 
/* 1230 */       int this_t0 = this.optional_0_;
/* 1231 */       if ((this_t0 & 0x2) != 0) {
/* 1232 */         sink.putByte(18);
/* 1233 */         sink.putPrefixedData(this.auth_domain_);
/*      */       }
/*      */ 
/* 1236 */       if (this.uninterpreted != null)
/* 1237 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1242 */       boolean result = true;
/* 1243 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1245 */       while (source.hasRemaining()) {
/* 1246 */         int tt = source.getVarInt();
/* 1247 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1251 */           result = false;
/* 1252 */           break;
/*      */         case 10:
/* 1255 */           this.destination_url_ = source.getPrefixedData();
/* 1256 */           this_t0 |= 1;
/* 1257 */           break;
/*      */         case 18:
/* 1260 */           this.auth_domain_ = source.getPrefixedData();
/* 1261 */           this_t0 |= 2;
/* 1262 */           break;
/*      */         default:
/* 1264 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1269 */       this.optional_0_ = this_t0;
/* 1270 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLRequest getDefaultInstanceForType()
/*      */     {
/* 1275 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateLogoutURLRequest getDefaultInstance() {
/* 1279 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateLogoutURLRequest freeze()
/*      */     {
/* 1344 */       this.destination_url_ = ProtocolSupport.freezeString(this.destination_url_);
/* 1345 */       this.auth_domain_ = ProtocolSupport.freezeString(this.auth_domain_);
/* 1346 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1349 */       if (this.uninterpreted == null) {
/* 1350 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1352 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1283 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateLogoutURLRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateLogoutURLRequest clearDestinationUrl()
/*      */         {
/* 1291 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest setDestinationUrlAsBytes(byte[] x) {
/* 1294 */           ProtocolSupport.unsupportedOperation();
/* 1295 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest setDestinationUrl(String v) {
/* 1298 */           ProtocolSupport.unsupportedOperation();
/* 1299 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest setDestinationUrl(String v, Charset cs) {
/* 1302 */           ProtocolSupport.unsupportedOperation();
/* 1303 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLogoutURLRequest clearAuthDomain()
/*      */         {
/* 1308 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest setAuthDomainAsBytes(byte[] x) {
/* 1311 */           ProtocolSupport.unsupportedOperation();
/* 1312 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest setAuthDomain(String v) {
/* 1315 */           ProtocolSupport.unsupportedOperation();
/* 1316 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest setAuthDomain(String v, Charset cs) {
/* 1319 */           ProtocolSupport.unsupportedOperation();
/* 1320 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLogoutURLRequest mergeFrom(UserServicePb.CreateLogoutURLRequest that) {
/* 1324 */           ProtocolSupport.unsupportedOperation();
/* 1325 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1328 */           ProtocolSupport.unsupportedOperation();
/* 1329 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest freeze() {
/* 1332 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLogoutURLRequest unfreeze() {
/* 1335 */           ProtocolSupport.unsupportedOperation();
/* 1336 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1339 */           return true;
/*      */         }
/*      */       };
/* 1358 */       text = new String[3];
/*      */ 
/* 1360 */       text[0] = "ErrorCode";
/* 1361 */       text[1] = "destination_url";
/* 1362 */       text[2] = "auth_domain";
/*      */ 
/* 1365 */       types = new int[3];
/*      */ 
/* 1367 */       Arrays.fill(types, 6);
/* 1368 */       types[0] = 0;
/* 1369 */       types[1] = 2;
/* 1370 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1209 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateLogoutURLRequest.class, "Z!apphosting/api/user_service.proto\n!apphosting.CreateLogoutURLRequest\023\032\017destination_url \001(\0020\t8\002\024\023\032\013auth_domain \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("destination_url", "destination_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("auth_domain", "auth_domain", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateLoginURLResponse extends ProtocolMessage<CreateLoginURLResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  730 */     private byte[] login_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateLoginURLResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int klogin_url = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getLoginUrlAsBytes()
/*      */     {
/*  736 */       return this.login_url_;
/*      */     }
/*      */     public final boolean hasLoginUrl() {
/*  739 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateLoginURLResponse clearLoginUrl() {
/*  742 */       this.optional_0_ &= -2;
/*  743 */       this.login_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  744 */       return this;
/*      */     }
/*      */     public CreateLoginURLResponse setLoginUrlAsBytes(byte[] x) {
/*  747 */       this.optional_0_ |= 1;
/*  748 */       this.login_url_ = x;
/*  749 */       return this;
/*      */     }
/*      */     public final String getLoginUrl() {
/*  752 */       return ProtocolSupport.toStringUtf8(this.login_url_);
/*      */     }
/*      */     public CreateLoginURLResponse setLoginUrl(String v) {
/*  755 */       if (v == null) throw new NullPointerException();
/*  756 */       this.optional_0_ |= 1;
/*  757 */       this.login_url_ = ProtocolSupport.toBytesUtf8(v);
/*  758 */       return this;
/*      */     }
/*      */     public final String getLoginUrl(Charset cs) {
/*  761 */       return ProtocolSupport.toString(this.login_url_, cs);
/*      */     }
/*      */     public CreateLoginURLResponse setLoginUrl(String v, Charset cs) {
/*  764 */       if (v == null) throw new NullPointerException();
/*  765 */       this.optional_0_ |= 1;
/*  766 */       this.login_url_ = ProtocolSupport.toBytes(v, cs);
/*  767 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLResponse mergeFrom(CreateLoginURLResponse that)
/*      */     {
/*  774 */       assert (that != this);
/*  775 */       int this_t0 = this.optional_0_;
/*  776 */       int that_t0 = that.optional_0_;
/*      */ 
/*  778 */       if ((that_t0 & 0x1) != 0) {
/*  779 */         this_t0 |= 1;
/*  780 */         this.login_url_ = that.login_url_;
/*      */       }
/*      */ 
/*  783 */       if (that.uninterpreted != null) {
/*  784 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  786 */       this.optional_0_ = this_t0;
/*  787 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateLoginURLResponse that) {
/*  791 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLoginURLResponse that) {
/*  795 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLoginURLResponse that, boolean ignoreUninterpreted) {
/*  799 */       if (that == null) return false;
/*  800 */       if (that == this) return true;
/*  801 */       int this_t0 = this.optional_0_;
/*  802 */       int that_t0 = that.optional_0_;
/*  803 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  805 */       if (((this_t0 & 0x1) != 0) && 
/*  806 */         (!Arrays.equals(this.login_url_, that.login_url_))) return false;
/*      */ 
/*  809 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  814 */       return ((that instanceof CreateLoginURLResponse)) && (equals((CreateLoginURLResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  818 */       int hash = -1047485142;
/*      */ 
/*  820 */       int this_t0 = this.optional_0_;
/*  821 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.login_url_) : -113);
/*  822 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  823 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  825 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  829 */       int this_t0 = this.optional_0_;
/*      */ 
/*  831 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  838 */       int n = 1 + Protocol.stringSize(this.login_url_.length);
/*      */ 
/*  840 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  846 */       int n = 6 + this.login_url_.length;
/*      */ 
/*  848 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  853 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  857 */       this.optional_0_ = 0;
/*  858 */       this.login_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  859 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLResponse newInstance() {
/*  863 */       return new CreateLoginURLResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  867 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  886 */       sink.putByte(10);
/*  887 */       sink.putPrefixedData(this.login_url_);
/*      */ 
/*  889 */       if (this.uninterpreted != null)
/*  890 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  895 */       boolean result = true;
/*  896 */       int this_t0 = this.optional_0_;
/*      */ 
/*  898 */       while (source.hasRemaining()) {
/*  899 */         int tt = source.getVarInt();
/*  900 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  904 */           result = false;
/*  905 */           break;
/*      */         case 10:
/*  908 */           this.login_url_ = source.getPrefixedData();
/*  909 */           this_t0 |= 1;
/*  910 */           break;
/*      */         default:
/*  912 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  917 */       this.optional_0_ = this_t0;
/*  918 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLResponse getDefaultInstanceForType()
/*      */     {
/*  923 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateLoginURLResponse getDefaultInstance() {
/*  927 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLResponse freeze()
/*      */     {
/*  975 */       this.login_url_ = ProtocolSupport.freezeString(this.login_url_);
/*  976 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  979 */       if (this.uninterpreted == null) {
/*  980 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  982 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  931 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateLoginURLResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateLoginURLResponse clearLoginUrl()
/*      */         {
/*  939 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLResponse setLoginUrlAsBytes(byte[] x) {
/*  942 */           ProtocolSupport.unsupportedOperation();
/*  943 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLResponse setLoginUrl(String v) {
/*  946 */           ProtocolSupport.unsupportedOperation();
/*  947 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLResponse setLoginUrl(String v, Charset cs) {
/*  950 */           ProtocolSupport.unsupportedOperation();
/*  951 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLoginURLResponse mergeFrom(UserServicePb.CreateLoginURLResponse that) {
/*  955 */           ProtocolSupport.unsupportedOperation();
/*  956 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  959 */           ProtocolSupport.unsupportedOperation();
/*  960 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLResponse freeze() {
/*  963 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLResponse unfreeze() {
/*  966 */           ProtocolSupport.unsupportedOperation();
/*  967 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  970 */           return true;
/*      */         }
/*      */       };
/*  987 */       text = new String[2];
/*      */ 
/*  989 */       text[0] = "ErrorCode";
/*  990 */       text[1] = "login_url";
/*      */ 
/*  993 */       types = new int[2];
/*      */ 
/*  995 */       Arrays.fill(types, 6);
/*  996 */       types[0] = 0;
/*  997 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  871 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateLoginURLResponse.class, "Z!apphosting/api/user_service.proto\n!apphosting.CreateLoginURLResponse\023\032\tlogin_url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("login_url", "login_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateLoginURLRequest extends ProtocolMessage<CreateLoginURLRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  259 */     private byte[] destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  260 */     private byte[] auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  261 */     private byte[] federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateLoginURLRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kdestination_url = 1;
/*      */     public static final int kauth_domain = 2;
/*      */     public static final int kfederated_identity = 3;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getDestinationUrlAsBytes()
/*      */     {
/*  267 */       return this.destination_url_;
/*      */     }
/*      */     public final boolean hasDestinationUrl() {
/*  270 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateLoginURLRequest clearDestinationUrl() {
/*  273 */       this.optional_0_ &= -2;
/*  274 */       this.destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  275 */       return this;
/*      */     }
/*      */     public CreateLoginURLRequest setDestinationUrlAsBytes(byte[] x) {
/*  278 */       this.optional_0_ |= 1;
/*  279 */       this.destination_url_ = x;
/*  280 */       return this;
/*      */     }
/*      */     public final String getDestinationUrl() {
/*  283 */       return ProtocolSupport.toStringUtf8(this.destination_url_);
/*      */     }
/*      */     public CreateLoginURLRequest setDestinationUrl(String v) {
/*  286 */       if (v == null) throw new NullPointerException();
/*  287 */       this.optional_0_ |= 1;
/*  288 */       this.destination_url_ = ProtocolSupport.toBytesUtf8(v);
/*  289 */       return this;
/*      */     }
/*      */     public final String getDestinationUrl(Charset cs) {
/*  292 */       return ProtocolSupport.toString(this.destination_url_, cs);
/*      */     }
/*      */     public CreateLoginURLRequest setDestinationUrl(String v, Charset cs) {
/*  295 */       if (v == null) throw new NullPointerException();
/*  296 */       this.optional_0_ |= 1;
/*  297 */       this.destination_url_ = ProtocolSupport.toBytes(v, cs);
/*  298 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getAuthDomainAsBytes()
/*      */     {
/*  303 */       return this.auth_domain_;
/*      */     }
/*      */     public final boolean hasAuthDomain() {
/*  306 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public CreateLoginURLRequest clearAuthDomain() {
/*  309 */       this.optional_0_ &= -3;
/*  310 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  311 */       return this;
/*      */     }
/*      */     public CreateLoginURLRequest setAuthDomainAsBytes(byte[] x) {
/*  314 */       this.optional_0_ |= 2;
/*  315 */       this.auth_domain_ = x;
/*  316 */       return this;
/*      */     }
/*      */     public final String getAuthDomain() {
/*  319 */       return ProtocolSupport.toStringUtf8(this.auth_domain_);
/*      */     }
/*      */     public CreateLoginURLRequest setAuthDomain(String v) {
/*  322 */       if (v == null) throw new NullPointerException();
/*  323 */       this.optional_0_ |= 2;
/*  324 */       this.auth_domain_ = ProtocolSupport.toBytesUtf8(v);
/*  325 */       return this;
/*      */     }
/*      */     public final String getAuthDomain(Charset cs) {
/*  328 */       return ProtocolSupport.toString(this.auth_domain_, cs);
/*      */     }
/*      */     public CreateLoginURLRequest setAuthDomain(String v, Charset cs) {
/*  331 */       if (v == null) throw new NullPointerException();
/*  332 */       this.optional_0_ |= 2;
/*  333 */       this.auth_domain_ = ProtocolSupport.toBytes(v, cs);
/*  334 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFederatedIdentityAsBytes()
/*      */     {
/*  339 */       return this.federated_identity_;
/*      */     }
/*      */     public final boolean hasFederatedIdentity() {
/*  342 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public CreateLoginURLRequest clearFederatedIdentity() {
/*  345 */       this.optional_0_ &= -5;
/*  346 */       this.federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  347 */       return this;
/*      */     }
/*      */     public CreateLoginURLRequest setFederatedIdentityAsBytes(byte[] x) {
/*  350 */       this.optional_0_ |= 4;
/*  351 */       this.federated_identity_ = x;
/*  352 */       return this;
/*      */     }
/*      */     public final String getFederatedIdentity() {
/*  355 */       return ProtocolSupport.toStringUtf8(this.federated_identity_);
/*      */     }
/*      */     public CreateLoginURLRequest setFederatedIdentity(String v) {
/*  358 */       if (v == null) throw new NullPointerException();
/*  359 */       this.optional_0_ |= 4;
/*  360 */       this.federated_identity_ = ProtocolSupport.toBytesUtf8(v);
/*  361 */       return this;
/*      */     }
/*      */     public final String getFederatedIdentity(Charset cs) {
/*  364 */       return ProtocolSupport.toString(this.federated_identity_, cs);
/*      */     }
/*      */     public CreateLoginURLRequest setFederatedIdentity(String v, Charset cs) {
/*  367 */       if (v == null) throw new NullPointerException();
/*  368 */       this.optional_0_ |= 4;
/*  369 */       this.federated_identity_ = ProtocolSupport.toBytes(v, cs);
/*  370 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLRequest mergeFrom(CreateLoginURLRequest that)
/*      */     {
/*  377 */       assert (that != this);
/*  378 */       int this_t0 = this.optional_0_;
/*  379 */       int that_t0 = that.optional_0_;
/*      */ 
/*  381 */       if ((that_t0 & 0x1) != 0) {
/*  382 */         this_t0 |= 1;
/*  383 */         this.destination_url_ = that.destination_url_;
/*      */       }
/*      */ 
/*  386 */       if ((that_t0 & 0x2) != 0) {
/*  387 */         this_t0 |= 2;
/*  388 */         this.auth_domain_ = that.auth_domain_;
/*      */       }
/*      */ 
/*  391 */       if ((that_t0 & 0x4) != 0) {
/*  392 */         this_t0 |= 4;
/*  393 */         this.federated_identity_ = that.federated_identity_;
/*      */       }
/*      */ 
/*  396 */       if (that.uninterpreted != null) {
/*  397 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  399 */       this.optional_0_ = this_t0;
/*  400 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateLoginURLRequest that) {
/*  404 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLoginURLRequest that) {
/*  408 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateLoginURLRequest that, boolean ignoreUninterpreted) {
/*  412 */       if (that == null) return false;
/*  413 */       if (that == this) return true;
/*  414 */       int this_t0 = this.optional_0_;
/*  415 */       int that_t0 = that.optional_0_;
/*  416 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  418 */       if (((this_t0 & 0x1) != 0) && 
/*  419 */         (!Arrays.equals(this.destination_url_, that.destination_url_))) return false;
/*      */ 
/*  422 */       if (((this_t0 & 0x2) != 0) && 
/*  423 */         (!Arrays.equals(this.auth_domain_, that.auth_domain_))) return false;
/*      */ 
/*  426 */       if (((this_t0 & 0x4) != 0) && 
/*  427 */         (!Arrays.equals(this.federated_identity_, that.federated_identity_))) return false;
/*      */ 
/*  430 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  435 */       return ((that instanceof CreateLoginURLRequest)) && (equals((CreateLoginURLRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  439 */       int hash = 1296623572;
/*      */ 
/*  441 */       int this_t0 = this.optional_0_;
/*  442 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.destination_url_) : -113);
/*      */ 
/*  444 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.auth_domain_) : -113);
/*      */ 
/*  446 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.federated_identity_) : -113);
/*  447 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  448 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  450 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  454 */       int this_t0 = this.optional_0_;
/*      */ 
/*  456 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  463 */       int n = 1 + Protocol.stringSize(this.destination_url_.length);
/*  464 */       int this_t0 = this.optional_0_;
/*  465 */       if ((this_t0 & 0x6) != 0) {
/*  466 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/*  468 */           n += 1 + Protocol.stringSize(this.auth_domain_.length);
/*      */         }
/*  470 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/*  472 */           n += 1 + Protocol.stringSize(this.federated_identity_.length);
/*      */         }
/*      */       }
/*      */ 
/*  476 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  482 */       int n = 6 + this.destination_url_.length;
/*  483 */       int this_t0 = this.optional_0_;
/*  484 */       if ((this_t0 & 0x6) != 0) {
/*  485 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/*  487 */           n += 6 + this.auth_domain_.length;
/*      */         }
/*  489 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/*  491 */           n += 6 + this.federated_identity_.length;
/*      */         }
/*      */       }
/*      */ 
/*  495 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  500 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  504 */       this.optional_0_ = 0;
/*  505 */       this.destination_url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  506 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  507 */       this.federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  508 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLRequest newInstance() {
/*  512 */       return new CreateLoginURLRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  516 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  544 */       sink.putByte(10);
/*  545 */       sink.putPrefixedData(this.destination_url_);
/*      */ 
/*  547 */       int this_t0 = this.optional_0_;
/*  548 */       if ((this_t0 & 0x2) != 0) {
/*  549 */         sink.putByte(18);
/*  550 */         sink.putPrefixedData(this.auth_domain_);
/*      */       }
/*      */ 
/*  553 */       if ((this_t0 & 0x4) != 0) {
/*  554 */         sink.putByte(26);
/*  555 */         sink.putPrefixedData(this.federated_identity_);
/*      */       }
/*      */ 
/*  558 */       if (this.uninterpreted != null)
/*  559 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  564 */       boolean result = true;
/*  565 */       int this_t0 = this.optional_0_;
/*      */ 
/*  567 */       while (source.hasRemaining()) {
/*  568 */         int tt = source.getVarInt();
/*  569 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  573 */           result = false;
/*  574 */           break;
/*      */         case 10:
/*  577 */           this.destination_url_ = source.getPrefixedData();
/*  578 */           this_t0 |= 1;
/*  579 */           break;
/*      */         case 18:
/*  582 */           this.auth_domain_ = source.getPrefixedData();
/*  583 */           this_t0 |= 2;
/*  584 */           break;
/*      */         case 26:
/*  587 */           this.federated_identity_ = source.getPrefixedData();
/*  588 */           this_t0 |= 4;
/*  589 */           break;
/*      */         default:
/*  591 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  596 */       this.optional_0_ = this_t0;
/*  597 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLRequest getDefaultInstanceForType()
/*      */     {
/*  602 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateLoginURLRequest getDefaultInstance() {
/*  606 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateLoginURLRequest freeze()
/*      */     {
/*  688 */       this.destination_url_ = ProtocolSupport.freezeString(this.destination_url_);
/*  689 */       this.auth_domain_ = ProtocolSupport.freezeString(this.auth_domain_);
/*  690 */       this.federated_identity_ = ProtocolSupport.freezeString(this.federated_identity_);
/*  691 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  694 */       if (this.uninterpreted == null) {
/*  695 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  697 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  610 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateLoginURLRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.CreateLoginURLRequest clearDestinationUrl()
/*      */         {
/*  618 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setDestinationUrlAsBytes(byte[] x) {
/*  621 */           ProtocolSupport.unsupportedOperation();
/*  622 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setDestinationUrl(String v) {
/*  625 */           ProtocolSupport.unsupportedOperation();
/*  626 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setDestinationUrl(String v, Charset cs) {
/*  629 */           ProtocolSupport.unsupportedOperation();
/*  630 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLoginURLRequest clearAuthDomain()
/*      */         {
/*  635 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setAuthDomainAsBytes(byte[] x) {
/*  638 */           ProtocolSupport.unsupportedOperation();
/*  639 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setAuthDomain(String v) {
/*  642 */           ProtocolSupport.unsupportedOperation();
/*  643 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setAuthDomain(String v, Charset cs) {
/*  646 */           ProtocolSupport.unsupportedOperation();
/*  647 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLoginURLRequest clearFederatedIdentity()
/*      */         {
/*  652 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setFederatedIdentityAsBytes(byte[] x) {
/*  655 */           ProtocolSupport.unsupportedOperation();
/*  656 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setFederatedIdentity(String v) {
/*  659 */           ProtocolSupport.unsupportedOperation();
/*  660 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest setFederatedIdentity(String v, Charset cs) {
/*  663 */           ProtocolSupport.unsupportedOperation();
/*  664 */           return this;
/*      */         }
/*      */ 
/*      */         public UserServicePb.CreateLoginURLRequest mergeFrom(UserServicePb.CreateLoginURLRequest that) {
/*  668 */           ProtocolSupport.unsupportedOperation();
/*  669 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  672 */           ProtocolSupport.unsupportedOperation();
/*  673 */           return false;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest freeze() {
/*  676 */           return this;
/*      */         }
/*      */         public UserServicePb.CreateLoginURLRequest unfreeze() {
/*  679 */           ProtocolSupport.unsupportedOperation();
/*  680 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  683 */           return true;
/*      */         }
/*      */       };
/*  704 */       text = new String[4];
/*      */ 
/*  706 */       text[0] = "ErrorCode";
/*  707 */       text[1] = "destination_url";
/*  708 */       text[2] = "auth_domain";
/*  709 */       text[3] = "federated_identity";
/*      */ 
/*  712 */       types = new int[4];
/*      */ 
/*  714 */       Arrays.fill(types, 6);
/*  715 */       types[0] = 0;
/*  716 */       types[1] = 2;
/*  717 */       types[2] = 2;
/*  718 */       types[3] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  520 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.CreateLoginURLRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("destination_url", "destination_url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("auth_domain", "auth_domain", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("federated_identity", "federated_identity", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class UserServiceError extends ProtocolMessage<UserServiceError>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final UserServiceError IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public UserServiceError mergeFrom(UserServiceError that)
/*      */     {
/*   79 */       assert (that != this);
/*      */ 
/*   81 */       if (that.uninterpreted != null) {
/*   82 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   84 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(UserServiceError that) {
/*   88 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(UserServiceError that) {
/*   92 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(UserServiceError that, boolean ignoreUninterpreted) {
/*   96 */       if (that == null) return false;
/*   97 */       if (that == this) return true;
/*      */ 
/*   99 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  104 */       return ((that instanceof UserServiceError)) && (equals((UserServiceError)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  108 */       int hash = 203548245;
/*  109 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  110 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  112 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  116 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  120 */       int n = 0;
/*      */ 
/*  122 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  127 */       int n = 0;
/*      */ 
/*  129 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  134 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  138 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public UserServiceError newInstance() {
/*  142 */       return new UserServiceError();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  146 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  171 */       if (this.uninterpreted != null)
/*  172 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  177 */       boolean result = true;
/*      */ 
/*  179 */       while (source.hasRemaining()) {
/*  180 */         int tt = source.getVarInt();
/*  181 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  185 */           result = false;
/*  186 */           break;
/*      */         default:
/*  188 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  193 */       return result;
/*      */     }
/*      */ 
/*      */     public UserServiceError getDefaultInstanceForType()
/*      */     {
/*  198 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final UserServiceError getDefaultInstance() {
/*  202 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  232 */       if (this.uninterpreted == null) {
/*  233 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  235 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  206 */       IMMUTABLE_DEFAULT_INSTANCE = new UserServiceError()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public UserServicePb.UserServiceError mergeFrom(UserServicePb.UserServiceError that)
/*      */         {
/*  213 */           ProtocolSupport.unsupportedOperation();
/*  214 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  217 */           ProtocolSupport.unsupportedOperation();
/*  218 */           return false;
/*      */         }
/*      */         public UserServicePb.UserServiceError freeze() {
/*  221 */           return this;
/*      */         }
/*      */         public UserServicePb.UserServiceError unfreeze() {
/*  224 */           ProtocolSupport.unsupportedOperation();
/*  225 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  228 */           return true;
/*      */         }
/*      */       };
/*  239 */       text = new String[1];
/*      */ 
/*  241 */       text[0] = "ErrorCode";
/*      */ 
/*  244 */       types = new int[1];
/*      */ 
/*  246 */       Arrays.fill(types, 6);
/*  247 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  150 */       private static final ProtocolType protocolType = new ProtocolType(UserServicePb.UserServiceError.class, "", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   47 */       OK(0), 
/*   48 */       REDIRECT_URL_TOO_LONG(1), 
/*   49 */       NOT_ALLOWED(2), 
/*   50 */       OAUTH_INVALID_TOKEN(3), 
/*   51 */       OAUTH_INVALID_REQUEST(4), 
/*   52 */       OAUTH_ERROR(5);
/*      */ 
/*      */       public static final ErrorCode ErrorCode_MIN;
/*      */       public static final ErrorCode ErrorCode_MAX;
/*      */       private final int value;
/*      */ 
/*   57 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   60 */         switch (value) { case 0:
/*   61 */           return OK;
/*      */         case 1:
/*   62 */           return REDIRECT_URL_TOO_LONG;
/*      */         case 2:
/*   63 */           return NOT_ALLOWED;
/*      */         case 3:
/*   64 */           return OAUTH_INVALID_TOKEN;
/*      */         case 4:
/*   65 */           return OAUTH_INVALID_REQUEST;
/*      */         case 5:
/*   66 */           return OAUTH_ERROR;
/*      */         }
/*   68 */         return null;
/*      */       }
/*      */ 
/*      */       private ErrorCode(int v) {
/*   72 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   54 */         ErrorCode_MIN = OK;
/*   55 */         ErrorCode_MAX = OAUTH_ERROR;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.api.UserServicePb
 * JD-Core Version:    0.6.0
 */