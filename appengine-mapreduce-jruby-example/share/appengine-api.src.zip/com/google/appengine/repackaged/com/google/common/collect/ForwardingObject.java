/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingObject
/*    */ {
/*    */   protected abstract Object delegate();
/*    */ 
/*    */   public String toString()
/*    */   {
/* 72 */     return delegate().toString();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingObject
 * JD-Core Version:    0.6.0
 */