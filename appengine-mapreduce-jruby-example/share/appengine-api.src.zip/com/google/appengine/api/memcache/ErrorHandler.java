package com.google.appengine.api.memcache;

public abstract interface ErrorHandler
{
  public abstract void handleDeserializationError(InvalidValueException paramInvalidValueException);

  public abstract void handleServiceError(MemcacheServiceException paramMemcacheServiceException);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.ErrorHandler
 * JD-Core Version:    0.6.0
 */