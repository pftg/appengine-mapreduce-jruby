/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class Tracer
/*     */ {
/* 164 */   static final Logger logger = Logger.getLogger(Tracer.class.getName());
/*     */   private static volatile boolean defaultPrettyPrint;
/* 176 */   private static List<TracingStatistic> extraTracingStatistics = new CopyOnWriteArrayList();
/*     */   private long[] extraTracingValues;
/*     */   private final String type;
/*     */   private final String comment;
/*     */   private final long startTimeMs;
/*     */   private long stopTimeMs;
/*     */   final Thread startThread;
/*     */   static final int MAX_TRACE_SIZE = 1000;
/* 221 */   static InternalClock clock = new InternalClock() {
/*     */     public long currentTimeMillis() {
/* 223 */       return System.currentTimeMillis();
/*     */     }
/* 221 */   };
/*     */ 
/* 332 */   private static final char[] MANY_SPACES = "                                                        ".toCharArray();
/*     */   private static AtomicTracerStatMap typeToCountMap;
/*     */   private static AtomicTracerStatMap typeToSilentMap;
/*     */   private static AtomicTracerStatMap typeToTimeMap;
/* 622 */   private static final Stat ZERO_STAT = new Stat();
/*     */ 
/* 940 */   private static ThreadLocal<ThreadTrace> traces = new ThreadLocal();
/*     */ 
/*     */   public Tracer(@Nullable String type, @Nullable String comment)
/*     */   {
/* 235 */     this.type = type;
/* 236 */     this.comment = (comment == null ? "" : comment);
/* 237 */     this.startTimeMs = clock.currentTimeMillis();
/* 238 */     this.startThread = Thread.currentThread();
/*     */     int i;
/* 239 */     if (!extraTracingStatistics.isEmpty()) {
/* 240 */       int size = extraTracingStatistics.size();
/* 241 */       this.extraTracingValues = new long[size];
/* 242 */       i = 0;
/* 243 */       for (TracingStatistic tracingStatistic : extraTracingStatistics) {
/* 244 */         this.extraTracingValues[i] = tracingStatistic.start(this.startThread);
/* 245 */         i++;
/*     */       }
/*     */     }
/*     */ 
/* 249 */     ThreadTrace trace = getThreadTrace();
/*     */ 
/* 252 */     if (!trace.isInitialized()) {
/* 253 */       return;
/*     */     }
/*     */ 
/* 257 */     if (trace.events.size() >= 1000) {
/* 258 */       logger.log(Level.WARNING, "Giant thread trace. Too many Tracers created. Clearing to avoid memory leak.", new Throwable(trace.toString()));
/*     */ 
/* 262 */       trace.truncateEvents();
/*     */     }
/*     */ 
/* 266 */     if (trace.outstandingEvents.size() >= 1000) {
/* 267 */       logger.log(Level.WARNING, "Too many outstanding Tracers. Tracer.stop() is missing or Tracer.stop() is not wrapped in a try/finally block. Clearing to avoid memory leak.", new Throwable(trace.toString()));
/*     */ 
/* 273 */       trace.truncateOutstandingEvents();
/*     */     }
/*     */ 
/* 276 */     trace.startEvent(this);
/*     */   }
/*     */ 
/*     */   public Tracer(@Nullable String comment)
/*     */   {
/* 285 */     this(null, comment);
/*     */   }
/*     */ 
/*     */   public static Tracer shortName(@Nullable Object object, @Nullable String comment)
/*     */   {
/* 296 */     if (object == null) {
/* 297 */       return new Tracer(comment);
/*     */     }
/* 299 */     return new Tracer(object.getClass().getSimpleName(), comment);
/*     */   }
/*     */ 
/*     */   private static void appendPaddedLong(StringBuilder sb, long v, int digits_column_width)
/*     */   {
/* 312 */     int digit_width = numDigits(v);
/* 313 */     appendSpaces(sb, digits_column_width - digit_width);
/* 314 */     sb.append(v);
/*     */   }
/*     */ 
/*     */   private static int numDigits(long n)
/*     */   {
/* 324 */     int i = 0;
/*     */     do {
/* 326 */       i++;
/* 327 */       n /= 10L;
/* 328 */     }while (n > 0L);
/* 329 */     return i;
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static void appendSpaces(StringBuilder sb, int numSpaces)
/*     */   {
/* 342 */     while (numSpaces > 0) {
/* 343 */       int numToAppend = Math.min(numSpaces, MANY_SPACES.length);
/* 344 */       sb.append(MANY_SPACES, 0, numToAppend);
/* 345 */       numSpaces -= numToAppend;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int addTracingStatistic(TracingStatistic tracingStatistic)
/*     */   {
/* 359 */     if (tracingStatistic.enable())
/*     */     {
/* 361 */       extraTracingStatistics.add(tracingStatistic);
/*     */ 
/* 363 */       return extraTracingStatistics.lastIndexOf(tracingStatistic);
/*     */     }
/* 365 */     return -1;
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static void clearTracingStatisticsTestingOnly()
/*     */   {
/* 377 */     extraTracingStatistics.clear();
/*     */   }
/*     */ 
/*     */   public long stop(int silence_threshold)
/*     */   {
/* 390 */     X.assertTrue(Thread.currentThread() == this.startThread);
/*     */ 
/* 392 */     ThreadTrace trace = getThreadTrace();
/*     */ 
/* 394 */     if (!trace.isInitialized()) {
/* 395 */       return 0L;
/*     */     }
/*     */ 
/* 398 */     this.stopTimeMs = clock.currentTimeMillis();
/* 399 */     if (this.extraTracingValues != null)
/*     */     {
/* 402 */       for (int i = 0; i < this.extraTracingValues.length; i++) {
/* 403 */         long value = ((TracingStatistic)extraTracingStatistics.get(i)).stop(this.startThread);
/* 404 */         this.extraTracingValues[i] = (value - this.extraTracingValues[i]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 409 */     if (!trace.isInitialized()) {
/* 410 */       return 0L;
/*     */     }
/*     */ 
/* 413 */     trace.endEvent(this, silence_threshold);
/* 414 */     return this.stopTimeMs - this.startTimeMs;
/*     */   }
/*     */ 
/*     */   public long stop()
/*     */   {
/* 422 */     return stop(-1);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 426 */     return this.type == null ? this.comment : appendTo(new StringBuilder()).toString();
/*     */   }
/*     */ 
/*     */   private StringBuilder appendTo(StringBuilder sb)
/*     */   {
/* 436 */     return this.type == null ? sb.append(this.comment) : sb.append("[").append(this.type).append("] ").append(this.comment);
/*     */   }
/*     */ 
/*     */   public static void setDefaultSilenceThreshold(int threshold)
/*     */   {
/* 442 */     getThreadTrace().defaultSilenceThreshold = threshold;
/*     */   }
/*     */ 
/*     */   public static void initCurrentThreadTrace()
/*     */   {
/* 451 */     ThreadTrace events = getThreadTrace();
/* 452 */     if (!events.isEmpty()) {
/* 453 */       logger.log(Level.WARNING, "Non-empty timer log:\n" + events, new Throwable());
/*     */ 
/* 456 */       clearThreadTrace();
/*     */ 
/* 459 */       events = getThreadTrace();
/*     */     }
/*     */ 
/* 463 */     events.init();
/*     */   }
/*     */ 
/*     */   public static void initCurrentThreadTrace(int default_silence_threshold) {
/* 467 */     initCurrentThreadTrace();
/* 468 */     setDefaultSilenceThreshold(default_silence_threshold);
/*     */   }
/*     */ 
/*     */   public static String getCurrentThreadTraceReport()
/*     */   {
/* 477 */     return getThreadTrace().toString();
/*     */   }
/*     */ 
/*     */   public static void logCurrentThreadTrace()
/*     */   {
/* 484 */     ThreadTrace trace = getThreadTrace();
/*     */ 
/* 491 */     if (!trace.isInitialized()) {
/* 492 */       logger.log(Level.WARNING, "Tracer log requested for this thread but was not initialized using Tracer.initCurrentThreadTrace().", new Throwable());
/*     */ 
/* 496 */       return;
/*     */     }
/*     */ 
/* 499 */     if (!trace.isEmpty())
/* 500 */       logger.log(Level.INFO, "timers:\n{0}", getCurrentThreadTraceReport());
/*     */   }
/*     */ 
/*     */   public static void clearCurrentThreadTrace()
/*     */   {
/* 508 */     clearThreadTrace();
/*     */   }
/*     */ 
/*     */   public static void logAndClearCurrentThreadTrace()
/*     */   {
/* 515 */     logCurrentThreadTrace();
/* 516 */     clearThreadTrace();
/*     */   }
/*     */ 
/*     */   public static void setPrettyPrint(boolean enabled)
/*     */   {
/* 525 */     defaultPrettyPrint = enabled;
/*     */   }
/*     */ 
/*     */   public static synchronized void enableTypeMaps()
/*     */   {
/* 582 */     if (typeToCountMap == null) {
/* 583 */       typeToCountMap = new AtomicTracerStatMap();
/* 584 */       typeToSilentMap = new AtomicTracerStatMap();
/* 585 */       typeToTimeMap = new AtomicTracerStatMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Map<String, Long> getTypeToCountMap()
/*     */   {
/* 595 */     return typeToCountMap != null ? typeToCountMap.getMap() : null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Long> getTypeToSilentMap()
/*     */   {
/* 604 */     return typeToSilentMap != null ? typeToSilentMap.getMap() : null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Long> getTypeToTimeMap()
/*     */   {
/* 613 */     return typeToTimeMap != null ? typeToTimeMap.getMap() : null;
/*     */   }
/*     */ 
/*     */   public static Stat getStatsForType(String type)
/*     */   {
/* 618 */     Stat stat = (Stat)getThreadTrace().stats.get(type);
/* 619 */     return stat != null ? stat : ZERO_STAT;
/*     */   }
/*     */ 
/*     */   private static String formatTime(long time)
/*     */   {
/* 626 */     int sec = (int)(time / 1000L % 60L);
/* 627 */     int ms = (int)(time % 1000L);
/* 628 */     return String.format("%02d.%03d", new Object[] { Integer.valueOf(sec), Integer.valueOf(ms) });
/*     */   }
/*     */ 
/*     */   static ThreadTrace getThreadTrace()
/*     */   {
/* 946 */     ThreadTrace t = (ThreadTrace)traces.get();
/* 947 */     if (t == null) {
/* 948 */       t = new ThreadTrace();
/* 949 */       t.prettyPrint = defaultPrettyPrint;
/* 950 */       traces.set(t);
/*     */     }
/* 952 */     return t;
/*     */   }
/*     */ 
/*     */   static void clearThreadTrace()
/*     */   {
/* 957 */     traces.set(null);
/*     */   }
/*     */ 
/*     */   static final class ThreadTrace
/*     */   {
/*     */     int defaultSilenceThreshold;
/* 700 */     final ArrayList<Tracer.Event> events = new ArrayList();
/*     */ 
/* 703 */     final HashSet<Tracer> outstandingEvents = new HashSet();
/*     */ 
/* 706 */     final Map<String, Tracer.Stat> stats = new HashMap();
/*     */ 
/* 712 */     boolean isOutstandingEventsTruncated = false;
/*     */ 
/* 718 */     boolean isEventsTruncated = false;
/*     */ 
/* 724 */     boolean isInitialized = false;
/*     */ 
/* 729 */     boolean prettyPrint = false;
/*     */ 
/*     */     void init()
/*     */     {
/* 733 */       this.isInitialized = true;
/*     */     }
/*     */ 
/*     */     boolean isInitialized()
/*     */     {
/* 738 */       return this.isInitialized;
/*     */     }
/*     */ 
/*     */     void startEvent(Tracer t)
/*     */     {
/* 746 */       this.events.add(new Tracer.Event(true, t));
/* 747 */       boolean notAlreadyOutstanding = this.outstandingEvents.add(t);
/* 748 */       X.assertTrue(notAlreadyOutstanding);
/*     */     }
/*     */ 
/*     */     void endEvent(Tracer t, int silenceThreshold)
/*     */     {
/* 755 */       boolean wasOutstanding = this.outstandingEvents.remove(t);
/* 756 */       if (!wasOutstanding) {
/* 757 */         if (this.isOutstandingEventsTruncated)
/*     */         {
/* 761 */           Tracer.logger.log(Level.WARNING, "event not found, probably because the event stack overflowed and was truncated", new Throwable());
/*     */         }
/*     */         else
/*     */         {
/* 768 */           X.assertTrue(false);
/*     */         }
/*     */       }
/*     */ 
/* 772 */       long elapsed = t.stopTimeMs - t.startTimeMs;
/*     */ 
/* 774 */       if (silenceThreshold == -1) {
/* 775 */         silenceThreshold = this.defaultSilenceThreshold;
/*     */       }
/*     */ 
/* 778 */       if (elapsed < silenceThreshold)
/*     */       {
/* 780 */         boolean removed = false;
/* 781 */         for (int i = 0; i < this.events.size(); i++) {
/* 782 */           Tracer.Event e = (Tracer.Event)this.events.get(i);
/* 783 */           if (e.tracer == t) {
/* 784 */             X.assertTrue(e.isStart);
/* 785 */             this.events.remove(i);
/* 786 */             removed = true;
/* 787 */             break;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 793 */         X.assertTrue((removed) || (this.isEventsTruncated));
/*     */       } else {
/* 795 */         this.events.add(new Tracer.Event(false, t));
/*     */       }
/*     */ 
/* 798 */       if (t.type != null) {
/* 799 */         Tracer.Stat stat = (Tracer.Stat)this.stats.get(t.type);
/* 800 */         if (stat == null) {
/* 801 */           stat = new Tracer.Stat();
/* 802 */           if (!Tracer.extraTracingStatistics.isEmpty()) {
/* 803 */             Tracer.Stat.access$802(stat, new int[Tracer.extraTracingStatistics.size()]);
/*     */           }
/* 805 */           this.stats.put(t.type, stat);
/*     */         }
/*     */ 
/* 808 */         Tracer.Stat.access$908(stat);
/* 809 */         if (Tracer.typeToCountMap != null) {
/* 810 */           Tracer.typeToCountMap.incrementBy(t.type, 1L);
/*     */         }
/*     */ 
/* 813 */         Tracer.Stat.access$1114(stat, elapsed);
/* 814 */         if (Tracer.typeToTimeMap != null) {
/* 815 */           Tracer.typeToTimeMap.incrementBy(t.type, elapsed);
/*     */         }
/*     */ 
/* 818 */         if ((Tracer.Stat.access$800(stat) != null) && (t.extraTracingValues != null)) {
/* 819 */           int overlapLength = Math.min(Tracer.Stat.access$800(stat).length, t.extraTracingValues.length);
/* 820 */           for (int i = 0; i < overlapLength; i++)
/*     */           {
/*     */             int tmp364_362 = i;
/*     */             int[] tmp364_359 = Tracer.Stat.access$800(stat); tmp364_359[tmp364_362] = (int)(tmp364_359[tmp364_362] + Tracer.access$400(t)[i]);
/* 822 */             AtomicTracerStatMap map = ((TracingStatistic)Tracer.extraTracingStatistics.get(i)).getTracingStat();
/* 823 */             if (map != null) {
/* 824 */               map.incrementBy(t.type, t.extraTracingValues[i]);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 829 */         if (elapsed < silenceThreshold) {
/* 830 */           Tracer.Stat.access$1308(stat);
/* 831 */           if (Tracer.typeToSilentMap != null)
/* 832 */             Tracer.typeToSilentMap.incrementBy(t.type, 1L);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     boolean isEmpty()
/*     */     {
/* 839 */       return (this.events.size() == 0) && (this.outstandingEvents.size() == 0);
/*     */     }
/*     */ 
/*     */     void truncateOutstandingEvents() {
/* 843 */       this.isOutstandingEventsTruncated = true;
/* 844 */       this.outstandingEvents.clear();
/*     */     }
/*     */ 
/*     */     void truncateEvents() {
/* 848 */       this.isEventsTruncated = true;
/* 849 */       this.events.clear();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 855 */       int numDigits = getMaxDigits();
/* 856 */       StringBuilder sb = new StringBuilder();
/* 857 */       long etime = -1L;
/* 858 */       int indentDepth = 0;
/* 859 */       for (Tracer.Event e : this.events) {
/* 860 */         if ((this.prettyPrint) && (!e.isStart) && (indentDepth > 0)) {
/* 861 */           indentDepth--;
/*     */         }
/* 863 */         sb.append(" ");
/* 864 */         if (this.prettyPrint)
/* 865 */           e.appendTo(sb, etime, indentDepth, numDigits);
/*     */         else {
/* 867 */           e.appendTo(sb, etime, 0, 4);
/*     */         }
/* 869 */         etime = e.eventTime();
/* 870 */         sb.append('\n');
/* 871 */         if ((this.prettyPrint) && (e.isStart))
/* 872 */           indentDepth++;
/*     */       }
/*     */       long now;
/* 876 */       if (this.outstandingEvents.size() != 0) {
/* 877 */         now = Tracer.clock.currentTimeMillis();
/*     */ 
/* 879 */         sb.append(" Unstopped timers:\n");
/* 880 */         for (Tracer t : this.outstandingEvents) {
/* 881 */           sb.append("  ").append(t).append(" (").append(now - t.startTimeMs).append(" ms, started at ").append(Tracer.access$300(t.startTimeMs)).append(")\n");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 891 */       for (String key : this.stats.keySet()) {
/* 892 */         Tracer.Stat stat = (Tracer.Stat)this.stats.get(key);
/* 893 */         if (Tracer.Stat.access$900(stat) > 1) {
/* 894 */           sb.append(" TOTAL ").append(key).append(" ").append(Tracer.Stat.access$900(stat)).append(" (").append(Tracer.Stat.access$1100(stat)).append(" ms");
/*     */ 
/* 901 */           if (Tracer.Stat.access$800(stat) != null) {
/* 902 */             for (int i = 0; i < Tracer.Stat.access$800(stat).length; i++) {
/* 903 */               sb.append("; ");
/* 904 */               sb.append(Tracer.Stat.access$800(stat)[i]).append(' ').append(((TracingStatistic)Tracer.extraTracingStatistics.get(i)).getUnits());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 909 */           sb.append(")\n");
/*     */         }
/*     */       }
/* 912 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     private int getMaxDigits()
/*     */     {
/* 921 */       long etime = -1L;
/* 922 */       long max_time = 0L;
/* 923 */       for (Tracer.Event e : this.events) {
/* 924 */         if (etime != -1L) {
/* 925 */           long time = e.eventTime() - etime;
/* 926 */           max_time = Math.max(max_time, time);
/*     */         }
/* 928 */         if (!e.isStart) {
/* 929 */           long time = e.tracer.stopTimeMs - e.tracer.startTimeMs;
/* 930 */           max_time = Math.max(max_time, time);
/*     */         }
/* 932 */         etime = e.eventTime();
/*     */       }
/*     */ 
/* 935 */       return Math.max(3, Tracer.access$1500(max_time));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class Event
/*     */   {
/*     */     boolean isStart;
/*     */     Tracer tracer;
/*     */     private static final String INDENT_STR = "|  ";
/*     */ 
/*     */     Event(boolean start, Tracer t)
/*     */     {
/* 637 */       this.isStart = start;
/* 638 */       this.tracer = t;
/*     */     }
/*     */ 
/*     */     long eventTime() {
/* 642 */       return this.isStart ? this.tracer.startTimeMs : this.tracer.stopTimeMs;
/*     */     }
/*     */ 
/*     */     void appendTo(StringBuilder sb, long prevEventTime, int indentDepth, int digitsColWidth)
/*     */     {
/* 660 */       if (prevEventTime == -1L)
/* 661 */         Tracer.appendSpaces(sb, digitsColWidth);
/*     */       else {
/* 663 */         Tracer.access$200(sb, eventTime() - prevEventTime, digitsColWidth);
/*     */       }
/*     */ 
/* 666 */       sb.append(' ');
/* 667 */       sb.append(Tracer.access$300(eventTime()));
/* 668 */       if (this.isStart) {
/* 669 */         sb.append(" Start ");
/* 670 */         Tracer.appendSpaces(sb, digitsColWidth);
/* 671 */         sb.append("   ");
/*     */       } else {
/* 673 */         sb.append(" Done ");
/* 674 */         long delta = this.tracer.stopTimeMs - this.tracer.startTimeMs;
/* 675 */         Tracer.access$200(sb, delta, digitsColWidth);
/* 676 */         sb.append(" ms ");
/* 677 */         if (this.tracer.extraTracingValues != null) {
/* 678 */           for (int i = 0; i < this.tracer.extraTracingValues.length; i++) {
/* 679 */             delta = this.tracer.extraTracingValues[i];
/* 680 */             Tracer.access$200(sb, delta, 4);
/* 681 */             sb.append(((TracingStatistic)Tracer.extraTracingStatistics.get(i)).getUnits());
/* 682 */             sb.append(";  ");
/*     */           }
/*     */         }
/*     */       }
/* 686 */       for (int i = 0; i < indentDepth; i++) {
/* 687 */         sb.append("|  ");
/*     */       }
/* 689 */       this.tracer.appendTo(sb);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Stat
/*     */   {
/*     */     private int count;
/*     */     private int silent;
/*     */     private int clockTime;
/*     */     private int[] extraInfo;
/*     */ 
/*     */     public int getCount()
/*     */     {
/* 539 */       return this.count;
/*     */     }
/*     */ 
/*     */     public int getSilentCount()
/*     */     {
/* 545 */       return this.silent;
/*     */     }
/*     */ 
/*     */     public int getTotalTime()
/*     */     {
/* 551 */       return this.clockTime;
/*     */     }
/*     */     @VisibleForTesting
/*     */     public int getExtraInfo(int index) {
/* 556 */       return index >= this.extraInfo.length ? 0 : this.extraInfo[index];
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface InternalClock
/*     */   {
/*     */     public abstract long currentTimeMillis();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Tracer
 * JD-Core Version:    0.6.0
 */