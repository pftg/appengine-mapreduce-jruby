/*    */ package com.google.appengine.api.oauth;
/*    */ 
/*    */ public class OAuthServiceFailureException extends RuntimeException
/*    */ {
/*    */   public OAuthServiceFailureException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.oauth.OAuthServiceFailureException
 * JD-Core Version:    0.6.0
 */