/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public final class Entity
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   static final long serialVersionUID = -836647825120453511L;
/*     */   public static final String KEY_RESERVED_PROPERTY = "__key__";
/*     */   private final Key key;
/*     */   private final Map<String, Object> propertyMap;
/*     */   private transient OnestoreEntity.EntityProto entityProto;
/*     */ 
/*     */   public Entity(String kind)
/*     */   {
/*  96 */     this(kind, (Key)null);
/*     */   }
/*     */ 
/*     */   public Entity(String kind, Key parent)
/*     */   {
/* 115 */     this(new Key(kind, parent));
/*     */   }
/*     */ 
/*     */   public Entity(String kind, String keyName)
/*     */   {
/* 126 */     this(KeyFactory.createKey(kind, keyName));
/*     */   }
/*     */ 
/*     */   public Entity(String kind, String keyName, Key parent)
/*     */   {
/* 140 */     this(parent == null ? KeyFactory.createKey(kind, keyName) : parent.getChild(kind, keyName));
/*     */   }
/*     */ 
/*     */   public Entity(Key key)
/*     */   {
/* 152 */     this.key = key;
/* 153 */     this.propertyMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 162 */     if ((object instanceof Entity)) {
/* 163 */       Entity otherEntity = (Entity)object;
/* 164 */       return this.key.equals(otherEntity.key);
/*     */     }
/* 166 */     return false;
/*     */   }
/*     */ 
/*     */   public Key getKey()
/*     */   {
/* 178 */     return this.key;
/*     */   }
/*     */ 
/*     */   public String getKind()
/*     */   {
/* 187 */     return this.key.getKind();
/*     */   }
/*     */ 
/*     */   public Key getParent()
/*     */   {
/* 196 */     return this.key.getParent();
/*     */   }
/*     */ 
/*     */   public Object getProperty(String propertyName)
/*     */   {
/* 206 */     return unwrapValue(this.propertyMap.get(propertyName));
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getProperties()
/*     */   {
/* 215 */     Map properties = new HashMap(this.propertyMap.size());
/*     */ 
/* 217 */     for (Map.Entry entry : this.propertyMap.entrySet()) {
/* 218 */       properties.put(entry.getKey(), unwrapValue(entry.getValue()));
/*     */     }
/*     */ 
/* 221 */     return Collections.unmodifiableMap(properties);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 226 */     return this.key.hashCode();
/*     */   }
/*     */ 
/*     */   public boolean hasProperty(String propertyName)
/*     */   {
/* 237 */     return this.propertyMap.containsKey(propertyName);
/*     */   }
/*     */ 
/*     */   public void removeProperty(String propertyName)
/*     */   {
/* 247 */     this.propertyMap.remove(propertyName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String propertyName, Object value)
/*     */   {
/* 280 */     DataTypeUtils.checkSupportedValue(propertyName, value);
/* 281 */     this.propertyMap.put(propertyName, value);
/*     */   }
/*     */ 
/*     */   public void setUnindexedProperty(String propertyName, Object value)
/*     */   {
/* 300 */     DataTypeUtils.checkSupportedValue(propertyName, value);
/* 301 */     this.propertyMap.put(propertyName, new UnindexedValue(value));
/*     */   }
/*     */ 
/*     */   public boolean isUnindexedProperty(String propertyName)
/*     */   {
/* 310 */     Object value = this.propertyMap.get(propertyName);
/* 311 */     return ((value instanceof UnindexedValue)) || ((value instanceof Text)) || ((value instanceof Blob));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 317 */     StringBuffer buffer = new StringBuffer();
/* 318 */     buffer.append("<Entity [" + this.key + "]:\n");
/* 319 */     for (Map.Entry entry : this.propertyMap.entrySet()) {
/* 320 */       buffer.append("\t" + (String)entry.getKey() + " = " + entry.getValue() + "\n");
/*     */     }
/* 322 */     buffer.append(">\n");
/* 323 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public String getAppId()
/*     */   {
/* 332 */     return this.key.getAppId();
/*     */   }
/*     */ 
/*     */   AppIdNamespace getAppIdNamespace()
/*     */   {
/* 341 */     return this.key.getAppIdNamespace();
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 350 */     return this.key.getNamespace();
/*     */   }
/*     */ 
/*     */   public Entity clone()
/*     */   {
/* 363 */     Entity entity = new Entity(this.key);
/* 364 */     entity.setPropertiesFrom(this);
/* 365 */     return entity;
/*     */   }
/*     */ 
/*     */   public void setPropertiesFrom(Entity src)
/*     */   {
/* 376 */     for (Map.Entry entry : src.propertyMap.entrySet()) {
/* 377 */       String name = (String)entry.getKey();
/* 378 */       Object entryValue = entry.getValue();
/*     */ 
/* 381 */       boolean indexed = entryValue instanceof UnindexedValue;
/* 382 */       Object valueToAdd = unwrapValue(entryValue);
/*     */       Collection destColl;
/*     */       Iterator i$;
/* 385 */       if ((valueToAdd instanceof Collection))
/*     */       {
/* 388 */         Collection srcColl = (Collection)valueToAdd;
/* 389 */         destColl = new ArrayList(srcColl.size());
/* 390 */         valueToAdd = destColl;
/* 391 */         for (i$ = srcColl.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 392 */           destColl.add(cloneIfMutable(element)); }
/*     */       }
/*     */       else {
/* 395 */         valueToAdd = cloneIfMutable(valueToAdd);
/*     */       }
/*     */ 
/* 399 */       if (indexed) {
/* 400 */         valueToAdd = new UnindexedValue(valueToAdd);
/*     */       }
/*     */ 
/* 404 */       this.propertyMap.put(name, valueToAdd);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object cloneIfMutable(Object obj)
/*     */   {
/* 414 */     if ((obj instanceof Date)) {
/* 415 */       return ((Date)obj).clone();
/*     */     }
/* 417 */     return obj;
/*     */   }
/*     */ 
/*     */   static Object unwrapValue(Object obj)
/*     */   {
/* 427 */     if ((obj instanceof UnindexedValue)) {
/* 428 */       return ((UnindexedValue)obj).getValue();
/*     */     }
/* 430 */     return obj;
/*     */   }
/*     */ 
/*     */   Map<String, Object> getPropertyMap()
/*     */   {
/* 435 */     return this.propertyMap;
/*     */   }
/*     */ 
/*     */   void setEntityProto(OnestoreEntity.EntityProto entityProto) {
/* 439 */     this.entityProto = entityProto;
/*     */   }
/*     */ 
/*     */   OnestoreEntity.EntityProto getEntityProto() {
/* 443 */     return this.entityProto;
/*     */   }
/*     */ 
/*     */   static final class UnindexedValue
/*     */     implements Serializable
/*     */   {
/*     */     private final Object value;
/*     */ 
/*     */     UnindexedValue(Object value)
/*     */     {
/*  56 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public Object getValue() {
/*  60 */       return this.value;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object that)
/*     */     {
/*  65 */       if ((that instanceof UnindexedValue)) {
/*  66 */         UnindexedValue uv = (UnindexedValue)that;
/*  67 */         return this.value == null ? false : uv.value == null ? true : this.value.equals(uv.value);
/*     */       }
/*  69 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/*  74 */       return this.value == null ? 0 : this.value.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  79 */       return this.value + " (unindexed)";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Entity
 * JD-Core Version:    0.6.0
 */