/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ 
/*    */ @GoogleInternal
/*    */ @GwtCompatible
/*    */ public class ParseFailedException extends Exception
/*    */ {
/*    */   private final String offendingInput;
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public ParseFailedException(CharSequence offendingInput)
/*    */   {
/* 26 */     this.offendingInput = offendingInput.toString();
/*    */   }
/*    */ 
/*    */   public ParseFailedException(CharSequence offendingInput, String message)
/*    */   {
/* 38 */     super(message);
/* 39 */     this.offendingInput = offendingInput.toString();
/*    */   }
/*    */ 
/*    */   public ParseFailedException(CharSequence offendingInput, String message, Throwable cause)
/*    */   {
/* 52 */     super(message, cause);
/* 53 */     this.offendingInput = offendingInput.toString();
/*    */   }
/*    */ 
/*    */   public ParseFailedException(CharSequence offendingInput, Throwable cause)
/*    */   {
/* 62 */     super(cause);
/* 63 */     this.offendingInput = offendingInput.toString();
/*    */   }
/*    */ 
/*    */   public String getOffendingInput()
/*    */   {
/* 70 */     return this.offendingInput;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 74 */     return this.offendingInput != null ? super.toString() + " (input: " + this.offendingInput + ")" : super.toString();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.ParseFailedException
 * JD-Core Version:    0.6.0
 */