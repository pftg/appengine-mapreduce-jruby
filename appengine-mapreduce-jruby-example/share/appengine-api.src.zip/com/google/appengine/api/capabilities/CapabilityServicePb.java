/*      */ package com.google.appengine.api.capabilities;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.protobuf.BlockingRpcChannel;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.BlockingService;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.Descriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumValueDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.MethodDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.ServiceDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.Builder;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Internal.EnumLiteMap;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcCallback;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcChannel;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcController;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcUtil;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Service;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ServiceException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet.Builder;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class CapabilityServicePb
/*      */ {
/*      */   private static Descriptors.Descriptor internal_static_apphosting_IsEnabledRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_IsEnabledRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_IsEnabledResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_IsEnabledResponse_fieldAccessorTable;
/*      */   private static Descriptors.FileDescriptor descriptor;
/*      */ 
/*      */   public static void registerAllExtensions(ExtensionRegistry registry)
/*      */   {
/*      */   }
/*      */ 
/*      */   public static Descriptors.FileDescriptor getDescriptor()
/*      */   {
/* 1285 */     return descriptor;
/*      */   }
/*      */   public static void internalForceInit() {
/*      */   }
/*      */   static {
/* 1290 */     String[] descriptorData = { "\n4apphosting/api/capabilities/capability_service.proto\022\napphosting\032\"apphosting/base/capabilities.proto\"E\n\020IsEnabledRequest\022\017\n\007package\030\001 \002(\t\022\022\n\ncapability\030\002 \003(\t\022\f\n\004call\030\003 \003(\t\"\002\n\021IsEnabledResponse\022C\n\016summary_status\030\001 \002(\0162+.apphosting.IsEnabledResponse.SummaryStatus\022\034\n\024time_until_scheduled\030\002 \001(\003\022,\n\006config\030\003 \003(\0132\034.apphosting.CapabilityConfig\"`\n\rSummaryStatus\022\013\n\007ENABLED\020\001\022\024\n\020SCHEDULED_FUTURE\020\002\022\021\n\rSCHE", "DULED_NOW\020\003\022\f\n\bDISABLED\020\004\022\013\n\007UNKNOWN\020\0052]\n\021CapabilityService\022H\n\tIsEnabled\022\034.apphosting.IsEnabledRequest\032\035.apphosting.IsEnabledResponseBB\n%com.google.appengine.api.capabilities\020\001 \001(\002B\023CapabilityServicePb" };
/*      */ 
/* 1308 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*      */     {
/*      */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*      */       {
/* 1312 */         CapabilityServicePb.access$2102(root);
/* 1313 */         CapabilityServicePb.access$002((Descriptors.Descriptor)CapabilityServicePb.getDescriptor().getMessageTypes().get(0));
/*      */ 
/* 1315 */         CapabilityServicePb.access$102(new GeneratedMessage.FieldAccessorTable(CapabilityServicePb.internal_static_apphosting_IsEnabledRequest_descriptor, new String[] { "Package", "Capability", "Call" }, CapabilityServicePb.IsEnabledRequest.class, CapabilityServicePb.IsEnabledRequest.Builder.class));
/*      */ 
/* 1321 */         CapabilityServicePb.access$902((Descriptors.Descriptor)CapabilityServicePb.getDescriptor().getMessageTypes().get(1));
/*      */ 
/* 1323 */         CapabilityServicePb.access$1002(new GeneratedMessage.FieldAccessorTable(CapabilityServicePb.internal_static_apphosting_IsEnabledResponse_descriptor, new String[] { "SummaryStatus", "TimeUntilScheduled", "Config" }, CapabilityServicePb.IsEnabledResponse.class, CapabilityServicePb.IsEnabledResponse.Builder.class));
/*      */ 
/* 1329 */         return null;
/*      */       }
/*      */     };
/* 1332 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[] { CapabilitiesPb.getDescriptor() }, assigner);
/*      */   }
/*      */ 
/*      */   public static abstract class CapabilityService
/*      */     implements Service
/*      */   {
/*      */     public static Service newReflectiveService(Interface impl)
/*      */     {
/* 1065 */       return new CapabilityService(impl)
/*      */       {
/*      */         public void isEnabled(RpcController controller, CapabilityServicePb.IsEnabledRequest request, RpcCallback<CapabilityServicePb.IsEnabledResponse> done)
/*      */         {
/* 1071 */           this.val$impl.isEnabled(controller, request, done);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static BlockingService newReflectiveBlockingService(BlockingInterface impl)
/*      */     {
/* 1079 */       return new BlockingService(impl)
/*      */       {
/*      */         public final Descriptors.ServiceDescriptor getDescriptorForType() {
/* 1082 */           return CapabilityServicePb.CapabilityService.getDescriptor();
/*      */         }
/*      */ 
/*      */         public final Message callBlockingMethod(Descriptors.MethodDescriptor method, RpcController controller, Message request)
/*      */           throws ServiceException
/*      */         {
/* 1090 */           if (method.getService() != CapabilityServicePb.CapabilityService.getDescriptor()) {
/* 1091 */             throw new IllegalArgumentException("Service.callBlockingMethod() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 1095 */           switch (method.getIndex()) {
/*      */           case 0:
/* 1097 */             return this.val$impl.isEnabled(controller, (CapabilityServicePb.IsEnabledRequest)request);
/*      */           }
/* 1099 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */ 
/*      */         public final Message getRequestPrototype(Descriptors.MethodDescriptor method)
/*      */         {
/* 1106 */           if (method.getService() != CapabilityServicePb.CapabilityService.getDescriptor()) {
/* 1107 */             throw new IllegalArgumentException("Service.getRequestPrototype() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 1111 */           switch (method.getIndex()) {
/*      */           case 0:
/* 1113 */             return CapabilityServicePb.IsEnabledRequest.getDefaultInstance();
/*      */           }
/* 1115 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */ 
/*      */         public final Message getResponsePrototype(Descriptors.MethodDescriptor method)
/*      */         {
/* 1122 */           if (method.getService() != CapabilityServicePb.CapabilityService.getDescriptor()) {
/* 1123 */             throw new IllegalArgumentException("Service.getResponsePrototype() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 1127 */           switch (method.getIndex()) {
/*      */           case 0:
/* 1129 */             return CapabilityServicePb.IsEnabledResponse.getDefaultInstance();
/*      */           }
/* 1131 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public abstract void isEnabled(RpcController paramRpcController, CapabilityServicePb.IsEnabledRequest paramIsEnabledRequest, RpcCallback<CapabilityServicePb.IsEnabledResponse> paramRpcCallback);
/*      */ 
/*      */     public static final Descriptors.ServiceDescriptor getDescriptor()
/*      */     {
/* 1146 */       return (Descriptors.ServiceDescriptor)CapabilityServicePb.getDescriptor().getServices().get(0);
/*      */     }
/*      */ 
/*      */     public final Descriptors.ServiceDescriptor getDescriptorForType() {
/* 1150 */       return getDescriptor();
/*      */     }
/*      */ 
/*      */     public final void callMethod(Descriptors.MethodDescriptor method, RpcController controller, Message request, RpcCallback<Message> done)
/*      */     {
/* 1159 */       if (method.getService() != getDescriptor()) {
/* 1160 */         throw new IllegalArgumentException("Service.callMethod() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 1164 */       switch (method.getIndex()) {
/*      */       case 0:
/* 1166 */         isEnabled(controller, (CapabilityServicePb.IsEnabledRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 1169 */         return;
/*      */       }
/* 1171 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public final Message getRequestPrototype(Descriptors.MethodDescriptor method)
/*      */     {
/* 1178 */       if (method.getService() != getDescriptor()) {
/* 1179 */         throw new IllegalArgumentException("Service.getRequestPrototype() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 1183 */       switch (method.getIndex()) {
/*      */       case 0:
/* 1185 */         return CapabilityServicePb.IsEnabledRequest.getDefaultInstance();
/*      */       }
/* 1187 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public final Message getResponsePrototype(Descriptors.MethodDescriptor method)
/*      */     {
/* 1194 */       if (method.getService() != getDescriptor()) {
/* 1195 */         throw new IllegalArgumentException("Service.getResponsePrototype() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 1199 */       switch (method.getIndex()) {
/*      */       case 0:
/* 1201 */         return CapabilityServicePb.IsEnabledResponse.getDefaultInstance();
/*      */       }
/* 1203 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcChannel channel)
/*      */     {
/* 1209 */       return new Stub(channel, null);
/*      */     }
/*      */ 
/*      */     public static BlockingInterface newBlockingStub(BlockingRpcChannel channel)
/*      */     {
/* 1241 */       return new BlockingStub(channel, null);
/*      */     }
/*      */ 
/*      */     private static final class BlockingStub
/*      */       implements CapabilityServicePb.CapabilityService.BlockingInterface
/*      */     {
/*      */       private final BlockingRpcChannel channel;
/*      */ 
/*      */       private BlockingStub(BlockingRpcChannel channel)
/*      */       {
/* 1253 */         this.channel = channel;
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledResponse isEnabled(RpcController controller, CapabilityServicePb.IsEnabledRequest request)
/*      */         throws ServiceException
/*      */       {
/* 1262 */         return (CapabilityServicePb.IsEnabledResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)CapabilityServicePb.CapabilityService.getDescriptor().getMethods().get(0), controller, request, CapabilityServicePb.IsEnabledResponse.getDefaultInstance());
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface
/*      */     {
/*      */       public abstract CapabilityServicePb.IsEnabledResponse isEnabled(RpcController paramRpcController, CapabilityServicePb.IsEnabledRequest paramIsEnabledRequest)
/*      */         throws ServiceException;
/*      */     }
/*      */ 
/*      */     public static final class Stub extends CapabilityServicePb.CapabilityService
/*      */       implements CapabilityServicePb.CapabilityService.Interface
/*      */     {
/*      */       private final RpcChannel channel;
/*      */ 
/*      */       private Stub(RpcChannel channel)
/*      */       {
/* 1214 */         this.channel = channel;
/*      */       }
/*      */ 
/*      */       public RpcChannel getChannel()
/*      */       {
/* 1220 */         return this.channel;
/*      */       }
/*      */ 
/*      */       public void isEnabled(RpcController controller, CapabilityServicePb.IsEnabledRequest request, RpcCallback<CapabilityServicePb.IsEnabledResponse> done)
/*      */       {
/* 1227 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(0), controller, request, CapabilityServicePb.IsEnabledResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, CapabilityServicePb.IsEnabledResponse.class, CapabilityServicePb.IsEnabledResponse.getDefaultInstance()));
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface
/*      */     {
/*      */       public abstract void isEnabled(RpcController paramRpcController, CapabilityServicePb.IsEnabledRequest paramIsEnabledRequest, RpcCallback<CapabilityServicePb.IsEnabledResponse> paramRpcCallback);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class IsEnabledResponse extends GeneratedMessage
/*      */   {
/* 1043 */     private static final IsEnabledResponse defaultInstance = new IsEnabledResponse(true);
/*      */     public static final int SUMMARY_STATUS_FIELD_NUMBER = 1;
/*      */     private boolean hasSummaryStatus;
/*      */     private SummaryStatus summaryStatus_;
/*      */     public static final int TIME_UNTIL_SCHEDULED_FIELD_NUMBER = 2;
/*      */     private boolean hasTimeUntilScheduled;
/*      */     private long timeUntilScheduled_;
/*      */     public static final int CONFIG_FIELD_NUMBER = 3;
/*      */     private List<CapabilitiesPb.CapabilityConfig> config_;
/*  674 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private IsEnabledResponse(Builder builder)
/*      */     {
/*  509 */       super();
/*      */     }
/*      */     private IsEnabledResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse getDefaultInstance() {
/*  515 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public IsEnabledResponse getDefaultInstanceForType() {
/*  519 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  524 */       return CapabilityServicePb.internal_static_apphosting_IsEnabledResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  529 */       return CapabilityServicePb.internal_static_apphosting_IsEnabledResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasSummaryStatus()
/*      */     {
/*  616 */       return this.hasSummaryStatus;
/*      */     }
/*      */     public SummaryStatus getSummaryStatus() {
/*  619 */       return this.summaryStatus_;
/*      */     }
/*      */ 
/*      */     public boolean hasTimeUntilScheduled()
/*      */     {
/*  627 */       return this.hasTimeUntilScheduled;
/*      */     }
/*      */     public long getTimeUntilScheduled() {
/*  630 */       return this.timeUntilScheduled_;
/*      */     }
/*      */ 
/*      */     public List<CapabilitiesPb.CapabilityConfig> getConfigList()
/*      */     {
/*  637 */       return this.config_;
/*      */     }
/*      */     public int getConfigCount() {
/*  640 */       return this.config_.size();
/*      */     }
/*      */     public CapabilitiesPb.CapabilityConfig getConfig(int index) {
/*  643 */       return (CapabilitiesPb.CapabilityConfig)this.config_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*  647 */       this.summaryStatus_ = SummaryStatus.ENABLED;
/*  648 */       this.timeUntilScheduled_ = 0L;
/*  649 */       this.config_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/*  652 */       if (!this.hasSummaryStatus) return false;
/*  653 */       for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*  654 */         if (!element.isInitialized()) return false;
/*      */       }
/*  656 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/*  661 */       getSerializedSize();
/*  662 */       if (hasSummaryStatus()) {
/*  663 */         output.writeEnum(1, getSummaryStatus().getNumber());
/*      */       }
/*  665 */       if (hasTimeUntilScheduled()) {
/*  666 */         output.writeInt64(2, getTimeUntilScheduled());
/*      */       }
/*  668 */       for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*  669 */         output.writeMessage(3, element);
/*      */       }
/*  671 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  676 */       int size = this.memoizedSerializedSize;
/*  677 */       if (size != -1) return size;
/*      */ 
/*  679 */       size = 0;
/*  680 */       if (hasSummaryStatus()) {
/*  681 */         size += CodedOutputStream.computeEnumSize(1, getSummaryStatus().getNumber());
/*      */       }
/*      */ 
/*  684 */       if (hasTimeUntilScheduled()) {
/*  685 */         size += CodedOutputStream.computeInt64Size(2, getTimeUntilScheduled());
/*      */       }
/*      */ 
/*  688 */       for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*  689 */         size += CodedOutputStream.computeMessageSize(3, element);
/*      */       }
/*      */ 
/*  692 */       size += getUnknownFields().getSerializedSize();
/*  693 */       this.memoizedSerializedSize = size;
/*  694 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  699 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  705 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  711 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  716 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  722 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(InputStream input) throws IOException
/*      */     {
/*  727 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  733 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  738 */       Builder builder = newBuilder();
/*  739 */       if (builder.mergeDelimitedFrom(input)) {
/*  740 */         return builder.buildParsed();
/*      */       }
/*  742 */       return null;
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  749 */       Builder builder = newBuilder();
/*  750 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  751 */         return builder.buildParsed();
/*      */       }
/*  753 */       return null;
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  759 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  765 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  769 */       return Builder.access$1200(); } 
/*  770 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(IsEnabledResponse prototype) {
/*  772 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  774 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1044 */       CapabilityServicePb.internalForceInit();
/* 1045 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasSummaryStatus;
/*  938 */       private CapabilityServicePb.IsEnabledResponse.SummaryStatus summaryStatus_ = CapabilityServicePb.IsEnabledResponse.SummaryStatus.ENABLED;
/*      */       private boolean hasTimeUntilScheduled;
/*      */       private long timeUntilScheduled_;
/*  980 */       private List<CapabilitiesPb.CapabilityConfig> config_ = Collections.emptyList();
/*      */       private boolean isConfigMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  780 */         return CapabilityServicePb.internal_static_apphosting_IsEnabledResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  785 */         return CapabilityServicePb.internal_static_apphosting_IsEnabledResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  793 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  797 */         super.clear();
/*  798 */         this.summaryStatus_ = CapabilityServicePb.IsEnabledResponse.SummaryStatus.ENABLED;
/*  799 */         this.hasSummaryStatus = false;
/*  800 */         this.timeUntilScheduled_ = 0L;
/*  801 */         this.hasTimeUntilScheduled = false;
/*  802 */         this.config_ = Collections.emptyList();
/*  803 */         this.isConfigMutable = false;
/*  804 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  808 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  813 */         return CapabilityServicePb.IsEnabledResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledResponse getDefaultInstanceForType() {
/*  817 */         return CapabilityServicePb.IsEnabledResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledResponse build() {
/*  821 */         CapabilityServicePb.IsEnabledResponse result = buildPartial();
/*  822 */         if (!result.isInitialized()) {
/*  823 */           throw newUninitializedMessageException(result);
/*      */         }
/*  825 */         return result;
/*      */       }
/*      */ 
/*      */       private CapabilityServicePb.IsEnabledResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  830 */         CapabilityServicePb.IsEnabledResponse result = buildPartial();
/*  831 */         if (!result.isInitialized()) {
/*  832 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  835 */         return result;
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledResponse buildPartial() {
/*  839 */         CapabilityServicePb.IsEnabledResponse result = new CapabilityServicePb.IsEnabledResponse(this, null);
/*  840 */         CapabilityServicePb.IsEnabledResponse.access$1402(result, this.hasSummaryStatus);
/*  841 */         CapabilityServicePb.IsEnabledResponse.access$1502(result, this.summaryStatus_);
/*  842 */         CapabilityServicePb.IsEnabledResponse.access$1602(result, this.hasTimeUntilScheduled);
/*  843 */         CapabilityServicePb.IsEnabledResponse.access$1702(result, this.timeUntilScheduled_);
/*  844 */         if (this.isConfigMutable) {
/*  845 */           this.config_ = Collections.unmodifiableList(this.config_);
/*  846 */           this.isConfigMutable = false;
/*      */         }
/*  848 */         CapabilityServicePb.IsEnabledResponse.access$1802(result, this.config_);
/*  849 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  853 */         if ((other instanceof CapabilityServicePb.IsEnabledResponse)) {
/*  854 */           return mergeFrom((CapabilityServicePb.IsEnabledResponse)other);
/*      */         }
/*  856 */         super.mergeFrom(other);
/*  857 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CapabilityServicePb.IsEnabledResponse other)
/*      */       {
/*  862 */         if (other == CapabilityServicePb.IsEnabledResponse.getDefaultInstance()) return this;
/*  863 */         if (other.hasSummaryStatus()) {
/*  864 */           setSummaryStatus(other.getSummaryStatus());
/*      */         }
/*  866 */         if (other.hasTimeUntilScheduled()) {
/*  867 */           setTimeUntilScheduled(other.getTimeUntilScheduled());
/*      */         }
/*  869 */         if (!other.config_.isEmpty()) {
/*  870 */           if (this.config_.isEmpty()) {
/*  871 */             this.config_ = other.config_;
/*  872 */             this.isConfigMutable = false;
/*      */           } else {
/*  874 */             ensureConfigIsMutable();
/*  875 */             this.config_.addAll(other.config_);
/*      */           }
/*      */         }
/*  878 */         mergeUnknownFields(other.getUnknownFields());
/*  879 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  883 */         if (!this.hasSummaryStatus) return false;
/*  884 */         for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*  885 */           if (!element.isInitialized()) return false;
/*      */         }
/*  887 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  894 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  898 */           int tag = input.readTag();
/*  899 */           switch (tag) {
/*      */           case 0:
/*  901 */             setUnknownFields(unknownFields.build());
/*  902 */             return this;
/*      */           default:
/*  904 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  906 */             setUnknownFields(unknownFields.build());
/*  907 */             return this;
/*      */           case 8:
/*  912 */             int rawValue = input.readEnum();
/*  913 */             CapabilityServicePb.IsEnabledResponse.SummaryStatus value = CapabilityServicePb.IsEnabledResponse.SummaryStatus.valueOf(rawValue);
/*  914 */             if (value == null)
/*  915 */               unknownFields.mergeVarintField(1, rawValue);
/*      */             else {
/*  917 */               setSummaryStatus(value);
/*      */             }
/*  919 */             break;
/*      */           case 16:
/*  922 */             setTimeUntilScheduled(input.readInt64());
/*  923 */             break;
/*      */           case 26:
/*  926 */             CapabilitiesPb.CapabilityConfig.Builder subBuilder = CapabilitiesPb.CapabilityConfig.newBuilder();
/*  927 */             input.readMessage(subBuilder, extensionRegistry);
/*  928 */             addConfig(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasSummaryStatus()
/*      */       {
/*  940 */         return this.hasSummaryStatus;
/*      */       }
/*      */       public CapabilityServicePb.IsEnabledResponse.SummaryStatus getSummaryStatus() {
/*  943 */         return this.summaryStatus_;
/*      */       }
/*      */       public Builder setSummaryStatus(CapabilityServicePb.IsEnabledResponse.SummaryStatus value) {
/*  946 */         if (value == null) {
/*  947 */           throw new NullPointerException();
/*      */         }
/*  949 */         this.hasSummaryStatus = true;
/*  950 */         this.summaryStatus_ = value;
/*  951 */         return this;
/*      */       }
/*      */       public Builder clearSummaryStatus() {
/*  954 */         this.hasSummaryStatus = false;
/*  955 */         this.summaryStatus_ = CapabilityServicePb.IsEnabledResponse.SummaryStatus.ENABLED;
/*  956 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasTimeUntilScheduled()
/*      */       {
/*  963 */         return this.hasTimeUntilScheduled;
/*      */       }
/*      */       public long getTimeUntilScheduled() {
/*  966 */         return this.timeUntilScheduled_;
/*      */       }
/*      */       public Builder setTimeUntilScheduled(long value) {
/*  969 */         this.hasTimeUntilScheduled = true;
/*  970 */         this.timeUntilScheduled_ = value;
/*  971 */         return this;
/*      */       }
/*      */       public Builder clearTimeUntilScheduled() {
/*  974 */         this.hasTimeUntilScheduled = false;
/*  975 */         this.timeUntilScheduled_ = 0L;
/*  976 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureConfigIsMutable()
/*      */       {
/*  984 */         if (!this.isConfigMutable) {
/*  985 */           this.config_ = new ArrayList(this.config_);
/*  986 */           this.isConfigMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<CapabilitiesPb.CapabilityConfig> getConfigList() {
/*  990 */         return Collections.unmodifiableList(this.config_);
/*      */       }
/*      */       public int getConfigCount() {
/*  993 */         return this.config_.size();
/*      */       }
/*      */       public CapabilitiesPb.CapabilityConfig getConfig(int index) {
/*  996 */         return (CapabilitiesPb.CapabilityConfig)this.config_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setConfig(int index, CapabilitiesPb.CapabilityConfig value) {
/* 1000 */         if (value == null) {
/* 1001 */           throw new NullPointerException();
/*      */         }
/* 1003 */         ensureConfigIsMutable();
/* 1004 */         this.config_.set(index, value);
/* 1005 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setConfig(int index, CapabilitiesPb.CapabilityConfig.Builder builderForValue) {
/* 1009 */         ensureConfigIsMutable();
/* 1010 */         this.config_.set(index, builderForValue.build());
/* 1011 */         return this;
/*      */       }
/*      */       public Builder addConfig(CapabilitiesPb.CapabilityConfig value) {
/* 1014 */         if (value == null) {
/* 1015 */           throw new NullPointerException();
/*      */         }
/* 1017 */         ensureConfigIsMutable();
/* 1018 */         this.config_.add(value);
/* 1019 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addConfig(CapabilitiesPb.CapabilityConfig.Builder builderForValue) {
/* 1023 */         ensureConfigIsMutable();
/* 1024 */         this.config_.add(builderForValue.build());
/* 1025 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllConfig(Iterable<? extends CapabilitiesPb.CapabilityConfig> values) {
/* 1029 */         ensureConfigIsMutable();
/* 1030 */         GeneratedMessage.Builder.addAll(values, this.config_);
/* 1031 */         return this;
/*      */       }
/*      */       public Builder clearConfig() {
/* 1034 */         this.config_ = Collections.emptyList();
/* 1035 */         this.isConfigMutable = false;
/* 1036 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum SummaryStatus
/*      */       implements ProtocolMessageEnum
/*      */     {
/*  534 */       ENABLED(0, 1), 
/*  535 */       SCHEDULED_FUTURE(1, 2), 
/*  536 */       SCHEDULED_NOW(2, 3), 
/*  537 */       DISABLED(3, 4), 
/*  538 */       UNKNOWN(4, 5);
/*      */ 
/*      */       public static final int ENABLED_VALUE = 1;
/*      */       public static final int SCHEDULED_FUTURE_VALUE = 2;
/*      */       public static final int SCHEDULED_NOW_VALUE = 3;
/*      */       public static final int DISABLED_VALUE = 4;
/*      */       public static final int UNKNOWN_VALUE = 5;
/*      */       private static Internal.EnumLiteMap<SummaryStatus> internalValueMap;
/*      */       private static final SummaryStatus[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/*  548 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static SummaryStatus valueOf(int value) {
/*  551 */         switch (value) { case 1:
/*  552 */           return ENABLED;
/*      */         case 2:
/*  553 */           return SCHEDULED_FUTURE;
/*      */         case 3:
/*  554 */           return SCHEDULED_NOW;
/*      */         case 4:
/*  555 */           return DISABLED;
/*      */         case 5:
/*  556 */           return UNKNOWN; }
/*  557 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<SummaryStatus> internalGetValueMap()
/*      */       {
/*  563 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/*  575 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  579 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  583 */         return (Descriptors.EnumDescriptor)CapabilityServicePb.IsEnabledResponse.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static SummaryStatus valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/*  591 */         if (desc.getType() != getDescriptor()) {
/*  592 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/*  595 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private SummaryStatus(int index, int value)
/*      */       {
/*  600 */         this.index = index;
/*  601 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  566 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public CapabilityServicePb.IsEnabledResponse.SummaryStatus findValueByNumber(int number) {
/*  569 */             return CapabilityServicePb.IsEnabledResponse.SummaryStatus.valueOf(number);
/*      */           }
/*      */         };
/*  586 */         VALUES = new SummaryStatus[] { ENABLED, SCHEDULED_FUTURE, SCHEDULED_NOW, DISABLED, UNKNOWN };
/*      */ 
/*  605 */         CapabilityServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class IsEnabledRequest extends GeneratedMessage
/*      */   {
/*  497 */     private static final IsEnabledRequest defaultInstance = new IsEnabledRequest(true);
/*      */     public static final int PACKAGE_FIELD_NUMBER = 1;
/*      */     private boolean hasPackage;
/*      */     private String package_;
/*      */     public static final int CAPABILITY_FIELD_NUMBER = 2;
/*      */     private List<String> capability_;
/*      */     public static final int CALL_FIELD_NUMBER = 3;
/*      */     private List<String> call_;
/*  102 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private IsEnabledRequest(Builder builder)
/*      */     {
/*   15 */       super();
/*      */     }
/*      */     private IsEnabledRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest getDefaultInstance() {
/*   21 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public IsEnabledRequest getDefaultInstanceForType() {
/*   25 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*   30 */       return CapabilityServicePb.internal_static_apphosting_IsEnabledRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*   35 */       return CapabilityServicePb.internal_static_apphosting_IsEnabledRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasPackage()
/*      */     {
/*   43 */       return this.hasPackage;
/*      */     }
/*      */     public String getPackage() {
/*   46 */       return this.package_;
/*      */     }
/*      */ 
/*      */     public List<String> getCapabilityList()
/*      */     {
/*   54 */       return this.capability_;
/*      */     }
/*      */     public int getCapabilityCount() {
/*   57 */       return this.capability_.size();
/*      */     }
/*      */     public String getCapability(int index) {
/*   60 */       return (String)this.capability_.get(index);
/*      */     }
/*      */ 
/*      */     public List<String> getCallList()
/*      */     {
/*   68 */       return this.call_;
/*      */     }
/*      */     public int getCallCount() {
/*   71 */       return this.call_.size();
/*      */     }
/*      */     public String getCall(int index) {
/*   74 */       return (String)this.call_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*   78 */       this.package_ = "";
/*   79 */       this.capability_ = Collections.emptyList();
/*   80 */       this.call_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/*   83 */       return this.hasPackage;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/*   89 */       getSerializedSize();
/*   90 */       if (hasPackage()) {
/*   91 */         output.writeString(1, getPackage());
/*      */       }
/*   93 */       for (String element : getCapabilityList()) {
/*   94 */         output.writeString(2, element);
/*      */       }
/*   96 */       for (String element : getCallList()) {
/*   97 */         output.writeString(3, element);
/*      */       }
/*   99 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  104 */       int size = this.memoizedSerializedSize;
/*  105 */       if (size != -1) return size;
/*      */ 
/*  107 */       size = 0;
/*  108 */       if (hasPackage()) {
/*  109 */         size += CodedOutputStream.computeStringSize(1, getPackage());
/*      */       }
/*      */ 
/*  113 */       int dataSize = 0;
/*  114 */       for (String element : getCapabilityList()) {
/*  115 */         dataSize += CodedOutputStream.computeStringSizeNoTag(element);
/*      */       }
/*      */ 
/*  118 */       size += dataSize;
/*  119 */       size += 1 * getCapabilityList().size();
/*      */ 
/*  122 */       int dataSize = 0;
/*  123 */       for (String element : getCallList()) {
/*  124 */         dataSize += CodedOutputStream.computeStringSizeNoTag(element);
/*      */       }
/*      */ 
/*  127 */       size += dataSize;
/*  128 */       size += 1 * getCallList().size();
/*      */ 
/*  130 */       size += getUnknownFields().getSerializedSize();
/*  131 */       this.memoizedSerializedSize = size;
/*  132 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  137 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  143 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  149 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  154 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  160 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(InputStream input) throws IOException
/*      */     {
/*  165 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  171 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  176 */       Builder builder = newBuilder();
/*  177 */       if (builder.mergeDelimitedFrom(input)) {
/*  178 */         return builder.buildParsed();
/*      */       }
/*  180 */       return null;
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  187 */       Builder builder = newBuilder();
/*  188 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  189 */         return builder.buildParsed();
/*      */       }
/*  191 */       return null;
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  197 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IsEnabledRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  203 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  207 */       return Builder.access$300(); } 
/*  208 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(IsEnabledRequest prototype) {
/*  210 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  212 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  498 */       CapabilityServicePb.internalForceInit();
/*  499 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasPackage;
/*  374 */       private String package_ = "";
/*      */ 
/*  396 */       private List<String> capability_ = Collections.emptyList();
/*      */       private boolean isCapabilityMutable;
/*  445 */       private List<String> call_ = Collections.emptyList();
/*      */       private boolean isCallMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  218 */         return CapabilityServicePb.internal_static_apphosting_IsEnabledRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  223 */         return CapabilityServicePb.internal_static_apphosting_IsEnabledRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  231 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  235 */         super.clear();
/*  236 */         this.package_ = "";
/*  237 */         this.hasPackage = false;
/*  238 */         this.capability_ = Collections.emptyList();
/*  239 */         this.isCapabilityMutable = false;
/*  240 */         this.call_ = Collections.emptyList();
/*  241 */         this.isCallMutable = false;
/*  242 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  246 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  251 */         return CapabilityServicePb.IsEnabledRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledRequest getDefaultInstanceForType() {
/*  255 */         return CapabilityServicePb.IsEnabledRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledRequest build() {
/*  259 */         CapabilityServicePb.IsEnabledRequest result = buildPartial();
/*  260 */         if (!result.isInitialized()) {
/*  261 */           throw newUninitializedMessageException(result);
/*      */         }
/*  263 */         return result;
/*      */       }
/*      */ 
/*      */       private CapabilityServicePb.IsEnabledRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  268 */         CapabilityServicePb.IsEnabledRequest result = buildPartial();
/*  269 */         if (!result.isInitialized()) {
/*  270 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  273 */         return result;
/*      */       }
/*      */ 
/*      */       public CapabilityServicePb.IsEnabledRequest buildPartial() {
/*  277 */         CapabilityServicePb.IsEnabledRequest result = new CapabilityServicePb.IsEnabledRequest(this, null);
/*  278 */         CapabilityServicePb.IsEnabledRequest.access$502(result, this.hasPackage);
/*  279 */         CapabilityServicePb.IsEnabledRequest.access$602(result, this.package_);
/*  280 */         if (this.isCapabilityMutable) {
/*  281 */           this.capability_ = Collections.unmodifiableList(this.capability_);
/*  282 */           this.isCapabilityMutable = false;
/*      */         }
/*  284 */         CapabilityServicePb.IsEnabledRequest.access$702(result, this.capability_);
/*  285 */         if (this.isCallMutable) {
/*  286 */           this.call_ = Collections.unmodifiableList(this.call_);
/*  287 */           this.isCallMutable = false;
/*      */         }
/*  289 */         CapabilityServicePb.IsEnabledRequest.access$802(result, this.call_);
/*  290 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  294 */         if ((other instanceof CapabilityServicePb.IsEnabledRequest)) {
/*  295 */           return mergeFrom((CapabilityServicePb.IsEnabledRequest)other);
/*      */         }
/*  297 */         super.mergeFrom(other);
/*  298 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CapabilityServicePb.IsEnabledRequest other)
/*      */       {
/*  303 */         if (other == CapabilityServicePb.IsEnabledRequest.getDefaultInstance()) return this;
/*  304 */         if (other.hasPackage()) {
/*  305 */           setPackage(other.getPackage());
/*      */         }
/*  307 */         if (!other.capability_.isEmpty()) {
/*  308 */           if (this.capability_.isEmpty()) {
/*  309 */             this.capability_ = other.capability_;
/*  310 */             this.isCapabilityMutable = false;
/*      */           } else {
/*  312 */             ensureCapabilityIsMutable();
/*  313 */             this.capability_.addAll(other.capability_);
/*      */           }
/*      */         }
/*  316 */         if (!other.call_.isEmpty()) {
/*  317 */           if (this.call_.isEmpty()) {
/*  318 */             this.call_ = other.call_;
/*  319 */             this.isCallMutable = false;
/*      */           } else {
/*  321 */             ensureCallIsMutable();
/*  322 */             this.call_.addAll(other.call_);
/*      */           }
/*      */         }
/*  325 */         mergeUnknownFields(other.getUnknownFields());
/*  326 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  330 */         return this.hasPackage;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  338 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  342 */           int tag = input.readTag();
/*  343 */           switch (tag) {
/*      */           case 0:
/*  345 */             setUnknownFields(unknownFields.build());
/*  346 */             return this;
/*      */           default:
/*  348 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  350 */             setUnknownFields(unknownFields.build());
/*  351 */             return this;
/*      */           case 10:
/*  356 */             setPackage(input.readString());
/*  357 */             break;
/*      */           case 18:
/*  360 */             addCapability(input.readString());
/*  361 */             break;
/*      */           case 26:
/*  364 */             addCall(input.readString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasPackage()
/*      */       {
/*  376 */         return this.hasPackage;
/*      */       }
/*      */       public String getPackage() {
/*  379 */         return this.package_;
/*      */       }
/*      */       public Builder setPackage(String value) {
/*  382 */         if (value == null) {
/*  383 */           throw new NullPointerException();
/*      */         }
/*  385 */         this.hasPackage = true;
/*  386 */         this.package_ = value;
/*  387 */         return this;
/*      */       }
/*      */       public Builder clearPackage() {
/*  390 */         this.hasPackage = false;
/*  391 */         this.package_ = CapabilityServicePb.IsEnabledRequest.getDefaultInstance().getPackage();
/*  392 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureCapabilityIsMutable()
/*      */       {
/*  400 */         if (!this.isCapabilityMutable) {
/*  401 */           this.capability_ = new ArrayList(this.capability_);
/*  402 */           this.isCapabilityMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<String> getCapabilityList() {
/*  407 */         return Collections.unmodifiableList(this.capability_);
/*      */       }
/*      */       public int getCapabilityCount() {
/*  410 */         return this.capability_.size();
/*      */       }
/*      */       public String getCapability(int index) {
/*  413 */         return (String)this.capability_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setCapability(int index, String value) {
/*  417 */         if (value == null) {
/*  418 */           throw new NullPointerException();
/*      */         }
/*  420 */         ensureCapabilityIsMutable();
/*  421 */         this.capability_.set(index, value);
/*  422 */         return this;
/*      */       }
/*      */       public Builder addCapability(String value) {
/*  425 */         if (value == null) {
/*  426 */           throw new NullPointerException();
/*      */         }
/*  428 */         ensureCapabilityIsMutable();
/*  429 */         this.capability_.add(value);
/*  430 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllCapability(Iterable<? extends String> values) {
/*  434 */         ensureCapabilityIsMutable();
/*  435 */         GeneratedMessage.Builder.addAll(values, this.capability_);
/*  436 */         return this;
/*      */       }
/*      */       public Builder clearCapability() {
/*  439 */         this.capability_ = Collections.emptyList();
/*  440 */         this.isCapabilityMutable = false;
/*  441 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureCallIsMutable()
/*      */       {
/*  449 */         if (!this.isCallMutable) {
/*  450 */           this.call_ = new ArrayList(this.call_);
/*  451 */           this.isCallMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<String> getCallList() {
/*  456 */         return Collections.unmodifiableList(this.call_);
/*      */       }
/*      */       public int getCallCount() {
/*  459 */         return this.call_.size();
/*      */       }
/*      */       public String getCall(int index) {
/*  462 */         return (String)this.call_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setCall(int index, String value) {
/*  466 */         if (value == null) {
/*  467 */           throw new NullPointerException();
/*      */         }
/*  469 */         ensureCallIsMutable();
/*  470 */         this.call_.set(index, value);
/*  471 */         return this;
/*      */       }
/*      */       public Builder addCall(String value) {
/*  474 */         if (value == null) {
/*  475 */           throw new NullPointerException();
/*      */         }
/*  477 */         ensureCallIsMutable();
/*  478 */         this.call_.add(value);
/*  479 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllCall(Iterable<? extends String> values) {
/*  483 */         ensureCallIsMutable();
/*  484 */         GeneratedMessage.Builder.addAll(values, this.call_);
/*  485 */         return this;
/*      */       }
/*      */       public Builder clearCall() {
/*  488 */         this.call_ = Collections.emptyList();
/*  489 */         this.isCallMutable = false;
/*  490 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.CapabilityServicePb
 * JD-Core Version:    0.6.0
 */