/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(emulated=true)
/*     */ abstract class AbstractBiMap<K, V> extends ForwardingMap<K, V>
/*     */   implements BiMap<K, V>, Serializable
/*     */ {
/*     */   private transient Map<K, V> delegate;
/*     */   private transient AbstractBiMap<V, K> inverse;
/*     */   private transient Set<K> keySet;
/*     */   private transient Set<V> valueSet;
/*     */   private transient Set<Map.Entry<K, V>> entrySet;
/*     */ 
/*     */   @GwtIncompatible("Not needed in emulated source.")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   AbstractBiMap(Map<K, V> forward, Map<V, K> backward)
/*     */   {
/*  56 */     setDelegates(forward, backward);
/*     */   }
/*     */ 
/*     */   private AbstractBiMap(Map<K, V> backward, AbstractBiMap<V, K> forward)
/*     */   {
/*  61 */     this.delegate = backward;
/*  62 */     this.inverse = forward;
/*     */   }
/*     */ 
/*     */   protected Map<K, V> delegate() {
/*  66 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   void setDelegates(Map<K, V> forward, Map<V, K> backward)
/*     */   {
/*  74 */     Preconditions.checkState(this.delegate == null);
/*  75 */     Preconditions.checkState(this.inverse == null);
/*  76 */     Preconditions.checkArgument(forward.isEmpty());
/*  77 */     Preconditions.checkArgument(backward.isEmpty());
/*  78 */     Preconditions.checkArgument(forward != backward);
/*  79 */     this.delegate = forward;
/*  80 */     this.inverse = new Inverse(backward, this, null);
/*     */   }
/*     */ 
/*     */   void setInverse(AbstractBiMap<V, K> inverse) {
/*  84 */     this.inverse = inverse;
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/*  90 */     return this.inverse.containsKey(value);
/*     */   }
/*     */ 
/*     */   public V put(K key, V value)
/*     */   {
/*  96 */     return putInBothMaps(key, value, false);
/*     */   }
/*     */ 
/*     */   public V forcePut(K key, V value) {
/* 100 */     return putInBothMaps(key, value, true);
/*     */   }
/*     */ 
/*     */   private V putInBothMaps(@Nullable K key, @Nullable V value, boolean force) {
/* 104 */     boolean containedKey = containsKey(key);
/* 105 */     if ((containedKey) && (Objects.equal(value, get(key)))) {
/* 106 */       return value;
/*     */     }
/* 108 */     if (force)
/* 109 */       inverse().remove(value);
/*     */     else {
/* 111 */       Preconditions.checkArgument(!containsValue(value), "value already present: %s", new Object[] { value });
/*     */     }
/* 113 */     Object oldValue = this.delegate.put(key, value);
/* 114 */     updateInverseMap(key, containedKey, oldValue, value);
/* 115 */     return oldValue;
/*     */   }
/*     */ 
/*     */   private void updateInverseMap(K key, boolean containedKey, V oldValue, V newValue)
/*     */   {
/* 120 */     if (containedKey) {
/* 121 */       removeFromInverseMap(oldValue);
/*     */     }
/* 123 */     this.inverse.delegate.put(newValue, key);
/*     */   }
/*     */ 
/*     */   public V remove(Object key) {
/* 127 */     return containsKey(key) ? removeFromBothMaps(key) : null;
/*     */   }
/*     */ 
/*     */   private V removeFromBothMaps(Object key) {
/* 131 */     Object oldValue = this.delegate.remove(key);
/* 132 */     removeFromInverseMap(oldValue);
/* 133 */     return oldValue;
/*     */   }
/*     */ 
/*     */   private void removeFromInverseMap(V oldValue) {
/* 137 */     this.inverse.delegate.remove(oldValue);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends K, ? extends V> map)
/*     */   {
/* 143 */     for (Map.Entry entry : map.entrySet())
/* 144 */       put(entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 149 */     this.delegate.clear();
/* 150 */     this.inverse.delegate.clear();
/*     */   }
/*     */ 
/*     */   public BiMap<V, K> inverse()
/*     */   {
/* 156 */     return this.inverse;
/*     */   }
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/* 162 */     Set result = this.keySet;
/* 163 */     return result == null ? (this.keySet = new KeySet(null)) : result;
/*     */   }
/*     */ 
/*     */   public Set<V> values()
/*     */   {
/* 220 */     Set result = this.valueSet;
/* 221 */     return result == null ? (this.valueSet = new ValueSet(null)) : result;
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entrySet()
/*     */   {
/* 267 */     Set result = this.entrySet;
/* 268 */     return result == null ? (this.entrySet = new EntrySet(null)) : result;
/*     */   }
/*     */ 
/*     */   private static class Inverse<K, V> extends AbstractBiMap<K, V>
/*     */   {
/*     */ 
/*     */     @GwtIncompatible("Not needed in emulated source.")
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private Inverse(Map<K, V> backward, AbstractBiMap<V, K> forward)
/*     */     {
/* 361 */       super(forward, null);
/*     */     }
/*     */ 
/*     */     @GwtIncompatible("java.io.ObjectOuputStream")
/*     */     private void writeObject(ObjectOutputStream stream)
/*     */       throws IOException
/*     */     {
/* 378 */       stream.defaultWriteObject();
/* 379 */       stream.writeObject(inverse());
/*     */     }
/*     */ 
/*     */     @GwtIncompatible("java.io.ObjectInputStream")
/*     */     private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*     */     {
/* 386 */       stream.defaultReadObject();
/* 387 */       setInverse((AbstractBiMap)stream.readObject());
/*     */     }
/*     */     @GwtIncompatible("Not needed in the emulated source.")
/*     */     Object readResolve() {
/* 392 */       return inverse().inverse();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EntrySet extends ForwardingSet<Map.Entry<K, V>>
/*     */   {
/* 272 */     final Set<Map.Entry<K, V>> esDelegate = AbstractBiMap.this.delegate.entrySet();
/*     */ 
/*     */     private EntrySet() {  }
/*     */ 
/* 275 */     protected Set<Map.Entry<K, V>> delegate() { return this.esDelegate; }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 279 */       AbstractBiMap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object object) {
/* 283 */       if (!this.esDelegate.remove(object)) {
/* 284 */         return false;
/*     */       }
/* 286 */       Map.Entry entry = (Map.Entry)object;
/* 287 */       AbstractBiMap.access$600(AbstractBiMap.this).delegate.remove(entry.getValue());
/* 288 */       return true;
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, V>> iterator() {
/* 292 */       Iterator iterator = this.esDelegate.iterator();
/* 293 */       return new Iterator(iterator) {
/*     */         Map.Entry<K, V> entry;
/*     */ 
/* 297 */         public boolean hasNext() { return this.val$iterator.hasNext(); }
/*     */ 
/*     */         public Map.Entry<K, V> next()
/*     */         {
/* 301 */           this.entry = ((Map.Entry)this.val$iterator.next());
/* 302 */           Map.Entry finalEntry = this.entry;
/*     */ 
/* 304 */           return new ForwardingMapEntry(finalEntry) {
/*     */             protected Map.Entry<K, V> delegate() {
/* 306 */               return this.val$finalEntry;
/*     */             }
/*     */ 
/*     */             public V setValue(V value)
/*     */             {
/* 311 */               Preconditions.checkState(AbstractBiMap.EntrySet.this.contains(this), "entry no longer in map");
/*     */ 
/* 313 */               if (Objects.equal(value, getValue())) {
/* 314 */                 return value;
/*     */               }
/* 316 */               Preconditions.checkArgument(!AbstractBiMap.this.containsValue(value), "value already present: %s", new Object[] { value });
/*     */ 
/* 318 */               Object oldValue = this.val$finalEntry.setValue(value);
/* 319 */               Preconditions.checkState(Objects.equal(value, AbstractBiMap.this.get(getKey())), "entry no longer in map");
/*     */ 
/* 321 */               AbstractBiMap.this.updateInverseMap(getKey(), true, oldValue, value);
/* 322 */               return oldValue;
/*     */             } } ;
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 328 */           Preconditions.checkState(this.entry != null);
/* 329 */           Object value = this.entry.getValue();
/* 330 */           this.val$iterator.remove();
/* 331 */           AbstractBiMap.this.removeFromInverseMap(value);
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 339 */       return ObjectArrays.toArrayImpl(this);
/*     */     }
/*     */     public <T> T[] toArray(T[] array) {
/* 342 */       return ObjectArrays.toArrayImpl(this, array);
/*     */     }
/*     */     public boolean contains(Object o) {
/* 345 */       return Maps.containsEntryImpl(delegate(), o);
/*     */     }
/*     */     public boolean containsAll(Collection<?> c) {
/* 348 */       return Collections2.containsAll(this, c);
/*     */     }
/*     */     public boolean removeAll(Collection<?> c) {
/* 351 */       return Iterators.removeAll(iterator(), c);
/*     */     }
/*     */     public boolean retainAll(Collection<?> c) {
/* 354 */       return Iterators.retainAll(iterator(), c);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ValueSet extends ForwardingSet<V>
/*     */   {
/* 225 */     final Set<V> valuesDelegate = AbstractBiMap.this.inverse.keySet();
/*     */ 
/*     */     private ValueSet() {  }
/*     */ 
/* 228 */     protected Set<V> delegate() { return this.valuesDelegate; }
/*     */ 
/*     */     public Iterator<V> iterator()
/*     */     {
/* 232 */       Iterator iterator = AbstractBiMap.this.delegate.values().iterator();
/* 233 */       return new Iterator(iterator) {
/*     */         V valueToRemove;
/*     */ 
/* 237 */         public boolean hasNext() { return this.val$iterator.hasNext(); }
/*     */ 
/*     */         public V next()
/*     */         {
/* 241 */           return this.valueToRemove = this.val$iterator.next();
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 245 */           this.val$iterator.remove();
/* 246 */           AbstractBiMap.this.removeFromInverseMap(this.valueToRemove);
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public Object[] toArray() {
/* 252 */       return ObjectArrays.toArrayImpl(this);
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 256 */       return ObjectArrays.toArrayImpl(this, array);
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 260 */       return Iterators.toString(iterator());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class KeySet extends ForwardingSet<K>
/*     */   {
/*     */     private KeySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Set<K> delegate()
/*     */     {
/* 168 */       return AbstractBiMap.this.delegate.keySet();
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 172 */       AbstractBiMap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object key) {
/* 176 */       if (!contains(key)) {
/* 177 */         return false;
/*     */       }
/* 179 */       AbstractBiMap.this.removeFromBothMaps(key);
/* 180 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> keysToRemove) {
/* 184 */       return Iterators.removeAll(iterator(), keysToRemove);
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> keysToRetain) {
/* 188 */       return Iterators.retainAll(iterator(), keysToRetain);
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator() {
/* 192 */       Iterator iterator = AbstractBiMap.this.delegate.entrySet().iterator();
/* 193 */       return new Iterator(iterator) {
/*     */         Map.Entry<K, V> entry;
/*     */ 
/* 197 */         public boolean hasNext() { return this.val$iterator.hasNext(); }
/*     */ 
/*     */         public K next() {
/* 200 */           this.entry = ((Map.Entry)this.val$iterator.next());
/* 201 */           return this.entry.getKey();
/*     */         }
/*     */         public void remove() {
/* 204 */           Preconditions.checkState(this.entry != null);
/* 205 */           Object value = this.entry.getValue();
/* 206 */           this.val$iterator.remove();
/* 207 */           AbstractBiMap.this.removeFromInverseMap(value);
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.AbstractBiMap
 * JD-Core Version:    0.6.0
 */