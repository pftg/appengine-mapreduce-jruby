/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import java.lang.ref.SoftReference;
/*    */ 
/*    */ public abstract class FinalizableSoftReference<T> extends SoftReference<T>
/*    */   implements FinalizableReference
/*    */ {
/*    */   protected FinalizableSoftReference(T referent, FinalizableReferenceQueue queue)
/*    */   {
/* 37 */     super(referent, queue.queue);
/* 38 */     queue.cleanUp();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.FinalizableSoftReference
 * JD-Core Version:    0.6.0
 */