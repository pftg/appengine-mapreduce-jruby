/*     */ package com.google.appengine.repackaged.com.google.common.base.internal;
/*     */ 
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class Finalizer extends Thread
/*     */ {
/*  51 */   private static final Logger logger = Logger.getLogger(Finalizer.class.getName());
/*     */   private static final String FINALIZABLE_REFERENCE = "com.google.appengine.repackaged.com.google.common.base.FinalizableReference";
/*     */   private final WeakReference<Class<?>> finalizableReferenceClassReference;
/*     */   private final PhantomReference<Object> frqReference;
/*  89 */   private final ReferenceQueue<Object> queue = new ReferenceQueue();
/*     */ 
/*  91 */   private static final Field inheritableThreadLocals = getInheritableThreadLocalsField();
/*     */ 
/*     */   public static ReferenceQueue<Object> startFinalizer(Class<?> finalizableReferenceClass, Object frq)
/*     */   {
/*  77 */     if (!finalizableReferenceClass.getName().equals("com.google.appengine.repackaged.com.google.common.base.FinalizableReference")) {
/*  78 */       throw new IllegalArgumentException("Expected com.google.common.base.FinalizableReference.");
/*     */     }
/*     */ 
/*  82 */     Finalizer finalizer = new Finalizer(finalizableReferenceClass, frq);
/*  83 */     finalizer.start();
/*  84 */     return finalizer.queue;
/*     */   }
/*     */ 
/*     */   private Finalizer(Class<?> finalizableReferenceClass, Object frq)
/*     */   {
/*  96 */     super(Finalizer.class.getName());
/*     */ 
/*  98 */     this.finalizableReferenceClassReference = new WeakReference(finalizableReferenceClass);
/*     */ 
/* 102 */     this.frqReference = new PhantomReference(frq, this.queue);
/*     */ 
/* 104 */     setDaemon(true);
/*     */     try
/*     */     {
/* 107 */       if (inheritableThreadLocals != null)
/* 108 */         inheritableThreadLocals.set(this, null);
/*     */     }
/*     */     catch (Throwable t) {
/* 111 */       logger.log(Level.INFO, "Failed to clear thread local values inherited by reference finalizer thread.", t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*     */       while (true)
/*     */         try
/*     */         {
/* 127 */           cleanUp(this.queue.remove());
/* 128 */           continue;
/*     */         } catch (InterruptedException e) {
/*     */         }
/*     */     }
/*     */     catch (ShutDown shutDown) {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void cleanUp(Reference<?> reference) throws Finalizer.ShutDown {
/* 137 */     Method finalizeReferentMethod = getFinalizeReferentMethod();
/*     */     do
/*     */     {
/* 143 */       reference.clear();
/*     */ 
/* 145 */       if (reference == this.frqReference)
/*     */       {
/* 150 */         throw new ShutDown(null);
/*     */       }
/*     */       try
/*     */       {
/* 154 */         finalizeReferentMethod.invoke(reference, new Object[0]);
/*     */       } catch (Throwable t) {
/* 156 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 163 */     while ((reference = this.queue.poll()) != null);
/*     */   }
/*     */ 
/*     */   private Method getFinalizeReferentMethod()
/*     */     throws Finalizer.ShutDown
/*     */   {
/* 170 */     Class finalizableReferenceClass = (Class)this.finalizableReferenceClassReference.get();
/*     */ 
/* 172 */     if (finalizableReferenceClass == null)
/*     */     {
/* 181 */       throw new ShutDown(null);
/*     */     }
/*     */     try {
/* 184 */       return finalizableReferenceClass.getMethod("finalizeReferent", new Class[0]); } catch (NoSuchMethodException e) {
/*     */     }
/* 186 */     throw new AssertionError(e);
/*     */   }
/*     */ 
/*     */   public static Field getInheritableThreadLocalsField()
/*     */   {
/*     */     try {
/* 192 */       Field inheritableThreadLocals = Thread.class.getDeclaredField("inheritableThreadLocals");
/*     */ 
/* 194 */       inheritableThreadLocals.setAccessible(true);
/* 195 */       return inheritableThreadLocals;
/*     */     } catch (Throwable t) {
/* 197 */       logger.log(Level.INFO, "Couldn't access Thread.inheritableThreadLocals. Reference finalizer threads will inherit thread local values.");
/*     */     }
/*     */ 
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */   private static class ShutDown extends Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.internal.Finalizer
 * JD-Core Version:    0.6.0
 */