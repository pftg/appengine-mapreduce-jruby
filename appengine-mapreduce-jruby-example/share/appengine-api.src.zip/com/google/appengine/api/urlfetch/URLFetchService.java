package com.google.appengine.api.urlfetch;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.Future;

public abstract interface URLFetchService
{
  public abstract HTTPResponse fetch(URL paramURL)
    throws IOException;

  public abstract HTTPResponse fetch(HTTPRequest paramHTTPRequest)
    throws IOException;

  public abstract Future<HTTPResponse> fetchAsync(URL paramURL);

  public abstract Future<HTTPResponse> fetchAsync(HTTPRequest paramHTTPRequest);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.URLFetchService
 * JD-Core Version:    0.6.0
 */