/*      */ package com.google.appengine.api.datastore;
/*      */ 
/*      */ import com.google.appengine.api.blobstore.BlobKey;
/*      */ import com.google.appengine.api.users.User;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.Path;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.Path.Element;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.Property;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.Property.Meaning;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.PointValue;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.ReferenceValue;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.ReferenceValuePathElement;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.UserValue;
/*      */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ public final class DataTypeTranslator
/*      */ {
/*      */   private static final StringType STRING_TYPE;
/*      */   private static final Map<Class<?>, Type<?>> typeMap;
/*      */   private static final Map<Class<? extends Comparable<?>>, Integer> comparableTypeMap;
/*      */   private static final AsComparableFunction NOT_COMPARABLE;
/*      */   private static final AsComparableFunction COMP_BYTE_ARRAY_FUNC;
/*      */   private static final AsComparableFunction INT_64_COMP_FUNC;
/*      */   private static final AsComparableFunction DOUBLE_COMP_FUNC;
/*      */   private static final AsComparableFunction BOOLEAN_COMP_FUNC;
/*      */ 
/*      */   public static void addPropertiesToPb(Map<String, Object> map, OnestoreEntity.EntityProto proto)
/*      */   {
/*  121 */     for (Map.Entry entry : map.entrySet()) {
/*  122 */       String key = (String)entry.getKey();
/*  123 */       boolean indexed = !(entry.getValue() instanceof Entity.UnindexedValue);
/*  124 */       Object value = Entity.unwrapValue(entry.getValue());
/*      */       Iterator i$;
/*  126 */       if ((value instanceof Collection)) {
/*  127 */         Collection values = (Collection)value;
/*  128 */         if (values.isEmpty())
/*      */         {
/*  135 */           addProperty(proto, key, null, indexed, false);
/*      */         }
/*  137 */         else for (i$ = values.iterator(); i$.hasNext(); ) { Object listValue = i$.next();
/*  138 */             addProperty(proto, key, listValue, indexed, true); }
/*      */       }
/*      */       else
/*      */       {
/*  142 */         addProperty(proto, key, value, indexed, false);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void addProperty(OnestoreEntity.EntityProto entity, String name, Object value, boolean indexed, boolean multiple)
/*      */   {
/*  159 */     Pair pair = createProperty(name, value, multiple);
/*  160 */     Type type = (Type)pair.first();
/*  161 */     OnestoreEntity.Property property = (OnestoreEntity.Property)pair.second();
/*      */ 
/*  163 */     if ((!indexed) || ((type != null) && (type.getComparableFunction() == null)))
/*  164 */       entity.addRawProperty(property);
/*      */     else
/*  166 */       entity.addProperty(property);
/*      */   }
/*      */ 
/*      */   private static Pair<Type<?>, OnestoreEntity.Property> createProperty(String name, Object value, boolean multiple)
/*      */   {
/*  183 */     OnestoreEntity.Property property = new OnestoreEntity.Property();
/*  184 */     property.setName(name);
/*  185 */     property.setMultiple(multiple);
/*      */ 
/*  187 */     if (value == null) {
/*  188 */       return Pair.of(null, property);
/*      */     }
/*      */ 
/*  191 */     Pair newValue = createPropertyValue(value);
/*  192 */     Type type = (Type)newValue.first;
/*  193 */     OnestoreEntity.Property.Meaning meaning = type.getMeaning();
/*  194 */     if (meaning != null) {
/*  195 */       property.setMeaning(meaning);
/*      */     }
/*  197 */     property.setValue((OnestoreEntity.PropertyValue)newValue.second);
/*  198 */     return new Pair(type, property);
/*      */   }
/*      */ 
/*      */   private static Pair<Type<?>, OnestoreEntity.PropertyValue> createPropertyValue(Object value) {
/*  202 */     if (value == null) {
/*  203 */       return Pair.of(null, null);
/*      */     }
/*  205 */     OnestoreEntity.PropertyValue newValue = new OnestoreEntity.PropertyValue();
/*  206 */     Type type = getType(value.getClass());
/*  207 */     type.setPropertyValue(newValue, value);
/*  208 */     return new Pair(type, newValue);
/*      */   }
/*      */ 
/*      */   public static void extractIndexedPropertiesFromPb(OnestoreEntity.EntityProto proto, Map<String, Object> map)
/*      */   {
/*  216 */     for (OnestoreEntity.Property property : proto.propertys())
/*  217 */       addPropertyValueToMap(property, map, true);
/*      */   }
/*      */ 
/*      */   private static void extractUnindexedPropertiesFromPb(OnestoreEntity.EntityProto proto, Map<String, Object> map)
/*      */   {
/*  227 */     for (OnestoreEntity.Property property : proto.rawPropertys())
/*  228 */       addPropertyValueToMap(property, map, false);
/*      */   }
/*      */ 
/*      */   public static void extractPropertiesFromPb(OnestoreEntity.EntityProto proto, Map<String, Object> map)
/*      */   {
/*  238 */     extractIndexedPropertiesFromPb(proto, map);
/*  239 */     extractUnindexedPropertiesFromPb(proto, map);
/*      */   }
/*      */ 
/*      */   public static void extractImplicitPropertiesFromPb(OnestoreEntity.EntityProto proto, Map<String, Object> map)
/*      */   {
/*  247 */     for (OnestoreEntity.Property property : getImplicitProperties(proto))
/*  248 */       addPropertyValueToMap(property, map, true);
/*      */   }
/*      */ 
/*      */   private static Iterable<OnestoreEntity.Property> getImplicitProperties(OnestoreEntity.EntityProto proto)
/*      */   {
/*  253 */     return Collections.singleton(buildImplicitKeyProperty(proto));
/*      */   }
/*      */ 
/*      */   private static OnestoreEntity.Property buildImplicitKeyProperty(OnestoreEntity.EntityProto proto) {
/*  257 */     OnestoreEntity.Property keyProp = new OnestoreEntity.Property();
/*  258 */     keyProp.setName("__key__");
/*  259 */     OnestoreEntity.PropertyValue propVal = new OnestoreEntity.PropertyValue();
/*  260 */     ReferenceType.access$2100(propVal, proto.getKey());
/*  261 */     keyProp.setValue(propVal);
/*  262 */     return keyProp;
/*      */   }
/*      */ 
/*      */   public static Collection<OnestoreEntity.Property> findIndexedPropertiesOnPb(OnestoreEntity.EntityProto proto, String propertyName)
/*      */   {
/*  271 */     if (propertyName.equals("__key__")) {
/*  272 */       return Collections.singleton(buildImplicitKeyProperty(proto));
/*      */     }
/*  274 */     Collection multipleProps = new ArrayList();
/*  275 */     OnestoreEntity.Property singleProp = addPropertiesWithName(proto.propertys(), propertyName, multipleProps);
/*  276 */     if (singleProp != null) {
/*  277 */       return Collections.singleton(singleProp);
/*      */     }
/*  279 */     return multipleProps;
/*      */   }
/*      */ 
/*      */   private static OnestoreEntity.Property addPropertiesWithName(Iterable<OnestoreEntity.Property> props, String propName, Collection<OnestoreEntity.Property> matchingMultipleProps)
/*      */   {
/*  294 */     for (OnestoreEntity.Property prop : props) {
/*  295 */       if (prop.getName().equals(propName)) {
/*  296 */         if (!prop.isMultiple()) {
/*  297 */           return prop;
/*      */         }
/*  299 */         matchingMultipleProps.add(prop);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  304 */     return null;
/*      */   }
/*      */ 
/*      */   private static void addPropertyValueToMap(OnestoreEntity.Property property, Map<String, Object> map, boolean indexed)
/*      */   {
/*  309 */     String name = property.getName();
/*  310 */     Object value = getPropertyValue(property);
/*      */ 
/*  312 */     if (property.isMultiple())
/*      */     {
/*  314 */       List results = (List)Entity.unwrapValue(map.get(name));
/*  315 */       if (results == null) {
/*  316 */         results = new ArrayList();
/*  317 */         map.put(name, indexed ? results : new Entity.UnindexedValue(results));
/*      */       }
/*  319 */       results.add(value);
/*      */     } else {
/*  321 */       map.put(name, indexed ? value : new Entity.UnindexedValue(value));
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Object getPropertyValue(OnestoreEntity.Property property)
/*      */   {
/*  332 */     OnestoreEntity.PropertyValue value = property.getValue();
/*  333 */     for (Type type : typeMap.values()) {
/*  334 */       if ((type.hasPropertyValue(value)) && (type.getMeaning() == property.getMeaningEnum())) {
/*  335 */         return type.getPropertyValue(value);
/*      */       }
/*      */     }
/*  338 */     return null;
/*      */   }
/*      */ 
/*      */   public static Comparable<Object> getComparablePropertyValue(OnestoreEntity.Property property)
/*      */   {
/*  348 */     OnestoreEntity.PropertyValue value = property.getValue();
/*  349 */     for (Type type : typeMap.values())
/*      */     {
/*  354 */       if ((type.hasPropertyValue(value)) && (type.getMeaning() == property.getMeaningEnum()) && (type.getComparableFunction() != null))
/*      */       {
/*  357 */         return toComparableObject(type.getComparableFunction().asComparable(value));
/*      */       }
/*      */     }
/*      */ 
/*  361 */     return null;
/*      */   }
/*      */ 
/*      */   static Comparable<Object> getComparablePropertyValue(Object value)
/*      */   {
/*  373 */     Pair newValue = createPropertyValue(value);
/*  374 */     if (newValue.first != null) {
/*  375 */       return toComparableObject(((Type)newValue.first).getComparableFunction().asComparable((OnestoreEntity.PropertyValue)newValue.second));
/*      */     }
/*      */ 
/*  378 */     return null;
/*      */   }
/*      */ 
/*      */   private static <T> Comparable<Object> toComparableObject(Comparable<T> original)
/*      */   {
/*  386 */     return original;
/*      */   }
/*      */ 
/*      */   public static int getTypeRank(Class<? extends Comparable> datastoreType)
/*      */   {
/*  396 */     return ((Integer)comparableTypeMap.get(datastoreType)).intValue();
/*      */   }
/*      */ 
/*      */   static OnestoreEntity.Property toProperty(String propertyName, Object value)
/*      */   {
/*  404 */     return (OnestoreEntity.Property)createProperty(propertyName, value, false).second();
/*      */   }
/*      */ 
/*      */   private static <T> Type<T> getType(Class<T> clazz)
/*      */   {
/*  415 */     if (typeMap.containsKey(clazz)) {
/*  416 */       return (Type)typeMap.get(clazz);
/*      */     }
/*  418 */     throw new UnsupportedOperationException("Unsupported data type: " + clazz.getName());
/*      */   }
/*      */ 
/*      */   static Map<Class<?>, Type<?>> getTypeMap()
/*      */   {
/* 1160 */     return typeMap;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   42 */     STRING_TYPE = new StringType(null);
/*      */ 
/*   54 */     typeMap = new HashMap();
/*      */ 
/*   56 */     typeMap.put(String.class, STRING_TYPE);
/*   57 */     typeMap.put(Byte.class, new Int64Type(null));
/*   58 */     typeMap.put(Short.class, new Int64Type(null));
/*   59 */     typeMap.put(Integer.class, new Int64Type(null));
/*   60 */     typeMap.put(Long.class, new Int64Type(null));
/*   61 */     typeMap.put(Float.class, new DoubleType(null));
/*   62 */     typeMap.put(Double.class, new DoubleType(null));
/*   63 */     typeMap.put(Boolean.class, new BoolType(null));
/*   64 */     typeMap.put(User.class, new UserType(null));
/*   65 */     typeMap.put(Key.class, new ReferenceType(null));
/*   66 */     typeMap.put(Blob.class, new BlobType(null));
/*   67 */     typeMap.put(Text.class, new TextType(null));
/*   68 */     typeMap.put(Date.class, new DateType(null));
/*   69 */     typeMap.put(Link.class, new LinkType(null));
/*   70 */     typeMap.put(ShortBlob.class, new ShortBlobType(null));
/*   71 */     typeMap.put(GeoPt.class, new GeoPtType(null));
/*   72 */     typeMap.put(Category.class, new CategoryType(null));
/*   73 */     typeMap.put(Rating.class, new RatingType(null));
/*   74 */     typeMap.put(PhoneNumber.class, new PhoneNumberType(null));
/*   75 */     typeMap.put(PostalAddress.class, new PostalAddressType(null));
/*   76 */     typeMap.put(Email.class, new EmailType(null));
/*   77 */     typeMap.put(IMHandle.class, new IMHandleType(null));
/*   78 */     typeMap.put(BlobKey.class, new BlobKeyType(null));
/*      */ 
/*   82 */     assert (typeMap.keySet().equals(DataTypeUtils.getSupportedTypes())) : ("Warning:  DataTypeUtils and DataTypeTranslator do not agree about supported classes: " + typeMap.keySet() + " vs. " + DataTypeUtils.getSupportedTypes());
/*      */ 
/*   93 */     comparableTypeMap = new HashMap();
/*      */ 
/*   97 */     comparableTypeMap.put(ComparableByteArray.class, Integer.valueOf(3));
/*   98 */     comparableTypeMap.put(Long.class, Integer.valueOf(1));
/*   99 */     comparableTypeMap.put(Double.class, Integer.valueOf(4));
/*  100 */     comparableTypeMap.put(Boolean.class, Integer.valueOf(2));
/*  101 */     comparableTypeMap.put(User.class, Integer.valueOf(8));
/*  102 */     comparableTypeMap.put(Key.class, Integer.valueOf(12));
/*  103 */     comparableTypeMap.put(GeoPt.class, Integer.valueOf(5));
/*      */ 
/*  493 */     NOT_COMPARABLE = null;
/*      */ 
/*  499 */     COMP_BYTE_ARRAY_FUNC = new AsComparableFunction() {
/*      */       public Comparable<DataTypeTranslator.ComparableByteArray> asComparable(OnestoreEntity.PropertyValue pv) {
/*  501 */         return new DataTypeTranslator.ComparableByteArray(pv.getStringValueAsBytes());
/*      */       }
/*      */     };
/*  532 */     INT_64_COMP_FUNC = new AsComparableFunction() {
/*      */       public Comparable<Long> asComparable(OnestoreEntity.PropertyValue pv) {
/*  534 */         return Long.valueOf(pv.getInt64Value());
/*      */       }
/*      */     };
/*  567 */     DOUBLE_COMP_FUNC = new AsComparableFunction() {
/*      */       public Comparable<Double> asComparable(OnestoreEntity.PropertyValue pv) {
/*  569 */         return Double.valueOf(pv.getDoubleValue());
/*      */       }
/*      */     };
/*  602 */     BOOLEAN_COMP_FUNC = new AsComparableFunction() {
/*      */       public Comparable<Boolean> asComparable(OnestoreEntity.PropertyValue pv) {
/*  604 */         return Boolean.valueOf(pv.isBooleanValue());
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static final class ComparableByteArray
/*      */     implements Comparable<ComparableByteArray>
/*      */   {
/*      */     private final byte[] bytes;
/*      */ 
/*      */     public ComparableByteArray(byte[] bytes)
/*      */     {
/* 1172 */       this.bytes = bytes;
/*      */     }
/*      */ 
/*      */     public int compareTo(ComparableByteArray other)
/*      */     {
/* 1178 */       byte[] otherBytes = other.bytes;
/* 1179 */       for (int i = 0; i < Math.min(this.bytes.length, otherBytes.length); i++) {
/* 1180 */         int v1 = this.bytes[i] & 0xFF;
/* 1181 */         int v2 = otherBytes[i] & 0xFF;
/* 1182 */         if (v1 != v2) {
/* 1183 */           return v1 - v2;
/*      */         }
/*      */       }
/* 1186 */       return this.bytes.length - otherBytes.length;
/*      */     }
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/* 1191 */       if (obj == null) {
/* 1192 */         return false;
/*      */       }
/* 1194 */       return Arrays.equals(this.bytes, ((ComparableByteArray)obj).bytes);
/*      */     }
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1199 */       int result = 1;
/* 1200 */       for (byte b : this.bytes) {
/* 1201 */         result = 31 * result + b;
/*      */       }
/* 1203 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class Pair<T, U>
/*      */   {
/*      */     private final T first;
/*      */     private final U second;
/*      */ 
/*      */     Pair(T t, U u)
/*      */     {
/* 1141 */       this.first = t;
/* 1142 */       this.second = u;
/*      */     }
/*      */ 
/*      */     T first() {
/* 1146 */       return this.first;
/*      */     }
/*      */ 
/*      */     U second() {
/* 1150 */       return this.second;
/*      */     }
/*      */ 
/*      */     public static <T, U> Pair<T, U> of(T t, U u) {
/* 1154 */       return new Pair(t, u);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class GeoPtType extends DataTypeTranslator.Type<GeoPt>
/*      */   {
/* 1102 */     private final DataTypeTranslator.AsComparableFunction POINT_VALUE_COMP_FUNC = new DataTypeTranslator.AsComparableFunction() {
/*      */       public Comparable<GeoPt> asComparable(OnestoreEntity.PropertyValue pv) {
/* 1104 */         return DataTypeTranslator.GeoPtType.this.getPropertyValue(pv);
/*      */       }
/* 1102 */     };
/*      */ 
/*      */     private GeoPtType()
/*      */     {
/* 1095 */       super();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/* 1110 */       return this.POINT_VALUE_COMP_FUNC;
/*      */     }
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/* 1115 */       GeoPt geoPt = (GeoPt)value;
/* 1116 */       OnestoreEntity.PropertyValue.PointValue pv = new OnestoreEntity.PropertyValue.PointValue().setX(geoPt.getLatitude()).setY(geoPt.getLongitude());
/*      */ 
/* 1118 */       propertyValue.setPointValue(pv);
/*      */     }
/*      */ 
/*      */     public GeoPt getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/* 1123 */       OnestoreEntity.PropertyValue.PointValue pv = propertyValue.getPointValue();
/* 1124 */       return new GeoPt((float)pv.getX(), (float)pv.getY());
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/* 1129 */       return propertyValue.hasPointValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class IMHandleType extends DataTypeTranslator.CustomStringType<IMHandle>
/*      */   {
/*      */     private IMHandleType()
/*      */     {
/* 1078 */       super(null);
/*      */     }
/*      */ 
/*      */     protected String asDatastoreString(Object value)
/*      */     {
/* 1083 */       return ((IMHandle)value).toDatastoreString();
/*      */     }
/*      */ 
/*      */     protected IMHandle fromDatastoreString(String datastoreString)
/*      */     {
/* 1088 */       return IMHandle.fromDatastoreString(datastoreString);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class PhoneNumberType extends DataTypeTranslator.CustomStringType<PhoneNumber>
/*      */   {
/*      */     private PhoneNumberType()
/*      */     {
/* 1057 */       super(null);
/*      */     }
/*      */ 
/*      */     protected String asDatastoreString(Object value)
/*      */     {
/* 1062 */       return ((PhoneNumber)value).getNumber();
/*      */     }
/*      */ 
/*      */     protected PhoneNumber fromDatastoreString(String datastoreString)
/*      */     {
/* 1067 */       return new PhoneNumber(datastoreString);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class PostalAddressType extends DataTypeTranslator.CustomStringType<PostalAddress>
/*      */   {
/*      */     private PostalAddressType()
/*      */     {
/* 1038 */       super(null);
/*      */     }
/*      */ 
/*      */     protected String asDatastoreString(Object value)
/*      */     {
/* 1043 */       return ((PostalAddress)value).getAddress();
/*      */     }
/*      */ 
/*      */     protected PostalAddress fromDatastoreString(String datastoreString)
/*      */     {
/* 1048 */       return new PostalAddress(datastoreString);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class EmailType extends DataTypeTranslator.CustomStringType<Email>
/*      */   {
/*      */     private EmailType()
/*      */     {
/* 1019 */       super(null);
/*      */     }
/*      */ 
/*      */     protected String asDatastoreString(Object value)
/*      */     {
/* 1024 */       return ((Email)value).getEmail();
/*      */     }
/*      */ 
/*      */     protected Email fromDatastoreString(String datastoreString)
/*      */     {
/* 1029 */       return new Email(datastoreString);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class RatingType extends DataTypeTranslator.CustomInt64Type<Rating>
/*      */   {
/*      */     private RatingType()
/*      */     {
/*  997 */       super(null);
/*      */     }
/*      */ 
/*      */     protected Long asDatastoreLong(Object value)
/*      */     {
/* 1002 */       return Long.valueOf(((Rating)value).getRating());
/*      */     }
/*      */ 
/*      */     protected Rating fromDatastoreLong(Long datastoreLong)
/*      */     {
/* 1007 */       if (datastoreLong == null) {
/* 1008 */         throw new NullPointerException("rating value cannot be null");
/*      */       }
/* 1010 */       return new Rating(datastoreLong.intValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CategoryType extends DataTypeTranslator.CustomStringType<Category>
/*      */   {
/*      */     private CategoryType()
/*      */     {
/*  977 */       super(null);
/*      */     }
/*      */ 
/*      */     protected String asDatastoreString(Object value)
/*      */     {
/*  982 */       return ((Category)value).getCategory();
/*      */     }
/*      */ 
/*      */     protected Category fromDatastoreString(String datastoreString)
/*      */     {
/*  987 */       return new Category(datastoreString);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract class CustomInt64Type<T> extends DataTypeTranslator.Type<T>
/*      */   {
/*  942 */     private static final DataTypeTranslator.Int64Type INT64_TYPE = new DataTypeTranslator.Int64Type(null);
/*      */ 
/*      */     private CustomInt64Type(OnestoreEntity.Property.Meaning meaning) {
/*  945 */       super();
/*      */     }
/*      */ 
/*      */     public final void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  950 */       INT64_TYPE.setPropertyValue(propertyValue, asDatastoreLong(value));
/*      */     }
/*      */ 
/*      */     public final T getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  955 */       return fromDatastoreLong(INT64_TYPE.getPropertyValue(propertyValue));
/*      */     }
/*      */ 
/*      */     public final DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  960 */       return INT64_TYPE.getComparableFunction();
/*      */     }
/*      */ 
/*      */     public final boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  965 */       return INT64_TYPE.hasPropertyValue(propertyValue);
/*      */     }
/*      */ 
/*      */     protected abstract Long asDatastoreLong(Object paramObject);
/*      */ 
/*      */     protected abstract T fromDatastoreLong(Long paramLong);
/*      */   }
/*      */ 
/*      */   private static abstract class CustomStringType<T> extends DataTypeTranslator.Type<T>
/*      */   {
/*      */     private CustomStringType(OnestoreEntity.Property.Meaning meaning)
/*      */     {
/*  907 */       super();
/*      */     }
/*      */ 
/*      */     public final void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  912 */       DataTypeTranslator.STRING_TYPE.setPropertyValue(propertyValue, asDatastoreString(value));
/*      */     }
/*      */ 
/*      */     public final T getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  917 */       return fromDatastoreString(DataTypeTranslator.STRING_TYPE.getPropertyValue(propertyValue));
/*      */     }
/*      */ 
/*      */     public final DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  922 */       return DataTypeTranslator.STRING_TYPE.getComparableFunction();
/*      */     }
/*      */ 
/*      */     public final boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  927 */       return DataTypeTranslator.STRING_TYPE.hasPropertyValue(propertyValue);
/*      */     }
/*      */ 
/*      */     protected abstract String asDatastoreString(Object paramObject);
/*      */ 
/*      */     protected abstract T fromDatastoreString(String paramString);
/*      */   }
/*      */ 
/*      */   private static class ShortBlobType extends DataTypeTranslator.Type<ShortBlob>
/*      */   {
/*      */     private ShortBlobType()
/*      */     {
/*  874 */       super();
/*      */     }
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  879 */       propertyValue.setStringValueAsBytes(((ShortBlob)value).getBytes());
/*      */     }
/*      */ 
/*      */     public ShortBlob getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  884 */       return new ShortBlob(propertyValue.getStringValueAsBytes());
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  889 */       return DataTypeTranslator.COMP_BYTE_ARRAY_FUNC;
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  894 */       return propertyValue.hasStringValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class LinkType extends DataTypeTranslator.Type<Link>
/*      */   {
/*      */     private LinkType()
/*      */     {
/*  847 */       super();
/*      */     }
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  852 */       Link link = (Link)value;
/*  853 */       propertyValue.setStringValue(link.getValue());
/*      */     }
/*      */ 
/*      */     public Link getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  858 */       return new Link(propertyValue.getStringValue());
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  863 */       return DataTypeTranslator.COMP_BYTE_ARRAY_FUNC;
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  868 */       return propertyValue.hasStringValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class DateType extends DataTypeTranslator.Type<Date>
/*      */   {
/*      */     private DateType()
/*      */     {
/*  818 */       super();
/*      */     }
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  823 */       Date date = (Date)value;
/*      */ 
/*  825 */       propertyValue.setInt64Value(date.getTime() * 1000L);
/*      */     }
/*      */ 
/*      */     public Date getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  831 */       return new Date(propertyValue.getInt64Value() / 1000L);
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  836 */       return DataTypeTranslator.INT_64_COMP_FUNC;
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  841 */       return propertyValue.hasInt64Value();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BlobKeyType extends DataTypeTranslator.CustomStringType<BlobKey>
/*      */   {
/*      */     private BlobKeyType()
/*      */     {
/*  802 */       super(null);
/*      */     }
/*      */ 
/*      */     protected String asDatastoreString(Object value)
/*      */     {
/*  807 */       return ((BlobKey)value).getKeyString();
/*      */     }
/*      */ 
/*      */     protected BlobKey fromDatastoreString(String datastoreString)
/*      */     {
/*  812 */       return new BlobKey(datastoreString);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class TextType extends DataTypeTranslator.Type<Text>
/*      */   {
/*      */     private TextType()
/*      */     {
/*  775 */       super();
/*      */     }
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  780 */       Text text = (Text)value;
/*  781 */       propertyValue.setStringValue(text.getValue());
/*      */     }
/*      */ 
/*      */     public Text getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  786 */       return new Text(propertyValue.getStringValue());
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  791 */       return propertyValue.hasStringValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  796 */       return DataTypeTranslator.NOT_COMPARABLE;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BlobType extends DataTypeTranslator.Type<Blob>
/*      */   {
/*      */     private BlobType()
/*      */     {
/*  747 */       super();
/*      */     }
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  752 */       Blob blob = (Blob)value;
/*  753 */       propertyValue.setStringValueAsBytes(blob.getBytes());
/*      */     }
/*      */ 
/*      */     public Blob getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  758 */       byte[] bytes = propertyValue.getStringValueAsBytes();
/*  759 */       return new Blob(bytes);
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  764 */       return propertyValue.hasStringValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  769 */       return DataTypeTranslator.NOT_COMPARABLE;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ReferenceType extends DataTypeTranslator.Type<Key>
/*      */   {
/*  672 */     private final DataTypeTranslator.AsComparableFunction COMP_FUNC = new DataTypeTranslator.AsComparableFunction() {
/*      */       public Comparable<Key> asComparable(OnestoreEntity.PropertyValue pv) {
/*  674 */         return DataTypeTranslator.ReferenceType.this.getPropertyValue(pv);
/*      */       }
/*  672 */     };
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  680 */       OnestoreEntity.Reference keyRef = KeyTranslator.convertToPb((Key)value);
/*  681 */       setPropertyValue(propertyValue, keyRef);
/*      */     }
/*      */ 
/*      */     private static void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, OnestoreEntity.Reference keyRef) {
/*  685 */       OnestoreEntity.PropertyValue.ReferenceValue refValue = new OnestoreEntity.PropertyValue.ReferenceValue();
/*  686 */       refValue.setApp(keyRef.getApp());
/*  687 */       if (keyRef.hasNameSpace()) {
/*  688 */         refValue.setNameSpace(keyRef.getNameSpace());
/*      */       }
/*  690 */       OnestoreEntity.Path path = keyRef.getPath();
/*  691 */       for (OnestoreEntity.Path.Element element : path.elements()) {
/*  692 */         OnestoreEntity.PropertyValue.ReferenceValuePathElement newElement = new OnestoreEntity.PropertyValue.ReferenceValuePathElement();
/*  693 */         newElement.setType(element.getType());
/*  694 */         if (element.hasName()) {
/*  695 */           newElement.setName(element.getName());
/*      */         }
/*  697 */         if (element.hasId()) {
/*  698 */           newElement.setId(element.getId());
/*      */         }
/*  700 */         refValue.addPathElement(newElement);
/*      */       }
/*      */ 
/*  703 */       propertyValue.setReferenceValue(refValue);
/*      */     }
/*      */ 
/*      */     public Key getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  711 */       OnestoreEntity.Reference reference = new OnestoreEntity.Reference();
/*  712 */       OnestoreEntity.PropertyValue.ReferenceValue refValue = propertyValue.getReferenceValue();
/*  713 */       reference.setApp(refValue.getApp());
/*  714 */       if (refValue.hasNameSpace()) {
/*  715 */         reference.setNameSpace(refValue.getNameSpace());
/*      */       }
/*  717 */       OnestoreEntity.Path path = new OnestoreEntity.Path();
/*  718 */       for (OnestoreEntity.PropertyValue.ReferenceValuePathElement element : refValue.pathElements()) {
/*  719 */         OnestoreEntity.Path.Element newElement = new OnestoreEntity.Path.Element();
/*  720 */         newElement.setType(element.getType());
/*  721 */         if (element.hasName()) {
/*  722 */           newElement.setName(element.getName());
/*      */         }
/*  724 */         if (element.hasId()) {
/*  725 */           newElement.setId(element.getId());
/*      */         }
/*  727 */         path.addElement(newElement);
/*      */       }
/*  729 */       reference.setPath(path);
/*      */ 
/*  731 */       return KeyTranslator.createFromPb(reference);
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  736 */       return propertyValue.hasReferenceValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  741 */       return this.COMP_FUNC;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UserType extends DataTypeTranslator.Type<User>
/*      */   {
/*  635 */     private final DataTypeTranslator.AsComparableFunction USER_COMP_FUNC = new DataTypeTranslator.AsComparableFunction() {
/*      */       public Comparable<User> asComparable(OnestoreEntity.PropertyValue pv) {
/*  637 */         return DataTypeTranslator.UserType.this.getPropertyValue(pv);
/*      */       }
/*  635 */     };
/*      */ 
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  643 */       User user = (User)value;
/*  644 */       OnestoreEntity.PropertyValue.UserValue userValue = new OnestoreEntity.PropertyValue.UserValue();
/*  645 */       userValue.setEmail(user.getEmail());
/*  646 */       userValue.setAuthDomain(user.getAuthDomain());
/*      */ 
/*  649 */       userValue.setGaiaid(0L);
/*  650 */       propertyValue.setUserValue(userValue);
/*      */     }
/*      */ 
/*      */     public User getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  655 */       OnestoreEntity.PropertyValue.UserValue userValue = propertyValue.getUserValue();
/*  656 */       String userId = userValue.hasObfuscatedGaiaid() ? userValue.getObfuscatedGaiaid() : null;
/*  657 */       return new User(userValue.getEmail(), userValue.getAuthDomain(), userId);
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  662 */       return propertyValue.hasUserValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  667 */       return this.USER_COMP_FUNC;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BoolType extends DataTypeTranslator.Type<Boolean>
/*      */   {
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  612 */       if (value != null)
/*  613 */         propertyValue.setBooleanValue(((Boolean)value).booleanValue());
/*      */     }
/*      */ 
/*      */     public Boolean getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  619 */       return Boolean.valueOf(propertyValue.isBooleanValue());
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  624 */       return propertyValue.hasBooleanValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  629 */       return DataTypeTranslator.BOOLEAN_COMP_FUNC;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class DoubleType extends DataTypeTranslator.Type<Double>
/*      */   {
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  577 */       if (value != null)
/*  578 */         propertyValue.setDoubleValue(((Number)value).doubleValue());
/*      */     }
/*      */ 
/*      */     public Double getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  584 */       return propertyValue.hasDoubleValue() ? Double.valueOf(propertyValue.getDoubleValue()) : null;
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  589 */       return propertyValue.hasDoubleValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  594 */       return DataTypeTranslator.DOUBLE_COMP_FUNC;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class Int64Type extends DataTypeTranslator.Type<Long>
/*      */   {
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  542 */       if (value != null)
/*  543 */         propertyValue.setInt64Value(((Number)value).longValue());
/*      */     }
/*      */ 
/*      */     public Long getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  549 */       return Long.valueOf(propertyValue.getInt64Value());
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  554 */       return propertyValue.hasInt64Value();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  559 */       return DataTypeTranslator.INT_64_COMP_FUNC;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class StringType extends DataTypeTranslator.Type<String>
/*      */   {
/*      */     public void setPropertyValue(OnestoreEntity.PropertyValue propertyValue, Object value)
/*      */     {
/*  509 */       propertyValue.setStringValue((String)value);
/*      */     }
/*      */ 
/*      */     public String getPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  514 */       return propertyValue.getStringValue();
/*      */     }
/*      */ 
/*      */     public boolean hasPropertyValue(OnestoreEntity.PropertyValue propertyValue)
/*      */     {
/*  519 */       return propertyValue.hasStringValue();
/*      */     }
/*      */ 
/*      */     public DataTypeTranslator.AsComparableFunction getComparableFunction()
/*      */     {
/*  524 */       return DataTypeTranslator.COMP_BYTE_ARRAY_FUNC;
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract class Type<T>
/*      */   {
/*      */     private final OnestoreEntity.Property.Meaning meaning;
/*      */ 
/*      */     protected Type(OnestoreEntity.Property.Meaning meaning)
/*      */     {
/*  441 */       this.meaning = meaning;
/*      */     }
/*      */ 
/*      */     protected Type() {
/*  445 */       this(null);
/*      */     }
/*      */ 
/*      */     public abstract DataTypeTranslator.AsComparableFunction getComparableFunction();
/*      */ 
/*      */     public OnestoreEntity.Property.Meaning getMeaning()
/*      */     {
/*  460 */       return this.meaning;
/*      */     }
/*      */ 
/*      */     public abstract void setPropertyValue(OnestoreEntity.PropertyValue paramPropertyValue, Object paramObject);
/*      */ 
/*      */     public abstract T getPropertyValue(OnestoreEntity.PropertyValue paramPropertyValue);
/*      */ 
/*      */     public abstract boolean hasPropertyValue(OnestoreEntity.PropertyValue paramPropertyValue);
/*      */   }
/*      */ 
/*      */   private static abstract interface AsComparableFunction
/*      */   {
/*      */     public abstract Comparable<?> asComparable(OnestoreEntity.PropertyValue paramPropertyValue);
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DataTypeTranslator
 * JD-Core Version:    0.6.0
 */