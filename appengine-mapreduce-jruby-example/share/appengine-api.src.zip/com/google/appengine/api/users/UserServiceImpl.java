/*     */ package com.google.appengine.api.users;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import com.google.apphosting.api.ApiProxy.Environment;
/*     */ import com.google.apphosting.api.UserServicePb.CreateLoginURLRequest;
/*     */ import com.google.apphosting.api.UserServicePb.CreateLoginURLResponse;
/*     */ import com.google.apphosting.api.UserServicePb.CreateLogoutURLRequest;
/*     */ import com.google.apphosting.api.UserServicePb.CreateLogoutURLResponse;
/*     */ import com.google.apphosting.api.UserServicePb.UserServiceError.ErrorCode;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ final class UserServiceImpl
/*     */   implements UserService
/*     */ {
/*     */   static final String USER_ID_KEY = "com.google.appengine.api.users.UserService.user_id_key";
/*     */   static final String FEDERATED_IDENTITY_KEY = "com.google.appengine.api.users.UserService.federated_identity";
/*     */   static final String FEDERATED_AUTHORITY_KEY = "com.google.appengine.api.users.UserService.federated_authority";
/*     */   static final String IS_FEDERATED_USER_KEY = "com.google.appengine.api.users.UserService.is_federated_user";
/*     */   private static final String PACKAGE = "user";
/*     */   private static final String LOGIN_URL_METHOD = "CreateLoginURL";
/*     */   private static final String LOGOUT_URL_METHOD = "CreateLogoutURL";
/*     */ 
/*     */   public String createLoginURL(String destinationURL)
/*     */   {
/*  42 */     return createLoginURL(destinationURL, null, null, null);
/*     */   }
/*     */ 
/*     */   public String createLoginURL(String destinationURL, String authDomain)
/*     */   {
/*  47 */     return createLoginURL(destinationURL, authDomain, null, null);
/*     */   }
/*     */ 
/*     */   public String createLoginURL(String destinationURL, String authDomain, String federatedIdentity, Set<String> attributesRequest)
/*     */   {
/*  54 */     UserServicePb.CreateLoginURLRequest request = new UserServicePb.CreateLoginURLRequest();
/*  55 */     request.setDestinationUrl(destinationURL);
/*  56 */     if (authDomain != null) {
/*  57 */       request.setAuthDomain(authDomain);
/*     */     }
/*  59 */     if (federatedIdentity != null) {
/*  60 */       request.setFederatedIdentity(federatedIdentity);
/*     */     }
/*  62 */     byte[] responseBytes = makeSyncCall("CreateLoginURL", request, destinationURL);
/*     */ 
/*  64 */     UserServicePb.CreateLoginURLResponse response = new UserServicePb.CreateLoginURLResponse();
/*  65 */     response.mergeFrom(responseBytes);
/*  66 */     return response.getLoginUrl();
/*     */   }
/*     */ 
/*     */   public String createLogoutURL(String destinationURL) {
/*  70 */     return createLogoutURL(destinationURL, null);
/*     */   }
/*     */ 
/*     */   public String createLogoutURL(String destinationURL, String authDomain)
/*     */   {
/*  75 */     UserServicePb.CreateLogoutURLRequest request = new UserServicePb.CreateLogoutURLRequest();
/*  76 */     request.setDestinationUrl(destinationURL);
/*  77 */     if (authDomain != null) {
/*  78 */       request.setAuthDomain(authDomain);
/*     */     }
/*  80 */     byte[] responseBytes = makeSyncCall("CreateLogoutURL", request, destinationURL);
/*     */ 
/*  82 */     UserServicePb.CreateLogoutURLResponse response = new UserServicePb.CreateLogoutURLResponse();
/*  83 */     response.mergeFrom(responseBytes);
/*  84 */     return response.getLogoutUrl();
/*     */   }
/*     */ 
/*     */   public boolean isUserLoggedIn() {
/*  88 */     ApiProxy.Environment environment = ApiProxy.getCurrentEnvironment();
/*  89 */     return environment.isLoggedIn();
/*     */   }
/*     */ 
/*     */   public boolean isUserAdmin() {
/*  93 */     if (isUserLoggedIn()) {
/*  94 */       return ApiProxy.getCurrentEnvironment().isAdmin();
/*     */     }
/*  96 */     throw new IllegalStateException("The current user is not logged in.");
/*     */   }
/*     */ 
/*     */   public User getCurrentUser()
/*     */   {
/* 101 */     ApiProxy.Environment environment = ApiProxy.getCurrentEnvironment();
/* 102 */     if (!environment.isLoggedIn()) {
/* 103 */       return null;
/*     */     }
/* 105 */     String userId = (String)environment.getAttributes().get("com.google.appengine.api.users.UserService.user_id_key");
/* 106 */     Boolean isFederated = (Boolean)environment.getAttributes().get("com.google.appengine.api.users.UserService.is_federated_user");
/* 107 */     if ((isFederated == null) || (!isFederated.booleanValue())) {
/* 108 */       return new User(environment.getEmail(), environment.getAuthDomain(), userId);
/*     */     }
/* 110 */     return new User(environment.getEmail(), (String)environment.getAttributes().get("com.google.appengine.api.users.UserService.federated_authority"), userId, (String)environment.getAttributes().get("com.google.appengine.api.users.UserService.federated_identity"));
/*     */   }
/*     */ 
/*     */   private byte[] makeSyncCall(String methodName, ProtocolMessage request, String destinationURL)
/*     */   {
/*     */     byte[] responseBytes;
/*     */     try
/*     */     {
/* 122 */       byte[] requestBytes = request.toByteArray();
/* 123 */       responseBytes = ApiProxy.makeSyncCall("user", methodName, requestBytes);
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 125 */       UserServicePb.UserServiceError.ErrorCode errorCode = UserServicePb.UserServiceError.ErrorCode.valueOf(ex.getApplicationError());
/*     */ 
/* 127 */       switch (1.$SwitchMap$com$google$apphosting$api$UserServicePb$UserServiceError$ErrorCode[errorCode.ordinal()]) {
/*     */       case 1:
/* 129 */         throw new IllegalArgumentException("URL too long: " + destinationURL);
/*     */       case 2:
/*     */       }
/* 131 */     }throw new IllegalArgumentException("The requested URL was not allowed: " + destinationURL);
/*     */ 
/* 138 */     throw new UserServiceFailureException(ex.getErrorDetail());
/*     */ 
/* 142 */     return responseBytes;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.users.UserServiceImpl
 * JD-Core Version:    0.6.0
 */