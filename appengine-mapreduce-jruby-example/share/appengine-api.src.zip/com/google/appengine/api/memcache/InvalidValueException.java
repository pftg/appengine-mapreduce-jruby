/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ public class InvalidValueException extends RuntimeException
/*    */ {
/*    */   public InvalidValueException(String message, Throwable t)
/*    */   {
/* 16 */     super(message, t);
/*    */   }
/*    */ 
/*    */   public InvalidValueException(String message) {
/* 20 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.InvalidValueException
 * JD-Core Version:    0.6.0
 */