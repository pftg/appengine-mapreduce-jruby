/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ @Deprecated
/*     */ @GoogleInternal
/*     */ public final class Log2
/*     */ {
/*  52 */   private static Logger defaultLog = null;
/*  53 */   private static Logger systemErrLog = null;
/*     */ 
/*  58 */   public static boolean useJavaLogging = false;
/*     */   public static final String LOG2_USE_JAVA_LOG_PROP = "google.log2UseJavaLog";
/*     */ 
/*     */   @Deprecated
/*     */   public static void setDefaultLog(Logger log)
/*     */   {
/*  95 */     synchronized (Log2.class) {
/*  96 */       if ((defaultLog != null) && (defaultLog != systemErrLog)) {
/*  97 */         defaultLog.close();
/*     */       }
/*  99 */       if (log != null)
/* 100 */         defaultLog = log;
/*     */       else
/* 102 */         defaultLog = systemErrLog;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static Logger getDefaultLog()
/*     */   {
/* 113 */     return defaultLog;
/*     */   }
/*     */ 
/*     */   public static void setThreshold(int level)
/*     */   {
/* 126 */     defaultLog.setThreshold(level);
/*     */   }
/*     */ 
/*     */   public static int getThreshold()
/*     */   {
/* 134 */     return defaultLog.getThreshold();
/*     */   }
/*     */ 
/*     */   public static void logDebug(String msg)
/*     */   {
/* 142 */     defaultLog.logDebug(msg);
/*     */   }
/*     */ 
/*     */   public static void logEvent(String msg)
/*     */   {
/* 150 */     defaultLog.logEvent(msg);
/*     */   }
/*     */ 
/*     */   public static void setErrorEmail(String emailAddr)
/*     */   {
/* 158 */     defaultLog.setErrorEmail(emailAddr);
/*     */   }
/*     */ 
/*     */   public static void logException(Throwable t)
/*     */   {
/* 166 */     defaultLog.logException(t);
/*     */   }
/*     */ 
/*     */   public static void logException(Throwable t, String msg)
/*     */   {
/* 174 */     defaultLog.logException(t, msg);
/*     */   }
/*     */ 
/*     */   public static void logSevereException(Throwable t, String msg) {
/* 178 */     defaultLog.logSevereException(t, msg);
/*     */   }
/*     */ 
/*     */   public static void logError(String msg)
/*     */   {
/* 186 */     defaultLog.logError(msg);
/*     */   }
/*     */ 
/*     */   public static void setThreadTag(String s)
/*     */   {
/* 195 */     defaultLog.setThreadTag(s);
/*     */   }
/*     */ 
/*     */   public static String getExceptionTrace(Throwable t)
/*     */   {
/* 202 */     StringWriter sw = new StringWriter();
/* 203 */     PrintWriter pw = new PrintWriter(sw);
/* 204 */     if ((t instanceof SQLException)) {
/* 205 */       SQLException sqlx = (SQLException)t;
/*     */       while (true) {
/* 207 */         pw.println("SQLException: errorCode=" + sqlx.getErrorCode() + " sqlState=" + sqlx.getSQLState());
/*     */ 
/* 209 */         sqlx.printStackTrace(pw);
/*     */ 
/* 211 */         sqlx = sqlx.getNextException();
/* 212 */         if (sqlx == null)
/*     */           break;
/* 214 */         pw.println("chained to:");
/*     */       }
/*     */     } else {
/* 217 */       t.printStackTrace(pw);
/*     */     }
/*     */ 
/* 220 */     return sw.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  66 */     useJavaLogging = Boolean.getBoolean("google.log2UseJavaLog");
/*  67 */     if (useJavaLogging) {
/*  68 */       systemErrLog = new Log2Logger();
/*  69 */       defaultLog = systemErrLog;
/*     */     }
/*     */ 
/*  72 */     if (defaultLog == null)
/*     */       try {
/*  74 */         BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.err));
/*     */ 
/*  76 */         systemErrLog = new LogWriter(bw);
/*  77 */         defaultLog = systemErrLog;
/*     */       } catch (Throwable t) {
/*  79 */         throw new RuntimeException("Log2: could not initialize  LogWriter object!");
/*     */       }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Log2
 * JD-Core Version:    0.6.0
 */