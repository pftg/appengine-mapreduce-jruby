/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ @GwtCompatible
/*     */ public abstract class Ordering<T>
/*     */   implements Comparator<T>
/*     */ {
/*     */   static final int LEFT_IS_GREATER = 1;
/*     */   static final int RIGHT_IS_GREATER = -1;
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <C extends Comparable> Ordering<C> natural()
/*     */   {
/*  77 */     return NaturalOrdering.INSTANCE;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Ordering<T> from(Comparator<T> comparator)
/*     */   {
/*  90 */     return (comparator instanceof Ordering) ? (Ordering)comparator : new ComparatorOrdering(comparator);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Ordering<T> from(Ordering<T> ordering)
/*     */   {
/* 102 */     return (Ordering)Preconditions.checkNotNull(ordering);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Ordering<T> explicit(List<T> valuesInOrder)
/*     */   {
/* 128 */     return new ExplicitOrdering(valuesInOrder);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Ordering<T> explicit(T leastValue, T[] remainingValuesInOrder)
/*     */   {
/* 157 */     return explicit(Lists.asList(leastValue, remainingValuesInOrder));
/*     */   }
/*     */ 
/*     */   public static Ordering<Object> arbitrary()
/*     */   {
/* 197 */     return ArbitraryOrderingHolder.ARBITRARY_ORDERING;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static Ordering<Object> usingToString()
/*     */   {
/* 258 */     return UsingToStringOrdering.INSTANCE;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Ordering<T> compound(Iterable<? extends Comparator<? super T>> comparators)
/*     */   {
/* 279 */     return new CompoundOrdering(comparators);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public <U extends T> Ordering<U> compound(Comparator<? super U> secondaryComparator)
/*     */   {
/* 304 */     return new CompoundOrdering(this, (Comparator)Preconditions.checkNotNull(secondaryComparator));
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public <S extends T> Ordering<S> reverse()
/*     */   {
/* 315 */     return new ReverseOrdering(this);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public <F> Ordering<F> onResultOf(Function<F, ? extends T> function)
/*     */   {
/* 329 */     return new ByFunctionOrdering(function, this);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public <S extends T> Ordering<Iterable<S>> lexicographical()
/*     */   {
/* 358 */     return new LexicographicalOrdering(this);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public <S extends T> Ordering<S> nullsFirst()
/*     */   {
/* 369 */     return new NullsFirstOrdering(this);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public <S extends T> Ordering<S> nullsLast()
/*     */   {
/* 380 */     return new NullsLastOrdering(this);
/*     */   }
/*     */ 
/*     */   public int binarySearch(List<? extends T> sortedList, T key)
/*     */   {
/* 394 */     return Collections.binarySearch(sortedList, key, this);
/*     */   }
/*     */ 
/*     */   public <E extends T> List<E> sortedCopy(Iterable<E> iterable)
/*     */   {
/* 411 */     List list = Lists.newArrayList(iterable);
/* 412 */     Collections.sort(list, this);
/* 413 */     return list;
/*     */   }
/*     */ 
/*     */   public <E extends T> ImmutableList<E> immutableSortedCopy(Iterable<E> iterable)
/*     */   {
/* 433 */     return ImmutableList.copyOf(sortedCopy(iterable));
/*     */   }
/*     */ 
/*     */   public boolean isOrdered(Iterable<? extends T> iterable)
/*     */   {
/* 443 */     Iterator it = iterable.iterator();
/* 444 */     if (it.hasNext()) {
/* 445 */       Object prev = it.next();
/* 446 */       while (it.hasNext()) {
/* 447 */         Object next = it.next();
/* 448 */         if (compare(prev, next) > 0) {
/* 449 */           return false;
/*     */         }
/* 451 */         prev = next;
/*     */       }
/*     */     }
/* 454 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isStrictlyOrdered(Iterable<? extends T> iterable)
/*     */   {
/* 464 */     Iterator it = iterable.iterator();
/* 465 */     if (it.hasNext()) {
/* 466 */       Object prev = it.next();
/* 467 */       while (it.hasNext()) {
/* 468 */         Object next = it.next();
/* 469 */         if (compare(prev, next) >= 0) {
/* 470 */           return false;
/*     */         }
/* 472 */         prev = next;
/*     */       }
/*     */     }
/* 475 */     return true;
/*     */   }
/*     */ 
/*     */   public <E extends T> E max(Iterable<E> iterable)
/*     */   {
/* 488 */     Iterator iterator = iterable.iterator();
/*     */ 
/* 491 */     Object maxSoFar = iterator.next();
/*     */ 
/* 493 */     while (iterator.hasNext()) {
/* 494 */       maxSoFar = max(maxSoFar, iterator.next());
/*     */     }
/*     */ 
/* 497 */     return maxSoFar;
/*     */   }
/*     */ 
/*     */   public <E extends T> E max(E a, E b, E c, E[] rest)
/*     */   {
/* 512 */     Object maxSoFar = max(max(a, b), c);
/*     */ 
/* 514 */     for (Object r : rest) {
/* 515 */       maxSoFar = max(maxSoFar, r);
/*     */     }
/*     */ 
/* 518 */     return maxSoFar;
/*     */   }
/*     */ 
/*     */   public <E extends T> E max(E a, E b)
/*     */   {
/* 535 */     return compare(a, b) >= 0 ? a : b;
/*     */   }
/*     */ 
/*     */   public <E extends T> E min(Iterable<E> iterable)
/*     */   {
/* 548 */     Iterator iterator = iterable.iterator();
/*     */ 
/* 551 */     Object minSoFar = iterator.next();
/*     */ 
/* 553 */     while (iterator.hasNext()) {
/* 554 */       minSoFar = min(minSoFar, iterator.next());
/*     */     }
/*     */ 
/* 557 */     return minSoFar;
/*     */   }
/*     */ 
/*     */   public <E extends T> E min(E a, E b, E c, E[] rest)
/*     */   {
/* 572 */     Object minSoFar = min(min(a, b), c);
/*     */ 
/* 574 */     for (Object r : rest) {
/* 575 */       minSoFar = min(minSoFar, r);
/*     */     }
/*     */ 
/* 578 */     return minSoFar;
/*     */   }
/*     */ 
/*     */   public <E extends T> E min(E a, E b)
/*     */   {
/* 595 */     return compare(a, b) <= 0 ? a : b;
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static class ArbitraryOrdering extends Ordering<Object>
/*     */   {
/* 205 */     private Map<Object, Integer> uids = Platform.tryWeakKeys(new MapMaker()).makeComputingMap(new Function()
/*     */     {
/* 208 */       final AtomicInteger counter = new AtomicInteger(0);
/*     */ 
/* 210 */       public Integer apply(Object from) { return Integer.valueOf(this.counter.getAndIncrement());
/*     */       }
/*     */     });
/*     */ 
/*     */     public int compare(Object left, Object right)
/*     */     {
/* 215 */       if (left == right) {
/* 216 */         return 0;
/*     */       }
/* 218 */       int leftCode = identityHashCode(left);
/* 219 */       int rightCode = identityHashCode(right);
/* 220 */       if (leftCode != rightCode) {
/* 221 */         return leftCode < rightCode ? -1 : 1;
/*     */       }
/*     */ 
/* 225 */       int result = ((Integer)this.uids.get(left)).compareTo((Integer)this.uids.get(right));
/* 226 */       if (result == 0) {
/* 227 */         throw new AssertionError();
/*     */       }
/* 229 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 233 */       return "Ordering.arbitrary()";
/*     */     }
/*     */ 
/*     */     int identityHashCode(Object object)
/*     */     {
/* 245 */       return System.identityHashCode(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ArbitraryOrderingHolder
/*     */   {
/* 201 */     static final Ordering<Object> ARBITRARY_ORDERING = new Ordering.ArbitraryOrdering();
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static class IncomparableValueException extends ClassCastException
/*     */   {
/*     */     final Object value;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     IncomparableValueException(Object value)
/*     */     {
/* 173 */       super();
/* 174 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Ordering
 * JD-Core Version:    0.6.0
 */