/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class CharsetCache
/*     */ {
/*  42 */   private static final CharsetCache instance = new CharsetCache(new DefaultLookup(null), 100);
/*     */   private final ConcurrentMap<String, SoftReference<Charset>> hitCache;
/*     */   private final Map<String, Boolean> missCache;
/*     */   private final Function<String, Charset> lookupFunction;
/*     */ 
/*     */   public static Charset forName(String charsetName)
/*     */   {
/*  57 */     return instance.lookup(charsetName);
/*     */   }
/*     */ 
/*     */   CharsetCache(Function<String, Charset> lookupFn, int missCacheSize)
/*     */   {
/* 102 */     Preconditions.checkNotNull(lookupFn);
/* 103 */     Preconditions.checkArgument(missCacheSize > 1);
/*     */ 
/* 105 */     this.lookupFunction = lookupFn;
/* 106 */     this.hitCache = new ConcurrentHashMap();
/*     */ 
/* 109 */     Map temp = new LinkedHashMap(missCacheSize, 0.75F, true, missCacheSize)
/*     */     {
/*     */       protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
/* 112 */         return size() > this.val$missCacheSize;
/*     */       }
/*     */     };
/* 115 */     this.missCache = Collections.synchronizedMap(temp);
/*     */   }
/*     */ 
/*     */   Charset lookup(String name)
/*     */   {
/* 122 */     Preconditions.checkArgument(name != null, "Charset name may not be null");
/*     */ 
/* 125 */     name = name.toLowerCase();
/* 126 */     SoftReference hit = (SoftReference)this.hitCache.get(name);
/* 127 */     if (hit != null) {
/* 128 */       Charset charset = (Charset)hit.get();
/* 129 */       if (charset != null)
/* 130 */         return charset;
/*     */     }
/* 132 */     else if (this.missCache.get(name) != null) {
/* 133 */       throw new UnsupportedCharsetException(name);
/*     */     }
/* 135 */     return lookupAndCache(name);
/*     */   }
/*     */ 
/*     */   private Charset lookupAndCache(String name)
/*     */   {
/*     */     try
/*     */     {
/* 144 */       Charset charset = (Charset)this.lookupFunction.apply(name);
/*     */ 
/* 147 */       SoftReference ref = new SoftReference(charset);
/* 148 */       this.hitCache.put(name, ref);
/* 149 */       for (String alias : charset.aliases()) {
/* 150 */         this.hitCache.put(alias.toLowerCase(), ref);
/*     */       }
/* 152 */       return charset;
/*     */     } catch (UnsupportedCharsetException e) {
/* 154 */       this.missCache.put(name, Boolean.TRUE);
/* 155 */     }throw e;
/*     */   }
/*     */ 
/*     */   private static class DefaultLookup
/*     */     implements Function<String, Charset>
/*     */   {
/*     */     public Charset apply(String charsetName)
/*     */     {
/*  65 */       return Charset.forName(charsetName);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.CharsetCache
 * JD-Core Version:    0.6.0
 */