/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.IOException;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public class Joiner
/*     */ {
/*     */   private final String separator;
/*     */ 
/*     */   public static Joiner on(String separator)
/*     */   {
/*  64 */     return new Joiner(separator);
/*     */   }
/*     */ 
/*     */   public static Joiner on(char separator)
/*     */   {
/*  71 */     return new Joiner(String.valueOf(separator));
/*     */   }
/*     */ 
/*     */   private Joiner(String separator)
/*     */   {
/*  77 */     this.separator = ((String)Preconditions.checkNotNull(separator));
/*     */   }
/*     */ 
/*     */   private Joiner(Joiner prototype) {
/*  81 */     this.separator = prototype.separator;
/*     */   }
/*     */ 
/*     */   public <A extends Appendable> A appendTo(A appendable, Iterable<?> parts)
/*     */     throws IOException
/*     */   {
/*  89 */     Preconditions.checkNotNull(appendable);
/*  90 */     Iterator iterator = parts.iterator();
/*  91 */     if (iterator.hasNext()) {
/*  92 */       appendable.append(toString(iterator.next()));
/*  93 */       while (iterator.hasNext()) {
/*  94 */         appendable.append(this.separator);
/*  95 */         appendable.append(toString(iterator.next()));
/*     */       }
/*     */     }
/*  98 */     return appendable;
/*     */   }
/*     */ 
/*     */   public final <A extends Appendable> A appendTo(A appendable, Object[] parts)
/*     */     throws IOException
/*     */   {
/* 106 */     return appendTo(appendable, Arrays.asList(parts));
/*     */   }
/*     */ 
/*     */   public final <A extends Appendable> A appendTo(A appendable, @Nullable Object first, @Nullable Object second, Object[] rest)
/*     */     throws IOException
/*     */   {
/* 115 */     return appendTo(appendable, iterable(first, second, rest));
/*     */   }
/*     */ 
/*     */   public final StringBuilder appendTo(StringBuilder builder, Iterable<?> parts)
/*     */   {
/*     */     try
/*     */     {
/* 125 */       appendTo(builder, parts);
/*     */     } catch (IOException impossible) {
/* 127 */       throw new AssertionError(impossible);
/*     */     }
/* 129 */     return builder;
/*     */   }
/*     */ 
/*     */   public final StringBuilder appendTo(StringBuilder builder, Object[] parts)
/*     */   {
/* 138 */     return appendTo(builder, Arrays.asList(parts));
/*     */   }
/*     */ 
/*     */   public final StringBuilder appendTo(StringBuilder builder, @Nullable Object first, @Nullable Object second, Object[] rest)
/*     */   {
/* 148 */     return appendTo(builder, iterable(first, second, rest));
/*     */   }
/*     */ 
/*     */   public final String join(Iterable<?> parts)
/*     */   {
/* 156 */     return appendTo(new StringBuilder(), parts).toString();
/*     */   }
/*     */ 
/*     */   public final String join(Object[] parts)
/*     */   {
/* 164 */     return join(Arrays.asList(parts));
/*     */   }
/*     */ 
/*     */   public final String join(@Nullable Object first, @Nullable Object second, Object[] rest)
/*     */   {
/* 172 */     return join(iterable(first, second, rest));
/*     */   }
/*     */ 
/*     */   public Joiner useForNull(String nullText)
/*     */   {
/* 180 */     Preconditions.checkNotNull(nullText);
/* 181 */     return new Joiner(this, nullText) {
/*     */       CharSequence toString(Object part) {
/* 183 */         return part == null ? this.val$nullText : Joiner.this.toString(part);
/*     */       }
/*     */ 
/*     */       public Joiner useForNull(String nullText) {
/* 187 */         Preconditions.checkNotNull(nullText);
/* 188 */         throw new UnsupportedOperationException("already specified useForNull");
/*     */       }
/*     */ 
/*     */       public Joiner skipNulls() {
/* 192 */         throw new UnsupportedOperationException("already specified useForNull");
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Joiner skipNulls()
/*     */   {
/* 202 */     return new Joiner(this)
/*     */     {
/*     */       public <A extends Appendable> A appendTo(A appendable, Iterable<?> parts) throws IOException {
/* 205 */         Preconditions.checkNotNull(appendable, "appendable");
/* 206 */         Preconditions.checkNotNull(parts, "parts");
/* 207 */         Iterator iterator = parts.iterator();
/* 208 */         while (iterator.hasNext()) {
/* 209 */           Object part = iterator.next();
/* 210 */           if (part != null) {
/* 211 */             appendable.append(Joiner.this.toString(part));
/* 212 */             break;
/*     */           }
/*     */         }
/* 215 */         while (iterator.hasNext()) {
/* 216 */           Object part = iterator.next();
/* 217 */           if (part != null) {
/* 218 */             appendable.append(Joiner.this.separator);
/* 219 */             appendable.append(Joiner.this.toString(part));
/*     */           }
/*     */         }
/* 222 */         return appendable;
/*     */       }
/*     */ 
/*     */       public Joiner useForNull(String nullText) {
/* 226 */         Preconditions.checkNotNull(nullText);
/* 227 */         throw new UnsupportedOperationException("already specified skipNulls");
/*     */       }
/*     */ 
/*     */       public Joiner.MapJoiner withKeyValueSeparator(String kvs) {
/* 231 */         Preconditions.checkNotNull(kvs);
/* 232 */         throw new UnsupportedOperationException("can't use .skipNulls() with maps");
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public MapJoiner withKeyValueSeparator(String keyValueSeparator)
/*     */   {
/* 242 */     return new MapJoiner(this, (String)Preconditions.checkNotNull(keyValueSeparator), null);
/*     */   }
/*     */ 
/*     */   CharSequence toString(Object part)
/*     */   {
/* 313 */     return (part instanceof CharSequence) ? (CharSequence)part : part.toString();
/*     */   }
/*     */ 
/*     */   private static Iterable<Object> iterable(Object first, Object second, Object[] rest)
/*     */   {
/* 318 */     Preconditions.checkNotNull(rest);
/* 319 */     return new AbstractList(rest, first, second) {
/*     */       public int size() {
/* 321 */         return this.val$rest.length + 2;
/*     */       }
/*     */ 
/*     */       public Object get(int index) {
/* 325 */         switch (index) {
/*     */         case 0:
/* 327 */           return this.val$first;
/*     */         case 1:
/* 329 */           return this.val$second;
/*     */         }
/* 331 */         return this.val$rest[(index - 2)];
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static class MapJoiner
/*     */   {
/*     */     private final Joiner joiner;
/*     */     private final String keyValueSeparator;
/*     */ 
/*     */     private MapJoiner(Joiner joiner, String keyValueSeparator)
/*     */     {
/* 254 */       this.joiner = joiner;
/* 255 */       this.keyValueSeparator = keyValueSeparator;
/*     */     }
/*     */ 
/*     */     public <A extends Appendable> A appendTo(A appendable, Map<?, ?> map)
/*     */       throws IOException
/*     */     {
/* 263 */       Preconditions.checkNotNull(appendable);
/* 264 */       Iterator iterator = map.entrySet().iterator();
/* 265 */       if (iterator.hasNext()) {
/* 266 */         Map.Entry entry = (Map.Entry)iterator.next();
/* 267 */         appendable.append(this.joiner.toString(entry.getKey()));
/* 268 */         appendable.append(this.keyValueSeparator);
/* 269 */         appendable.append(this.joiner.toString(entry.getValue()));
/* 270 */         while (iterator.hasNext()) {
/* 271 */           appendable.append(this.joiner.separator);
/* 272 */           Map.Entry e = (Map.Entry)iterator.next();
/* 273 */           appendable.append(this.joiner.toString(e.getKey()));
/* 274 */           appendable.append(this.keyValueSeparator);
/* 275 */           appendable.append(this.joiner.toString(e.getValue()));
/*     */         }
/*     */       }
/* 278 */       return appendable;
/*     */     }
/*     */ 
/*     */     public StringBuilder appendTo(StringBuilder builder, Map<?, ?> map)
/*     */     {
/*     */       try
/*     */       {
/* 288 */         appendTo(builder, map);
/*     */       } catch (IOException impossible) {
/* 290 */         throw new AssertionError(impossible);
/*     */       }
/* 292 */       return builder;
/*     */     }
/*     */ 
/*     */     public String join(Map<?, ?> map)
/*     */     {
/* 300 */       return appendTo(new StringBuilder(), map).toString();
/*     */     }
/*     */ 
/*     */     public MapJoiner useForNull(String nullText)
/*     */     {
/* 308 */       return new MapJoiner(this.joiner.useForNull(nullText), this.keyValueSeparator);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Joiner
 * JD-Core Version:    0.6.0
 */