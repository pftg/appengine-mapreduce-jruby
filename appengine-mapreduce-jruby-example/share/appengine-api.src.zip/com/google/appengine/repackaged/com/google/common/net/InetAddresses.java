/*     */ package com.google.appengine.repackaged.com.google.common.net;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Hash;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.io.ByteArrayDataInput;
/*     */ import com.google.appengine.repackaged.com.google.common.io.ByteStreams;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*     */ import com.google.common.annotations.Beta;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.Inet6Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Locale;
/*     */ 
/*     */ @Beta
/*     */ public final class InetAddresses
/*     */ {
/*     */   private static final int IPV4_PART_COUNT = 4;
/*     */   private static final int IPV6_PART_COUNT = 8;
/* 124 */   private static final Inet4Address LOOPBACK4 = (Inet4Address)forString("127.0.0.1");
/*     */ 
/* 126 */   private static final Inet4Address ANY4 = (Inet4Address)forString("0.0.0.0");
/*     */ 
/*     */   private static Inet4Address getInet4Address(byte[] bytes) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: arraylength
/*     */     //   2: iconst_4
/*     */     //   3: if_icmpne +7 -> 10
/*     */     //   6: iconst_1
/*     */     //   7: goto +4 -> 11
/*     */     //   10: iconst_0
/*     */     //   11: ldc 29
/*     */     //   13: iconst_1
/*     */     //   14: anewarray 4	java/lang/Object
/*     */     //   17: dup
/*     */     //   18: iconst_0
/*     */     //   19: aload_0
/*     */     //   20: arraylength
/*     */     //   21: invokestatic 35	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   24: aastore
/*     */     //   25: invokestatic 41	com/google/appengine/repackaged/com/google/common/base/Preconditions:checkArgument	(ZLjava/lang/String;[Ljava/lang/Object;)V
/*     */     //   28: aload_0
/*     */     //   29: invokestatic 47	java/net/InetAddress:getByAddress	([B)Ljava/net/InetAddress;
/*     */     //   32: astore_1
/*     */     //   33: aload_1
/*     */     //   34: instanceof 49
/*     */     //   37: ifne +27 -> 64
/*     */     //   40: new 27	java/net/UnknownHostException
/*     */     //   43: dup
/*     */     //   44: ldc 51
/*     */     //   46: iconst_1
/*     */     //   47: anewarray 4	java/lang/Object
/*     */     //   50: dup
/*     */     //   51: iconst_0
/*     */     //   52: aload_1
/*     */     //   53: invokevirtual 55	java/net/InetAddress:getHostAddress	()Ljava/lang/String;
/*     */     //   56: aastore
/*     */     //   57: invokestatic 61	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   60: invokespecial 64	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
/*     */     //   63: athrow
/*     */     //   64: aload_1
/*     */     //   65: checkcast 49	java/net/Inet4Address
/*     */     //   68: areturn
/*     */     //   69: astore_1
/*     */     //   70: new 66	java/lang/IllegalArgumentException
/*     */     //   73: dup
/*     */     //   74: ldc 68
/*     */     //   76: iconst_1
/*     */     //   77: anewarray 4	java/lang/Object
/*     */     //   80: dup
/*     */     //   81: iconst_0
/*     */     //   82: aload_0
/*     */     //   83: invokestatic 74	java/util/Arrays:toString	([B)Ljava/lang/String;
/*     */     //   86: aastore
/*     */     //   87: invokestatic 61	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   90: aload_1
/*     */     //   91: invokespecial 77	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   94: athrow
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   28	68	69	java/net/UnknownHostException } 
/*     */   public static InetAddress forString(String ipString) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic 89	com/google/appengine/repackaged/com/google/common/net/InetAddresses:textToNumericFormatV4	(Ljava/lang/String;)[B
/*     */     //   4: astore_1
/*     */     //   5: aload_1
/*     */     //   6: ifnonnull +8 -> 14
/*     */     //   9: aload_0
/*     */     //   10: invokestatic 92	com/google/appengine/repackaged/com/google/common/net/InetAddresses:textToNumericFormatV6	(Ljava/lang/String;)[B
/*     */     //   13: astore_1
/*     */     //   14: aload_1
/*     */     //   15: ifnonnull +24 -> 39
/*     */     //   18: new 66	java/lang/IllegalArgumentException
/*     */     //   21: dup
/*     */     //   22: ldc 94
/*     */     //   24: iconst_1
/*     */     //   25: anewarray 4	java/lang/Object
/*     */     //   28: dup
/*     */     //   29: iconst_0
/*     */     //   30: aload_0
/*     */     //   31: aastore
/*     */     //   32: invokestatic 61	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   35: invokespecial 95	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   38: athrow
/*     */     //   39: aload_1
/*     */     //   40: invokestatic 47	java/net/InetAddress:getByAddress	([B)Ljava/net/InetAddress;
/*     */     //   43: areturn
/*     */     //   44: astore_2
/*     */     //   45: new 66	java/lang/IllegalArgumentException
/*     */     //   48: dup
/*     */     //   49: ldc 97
/*     */     //   51: iconst_1
/*     */     //   52: anewarray 4	java/lang/Object
/*     */     //   55: dup
/*     */     //   56: iconst_0
/*     */     //   57: aload_0
/*     */     //   58: aastore
/*     */     //   59: invokestatic 61	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   62: aload_2
/*     */     //   63: invokespecial 77	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   66: athrow
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   39	43	44	java/net/UnknownHostException } 
/*     */   public static boolean isInetAddress(String ipString) { try { forString(ipString);
/* 231 */       return true; } catch (IllegalArgumentException e) {
/*     */     }
/* 233 */     return false;
/*     */   }
/*     */ 
/*     */   private static byte[] textToNumericFormatV4(String ipString)
/*     */   {
/* 239 */     boolean isIpv6 = false;
/*     */ 
/* 243 */     if (ipString.toUpperCase(Locale.US).startsWith("::FFFF:")) {
/* 244 */       ipString = ipString.substring(7);
/* 245 */     } else if (ipString.startsWith("::")) {
/* 246 */       ipString = ipString.substring(2);
/* 247 */       isIpv6 = true;
/*     */     }
/*     */ 
/* 250 */     String[] address = ipString.split("\\.");
/* 251 */     if (address.length != 4)
/* 252 */       return null;
/*     */     try
/*     */     {
/* 255 */       byte[] bytes = new byte[4];
/* 256 */       for (int i = 0; i < bytes.length; i++) {
/* 257 */         int piece = Integer.parseInt(address[i]);
/* 258 */         if ((piece < 0) || (piece > 255)) {
/* 259 */           return null;
/*     */         }
/*     */ 
/* 266 */         if ((address[i].startsWith("0")) && (address[i].length() != 1)) {
/* 267 */           return null;
/*     */         }
/* 269 */         bytes[i] = (byte)piece;
/*     */       }
/*     */ 
/* 272 */       if (isIpv6) {
/* 273 */         byte[] data = new byte[16];
/* 274 */         System.arraycopy(bytes, 0, data, 12, 4);
/* 275 */         return data;
/*     */       }
/* 277 */       return bytes;
/*     */     } catch (NumberFormatException ex) {
/*     */     }
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */   private static byte[] textToNumericFormatV6(String ipString)
/*     */   {
/* 285 */     if (!ipString.contains(":")) {
/* 286 */       return null;
/*     */     }
/* 288 */     if (ipString.contains(":::")) {
/* 289 */       return null;
/*     */     }
/*     */ 
/* 292 */     if (ipString.contains(".")) {
/* 293 */       ipString = convertDottedQuadToHex(ipString);
/* 294 */       if (ipString == null) {
/* 295 */         return null;
/*     */       }
/*     */     }
/*     */ 
/* 299 */     ipString = padIpString(ipString);
/*     */     try {
/* 301 */       String[] address = ipString.split(":", 8);
/* 302 */       if (address.length != 8) {
/* 303 */         return null;
/*     */       }
/* 305 */       byte[] bytes = new byte[16];
/* 306 */       for (int i = 0; i < 8; i++) {
/* 307 */         int piece = address[i].equals("") ? 0 : Integer.parseInt(address[i], 16);
/* 308 */         bytes[(2 * i)] = (byte)((piece & 0xFF00) >>> 8);
/* 309 */         bytes[(2 * i + 1)] = (byte)(piece & 0xFF);
/*     */       }
/* 311 */       return bytes; } catch (NumberFormatException ex) {
/*     */     }
/* 313 */     return null;
/*     */   }
/*     */ 
/*     */   private static String padIpString(String ipString)
/*     */   {
/* 319 */     if (ipString.contains("::")) {
/* 320 */       int count = numberOfColons(ipString);
/* 321 */       StringBuilder buffer = new StringBuilder("::");
/* 322 */       for (int i = 0; i + count < 7; i++) {
/* 323 */         buffer.append(":");
/*     */       }
/* 325 */       ipString = ipString.replace("::", buffer);
/*     */     }
/* 327 */     return ipString;
/*     */   }
/*     */ 
/*     */   private static int numberOfColons(String s) {
/* 331 */     int count = 0;
/* 332 */     for (int i = 0; i < s.length(); i++) {
/* 333 */       if (s.charAt(i) == ':') {
/* 334 */         count++;
/*     */       }
/*     */     }
/* 337 */     return count;
/*     */   }
/*     */ 
/*     */   private static String convertDottedQuadToHex(String ipString) {
/* 341 */     int lastColon = ipString.lastIndexOf(':');
/* 342 */     String initialPart = ipString.substring(0, lastColon + 1);
/* 343 */     String dottedQuad = ipString.substring(lastColon + 1);
/* 344 */     byte[] quad = textToNumericFormatV4(dottedQuad);
/* 345 */     if (quad == null) {
/* 346 */       return null;
/*     */     }
/* 348 */     String penultimate = Integer.toHexString((quad[0] & 0xFF) << 8 | quad[1] & 0xFF);
/* 349 */     String ultimate = Integer.toHexString((quad[2] & 0xFF) << 8 | quad[3] & 0xFF);
/* 350 */     return initialPart + penultimate + ":" + ultimate;
/*     */   }
/*     */ 
/*     */   public static String toUriString(InetAddress ip)
/*     */   {
/* 379 */     if ((ip instanceof Inet6Address)) {
/* 380 */       return "[" + ip.getHostAddress() + "]";
/*     */     }
/* 382 */     return ip.getHostAddress();
/*     */   }
/*     */ 
/*     */   public static InetAddress forUriString(String hostAddr)
/*     */   {
/* 401 */     Preconditions.checkNotNull(hostAddr);
/* 402 */     Preconditions.checkArgument(hostAddr.length() > 0, "host string is empty");
/* 403 */     InetAddress retval = null;
/*     */     try
/*     */     {
/* 407 */       retval = forString(hostAddr);
/* 408 */       if ((retval instanceof Inet4Address)) {
/* 409 */         return retval;
/*     */       }
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/*     */     }
/*     */ 
/* 416 */     if ((!hostAddr.startsWith("[")) || (!hostAddr.endsWith("]"))) {
/* 417 */       throw new IllegalArgumentException("Not a valid address: \"" + hostAddr + '"');
/*     */     }
/*     */ 
/* 420 */     retval = forString(hostAddr.substring(1, hostAddr.length() - 1));
/* 421 */     if ((retval instanceof Inet6Address)) {
/* 422 */       return retval;
/*     */     }
/*     */ 
/* 425 */     throw new IllegalArgumentException("Not a valid address: \"" + hostAddr + '"');
/*     */   }
/*     */ 
/*     */   public static boolean isUriInetAddress(String ipString)
/*     */   {
/*     */     try
/*     */     {
/* 437 */       forUriString(ipString);
/* 438 */       return true; } catch (IllegalArgumentException e) {
/*     */     }
/* 440 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isCompatIPv4Address(Inet6Address ip)
/*     */   {
/* 470 */     if (!ip.isIPv4CompatibleAddress()) {
/* 471 */       return false;
/*     */     }
/*     */ 
/* 474 */     byte[] bytes = ip.getAddress();
/*     */ 
/* 477 */     return (bytes[12] != 0) || (bytes[13] != 0) || (bytes[14] != 0) || ((bytes[15] != 0) && (bytes[15] != 1));
/*     */   }
/*     */ 
/*     */   public static Inet4Address getCompatIPv4Address(Inet6Address ip)
/*     */   {
/* 493 */     Preconditions.checkArgument(isCompatIPv4Address(ip), "Address '%s' is not IPv4-compatible.", new Object[] { ip.getHostAddress() });
/*     */ 
/* 496 */     return getInet4Address(copyOfRange(ip.getAddress(), 12, 16));
/*     */   }
/*     */ 
/*     */   public static boolean is6to4Address(Inet6Address ip)
/*     */   {
/* 515 */     byte[] bytes = ip.getAddress();
/* 516 */     return (bytes[0] == 32) && (bytes[1] == 2);
/*     */   }
/*     */ 
/*     */   public static Inet4Address get6to4IPv4Address(Inet6Address ip)
/*     */   {
/* 529 */     Preconditions.checkArgument(is6to4Address(ip), "Address '%s' is not a 6to4 address.", new Object[] { ip.getHostAddress() });
/*     */ 
/* 532 */     return getInet4Address(copyOfRange(ip.getAddress(), 2, 6));
/*     */   }
/*     */ 
/*     */   public static boolean isTeredoAddress(Inet6Address ip)
/*     */   {
/* 618 */     byte[] bytes = ip.getAddress();
/* 619 */     return (bytes[0] == 32) && (bytes[1] == 1) && (bytes[2] == 0) && (bytes[3] == 0);
/*     */   }
/*     */ 
/*     */   public static InetAddresses.TeredoInfo getTeredoInfo(Inet6Address ip)
/*     */   {
/* 633 */     Preconditions.checkArgument(isTeredoAddress(ip), "Address '%s' is not a Teredo address.", new Object[] { ip.getHostAddress() });
/*     */ 
/* 636 */     byte[] bytes = ip.getAddress();
/* 637 */     Inet4Address server = getInet4Address(copyOfRange(bytes, 4, 8));
/*     */ 
/* 639 */     int flags = ByteStreams.newDataInput(bytes, 8).readShort() & 0xFFFF;
/*     */ 
/* 642 */     int port = (ByteStreams.newDataInput(bytes, 10).readShort() ^ 0xFFFFFFFF) & 0xFFFF;
/*     */ 
/* 644 */     byte[] clientBytes = copyOfRange(bytes, 12, 16);
/* 645 */     for (int i = 0; i < clientBytes.length; i++)
/*     */     {
/* 647 */       clientBytes[i] = (byte)(clientBytes[i] ^ 0xFFFFFFFF);
/*     */     }
/* 649 */     Inet4Address client = getInet4Address(clientBytes);
/*     */ 
/* 651 */     return new InetAddresses.TeredoInfo(server, client, port, flags);
/*     */   }
/*     */ 
/*     */   public static boolean isIsatapAddress(Inet6Address ip)
/*     */   {
/* 674 */     if (isTeredoAddress(ip)) {
/* 675 */       return false;
/*     */     }
/*     */ 
/* 678 */     byte[] bytes = ip.getAddress();
/*     */ 
/* 680 */     if ((bytes[8] | 0x3) != 3)
/*     */     {
/* 684 */       return false;
/*     */     }
/*     */ 
/* 687 */     return (bytes[9] == 0) && (bytes[10] == 94) && (bytes[11] == -2);
/*     */   }
/*     */ 
/*     */   public static Inet4Address getIsatapIPv4Address(Inet6Address ip)
/*     */   {
/* 701 */     Preconditions.checkArgument(isIsatapAddress(ip), "Address '%s' is not an ISATAP address.", new Object[] { ip.getHostAddress() });
/*     */ 
/* 704 */     return getInet4Address(copyOfRange(ip.getAddress(), 12, 16));
/*     */   }
/*     */ 
/*     */   public static Inet4Address getEmbeddedIPv4ClientAddress(Inet6Address ip)
/*     */   {
/* 723 */     if (isCompatIPv4Address(ip)) {
/* 724 */       return getCompatIPv4Address(ip);
/*     */     }
/*     */ 
/* 727 */     if (is6to4Address(ip)) {
/* 728 */       return get6to4IPv4Address(ip);
/*     */     }
/*     */ 
/* 731 */     if (isTeredoAddress(ip)) {
/* 732 */       return getTeredoInfo(ip).getClient();
/*     */     }
/*     */ 
/* 735 */     throw new IllegalArgumentException(String.format("'%s' has no embedded IPv4 address.", new Object[] { ip.getHostAddress() }));
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static Inet4Address getCoercedIPv4Address(InetAddress ip)
/*     */   {
/* 761 */     if ((ip instanceof Inet4Address)) {
/* 762 */       return (Inet4Address)ip;
/*     */     }
/*     */ 
/* 766 */     byte[] bytes = ip.getAddress();
/* 767 */     boolean leadingBytesOfZero = true;
/* 768 */     for (int i = 0; i < 15; i++) {
/* 769 */       if (bytes[i] != 0) {
/* 770 */         leadingBytesOfZero = false;
/* 771 */         break;
/*     */       }
/*     */     }
/* 774 */     if ((leadingBytesOfZero) && (bytes[15] == 1))
/* 775 */       return LOOPBACK4;
/* 776 */     if ((leadingBytesOfZero) && (bytes[15] == 0)) {
/* 777 */       return ANY4;
/*     */     }
/*     */ 
/* 780 */     int coercedHash = 0;
/*     */     try {
/* 782 */       coercedHash = Hash.hash32(getEmbeddedIPv4ClientAddress((Inet6Address)ip).getAddress());
/*     */     }
/*     */     catch (IllegalArgumentException acceptable)
/*     */     {
/* 787 */       coercedHash = Hash.hash32(ip.getAddress(), 0, 8);
/*     */     }
/*     */ 
/* 791 */     coercedHash |= -536870912;
/*     */ 
/* 795 */     if (coercedHash == -1) {
/* 796 */       coercedHash = -2;
/*     */     }
/*     */ 
/* 799 */     return getInet4Address(Ints.toByteArray(coercedHash));
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static int coerceToInteger(InetAddress ip)
/*     */   {
/* 824 */     return ByteStreams.newDataInput(getCoercedIPv4Address(ip).getAddress()).readInt();
/*     */   }
/*     */ 
/*     */   public static Inet4Address fromInteger(int address)
/*     */   {
/* 835 */     return getInet4Address(Ints.toByteArray(address));
/*     */   }
/*     */ 
/*     */   public static InetAddress fromLittleEndianByteArray(byte[] addr)
/*     */     throws UnknownHostException
/*     */   {
/* 851 */     byte[] reversed = new byte[addr.length];
/* 852 */     for (int i = 0; i < addr.length; i++) {
/* 853 */       reversed[i] = addr[(addr.length - i - 1)];
/*     */     }
/* 855 */     return InetAddress.getByAddress(reversed);
/*     */   }
/*     */ 
/*     */   private static byte[] copyOfRange(byte[] original, int from, int to)
/*     */   {
/* 864 */     Preconditions.checkNotNull(original);
/*     */ 
/* 866 */     int end = Math.min(to, original.length);
/* 867 */     byte[] result = new byte[to - from];
/*     */ 
/* 869 */     System.arraycopy(original, from, result, 0, end - from);
/* 870 */     return result;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.net.InetAddresses
 * JD-Core Version:    0.6.0
 */