/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ final class CompositeImpl extends Composite
/*    */ {
/*    */   private final Image image;
/*    */   private final Composite.Anchor anchor;
/*    */   private final int xOffset;
/*    */   private final int yOffset;
/*    */   private final float opacity;
/*    */ 
/*    */   CompositeImpl(Image image, int xOffset, int yOffset, float opacity, Composite.Anchor anchor)
/*    */   {
/* 30 */     if (image == null) {
/* 31 */       throw new IllegalArgumentException("The image must not be null");
/*    */     }
/* 33 */     if ((xOffset > 4000) || (xOffset < -4000) || (yOffset > 4000) || (yOffset < -4000))
/*    */     {
/* 37 */       throw new IllegalArgumentException("Images must fit on the canvas");
/*    */     }
/* 39 */     if ((opacity < 0.0F) || (opacity > 1.0F)) {
/* 40 */       throw new IllegalArgumentException("Opacity must be in range [0, 1]");
/*    */     }
/* 42 */     if (anchor == null) {
/* 43 */       throw new IllegalArgumentException("Anchor must not be null");
/*    */     }
/* 45 */     this.image = image;
/* 46 */     this.anchor = anchor;
/* 47 */     this.xOffset = xOffset;
/* 48 */     this.yOffset = yOffset;
/* 49 */     this.opacity = opacity;
/*    */   }
/*    */ 
/*    */   void apply(ImagesServicePb.ImagesCompositeRequest request, Map<Image, Integer> imageIndexMap)
/*    */   {
/* 55 */     if (!imageIndexMap.containsKey(this.image)) {
/* 56 */       imageIndexMap.put(this.image, Integer.valueOf(request.imageSize()));
/* 57 */       ImagesServiceImpl.convertImageData(this.image, request.addImage());
/*    */     }
/* 59 */     ImagesServicePb.CompositeImageOptions options = request.addOptions();
/* 60 */     int sourceId = ((Integer)imageIndexMap.get(this.image)).intValue();
/* 61 */     options.setSourceIndex(sourceId);
/* 62 */     options.setXOffset(this.xOffset);
/* 63 */     options.setYOffset(this.yOffset);
/* 64 */     options.setOpacity(this.opacity);
/* 65 */     options.setAnchor(this.anchor.ordinal());
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.CompositeImpl
 * JD-Core Version:    0.6.0
 */