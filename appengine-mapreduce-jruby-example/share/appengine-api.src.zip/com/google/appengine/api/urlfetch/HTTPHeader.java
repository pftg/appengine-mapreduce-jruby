/*    */ package com.google.appengine.api.urlfetch;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class HTTPHeader
/*    */   implements Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final String value;
/*    */ 
/*    */   public HTTPHeader(String name, String value)
/*    */   {
/* 25 */     this.name = name;
/* 26 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 30 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 34 */     return this.value;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.HTTPHeader
 * JD-Core Version:    0.6.0
 */