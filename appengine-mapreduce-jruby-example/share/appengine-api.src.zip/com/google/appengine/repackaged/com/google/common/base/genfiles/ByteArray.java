/*     */ package com.google.appengine.repackaged.com.google.common.base.genfiles;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.X;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ public final class ByteArray
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private byte[] list;
/*     */   private int length;
/*     */ 
/*     */   @Deprecated
/*     */   public ByteArray()
/*     */   {
/*  45 */     this.list = new byte[4];
/*  46 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ByteArray(int capacity)
/*     */   {
/*  58 */     this.list = new byte[capacity];
/*  59 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   public ByteArray(byte[] source, int start, int num)
/*     */   {
/*  64 */     X.assertTrue(num >= 0);
/*  65 */     this.list = new byte[num];
/*  66 */     this.length = num;
/*  67 */     System.arraycopy(source, start, this.list, 0, num);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private ByteArray(byte[] array, int arrayLength)
/*     */   {
/*  78 */     this.list = array;
/*  79 */     this.length = arrayLength;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static ByteArray newInstance(byte[] array)
/*     */   {
/* 102 */     Preconditions.checkNotNull(array);
/* 103 */     return new ByteArray(array, array.length);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static ByteArray newInstance(byte[] array, int length)
/*     */   {
/* 128 */     Preconditions.checkNotNull(array);
/* 129 */     Preconditions.checkArgument((length >= 0) && (length <= array.length));
/* 130 */     return new ByteArray(array, length);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 135 */     return this.length;
/*     */   }
/*     */ 
/*     */   public byte get(int i)
/*     */   {
/* 141 */     X.assertTrue((i >= 0) && (i < this.length));
/* 142 */     return this.list[i];
/*     */   }
/*     */ 
/*     */   public void set(int i, byte x)
/*     */   {
/* 148 */     X.assertTrue((i >= 0) && (i < this.length));
/* 149 */     this.list[i] = x;
/*     */   }
/*     */ 
/*     */   public void add(byte x)
/*     */   {
/* 154 */     if (this.length >= this.list.length) ensureCapacity(this.length + 1);
/* 155 */     this.list[(this.length++)] = x;
/*     */   }
/*     */ 
/*     */   public void prependSlow(byte x)
/*     */   {
/* 161 */     ensureCapacity(this.length + 1);
/* 162 */     System.arraycopy(this.list, 0, this.list, 1, this.length);
/* 163 */     this.list[0] = x;
/* 164 */     this.length += 1;
/*     */   }
/*     */ 
/*     */   public void add(byte[] source, int start, int num)
/*     */   {
/* 169 */     if (this.length + num > this.list.length) ensureCapacity(this.length + num);
/* 170 */     System.arraycopy(source, start, this.list, this.length, num);
/* 171 */     this.length += num;
/*     */   }
/*     */ 
/*     */   public void addArray(ByteArray other)
/*     */   {
/* 176 */     add(other.rep(), 0, other.size());
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 181 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   public void removeLast()
/*     */   {
/* 186 */     X.assertTrue(this.length > 0);
/*     */ 
/* 189 */     this.length -= 1;
/*     */   }
/*     */ 
/*     */   public byte pop()
/*     */   {
/* 194 */     X.assertTrue(this.length > 0);
/*     */ 
/* 197 */     return this.list[(--this.length)];
/*     */   }
/*     */ 
/*     */   public void removeFast(int i)
/*     */   {
/* 203 */     X.assertTrue((i >= 0) && (i < this.length));
/* 204 */     this.list[i] = this.list[(this.length - 1)];
/* 205 */     removeLast();
/*     */   }
/*     */ 
/*     */   public int indexOf(byte element)
/*     */   {
/* 212 */     for (int i = 0; i < this.length; i++) {
/* 213 */       if (this.list[i] == element) {
/* 214 */         return i;
/*     */       }
/*     */     }
/* 217 */     return -1;
/*     */   }
/*     */ 
/*     */   public void removeSlow(int i)
/*     */   {
/* 224 */     X.assertTrue((i >= 0) && (i < this.length));
/* 225 */     System.arraycopy(this.list, i + 1, this.list, i, this.length - (i + 1));
/* 226 */     this.length -= 1;
/*     */   }
/*     */ 
/*     */   public void replaceSlow(int start, int rangelen, ByteArray other)
/*     */   {
/* 233 */     X.assertTrue(other.list != this.list);
/* 234 */     int end = start + rangelen;
/* 235 */     X.assertTrue((start >= 0) && (end <= this.length));
/* 236 */     ensureCapacity(this.length - rangelen + other.length);
/* 237 */     if (end < this.length) {
/* 238 */       System.arraycopy(this.list, end, this.list, start + other.length, this.length - end);
/*     */     }
/* 240 */     System.arraycopy(other.list, 0, this.list, start, other.length);
/* 241 */     this.length = (this.length - rangelen + other.length);
/*     */   }
/*     */ 
/*     */   public void ensureCapacity(int n)
/*     */   {
/* 248 */     if (this.list.length < n) {
/* 249 */       int new_size = this.list.length * 2;
/* 250 */       if (new_size < n) {
/* 251 */         new_size = n;
/*     */       }
/* 253 */       byte[] copy = new byte[new_size];
/* 254 */       System.arraycopy(this.list, 0, copy, 0, this.length);
/* 255 */       this.list = copy;
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] rep()
/*     */   {
/* 264 */     return this.list;
/*     */   }
/*     */ 
/*     */   public void resize(int n)
/*     */   {
/* 272 */     X.assertTrue(n >= 0);
/* 273 */     ensureCapacity(n);
/* 274 */     this.length = n;
/*     */   }
/*     */ 
/*     */   public void trimToSize()
/*     */   {
/* 279 */     if (this.list.length != this.length)
/* 280 */       this.list = toArray();
/*     */   }
/*     */ 
/*     */   public void swap(ByteArray other)
/*     */   {
/* 287 */     int tmp_length = this.length;
/* 288 */     this.length = other.length;
/* 289 */     other.length = tmp_length;
/* 290 */     byte[] tmp_list = this.list;
/* 291 */     this.list = other.list;
/* 292 */     other.list = tmp_list;
/*     */   }
/*     */ 
/*     */   public byte[] toArray()
/*     */   {
/* 297 */     byte[] copy = new byte[this.length];
/* 298 */     System.arraycopy(this.list, 0, copy, 0, this.length);
/* 299 */     return copy;
/*     */   }
/*     */ 
/*     */   public byte[] subArray(int start, int len)
/*     */   {
/* 304 */     X.assertTrue(start >= 0);
/* 305 */     X.assertTrue(start + len <= this.length);
/* 306 */     byte[] copy = new byte[len];
/* 307 */     System.arraycopy(this.list, start, copy, 0, len);
/* 308 */     return copy;
/*     */   }
/*     */ 
/*     */   public void copy(byte[] dest, int len, int src_pos, int dest_pos)
/*     */   {
/* 313 */     X.assertTrue(src_pos >= 0);
/* 314 */     X.assertTrue(dest_pos >= 0);
/* 315 */     X.assertTrue(len >= 0);
/* 316 */     X.assertTrue(src_pos + len <= this.length);
/* 317 */     X.assertTrue(dest_pos + len <= dest.length);
/* 318 */     System.arraycopy(this.list, src_pos, dest, dest_pos, len);
/*     */   }
/*     */   public final void addUTF(String str) {
/* 325 */     int original_length = this.length;
/*     */     byte[] utf8_bytes;
/*     */     try {
/* 328 */       utf8_bytes = str.getBytes("UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/* 330 */       System.out.println("addUTF: " + e);
/* 331 */       return;
/*     */     }
/* 333 */     resize(this.length + utf8_bytes.length);
/* 334 */     for (int i = 0; i < utf8_bytes.length; i++)
/* 335 */       this.list[(original_length + i)] = utf8_bytes[i];
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.genfiles.ByteArray
 * JD-Core Version:    0.6.0
 */