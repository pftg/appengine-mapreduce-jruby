/*     */ package com.google.appengine.api.mail.stdimpl;
/*     */ 
/*     */ import com.google.appengine.api.mail.MailService;
/*     */ import com.google.appengine.api.mail.MailService.Attachment;
/*     */ import com.google.appengine.api.mail.MailService.Message;
/*     */ import com.google.appengine.api.mail.MailServiceFactory;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Join;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.SendFailedException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.URLName;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMessage.RecipientType;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ 
/*     */ public class GMTransport extends Transport
/*     */ {
/*     */   private static final String ADMINS_ADDRESS = "admins";
/*     */ 
/*     */   public GMTransport(Session session, URLName urlName)
/*     */   {
/*  48 */     super(session, urlName);
/*     */   }
/*     */ 
/*     */   protected boolean protocolConnect(String host, int port, String user, String password)
/*     */   {
/*  56 */     return true;
/*     */   }
/*     */ 
/*     */   public void sendMessage(Message message, Address[] addresses)
/*     */     throws MessagingException
/*     */   {
/*  63 */     MailService service = MailServiceFactory.getMailService();
/*  64 */     MailService.Message msg = new MailService.Message();
/*     */ 
/*  68 */     String sender = null;
/*  69 */     if ((message instanceof MimeMessage)) {
/*  70 */       Address senderAddr = ((MimeMessage)message).getSender();
/*  71 */       if (senderAddr != null) {
/*  72 */         sender = senderAddr.toString();
/*     */       }
/*     */     }
/*  75 */     if ((sender == null) && (message.getFrom() != null) && (message.getFrom().length > 0))
/*     */     {
/*  80 */       sender = message.getFrom()[0].toString();
/*     */     }
/*     */ 
/*  83 */     msg.setSender(sender);
/*     */     try
/*     */     {
/*  91 */       msg.setReplyTo(Join.join(", ", message.getReplyTo()));
/*     */     }
/*     */     catch (NullPointerException e)
/*     */     {
/*     */     }
/*     */ 
/*  97 */     boolean toAdmins = false;
/*  98 */     Address[] allRecipients = message.getAllRecipients();
/*  99 */     if (allRecipients != null) {
/* 100 */       for (Address addr : allRecipients) {
/* 101 */         if ("admins".equals(addr.toString())) {
/* 102 */           toAdmins = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 109 */     if (!toAdmins) {
/* 110 */       Set allAddresses = new HashSet();
/* 111 */       for (Address addr : addresses) {
/* 112 */         allAddresses.add(addr.toString());
/*     */       }
/* 114 */       msg.setTo(convertAddressFields(message.getRecipients(MimeMessage.RecipientType.TO), allAddresses));
/* 115 */       msg.setCc(convertAddressFields(message.getRecipients(MimeMessage.RecipientType.CC), allAddresses));
/* 116 */       msg.setBcc(convertAddressFields(message.getRecipients(MimeMessage.RecipientType.BCC), allAddresses));
/*     */     }
/*     */ 
/* 120 */     msg.setSubject(message.getSubject());
/*     */ 
/* 123 */     Object textObject = null;
/* 124 */     Object htmlObject = null;
/* 125 */     String textType = null;
/* 126 */     String htmlType = null;
/* 127 */     Multipart otherMessageParts = null;
/*     */ 
/* 129 */     if (message.getContentType() == null)
/*     */     {
/*     */       try
/*     */       {
/* 133 */         textObject = message.getContent();
/* 134 */         textType = message.getContentType();
/*     */       } catch (IOException e) {
/* 136 */         throw new MessagingException("Getting typeless content failed", e);
/*     */       }
/*     */     }
/* 138 */     else if (message.isMimeType("text/html"))
/*     */       try {
/* 140 */         htmlObject = message.getContent();
/* 141 */         htmlType = message.getContentType();
/*     */       } catch (IOException e) {
/* 143 */         throw new MessagingException("Getting html content failed", e);
/*     */       }
/* 145 */     else if (message.isMimeType("text/*"))
/*     */     {
/*     */       try
/*     */       {
/* 149 */         textObject = message.getContent();
/* 150 */         textType = message.getContentType();
/*     */       } catch (IOException e) {
/* 152 */         throw new MessagingException("Getting text/* content failed", e);
/*     */       }
/*     */     }
/* 154 */     else if (message.isMimeType("multipart/*"))
/*     */     {
/*     */       try
/*     */       {
/* 162 */         Multipart mp = (Multipart)message.getContent();
/* 163 */         for (int i = 0; i < mp.getCount(); i++) {
/* 164 */           BodyPart bp = mp.getBodyPart(i);
/* 165 */           if ((bp.isMimeType("text/plain")) && (textObject == null)) {
/* 166 */             textObject = bp.getContent();
/* 167 */             textType = bp.getContentType();
/* 168 */           } else if ((bp.isMimeType("text/html")) && (htmlObject == null)) {
/* 169 */             htmlObject = bp.getContent();
/* 170 */             htmlType = bp.getContentType();
/*     */           } else {
/* 172 */             if (otherMessageParts == null) {
/* 173 */               String type = mp.getContentType();
/* 174 */               assert (type.startsWith("multipart/"));
/* 175 */               otherMessageParts = new MimeMultipart(type.substring("multipart/".length()));
/*     */             }
/*     */ 
/* 178 */             otherMessageParts.addBodyPart(bp);
/*     */           }
/*     */         }
/*     */       } catch (IOException e) {
/* 182 */         throw new MessagingException("Getting multipart content failed", e);
/*     */       }
/*     */     }
/*     */ 
/* 186 */     if (textObject != null) {
/* 187 */       if ((textObject instanceof String))
/* 188 */         msg.setTextBody((String)textObject);
/* 189 */       else if ((textObject instanceof InputStream))
/*     */         try {
/* 191 */           msg.setTextBody(inputStreamToString((InputStream)textObject, textType));
/*     */         } catch (IOException e) {
/* 193 */           throw new MessagingException("Stringifying text body failed", e);
/*     */         }
/*     */       else {
/* 196 */         throw new MessagingException("Converting text body failed");
/*     */       }
/*     */     }
/*     */ 
/* 200 */     if (htmlObject != null) {
/* 201 */       if ((htmlObject instanceof String))
/*     */       {
/* 203 */         msg.setHtmlBody((String)htmlObject);
/* 204 */       } else if ((htmlObject instanceof InputStream))
/*     */         try {
/* 206 */           msg.setHtmlBody(inputStreamToString((InputStream)htmlObject, htmlType));
/*     */         } catch (IOException e) {
/* 208 */           throw new MessagingException("Stringifying html body failed", e);
/*     */         }
/*     */       else {
/* 211 */         throw new MessagingException("Converting html body failed");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 217 */     if (otherMessageParts != null) {
/* 218 */       ArrayList attachments = new ArrayList(otherMessageParts.getCount());
/*     */ 
/* 220 */       for (int i = 0; i < otherMessageParts.getCount(); i++) { BodyPart bp = otherMessageParts.getBodyPart(i);
/* 222 */         String name = bp.getFileName();
/*     */         byte[] data;
/*     */         try { Object o = bp.getContent();
/*     */           byte[] data;
/* 226 */           if ((o instanceof InputStream)) {
/* 227 */             data = inputStreamToBytes((InputStream)o);
/*     */           }
/*     */           else
/*     */           {
/*     */             byte[] data;
/* 228 */             if ((o instanceof String))
/* 229 */               data = ((String)o).getBytes();
/*     */             else
/* 231 */               throw new MessagingException("Converting attachment data failed");
/*     */           }
/*     */         } catch (IOException e) {
/* 234 */           throw new MessagingException("Extracting attachment data failed", e);
/*     */         }
/* 236 */         MailService.Attachment attachment = new MailService.Attachment(name, data);
/*     */ 
/* 238 */         attachments.add(attachment);
/*     */       }
/* 240 */       msg.setAttachments(attachments);
/*     */     }
/*     */     try
/*     */     {
/* 244 */       if (toAdmins)
/* 245 */         service.sendToAdmins(msg);
/*     */       else
/* 247 */         service.send(msg);
/*     */     }
/*     */     catch (IOException e) {
/* 250 */       notifyTransportListeners(2, new Address[0], addresses, new Address[0], message);
/*     */ 
/* 253 */       throw new SendFailedException("MailService IO failed", e);
/*     */     } catch (IllegalArgumentException e) {
/* 255 */       throw new MessagingException("Illegal Arguments", e);
/*     */     }
/*     */ 
/* 258 */     notifyTransportListeners(1, addresses, new Address[0], new Address[0], message);
/*     */   }
/*     */ 
/*     */   private Collection<String> convertAddressFields(Address[] targetAddrs, Set<String> allAddrs)
/*     */   {
/* 273 */     if ((targetAddrs == null) || (targetAddrs.length == 0)) {
/* 274 */       return null;
/*     */     }
/* 276 */     ArrayList ourAddrs = new ArrayList(targetAddrs.length);
/* 277 */     for (Address addr : targetAddrs) {
/* 278 */       String email = addr.toString();
/* 279 */       if (allAddrs.contains(email)) {
/* 280 */         ourAddrs.add(email);
/*     */       }
/*     */     }
/* 283 */     return ourAddrs;
/*     */   }
/*     */ 
/*     */   private String inputStreamToString(InputStream in, String type)
/*     */     throws IOException
/*     */   {
/* 295 */     String charset = null;
/* 296 */     String[] args = type.split(";");
/* 297 */     for (String arg : args) {
/* 298 */       if (arg.trim().startsWith("charset=")) {
/* 299 */         charset = arg.split("=")[1];
/* 300 */         break;
/*     */       }
/*     */     }
/* 303 */     if (charset != null) {
/* 304 */       return new String(inputStreamToBytes(in), charset);
/*     */     }
/* 306 */     return new String(inputStreamToBytes(in));
/*     */   }
/*     */ 
/*     */   private byte[] inputStreamToBytes(InputStream in)
/*     */     throws IOException
/*     */   {
/* 318 */     byte[] bytes = new byte[in.available()];
/* 319 */     int count = in.read(bytes);
/* 320 */     return bytes;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.mail.stdimpl.GMTransport
 * JD-Core Version:    0.6.0
 */