/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Comparator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(emulated=true)
/*     */ public final class TreeMultiset<E> extends AbstractMapBasedMultiset<E>
/*     */ {
/*     */ 
/*     */   @GwtIncompatible("not needed in emulated source")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <E extends Comparable> TreeMultiset<E> create()
/*     */   {
/*  72 */     return new TreeMultiset();
/*     */   }
/*     */ 
/*     */   public static <E> TreeMultiset<E> create(Comparator<? super E> comparator)
/*     */   {
/*  89 */     return new TreeMultiset(comparator);
/*     */   }
/*     */ 
/*     */   public static <E extends Comparable> TreeMultiset<E> create(Iterable<? extends E> elements)
/*     */   {
/* 103 */     TreeMultiset multiset = create();
/* 104 */     Iterables.addAll(multiset, elements);
/* 105 */     return multiset;
/*     */   }
/*     */ 
/*     */   private TreeMultiset() {
/* 109 */     super(new TreeMap());
/*     */   }
/*     */ 
/*     */   private TreeMultiset(Comparator<? super E> comparator) {
/* 113 */     super(new TreeMap(comparator));
/*     */   }
/*     */ 
/*     */   public SortedSet<E> elementSet()
/*     */   {
/* 123 */     return (SortedSet)super.elementSet();
/*     */   }
/*     */ 
/*     */   public int count(@Nullable Object element) {
/*     */     try {
/* 128 */       return super.count(element);
/*     */     } catch (NullPointerException e) {
/* 130 */       return 0; } catch (ClassCastException e) {
/*     */     }
/* 132 */     return 0;
/*     */   }
/*     */ 
/*     */   Set<E> createElementSet()
/*     */   {
/* 137 */     return new SortedMapBasedElementSet((SortedMap)backingMap());
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 201 */     stream.defaultWriteObject();
/* 202 */     stream.writeObject(elementSet().comparator());
/* 203 */     Serialization.writeMultiset(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 209 */     stream.defaultReadObject();
/*     */ 
/* 211 */     Comparator comparator = (Comparator)stream.readObject();
/*     */ 
/* 213 */     setBackingMap(new TreeMap(comparator));
/* 214 */     Serialization.populateMultiset(this, stream);
/*     */   }
/*     */ 
/*     */   private class SortedMapBasedElementSet extends AbstractMapBasedMultiset<E>.MapBasedElementSet
/*     */     implements SortedSet<E>
/*     */   {
/*     */     SortedMapBasedElementSet()
/*     */     {
/* 145 */       super(map);
/*     */     }
/*     */ 
/*     */     SortedMap<E, AtomicInteger> sortedMap() {
/* 149 */       return (SortedMap)getMap();
/*     */     }
/*     */ 
/*     */     public Comparator<? super E> comparator() {
/* 153 */       return sortedMap().comparator();
/*     */     }
/*     */ 
/*     */     public E first() {
/* 157 */       return sortedMap().firstKey();
/*     */     }
/*     */ 
/*     */     public E last() {
/* 161 */       return sortedMap().lastKey();
/*     */     }
/*     */ 
/*     */     public SortedSet<E> headSet(E toElement) {
/* 165 */       return new SortedMapBasedElementSet(TreeMultiset.this, sortedMap().headMap(toElement));
/*     */     }
/*     */ 
/*     */     public SortedSet<E> subSet(E fromElement, E toElement) {
/* 169 */       return new SortedMapBasedElementSet(TreeMultiset.this, sortedMap().subMap(fromElement, toElement));
/*     */     }
/*     */ 
/*     */     public SortedSet<E> tailSet(E fromElement)
/*     */     {
/* 174 */       return new SortedMapBasedElementSet(TreeMultiset.this, sortedMap().tailMap(fromElement));
/*     */     }
/*     */ 
/*     */     public boolean remove(Object element) {
/*     */       try {
/* 179 */         return super.remove(element);
/*     */       } catch (NullPointerException e) {
/* 181 */         return false; } catch (ClassCastException e) {
/*     */       }
/* 183 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.TreeMultiset
 * JD-Core Version:    0.6.0
 */