/*      */ package com.google.appengine.repackaged.com.google.common.base;
/*      */ 
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import java.io.IOException;
/*      */ 
/*      */ @GoogleInternal
/*      */ @GwtCompatible
/*      */ public final class CharEscapers
/*      */ {
/*   32 */   private static final CharEscaper NULL_ESCAPER = new CharEscaper()
/*      */   {
/*      */     public String escape(String string) {
/*   35 */       Preconditions.checkNotNull(string);
/*   36 */       return string;
/*      */     }
/*      */ 
/*      */     public Appendable escape(Appendable out)
/*      */     {
/*   41 */       Preconditions.checkNotNull(out);
/*      */ 
/*   46 */       return new Appendable(out) {
/*      */         public Appendable append(CharSequence csq) throws IOException {
/*   48 */           Preconditions.checkNotNull(csq);
/*   49 */           this.val$out.append(csq);
/*   50 */           return this;
/*      */         }
/*      */ 
/*      */         public Appendable append(CharSequence csq, int start, int end) throws IOException
/*      */         {
/*   55 */           Preconditions.checkNotNull(csq);
/*   56 */           this.val$out.append(csq, start, end);
/*   57 */           return this;
/*      */         }
/*      */ 
/*      */         public Appendable append(char c) throws IOException {
/*   61 */           this.val$out.append(c);
/*   62 */           return this;
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     protected char[] escape(char c) {
/*   69 */       return null;
/*      */     }
/*   32 */   };
/*      */ 
/*   98 */   private static final CharEscaper XML_ESCAPER = newBasicXmlEscapeBuilder().addEscape('"', "&quot;").addEscape('\'', "&apos;").toEscaper();
/*      */ 
/*  125 */   private static final CharEscaper XML_CONTENT_ESCAPER = newBasicXmlEscapeBuilder().toEscaper();
/*      */ 
/*  420 */   private static final CharEscaper ASCII_HTML_ESCAPER = new CharEscaperBuilder().addEscape('"', "&quot;").addEscape('\'', "&#39;").addEscape('&', "&amp;").addEscape('<', "&lt;").addEscape('>', "&gt;").toEscaper();
/*      */ 
/*  629 */   private static final Escaper URI_ESCAPER = new PercentEscaper("-_.*", true);
/*      */ 
/*  632 */   private static final Escaper URI_ESCAPER_NO_PLUS = new PercentEscaper("-_.*", false);
/*      */ 
/*  635 */   private static final Escaper URI_PATH_ESCAPER = new PercentEscaper("-_.!~*'()@:$&,;=", false);
/*      */ 
/*  638 */   private static final Escaper URI_QUERY_STRING_ESCAPER = new PercentEscaper("-_.!~*'()@:$,;/?:", false);
/*      */ 
/*  641 */   private static final Escaper URI_QUERY_STRING_ESCAPER_WITH_PLUS = new PercentEscaper("-_.!~*'()@:$,;/?:", true);
/*      */ 
/*  684 */   private static final Escaper CPP_URI_ESCAPER = new PercentEscaper("!()*-._~,/:", true);
/*      */ 
/*  706 */   private static final CharEscaper JAVA_STRING_ESCAPER = new JavaCharEscaper(new CharEscaperBuilder().addEscape('\b', "\\b").addEscape('\f', "\\f").addEscape('\n', "\\n").addEscape('\r', "\\r").addEscape('\t', "\\t").addEscape('"', "\\\"").addEscape('\\', "\\\\").toArray());
/*      */ 
/*  736 */   private static final CharEscaper JAVA_CHAR_ESCAPER = new JavaCharEscaper(new CharEscaperBuilder().addEscape('\b', "\\b").addEscape('\f', "\\f").addEscape('\n', "\\n").addEscape('\r', "\\r").addEscape('\t', "\\t").addEscape('\'', "\\'").addEscape('"', "\\\"").addEscape('\\', "\\\\").toArray());
/*      */ 
/*  762 */   private static final CharEscaper JAVA_STRING_UNICODE_ESCAPER = new CharEscaper()
/*      */   {
/*      */     protected char[] escape(char c) {
/*  765 */       if (c <= '') {
/*  766 */         return null;
/*      */       }
/*      */ 
/*  769 */       char[] r = new char[6];
/*  770 */       r[5] = CharEscapers.access$100()[(c & 0xF)];
/*  771 */       c = (char)(c >>> '\004');
/*  772 */       r[4] = CharEscapers.access$100()[(c & 0xF)];
/*  773 */       c = (char)(c >>> '\004');
/*  774 */       r[3] = CharEscapers.access$100()[(c & 0xF)];
/*  775 */       c = (char)(c >>> '\004');
/*  776 */       r[2] = CharEscapers.access$100()[(c & 0xF)];
/*  777 */       r[1] = 'u';
/*  778 */       r[0] = '\\';
/*  779 */       return r;
/*      */     }
/*  762 */   };
/*      */ 
/*  797 */   private static final CharEscaper PYTHON_ESCAPER = new CharEscaperBuilder().addEscape('\n', "\\n").addEscape('\r', "\\r").addEscape('\t', "\\t").addEscape('\\', "\\\\").addEscape('"', "\\\"").addEscape('\'', "\\'").toEscaper();
/*      */ 
/*  821 */   private static final CharEscaper JAVASCRIPT_ESCAPER = new JavascriptCharEscaper(new CharEscaperBuilder().addEscape('\'', "\\x27").addEscape('"', "\\x22").addEscape('<', "\\x3c").addEscape('=', "\\x3d").addEscape('>', "\\x3e").addEscape('&', "\\x26").addEscape('\b', "\\b").addEscape('\t', "\\t").addEscape('\n', "\\n").addEscape('\f', "\\f").addEscape('\r', "\\r").addEscape('\\', "\\\\").toArray());
/*      */ 
/* 1093 */   private static final char[] HEX_DIGITS = "0123456789abcdef".toCharArray();
/*      */ 
/*      */   public static CharEscaper nullEscaper()
/*      */   {
/*   77 */     return NULL_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper xmlEscaper()
/*      */   {
/*   89 */     return XML_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper xmlContentEscaper()
/*      */   {
/*  114 */     return XML_CONTENT_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper htmlEscaper()
/*      */   {
/*  139 */     return HtmlEscaperHolder.HTML_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper asciiHtmlEscaper()
/*      */   {
/*  412 */     return ASCII_HTML_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static Escaper uriEscaper()
/*      */   {
/*  464 */     return uriEscaper(true);
/*      */   }
/*      */ 
/*      */   public static Escaper uriPathEscaper()
/*      */   {
/*  494 */     return URI_PATH_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static Escaper uriQueryStringEscaper()
/*      */   {
/*  537 */     return uriQueryStringEscaper(false);
/*      */   }
/*      */ 
/*      */   public static Escaper uriEscaper(boolean plusForSpace)
/*      */   {
/*  574 */     return plusForSpace ? URI_ESCAPER : URI_ESCAPER_NO_PLUS;
/*      */   }
/*      */ 
/*      */   public static Escaper uriQueryStringEscaper(boolean plusForSpace)
/*      */   {
/*  625 */     return plusForSpace ? URI_QUERY_STRING_ESCAPER_WITH_PLUS : URI_QUERY_STRING_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static Escaper cppUriEscaper()
/*      */   {
/*  675 */     return CPP_URI_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper javaStringEscaper()
/*      */   {
/*  696 */     return JAVA_STRING_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper javaCharEscaper()
/*      */   {
/*  724 */     return JAVA_CHAR_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper javaStringUnicodeEscaper()
/*      */   {
/*  754 */     return JAVA_STRING_UNICODE_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper pythonEscaper()
/*      */   {
/*  789 */     return PYTHON_ESCAPER;
/*      */   }
/*      */ 
/*      */   public static CharEscaper javascriptEscaper()
/*      */   {
/*  814 */     return JAVASCRIPT_ESCAPER;
/*      */   }
/*      */ 
/*      */   private static CharEscaperBuilder newBasicXmlEscapeBuilder()
/*      */   {
/*  838 */     return new CharEscaperBuilder().addEscape('&', "&amp;").addEscape('<', "&lt;").addEscape('>', "&gt;").addEscapes(new char[] { '\000', '\001', '\002', '\003', '\004', '\005', '\006', '\007', '\b', '\013', '\f', '\016', '\017', '\020', '\021', '\022', '\023', '\024', '\025', '\026', '\027', '\030', '\031', '\032', '\033', '\034', '\035', '\036', '\037' }, "");
/*      */   }
/*      */ 
/*      */   public static CharEscaper fallThrough(CharEscaper primary, CharEscaper secondary)
/*      */   {
/*  873 */     Preconditions.checkNotNull(primary);
/*  874 */     Preconditions.checkNotNull(secondary);
/*  875 */     return new FallThroughCharEscaper(primary, secondary);
/*      */   }
/*      */ 
/*      */   private static class FallThroughCharEscaper extends CharEscaper
/*      */   {
/*      */     private final CharEscaper primary;
/*      */     private final CharEscaper secondary;
/*      */ 
/*      */     public FallThroughCharEscaper(CharEscaper primary, CharEscaper secondary)
/*      */     {
/* 1079 */       this.primary = primary;
/* 1080 */       this.secondary = secondary;
/*      */     }
/*      */ 
/*      */     protected char[] escape(char c)
/*      */     {
/* 1085 */       char[] result = this.primary.escape(c);
/* 1086 */       if (result == null) {
/* 1087 */         result = this.secondary.escape(c);
/*      */       }
/* 1089 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class HtmlCharEscaper extends CharEscapers.FastCharEscaper
/*      */   {
/*      */     public HtmlCharEscaper(char[][] replacements)
/*      */     {
/* 1026 */       super('\000', '~');
/*      */     }
/*      */ 
/*      */     protected char[] escape(char c)
/*      */     {
/* 1031 */       if (c < this.replacementLength) {
/* 1032 */         char[] r = this.replacements[c];
/* 1033 */         if (r != null) {
/* 1034 */           return r;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1040 */       if (c <= this.safeMax)
/* 1041 */         return null;
/*      */       int index;
/*      */       int index;
/* 1045 */       if (c < 'Ϩ') {
/* 1046 */         index = 4;
/*      */       }
/*      */       else
/*      */       {
/*      */         int index;
/* 1047 */         if (c < '✐')
/* 1048 */           index = 5;
/*      */         else
/* 1050 */           index = 6;
/*      */       }
/* 1052 */       char[] result = new char[index + 2];
/* 1053 */       result[0] = '&';
/* 1054 */       result[1] = '#';
/* 1055 */       result[(index + 1)] = ';';
/*      */ 
/* 1059 */       int intValue = c;
/* 1060 */       for (; index > 1; index--) {
/* 1061 */         result[index] = CharEscapers.access$100()[(intValue % 10)];
/* 1062 */         intValue /= 10;
/*      */       }
/* 1064 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class JavascriptCharEscaper extends CharEscapers.FastCharEscaper
/*      */   {
/*      */     public JavascriptCharEscaper(char[][] replacements)
/*      */     {
/*  975 */       super(' ', '~');
/*      */     }
/*      */ 
/*      */     protected char[] escape(char c)
/*      */     {
/*  980 */       if (c < this.replacementLength) {
/*  981 */         char[] r = this.replacements[c];
/*  982 */         if (r != null) {
/*  983 */           return r;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  988 */       if ((this.safeMin <= c) && (c <= this.safeMax)) {
/*  989 */         return null;
/*      */       }
/*      */ 
/*  993 */       if (c < 'Ā') {
/*  994 */         char[] r = new char[4];
/*  995 */         r[3] = CharEscapers.access$100()[(c & 0xF)];
/*  996 */         c = (char)(c >>> '\004');
/*  997 */         r[2] = CharEscapers.access$100()[(c & 0xF)];
/*  998 */         r[1] = 'x';
/*  999 */         r[0] = '\\';
/* 1000 */         return r;
/*      */       }
/*      */ 
/* 1004 */       char[] r = new char[6];
/* 1005 */       r[5] = CharEscapers.access$100()[(c & 0xF)];
/* 1006 */       c = (char)(c >>> '\004');
/* 1007 */       r[4] = CharEscapers.access$100()[(c & 0xF)];
/* 1008 */       c = (char)(c >>> '\004');
/* 1009 */       r[3] = CharEscapers.access$100()[(c & 0xF)];
/* 1010 */       c = (char)(c >>> '\004');
/* 1011 */       r[2] = CharEscapers.access$100()[(c & 0xF)];
/* 1012 */       r[1] = 'u';
/* 1013 */       r[0] = '\\';
/* 1014 */       return r;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class JavaCharEscaper extends CharEscapers.FastCharEscaper
/*      */   {
/*      */     public JavaCharEscaper(char[][] replacements)
/*      */     {
/*  921 */       super(' ', '~');
/*      */     }
/*      */ 
/*      */     protected char[] escape(char c)
/*      */     {
/*  926 */       if (c < this.replacementLength) {
/*  927 */         char[] r = this.replacements[c];
/*  928 */         if (r != null) {
/*  929 */           return r;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  934 */       if ((this.safeMin <= c) && (c <= this.safeMax)) {
/*  935 */         return null;
/*      */       }
/*      */ 
/*  938 */       if (c <= 'ÿ')
/*      */       {
/*  941 */         char[] r = new char[4];
/*  942 */         r[0] = '\\';
/*  943 */         r[3] = CharEscapers.access$100()[(c & 0x7)];
/*  944 */         c = (char)(c >>> '\003');
/*  945 */         r[2] = CharEscapers.access$100()[(c & 0x7)];
/*  946 */         c = (char)(c >>> '\003');
/*  947 */         r[1] = CharEscapers.access$100()[(c & 0x7)];
/*  948 */         return r;
/*      */       }
/*      */ 
/*  953 */       char[] r = new char[6];
/*  954 */       r[0] = '\\';
/*  955 */       r[1] = 'u';
/*  956 */       r[5] = CharEscapers.access$100()[(c & 0xF)];
/*  957 */       c = (char)(c >>> '\004');
/*  958 */       r[4] = CharEscapers.access$100()[(c & 0xF)];
/*  959 */       c = (char)(c >>> '\004');
/*  960 */       r[3] = CharEscapers.access$100()[(c & 0xF)];
/*  961 */       c = (char)(c >>> '\004');
/*  962 */       r[2] = CharEscapers.access$100()[(c & 0xF)];
/*  963 */       return r;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract class FastCharEscaper extends CharEscaper
/*      */   {
/*      */     protected final char[][] replacements;
/*      */     protected final int replacementLength;
/*      */     protected final char safeMin;
/*      */     protected final char safeMax;
/*      */ 
/*      */     public FastCharEscaper(char[][] replacements, char safeMin, char safeMax)
/*      */     {
/*  893 */       this.replacements = replacements;
/*  894 */       this.replacementLength = replacements.length;
/*  895 */       this.safeMin = safeMin;
/*  896 */       this.safeMax = safeMax;
/*      */     }
/*      */ 
/*      */     public String escape(String s)
/*      */     {
/*  901 */       int slen = s.length();
/*  902 */       for (int index = 0; index < slen; index++) {
/*  903 */         char c = s.charAt(index);
/*  904 */         if (((c < this.replacementLength) && (this.replacements[c] != null)) || (c < this.safeMin) || (c > this.safeMax))
/*      */         {
/*  906 */           return escapeSlow(s, index);
/*      */         }
/*      */       }
/*  909 */       return s;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class HtmlEscaperHolder
/*      */   {
/*  146 */     private static final CharEscaper HTML_ESCAPER = new CharEscapers.HtmlCharEscaper(new CharEscaperBuilder().addEscape('"', "&quot;").addEscape('\'', "&#39;").addEscape('&', "&amp;").addEscape('<', "&lt;").addEscape('>', "&gt;").addEscape(' ', "&nbsp;").addEscape('¡', "&iexcl;").addEscape('¢', "&cent;").addEscape('£', "&pound;").addEscape('¤', "&curren;").addEscape('¥', "&yen;").addEscape('¦', "&brvbar;").addEscape('§', "&sect;").addEscape('¨', "&uml;").addEscape('©', "&copy;").addEscape('ª', "&ordf;").addEscape('«', "&laquo;").addEscape('¬', "&not;").addEscape('­', "&shy;").addEscape('®', "&reg;").addEscape('¯', "&macr;").addEscape('°', "&deg;").addEscape('±', "&plusmn;").addEscape('²', "&sup2;").addEscape('³', "&sup3;").addEscape('´', "&acute;").addEscape('µ', "&micro;").addEscape('¶', "&para;").addEscape('·', "&middot;").addEscape('¸', "&cedil;").addEscape('¹', "&sup1;").addEscape('º', "&ordm;").addEscape('»', "&raquo;").addEscape('¼', "&frac14;").addEscape('½', "&frac12;").addEscape('¾', "&frac34;").addEscape('¿', "&iquest;").addEscape('À', "&Agrave;").addEscape('Á', "&Aacute;").addEscape('Â', "&Acirc;").addEscape('Ã', "&Atilde;").addEscape('Ä', "&Auml;").addEscape('Å', "&Aring;").addEscape('Æ', "&AElig;").addEscape('Ç', "&Ccedil;").addEscape('È', "&Egrave;").addEscape('É', "&Eacute;").addEscape('Ê', "&Ecirc;").addEscape('Ë', "&Euml;").addEscape('Ì', "&Igrave;").addEscape('Í', "&Iacute;").addEscape('Î', "&Icirc;").addEscape('Ï', "&Iuml;").addEscape('Ð', "&ETH;").addEscape('Ñ', "&Ntilde;").addEscape('Ò', "&Ograve;").addEscape('Ó', "&Oacute;").addEscape('Ô', "&Ocirc;").addEscape('Õ', "&Otilde;").addEscape('Ö', "&Ouml;").addEscape('×', "&times;").addEscape('Ø', "&Oslash;").addEscape('Ù', "&Ugrave;").addEscape('Ú', "&Uacute;").addEscape('Û', "&Ucirc;").addEscape('Ü', "&Uuml;").addEscape('Ý', "&Yacute;").addEscape('Þ', "&THORN;").addEscape('ß', "&szlig;").addEscape('à', "&agrave;").addEscape('á', "&aacute;").addEscape('â', "&acirc;").addEscape('ã', "&atilde;").addEscape('ä', "&auml;").addEscape('å', "&aring;").addEscape('æ', "&aelig;").addEscape('ç', "&ccedil;").addEscape('è', "&egrave;").addEscape('é', "&eacute;").addEscape('ê', "&ecirc;").addEscape('ë', "&euml;").addEscape('ì', "&igrave;").addEscape('í', "&iacute;").addEscape('î', "&icirc;").addEscape('ï', "&iuml;").addEscape('ð', "&eth;").addEscape('ñ', "&ntilde;").addEscape('ò', "&ograve;").addEscape('ó', "&oacute;").addEscape('ô', "&ocirc;").addEscape('õ', "&otilde;").addEscape('ö', "&ouml;").addEscape('÷', "&divide;").addEscape('ø', "&oslash;").addEscape('ù', "&ugrave;").addEscape('ú', "&uacute;").addEscape('û', "&ucirc;").addEscape('ü', "&uuml;").addEscape('ý', "&yacute;").addEscape('þ', "&thorn;").addEscape('ÿ', "&yuml;").addEscape('Œ', "&OElig;").addEscape('œ', "&oelig;").addEscape('Š', "&Scaron;").addEscape('š', "&scaron;").addEscape('Ÿ', "&Yuml;").addEscape('ƒ', "&fnof;").addEscape('ˆ', "&circ;").addEscape('˜', "&tilde;").addEscape('Α', "&Alpha;").addEscape('Β', "&Beta;").addEscape('Γ', "&Gamma;").addEscape('Δ', "&Delta;").addEscape('Ε', "&Epsilon;").addEscape('Ζ', "&Zeta;").addEscape('Η', "&Eta;").addEscape('Θ', "&Theta;").addEscape('Ι', "&Iota;").addEscape('Κ', "&Kappa;").addEscape('Λ', "&Lambda;").addEscape('Μ', "&Mu;").addEscape('Ν', "&Nu;").addEscape('Ξ', "&Xi;").addEscape('Ο', "&Omicron;").addEscape('Π', "&Pi;").addEscape('Ρ', "&Rho;").addEscape('Σ', "&Sigma;").addEscape('Τ', "&Tau;").addEscape('Υ', "&Upsilon;").addEscape('Φ', "&Phi;").addEscape('Χ', "&Chi;").addEscape('Ψ', "&Psi;").addEscape('Ω', "&Omega;").addEscape('α', "&alpha;").addEscape('β', "&beta;").addEscape('γ', "&gamma;").addEscape('δ', "&delta;").addEscape('ε', "&epsilon;").addEscape('ζ', "&zeta;").addEscape('η', "&eta;").addEscape('θ', "&theta;").addEscape('ι', "&iota;").addEscape('κ', "&kappa;").addEscape('λ', "&lambda;").addEscape('μ', "&mu;").addEscape('ν', "&nu;").addEscape('ξ', "&xi;").addEscape('ο', "&omicron;").addEscape('π', "&pi;").addEscape('ρ', "&rho;").addEscape('ς', "&sigmaf;").addEscape('σ', "&sigma;").addEscape('τ', "&tau;").addEscape('υ', "&upsilon;").addEscape('φ', "&phi;").addEscape('χ', "&chi;").addEscape('ψ', "&psi;").addEscape('ω', "&omega;").addEscape('ϑ', "&thetasym;").addEscape('ϒ', "&upsih;").addEscape('ϖ', "&piv;").addEscape(' ', "&ensp;").addEscape(' ', "&emsp;").addEscape(' ', "&thinsp;").addEscape('‌', "&zwnj;").addEscape('‍', "&zwj;").addEscape('‎', "&lrm;").addEscape('‏', "&rlm;").addEscape('–', "&ndash;").addEscape('—', "&mdash;").addEscape('‘', "&lsquo;").addEscape('’', "&rsquo;").addEscape('‚', "&sbquo;").addEscape('“', "&ldquo;").addEscape('”', "&rdquo;").addEscape('„', "&bdquo;").addEscape('†', "&dagger;").addEscape('‡', "&Dagger;").addEscape('•', "&bull;").addEscape('…', "&hellip;").addEscape('‰', "&permil;").addEscape('′', "&prime;").addEscape('″', "&Prime;").addEscape('‹', "&lsaquo;").addEscape('›', "&rsaquo;").addEscape('‾', "&oline;").addEscape('⁄', "&frasl;").addEscape('€', "&euro;").addEscape('ℑ', "&image;").addEscape('℘', "&weierp;").addEscape('ℜ', "&real;").addEscape('™', "&trade;").addEscape('ℵ', "&alefsym;").addEscape('←', "&larr;").addEscape('↑', "&uarr;").addEscape('→', "&rarr;").addEscape('↓', "&darr;").addEscape('↔', "&harr;").addEscape('↵', "&crarr;").addEscape('⇐', "&lArr;").addEscape('⇑', "&uArr;").addEscape('⇒', "&rArr;").addEscape('⇓', "&dArr;").addEscape('⇔', "&hArr;").addEscape('∀', "&forall;").addEscape('∂', "&part;").addEscape('∃', "&exist;").addEscape('∅', "&empty;").addEscape('∇', "&nabla;").addEscape('∈', "&isin;").addEscape('∉', "&notin;").addEscape('∋', "&ni;").addEscape('∏', "&prod;").addEscape('∑', "&sum;").addEscape('−', "&minus;").addEscape('∗', "&lowast;").addEscape('√', "&radic;").addEscape('∝', "&prop;").addEscape('∞', "&infin;").addEscape('∠', "&ang;").addEscape('∧', "&and;").addEscape('∨', "&or;").addEscape('∩', "&cap;").addEscape('∪', "&cup;").addEscape('∫', "&int;").addEscape('∴', "&there4;").addEscape('∼', "&sim;").addEscape('≅', "&cong;").addEscape('≈', "&asymp;").addEscape('≠', "&ne;").addEscape('≡', "&equiv;").addEscape('≤', "&le;").addEscape('≥', "&ge;").addEscape('⊂', "&sub;").addEscape('⊃', "&sup;").addEscape('⊄', "&nsub;").addEscape('⊆', "&sube;").addEscape('⊇', "&supe;").addEscape('⊕', "&oplus;").addEscape('⊗', "&otimes;").addEscape('⊥', "&perp;").addEscape('⋅', "&sdot;").addEscape('⌈', "&lceil;").addEscape('⌉', "&rceil;").addEscape('⌊', "&lfloor;").addEscape('⌋', "&rfloor;").addEscape('〈', "&lang;").addEscape('〉', "&rang;").addEscape('◊', "&loz;").addEscape('♠', "&spades;").addEscape('♣', "&clubs;").addEscape('♥', "&hearts;").addEscape('♦', "&diams;").toArray());
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.CharEscapers
 * JD-Core Version:    0.6.0
 */