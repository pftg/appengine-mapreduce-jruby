/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.SortedMap;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public class ImmutableSortedMap<K, V> extends ImmutableSortedMapFauxverideShim<K, V>
/*     */   implements SortedMap<K, V>
/*     */ {
/*  64 */   private static final Comparator NATURAL_ORDER = Ordering.natural();
/*  65 */   private static final Map.Entry<?, ?>[] EMPTY_ARRAY = new Map.Entry[0];
/*     */ 
/*  68 */   private static final ImmutableMap<Object, Object> NATURAL_EMPTY_MAP = new ImmutableSortedMap(EMPTY_ARRAY, NATURAL_ORDER);
/*     */   private final transient Map.Entry<K, V>[] entries;
/*     */   private final transient Comparator<? super K> comparator;
/*     */   private final transient int fromIndex;
/*     */   private final transient int toIndex;
/*     */   private transient ImmutableSet<Map.Entry<K, V>> entrySet;
/*     */   private transient ImmutableSortedSet<K> keySet;
/*     */   private transient ImmutableCollection<V> values;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> ImmutableSortedMap<K, V> of()
/*     */   {
/*  77 */     return (ImmutableSortedMap)NATURAL_EMPTY_MAP;
/*     */   }
/*     */ 
/*     */   private static <K, V> ImmutableSortedMap<K, V> emptyMap(Comparator<? super K> comparator)
/*     */   {
/*  82 */     if (NATURAL_ORDER.equals(comparator)) {
/*  83 */       return of();
/*     */     }
/*  85 */     return new ImmutableSortedMap(EMPTY_ARRAY, comparator);
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1)
/*     */   {
/*  94 */     Map.Entry[] entries = { entryOf(k1, v1) };
/*  95 */     return new ImmutableSortedMap(entries, Ordering.natural());
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2)
/*     */   {
/* 107 */     return new Builder(Ordering.natural()).put(k1, v1).put(k2, v2).build();
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*     */   {
/* 120 */     return new Builder(Ordering.natural()).put(k1, v1).put(k2, v2).put(k3, v3).build();
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*     */   {
/* 133 */     return new Builder(Ordering.natural()).put(k1, v1).put(k2, v2).put(k3, v3).put(k4, v4).build();
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*     */   {
/* 146 */     return new Builder(Ordering.natural()).put(k1, v1).put(k2, v2).put(k3, v3).put(k4, v4).put(k5, v5).build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/*     */   {
/* 171 */     Ordering naturalOrder = Ordering.natural();
/* 172 */     return copyOfInternal(map, naturalOrder);
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map, Comparator<? super K> comparator)
/*     */   {
/* 188 */     return copyOfInternal(map, (Comparator)Preconditions.checkNotNull(comparator));
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableSortedMap<K, V> copyOfSorted(SortedMap<K, ? extends V> map)
/*     */   {
/* 205 */     Comparator comparator = map.comparator() == null ? NATURAL_ORDER : map.comparator();
/*     */ 
/* 207 */     return copyOfInternal(map, comparator);
/*     */   }
/*     */ 
/*     */   private static <K, V> ImmutableSortedMap<K, V> copyOfInternal(Map<? extends K, ? extends V> map, Comparator<? super K> comparator)
/*     */   {
/* 212 */     boolean sameComparator = false;
/* 213 */     if ((map instanceof SortedMap)) {
/* 214 */       SortedMap sortedMap = (SortedMap)map;
/* 215 */       Comparator comparator2 = sortedMap.comparator();
/* 216 */       sameComparator = comparator2 == null ? false : comparator == NATURAL_ORDER ? true : comparator.equals(comparator2);
/*     */     }
/*     */ 
/* 221 */     if ((sameComparator) && ((map instanceof ImmutableSortedMap)))
/*     */     {
/* 225 */       ImmutableSortedMap kvMap = (ImmutableSortedMap)map;
/* 226 */       return kvMap;
/*     */     }
/*     */ 
/* 230 */     List list = Lists.newArrayListWithCapacity(map.size());
/* 231 */     for (Map.Entry entry : map.entrySet()) {
/* 232 */       list.add(entryOf(entry.getKey(), entry.getValue()));
/*     */     }
/* 234 */     Map.Entry[] entryArray = (Map.Entry[])list.toArray(new Map.Entry[list.size()]);
/*     */ 
/* 236 */     if (!sameComparator) {
/* 237 */       sortEntries(entryArray, comparator);
/* 238 */       validateEntries(entryArray, comparator);
/*     */     }
/*     */ 
/* 241 */     return new ImmutableSortedMap(entryArray, comparator);
/*     */   }
/*     */ 
/*     */   private static void sortEntries(Map.Entry<?, ?>[] entryArray, Comparator<?> comparator)
/*     */   {
/* 246 */     Comparator entryComparator = new Comparator(comparator) {
/*     */       public int compare(Map.Entry<?, ?> entry1, Map.Entry<?, ?> entry2) {
/* 248 */         return ImmutableSortedSet.unsafeCompare(this.val$comparator, entry1.getKey(), entry2.getKey());
/*     */       }
/*     */     };
/* 252 */     Arrays.sort(entryArray, entryComparator);
/*     */   }
/*     */ 
/*     */   private static void validateEntries(Map.Entry<?, ?>[] entryArray, Comparator<?> comparator)
/*     */   {
/* 257 */     for (int i = 1; i < entryArray.length; i++) {
/* 258 */       if (ImmutableSortedSet.unsafeCompare(comparator, entryArray[(i - 1)].getKey(), entryArray[i].getKey()) != 0)
/*     */         continue;
/* 260 */       throw new IllegalArgumentException("Duplicate keys in mappings " + entryArray[(i - 1)] + " and " + entryArray[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<K>, V> Builder<K, V> naturalOrder()
/*     */   {
/* 278 */     return new Builder(Ordering.natural());
/*     */   }
/*     */ 
/*     */   public static <K, V> Builder<K, V> orderedBy(Comparator<K> comparator)
/*     */   {
/* 290 */     return new Builder(comparator);
/*     */   }
/*     */ 
/*     */   public static <K extends Comparable<K>, V> Builder<K, V> reverseOrder()
/*     */   {
/* 303 */     return new Builder(Ordering.natural().reverse());
/*     */   }
/*     */ 
/*     */   private ImmutableSortedMap(Map.Entry<?, ?>[] entries, Comparator<? super K> comparator, int fromIndex, int toIndex)
/*     */   {
/* 383 */     Map.Entry[] tmp = (Map.Entry[])entries;
/* 384 */     this.entries = tmp;
/* 385 */     this.comparator = comparator;
/* 386 */     this.fromIndex = fromIndex;
/* 387 */     this.toIndex = toIndex;
/*     */   }
/*     */ 
/*     */   ImmutableSortedMap(Map.Entry<?, ?>[] entries, Comparator<? super K> comparator)
/*     */   {
/* 392 */     this(entries, comparator, 0, entries.length);
/*     */   }
/*     */ 
/*     */   public int size() {
/* 396 */     return this.toIndex - this.fromIndex;
/*     */   }
/*     */ 
/*     */   public V get(@Nullable Object key) {
/* 400 */     if (key == null)
/* 401 */       return null;
/*     */     int i;
/*     */     try {
/* 405 */       i = binarySearch(key);
/*     */     } catch (ClassCastException e) {
/* 407 */       return null;
/*     */     }
/* 409 */     return i >= 0 ? this.entries[i].getValue() : null;
/*     */   }
/*     */ 
/*     */   private int binarySearch(Object key) {
/* 413 */     int lower = this.fromIndex;
/* 414 */     int upper = this.toIndex - 1;
/*     */ 
/* 416 */     while (lower <= upper) {
/* 417 */       int middle = lower + (upper - lower) / 2;
/* 418 */       int c = ImmutableSortedSet.unsafeCompare(this.comparator, key, this.entries[middle].getKey());
/*     */ 
/* 420 */       if (c < 0)
/* 421 */         upper = middle - 1;
/* 422 */       else if (c > 0)
/* 423 */         lower = middle + 1;
/*     */       else {
/* 425 */         return middle;
/*     */       }
/*     */     }
/*     */ 
/* 429 */     return -lower - 1;
/*     */   }
/*     */ 
/*     */   public boolean containsValue(@Nullable Object value) {
/* 433 */     if (value == null) {
/* 434 */       return false;
/*     */     }
/* 436 */     for (int i = this.fromIndex; i < this.toIndex; i++) {
/* 437 */       if (this.entries[i].getValue().equals(value)) {
/* 438 */         return true;
/*     */       }
/*     */     }
/* 441 */     return false;
/*     */   }
/*     */ 
/*     */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/*     */   {
/* 451 */     ImmutableSet es = this.entrySet;
/* 452 */     return es == null ? (this.entrySet = createEntrySet()) : es;
/*     */   }
/*     */ 
/*     */   private ImmutableSet<Map.Entry<K, V>> createEntrySet() {
/* 456 */     return isEmpty() ? ImmutableSet.of() : new EntrySet(this);
/*     */   }
/*     */ 
/*     */   public ImmutableSortedSet<K> keySet()
/*     */   {
/* 507 */     ImmutableSortedSet ks = this.keySet;
/* 508 */     return ks == null ? (this.keySet = createKeySet()) : ks;
/*     */   }
/*     */ 
/*     */   private ImmutableSortedSet<K> createKeySet() {
/* 512 */     if (isEmpty()) {
/* 513 */       return ImmutableSortedSet.emptySet(this.comparator);
/*     */     }
/*     */ 
/* 517 */     Object[] array = new Object[size()];
/* 518 */     for (int i = this.fromIndex; i < this.toIndex; i++) {
/* 519 */       array[(i - this.fromIndex)] = this.entries[i].getKey();
/*     */     }
/* 521 */     return new RegularImmutableSortedSet(array, this.comparator);
/*     */   }
/*     */ 
/*     */   public ImmutableCollection<V> values()
/*     */   {
/* 531 */     ImmutableCollection v = this.values;
/* 532 */     return v == null ? (this.values = new Values(this)) : v;
/*     */   }
/*     */ 
/*     */   public Comparator<? super K> comparator()
/*     */   {
/* 585 */     return this.comparator;
/*     */   }
/*     */ 
/*     */   public K firstKey() {
/* 589 */     if (isEmpty()) {
/* 590 */       throw new NoSuchElementException();
/*     */     }
/* 592 */     return this.entries[this.fromIndex].getKey();
/*     */   }
/*     */ 
/*     */   public K lastKey() {
/* 596 */     if (isEmpty()) {
/* 597 */       throw new NoSuchElementException();
/*     */     }
/* 599 */     return this.entries[(this.toIndex - 1)].getKey();
/*     */   }
/*     */ 
/*     */   public ImmutableSortedMap<K, V> headMap(K toKey)
/*     */   {
/* 613 */     int newToIndex = findSubmapIndex(Preconditions.checkNotNull(toKey));
/* 614 */     return createSubmap(this.fromIndex, newToIndex);
/*     */   }
/*     */ 
/*     */   public ImmutableSortedMap<K, V> subMap(K fromKey, K toKey)
/*     */   {
/* 631 */     Preconditions.checkNotNull(fromKey);
/* 632 */     Preconditions.checkNotNull(toKey);
/* 633 */     Preconditions.checkArgument(this.comparator.compare(fromKey, toKey) <= 0);
/* 634 */     int newFromIndex = findSubmapIndex(fromKey);
/* 635 */     int newToIndex = findSubmapIndex(toKey);
/* 636 */     return createSubmap(newFromIndex, newToIndex);
/*     */   }
/*     */ 
/*     */   public ImmutableSortedMap<K, V> tailMap(K fromKey)
/*     */   {
/* 650 */     int newFromIndex = findSubmapIndex(Preconditions.checkNotNull(fromKey));
/* 651 */     return createSubmap(newFromIndex, this.toIndex);
/*     */   }
/*     */ 
/*     */   private int findSubmapIndex(K key) {
/* 655 */     int index = binarySearch(key);
/* 656 */     return index >= 0 ? index : -index - 1;
/*     */   }
/*     */ 
/*     */   private ImmutableSortedMap<K, V> createSubmap(int newFromIndex, int newToIndex)
/*     */   {
/* 661 */     if (newFromIndex < newToIndex) {
/* 662 */       return new ImmutableSortedMap(this.entries, this.comparator, newFromIndex, newToIndex);
/*     */     }
/*     */ 
/* 665 */     return emptyMap(this.comparator);
/*     */   }
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 690 */     return new SerializedForm(this);
/*     */   }
/*     */ 
/*     */   private static class SerializedForm extends ImmutableMap.SerializedForm
/*     */   {
/*     */     private final Comparator<Object> comparator;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SerializedForm(ImmutableSortedMap<?, ?> sortedMap)
/*     */     {
/* 679 */       super();
/* 680 */       this.comparator = sortedMap.comparator();
/*     */     }
/*     */     Object readResolve() {
/* 683 */       ImmutableSortedMap.Builder builder = new ImmutableSortedMap.Builder(this.comparator);
/* 684 */       return createMap(builder);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ValuesSerializedForm<V>
/*     */     implements Serializable
/*     */   {
/*     */     final ImmutableSortedMap<?, V> map;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     ValuesSerializedForm(ImmutableSortedMap<?, V> map)
/*     */     {
/* 570 */       this.map = map;
/*     */     }
/*     */     Object readResolve() {
/* 573 */       return this.map.values();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Values<V> extends ImmutableCollection<V>
/*     */   {
/*     */     private final ImmutableSortedMap<?, V> map;
/*     */ 
/*     */     Values(ImmutableSortedMap<?, V> map)
/*     */     {
/* 540 */       this.map = map;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 544 */       return this.map.size();
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<V> iterator() {
/* 548 */       return new AbstractIterator() {
/* 549 */         int index = ImmutableSortedMap.this.fromIndex;
/*     */ 
/* 551 */         protected V computeNext() { return this.index < ImmutableSortedMap.this.toIndex ? ImmutableSortedMap.this.entries[(this.index++)].getValue() : endOfData();
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public boolean contains(Object target)
/*     */     {
/* 559 */       return this.map.containsValue(target);
/*     */     }
/*     */ 
/*     */     Object writeReplace() {
/* 563 */       return new ImmutableSortedMap.ValuesSerializedForm(this.map);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EntrySetSerializedForm<K, V>
/*     */     implements Serializable
/*     */   {
/*     */     final ImmutableSortedMap<K, V> map;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     EntrySetSerializedForm(ImmutableSortedMap<K, V> map)
/*     */     {
/* 493 */       this.map = map;
/*     */     }
/*     */     Object readResolve() {
/* 496 */       return this.map.entrySet();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EntrySet<K, V> extends ImmutableSet<Map.Entry<K, V>>
/*     */   {
/*     */     final transient ImmutableSortedMap<K, V> map;
/*     */ 
/*     */     EntrySet(ImmutableSortedMap<K, V> map)
/*     */     {
/* 465 */       this.map = map;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 469 */       return this.map.size();
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<Map.Entry<K, V>> iterator() {
/* 473 */       return Iterators.forArray(this.map.entries, this.map.fromIndex, size());
/*     */     }
/*     */ 
/*     */     public boolean contains(Object target) {
/* 477 */       if ((target instanceof Map.Entry)) {
/* 478 */         Map.Entry entry = (Map.Entry)target;
/* 479 */         Object mappedValue = this.map.get(entry.getKey());
/* 480 */         return (mappedValue != null) && (mappedValue.equals(entry.getValue()));
/*     */       }
/* 482 */       return false;
/*     */     }
/*     */ 
/*     */     Object writeReplace() {
/* 486 */       return new ImmutableSortedMap.EntrySetSerializedForm(this.map);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Builder<K, V> extends ImmutableMap.Builder<K, V>
/*     */   {
/*     */     private final Comparator<? super K> comparator;
/*     */ 
/*     */     public Builder(Comparator<? super K> comparator)
/*     */     {
/* 332 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/*     */     }
/*     */ 
/*     */     public Builder<K, V> put(K key, V value)
/*     */     {
/* 341 */       this.entries.add(ImmutableMap.entryOf(key, value));
/* 342 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/*     */     {
/* 353 */       for (Map.Entry entry : map.entrySet()) {
/* 354 */         put(entry.getKey(), entry.getValue());
/*     */       }
/* 356 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableSortedMap<K, V> build()
/*     */     {
/* 366 */       Map.Entry[] entryArray = (Map.Entry[])this.entries.toArray(new Map.Entry[this.entries.size()]);
/*     */ 
/* 368 */       ImmutableSortedMap.access$000(entryArray, this.comparator);
/* 369 */       ImmutableSortedMap.access$100(entryArray, this.comparator);
/* 370 */       return new ImmutableSortedMap(entryArray, this.comparator);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableSortedMap
 * JD-Core Version:    0.6.0
 */