/*    */ package com.google.appengine.api.channel;
/*    */ 
/*    */ public final class ChannelMessage
/*    */ {
/*    */   private final String applicationKey;
/*    */   private final String message;
/*    */ 
/*    */   public ChannelMessage(String applicationKey, String message)
/*    */   {
/* 24 */     this.applicationKey = applicationKey;
/* 25 */     this.message = message;
/*    */   }
/*    */ 
/*    */   public String getApplicationKey() {
/* 29 */     return this.applicationKey;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 33 */     return this.message;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.channel.ChannelMessage
 * JD-Core Version:    0.6.0
 */