/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Suppliers
/*     */ {
/*     */   public static <F, T> Supplier<T> compose(Function<? super F, T> function, Supplier<F> supplier)
/*     */   {
/*  50 */     Preconditions.checkNotNull(function);
/*  51 */     Preconditions.checkNotNull(supplier);
/*  52 */     return new SupplierComposition(function, supplier);
/*     */   }
/*     */ 
/*     */   public static <T> Supplier<T> memoize(Supplier<T> delegate)
/*     */   {
/*  81 */     return new MemoizingSupplier((Supplier)Preconditions.checkNotNull(delegate));
/*     */   }
/*     */ 
/*     */   public static <T> Supplier<T> memoizeWithExpiration(Supplier<T> delegate, long duration, TimeUnit unit)
/*     */   {
/* 125 */     return new ExpiringMemoizingSupplier(delegate, duration, unit);
/*     */   }
/*     */ 
/*     */   public static <T> Supplier<T> ofInstance(@Nullable T instance)
/*     */   {
/* 159 */     return new SupplierOfInstance(instance);
/*     */   }
/*     */ 
/*     */   public static <T> Supplier<T> synchronizedSupplier(Supplier<T> delegate)
/*     */   {
/* 180 */     return new ThreadSafeSupplier((Supplier)Preconditions.checkNotNull(delegate));
/*     */   }
/*     */   private static class ThreadSafeSupplier<T> implements Supplier<T>, Serializable {
/*     */     final Supplier<T> delegate;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/* 188 */     ThreadSafeSupplier(Supplier<T> delegate) { this.delegate = delegate; }
/*     */ 
/*     */     public T get() {
/* 191 */       synchronized (this.delegate) {
/* 192 */         return this.delegate.get();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SupplierOfInstance<T>
/*     */     implements Supplier<T>, Serializable
/*     */   {
/*     */     final T instance;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SupplierOfInstance(T instance)
/*     */     {
/* 167 */       this.instance = instance;
/*     */     }
/*     */     public T get() {
/* 170 */       return this.instance;
/*     */     }
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static class ExpiringMemoizingSupplier<T>
/*     */     implements Supplier<T>, Serializable
/*     */   {
/*     */     final Supplier<T> delegate;
/*     */     final long durationNanos;
/*     */     transient boolean initialized;
/*     */     transient T value;
/*     */     transient long expirationNanos;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     ExpiringMemoizingSupplier(Supplier<T> delegate, long duration, TimeUnit unit)
/*     */     {
/* 138 */       this.delegate = ((Supplier)Preconditions.checkNotNull(delegate));
/* 139 */       this.durationNanos = unit.toNanos(duration);
/* 140 */       Preconditions.checkArgument(duration > 0L);
/*     */     }
/*     */ 
/*     */     public synchronized T get() {
/* 144 */       if ((!this.initialized) || (Platform.systemNanoTime() - this.expirationNanos >= 0L)) {
/* 145 */         this.value = this.delegate.get();
/* 146 */         this.initialized = true;
/* 147 */         this.expirationNanos = (Platform.systemNanoTime() + this.durationNanos);
/*     */       }
/* 149 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static class MemoizingSupplier<T>
/*     */     implements Supplier<T>, Serializable
/*     */   {
/*     */     final Supplier<T> delegate;
/*     */     transient boolean initialized;
/*     */     transient T value;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     MemoizingSupplier(Supplier<T> delegate)
/*     */     {
/*  91 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     public synchronized T get() {
/*  95 */       if (!this.initialized) {
/*  96 */         this.value = this.delegate.get();
/*  97 */         this.initialized = true;
/*     */       }
/*  99 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SupplierComposition<F, T>
/*     */     implements Supplier<T>, Serializable
/*     */   {
/*     */     final Function<? super F, T> function;
/*     */     final Supplier<F> supplier;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SupplierComposition(Function<? super F, T> function, Supplier<F> supplier)
/*     */     {
/*  61 */       this.function = function;
/*  62 */       this.supplier = supplier;
/*     */     }
/*     */     public T get() {
/*  65 */       return this.function.apply(this.supplier.get());
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Suppliers
 * JD-Core Version:    0.6.0
 */