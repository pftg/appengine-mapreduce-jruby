/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public final class KeyRange
/*     */   implements Iterable<Key>, Serializable
/*     */ {
/*     */   static final long serialVersionUID = 962890261927141064L;
/*     */   private final Key parent;
/*     */   private final String kind;
/*     */   private final Key start;
/*     */   private final Key end;
/*     */ 
/*     */   public KeyRange(Key parent, String kind, long start, long end)
/*     */   {
/*  36 */     if ((parent != null) && (!parent.isComplete())) {
/*  37 */       throw new IllegalArgumentException("Invalid parent: not a complete key");
/*     */     }
/*     */ 
/*  40 */     if ((kind == null) || (kind.equals(""))) {
/*  41 */       throw new IllegalArgumentException("Invalid kind: cannot be null or empty");
/*     */     }
/*     */ 
/*  44 */     if (start < 1L) {
/*  45 */       throw new IllegalArgumentException("Illegal start " + start + ": less than 1");
/*     */     }
/*     */ 
/*  48 */     if (end < start) {
/*  49 */       throw new IllegalArgumentException("Illegal end " + end + ": less than start " + start);
/*     */     }
/*     */ 
/*  52 */     this.parent = parent;
/*  53 */     this.kind = kind;
/*  54 */     this.start = KeyFactory.createKey(parent, kind, start);
/*  55 */     this.end = KeyFactory.createKey(parent, kind, end);
/*     */   }
/*     */ 
/*     */   private KeyRange()
/*     */   {
/*  65 */     this.parent = null;
/*  66 */     this.kind = null;
/*  67 */     this.start = null;
/*  68 */     this.end = null;
/*     */   }
/*     */ 
/*     */   Key getParent()
/*     */   {
/*  75 */     return this.parent;
/*     */   }
/*     */ 
/*     */   String getKind()
/*     */   {
/*  82 */     return this.kind;
/*     */   }
/*     */ 
/*     */   public Key getStart()
/*     */   {
/*  89 */     return this.start;
/*     */   }
/*     */ 
/*     */   public Key getEnd()
/*     */   {
/*  96 */     return this.end;
/*     */   }
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 104 */     return this.end.getId() - this.start.getId() + 1L;
/*     */   }
/*     */ 
/*     */   public Iterator<Key> iterator() {
/* 108 */     return new IdRangeIterator(null);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 113 */     if ((obj == null) || (!(obj instanceof KeyRange))) {
/* 114 */       return false;
/*     */     }
/* 116 */     KeyRange that = (KeyRange)obj;
/*     */ 
/* 119 */     return (this.start.equals(that.start)) && (this.end.equals(that.end));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 124 */     return 31 * this.start.hashCode() + this.end.hashCode();
/*     */   }
/*     */ 
/*     */   private final class IdRangeIterator
/*     */     implements Iterator<Key>
/*     */   {
/* 132 */     private long next = KeyRange.this.start.getId();
/*     */ 
/*     */     private IdRangeIterator() {
/*     */     }
/* 136 */     public boolean hasNext() { return this.next <= KeyRange.this.end.getId(); }
/*     */ 
/*     */     public Key next()
/*     */     {
/* 140 */       if (!hasNext()) {
/* 141 */         throw new NoSuchElementException();
/*     */       }
/* 143 */       return KeyFactory.createKey(KeyRange.this.parent, KeyRange.this.kind, this.next++);
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 147 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.KeyRange
 * JD-Core Version:    0.6.0
 */