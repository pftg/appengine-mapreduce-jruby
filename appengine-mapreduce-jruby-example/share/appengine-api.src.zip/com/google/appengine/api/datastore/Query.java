/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class Query
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 7090652715949085374L;
/*     */   private final String kind;
/*     */   private final List<SortPredicate> sortPredicates;
/*     */   private final List<FilterPredicate> filterPredicates;
/*     */   private Key ancestor;
/*     */   private boolean keysOnly;
/*     */   private AppIdNamespace appIdNamespace;
/*     */   private transient String fullTextSearch;
/*     */ 
/*     */   public Query()
/*     */   {
/*  76 */     this((String)null);
/*     */   }
/*     */ 
/*     */   public Query(String kind)
/*     */   {
/*  87 */     this(kind, null, new ArrayList(), new ArrayList(), false, DatastoreApiHelper.getCurrentAppIdNamespace(), null);
/*     */   }
/*     */ 
/*     */   Query(String kind, Key ancestor, List<SortPredicate> sortPreds, List<FilterPredicate> filterPreds, boolean keysOnly, AppIdNamespace appIdNamespace, String fullTextSearch)
/*     */   {
/*  94 */     this.kind = kind;
/*  95 */     this.ancestor = ancestor;
/*  96 */     this.sortPredicates = sortPreds;
/*  97 */     this.filterPredicates = filterPreds;
/*  98 */     this.keysOnly = keysOnly;
/*  99 */     this.appIdNamespace = appIdNamespace;
/* 100 */     this.fullTextSearch = fullTextSearch;
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 105 */     in.defaultReadObject();
/*     */ 
/* 107 */     if (this.appIdNamespace == null)
/* 108 */       if (this.ancestor != null)
/* 109 */         this.appIdNamespace = this.ancestor.getAppIdNamespace();
/*     */       else
/* 111 */         this.appIdNamespace = new AppIdNamespace(DatastoreApiHelper.getCurrentAppId(), "");
/*     */   }
/*     */ 
/*     */   public Query(Key ancestor)
/*     */   {
/* 124 */     this((String)null);
/* 125 */     if (ancestor != null)
/* 126 */       setAncestor(ancestor);
/*     */   }
/*     */ 
/*     */   public Query(String kind, Key ancestor)
/*     */   {
/* 140 */     this(kind);
/* 141 */     if (ancestor != null)
/* 142 */       setAncestor(ancestor);
/*     */   }
/*     */ 
/*     */   public String getKind()
/*     */   {
/* 151 */     return this.kind;
/*     */   }
/*     */ 
/*     */   AppIdNamespace getAppIdNamespace()
/*     */   {
/* 161 */     return this.appIdNamespace;
/*     */   }
/*     */ 
/*     */   public Key getAncestor()
/*     */   {
/* 169 */     return this.ancestor;
/*     */   }
/*     */ 
/*     */   public Query setAncestor(Key ancestor)
/*     */   {
/* 191 */     if ((ancestor != null) && (!ancestor.isComplete()))
/* 192 */       throw new IllegalArgumentException(ancestor + " is incomplete.");
/* 193 */     if ((ancestor == null) && 
/* 194 */       (this.ancestor == null)) {
/* 195 */       throw new IllegalArgumentException("Cannot clear ancestor unless ancestor has already been set");
/*     */     }
/*     */ 
/* 199 */     if ((ancestor != null) && 
/* 200 */       (!ancestor.getAppIdNamespace().equals(this.appIdNamespace))) {
/* 201 */       throw new IllegalArgumentException("Namespace of ancestor key and query must match.");
/*     */     }
/*     */ 
/* 205 */     this.ancestor = ancestor;
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */   public Query addFilter(String propertyName, FilterOperator operator, Object value)
/*     */   {
/* 235 */     this.filterPredicates.add(new FilterPredicate(propertyName, operator, value));
/* 236 */     return this;
/*     */   }
/*     */ 
/*     */   public List<FilterPredicate> getFilterPredicates()
/*     */   {
/* 243 */     return Collections.unmodifiableList(this.filterPredicates);
/*     */   }
/*     */ 
/*     */   public Query addSort(String propertyName)
/*     */   {
/* 267 */     return addSort(propertyName, SortDirection.ASCENDING);
/*     */   }
/*     */ 
/*     */   public Query addSort(String propertyName, SortDirection direction)
/*     */   {
/* 292 */     this.sortPredicates.add(new SortPredicate(propertyName, direction));
/* 293 */     return this;
/*     */   }
/*     */ 
/*     */   public List<SortPredicate> getSortPredicates()
/*     */   {
/* 300 */     return Collections.unmodifiableList(this.sortPredicates);
/*     */   }
/*     */ 
/*     */   public Query setKeysOnly()
/*     */   {
/* 309 */     this.keysOnly = true;
/* 310 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean isKeysOnly()
/*     */   {
/* 318 */     return this.keysOnly;
/*     */   }
/*     */ 
/*     */   String getFullTextSearch()
/*     */   {
/* 326 */     return this.fullTextSearch;
/*     */   }
/*     */ 
/*     */   Query setFullTextSearch(String fullTextSearch)
/*     */   {
/* 336 */     this.fullTextSearch = fullTextSearch;
/* 337 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 342 */     if (this == o) {
/* 343 */       return true;
/*     */     }
/* 345 */     if ((o == null) || (getClass() != o.getClass())) {
/* 346 */       return false;
/*     */     }
/*     */ 
/* 349 */     Query query = (Query)o;
/*     */ 
/* 351 */     if (this.keysOnly != query.keysOnly) {
/* 352 */       return false;
/*     */     }
/* 354 */     if (this.ancestor != null ? !this.ancestor.equals(query.ancestor) : query.ancestor != null) {
/* 355 */       return false;
/*     */     }
/* 357 */     if (!this.appIdNamespace.equals(query.appIdNamespace)) {
/* 358 */       return false;
/*     */     }
/* 360 */     if (!this.filterPredicates.equals(query.filterPredicates)) {
/* 361 */       return false;
/*     */     }
/* 363 */     if (!this.kind.equals(query.kind)) {
/* 364 */       return false;
/*     */     }
/* 366 */     if (!this.sortPredicates.equals(query.sortPredicates)) {
/* 367 */       return false;
/*     */     }
/*     */ 
/* 371 */     return this.fullTextSearch != null ? this.fullTextSearch.equals(query.fullTextSearch) : query.fullTextSearch == null;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 380 */     int result = this.kind.hashCode();
/* 381 */     result = 31 * result + this.sortPredicates.hashCode();
/* 382 */     result = 31 * result + this.filterPredicates.hashCode();
/* 383 */     result = 31 * result + (this.ancestor != null ? this.ancestor.hashCode() : 0);
/* 384 */     result = 31 * result + (this.keysOnly ? 1 : 0);
/* 385 */     result = 31 * result + this.appIdNamespace.hashCode();
/* 386 */     result = 31 * result + (this.fullTextSearch != null ? this.fullTextSearch.hashCode() : 0);
/* 387 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 395 */     StringBuilder result = new StringBuilder("SELECT " + (this.keysOnly ? "__key__" : "*"));
/*     */ 
/* 397 */     if (this.kind != null) {
/* 398 */       result.append(" FROM ");
/* 399 */       result.append(this.kind);
/*     */     }
/*     */ 
/* 402 */     if ((this.ancestor != null) || (!this.filterPredicates.isEmpty())) {
/* 403 */       result.append(" WHERE ");
/*     */     }
/*     */ 
/* 406 */     String AND_SEPARATOR = " AND ";
/* 407 */     for (FilterPredicate filter : this.filterPredicates) {
/* 408 */       result.append(filter);
/* 409 */       result.append(" AND ");
/*     */     }
/*     */ 
/* 412 */     if (this.ancestor != null) {
/* 413 */       result.append("__ancestor__ is ");
/* 414 */       result.append(this.ancestor);
/* 415 */     } else if (!this.filterPredicates.isEmpty()) {
/* 416 */       result.delete(result.length() - " AND ".length(), result.length());
/*     */     }
/*     */ 
/* 419 */     String COMMA_SEPARATOR = ", ";
/* 420 */     if (!this.sortPredicates.isEmpty()) {
/* 421 */       result.append(" ORDER BY ");
/* 422 */       for (SortPredicate sort : this.sortPredicates) {
/* 423 */         result.append(sort);
/* 424 */         result.append(", ");
/*     */       }
/* 426 */       result.delete(result.length() - ", ".length(), result.length());
/*     */     }
/* 428 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static final class FilterPredicate
/*     */     implements Serializable
/*     */   {
/*     */     static final long serialVersionUID = 7681475799401864259L;
/*     */     private final String propertyName;
/*     */     private final Query.FilterOperator operator;
/*     */     private final Object value;
/*     */ 
/*     */     public FilterPredicate(String propertyName, Query.FilterOperator operator, Object value)
/*     */     {
/* 534 */       if (propertyName == null)
/* 535 */         throw new NullPointerException("Property name was null");
/* 536 */       if (operator == null)
/* 537 */         throw new NullPointerException("Operator was null");
/* 538 */       if (operator == Query.FilterOperator.IN) {
/* 539 */         if ((!(value instanceof Collection)) && ((value instanceof Iterable)))
/*     */         {
/* 541 */           List newValue = new ArrayList();
/* 542 */           for (Iterator i$ = ((Iterable)value).iterator(); i$.hasNext(); ) { Object val = i$.next();
/* 543 */             newValue.add(val);
/*     */           }
/* 545 */           value = newValue;
/*     */         }
/* 547 */         DataTypeUtils.checkSupportedValue(propertyName, value, true, true);
/*     */       } else {
/* 549 */         DataTypeUtils.checkSupportedValue(propertyName, value, false, false);
/*     */       }
/* 551 */       this.propertyName = propertyName;
/* 552 */       this.operator = operator;
/* 553 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public String getPropertyName()
/*     */     {
/* 560 */       return this.propertyName;
/*     */     }
/*     */ 
/*     */     public Query.FilterOperator getOperator()
/*     */     {
/* 567 */       return this.operator;
/*     */     }
/*     */ 
/*     */     public Object getValue()
/*     */     {
/* 574 */       return this.value;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 579 */       if (this == o) {
/* 580 */         return true;
/*     */       }
/* 582 */       if ((o == null) || (getClass() != o.getClass())) {
/* 583 */         return false;
/*     */       }
/*     */ 
/* 586 */       FilterPredicate that = (FilterPredicate)o;
/*     */ 
/* 588 */       if (this.operator != that.operator) {
/* 589 */         return false;
/*     */       }
/* 591 */       if (!this.propertyName.equals(that.propertyName)) {
/* 592 */         return false;
/*     */       }
/*     */ 
/* 595 */       return this.value != null ? this.value.equals(that.value) : that.value == null;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 604 */       int result = this.propertyName.hashCode();
/* 605 */       result = 31 * result + this.operator.hashCode();
/* 606 */       result = 31 * result + (this.value != null ? this.value.hashCode() : 0);
/* 607 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 612 */       return this.propertyName + " " + this.operator.toString() + " " + (this.value != null ? this.value.toString() : "NULL");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class SortPredicate
/*     */     implements Serializable
/*     */   {
/*     */     static final long serialVersionUID = -623786024456258081L;
/*     */     private final String propertyName;
/*     */     private final Query.SortDirection direction;
/*     */ 
/*     */     public SortPredicate(String propertyName, Query.SortDirection direction)
/*     */     {
/* 441 */       if (propertyName == null) {
/* 442 */         throw new NullPointerException("Property name was null");
/*     */       }
/*     */ 
/* 445 */       if (direction == null) {
/* 446 */         throw new NullPointerException("Direction was null");
/*     */       }
/*     */ 
/* 449 */       this.propertyName = propertyName;
/* 450 */       this.direction = direction;
/*     */     }
/*     */ 
/*     */     public String getPropertyName()
/*     */     {
/* 457 */       return this.propertyName;
/*     */     }
/*     */ 
/*     */     public Query.SortDirection getDirection()
/*     */     {
/* 464 */       return this.direction;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 469 */       if (this == o) {
/* 470 */         return true;
/*     */       }
/* 472 */       if ((o == null) || (getClass() != o.getClass())) {
/* 473 */         return false;
/*     */       }
/*     */ 
/* 476 */       SortPredicate that = (SortPredicate)o;
/*     */ 
/* 478 */       if (this.direction != that.direction) {
/* 479 */         return false;
/*     */       }
/*     */ 
/* 482 */       return this.propertyName.equals(that.propertyName);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 491 */       int result = this.propertyName.hashCode();
/* 492 */       result = 31 * result + this.direction.hashCode();
/* 493 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 498 */       return this.propertyName + (this.direction == Query.SortDirection.DESCENDING ? " DESC" : "");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum FilterOperator
/*     */   {
/*  37 */     LESS_THAN("<"), 
/*  38 */     LESS_THAN_OR_EQUAL("<="), 
/*  39 */     GREATER_THAN(">"), 
/*  40 */     GREATER_THAN_OR_EQUAL(">="), 
/*  41 */     EQUAL("="), 
/*  42 */     NOT_EQUAL("!="), 
/*  43 */     IN("IN");
/*     */ 
/*     */     private final String shortName;
/*     */ 
/*  47 */     private FilterOperator(String shortName) { this.shortName = shortName;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  52 */       return this.shortName;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum SortDirection
/*     */   {
/*  30 */     ASCENDING, DESCENDING;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Query
 * JD-Core Version:    0.6.0
 */