/*     */ package com.google.appengine.api.utils;
/*     */ 
/*     */ public class SystemProperty
/*     */ {
/*  30 */   public static final Environment environment = new Environment(null);
/*     */ 
/*  38 */   public static final SystemProperty version = new SystemProperty("com.google.appengine.runtime.version");
/*     */ 
/*  45 */   public static final SystemProperty applicationId = new SystemProperty("com.google.appengine.application.id");
/*     */ 
/*  53 */   public static final SystemProperty applicationVersion = new SystemProperty("com.google.appengine.application.version");
/*     */ 
/*  57 */   public static final SystemProperty instanceReplicaId = new SystemProperty("com.google.appengine.instance.replica-id");
/*     */   private String key;
/*     */ 
/*     */   private SystemProperty(String key)
/*     */   {
/* 108 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public String key()
/*     */   {
/* 117 */     return this.key;
/*     */   }
/*     */ 
/*     */   public String get()
/*     */   {
/* 125 */     return System.getProperty(key());
/*     */   }
/*     */ 
/*     */   public void set(String value)
/*     */   {
/* 133 */     System.setProperty(key(), value);
/*     */   }
/*     */ 
/*     */   public static class Environment extends SystemProperty
/*     */   {
/*     */     private Environment()
/*     */     {
/*  80 */       super(null);
/*     */     }
/*     */ 
/*     */     public Value value()
/*     */     {
/*     */       try
/*     */       {
/*  91 */         return Value.valueOf(get()); } catch (IllegalArgumentException e) {
/*     */       }
/*  93 */       return null;
/*     */     }
/*     */ 
/*     */     public void set(Value value)
/*     */     {
/* 103 */       set(value.value());
/*     */     }
/*     */ 
/*     */     public static enum Value
/*     */     {
/*  71 */       Production, 
/*  72 */       Development;
/*     */ 
/*     */       public String value() {
/*  75 */         return toString();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.utils.SystemProperty
 * JD-Core Version:    0.6.0
 */