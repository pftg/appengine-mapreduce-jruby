/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract interface DatastoreService
/*     */ {
/*     */   public abstract Entity get(Key paramKey)
/*     */     throws EntityNotFoundException;
/*     */ 
/*     */   public abstract Entity get(Transaction paramTransaction, Key paramKey)
/*     */     throws EntityNotFoundException;
/*     */ 
/*     */   public abstract Map<Key, Entity> get(Iterable<Key> paramIterable);
/*     */ 
/*     */   public abstract Map<Key, Entity> get(Transaction paramTransaction, Iterable<Key> paramIterable);
/*     */ 
/*     */   public abstract Key put(Entity paramEntity);
/*     */ 
/*     */   public abstract Key put(Transaction paramTransaction, Entity paramEntity);
/*     */ 
/*     */   public abstract List<Key> put(Iterable<Entity> paramIterable);
/*     */ 
/*     */   public abstract List<Key> put(Transaction paramTransaction, Iterable<Entity> paramIterable);
/*     */ 
/*     */   public abstract void delete(Key[] paramArrayOfKey);
/*     */ 
/*     */   public abstract void delete(Transaction paramTransaction, Key[] paramArrayOfKey);
/*     */ 
/*     */   public abstract void delete(Iterable<Key> paramIterable);
/*     */ 
/*     */   public abstract void delete(Transaction paramTransaction, Iterable<Key> paramIterable);
/*     */ 
/*     */   public abstract PreparedQuery prepare(Query paramQuery);
/*     */ 
/*     */   public abstract PreparedQuery prepare(Transaction paramTransaction, Query paramQuery);
/*     */ 
/*     */   public abstract Transaction beginTransaction();
/*     */ 
/*     */   public abstract Transaction getCurrentTransaction();
/*     */ 
/*     */   public abstract Transaction getCurrentTransaction(Transaction paramTransaction);
/*     */ 
/*     */   public abstract Collection<Transaction> getActiveTransactions();
/*     */ 
/*     */   public abstract KeyRange allocateIds(String paramString, long paramLong);
/*     */ 
/*     */   public abstract KeyRange allocateIds(Key paramKey, String paramString, long paramLong);
/*     */ 
/*     */   public abstract KeyRangeState allocateIdRange(KeyRange paramKeyRange);
/*     */ 
/*     */   public static enum KeyRangeState
/*     */   {
/* 375 */     EMPTY, 
/*     */ 
/* 392 */     CONTENTION, 
/*     */ 
/* 405 */     COLLISION;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreService
 * JD-Core Version:    0.6.0
 */