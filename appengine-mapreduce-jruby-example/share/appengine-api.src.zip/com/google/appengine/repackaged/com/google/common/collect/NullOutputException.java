/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ class NullOutputException extends NullPointerException
/*    */ {
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public NullOutputException(String s)
/*    */   {
/* 28 */     super(s);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.NullOutputException
 * JD-Core Version:    0.6.0
 */