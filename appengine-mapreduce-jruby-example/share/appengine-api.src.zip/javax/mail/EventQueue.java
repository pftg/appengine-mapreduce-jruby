/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ class EventQueue
/*     */   implements Runnable
/*     */ {
/*     */   protected Thread dispatchThread;
/*  54 */   protected List eventQueue = new LinkedList();
/*     */ 
/*     */   public EventQueue()
/*     */   {
/*  60 */     this.dispatchThread = new Thread(this, "JavaMail-EventQueue");
/*  61 */     this.dispatchThread.setDaemon(true);
/*     */ 
/*  63 */     this.dispatchThread.start();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*     */       while (true)
/*     */       {
/*  81 */         PendingEvent p = dequeueEvent();
/*     */ 
/*  83 */         if (p.event == null) {
/*  84 */           return;
/*     */         }
/*     */ 
/*  88 */         dispatchEvent(p.event, p.listeners);
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 104 */     if (this.dispatchThread != null)
/*     */     {
/* 107 */       queueEvent(null, null);
/* 108 */       this.dispatchThread = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void queueEvent(MailEvent event, List listeners)
/*     */   {
/* 125 */     PendingEvent p = new PendingEvent(event, listeners);
/* 126 */     this.eventQueue.add(p);
/*     */ 
/* 128 */     notify();
/*     */   }
/*     */ 
/*     */   protected synchronized PendingEvent dequeueEvent()
/*     */     throws InterruptedException
/*     */   {
/* 138 */     while (this.eventQueue.isEmpty()) {
/* 139 */       wait();
/*     */     }
/*     */ 
/* 143 */     return (PendingEvent)this.eventQueue.remove(0);
/*     */   }
/*     */ 
/*     */   protected void dispatchEvent(MailEvent event, List listeners)
/*     */   {
/* 156 */     for (int i = 0; i < listeners.size(); i++)
/*     */       try {
/* 158 */         event.dispatch(listeners.get(i));
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   class PendingEvent
/*     */   {
/*     */     MailEvent event;
/*     */     List listeners;
/*     */ 
/*     */     PendingEvent(MailEvent event, List listeners)
/*     */     {
/* 176 */       this.event = event;
/* 177 */       this.listeners = listeners;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.EventQueue
 * JD-Core Version:    0.6.0
 */