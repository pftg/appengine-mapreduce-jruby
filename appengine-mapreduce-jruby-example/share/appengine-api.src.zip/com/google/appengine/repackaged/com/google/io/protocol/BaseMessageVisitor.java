/*    */ package com.google.appengine.repackaged.com.google.io.protocol;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class BaseMessageVisitor
/*    */   implements MessageVisitor
/*    */ {
/*    */   public boolean shouldVisitField(ProtocolType.FieldType fieldType, int count)
/*    */   {
/* 21 */     throw new UnsupportedOperationException("Not implemented");
/*    */   }
/*    */ 
/*    */   public void visitBoolean(ProtocolType.FieldType fieldType, int index, boolean value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitByteArray(ProtocolType.FieldType fieldType, int index, byte[] value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitDouble(ProtocolType.FieldType fieldType, int index, double value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitFloat(ProtocolType.FieldType fieldType, int index, float value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitForeign(ProtocolType.FieldType fieldType, int index, ProtocolMessage value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitGroup(ProtocolType.FieldType fieldType, int index, ProtocolMessage value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitInteger(ProtocolType.FieldType fieldType, int index, int value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitLong(ProtocolType.FieldType fieldType, int index, long value)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitRawMessage(ByteBuffer message)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void visitString(ProtocolType.FieldType fieldType, int index, String value)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.BaseMessageVisitor
 * JD-Core Version:    0.6.0
 */