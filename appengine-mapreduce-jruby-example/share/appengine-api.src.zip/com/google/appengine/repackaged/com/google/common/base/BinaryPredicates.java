/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public class BinaryPredicates
/*     */ {
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <X, Y> BinaryPredicate<X, Y> alwaysTrue()
/*     */   {
/*  41 */     return restrict(AlwaysTrue.AlwaysTrue);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <X, Y> BinaryPredicate<X, Y> alwaysFalse()
/*     */   {
/*  49 */     return restrict(AlwaysFalse.AlwaysFalse);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <X, Y> BinaryPredicate<X, Y> equality()
/*     */   {
/*  58 */     return restrict(Equality.Equality);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <X, Y> BinaryPredicate<X, Y> identity()
/*     */   {
/*  67 */     return restrict(Identity.Identity);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> first(Predicate<? super X> predicate)
/*     */   {
/*  75 */     return new First(predicate);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> second(Predicate<? super Y> predicate)
/*     */   {
/*  83 */     return new Second(predicate);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> and(BinaryPredicate<? super X, ? super Y> binaryPredicate1, BinaryPredicate<? super X, ? super Y> binaryPredicate2)
/*     */   {
/*  96 */     BinaryPredicate restricted1 = restrict(binaryPredicate1);
/*  97 */     BinaryPredicate restricted2 = restrict(binaryPredicate2);
/*     */ 
/* 100 */     Iterable iterable = Arrays.asList(new BinaryPredicate[] { restricted1, restricted2 });
/* 101 */     return new And(iterable);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> and(BinaryPredicate<? super X, ? super Y>[] components)
/*     */   {
/* 117 */     return new And(Arrays.asList(components));
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> and(Iterable<? extends BinaryPredicate<? super X, ? super Y>> components)
/*     */   {
/* 134 */     return new And(components);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> or(BinaryPredicate<? super X, ? super Y> binaryPredicate1, BinaryPredicate<? super X, ? super Y> binaryPredicate2)
/*     */   {
/* 147 */     BinaryPredicate restricted1 = restrict(binaryPredicate1);
/* 148 */     BinaryPredicate restricted2 = restrict(binaryPredicate2);
/*     */ 
/* 151 */     Iterable iterable = Arrays.asList(new BinaryPredicate[] { restricted1, restricted2 });
/* 152 */     return new Or(iterable);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> or(BinaryPredicate<? super X, ? super Y>[] components)
/*     */   {
/* 168 */     return new Or(Arrays.asList(components));
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> or(Iterable<? extends BinaryPredicate<? super X, ? super Y>> components)
/*     */   {
/* 185 */     return new Or(components);
/*     */   }
/*     */ 
/*     */   public static <X, Y> BinaryPredicate<X, Y> not(BinaryPredicate<? super X, ? super Y> binaryPredicate)
/*     */   {
/* 196 */     return new Not(binaryPredicate);
/*     */   }
/*     */ 
/*     */   private static <X, Y> BinaryPredicate<X, Y> restrict(@Nullable BinaryPredicate<? super X, ? super Y> predicate)
/*     */   {
/* 212 */     return predicate;
/*     */   }
/*     */ 
/*     */   private static boolean iterableElementsEqual(Iterable<?> iterable1, Iterable<?> iterable2)
/*     */   {
/* 404 */     Iterator iterator1 = iterable1.iterator();
/* 405 */     Iterator iterator2 = iterable2.iterator();
/* 406 */     while (iterator1.hasNext()) {
/* 407 */       if (!iterator2.hasNext()) {
/* 408 */         return false;
/*     */       }
/* 410 */       if (!iterator1.next().equals(iterator2.next())) {
/* 411 */         return false;
/*     */       }
/*     */     }
/* 414 */     return !iterator2.hasNext();
/*     */   }
/*     */ 
/*     */   private static int iterableAsListHashCode(Iterable<?> iterable)
/*     */   {
/* 424 */     Iterator iterator = iterable.iterator();
/* 425 */     int result = 1;
/* 426 */     while (iterator.hasNext()) {
/* 427 */       Object obj = iterator.next();
/* 428 */       result = 31 * result + obj.hashCode();
/*     */     }
/* 430 */     return result;
/*     */   }
/*     */ 
/*     */   private static final class Second<X, Y>
/*     */     implements BinaryPredicate<X, Y>, Serializable
/*     */   {
/*     */     final Predicate<? super Y> predicate;
/*     */     private static final long serialVersionUID = -7134579481937611424L;
/*     */ 
/*     */     Second(Predicate<? super Y> predicate)
/*     */     {
/* 372 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*     */     }
/*     */ 
/*     */     public boolean apply(@Nullable X x, @Nullable Y y) {
/* 376 */       return this.predicate.apply(y);
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 380 */       if ((obj instanceof Second)) {
/* 381 */         Second other = (Second)obj;
/* 382 */         return this.predicate.equals(other.predicate);
/*     */       }
/* 384 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 388 */       return this.predicate.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class First<X, Y>
/*     */     implements BinaryPredicate<X, Y>, Serializable
/*     */   {
/*     */     final Predicate<? super X> predicate;
/*     */     private static final long serialVersionUID = 5389902773091803723L;
/*     */ 
/*     */     First(Predicate<? super X> predicate)
/*     */     {
/* 345 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*     */     }
/*     */ 
/*     */     public boolean apply(@Nullable X x, @Nullable Y y) {
/* 349 */       return this.predicate.apply(x);
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 353 */       if ((obj instanceof First)) {
/* 354 */         First other = (First)obj;
/* 355 */         return this.predicate.equals(other.predicate);
/*     */       }
/* 357 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 361 */       return this.predicate.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class Or<X, Y>
/*     */     implements BinaryPredicate<X, Y>, Serializable
/*     */   {
/*     */     final Iterable<? extends BinaryPredicate<? super X, ? super Y>> predicates;
/*     */     private static final long serialVersionUID = -1352468805830701672L;
/*     */ 
/*     */     Or(Iterable<? extends BinaryPredicate<? super X, ? super Y>> predicates)
/*     */     {
/* 314 */       this.predicates = Preconditions.checkContentsNotNull(predicates);
/*     */     }
/*     */ 
/*     */     public boolean apply(@Nullable X x, @Nullable Y y) {
/* 318 */       for (BinaryPredicate predicate : this.predicates) {
/* 319 */         if (predicate.apply(x, y)) {
/* 320 */           return true;
/*     */         }
/*     */       }
/* 323 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 327 */       if ((obj instanceof Or)) {
/* 328 */         return BinaryPredicates.access$000(this.predicates, ((Or)obj).predicates);
/*     */       }
/* 330 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 334 */       return BinaryPredicates.access$100(this.predicates);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class And<X, Y>
/*     */     implements BinaryPredicate<X, Y>, Serializable
/*     */   {
/*     */     final Iterable<? extends BinaryPredicate<? super X, ? super Y>> predicates;
/*     */     private static final long serialVersionUID = 4814831122225615776L;
/*     */ 
/*     */     And(Iterable<? extends BinaryPredicate<? super X, ? super Y>> predicates)
/*     */     {
/* 283 */       this.predicates = Preconditions.checkContentsNotNull(predicates);
/*     */     }
/*     */ 
/*     */     public boolean apply(@Nullable X x, @Nullable Y y) {
/* 287 */       for (BinaryPredicate predicate : this.predicates) {
/* 288 */         if (!predicate.apply(x, y)) {
/* 289 */           return false;
/*     */         }
/*     */       }
/* 292 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 296 */       if ((obj instanceof And)) {
/* 297 */         return BinaryPredicates.access$000(this.predicates, ((And)obj).predicates);
/*     */       }
/* 299 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 303 */       return BinaryPredicates.access$100(this.predicates);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class Not<X, Y>
/*     */     implements BinaryPredicate<X, Y>, Serializable
/*     */   {
/*     */     final BinaryPredicate<? super X, ? super Y> predicate;
/*     */     private static final long serialVersionUID = 7318841078083112007L;
/*     */ 
/*     */     Not(BinaryPredicate<? super X, ? super Y> predicate)
/*     */     {
/* 256 */       this.predicate = ((BinaryPredicate)Preconditions.checkNotNull(predicate));
/*     */     }
/*     */ 
/*     */     public boolean apply(@Nullable X x, @Nullable Y y) {
/* 260 */       return !this.predicate.apply(x, y);
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 264 */       if ((obj instanceof Not)) {
/* 265 */         Not other = (Not)obj;
/* 266 */         return this.predicate.equals(other.predicate);
/*     */       }
/* 268 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 272 */       return this.predicate.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum Identity
/*     */     implements BinaryPredicate<Object, Object>
/*     */   {
/* 245 */     Identity;
/*     */ 
/* 247 */     public boolean apply(@Nullable Object o1, @Nullable Object o2) { return o1 == o2;
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum Equality
/*     */     implements BinaryPredicate<Object, Object>
/*     */   {
/* 236 */     Equality;
/*     */ 
/* 238 */     public boolean apply(@Nullable Object o1, @Nullable Object o2) { return Objects.equal(o1, o2);
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum AlwaysFalse
/*     */     implements BinaryPredicate<Object, Object>
/*     */   {
/* 227 */     AlwaysFalse;
/*     */ 
/* 229 */     public boolean apply(@Nullable Object o1, @Nullable Object o2) { return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum AlwaysTrue
/*     */     implements BinaryPredicate<Object, Object>
/*     */   {
/* 218 */     AlwaysTrue;
/*     */ 
/* 220 */     public boolean apply(@Nullable Object o1, @Nullable Object o2) { return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.BinaryPredicates
 * JD-Core Version:    0.6.0
 */