package com.google.appengine.api.memcache;

public abstract interface Stats
{
  public abstract long getHitCount();

  public abstract long getMissCount();

  public abstract long getBytesReturnedForHits();

  public abstract long getItemCount();

  public abstract long getTotalItemBytes();

  public abstract int getMaxTimeWithoutAccess();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.Stats
 * JD-Core Version:    0.6.0
 */