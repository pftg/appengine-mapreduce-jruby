/*    */ package javax.mail;
/*    */ 
/*    */ public class IllegalWriteException extends MessagingException
/*    */ {
/*    */   public IllegalWriteException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IllegalWriteException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.IllegalWriteException
 * JD-Core Version:    0.6.0
 */