/*     */ package javax.mail;
/*     */ 
/*     */ public class Quota
/*     */ {
/*     */   public String quotaRoot;
/*     */   public Resource[] resources;
/*     */ 
/*     */   public Quota(String quotaRoot)
/*     */   {
/*  45 */     this.quotaRoot = quotaRoot;
/*     */   }
/*     */ 
/*     */   public void setResourceLimit(String name, long limit)
/*     */   {
/*  57 */     Resource target = findResource(name);
/*  58 */     target.limit = limit;
/*     */   }
/*     */ 
/*     */   private Resource findResource(String name)
/*     */   {
/*  71 */     if (this.resources == null) {
/*  72 */       Resource target = new Resource(name, 0L, 0L);
/*  73 */       this.resources = new Resource[] { target };
/*  74 */       return target;
/*     */     }
/*     */ 
/*  78 */     for (int i = 0; i < this.resources.length; i++) {
/*  79 */       Resource current = this.resources[i];
/*  80 */       if (current.name.equalsIgnoreCase(name)) {
/*  81 */         return current;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  86 */     Resource[] newResources = new Resource[this.resources.length + 1];
/*  87 */     System.arraycopy(this.resources, 0, newResources, 0, this.resources.length);
/*  88 */     Resource target = new Resource(name, 0L, 0L);
/*  89 */     newResources[this.resources.length] = target;
/*  90 */     this.resources = newResources;
/*  91 */     return target;
/*     */   }
/*     */ 
/*     */   public static class Resource
/*     */   {
/*     */     public String name;
/*     */     public long usage;
/*     */     public long limit;
/*     */ 
/*     */     public Resource(String name, long usage, long limit)
/*     */     {
/* 123 */       this.name = name;
/* 124 */       this.usage = usage;
/* 125 */       this.limit = limit;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Quota
 * JD-Core Version:    0.6.0
 */