/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class PhoneNumber
/*    */   implements Serializable, Comparable<PhoneNumber>
/*    */ {
/*    */   public static final long serialVersionUID = -8968032543663409348L;
/*    */   private String number;
/*    */ 
/*    */   public PhoneNumber(String number)
/*    */   {
/* 37 */     if (number == null) {
/* 38 */       throw new NullPointerException("number must not be null");
/*    */     }
/* 40 */     this.number = number;
/*    */   }
/*    */ 
/*    */   private PhoneNumber()
/*    */   {
/* 50 */     this.number = null;
/*    */   }
/*    */ 
/*    */   public String getNumber() {
/* 54 */     return this.number;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 59 */     if (this == o) {
/* 60 */       return true;
/*    */     }
/* 62 */     if ((o == null) || (getClass() != o.getClass())) {
/* 63 */       return false;
/*    */     }
/*    */ 
/* 66 */     PhoneNumber that = (PhoneNumber)o;
/*    */ 
/* 69 */     return this.number.equals(that.number);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 77 */     return this.number.hashCode();
/*    */   }
/*    */ 
/*    */   public int compareTo(PhoneNumber o) {
/* 81 */     return this.number.compareTo(o.number);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.PhoneNumber
 * JD-Core Version:    0.6.0
 */