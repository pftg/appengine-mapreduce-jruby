package com.google.appengine.api.xmpp;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;

public abstract interface XMPPService
{
  public abstract Presence getPresence(JID paramJID);

  public abstract Presence getPresence(JID paramJID1, JID paramJID2);

  public abstract void sendInvitation(JID paramJID);

  public abstract void sendInvitation(JID paramJID1, JID paramJID2);

  public abstract SendResponse sendMessage(Message paramMessage);

  public abstract Message parseMessage(HttpServletRequest paramHttpServletRequest)
    throws IOException;
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.XMPPService
 * JD-Core Version:    0.6.0
 */