/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public final class Blob
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 6210713401925622518L;
/*    */   private byte[] bytes;
/*    */ 
/*    */   public Blob(byte[] bytes)
/*    */   {
/* 42 */     this.bytes = bytes;
/*    */   }
/*    */ 
/*    */   private Blob()
/*    */   {
/*    */   }
/*    */ 
/*    */   public byte[] getBytes()
/*    */   {
/* 58 */     return this.bytes;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 63 */     return Arrays.hashCode(this.bytes);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 72 */     if ((object instanceof Blob)) {
/* 73 */       Blob key = (Blob)object;
/* 74 */       return Arrays.equals(this.bytes, key.bytes);
/*    */     }
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 84 */     return "<Blob: " + this.bytes.length + " bytes>";
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Blob
 * JD-Core Version:    0.6.0
 */