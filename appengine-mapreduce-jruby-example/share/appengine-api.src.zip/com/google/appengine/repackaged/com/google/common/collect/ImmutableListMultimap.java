/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public class ImmutableListMultimap<K, V> extends ImmutableMultimap<K, V>
/*     */   implements ListMultimap<K, V>
/*     */ {
/*     */ 
/*     */   @GwtIncompatible("Not needed in emulated source")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> of()
/*     */   {
/*  59 */     return EmptyImmutableListMultimap.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1)
/*     */   {
/*  66 */     Builder builder = builder();
/*     */ 
/*  68 */     builder.put(k1, v1);
/*  69 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2)
/*     */   {
/*  76 */     Builder builder = builder();
/*     */ 
/*  78 */     builder.put(k1, v1);
/*  79 */     builder.put(k2, v2);
/*  80 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*     */   {
/*  88 */     Builder builder = builder();
/*     */ 
/*  90 */     builder.put(k1, v1);
/*  91 */     builder.put(k2, v2);
/*  92 */     builder.put(k3, v3);
/*  93 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*     */   {
/* 101 */     Builder builder = builder();
/*     */ 
/* 103 */     builder.put(k1, v1);
/* 104 */     builder.put(k2, v2);
/* 105 */     builder.put(k3, v3);
/* 106 */     builder.put(k4, v4);
/* 107 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*     */   {
/* 115 */     Builder builder = builder();
/*     */ 
/* 117 */     builder.put(k1, v1);
/* 118 */     builder.put(k2, v2);
/* 119 */     builder.put(k3, v3);
/* 120 */     builder.put(k4, v4);
/* 121 */     builder.put(k5, v5);
/* 122 */     return builder.build();
/*     */   }
/*     */ 
/*     */   public static <K, V> Builder<K, V> builder()
/*     */   {
/* 132 */     return new Builder();
/*     */   }
/*     */ 
/*     */   public static <K, V> ImmutableListMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap)
/*     */   {
/* 227 */     if (multimap.isEmpty()) {
/* 228 */       return of();
/*     */     }
/*     */ 
/* 231 */     if ((multimap instanceof ImmutableListMultimap))
/*     */     {
/* 233 */       ImmutableListMultimap kvMultimap = (ImmutableListMultimap)multimap;
/*     */ 
/* 235 */       return kvMultimap;
/*     */     }
/*     */ 
/* 238 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/* 239 */     int size = 0;
/*     */ 
/* 242 */     for (Map.Entry entry : multimap.asMap().entrySet()) {
/* 243 */       ImmutableList list = ImmutableList.copyOf((Collection)entry.getValue());
/* 244 */       if (!list.isEmpty()) {
/* 245 */         builder.put(entry.getKey(), list);
/* 246 */         size += list.size();
/*     */       }
/*     */     }
/*     */ 
/* 250 */     return new ImmutableListMultimap(builder.build(), size);
/*     */   }
/*     */ 
/*     */   ImmutableListMultimap(ImmutableMap<K, ImmutableList<V>> map, int size) {
/* 254 */     super(map, size);
/*     */   }
/*     */ 
/*     */   public ImmutableList<V> get(@Nullable K key)
/*     */   {
/* 267 */     ImmutableList list = (ImmutableList)this.map.get(key);
/* 268 */     return list == null ? ImmutableList.of() : list;
/*     */   }
/*     */ 
/*     */   public ImmutableList<V> removeAll(Object key)
/*     */   {
/* 277 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public ImmutableList<V> replaceValues(K key, Iterable<? extends V> values)
/*     */   {
/* 287 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 296 */     stream.defaultWriteObject();
/* 297 */     Serialization.writeMultimap(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 303 */     stream.defaultReadObject();
/* 304 */     int keyCount = stream.readInt();
/* 305 */     if (keyCount < 0) {
/* 306 */       throw new InvalidObjectException("Invalid key count " + keyCount);
/*     */     }
/* 308 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/*     */ 
/* 310 */     int tmpSize = 0;
/*     */ 
/* 312 */     for (int i = 0; i < keyCount; i++) {
/* 313 */       Object key = stream.readObject();
/* 314 */       int valueCount = stream.readInt();
/* 315 */       if (valueCount <= 0) {
/* 316 */         throw new InvalidObjectException("Invalid value count " + valueCount);
/*     */       }
/*     */ 
/* 319 */       Object[] array = new Object[valueCount];
/* 320 */       for (int j = 0; j < valueCount; j++) {
/* 321 */         array[j] = stream.readObject();
/*     */       }
/* 323 */       builder.put(key, ImmutableList.copyOf(array));
/* 324 */       tmpSize += valueCount;
/*     */     }
/*     */     ImmutableMap tmpMap;
/*     */     try {
/* 329 */       tmpMap = builder.build();
/*     */     } catch (IllegalArgumentException e) {
/* 331 */       throw ((InvalidObjectException)new InvalidObjectException(e.getMessage()).initCause(e));
/*     */     }
/*     */ 
/* 335 */     ImmutableMultimap.FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
/* 336 */     ImmutableMultimap.FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
/*     */   }
/*     */ 
/*     */   public static final class Builder<K, V> extends ImmutableMultimap.Builder<K, V>
/*     */   {
/*     */     public Builder<K, V> put(K key, V value)
/*     */     {
/* 163 */       super.put(key, value);
/* 164 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(K key, Iterable<? extends V> values)
/*     */     {
/* 175 */       super.putAll(key, values);
/* 176 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(K key, V[] values)
/*     */     {
/* 186 */       super.putAll(key, values);
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<K, V> putAll(Multimap<? extends K, ? extends V> multimap)
/*     */     {
/* 201 */       super.putAll(multimap);
/* 202 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableListMultimap<K, V> build()
/*     */     {
/* 209 */       return (ImmutableListMultimap)super.build();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableListMultimap
 * JD-Core Version:    0.6.0
 */