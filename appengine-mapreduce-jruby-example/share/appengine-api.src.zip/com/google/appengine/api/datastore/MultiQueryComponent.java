/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ class MultiQueryComponent
/*    */   implements Comparable<MultiQueryComponent>
/*    */ {
/*    */   private final Order order;
/*    */   private final List<List<Query.FilterPredicate>> filters;
/*    */ 
/*    */   public MultiQueryComponent(Order order)
/*    */   {
/* 23 */     this.order = order;
/* 24 */     this.filters = new ArrayList();
/*    */   }
/*    */ 
/*    */   public MultiQueryComponent(Order order, List<List<Query.FilterPredicate>> filters) {
/* 28 */     this.order = order;
/* 29 */     this.filters = filters;
/*    */   }
/*    */ 
/*    */   public Order getOrder() {
/* 33 */     return this.order;
/*    */   }
/*    */ 
/*    */   public void addFilters(Query.FilterPredicate[] filters)
/*    */   {
/* 42 */     this.filters.add(Arrays.asList(filters));
/*    */   }
/*    */ 
/*    */   public List<List<Query.FilterPredicate>> getFilters() {
/* 46 */     return this.filters;
/*    */   }
/*    */ 
/*    */   public int compareTo(MultiQueryComponent o)
/*    */   {
/* 51 */     return this.order.compareTo(o.order);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 56 */     return "MultiQueryComponent [filters=" + this.filters + ", order=" + this.order + "]";
/*    */   }
/*    */ 
/*    */   public static enum Order
/*    */   {
/* 17 */     SERIAL, PARALLEL;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.MultiQueryComponent
 * JD-Core Version:    0.6.0
 */