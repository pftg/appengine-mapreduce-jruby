/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(emulated=true)
/*     */ public final class HashBiMap<K, V> extends AbstractBiMap<K, V>
/*     */ {
/*     */ 
/*     */   @GwtIncompatible("Not needed in emulated source")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> HashBiMap<K, V> create()
/*     */   {
/*  46 */     return new HashBiMap();
/*     */   }
/*     */ 
/*     */   public static <K, V> HashBiMap<K, V> create(int expectedSize)
/*     */   {
/*  57 */     return new HashBiMap(expectedSize);
/*     */   }
/*     */ 
/*     */   public static <K, V> HashBiMap<K, V> create(Map<? extends K, ? extends V> map)
/*     */   {
/*  67 */     HashBiMap bimap = create(map.size());
/*  68 */     bimap.putAll(map);
/*  69 */     return bimap;
/*     */   }
/*     */ 
/*     */   private HashBiMap() {
/*  73 */     super(new HashMap(), new HashMap());
/*     */   }
/*     */ 
/*     */   private HashBiMap(int expectedSize) {
/*  77 */     super(new HashMap(Maps.capacity(expectedSize)), new HashMap(Maps.capacity(expectedSize)));
/*     */   }
/*     */ 
/*     */   public V put(@Nullable K key, @Nullable V value)
/*     */   {
/*  84 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */   public V forcePut(@Nullable K key, @Nullable V value) {
/*  88 */     return super.forcePut(key, value);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/*  97 */     stream.defaultWriteObject();
/*  98 */     Serialization.writeMap(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 104 */     stream.defaultReadObject();
/* 105 */     int size = Serialization.readCount(stream);
/* 106 */     setDelegates(Maps.newHashMapWithExpectedSize(size), Maps.newHashMapWithExpectedSize(size));
/*     */ 
/* 108 */     Serialization.populateMap(this, stream, size);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.HashBiMap
 * JD-Core Version:    0.6.0
 */