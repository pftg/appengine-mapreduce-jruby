/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ public class XMPPServiceFactory
/*    */ {
/*    */   public static XMPPService getXMPPService()
/*    */   {
/* 13 */     return new XMPPServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.XMPPServiceFactory
 * JD-Core Version:    0.6.0
 */