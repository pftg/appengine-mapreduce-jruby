/*    */ package javax.mail;
/*    */ 
/*    */ public abstract class BodyPart
/*    */   implements Part
/*    */ {
/*    */   protected Multipart parent;
/*    */ 
/*    */   public Multipart getParent()
/*    */   {
/* 30 */     return this.parent;
/*    */   }
/*    */ 
/*    */   void setParent(Multipart parent)
/*    */   {
/* 36 */     this.parent = parent;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.BodyPart
 * JD-Core Version:    0.6.0
 */