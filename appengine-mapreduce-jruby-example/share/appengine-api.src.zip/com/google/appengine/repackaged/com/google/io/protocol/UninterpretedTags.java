/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.ForwardingMultimap;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Multimap;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Multimaps;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public final class UninterpretedTags extends ForwardingMultimap<Integer, byte[]>
/*     */   implements MessageAppender, Serializable
/*     */ {
/*  41 */   private final Multimap<Integer, byte[]> delegate = Multimaps.newListMultimap(new TreeMap(), ListFactory.INSTANCE);
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   protected Multimap<Integer, byte[]> delegate()
/*     */   {
/*  49 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   public final void putBytes(Integer tag, byte[] data) {
/*  53 */     put(tag, data);
/*     */   }
/*     */ 
/*     */   public final void put(ProtocolSink sink)
/*     */   {
/*  66 */     for (Map.Entry message : entries()) {
/*  67 */       sink.putVarInt(((Integer)message.getKey()).intValue());
/*  68 */       sink.putBytes((byte[])message.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int encodingSize()
/*     */   {
/*  79 */     int result = 0;
/*  80 */     for (Map.Entry message : entries()) {
/*  81 */       Integer wireTag = (Integer)message.getKey();
/*  82 */       result += Protocol.varIntSize(wireTag.intValue()) + ((byte[])message.getValue()).length;
/*     */     }
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */   public final int maxEncodingSize()
/*     */   {
/*  94 */     int result = 0;
/*  95 */     for (byte[] values : values()) {
/*  96 */       result += values.length;
/*     */     }
/*  98 */     result += size() * 5;
/*  99 */     return result;
/*     */   }
/*     */ 
/*     */   public void addLengthDelimited(int tagNumber, byte[] bytes)
/*     */   {
/* 104 */     int lengthSize = Protocol.varIntSize(bytes.length);
/* 105 */     byte[] withLengthPrefix = new byte[lengthSize + bytes.length];
/* 106 */     ProtocolSink sink = new ProtocolSink(withLengthPrefix);
/* 107 */     sink.putVarInt(bytes.length);
/* 108 */     System.arraycopy(bytes, 0, withLengthPrefix, lengthSize, bytes.length);
/* 109 */     put(Integer.valueOf(Protocol.makeTagWord(tagNumber, 2)), withLengthPrefix);
/*     */   }
/*     */ 
/*     */   public void addMessage(int tagNumber, ProtocolMessage message)
/*     */   {
/* 114 */     int encodedSize = message.encodingSize();
/* 115 */     byte[] bytes = new byte[Protocol.varIntSize(encodedSize) + encodedSize];
/* 116 */     ProtocolSink sink = new ProtocolSink(bytes);
/* 117 */     sink.putVarInt(encodedSize);
/* 118 */     message.outputTo(sink);
/* 119 */     put(Integer.valueOf(Protocol.makeTagWord(tagNumber, 2)), bytes);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 131 */     if (this == o) {
/* 132 */       return true;
/*     */     }
/* 134 */     if ((o == null) || (getClass() != o.getClass())) {
/* 135 */       return false;
/*     */     }
/* 137 */     UninterpretedTags that = (UninterpretedTags)o;
/* 138 */     return equals(that);
/*     */   }
/*     */ 
/*     */   public static boolean equivalent(UninterpretedTags t1, UninterpretedTags t2)
/*     */   {
/* 147 */     if ((t1 == null) || (t1.isEmpty())) {
/* 148 */       return (t2 == null) || (t2.isEmpty());
/*     */     }
/* 150 */     return t1.equals(t2);
/*     */   }
/*     */ 
/*     */   public boolean equals(UninterpretedTags that)
/*     */   {
/* 164 */     if ((that == null) || (size() != that.size())) {
/* 165 */       return false;
/*     */     }
/* 167 */     for (Map.Entry thisEntry : asMap().entrySet())
/*     */     {
/* 169 */       Integer this_wiretag = (Integer)thisEntry.getKey();
/* 170 */       List thisArrays = (List)thisEntry.getValue();
/* 171 */       List thatArrays = (List)that.get(this_wiretag);
/* 172 */       if ((thatArrays == null) || (thisArrays.size() != thatArrays.size())) {
/* 173 */         return false;
/*     */       }
/* 175 */       for (int j = thisArrays.size() - 1; j >= 0; j--) {
/* 176 */         if (!Arrays.equals((byte[])thisArrays.get(j), (byte[])thatArrays.get(j))) {
/* 177 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 181 */     return true;
/*     */   }
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 190 */     int hash = 2537462;
/* 191 */     for (Map.Entry message : entries()) {
/* 192 */       hash = hash * 31 + ((Integer)message.getKey()).intValue();
/* 193 */       hash = hash * 31 + Arrays.hashCode((byte[])message.getValue());
/*     */     }
/* 195 */     return hash;
/*     */   }
/*     */ 
/*     */   private static enum ListFactory
/*     */     implements Supplier<List<byte[]>>
/*     */   {
/*  34 */     INSTANCE;
/*     */ 
/*     */     public List<byte[]> get() {
/*  37 */       return new ArrayList();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags
 * JD-Core Version:    0.6.0
 */