package com.google.appengine.repackaged.com.google.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public abstract interface Message extends MessageLite
{
  public abstract Descriptors.Descriptor getDescriptorForType();

  public abstract Message getDefaultInstanceForType();

  public abstract Map<Descriptors.FieldDescriptor, Object> getAllFields();

  public abstract boolean hasField(Descriptors.FieldDescriptor paramFieldDescriptor);

  public abstract Object getField(Descriptors.FieldDescriptor paramFieldDescriptor);

  public abstract int getRepeatedFieldCount(Descriptors.FieldDescriptor paramFieldDescriptor);

  public abstract Object getRepeatedField(Descriptors.FieldDescriptor paramFieldDescriptor, int paramInt);

  public abstract UnknownFieldSet getUnknownFields();

  public abstract boolean equals(Object paramObject);

  public abstract int hashCode();

  public abstract String toString();

  public abstract Builder newBuilderForType();

  public abstract Builder toBuilder();

  public static abstract interface Builder extends MessageLite.Builder
  {
    public abstract Builder clear();

    public abstract Builder mergeFrom(Message paramMessage);

    public abstract Message build();

    public abstract Message buildPartial();

    public abstract Builder clone();

    public abstract Builder mergeFrom(CodedInputStream paramCodedInputStream)
      throws IOException;

    public abstract Builder mergeFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite)
      throws IOException;

    public abstract Descriptors.Descriptor getDescriptorForType();

    public abstract Message getDefaultInstanceForType();

    public abstract Map<Descriptors.FieldDescriptor, Object> getAllFields();

    public abstract Builder newBuilderForField(Descriptors.FieldDescriptor paramFieldDescriptor);

    public abstract boolean hasField(Descriptors.FieldDescriptor paramFieldDescriptor);

    public abstract Object getField(Descriptors.FieldDescriptor paramFieldDescriptor);

    public abstract Builder setField(Descriptors.FieldDescriptor paramFieldDescriptor, Object paramObject);

    public abstract Builder clearField(Descriptors.FieldDescriptor paramFieldDescriptor);

    public abstract int getRepeatedFieldCount(Descriptors.FieldDescriptor paramFieldDescriptor);

    public abstract Object getRepeatedField(Descriptors.FieldDescriptor paramFieldDescriptor, int paramInt);

    public abstract Builder setRepeatedField(Descriptors.FieldDescriptor paramFieldDescriptor, int paramInt, Object paramObject);

    public abstract Builder addRepeatedField(Descriptors.FieldDescriptor paramFieldDescriptor, Object paramObject);

    public abstract UnknownFieldSet getUnknownFields();

    public abstract Builder setUnknownFields(UnknownFieldSet paramUnknownFieldSet);

    public abstract Builder mergeUnknownFields(UnknownFieldSet paramUnknownFieldSet);

    public abstract Builder mergeFrom(ByteString paramByteString)
      throws InvalidProtocolBufferException;

    public abstract Builder mergeFrom(ByteString paramByteString, ExtensionRegistryLite paramExtensionRegistryLite)
      throws InvalidProtocolBufferException;

    public abstract Builder mergeFrom(byte[] paramArrayOfByte)
      throws InvalidProtocolBufferException;

    public abstract Builder mergeFrom(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws InvalidProtocolBufferException;

    public abstract Builder mergeFrom(byte[] paramArrayOfByte, ExtensionRegistryLite paramExtensionRegistryLite)
      throws InvalidProtocolBufferException;

    public abstract Builder mergeFrom(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ExtensionRegistryLite paramExtensionRegistryLite)
      throws InvalidProtocolBufferException;

    public abstract Builder mergeFrom(InputStream paramInputStream)
      throws IOException;

    public abstract Builder mergeFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite)
      throws IOException;

    public abstract boolean mergeDelimitedFrom(InputStream paramInputStream)
      throws IOException;

    public abstract boolean mergeDelimitedFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite)
      throws IOException;
  }
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.Message
 * JD-Core Version:    0.6.0
 */