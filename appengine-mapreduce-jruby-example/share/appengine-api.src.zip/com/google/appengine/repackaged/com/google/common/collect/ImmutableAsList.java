/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ final class ImmutableAsList<E> extends RegularImmutableList<E>
/*    */ {
/*    */   private final transient ImmutableCollection<E> collection;
/*    */ 
/*    */   ImmutableAsList(Object[] array, ImmutableCollection<E> collection)
/*    */   {
/* 34 */     super(array, 0, array.length);
/* 35 */     this.collection = collection;
/*    */   }
/*    */ 
/*    */   public boolean contains(Object target)
/*    */   {
/* 41 */     return this.collection.contains(target);
/*    */   }
/*    */ 
/*    */   private void readObject(ObjectInputStream stream)
/*    */     throws InvalidObjectException
/*    */   {
/* 60 */     throw new InvalidObjectException("Use SerializedForm");
/*    */   }
/*    */ 
/*    */   Object writeReplace() {
/* 64 */     return new SerializedForm(this.collection);
/*    */   }
/*    */ 
/*    */   static class SerializedForm
/*    */     implements Serializable
/*    */   {
/*    */     final ImmutableCollection<?> collection;
/*    */     private static final long serialVersionUID = 0L;
/*    */ 
/*    */     SerializedForm(ImmutableCollection<?> collection)
/*    */     {
/* 50 */       this.collection = collection;
/*    */     }
/*    */     Object readResolve() {
/* 53 */       return this.collection.asList();
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableAsList
 * JD-Core Version:    0.6.0
 */