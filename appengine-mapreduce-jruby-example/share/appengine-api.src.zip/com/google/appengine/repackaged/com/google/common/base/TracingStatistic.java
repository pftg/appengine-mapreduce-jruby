package com.google.appengine.repackaged.com.google.common.base;

import com.google.common.annotations.GoogleInternal;

@GoogleInternal
public abstract interface TracingStatistic
{
  public abstract long start(Thread paramThread);

  public abstract long stop(Thread paramThread);

  public abstract boolean enable();

  public abstract AtomicTracerStatMap getTracingStat();

  public abstract String getUnits();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.TracingStatistic
 * JD-Core Version:    0.6.0
 */