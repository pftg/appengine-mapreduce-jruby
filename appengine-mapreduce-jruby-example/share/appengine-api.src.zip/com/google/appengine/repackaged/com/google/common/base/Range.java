package com.google.appengine.repackaged.com.google.common.base;

import com.google.common.annotations.GoogleInternal;
import com.google.common.annotations.GwtCompatible;
import javax.annotation.Nullable;

@GoogleInternal
@GwtCompatible
public abstract interface Range<V extends Comparable<? super V>>
{
  public abstract boolean contains(V paramV);

  public abstract Range<V> enclose(V paramV);

  public abstract Range<V> enclosure(Range<V> paramRange);

  public abstract V max();

  public abstract boolean equals(@Nullable Object paramObject);

  public abstract int hashCode();

  public abstract Range<V> intersection(Range<V> paramRange);

  public abstract boolean intersects(Range<V> paramRange);

  public abstract boolean isEmpty();

  public abstract V min();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Range
 * JD-Core Version:    0.6.0
 */