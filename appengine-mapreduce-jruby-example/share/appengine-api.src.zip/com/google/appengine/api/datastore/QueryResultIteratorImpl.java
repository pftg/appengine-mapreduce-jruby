/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ class QueryResultIteratorImpl
/*     */   implements QueryResultIterator<Entity>
/*     */ {
/*     */   private final PreparedQuery query;
/*     */   private final QueryResultsSource resultsSource;
/*     */   private final LinkedList<Entity> entityBuffer;
/*     */   private final Transaction txn;
/*  32 */   private Cursor cursor = null;
/*  33 */   private int resultsSinceCursorUpdate = 0;
/*     */ 
/*     */   QueryResultIteratorImpl(PreparedQuery query, List<Entity> prefetchedEntities, QueryResultsSource resultsSource, FetchOptions fetchOptions, Transaction txn)
/*     */   {
/*  45 */     this.query = query;
/*  46 */     this.resultsSource = resultsSource;
/*  47 */     this.entityBuffer = new LinkedList(prefetchedEntities);
/*  48 */     this.txn = txn;
/*     */ 
/*  50 */     if (fetchOptions.getCompile() == Boolean.TRUE)
/*  51 */       if (this.entityBuffer.isEmpty())
/*     */       {
/*  54 */         updateCursorFromResultsSource();
/*     */       }
/*     */       else
/*     */       {
/*  58 */         this.cursor = (fetchOptions.getStartCursor() == null ? new Cursor() : new Cursor(fetchOptions.getStartCursor()));
/*     */ 
/*  63 */         if (fetchOptions.getOffset() != null)
/*  64 */           this.resultsSinceCursorUpdate = fetchOptions.getOffset().intValue();
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  71 */     return ensureLoaded();
/*     */   }
/*     */ 
/*     */   public Entity next() {
/*  75 */     TransactionImpl.ensureTxnActive(this.txn);
/*  76 */     if (ensureLoaded()) {
/*  77 */       this.resultsSinceCursorUpdate += 1;
/*  78 */       return (Entity)this.entityBuffer.removeFirst();
/*     */     }
/*  80 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */   private void updateCursorFromResultsSource()
/*     */   {
/*  85 */     this.cursor = this.resultsSource.getCursor();
/*  86 */     this.resultsSinceCursorUpdate = 0;
/*     */   }
/*     */ 
/*     */   public Cursor getCursor()
/*     */   {
/*  91 */     if (this.entityBuffer.isEmpty())
/*     */     {
/*  94 */       updateCursorFromResultsSource();
/*  95 */     } else if (this.cursor != null)
/*     */     {
/*  99 */       this.cursor.advance(this.resultsSinceCursorUpdate, this.query);
/* 100 */       this.resultsSinceCursorUpdate = 0;
/*     */     }
/*     */ 
/* 104 */     if (this.cursor != null)
/*     */     {
/* 107 */       return new Cursor(this.cursor);
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   public List<Entity> nextList(int maximumElements)
/*     */   {
/* 121 */     TransactionImpl.ensureTxnActive(this.txn);
/* 122 */     ensureLoaded(maximumElements);
/*     */ 
/* 124 */     int numberToReturn = Math.min(maximumElements, this.entityBuffer.size());
/* 125 */     List backingList = this.entityBuffer.subList(0, numberToReturn);
/*     */ 
/* 127 */     List returnList = new ArrayList(backingList);
/* 128 */     backingList.clear();
/* 129 */     this.resultsSinceCursorUpdate += returnList.size();
/* 130 */     return returnList;
/*     */   }
/*     */ 
/*     */   private boolean ensureLoaded()
/*     */   {
/* 141 */     if ((this.entityBuffer.size() <= 0) && (this.resultsSource.hasMoreEntities()))
/*     */     {
/* 143 */       updateCursorFromResultsSource();
/*     */ 
/* 145 */       this.entityBuffer.addAll(this.resultsSource.getMoreEntities());
/*     */     }
/* 147 */     return this.entityBuffer.size() > 0;
/*     */   }
/*     */ 
/*     */   private boolean ensureLoaded(int numberDesired)
/*     */   {
/* 166 */     updateCursorFromResultsSource();
/*     */ 
/* 171 */     while ((this.resultsSource.hasMoreEntities()) && (numberDesired > this.entityBuffer.size())) {
/* 172 */       int numberToLoad = numberDesired - this.entityBuffer.size();
/* 173 */       List nextResults = this.resultsSource.getMoreEntities(numberToLoad);
/* 174 */       if (nextResults.isEmpty()) {
/*     */         break;
/*     */       }
/* 177 */       this.entityBuffer.addAll(nextResults);
/*     */     }
/* 179 */     return this.entityBuffer.size() >= numberDesired;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */   {
/* 188 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryResultIteratorImpl
 * JD-Core Version:    0.6.0
 */