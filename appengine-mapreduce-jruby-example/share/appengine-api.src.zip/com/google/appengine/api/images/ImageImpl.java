/*     */ package com.google.appengine.api.images;
/*     */ 
/*     */ import B;
/*     */ import com.google.appengine.api.blobstore.BlobKey;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ final class ImageImpl
/*     */   implements Image
/*     */ {
/*     */   static final long serialVersionUID = -7970719108027515279L;
/*     */   private byte[] imageData;
/*     */   private int width;
/*     */   private int height;
/*     */   private Image.Format format;
/*     */   private BlobKey blobKey;
/*     */   private static final int EOI_MARKER = 217;
/*     */   private static final int RST_MARKER_START = 208;
/*     */   private static final int RST_MARKER_END = 215;
/*     */   private static final int TEM_MARKER = 1;
/*     */   private static final int HUFFMAN_TABLE_MARKER = 196;
/*     */   private static final int ARITHMETIC_CODING_CONDITIONING_MARKER = 204;
/*     */ 
/*     */   ImageImpl(byte[] imageData)
/*     */   {
/*  43 */     setImageData(imageData);
/*     */   }
/*     */ 
/*     */   ImageImpl(BlobKey blobKey) {
/*  47 */     this.width = -1;
/*  48 */     this.height = -1;
/*  49 */     this.blobKey = blobKey;
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/*  54 */     if (this.width < 0) {
/*  55 */       updateDimensions();
/*     */     }
/*  57 */     return this.width;
/*     */   }
/*     */ 
/*     */   public int getHeight()
/*     */   {
/*  62 */     if (this.height < 0) {
/*  63 */       updateDimensions();
/*     */     }
/*  65 */     return this.height;
/*     */   }
/*     */ 
/*     */   public Image.Format getFormat()
/*     */   {
/*  70 */     if (this.format == null) {
/*  71 */       updateDimensions();
/*     */     }
/*  73 */     return this.format;
/*     */   }
/*     */ 
/*     */   public byte[] getImageData()
/*     */   {
/*  78 */     return this.imageData != null ? (byte[])this.imageData.clone() : null;
/*     */   }
/*     */ 
/*     */   public void setImageData(byte[] imageData)
/*     */   {
/*  83 */     if (imageData == null) {
/*  84 */       throw new IllegalArgumentException("imageData must not be null");
/*     */     }
/*  86 */     if (imageData.length == 0) {
/*  87 */       throw new IllegalArgumentException("imageData must not be empty");
/*     */     }
/*  89 */     this.imageData = ((byte[])imageData.clone());
/*     */ 
/*  91 */     this.width = -1;
/*  92 */     this.height = -1;
/*  93 */     this.format = null;
/*  94 */     this.blobKey = null;
/*     */   }
/*     */ 
/*     */   public BlobKey getBlobKey() {
/*  98 */     return this.blobKey;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 103 */     if ((o instanceof Image)) {
/* 104 */       Image other = (Image)o;
/* 105 */       BlobKey otherBlobKey = other.getBlobKey();
/* 106 */       if ((this.blobKey != null) || (otherBlobKey != null)) {
/* 107 */         return this.blobKey == null ? false : otherBlobKey == null ? true : this.blobKey.equals(otherBlobKey);
/*     */       }
/* 109 */       return Arrays.equals(this.imageData, other.getImageData());
/*     */     }
/*     */ 
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 117 */     if (this.blobKey != null) {
/* 118 */       return this.blobKey.hashCode();
/*     */     }
/* 120 */     return Arrays.hashCode(this.imageData);
/*     */   }
/*     */ 
/*     */   private void updateDimensions()
/*     */   {
/* 129 */     if (this.imageData == null) {
/* 130 */       throw new UnsupportedOperationException("No image data is available.");
/*     */     }
/* 132 */     if (this.imageData.length < 8) {
/* 133 */       throw new IllegalArgumentException("imageData must be a valid image");
/*     */     }
/*     */ 
/* 136 */     if ((this.imageData[0] == 71) && (this.imageData[1] == 73) && (this.imageData[2] == 70)) {
/* 137 */       updateGifDimensions();
/* 138 */       this.format = Image.Format.GIF;
/* 139 */     } else if ((this.imageData[0] == -119) && (this.imageData[1] == 80) && (this.imageData[2] == 78) && (this.imageData[3] == 71) && (this.imageData[4] == 13) && (this.imageData[5] == 10) && (this.imageData[6] == 26) && (this.imageData[7] == 10))
/*     */     {
/* 143 */       updatePngDimensions();
/* 144 */       this.format = Image.Format.PNG;
/* 145 */     } else if ((this.imageData[0] == -1) && (this.imageData[1] == -40)) {
/* 146 */       updateJpegDimensions();
/* 147 */       this.format = Image.Format.JPEG;
/* 148 */     } else if (((this.imageData[0] == 73) && (this.imageData[1] == 73) && (this.imageData[2] == 42) && (this.imageData[3] == 0)) || ((this.imageData[0] == 77) && (this.imageData[1] == 77) && (this.imageData[2] == 0) && (this.imageData[3] == 42)))
/*     */     {
/* 152 */       updateTiffDimensions();
/* 153 */       this.format = Image.Format.TIFF;
/* 154 */     } else if ((this.imageData[0] == 66) && (this.imageData[1] == 77)) {
/* 155 */       updateBmpDimensions();
/* 156 */       this.format = Image.Format.BMP;
/* 157 */     } else if ((this.imageData[0] == 0) && (this.imageData[1] == 0) && (this.imageData[2] == 1) && (this.imageData[3] == 0))
/*     */     {
/* 159 */       updateIcoDimensions();
/* 160 */       this.format = Image.Format.ICO;
/*     */     } else {
/* 162 */       throw new IllegalArgumentException("imageData must be a valid image");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateGifDimensions()
/*     */   {
/* 172 */     if (this.imageData.length < 10) {
/* 173 */       throw new IllegalArgumentException("corrupt GIF format");
/*     */     }
/* 175 */     ByteBuffer buffer = ByteBuffer.wrap(this.imageData);
/* 176 */     buffer.order(ByteOrder.LITTLE_ENDIAN);
/* 177 */     this.width = (buffer.getChar(6) & 0xFFFF);
/* 178 */     this.height = (buffer.getChar(8) & 0xFFFF);
/*     */   }
/*     */ 
/*     */   private void updatePngDimensions()
/*     */   {
/* 188 */     if (this.imageData.length < 24) {
/* 189 */       throw new IllegalArgumentException("corrupt PNG format");
/*     */     }
/* 191 */     ByteBuffer buffer = ByteBuffer.wrap(this.imageData);
/* 192 */     buffer.order(ByteOrder.BIG_ENDIAN);
/* 193 */     this.width = buffer.getInt(16);
/* 194 */     this.height = buffer.getInt(20);
/*     */   }
/*     */ 
/*     */   private void updateJpegDimensions()
/*     */   {
/* 204 */     ByteBuffer buffer = ByteBuffer.wrap(this.imageData);
/* 205 */     buffer.order(ByteOrder.BIG_ENDIAN);
/*     */ 
/* 208 */     if ((extend(buffer.get()) != 255) || (extend(buffer.get()) != 216)) {
/* 209 */       throw new IllegalArgumentException("corrupt JPEG format: Expected SOI marker");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*     */       while (true)
/*     */       {
/* 219 */         int code = extend(buffer.get());
/* 220 */         if (code != 255) {
/*     */           continue;
/*     */         }
/* 223 */         while (code == 255) {
/* 224 */           code = extend(buffer.get());
/*     */         }
/*     */ 
/* 227 */         if (isFrameMarker(code))
/*     */         {
/* 231 */           buffer.position(buffer.position() + 3);
/* 232 */           this.height = extend(buffer.getShort());
/* 233 */           this.width = extend(buffer.getShort());
/* 234 */           return;
/*     */         }
/*     */ 
/* 241 */         if (code == 217) {
/* 242 */           throw new IllegalArgumentException("corrupt JPEG format: No frame sgements found.");
/*     */         }
/*     */ 
/* 245 */         if (((code >= 208) && (code <= 215)) || 
/* 249 */           (code == 1))
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 257 */         int length = extend(buffer.getShort(buffer.position()));
/* 258 */         buffer.position(buffer.position() + length);
/*     */       }
/*     */     } catch (IllegalArgumentException ex) {
/* 261 */       throw new IllegalArgumentException("corrupt JPEG format"); } catch (BufferUnderflowException ex) {
/*     */     }
/* 263 */     throw new IllegalArgumentException("corrupt JPEG format");
/*     */   }
/*     */ 
/*     */   private static boolean isFrameMarker(int code)
/*     */   {
/* 270 */     return ((code & 0xF0) == 192) && (code != 196) && (code != 204);
/*     */   }
/*     */ 
/*     */   private static int extend(byte b)
/*     */   {
/* 276 */     return b & 0xFF;
/*     */   }
/*     */ 
/*     */   private static int extend(short s) {
/* 280 */     return s & 0xFFFF;
/*     */   }
/*     */ 
/*     */   private void updateTiffDimensions()
/*     */   {
/* 290 */     ByteBuffer buffer = ByteBuffer.wrap(this.imageData);
/* 291 */     if (this.imageData[0] == 73) {
/* 292 */       buffer.order(ByteOrder.LITTLE_ENDIAN);
/*     */     }
/* 294 */     int offset = buffer.getInt(4);
/*     */ 
/* 296 */     int ifdSize = buffer.getChar(offset) & 0xFFFF;
/* 297 */     offset += 2;
/* 298 */     for (int i = 0; (i < ifdSize) && (offset + 12 <= this.imageData.length); i++) {
/* 299 */       int tag = buffer.getChar(offset) & 0xFFFF;
/* 300 */       if ((tag == 256) || (tag == 257)) {
/* 301 */         int type = buffer.getChar(offset + 2) & 0xFFFF;
/*     */         int result;
/*     */         int result;
/* 303 */         if (type == 3) {
/* 304 */           result = buffer.getChar(offset + 8) & 0xFFFF;
/*     */         }
/*     */         else
/*     */         {
/*     */           int result;
/* 305 */           if (type == 4)
/* 306 */             result = buffer.getInt(offset + 8);
/*     */           else
/* 308 */             result = this.imageData[(offset + 8)];
/*     */         }
/* 310 */         if (tag == 256) {
/* 311 */           this.width = result;
/* 312 */           if (this.height != -1)
/* 313 */             return;
/*     */         }
/*     */         else {
/* 316 */           this.height = result;
/* 317 */           if (this.width != -1) {
/* 318 */             return;
/*     */           }
/*     */         }
/*     */       }
/* 322 */       offset += 12;
/*     */     }
/* 324 */     if ((this.width == -1) || (this.height == -1))
/* 325 */       throw new IllegalArgumentException("corrupt tiff format");
/*     */   }
/*     */ 
/*     */   private void updateBmpDimensions()
/*     */   {
/* 338 */     if (this.imageData.length < 18) {
/* 339 */       throw new IllegalArgumentException("corrupt BMP format");
/*     */     }
/* 341 */     ByteBuffer buffer = ByteBuffer.wrap(this.imageData);
/* 342 */     buffer.order(ByteOrder.LITTLE_ENDIAN);
/* 343 */     this.width = (buffer.get(6) & 0xFF);
/* 344 */     this.height = (buffer.get(7) & 0xFF);
/* 345 */     int headerLength = buffer.getInt(14);
/* 346 */     if ((headerLength == 12) && (this.imageData.length >= 22)) {
/* 347 */       this.width = (buffer.getChar(18) & 0xFFFF);
/* 348 */       this.height = (buffer.getChar(20) & 0xFFFF);
/* 349 */     } else if (((headerLength == 40) || (headerLength == 108) || (headerLength == 124) || (headerLength == 64)) && (this.imageData.length >= 26))
/*     */     {
/* 352 */       this.width = buffer.getInt(18);
/* 353 */       this.height = buffer.getInt(22);
/*     */     } else {
/* 355 */       throw new IllegalArgumentException("corrupt BMP format");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateIcoDimensions()
/*     */   {
/* 364 */     if (this.imageData.length < 8) {
/* 365 */       throw new IllegalArgumentException("corrupt ICO format");
/*     */     }
/* 367 */     ByteBuffer buffer = ByteBuffer.wrap(this.imageData);
/* 368 */     buffer.order(ByteOrder.LITTLE_ENDIAN);
/* 369 */     this.width = (buffer.get(6) & 0xFF);
/* 370 */     this.height = (buffer.get(7) & 0xFF);
/*     */ 
/* 373 */     if (this.width == 0) {
/* 374 */       this.width = 256;
/*     */     }
/* 376 */     if (this.height == 0)
/* 377 */       this.height = 256;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImageImpl
 * JD-Core Version:    0.6.0
 */