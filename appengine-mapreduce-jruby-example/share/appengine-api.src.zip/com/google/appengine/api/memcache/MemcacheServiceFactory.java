/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ public class MemcacheServiceFactory
/*    */ {
/*    */   public static MemcacheService getMemcacheService()
/*    */   {
/* 27 */     return new MemcacheServiceImpl(null);
/*    */   }
/*    */ 
/*    */   public static MemcacheService getMemcacheService(String namespace)
/*    */   {
/* 45 */     return new MemcacheServiceImpl(namespace);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.MemcacheServiceFactory
 * JD-Core Version:    0.6.0
 */