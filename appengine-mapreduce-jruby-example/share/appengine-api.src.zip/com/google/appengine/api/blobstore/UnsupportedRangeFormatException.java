/*    */ package com.google.appengine.api.blobstore;
/*    */ 
/*    */ public class UnsupportedRangeFormatException extends RangeFormatException
/*    */ {
/*    */   public UnsupportedRangeFormatException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ 
/*    */   public UnsupportedRangeFormatException(String message, Throwable cause) {
/* 17 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.UnsupportedRangeFormatException
 * JD-Core Version:    0.6.0
 */