/*    */ package com.google.appengine.repackaged.com.google.io.protocol;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public final class ProtoString
/*    */ {
/*    */   private final byte[] data;
/*    */ 
/*    */   public ProtoString(byte[] data)
/*    */   {
/* 17 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public ProtoString(String data) {
/* 21 */     this(Protocol.toBytesUtf8(data));
/*    */   }
/*    */ 
/*    */   public final String get() {
/* 25 */     return Protocol.toStringUtf8(this.data);
/*    */   }
/*    */ 
/*    */   public final byte[] getAsBytes() {
/* 29 */     return this.data;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 34 */     return ((obj instanceof ProtoString)) && (Arrays.equals(this.data, ((ProtoString)obj).data));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 39 */     return Arrays.hashCode(this.data);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtoString
 * JD-Core Version:    0.6.0
 */