package javax.mail;

public abstract interface QuotaAwareStore
{
  public abstract Quota[] getQuota(String paramString)
    throws MessagingException;

  public abstract void setQuota(Quota paramQuota)
    throws MessagingException;
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.QuotaAwareStore
 * JD-Core Version:    0.6.0
 */