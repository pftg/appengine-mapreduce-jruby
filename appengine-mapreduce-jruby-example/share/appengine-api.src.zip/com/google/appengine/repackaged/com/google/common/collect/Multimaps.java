/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Joiner;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Joiner.MapJoiner;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import com.google.common.annotations.GwtIncompatible;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GwtCompatible(emulated=true)
/*      */ public final class Multimaps
/*      */ {
/*      */   public static <K, V> Multimap<K, V> newMultimap(Map<K, Collection<V>> map, Supplier<? extends Collection<V>> factory)
/*      */   {
/*  101 */     return new CustomMultimap(map, factory);
/*      */   }
/*      */ 
/*      */   public static <K, V> ListMultimap<K, V> newListMultimap(Map<K, Collection<V>> map, Supplier<? extends List<V>> factory)
/*      */   {
/*  181 */     return new CustomListMultimap(map, factory);
/*      */   }
/*      */ 
/*      */   public static <K, V> SetMultimap<K, V> newSetMultimap(Map<K, Collection<V>> map, Supplier<? extends Set<V>> factory)
/*      */   {
/*  259 */     return new CustomSetMultimap(map, factory);
/*      */   }
/*      */ 
/*      */   public static <K, V> SortedSetMultimap<K, V> newSortedSetMultimap(Map<K, Collection<V>> map, Supplier<? extends SortedSet<V>> factory)
/*      */   {
/*  337 */     return new CustomSortedSetMultimap(map, factory);
/*      */   }
/*      */ 
/*      */   public static <K, V, M extends Multimap<K, V>> M invertFrom(Multimap<? extends V, ? extends K> source, M dest)
/*      */   {
/*  393 */     Preconditions.checkNotNull(dest);
/*  394 */     for (Map.Entry entry : source.entries()) {
/*  395 */       dest.put(entry.getValue(), entry.getKey());
/*      */     }
/*  397 */     return dest;
/*      */   }
/*      */ 
/*      */   public static <K, V> Multimap<K, V> synchronizedMultimap(Multimap<K, V> multimap)
/*      */   {
/*  435 */     return Synchronized.multimap(multimap, null);
/*      */   }
/*      */ 
/*      */   public static <K, V> Multimap<K, V> unmodifiableMultimap(Multimap<K, V> delegate)
/*      */   {
/*  457 */     return new UnmodifiableMultimap(delegate);
/*      */   }
/*      */ 
/*      */   public static <K, V> SetMultimap<K, V> synchronizedSetMultimap(SetMultimap<K, V> multimap)
/*      */   {
/*  715 */     return Synchronized.setMultimap(multimap, null);
/*      */   }
/*      */ 
/*      */   public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(SetMultimap<K, V> delegate)
/*      */   {
/*  738 */     return new UnmodifiableSetMultimap(delegate);
/*      */   }
/*      */ 
/*      */   public static <K, V> SortedSetMultimap<K, V> synchronizedSortedSetMultimap(SortedSetMultimap<K, V> multimap)
/*      */   {
/*  755 */     return Synchronized.sortedSetMultimap(multimap, null);
/*      */   }
/*      */ 
/*      */   public static <K, V> SortedSetMultimap<K, V> unmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate)
/*      */   {
/*  778 */     return new UnmodifiableSortedSetMultimap(delegate);
/*      */   }
/*      */ 
/*      */   public static <K, V> ListMultimap<K, V> synchronizedListMultimap(ListMultimap<K, V> multimap)
/*      */   {
/*  792 */     return Synchronized.listMultimap(multimap, null);
/*      */   }
/*      */ 
/*      */   public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ListMultimap<K, V> delegate)
/*      */   {
/*  815 */     return new UnmodifiableListMultimap(delegate);
/*      */   }
/*      */ 
/*      */   private static <V> Collection<V> unmodifiableValueCollection(Collection<V> collection)
/*      */   {
/*  828 */     if ((collection instanceof SortedSet))
/*  829 */       return Collections.unmodifiableSortedSet((SortedSet)collection);
/*  830 */     if ((collection instanceof Set))
/*  831 */       return Collections.unmodifiableSet((Set)collection);
/*  832 */     if ((collection instanceof List)) {
/*  833 */       return Collections.unmodifiableList((List)collection);
/*      */     }
/*  835 */     return Collections.unmodifiableCollection(collection);
/*      */   }
/*      */ 
/*      */   private static <K, V> Map.Entry<K, Collection<V>> unmodifiableAsMapEntry(Map.Entry<K, Collection<V>> entry)
/*      */   {
/*  851 */     Preconditions.checkNotNull(entry);
/*  852 */     return new AbstractMapEntry(entry) {
/*      */       public K getKey() {
/*  854 */         return this.val$entry.getKey();
/*      */       }
/*      */ 
/*      */       public Collection<V> getValue() {
/*  858 */         return Multimaps.access$100((Collection)this.val$entry.getValue());
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private static <K, V> Collection<Map.Entry<K, V>> unmodifiableEntries(Collection<Map.Entry<K, V>> entries)
/*      */   {
/*  874 */     if ((entries instanceof Set)) {
/*  875 */       return Maps.unmodifiableEntrySet((Set)entries);
/*      */     }
/*  877 */     return new Maps.UnmodifiableEntries(Collections.unmodifiableCollection(entries));
/*      */   }
/*      */ 
/*      */   private static <K, V> Set<Map.Entry<K, Collection<V>>> unmodifiableAsMapEntries(Set<Map.Entry<K, Collection<V>>> asMapEntries)
/*      */   {
/*  893 */     return new UnmodifiableAsMapEntries(Collections.unmodifiableSet(asMapEntries));
/*      */   }
/*      */ 
/*      */   public static <K, V> SetMultimap<K, V> forMap(Map<K, V> map)
/*      */   {
/*  960 */     return new MapMultimap(map);
/*      */   }
/*      */ 
/*      */   public static <K, V> ImmutableListMultimap<K, V> index(Iterable<V> values, Function<? super V, K> keyFunction)
/*      */   {
/* 1234 */     Preconditions.checkNotNull(keyFunction);
/* 1235 */     ImmutableListMultimap.Builder builder = ImmutableListMultimap.builder();
/*      */ 
/* 1237 */     for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 1238 */       Preconditions.checkNotNull(value, values);
/* 1239 */       builder.put(keyFunction.apply(value), value);
/*      */     }
/* 1241 */     return builder.build();
/*      */   }
/*      */ 
/*      */   private static class MapMultimap<K, V>
/*      */     implements SetMultimap<K, V>, Serializable
/*      */   {
/*      */     final Map<K, V> map;
/*      */     transient Map<K, Collection<V>> asMap;
/* 1097 */     private static final Joiner.MapJoiner joiner = Joiner.on("], ").withKeyValueSeparator("=[").useForNull("null");
/*      */     private static final long serialVersionUID = 7845222491160860175L;
/*      */ 
/*      */     MapMultimap(Map<K, V> map)
/*      */     {
/*  970 */       this.map = ((Map)Preconditions.checkNotNull(map));
/*      */     }
/*      */ 
/*      */     public int size() {
/*  974 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/*  978 */       return this.map.isEmpty();
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  982 */       return this.map.containsKey(key);
/*      */     }
/*      */ 
/*      */     public boolean containsValue(Object value) {
/*  986 */       return this.map.containsValue(value);
/*      */     }
/*      */ 
/*      */     public boolean containsEntry(Object key, Object value) {
/*  990 */       return this.map.entrySet().contains(Maps.immutableEntry(key, value));
/*      */     }
/*      */ 
/*      */     public Set<V> get(K key) {
/*  994 */       return new AbstractSet(key) {
/*      */         public Iterator<V> iterator() {
/*  996 */           return new Iterator() {
/*      */             int i;
/*      */ 
/* 1000 */             public boolean hasNext() { return (this.i == 0) && (Multimaps.MapMultimap.this.map.containsKey(Multimaps.MapMultimap.1.this.val$key)); }
/*      */ 
/*      */             public V next()
/*      */             {
/* 1004 */               if (!hasNext()) {
/* 1005 */                 throw new NoSuchElementException();
/*      */               }
/* 1007 */               this.i += 1;
/* 1008 */               return Multimaps.MapMultimap.this.map.get(Multimaps.MapMultimap.1.this.val$key);
/*      */             }
/*      */ 
/*      */             public void remove() {
/* 1012 */               Preconditions.checkState(this.i == 1);
/* 1013 */               this.i = -1;
/* 1014 */               Multimaps.MapMultimap.this.map.remove(Multimaps.MapMultimap.1.this.val$key);
/*      */             } } ;
/*      */         }
/*      */ 
/*      */         public int size() {
/* 1020 */           return Multimaps.MapMultimap.this.map.containsKey(this.val$key) ? 1 : 0;
/*      */         } } ;
/*      */     }
/*      */ 
/*      */     public boolean put(K key, V value) {
/* 1026 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public boolean putAll(K key, Iterable<? extends V> values) {
/* 1030 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
/* 1034 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Set<V> replaceValues(K key, Iterable<? extends V> values) {
/* 1038 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public boolean remove(Object key, Object value) {
/* 1042 */       return this.map.entrySet().remove(Maps.immutableEntry(key, value));
/*      */     }
/*      */ 
/*      */     public Set<V> removeAll(Object key) {
/* 1046 */       Set values = new HashSet(2);
/* 1047 */       if (!this.map.containsKey(key)) {
/* 1048 */         return values;
/*      */       }
/* 1050 */       values.add(this.map.remove(key));
/* 1051 */       return values;
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1055 */       this.map.clear();
/*      */     }
/*      */ 
/*      */     public Set<K> keySet() {
/* 1059 */       return this.map.keySet();
/*      */     }
/*      */ 
/*      */     public Multiset<K> keys() {
/* 1063 */       return Multisets.forSet(this.map.keySet());
/*      */     }
/*      */ 
/*      */     public Collection<V> values() {
/* 1067 */       return this.map.values();
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, V>> entries() {
/* 1071 */       return this.map.entrySet();
/*      */     }
/*      */ 
/*      */     public Map<K, Collection<V>> asMap() {
/* 1075 */       Map result = this.asMap;
/* 1076 */       if (result == null) {
/* 1077 */         this.asMap = (result = new AsMap());
/*      */       }
/* 1079 */       return result;
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object) {
/* 1083 */       if (object == this) {
/* 1084 */         return true;
/*      */       }
/* 1086 */       if ((object instanceof Multimap)) {
/* 1087 */         Multimap that = (Multimap)object;
/* 1088 */         return (size() == that.size()) && (asMap().equals(that.asMap()));
/*      */       }
/* 1090 */       return false;
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1094 */       return this.map.hashCode();
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1101 */       if (this.map.isEmpty()) {
/* 1102 */         return "{}";
/*      */       }
/* 1104 */       StringBuilder builder = new StringBuilder(this.map.size() * 16).append('{');
/* 1105 */       joiner.appendTo(builder, this.map);
/* 1106 */       return "]}";
/*      */     }
/*      */ 
/*      */     class AsMap extends Maps.ImprovedAbstractMap<K, Collection<V>>
/*      */     {
/*      */       AsMap()
/*      */       {
/*      */       }
/*      */ 
/*      */       protected Set<Map.Entry<K, Collection<V>>> createEntrySet()
/*      */       {
/* 1170 */         return new Multimaps.MapMultimap.AsMapEntries(Multimaps.MapMultimap.this);
/*      */       }
/*      */ 
/*      */       public boolean containsKey(Object key)
/*      */       {
/* 1176 */         return Multimaps.MapMultimap.this.map.containsKey(key);
/*      */       }
/*      */ 
/*      */       public Collection<V> get(Object key)
/*      */       {
/* 1181 */         Collection collection = Multimaps.MapMultimap.this.get(key);
/* 1182 */         return collection.isEmpty() ? null : collection;
/*      */       }
/*      */ 
/*      */       public Collection<V> remove(Object key) {
/* 1186 */         Collection collection = Multimaps.MapMultimap.this.removeAll(key);
/* 1187 */         return collection.isEmpty() ? null : collection;
/*      */       }
/*      */     }
/*      */ 
/*      */     class AsMapEntries extends AbstractSet<Map.Entry<K, Collection<V>>>
/*      */     {
/*      */       AsMapEntries()
/*      */       {
/*      */       }
/*      */ 
/*      */       public int size()
/*      */       {
/* 1112 */         return Multimaps.MapMultimap.this.map.size();
/*      */       }
/*      */ 
/*      */       public Iterator<Map.Entry<K, Collection<V>>> iterator() {
/* 1116 */         return new Iterator() {
/* 1117 */           final Iterator<K> keys = Multimaps.MapMultimap.this.map.keySet().iterator();
/*      */ 
/*      */           public boolean hasNext() {
/* 1120 */             return this.keys.hasNext();
/*      */           }
/*      */           public Map.Entry<K, Collection<V>> next() {
/* 1123 */             Object key = this.keys.next();
/* 1124 */             return new AbstractMapEntry(key) {
/*      */               public K getKey() {
/* 1126 */                 return this.val$key;
/*      */               }
/*      */               public Collection<V> getValue() {
/* 1129 */                 return Multimaps.MapMultimap.this.get(this.val$key);
/*      */               } } ;
/*      */           }
/*      */ 
/*      */           public void remove() {
/* 1134 */             this.keys.remove();
/*      */           } } ;
/*      */       }
/*      */ 
/*      */       public boolean contains(Object o) {
/* 1140 */         if (!(o instanceof Map.Entry)) {
/* 1141 */           return false;
/*      */         }
/* 1143 */         Map.Entry entry = (Map.Entry)o;
/* 1144 */         if (!(entry.getValue() instanceof Set)) {
/* 1145 */           return false;
/*      */         }
/* 1147 */         Set set = (Set)entry.getValue();
/* 1148 */         return (set.size() == 1) && (Multimaps.MapMultimap.this.containsEntry(entry.getKey(), set.iterator().next()));
/*      */       }
/*      */ 
/*      */       public boolean remove(Object o)
/*      */       {
/* 1153 */         if (!(o instanceof Map.Entry)) {
/* 1154 */           return false;
/*      */         }
/* 1156 */         Map.Entry entry = (Map.Entry)o;
/* 1157 */         if (!(entry.getValue() instanceof Set)) {
/* 1158 */           return false;
/*      */         }
/* 1160 */         Set set = (Set)entry.getValue();
/* 1161 */         return (set.size() == 1) && (Multimaps.MapMultimap.this.map.entrySet().remove(Maps.immutableEntry(entry.getKey(), set.iterator().next())));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class UnmodifiableAsMapEntries<K, V> extends ForwardingSet<Map.Entry<K, Collection<V>>>
/*      */   {
/*      */     private final Set<Map.Entry<K, Collection<V>>> delegate;
/*      */ 
/*      */     UnmodifiableAsMapEntries(Set<Map.Entry<K, Collection<V>>> delegate)
/*      */     {
/*  902 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     protected Set<Map.Entry<K, Collection<V>>> delegate() {
/*  906 */       return this.delegate;
/*      */     }
/*      */ 
/*      */     public Iterator<Map.Entry<K, Collection<V>>> iterator() {
/*  910 */       Iterator iterator = this.delegate.iterator();
/*  911 */       return new ForwardingIterator(iterator) {
/*      */         protected Iterator<Map.Entry<K, Collection<V>>> delegate() {
/*  913 */           return this.val$iterator;
/*      */         }
/*      */         public Map.Entry<K, Collection<V>> next() {
/*  916 */           return Multimaps.access$300((Map.Entry)this.val$iterator.next());
/*      */         } } ;
/*      */     }
/*      */ 
/*      */     public Object[] toArray() {
/*  922 */       return ObjectArrays.toArrayImpl(this);
/*      */     }
/*      */ 
/*      */     public <T> T[] toArray(T[] array) {
/*  926 */       return ObjectArrays.toArrayImpl(this, array);
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/*  930 */       return Maps.containsEntryImpl(delegate(), o);
/*      */     }
/*      */ 
/*      */     public boolean containsAll(Collection<?> c) {
/*  934 */       return Collections2.containsAll(this, c);
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object) {
/*  938 */       return Collections2.setEquals(this, object);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnmodifiableSortedSetMultimap<K, V> extends Multimaps.UnmodifiableSetMultimap<K, V>
/*      */     implements SortedSetMultimap<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     UnmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate)
/*      */     {
/*  680 */       super();
/*      */     }
/*      */     public SortedSetMultimap<K, V> delegate() {
/*  683 */       return (SortedSetMultimap)super.delegate();
/*      */     }
/*      */     public SortedSet<V> get(K key) {
/*  686 */       return Collections.unmodifiableSortedSet(delegate().get(key));
/*      */     }
/*      */     public SortedSet<V> removeAll(Object key) {
/*  689 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values) {
/*  693 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     public Comparator<? super V> valueComparator() {
/*  696 */       return delegate().valueComparator();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnmodifiableSetMultimap<K, V> extends Multimaps.UnmodifiableMultimap<K, V>
/*      */     implements SetMultimap<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     UnmodifiableSetMultimap(SetMultimap<K, V> delegate)
/*      */     {
/*  652 */       super();
/*      */     }
/*      */     public SetMultimap<K, V> delegate() {
/*  655 */       return (SetMultimap)super.delegate();
/*      */     }
/*      */ 
/*      */     public Set<V> get(K key)
/*      */     {
/*  662 */       return Collections.unmodifiableSet(delegate().get(key));
/*      */     }
/*      */     public Set<Map.Entry<K, V>> entries() {
/*  665 */       return Maps.unmodifiableEntrySet(delegate().entries());
/*      */     }
/*      */     public Set<V> removeAll(Object key) {
/*  668 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Set<V> replaceValues(K key, Iterable<? extends V> values) {
/*  672 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnmodifiableListMultimap<K, V> extends Multimaps.UnmodifiableMultimap<K, V>
/*      */     implements ListMultimap<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     UnmodifiableListMultimap(ListMultimap<K, V> delegate)
/*      */     {
/*  631 */       super();
/*      */     }
/*      */     public ListMultimap<K, V> delegate() {
/*  634 */       return (ListMultimap)super.delegate();
/*      */     }
/*      */     public List<V> get(K key) {
/*  637 */       return Collections.unmodifiableList(delegate().get(key));
/*      */     }
/*      */     public List<V> removeAll(Object key) {
/*  640 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public List<V> replaceValues(K key, Iterable<? extends V> values) {
/*  644 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnmodifiableAsMapValues<V> extends ForwardingCollection<Collection<V>>
/*      */   {
/*      */     final Collection<Collection<V>> delegate;
/*      */ 
/*      */     UnmodifiableAsMapValues(Collection<Collection<V>> delegate)
/*      */     {
/*  595 */       this.delegate = Collections.unmodifiableCollection(delegate);
/*      */     }
/*      */     protected Collection<Collection<V>> delegate() {
/*  598 */       return this.delegate;
/*      */     }
/*      */     public Iterator<Collection<V>> iterator() {
/*  601 */       Iterator iterator = this.delegate.iterator();
/*  602 */       return new Iterator(iterator) {
/*      */         public boolean hasNext() {
/*  604 */           return this.val$iterator.hasNext();
/*      */         }
/*      */         public Collection<V> next() {
/*  607 */           return Multimaps.access$100((Collection)this.val$iterator.next());
/*      */         }
/*      */         public void remove() {
/*  610 */           throw new UnsupportedOperationException();
/*      */         } } ;
/*      */     }
/*      */ 
/*      */     public Object[] toArray() {
/*  615 */       return ObjectArrays.toArrayImpl(this);
/*      */     }
/*      */     public <T> T[] toArray(T[] array) {
/*  618 */       return ObjectArrays.toArrayImpl(this, array);
/*      */     }
/*      */     public boolean contains(Object o) {
/*  621 */       return Iterators.contains(iterator(), o);
/*      */     }
/*      */     public boolean containsAll(Collection<?> c) {
/*  624 */       return Collections2.containsAll(this, c);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnmodifiableMultimap<K, V> extends ForwardingMultimap<K, V>
/*      */     implements Serializable
/*      */   {
/*      */     final Multimap<K, V> delegate;
/*      */     transient Collection<Map.Entry<K, V>> entries;
/*      */     transient Multiset<K> keys;
/*      */     transient Set<K> keySet;
/*      */     transient Collection<V> values;
/*      */     transient Map<K, Collection<V>> map;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     UnmodifiableMultimap(Multimap<K, V> delegate)
/*      */     {
/*  470 */       this.delegate = ((Multimap)Preconditions.checkNotNull(delegate));
/*      */     }
/*      */ 
/*      */     protected Multimap<K, V> delegate() {
/*  474 */       return this.delegate;
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  478 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Map<K, Collection<V>> asMap() {
/*  482 */       Map result = this.map;
/*  483 */       if (result == null) {
/*  484 */         Map unmodifiableMap = Collections.unmodifiableMap(this.delegate.asMap());
/*      */ 
/*  486 */         this.map = (result = new ForwardingMap(unmodifiableMap) { Set<Map.Entry<K, Collection<V>>> entrySet;
/*      */           Collection<Collection<V>> asMapValues;
/*      */ 
/*  488 */           protected Map<K, Collection<V>> delegate() { return this.val$unmodifiableMap;
/*      */           }
/*      */ 
/*      */           public Set<Map.Entry<K, Collection<V>>> entrySet()
/*      */           {
/*  494 */             Set result = this.entrySet;
/*  495 */             return result == null ? (this.entrySet = Multimaps.access$000(this.val$unmodifiableMap.entrySet())) : result;
/*      */           }
/*      */ 
/*      */           public Collection<V> get(Object key)
/*      */           {
/*  502 */             Collection collection = (Collection)this.val$unmodifiableMap.get(key);
/*  503 */             return collection == null ? null : Multimaps.access$100(collection);
/*      */           }
/*      */ 
/*      */           public Collection<Collection<V>> values()
/*      */           {
/*  510 */             Collection result = this.asMapValues;
/*  511 */             return result == null ? (this.asMapValues = new Multimaps.UnmodifiableAsMapValues(this.val$unmodifiableMap.values())) : result;
/*      */           }
/*      */ 
/*      */           public boolean containsValue(Object o)
/*      */           {
/*  518 */             return values().contains(o);
/*      */           } } );
/*      */       }
/*  522 */       return result;
/*      */     }
/*      */ 
/*      */     public Collection<Map.Entry<K, V>> entries() {
/*  526 */       Collection result = this.entries;
/*  527 */       if (result == null) {
/*  528 */         this.entries = (result = Multimaps.access$200(this.delegate.entries()));
/*      */       }
/*  530 */       return result;
/*      */     }
/*      */ 
/*      */     public Collection<V> get(K key) {
/*  534 */       return Multimaps.access$100(this.delegate.get(key));
/*      */     }
/*      */ 
/*      */     public Multiset<K> keys() {
/*  538 */       Multiset result = this.keys;
/*  539 */       if (result == null) {
/*  540 */         this.keys = (result = Multisets.unmodifiableMultiset(this.delegate.keys()));
/*      */       }
/*  542 */       return result;
/*      */     }
/*      */ 
/*      */     public Set<K> keySet() {
/*  546 */       Set result = this.keySet;
/*  547 */       if (result == null) {
/*  548 */         this.keySet = (result = Collections.unmodifiableSet(this.delegate.keySet()));
/*      */       }
/*  550 */       return result;
/*      */     }
/*      */ 
/*      */     public boolean put(K key, V value) {
/*  554 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public boolean putAll(K key, Iterable<? extends V> values)
/*      */     {
/*  559 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*      */     {
/*  564 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public boolean remove(Object key, Object value) {
/*  568 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Collection<V> removeAll(Object key) {
/*  572 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*      */     {
/*  577 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Collection<V> values() {
/*  581 */       Collection result = this.values;
/*  582 */       if (result == null) {
/*  583 */         this.values = (result = Collections.unmodifiableCollection(this.delegate.values()));
/*      */       }
/*  585 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CustomSortedSetMultimap<K, V> extends AbstractSortedSetMultimap<K, V>
/*      */   {
/*      */     transient Supplier<? extends SortedSet<V>> factory;
/*      */     transient Comparator<? super V> valueComparator;
/*      */ 
/*      */     @GwtIncompatible("not needed in emulated source")
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     CustomSortedSetMultimap(Map<K, Collection<V>> map, Supplier<? extends SortedSet<V>> factory)
/*      */     {
/*  347 */       super();
/*  348 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*  349 */       this.valueComparator = ((SortedSet)factory.get()).comparator();
/*      */     }
/*      */ 
/*      */     protected SortedSet<V> createCollection() {
/*  353 */       return (SortedSet)this.factory.get();
/*      */     }
/*      */ 
/*      */     public Comparator<? super V> valueComparator() {
/*  357 */       return this.valueComparator;
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectOutputStream")
/*      */     private void writeObject(ObjectOutputStream stream) throws IOException {
/*  363 */       stream.defaultWriteObject();
/*  364 */       stream.writeObject(this.factory);
/*  365 */       stream.writeObject(backingMap());
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectInputStream")
/*      */     private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*      */     {
/*  372 */       stream.defaultReadObject();
/*  373 */       this.factory = ((Supplier)stream.readObject());
/*  374 */       this.valueComparator = ((SortedSet)this.factory.get()).comparator();
/*  375 */       Map map = (Map)stream.readObject();
/*  376 */       setMap(map);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CustomSetMultimap<K, V> extends AbstractSetMultimap<K, V>
/*      */   {
/*      */     transient Supplier<? extends Set<V>> factory;
/*      */ 
/*      */     @GwtIncompatible("not needed in emulated source")
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     CustomSetMultimap(Map<K, Collection<V>> map, Supplier<? extends Set<V>> factory)
/*      */     {
/*  268 */       super();
/*  269 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*      */     }
/*      */ 
/*      */     protected Set<V> createCollection() {
/*  273 */       return (Set)this.factory.get();
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectOutputStream")
/*      */     private void writeObject(ObjectOutputStream stream) throws IOException {
/*  279 */       stream.defaultWriteObject();
/*  280 */       stream.writeObject(this.factory);
/*  281 */       stream.writeObject(backingMap());
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectInputStream")
/*      */     private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*      */     {
/*  288 */       stream.defaultReadObject();
/*  289 */       this.factory = ((Supplier)stream.readObject());
/*  290 */       Map map = (Map)stream.readObject();
/*  291 */       setMap(map);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CustomListMultimap<K, V> extends AbstractListMultimap<K, V>
/*      */   {
/*      */     transient Supplier<? extends List<V>> factory;
/*      */ 
/*      */     @GwtIncompatible("java serialization not supported")
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     CustomListMultimap(Map<K, Collection<V>> map, Supplier<? extends List<V>> factory)
/*      */     {
/*  190 */       super();
/*  191 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*      */     }
/*      */ 
/*      */     protected List<V> createCollection() {
/*  195 */       return (List)this.factory.get();
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectOutputStream")
/*      */     private void writeObject(ObjectOutputStream stream) throws IOException {
/*  201 */       stream.defaultWriteObject();
/*  202 */       stream.writeObject(this.factory);
/*  203 */       stream.writeObject(backingMap());
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectInputStream")
/*      */     private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*      */     {
/*  210 */       stream.defaultReadObject();
/*  211 */       this.factory = ((Supplier)stream.readObject());
/*  212 */       Map map = (Map)stream.readObject();
/*  213 */       setMap(map);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CustomMultimap<K, V> extends AbstractMultimap<K, V>
/*      */   {
/*      */     transient Supplier<? extends Collection<V>> factory;
/*      */ 
/*      */     @GwtIncompatible("java serialization not supported")
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     CustomMultimap(Map<K, Collection<V>> map, Supplier<? extends Collection<V>> factory)
/*      */     {
/*  109 */       super();
/*  110 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*      */     }
/*      */ 
/*      */     protected Collection<V> createCollection() {
/*  114 */       return (Collection)this.factory.get();
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectOutputStream")
/*      */     private void writeObject(ObjectOutputStream stream)
/*      */       throws IOException
/*      */     {
/*  123 */       stream.defaultWriteObject();
/*  124 */       stream.writeObject(this.factory);
/*  125 */       stream.writeObject(backingMap());
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectInputStream")
/*      */     private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*      */     {
/*  132 */       stream.defaultReadObject();
/*  133 */       this.factory = ((Supplier)stream.readObject());
/*  134 */       Map map = (Map)stream.readObject();
/*  135 */       setMap(map);
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Multimaps
 * JD-Core Version:    0.6.0
 */