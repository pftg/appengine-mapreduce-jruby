/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.X;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.ImmutableMap;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Maps;
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.proto.ProtocolDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public final class MessageSet extends ProtocolMessage<MessageSet>
/*     */ {
/*     */   private static final byte TAG_BEGIN_ITEM_GROUP = 11;
/*     */   private static final byte TAG_END_ITEM_GROUP = 12;
/*     */   private static final byte TAG_TYPE_ID = 16;
/*     */   private static final byte TAG_MESSAGE = 26;
/*     */   private final Map<Integer, Item> items;
/*  71 */   private static final Logger LOG = Logger.getLogger(MessageSet.class.getName());
/*     */ 
/*  77 */   public static final MessageSet IMMUTABLE_DEFAULT_INSTANCE = new MessageSet(ImmutableMap.of());
/*     */   private static ProtocolType cachedClassProtocolType;
/* 742 */   private static final ConcurrentMap<Object, TypedIdInfo> typedIdHash = Maps.newConcurrentMap();
/*     */ 
/* 746 */   private static final TypedIdInfo TYPED_ID_ERROR = new TypedIdInfo(null, null, 0);
/*     */ 
/* 749 */   private static boolean allowDuplicates = false;
/*     */   public static final int NO_TYPE_ID = 0;
/*     */ 
/*     */   public MessageSet getDefaultInstanceForType()
/*     */   {
/*  82 */     return IMMUTABLE_DEFAULT_INSTANCE;
/*     */   }
/*     */ 
/*     */   public MessageSet()
/*     */   {
/*  87 */     this.items = Maps.newTreeMap();
/*     */   }
/*     */ 
/*     */   private MessageSet(Map<Integer, Item> items)
/*     */   {
/*  92 */     this.items = items;
/*     */   }
/*     */ 
/*     */   public <T extends ProtocolMessage> T get(Class<T> messageClass)
/*     */   {
/* 115 */     int typeId = getTypeId(messageClass);
/* 116 */     if (typeId == 0) {
/* 117 */       throw newNoTypeIdException(messageClass);
/*     */     }
/* 119 */     Item item = (Item)this.items.get(Integer.valueOf(typeId));
/* 120 */     if ((item == null) || (!item.parse(messageClass))) {
/* 121 */       return ProtocolSupport.newInstance(messageClass);
/*     */     }
/* 123 */     return item.message;
/*     */   }
/*     */ 
/*     */   public <T extends ProtocolMessage> T mutable(Class<T> messageClass)
/*     */   {
/* 133 */     int typeId = getTypeId(messageClass);
/* 134 */     if (typeId == 0) {
/* 135 */       throw newNoTypeIdException(messageClass);
/*     */     }
/* 137 */     Item item = (Item)this.items.get(Integer.valueOf(typeId));
/*     */ 
/* 139 */     if ((item == null) || (!item.parse(messageClass))) {
/* 140 */       item = new Item(messageClass);
/* 141 */       this.items.put(Integer.valueOf(typeId), item);
/*     */     }
/*     */ 
/* 144 */     return item.message;
/*     */   }
/*     */ 
/*     */   public boolean has(Class<? extends ProtocolMessage> messageClass)
/*     */   {
/* 149 */     int typeId = getTypeId(messageClass);
/* 150 */     if (typeId == 0) {
/* 151 */       return false;
/*     */     }
/* 153 */     Item item = (Item)this.items.get(Integer.valueOf(typeId));
/* 154 */     return (item != null) && (item.parse(messageClass));
/*     */   }
/*     */ 
/*     */   public boolean hasUnparsed(Class<? extends ProtocolMessage> messageClass)
/*     */   {
/* 164 */     int typeId = getTypeId(messageClass);
/* 165 */     return (typeId != 0) && (this.items.containsKey(Integer.valueOf(typeId)));
/*     */   }
/*     */ 
/*     */   public void remove(Class<? extends ProtocolMessage> messageClass)
/*     */   {
/* 170 */     int typeId = getTypeId(messageClass);
/* 171 */     if (typeId == 0) {
/* 172 */       throw newNoTypeIdException(messageClass);
/*     */     }
/* 174 */     this.items.remove(Integer.valueOf(typeId));
/*     */   }
/*     */ 
/*     */   public Set<Integer> getTypeIds()
/*     */   {
/* 179 */     return Collections.unmodifiableSet(this.items.keySet());
/*     */   }
/*     */ 
/*     */   public int numMessages()
/*     */   {
/* 184 */     return this.items.size();
/*     */   }
/*     */ 
/*     */   public MessageSet mergeFrom(MessageSet that)
/*     */   {
/* 197 */     X.assertTrue(that != this);
/*     */ 
/* 199 */     for (Map.Entry entry : that.items.entrySet()) {
/* 200 */       Item item = (Item)this.items.get(entry.getKey());
/* 201 */       if (item != null)
/* 202 */         item.mergeFrom((Item)entry.getValue());
/*     */       else {
/* 204 */         this.items.put(entry.getKey(), ((Item)entry.getValue()).copy());
/*     */       }
/*     */     }
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean equals(MessageSet that, boolean ignoreUninterpreted) {
/* 211 */     if (this == that) {
/* 212 */       return true;
/*     */     }
/* 214 */     return this.items.equals(that.items);
/*     */   }
/*     */ 
/*     */   public boolean equalsIgnoreUninterpreted(MessageSet that) {
/* 218 */     return equals(that, true);
/*     */   }
/*     */ 
/*     */   public boolean equals(MessageSet that) {
/* 222 */     return equals(that, false);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object that) {
/* 226 */     return ((that instanceof MessageSet)) && (equals((MessageSet)that));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 242 */     throw new RuntimeException("Do not use MessageSets as hash table keys.");
/*     */   }
/*     */ 
/*     */   public boolean isInitialized() {
/* 246 */     for (Item item : this.items.values()) {
/* 247 */       if (!item.isInitialized()) {
/* 248 */         return false;
/*     */       }
/*     */     }
/* 251 */     return true;
/*     */   }
/*     */ 
/*     */   public int encodingSize() {
/* 255 */     int size = 0;
/* 256 */     for (Map.Entry entry : this.items.entrySet()) {
/* 257 */       size += ((Item)entry.getValue()).encodingSize(((Integer)entry.getKey()).intValue());
/*     */     }
/* 259 */     return size;
/*     */   }
/*     */ 
/*     */   public int maxEncodingSize() {
/* 263 */     int size = this.items.size() * 14;
/* 264 */     for (Item item : this.items.values()) {
/* 265 */       size += item.message.maxEncodingSize();
/*     */     }
/* 267 */     return size;
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 271 */     this.items.clear();
/*     */   }
/*     */ 
/*     */   public MessageSet newInstance() {
/* 275 */     return new MessageSet();
/*     */   }
/*     */ 
/*     */   public void outputTo(ProtocolSink sink) {
/* 279 */     for (Map.Entry entry : this.items.entrySet())
/* 280 */       ((Item)entry.getValue()).output(sink, ((Integer)entry.getKey()).intValue());
/*     */   }
/*     */ 
/*     */   public boolean merge(ProtocolSource source)
/*     */   {
/* 285 */     while (source.remaining() > 0) {
/* 286 */       int tag = source.getVarInt();
/* 287 */       switch (tag)
/*     */       {
/*     */       case 0:
/* 291 */         return false;
/*     */       case 11:
/* 294 */         Item item = new Item();
/* 295 */         int typeId = item.decode(source);
/* 296 */         if (typeId == 0) {
/* 297 */           return false;
/*     */         }
/*     */ 
/* 300 */         Item oldItem = (Item)this.items.get(Integer.valueOf(typeId));
/* 301 */         if (oldItem == null)
/* 302 */           this.items.put(Integer.valueOf(typeId), item);
/*     */         else {
/* 304 */           oldItem.mergeFrom(item);
/*     */         }
/* 306 */         break;
/*     */       default:
/* 310 */         source.skipData(tag);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 315 */     return true;
/*     */   }
/*     */ 
/*     */   public ProtocolType getProtocolType()
/*     */   {
/* 330 */     return getClassProtocolType();
/*     */   }
/*     */ 
/*     */   private static synchronized ProtocolType getClassProtocolType()
/*     */   {
/* 336 */     if (cachedClassProtocolType == null) {
/* 337 */       String name = MessageSet.class.getName();
/* 338 */       String fileName = "java/" + name.replace('.', '/') + ".java";
/* 339 */       ProtocolDescriptor descriptor = new ProtocolDescriptor().setName(name).setProtoName("MessageSet").setFilename(fileName);
/*     */ 
/* 344 */       cachedClassProtocolType = new ProtocolType(MessageSet.class, null, new ProtocolType.FieldType[0], descriptor)
/*     */       {
/*     */         protected void visitInternal(ProtocolMessage message, ProtocolType.Visitor visitor, Iterable<ProtocolType.FieldType> fields) {
/* 347 */           ((MessageSet)message).visit(visitor);
/*     */         }
/*     */ 
/*     */         protected void visitInternal(ProtocolMessage message, MessageVisitor visitor, Iterable<ProtocolType.FieldType> fields) {
/* 351 */           ((MessageSet)message).visit(visitor);
/*     */         }
/*     */         public ProtocolDescriptor getProtocolDescriptor() {
/* 354 */           return this.val$descriptor;
/*     */         } } ;
/*     */     }
/* 358 */     return cachedClassProtocolType;
/*     */   }
/*     */ 
/*     */   private void visit(ProtocolType.Visitor visitor)
/*     */   {
/* 366 */     for (Map.Entry entry : this.items.entrySet()) {
/* 367 */       int typeId = ((Integer)entry.getKey()).intValue();
/* 368 */       Item item = (Item)entry.getValue();
/*     */ 
/* 371 */       if (item.messageClass == null) {
/* 372 */         Class clazz = getRegisteredClazz(typeId);
/* 373 */         if (clazz != null)
/* 374 */           item.parse(clazz);
/*     */       }
/*     */       FieldType fieldType;
/*     */       FieldType fieldType;
/* 377 */       if (item.messageClass == null)
/* 378 */         fieldType = new FieldType(typeId);
/*     */       else {
/* 380 */         fieldType = new FieldType(item.messageClass, typeId);
/*     */       }
/*     */ 
/* 383 */       if (visitor.shouldVisitField(fieldType, 1))
/* 384 */         visitor.visitForeign(fieldType, 0, item.message);
/*     */     }
/*     */   }
/*     */ 
/*     */   static void outputTo(GrowableProtocolSink sink, int typeId, GrowableProtocolSink typeValue)
/*     */   {
/* 434 */     sink.putByte(11);
/* 435 */     sink.putByte(16);
/* 436 */     sink.putVarInt(typeId);
/* 437 */     sink.putByte(26);
/* 438 */     sink.putVarInt(typeValue.position());
/* 439 */     sink.putBytes(typeValue.array(), 0, typeValue.position());
/* 440 */     sink.putByte(12);
/*     */   }
/*     */ 
/*     */   public static Class<? extends ProtocolMessage> getRegisteredClazz(int typeId)
/*     */   {
/* 448 */     TypedIdInfo typedIdInfo = (TypedIdInfo)typedIdHash.get(Integer.valueOf(typeId));
/* 449 */     return typedIdInfo != null ? typedIdInfo.clazz : null;
/*     */   }
/*     */ 
/*     */   public static Class<? extends ProtocolMessage> getRegisteredClazz(String typeName)
/*     */   {
/* 457 */     TypedIdInfo typedIdInfo = (TypedIdInfo)typedIdHash.get(typeName);
/* 458 */     return typedIdInfo != null ? typedIdInfo.clazz : null;
/*     */   }
/*     */ 
/*     */   private static RuntimeException newNoTypeIdException(Class<? extends ProtocolMessage> cls)
/*     */   {
/* 689 */     return new RuntimeException("MESSAGE_TYPE_ID not defined for class: " + cls.getName());
/*     */   }
/*     */ 
/*     */   public static int getTypeId(Class<? extends ProtocolMessage> clazz)
/*     */   {
/* 759 */     TypedIdInfo typedIdInfo = (TypedIdInfo)typedIdHash.get(clazz);
/* 760 */     if (typedIdInfo == null)
/*     */     {
/* 764 */       ProtocolSupport.newInstance(clazz);
/*     */ 
/* 766 */       typedIdInfo = (TypedIdInfo)typedIdHash.get(clazz);
/* 767 */       if (typedIdInfo == null)
/*     */       {
/* 769 */         LOG.warning(String.format("Class %s has no type id", new Object[] { clazz.getName() }));
/* 770 */         typedIdInfo = new TypedIdInfo(clazz, null, 0);
/* 771 */         typedIdHash.put(clazz, typedIdInfo);
/*     */       }
/*     */     }
/* 774 */     return typedIdInfo.typeId;
/*     */   }
/*     */ 
/*     */   static void setAllowMessageSetNameAndTypeDuplicates(boolean value)
/*     */   {
/* 779 */     allowDuplicates = value;
/*     */   }
/*     */ 
/*     */   public static void registerTypeId(Class<? extends ProtocolMessage> clazz, int typeId, String name)
/*     */   {
/* 788 */     TypedIdInfo typedIdInfo = new TypedIdInfo(clazz, name, typeId);
/*     */ 
/* 792 */     synchronized (typedIdHash) {
/* 793 */       typedIdHash.put(clazz, typedIdInfo);
/*     */ 
/* 795 */       if (allowDuplicates)
/*     */       {
/* 797 */         typedIdHash.put(name, typedIdInfo);
/* 798 */         typedIdHash.put(Integer.valueOf(typeId), typedIdInfo);
/*     */       } else {
/* 800 */         TypedIdInfo oldInfo = (TypedIdInfo)typedIdHash.putIfAbsent(name, typedIdInfo);
/* 801 */         if ((oldInfo != null) && (!oldInfo.equals(typedIdInfo))) {
/* 802 */           LOG.warning(String.format("Class %s has an ambiguous external name", new Object[] { clazz.getName() }));
/* 803 */           typedIdHash.put(name, TYPED_ID_ERROR);
/*     */         }
/* 805 */         oldInfo = (TypedIdInfo)typedIdHash.putIfAbsent(Integer.valueOf(typeId), typedIdInfo);
/* 806 */         if ((oldInfo != null) && (!oldInfo.equals(typedIdInfo))) {
/* 807 */           LOG.severe(String.format("Class %s has an ambiguous MESSAGE_TYPE_ID", new Object[] { clazz.getName() }));
/* 808 */           typedIdHash.put(Integer.valueOf(typeId), TYPED_ID_ERROR);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static Class<? extends ProtocolMessage> findClass(String name)
/*     */   {
/* 816 */     TypedIdInfo typedIdInfo = (TypedIdInfo)typedIdHash.get(name);
/* 817 */     if (typedIdInfo == null)
/* 818 */       return null;
/* 819 */     if (typedIdInfo.clazz == null) {
/* 820 */       throw new RuntimeException("Ambiguous name: " + name);
/*     */     }
/* 822 */     return typedIdInfo.clazz;
/*     */   }
/*     */ 
/*     */   public MessageSet freeze()
/*     */   {
/* 827 */     for (Item item : this.items.values())
/*     */     {
/* 829 */       item.message.freeze();
/*     */     }
/* 831 */     return this;
/*     */   }
/*     */ 
/*     */   public MessageSet unfreeze() {
/* 835 */     for (Item item : this.items.values())
/*     */     {
/* 837 */       item.message.unfreeze();
/*     */     }
/* 839 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean isFrozen() {
/* 843 */     for (Item item : this.items.values())
/*     */     {
/* 845 */       if (item.message.isFrozen()) {
/* 846 */         return true;
/*     */       }
/*     */     }
/* 849 */     return false;
/*     */   }
/*     */ 
/*     */   private static class TypedIdInfo
/*     */   {
/*     */     final Class<? extends ProtocolMessage> clazz;
/*     */     final String name;
/*     */     final int typeId;
/*     */ 
/*     */     public TypedIdInfo(Class<? extends ProtocolMessage> clazz, String name, int typeId)
/*     */     {
/* 710 */       this.clazz = clazz;
/* 711 */       this.name = name;
/* 712 */       this.typeId = typeId;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 716 */       if (this == obj) {
/* 717 */         return true;
/*     */       }
/* 719 */       if (!(obj instanceof TypedIdInfo)) {
/* 720 */         return false;
/*     */       }
/* 722 */       TypedIdInfo info = (TypedIdInfo)obj;
/* 723 */       if (this.typeId != info.typeId) {
/* 724 */         return false;
/*     */       }
/* 726 */       if (this.clazz != info.clazz) {
/* 727 */         return false;
/*     */       }
/* 729 */       return (this.name != null) && (this.name.equals(info.name));
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 733 */       throw new RuntimeException("Do not use TypedIdInfo as hash table keys.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Item
/*     */     implements Serializable
/*     */   {
/*     */     ProtocolMessage message;
/*     */     Class<? extends ProtocolMessage> messageClass;
/*     */     private static final int MAX_ENCODING_OVERHEAD_PER_LINE = 14;
/*     */ 
/*     */     public Item()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Item(Class<? extends ProtocolMessage> messageClass)
/*     */     {
/* 484 */       this.messageClass = messageClass;
/* 485 */       this.message = ProtocolSupport.newInstance(messageClass);
/*     */     }
/*     */ 
/*     */     public boolean parse(Class<? extends ProtocolMessage> newMessageClass)
/*     */     {
/* 494 */       if (this.messageClass != null) {
/* 495 */         return true;
/*     */       }
/*     */ 
/* 498 */       ProtocolMessage newMessage = ProtocolSupport.newInstance(newMessageClass);
/* 499 */       if (!newMessage.parseFrom(((RawMessage)this.message).contents())) {
/* 500 */         MessageSet.LOG.warning("Parse error in message inside MessageSet.  Tried to parse as: " + newMessageClass.getName());
/*     */ 
/* 502 */         return false;
/*     */       }
/*     */ 
/* 505 */       this.message = newMessage;
/* 506 */       this.messageClass = newMessageClass;
/* 507 */       return true;
/*     */     }
/*     */ 
/*     */     public void mergeFrom(Item other)
/*     */     {
/* 515 */       if (this.messageClass == null) {
/* 516 */         if (other.messageClass != null)
/*     */         {
/* 519 */           if (!parse(other.messageClass))
/*     */           {
/* 522 */             this.messageClass = other.messageClass;
/* 523 */             this.message = ProtocolSupport.newInstance(this.messageClass);
/*     */           }
/*     */         }
/*     */       }
/* 527 */       else if (other.messageClass == null)
/*     */       {
/* 530 */         if (!other.parse(this.messageClass)) {
/* 531 */           return;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 537 */       this.message.mergeFrom(other.message);
/*     */     }
/*     */ 
/*     */     public Item copy()
/*     */     {
/* 542 */       Item result = new Item();
/*     */ 
/* 544 */       if (this.messageClass == null) {
/* 545 */         result.message = new RawMessage();
/*     */       } else {
/* 547 */         result.messageClass = this.messageClass;
/* 548 */         result.message = ProtocolSupport.newInstance(this.messageClass);
/*     */       }
/*     */ 
/* 551 */       result.message.mergeFrom(this.message);
/* 552 */       return result;
/*     */     }
/*     */ 
/*     */     public boolean equals(Item other)
/*     */     {
/* 560 */       if (this.messageClass == null) {
/* 561 */         if (other.messageClass != null)
/*     */         {
/* 564 */           if (!parse(other.messageClass)) {
/* 565 */             return false;
/*     */           }
/*     */         }
/*     */       }
/* 569 */       else if (other.messageClass == null)
/*     */       {
/* 572 */         if (!other.parse(this.messageClass)) {
/* 573 */           return false;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 578 */       return this.message.equals(other.message);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 587 */       throw new RuntimeException("Do not use MessageSets as hash table keys.");
/*     */     }
/*     */ 
/*     */     public boolean equals(Object that) {
/* 591 */       return ((that instanceof Item)) && (equals((Item)that));
/*     */     }
/*     */ 
/*     */     public String findInitializationError()
/*     */     {
/* 596 */       return this.message.findInitializationError();
/*     */     }
/*     */ 
/*     */     public boolean isInitialized()
/*     */     {
/* 601 */       return this.message.isInitialized();
/*     */     }
/*     */ 
/*     */     public int encodingSize(int typeId)
/*     */     {
/* 611 */       return Protocol.stringSize(this.message.encodingSize()) + Protocol.varIntSize(typeId) + 4;
/*     */     }
/*     */ 
/*     */     public void output(ProtocolSink sink, int typeId)
/*     */     {
/* 632 */       sink.putByte(11);
/* 633 */       sink.putByte(16);
/* 634 */       sink.putVarInt(typeId);
/* 635 */       sink.putByte(26);
/* 636 */       sink.putVarInt(this.message.encodingSize());
/* 637 */       this.message.outputTo(sink);
/* 638 */       sink.putByte(12);
/*     */     }
/*     */ 
/*     */     public int decode(ProtocolSource source)
/*     */     {
/* 651 */       int typeId = 0;
/*     */       int tag;
/* 653 */       while ((tag = source.getVarInt()) != 12) {
/* 654 */         switch (tag)
/*     */         {
/*     */         case 0:
/* 659 */           return 0;
/*     */         case 16:
/* 661 */           typeId = source.getVarInt();
/* 662 */           break;
/*     */         case 26:
/* 665 */           int len = source.getVarInt();
/* 666 */           source.push(len);
/* 667 */           this.message = new RawMessage();
/* 668 */           if (!this.message.merge(source)) {
/* 669 */             return 0;
/*     */           }
/* 671 */           source.pop();
/* 672 */           break;
/*     */         default:
/* 675 */           source.skipData(tag);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 680 */       return typeId;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class FieldType extends ProtocolType.FieldType
/*     */   {
/*     */     public FieldType(Class<? extends ProtocolMessage> cls, int typeId)
/*     */     {
/* 398 */       super(cls.getName(), typeId, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, cls);
/*     */     }
/*     */ 
/*     */     public FieldType(int typeId)
/*     */     {
/* 404 */       super(String.valueOf(typeId), typeId, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, RawMessage.class);
/*     */     }
/*     */ 
/*     */     public int size(ProtocolMessage message)
/*     */     {
/* 411 */       return ((MessageSet)message).items.containsKey(Integer.valueOf(getTag())) ? 1 : 0;
/*     */     }
/*     */ 
/*     */     public void visit(ProtocolMessage message, ProtocolType.Visitor visitor)
/*     */     {
/* 419 */       MessageSet messageSet = (MessageSet)message;
/* 420 */       MessageSet.Item item = (MessageSet.Item)messageSet.items.get(Integer.valueOf(getTag()));
/*     */ 
/* 422 */       if (!visitor.shouldVisitField(this, item == null ? 0 : 1)) {
/* 423 */         return;
/*     */       }
/*     */ 
/* 426 */       if (item != null)
/* 427 */         visitor.visitForeign(this, 0, item.message);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.MessageSet
 * JD-Core Version:    0.6.0
 */