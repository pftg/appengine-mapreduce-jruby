/*      */ package com.google.appengine.api.images;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import com.google.net.rpc.DefaultStubCreationFilter;
/*      */ import com.google.net.rpc.RPC;
/*      */ import com.google.net.rpc.RpcCallback;
/*      */ import com.google.net.rpc.RpcCancelCallback;
/*      */ import com.google.net.rpc.RpcException;
/*      */ import com.google.net.rpc.RpcInterface;
/*      */ import com.google.net.rpc.RpcServerParameters;
/*      */ import com.google.net.rpc.RpcService;
/*      */ import com.google.net.rpc.RpcStub;
/*      */ import com.google.net.rpc.RpcStubFactory;
/*      */ import com.google.net.rpc.RpcStubParameters;
/*      */ import com.google.net.rpc.StubCreationFilter;
/*      */ import com.google.net.rpc.impl.ApplicationHandler;
/*      */ import com.google.net.rpc.impl.BlockingApplicationHandler;
/*      */ import com.google.net.rpc.impl.RpcHandlerRegistry;
/*      */ import com.google.net.rpc.impl.RpcServerConfig;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1CompatibilityStub;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1HandlerRegistry;
/*      */ import com.google.net.rpc3.server.RpcServer.Builder;
/*      */ import com.google.net.ssl.SslSecurityLevel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ public class ImagesServicePb
/*      */ {
/*      */   public static final class ImagesService
/*      */   {
/* 6214 */     private static volatile StubCreationFilter stubCreationFilter_ = new DefaultStubCreationFilter();
/*      */ 
/* 6220 */     private static final RpcStubFactory stubFactory_ = new RpcStubFactory() {
/*      */       public RpcStub newRpcStub(RpcStubParameters params) {
/* 6222 */         return new ImagesServicePb.ImagesService.SimpleStub(ImagesServicePb.ImagesService.stubCreationFilter_.filterStubParameters("ImagesService", params));
/*      */       }
/* 6220 */     };
/*      */ 
/*      */     public static void setStubCreationFilter(StubCreationFilter filter)
/*      */     {
/* 6217 */       stubCreationFilter_ = filter == null ? new DefaultStubCreationFilter() : filter;
/*      */     }
/*      */ 
/*      */     public static RpcStubFactory stubFactory()
/*      */     {
/* 6226 */       return stubFactory_;
/*      */     }
/*      */ 
/*      */     public static BlockingStub newBlockingStub(RpcStubParameters params)
/*      */     {
/* 6289 */       return new BlockingStub(stubCreationFilter_.filterStubParameters("ImagesService", params));
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcStubParameters params)
/*      */     {
/* 6322 */       return new Stub(stubCreationFilter_.filterStubParameters("ImagesService", params));
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcHandlerRegistry registry)
/*      */     {
/* 6399 */       ServerConfig config = new ServerConfig();
/* 6400 */       exportServiceUsingConfig(service, registry, config);
/* 6401 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 6407 */       registry.registerHandler(config.serviceName(), "Transform", new ImagesServicePb.ImagesTransformRequest(), new ImagesServicePb.ImagesTransformResponse(), null, config.Transform_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 6411 */           this.val$service.transform(rpc, (ImagesServicePb.ImagesTransformRequest)rpc.internalRequest(), (ImagesServicePb.ImagesTransformResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 6415 */       registry.registerHandler(config.serviceName(), "Composite", new ImagesServicePb.ImagesCompositeRequest(), new ImagesServicePb.ImagesCompositeResponse(), null, config.Composite_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 6419 */           this.val$service.composite(rpc, (ImagesServicePb.ImagesCompositeRequest)rpc.internalRequest(), (ImagesServicePb.ImagesCompositeResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 6423 */       registry.registerHandler(config.serviceName(), "Histogram", new ImagesServicePb.ImagesHistogramRequest(), new ImagesServicePb.ImagesHistogramResponse(), null, config.Histogram_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 6427 */           this.val$service.histogram(rpc, (ImagesServicePb.ImagesHistogramRequest)rpc.internalRequest(), (ImagesServicePb.ImagesHistogramResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 6431 */       registry.registerHandler(config.serviceName(), "GetUrlBase", new ImagesServicePb.ImagesGetUrlBaseRequest(), new ImagesServicePb.ImagesGetUrlBaseResponse(), null, config.GetUrlBase_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 6435 */           this.val$service.getUrlBase(rpc, (ImagesServicePb.ImagesGetUrlBaseRequest)rpc.internalRequest(), (ImagesServicePb.ImagesGetUrlBaseResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     public static RpcService newService(Interface impl) {
/* 6442 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 6444 */           return ImagesServicePb.ImagesService.exportService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcServer.Builder builder) {
/* 6451 */       ServerConfig config = new ServerConfig();
/* 6452 */       exportServiceUsingConfig(service, builder, config);
/* 6453 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 6459 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 6460 */       exportServiceUsingConfig(service, registry, config);
/* 6461 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcHandlerRegistry registry)
/*      */     {
/* 6466 */       ServerConfig config = new ServerConfig();
/* 6467 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 6468 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 6474 */       registry.registerHandler(config.serviceName(), "Transform", new ImagesServicePb.ImagesTransformRequest(), new ImagesServicePb.ImagesTransformResponse(), null, config.Transform_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ImagesServicePb.ImagesTransformResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 6478 */           return this.val$service.transform(rpc, (ImagesServicePb.ImagesTransformRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 6481 */       registry.registerHandler(config.serviceName(), "Composite", new ImagesServicePb.ImagesCompositeRequest(), new ImagesServicePb.ImagesCompositeResponse(), null, config.Composite_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ImagesServicePb.ImagesCompositeResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 6485 */           return this.val$service.composite(rpc, (ImagesServicePb.ImagesCompositeRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 6488 */       registry.registerHandler(config.serviceName(), "Histogram", new ImagesServicePb.ImagesHistogramRequest(), new ImagesServicePb.ImagesHistogramResponse(), null, config.Histogram_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ImagesServicePb.ImagesHistogramResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 6492 */           return this.val$service.histogram(rpc, (ImagesServicePb.ImagesHistogramRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 6495 */       registry.registerHandler(config.serviceName(), "GetUrlBase", new ImagesServicePb.ImagesGetUrlBaseRequest(), new ImagesServicePb.ImagesGetUrlBaseResponse(), null, config.GetUrlBase_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 6499 */           return this.val$service.getUrlBase(rpc, (ImagesServicePb.ImagesGetUrlBaseRequest)rpc.internalRequest());
/*      */         } } );
/*      */     }
/*      */ 
/*      */     public static RpcService newBlockingService(BlockingInterface impl) {
/* 6505 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 6507 */           return ImagesServicePb.ImagesService.exportBlockingService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcServer.Builder builder) {
/* 6514 */       ServerConfig config = new ServerConfig();
/* 6515 */       exportBlockingServiceUsingConfig(service, builder, config);
/* 6516 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 6522 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 6523 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 6524 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static void unexport(RpcHandlerRegistry registry) {
/* 6528 */       registry.unregisterService("ImagesService");
/*      */     }
/*      */ 
/*      */     public static class ServerConfig extends RpcServerConfig
/*      */     {
/* 6326 */       final RpcServerParameters Transform_parameters_ = new RpcServerParameters();
/* 6327 */       final RpcServerParameters Composite_parameters_ = new RpcServerParameters();
/* 6328 */       final RpcServerParameters Histogram_parameters_ = new RpcServerParameters();
/* 6329 */       final RpcServerParameters GetUrlBase_parameters_ = new RpcServerParameters();
/*      */ 
/*      */       public ServerConfig() {
/* 6332 */         this("ImagesService");
/*      */       }
/*      */       public ServerConfig(String serviceName) {
/* 6335 */         super();
/*      */       }
/*      */       public void setRpcRunner(Executor t) {
/* 6338 */         setRpcRunner_Transform(t);
/* 6339 */         setRpcRunner_Composite(t);
/* 6340 */         setRpcRunner_Histogram(t);
/* 6341 */         setRpcRunner_GetUrlBase(t);
/*      */       }
/*      */ 
/*      */       public void setRpcRunner_Transform(Executor t) {
/* 6345 */         this.Transform_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_Composite(Executor t) {
/* 6348 */         this.Composite_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_Histogram(Executor t) {
/* 6351 */         this.Histogram_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_GetUrlBase(Executor t) {
/* 6354 */         this.GetUrlBase_parameters_.setRpcRunner(t);
/*      */       }
/*      */ 
/*      */       public void setServerLogging_Transform(int t) {
/* 6358 */         this.Transform_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_Composite(int t) {
/* 6361 */         this.Composite_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_Histogram(int t) {
/* 6364 */         this.Histogram_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_GetUrlBase(int t) {
/* 6367 */         this.GetUrlBase_parameters_.setServerLogging(t);
/*      */       }
/*      */ 
/*      */       public void setSecurityLevel_Transform(SslSecurityLevel t) {
/* 6371 */         this.Transform_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_Composite(SslSecurityLevel t) {
/* 6374 */         this.Composite_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_Histogram(SslSecurityLevel t) {
/* 6377 */         this.Histogram_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_GetUrlBase(SslSecurityLevel t) {
/* 6380 */         this.GetUrlBase_parameters_.setSecurityLevel(t);
/*      */       }
/*      */ 
/*      */       public void setRpcCancelCallback_Transform(RpcCancelCallback t) {
/* 6384 */         this.Transform_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_Composite(RpcCancelCallback t) {
/* 6387 */         this.Composite_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_Histogram(RpcCancelCallback t) {
/* 6390 */         this.Histogram_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_GetUrlBase(RpcCancelCallback t) {
/* 6393 */         this.GetUrlBase_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class Stub extends ImagesServicePb.ImagesService.BlockingStub
/*      */       implements ImagesServicePb.ImagesService.Interface
/*      */     {
/*      */       Stub(RpcStubParameters params)
/*      */       {
/* 6301 */         super();
/*      */       }
/*      */       public void transform(RPC rpc, ImagesServicePb.ImagesTransformRequest req, ImagesServicePb.ImagesTransformResponse reply, RpcCallback cb) {
/* 6304 */         startNonBlockingRpc(rpc, this.Transform_method_, "Transform", req, reply, cb, this.Transform_parameters_);
/*      */       }
/*      */ 
/*      */       public void composite(RPC rpc, ImagesServicePb.ImagesCompositeRequest req, ImagesServicePb.ImagesCompositeResponse reply, RpcCallback cb) {
/* 6308 */         startNonBlockingRpc(rpc, this.Composite_method_, "Composite", req, reply, cb, this.Composite_parameters_);
/*      */       }
/*      */ 
/*      */       public void histogram(RPC rpc, ImagesServicePb.ImagesHistogramRequest req, ImagesServicePb.ImagesHistogramResponse reply, RpcCallback cb) {
/* 6312 */         startNonBlockingRpc(rpc, this.Histogram_method_, "Histogram", req, reply, cb, this.Histogram_parameters_);
/*      */       }
/*      */ 
/*      */       public void getUrlBase(RPC rpc, ImagesServicePb.ImagesGetUrlBaseRequest req, ImagesServicePb.ImagesGetUrlBaseResponse reply, RpcCallback cb) {
/* 6316 */         startNonBlockingRpc(rpc, this.GetUrlBase_method_, "GetUrlBase", req, reply, cb, this.GetUrlBase_parameters_);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface extends RpcInterface
/*      */     {
/*      */       public abstract void transform(RPC paramRPC, ImagesServicePb.ImagesTransformRequest paramImagesTransformRequest, ImagesServicePb.ImagesTransformResponse paramImagesTransformResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void composite(RPC paramRPC, ImagesServicePb.ImagesCompositeRequest paramImagesCompositeRequest, ImagesServicePb.ImagesCompositeResponse paramImagesCompositeResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void histogram(RPC paramRPC, ImagesServicePb.ImagesHistogramRequest paramImagesHistogramRequest, ImagesServicePb.ImagesHistogramResponse paramImagesHistogramResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void getUrlBase(RPC paramRPC, ImagesServicePb.ImagesGetUrlBaseRequest paramImagesGetUrlBaseRequest, ImagesServicePb.ImagesGetUrlBaseResponse paramImagesGetUrlBaseResponse, RpcCallback paramRpcCallback);
/*      */     }
/*      */ 
/*      */     public static class BlockingStub extends ImagesServicePb.ImagesService.BaseStub
/*      */       implements ImagesServicePb.ImagesService.BlockingInterface
/*      */     {
/*      */       BlockingStub(RpcStubParameters params)
/*      */       {
/* 6260 */         super();
/*      */       }
/*      */       public ImagesServicePb.ImagesTransformResponse transform(RPC rpc, ImagesServicePb.ImagesTransformRequest req) throws RpcException {
/* 6263 */         ImagesServicePb.ImagesTransformResponse reply = new ImagesServicePb.ImagesTransformResponse();
/* 6264 */         startBlockingRpc(rpc, this.Transform_method_, "Transform", req, reply, this.Transform_parameters_);
/*      */ 
/* 6266 */         return reply;
/*      */       }
/*      */       public ImagesServicePb.ImagesCompositeResponse composite(RPC rpc, ImagesServicePb.ImagesCompositeRequest req) throws RpcException {
/* 6269 */         ImagesServicePb.ImagesCompositeResponse reply = new ImagesServicePb.ImagesCompositeResponse();
/* 6270 */         startBlockingRpc(rpc, this.Composite_method_, "Composite", req, reply, this.Composite_parameters_);
/*      */ 
/* 6272 */         return reply;
/*      */       }
/*      */       public ImagesServicePb.ImagesHistogramResponse histogram(RPC rpc, ImagesServicePb.ImagesHistogramRequest req) throws RpcException {
/* 6275 */         ImagesServicePb.ImagesHistogramResponse reply = new ImagesServicePb.ImagesHistogramResponse();
/* 6276 */         startBlockingRpc(rpc, this.Histogram_method_, "Histogram", req, reply, this.Histogram_parameters_);
/*      */ 
/* 6278 */         return reply;
/*      */       }
/*      */       public ImagesServicePb.ImagesGetUrlBaseResponse getUrlBase(RPC rpc, ImagesServicePb.ImagesGetUrlBaseRequest req) throws RpcException {
/* 6281 */         ImagesServicePb.ImagesGetUrlBaseResponse reply = new ImagesServicePb.ImagesGetUrlBaseResponse();
/* 6282 */         startBlockingRpc(rpc, this.GetUrlBase_method_, "GetUrlBase", req, reply, this.GetUrlBase_parameters_);
/*      */ 
/* 6284 */         return reply;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface extends RpcInterface
/*      */     {
/*      */       public abstract ImagesServicePb.ImagesTransformResponse transform(RPC paramRPC, ImagesServicePb.ImagesTransformRequest paramImagesTransformRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ImagesServicePb.ImagesCompositeResponse composite(RPC paramRPC, ImagesServicePb.ImagesCompositeRequest paramImagesCompositeRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ImagesServicePb.ImagesHistogramResponse histogram(RPC paramRPC, ImagesServicePb.ImagesHistogramRequest paramImagesHistogramRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ImagesServicePb.ImagesGetUrlBaseResponse getUrlBase(RPC paramRPC, ImagesServicePb.ImagesGetUrlBaseRequest paramImagesGetUrlBaseRequest)
/*      */         throws RpcException;
/*      */     }
/*      */ 
/*      */     private static class BaseStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       protected final String Transform_method_;
/* 6242 */       protected final RPC Transform_parameters_ = newRpcPrototype(ImagesServicePb.ImagesService.Method.Transform);
/*      */       protected final String Composite_method_;
/* 6244 */       protected final RPC Composite_parameters_ = newRpcPrototype(ImagesServicePb.ImagesService.Method.Composite);
/*      */       protected final String Histogram_method_;
/* 6246 */       protected final RPC Histogram_parameters_ = newRpcPrototype(ImagesServicePb.ImagesService.Method.Histogram);
/*      */       protected final String GetUrlBase_method_;
/* 6248 */       protected final RPC GetUrlBase_parameters_ = newRpcPrototype(ImagesServicePb.ImagesService.Method.GetUrlBase);
/*      */ 
/*      */       protected BaseStub(RpcStubParameters params)
/*      */       {
/* 6234 */         super(params, ImagesServicePb.ImagesService.Method.class);
/* 6235 */         this.Transform_method_ = makeFullMethodName("Transform");
/* 6236 */         this.Composite_method_ = makeFullMethodName("Composite");
/* 6237 */         this.Histogram_method_ = makeFullMethodName("Histogram");
/* 6238 */         this.GetUrlBase_method_ = makeFullMethodName("GetUrlBase");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class SimpleStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       public SimpleStub(RpcStubParameters params)
/*      */       {
/* 6229 */         super(params, ImagesServicePb.ImagesService.Method.class);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Method
/*      */     {
/* 6208 */       Transform, 
/* 6209 */       Composite, 
/* 6210 */       Histogram, 
/* 6211 */       GetUrlBase;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesGetUrlBaseResponse extends ProtocolMessage<ImagesGetUrlBaseResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 5929 */     private byte[] url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesGetUrlBaseResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kurl = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getUrlAsBytes()
/*      */     {
/* 5935 */       return this.url_;
/*      */     }
/*      */     public final boolean hasUrl() {
/* 5938 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesGetUrlBaseResponse clearUrl() {
/* 5941 */       this.optional_0_ &= -2;
/* 5942 */       this.url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5943 */       return this;
/*      */     }
/*      */     public ImagesGetUrlBaseResponse setUrlAsBytes(byte[] x) {
/* 5946 */       this.optional_0_ |= 1;
/* 5947 */       this.url_ = x;
/* 5948 */       return this;
/*      */     }
/*      */     public final String getUrl() {
/* 5951 */       return ProtocolSupport.toStringUtf8(this.url_);
/*      */     }
/*      */     public ImagesGetUrlBaseResponse setUrl(String v) {
/* 5954 */       if (v == null) throw new NullPointerException();
/* 5955 */       this.optional_0_ |= 1;
/* 5956 */       this.url_ = ProtocolSupport.toBytesUtf8(v);
/* 5957 */       return this;
/*      */     }
/*      */     public final String getUrl(Charset cs) {
/* 5960 */       return ProtocolSupport.toString(this.url_, cs);
/*      */     }
/*      */     public ImagesGetUrlBaseResponse setUrl(String v, Charset cs) {
/* 5963 */       if (v == null) throw new NullPointerException();
/* 5964 */       this.optional_0_ |= 1;
/* 5965 */       this.url_ = ProtocolSupport.toBytes(v, cs);
/* 5966 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseResponse mergeFrom(ImagesGetUrlBaseResponse that)
/*      */     {
/* 5973 */       assert (that != this);
/* 5974 */       int this_t0 = this.optional_0_;
/* 5975 */       int that_t0 = that.optional_0_;
/*      */ 
/* 5977 */       if ((that_t0 & 0x1) != 0) {
/* 5978 */         this_t0 |= 1;
/* 5979 */         this.url_ = that.url_;
/*      */       }
/*      */ 
/* 5982 */       if (that.uninterpreted != null) {
/* 5983 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 5985 */       this.optional_0_ = this_t0;
/* 5986 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesGetUrlBaseResponse that) {
/* 5990 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesGetUrlBaseResponse that) {
/* 5994 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesGetUrlBaseResponse that, boolean ignoreUninterpreted) {
/* 5998 */       if (that == null) return false;
/* 5999 */       if (that == this) return true;
/* 6000 */       int this_t0 = this.optional_0_;
/* 6001 */       int that_t0 = that.optional_0_;
/* 6002 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 6004 */       if (((this_t0 & 0x1) != 0) && 
/* 6005 */         (!Arrays.equals(this.url_, that.url_))) return false;
/*      */ 
/* 6008 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 6013 */       return ((that instanceof ImagesGetUrlBaseResponse)) && (equals((ImagesGetUrlBaseResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 6017 */       int hash = 697634943;
/*      */ 
/* 6019 */       int this_t0 = this.optional_0_;
/* 6020 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.url_) : -113);
/* 6021 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 6022 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 6024 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 6028 */       int this_t0 = this.optional_0_;
/*      */ 
/* 6030 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 6037 */       int n = 1 + Protocol.stringSize(this.url_.length);
/*      */ 
/* 6039 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 6045 */       int n = 6 + this.url_.length;
/*      */ 
/* 6047 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 6052 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 6056 */       this.optional_0_ = 0;
/* 6057 */       this.url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 6058 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseResponse newInstance() {
/* 6062 */       return new ImagesGetUrlBaseResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 6066 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 6085 */       sink.putByte(10);
/* 6086 */       sink.putPrefixedData(this.url_);
/*      */ 
/* 6088 */       if (this.uninterpreted != null)
/* 6089 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 6094 */       boolean result = true;
/* 6095 */       int this_t0 = this.optional_0_;
/*      */ 
/* 6097 */       while (source.hasRemaining()) {
/* 6098 */         int tt = source.getVarInt();
/* 6099 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 6103 */           result = false;
/* 6104 */           break;
/*      */         case 10:
/* 6107 */           this.url_ = source.getPrefixedData();
/* 6108 */           this_t0 |= 1;
/* 6109 */           break;
/*      */         default:
/* 6111 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 6116 */       this.optional_0_ = this_t0;
/* 6117 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseResponse getDefaultInstanceForType()
/*      */     {
/* 6122 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesGetUrlBaseResponse getDefaultInstance() {
/* 6126 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseResponse freeze()
/*      */     {
/* 6174 */       this.url_ = ProtocolSupport.freezeString(this.url_);
/* 6175 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 6178 */       if (this.uninterpreted == null) {
/* 6179 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 6181 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6130 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesGetUrlBaseResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse clearUrl()
/*      */         {
/* 6138 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse setUrlAsBytes(byte[] x) {
/* 6141 */           ProtocolSupport.unsupportedOperation();
/* 6142 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse setUrl(String v) {
/* 6145 */           ProtocolSupport.unsupportedOperation();
/* 6146 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse setUrl(String v, Charset cs) {
/* 6149 */           ProtocolSupport.unsupportedOperation();
/* 6150 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse mergeFrom(ImagesServicePb.ImagesGetUrlBaseResponse that) {
/* 6154 */           ProtocolSupport.unsupportedOperation();
/* 6155 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 6158 */           ProtocolSupport.unsupportedOperation();
/* 6159 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse freeze() {
/* 6162 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseResponse unfreeze() {
/* 6165 */           ProtocolSupport.unsupportedOperation();
/* 6166 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 6169 */           return true;
/*      */         }
/*      */       };
/* 6186 */       text = new String[2];
/*      */ 
/* 6188 */       text[0] = "ErrorCode";
/* 6189 */       text[1] = "url";
/*      */ 
/* 6192 */       types = new int[2];
/*      */ 
/* 6194 */       Arrays.fill(types, 6);
/* 6195 */       types[0] = 0;
/* 6196 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 6070 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesGetUrlBaseResponse.class, "Z*apphosting/api/images/images_service.proto\n#apphosting.ImagesGetUrlBaseResponse\023\032\003url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("url", "url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesGetUrlBaseRequest extends ProtocolMessage<ImagesGetUrlBaseRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 5650 */     private byte[] blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesGetUrlBaseRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kblob_key = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getBlobKeyAsBytes()
/*      */     {
/* 5656 */       return this.blob_key_;
/*      */     }
/*      */     public final boolean hasBlobKey() {
/* 5659 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesGetUrlBaseRequest clearBlobKey() {
/* 5662 */       this.optional_0_ &= -2;
/* 5663 */       this.blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5664 */       return this;
/*      */     }
/*      */     public ImagesGetUrlBaseRequest setBlobKeyAsBytes(byte[] x) {
/* 5667 */       this.optional_0_ |= 1;
/* 5668 */       this.blob_key_ = x;
/* 5669 */       return this;
/*      */     }
/*      */     public final String getBlobKey() {
/* 5672 */       return ProtocolSupport.toStringUtf8(this.blob_key_);
/*      */     }
/*      */     public ImagesGetUrlBaseRequest setBlobKey(String v) {
/* 5675 */       if (v == null) throw new NullPointerException();
/* 5676 */       this.optional_0_ |= 1;
/* 5677 */       this.blob_key_ = ProtocolSupport.toBytesUtf8(v);
/* 5678 */       return this;
/*      */     }
/*      */     public final String getBlobKey(Charset cs) {
/* 5681 */       return ProtocolSupport.toString(this.blob_key_, cs);
/*      */     }
/*      */     public ImagesGetUrlBaseRequest setBlobKey(String v, Charset cs) {
/* 5684 */       if (v == null) throw new NullPointerException();
/* 5685 */       this.optional_0_ |= 1;
/* 5686 */       this.blob_key_ = ProtocolSupport.toBytes(v, cs);
/* 5687 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseRequest mergeFrom(ImagesGetUrlBaseRequest that)
/*      */     {
/* 5694 */       assert (that != this);
/* 5695 */       int this_t0 = this.optional_0_;
/* 5696 */       int that_t0 = that.optional_0_;
/*      */ 
/* 5698 */       if ((that_t0 & 0x1) != 0) {
/* 5699 */         this_t0 |= 1;
/* 5700 */         this.blob_key_ = that.blob_key_;
/*      */       }
/*      */ 
/* 5703 */       if (that.uninterpreted != null) {
/* 5704 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 5706 */       this.optional_0_ = this_t0;
/* 5707 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesGetUrlBaseRequest that) {
/* 5711 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesGetUrlBaseRequest that) {
/* 5715 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesGetUrlBaseRequest that, boolean ignoreUninterpreted) {
/* 5719 */       if (that == null) return false;
/* 5720 */       if (that == this) return true;
/* 5721 */       int this_t0 = this.optional_0_;
/* 5722 */       int that_t0 = that.optional_0_;
/* 5723 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 5725 */       if (((this_t0 & 0x1) != 0) && 
/* 5726 */         (!Arrays.equals(this.blob_key_, that.blob_key_))) return false;
/*      */ 
/* 5729 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 5734 */       return ((that instanceof ImagesGetUrlBaseRequest)) && (equals((ImagesGetUrlBaseRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 5738 */       int hash = -741365546;
/*      */ 
/* 5740 */       int this_t0 = this.optional_0_;
/* 5741 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.blob_key_) : -113);
/* 5742 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 5743 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 5745 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 5749 */       int this_t0 = this.optional_0_;
/*      */ 
/* 5751 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 5758 */       int n = 1 + Protocol.stringSize(this.blob_key_.length);
/*      */ 
/* 5760 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 5766 */       int n = 6 + this.blob_key_.length;
/*      */ 
/* 5768 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 5773 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 5777 */       this.optional_0_ = 0;
/* 5778 */       this.blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5779 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseRequest newInstance() {
/* 5783 */       return new ImagesGetUrlBaseRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 5787 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 5806 */       sink.putByte(10);
/* 5807 */       sink.putPrefixedData(this.blob_key_);
/*      */ 
/* 5809 */       if (this.uninterpreted != null)
/* 5810 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 5815 */       boolean result = true;
/* 5816 */       int this_t0 = this.optional_0_;
/*      */ 
/* 5818 */       while (source.hasRemaining()) {
/* 5819 */         int tt = source.getVarInt();
/* 5820 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 5824 */           result = false;
/* 5825 */           break;
/*      */         case 10:
/* 5828 */           this.blob_key_ = source.getPrefixedData();
/* 5829 */           this_t0 |= 1;
/* 5830 */           break;
/*      */         default:
/* 5832 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5837 */       this.optional_0_ = this_t0;
/* 5838 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseRequest getDefaultInstanceForType()
/*      */     {
/* 5843 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesGetUrlBaseRequest getDefaultInstance() {
/* 5847 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesGetUrlBaseRequest freeze()
/*      */     {
/* 5895 */       this.blob_key_ = ProtocolSupport.freezeString(this.blob_key_);
/* 5896 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 5899 */       if (this.uninterpreted == null) {
/* 5900 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 5902 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 5851 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesGetUrlBaseRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest clearBlobKey()
/*      */         {
/* 5859 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest setBlobKeyAsBytes(byte[] x) {
/* 5862 */           ProtocolSupport.unsupportedOperation();
/* 5863 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest setBlobKey(String v) {
/* 5866 */           ProtocolSupport.unsupportedOperation();
/* 5867 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest setBlobKey(String v, Charset cs) {
/* 5870 */           ProtocolSupport.unsupportedOperation();
/* 5871 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest mergeFrom(ImagesServicePb.ImagesGetUrlBaseRequest that) {
/* 5875 */           ProtocolSupport.unsupportedOperation();
/* 5876 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 5879 */           ProtocolSupport.unsupportedOperation();
/* 5880 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest freeze() {
/* 5883 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesGetUrlBaseRequest unfreeze() {
/* 5886 */           ProtocolSupport.unsupportedOperation();
/* 5887 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 5890 */           return true;
/*      */         }
/*      */       };
/* 5907 */       text = new String[2];
/*      */ 
/* 5909 */       text[0] = "ErrorCode";
/* 5910 */       text[1] = "blob_key";
/*      */ 
/* 5913 */       types = new int[2];
/*      */ 
/* 5915 */       Arrays.fill(types, 6);
/* 5916 */       types[0] = 0;
/* 5917 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 5791 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesGetUrlBaseRequest.class, "Z*apphosting/api/images/images_service.proto\n\"apphosting.ImagesGetUrlBaseRequest\023\032\bblob_key \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("blob_key", "blob_key", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesHistogramResponse extends ProtocolMessage<ImagesHistogramResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 5371 */     private ImagesServicePb.ImagesHistogram histogram_ = new ImagesServicePb.ImagesHistogram();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesHistogramResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int khistogram = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final ImagesServicePb.ImagesHistogram getHistogram()
/*      */     {
/* 5377 */       return this.histogram_;
/*      */     }
/*      */     public final boolean hasHistogram() {
/* 5380 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesHistogramResponse clearHistogram() {
/* 5383 */       this.optional_0_ &= -2;
/* 5384 */       this.histogram_.clear();
/* 5385 */       return this;
/*      */     }
/*      */     public ImagesHistogramResponse setHistogram(ImagesServicePb.ImagesHistogram x) {
/* 5388 */       if (x == null) throw new NullPointerException();
/* 5389 */       this.optional_0_ |= 1;
/* 5390 */       this.histogram_ = x;
/* 5391 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImagesHistogram getMutableHistogram() {
/* 5394 */       this.optional_0_ |= 1;
/* 5395 */       return this.histogram_;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramResponse mergeFrom(ImagesHistogramResponse that)
/*      */     {
/* 5402 */       assert (that != this);
/* 5403 */       int this_t0 = this.optional_0_;
/* 5404 */       int that_t0 = that.optional_0_;
/*      */ 
/* 5406 */       if ((that_t0 & 0x1) != 0) {
/* 5407 */         this_t0 |= 1;
/* 5408 */         ImagesServicePb.ImagesHistogram v = this.histogram_;
/* 5409 */         v.mergeFrom(that.histogram_);
/*      */       }
/*      */ 
/* 5412 */       if (that.uninterpreted != null) {
/* 5413 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 5415 */       this.optional_0_ = this_t0;
/* 5416 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesHistogramResponse that) {
/* 5420 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesHistogramResponse that) {
/* 5424 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesHistogramResponse that, boolean ignoreUninterpreted) {
/* 5428 */       if (that == null) return false;
/* 5429 */       if (that == this) return true;
/* 5430 */       int this_t0 = this.optional_0_;
/* 5431 */       int that_t0 = that.optional_0_;
/* 5432 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 5434 */       if (((this_t0 & 0x1) != 0) && 
/* 5435 */         (!this.histogram_.equals(that.histogram_, ignoreUninterpreted))) return false;
/*      */ 
/* 5438 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 5443 */       return ((that instanceof ImagesHistogramResponse)) && (equals((ImagesHistogramResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 5447 */       int hash = 805242702;
/*      */ 
/* 5449 */       int this_t0 = this.optional_0_;
/* 5450 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.histogram_.hashCode() : -113);
/* 5451 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 5452 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 5454 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 5458 */       int this_t0 = this.optional_0_;
/* 5459 */       if ((this_t0 & 0x1) != 1) {
/* 5460 */         return false;
/*      */       }
/*      */ 
/* 5464 */       return this.histogram_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 5471 */       int n = 1 + Protocol.stringSize(this.histogram_.encodingSize());
/*      */ 
/* 5473 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 5479 */       int n = 6 + this.histogram_.maxEncodingSize();
/*      */ 
/* 5481 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 5486 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 5490 */       this.optional_0_ = 0;
/* 5491 */       this.histogram_.clear();
/* 5492 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramResponse newInstance() {
/* 5496 */       return new ImagesHistogramResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 5500 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 5521 */       sink.putByte(10);
/* 5522 */       sink.putForeign(this.histogram_);
/*      */ 
/* 5524 */       if (this.uninterpreted != null)
/* 5525 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 5530 */       boolean result = true;
/* 5531 */       int this_t0 = this.optional_0_;
/*      */ 
/* 5533 */       while (source.hasRemaining()) {
/* 5534 */         int tt = source.getVarInt();
/* 5535 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 5539 */           result = false;
/* 5540 */           break;
/*      */         case 10:
/* 5543 */           source.push(source.getVarInt());
/* 5544 */           if (!this.histogram_.merge(source)) { result = false; break label111; }
/* 5545 */           source.pop();
/* 5546 */           this_t0 |= 1;
/* 5547 */           break;
/*      */         default:
/* 5549 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5554 */       label111: this.optional_0_ = this_t0;
/* 5555 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramResponse getDefaultInstanceForType()
/*      */     {
/* 5560 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesHistogramResponse getDefaultInstance() {
/* 5564 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramResponse freeze()
/*      */     {
/* 5607 */       this.histogram_.freeze();
/* 5608 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramResponse unfreeze() {
/* 5612 */       this.histogram_.unfreeze();
/* 5613 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 5617 */       return this.histogram_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 5620 */       if (this.uninterpreted == null) {
/* 5621 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 5623 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 5568 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesHistogramResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogramResponse clearHistogram()
/*      */         {
/* 5576 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogramResponse setHistogram(ImagesServicePb.ImagesHistogram x) {
/* 5579 */           ProtocolSupport.unsupportedOperation();
/* 5580 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram getMutableHistogram() {
/* 5583 */           return (ImagesServicePb.ImagesHistogram)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogramResponse mergeFrom(ImagesServicePb.ImagesHistogramResponse that) {
/* 5587 */           ProtocolSupport.unsupportedOperation();
/* 5588 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 5591 */           ProtocolSupport.unsupportedOperation();
/* 5592 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogramResponse freeze() {
/* 5595 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogramResponse unfreeze() {
/* 5598 */           ProtocolSupport.unsupportedOperation();
/* 5599 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 5602 */           return true;
/*      */         }
/*      */       };
/* 5628 */       text = new String[2];
/*      */ 
/* 5630 */       text[0] = "ErrorCode";
/* 5631 */       text[1] = "histogram";
/*      */ 
/* 5634 */       types = new int[2];
/*      */ 
/* 5636 */       Arrays.fill(types, 6);
/* 5637 */       types[0] = 0;
/* 5638 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 5504 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesHistogramResponse.class, "Z*apphosting/api/images/images_service.proto\n\"apphosting.ImagesHistogramResponse\023\032\thistogram \001(\0020\0138\002J\032apphosting.ImagesHistogram\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("histogram", "histogram", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.ImagesHistogram.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesHistogram extends ProtocolMessage<ImagesHistogram>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 4826 */     private int[] red_ = ProtocolSupport.EMPTY_INT_ARRAY;
/*      */     private int red_elts_;
/* 4828 */     private int[] green_ = ProtocolSupport.EMPTY_INT_ARRAY;
/*      */     private int green_elts_;
/* 4830 */     private int[] blue_ = ProtocolSupport.EMPTY_INT_ARRAY;
/*      */     private int blue_elts_;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final ImagesHistogram IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kred = 1;
/*      */     public static final int kgreen = 2;
/*      */     public static final int kblue = 3;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int redSize()
/*      */     {
/* 4836 */       return this.red_elts_;
/*      */     }
/*      */     public final int getRed(int i) {
/* 4839 */       assert ((i >= 0) && (i < this.red_elts_));
/* 4840 */       return this.red_[i];
/*      */     }
/*      */     public ImagesHistogram clearRed() {
/* 4843 */       this.red_elts_ = 0;
/* 4844 */       this.red_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 4845 */       return this;
/*      */     }
/*      */     public ImagesHistogram setRed(int i, int v) {
/* 4848 */       assert ((i >= 0) && (i < this.red_elts_));
/* 4849 */       this.red_[i] = v;
/* 4850 */       return this;
/*      */     }
/*      */     public ImagesHistogram addRed(int v) {
/* 4853 */       if (this.red_elts_ == this.red_.length) {
/* 4854 */         this.red_ = ProtocolSupport.growArray(this.red_);
/*      */       }
/* 4856 */       this.red_[(this.red_elts_++)] = v;
/* 4857 */       return this;
/*      */     }
/*      */     public final Iterator<Integer> redIterator() {
/* 4860 */       return ProtocolSupport.asList(this.red_, 0, this.red_elts_).iterator();
/*      */     }
/*      */     public final List<Integer> reds() {
/* 4863 */       return ProtocolSupport.asList(this.red_, 0, this.red_elts_);
/*      */     }
/*      */     public final List<Integer> mutableReds() {
/* 4866 */       return new AbstractList() {
/* 4867 */         public int size() { return ImagesServicePb.ImagesHistogram.this.red_elts_; } 
/*      */         public Integer get(int i) {
/* 4869 */           if ((i < 0) || (i >= size())) {
/* 4870 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 4872 */           return Integer.valueOf(ImagesServicePb.ImagesHistogram.this.red_[i]);
/*      */         }
/*      */         public Integer set(int i, Integer elt) {
/* 4875 */           Integer result = get(i);
/* 4876 */           ImagesServicePb.ImagesHistogram.this.setRed(i, elt.intValue());
/* 4877 */           return result;
/*      */         }
/*      */         public boolean add(Integer elt) {
/* 4880 */           ImagesServicePb.ImagesHistogram.this.addRed(elt.intValue());
/* 4881 */           return true;
/*      */         }
/*      */         public Integer remove(int i) {
/* 4884 */           if ((i < 0) || (i >= size())) {
/* 4885 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 4887 */           Integer result = get(i);
/* 4888 */           for (int j = i + 1; j < size(); j++) {
/* 4889 */             ImagesServicePb.ImagesHistogram.this.red_[(j - 1)] = ImagesServicePb.ImagesHistogram.access$1300(ImagesServicePb.ImagesHistogram.this)[j];
/*      */           }
/* 4891 */           ImagesServicePb.ImagesHistogram.access$1210(ImagesServicePb.ImagesHistogram.this);
/* 4892 */           return result;
/*      */         }
/* 4894 */         public void clear() { ImagesServicePb.ImagesHistogram.access$1202(ImagesServicePb.ImagesHistogram.this, 0); }
/*      */       };
/*      */     }
/*      */ 
/*      */     public final int greenSize() {
/* 4900 */       return this.green_elts_;
/*      */     }
/*      */     public final int getGreen(int i) {
/* 4903 */       assert ((i >= 0) && (i < this.green_elts_));
/* 4904 */       return this.green_[i];
/*      */     }
/*      */     public ImagesHistogram clearGreen() {
/* 4907 */       this.green_elts_ = 0;
/* 4908 */       this.green_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 4909 */       return this;
/*      */     }
/*      */     public ImagesHistogram setGreen(int i, int v) {
/* 4912 */       assert ((i >= 0) && (i < this.green_elts_));
/* 4913 */       this.green_[i] = v;
/* 4914 */       return this;
/*      */     }
/*      */     public ImagesHistogram addGreen(int v) {
/* 4917 */       if (this.green_elts_ == this.green_.length) {
/* 4918 */         this.green_ = ProtocolSupport.growArray(this.green_);
/*      */       }
/* 4920 */       this.green_[(this.green_elts_++)] = v;
/* 4921 */       return this;
/*      */     }
/*      */     public final Iterator<Integer> greenIterator() {
/* 4924 */       return ProtocolSupport.asList(this.green_, 0, this.green_elts_).iterator();
/*      */     }
/*      */     public final List<Integer> greens() {
/* 4927 */       return ProtocolSupport.asList(this.green_, 0, this.green_elts_);
/*      */     }
/*      */     public final List<Integer> mutableGreens() {
/* 4930 */       return new AbstractList() {
/* 4931 */         public int size() { return ImagesServicePb.ImagesHistogram.this.green_elts_; } 
/*      */         public Integer get(int i) {
/* 4933 */           if ((i < 0) || (i >= size())) {
/* 4934 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 4936 */           return Integer.valueOf(ImagesServicePb.ImagesHistogram.this.green_[i]);
/*      */         }
/*      */         public Integer set(int i, Integer elt) {
/* 4939 */           Integer result = get(i);
/* 4940 */           ImagesServicePb.ImagesHistogram.this.setGreen(i, elt.intValue());
/* 4941 */           return result;
/*      */         }
/*      */         public boolean add(Integer elt) {
/* 4944 */           ImagesServicePb.ImagesHistogram.this.addGreen(elt.intValue());
/* 4945 */           return true;
/*      */         }
/*      */         public Integer remove(int i) {
/* 4948 */           if ((i < 0) || (i >= size())) {
/* 4949 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 4951 */           Integer result = get(i);
/* 4952 */           for (int j = i + 1; j < size(); j++) {
/* 4953 */             ImagesServicePb.ImagesHistogram.this.green_[(j - 1)] = ImagesServicePb.ImagesHistogram.access$1500(ImagesServicePb.ImagesHistogram.this)[j];
/*      */           }
/* 4955 */           ImagesServicePb.ImagesHistogram.access$1410(ImagesServicePb.ImagesHistogram.this);
/* 4956 */           return result;
/*      */         }
/* 4958 */         public void clear() { ImagesServicePb.ImagesHistogram.access$1402(ImagesServicePb.ImagesHistogram.this, 0); }
/*      */       };
/*      */     }
/*      */ 
/*      */     public final int blueSize() {
/* 4964 */       return this.blue_elts_;
/*      */     }
/*      */     public final int getBlue(int i) {
/* 4967 */       assert ((i >= 0) && (i < this.blue_elts_));
/* 4968 */       return this.blue_[i];
/*      */     }
/*      */     public ImagesHistogram clearBlue() {
/* 4971 */       this.blue_elts_ = 0;
/* 4972 */       this.blue_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 4973 */       return this;
/*      */     }
/*      */     public ImagesHistogram setBlue(int i, int v) {
/* 4976 */       assert ((i >= 0) && (i < this.blue_elts_));
/* 4977 */       this.blue_[i] = v;
/* 4978 */       return this;
/*      */     }
/*      */     public ImagesHistogram addBlue(int v) {
/* 4981 */       if (this.blue_elts_ == this.blue_.length) {
/* 4982 */         this.blue_ = ProtocolSupport.growArray(this.blue_);
/*      */       }
/* 4984 */       this.blue_[(this.blue_elts_++)] = v;
/* 4985 */       return this;
/*      */     }
/*      */     public final Iterator<Integer> blueIterator() {
/* 4988 */       return ProtocolSupport.asList(this.blue_, 0, this.blue_elts_).iterator();
/*      */     }
/*      */     public final List<Integer> blues() {
/* 4991 */       return ProtocolSupport.asList(this.blue_, 0, this.blue_elts_);
/*      */     }
/*      */     public final List<Integer> mutableBlues() {
/* 4994 */       return new AbstractList() {
/* 4995 */         public int size() { return ImagesServicePb.ImagesHistogram.this.blue_elts_; } 
/*      */         public Integer get(int i) {
/* 4997 */           if ((i < 0) || (i >= size())) {
/* 4998 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 5000 */           return Integer.valueOf(ImagesServicePb.ImagesHistogram.this.blue_[i]);
/*      */         }
/*      */         public Integer set(int i, Integer elt) {
/* 5003 */           Integer result = get(i);
/* 5004 */           ImagesServicePb.ImagesHistogram.this.setBlue(i, elt.intValue());
/* 5005 */           return result;
/*      */         }
/*      */         public boolean add(Integer elt) {
/* 5008 */           ImagesServicePb.ImagesHistogram.this.addBlue(elt.intValue());
/* 5009 */           return true;
/*      */         }
/*      */         public Integer remove(int i) {
/* 5012 */           if ((i < 0) || (i >= size())) {
/* 5013 */             throw new ArrayIndexOutOfBoundsException();
/*      */           }
/* 5015 */           Integer result = get(i);
/* 5016 */           for (int j = i + 1; j < size(); j++) {
/* 5017 */             ImagesServicePb.ImagesHistogram.this.blue_[(j - 1)] = ImagesServicePb.ImagesHistogram.access$1700(ImagesServicePb.ImagesHistogram.this)[j];
/*      */           }
/* 5019 */           ImagesServicePb.ImagesHistogram.access$1610(ImagesServicePb.ImagesHistogram.this);
/* 5020 */           return result;
/*      */         }
/* 5022 */         public void clear() { ImagesServicePb.ImagesHistogram.access$1602(ImagesServicePb.ImagesHistogram.this, 0);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public ImagesHistogram mergeFrom(ImagesHistogram that)
/*      */     {
/* 5030 */       assert (that != this);
/*      */ 
/* 5032 */       if (that.red_elts_ > 0) {
/* 5033 */         this.red_ = ProtocolSupport.ensureCapacity(this.red_, this.red_elts_ + that.red_elts_);
/* 5034 */         System.arraycopy(that.red_, 0, this.red_, this.red_elts_, that.red_elts_);
/* 5035 */         this.red_elts_ += that.red_elts_;
/*      */       }
/*      */ 
/* 5038 */       if (that.green_elts_ > 0) {
/* 5039 */         this.green_ = ProtocolSupport.ensureCapacity(this.green_, this.green_elts_ + that.green_elts_);
/* 5040 */         System.arraycopy(that.green_, 0, this.green_, this.green_elts_, that.green_elts_);
/* 5041 */         this.green_elts_ += that.green_elts_;
/*      */       }
/*      */ 
/* 5044 */       if (that.blue_elts_ > 0) {
/* 5045 */         this.blue_ = ProtocolSupport.ensureCapacity(this.blue_, this.blue_elts_ + that.blue_elts_);
/* 5046 */         System.arraycopy(that.blue_, 0, this.blue_, this.blue_elts_, that.blue_elts_);
/* 5047 */         this.blue_elts_ += that.blue_elts_;
/*      */       }
/*      */ 
/* 5050 */       if (that.uninterpreted != null) {
/* 5051 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 5053 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesHistogram that) {
/* 5057 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesHistogram that) {
/* 5061 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesHistogram that, boolean ignoreUninterpreted) {
/* 5065 */       if (that == null) return false;
/* 5066 */       if (that == this) return true;
/* 5069 */       int n;
/* 5069 */       if ((n = this.red_elts_) != that.red_elts_) return false;
/* 5070 */       for (int i = 0; i < n; i++) {
/* 5071 */         if (this.red_[i] != that.red_[i]) return false;
/*      */       }
/*      */ 
/* 5074 */       if ((n = this.green_elts_) != that.green_elts_) return false;
/* 5075 */       for (int i = 0; i < n; i++) {
/* 5076 */         if (this.green_[i] != that.green_[i]) return false;
/*      */       }
/*      */ 
/* 5079 */       if ((n = this.blue_elts_) != that.blue_elts_) return false;
/* 5080 */       for (int i = 0; i < n; i++) {
/* 5081 */         if (this.blue_[i] != that.blue_[i]) return false;
/*      */       }
/*      */ 
/* 5084 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 5089 */       return ((that instanceof ImagesHistogram)) && (equals((ImagesHistogram)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 5093 */       int hash = -1616598715;
/*      */ 
/* 5095 */       hash *= 31;
/* 5096 */       int i = 0; for (int n = this.red_elts_; i < n; i++) {
/* 5097 */         hash = hash * 31 + this.red_[i];
/*      */       }
/*      */ 
/* 5100 */       hash *= 31;
/* 5101 */       int i = 0; for (int n = this.green_elts_; i < n; i++) {
/* 5102 */         hash = hash * 31 + this.green_[i];
/*      */       }
/*      */ 
/* 5105 */       hash *= 31;
/* 5106 */       int i = 0; for (int n = this.blue_elts_; i < n; i++) {
/* 5107 */         hash = hash * 31 + this.blue_[i];
/*      */       }
/* 5109 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 5110 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 5112 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 5116 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 5120 */       int n = 0;
/*      */       int m;
/* 5123 */       n += (m = this.red_elts_);
/* 5124 */       for (int i = 0; i < m; i++) {
/* 5125 */         n += Protocol.varLongSize(this.red_[i]);
/*      */       }
/*      */ 
/* 5128 */       n += (m = this.green_elts_);
/* 5129 */       for (int i = 0; i < m; i++) {
/* 5130 */         n += Protocol.varLongSize(this.green_[i]);
/*      */       }
/*      */ 
/* 5133 */       n += (m = this.blue_elts_);
/* 5134 */       for (int i = 0; i < m; i++) {
/* 5135 */         n += Protocol.varLongSize(this.blue_[i]);
/*      */       }
/*      */ 
/* 5138 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 5143 */       int n = 0;
/*      */ 
/* 5145 */       n += 11 * this.red_elts_;
/*      */ 
/* 5147 */       n += 11 * this.green_elts_;
/*      */ 
/* 5149 */       n += 11 * this.blue_elts_;
/*      */ 
/* 5151 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 5156 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 5160 */       this.red_elts_ = 0;
/* 5161 */       this.red_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 5162 */       this.green_elts_ = 0;
/* 5163 */       this.green_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 5164 */       this.blue_elts_ = 0;
/* 5165 */       this.blue_ = ProtocolSupport.EMPTY_INT_ARRAY;
/* 5166 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesHistogram newInstance() {
/* 5170 */       return new ImagesHistogram();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 5174 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 5198 */       int i = 0; for (int m = this.red_elts_; i < m; i++) {
/* 5199 */         int v = this.red_[i];
/* 5200 */         sink.putByte(8);
/* 5201 */         sink.putVarLong(v);
/*      */       }
/*      */ 
/* 5204 */       int i = 0; for (int m = this.green_elts_; i < m; i++) {
/* 5205 */         int v = this.green_[i];
/* 5206 */         sink.putByte(16);
/* 5207 */         sink.putVarLong(v);
/*      */       }
/*      */ 
/* 5210 */       int i = 0; for (int m = this.blue_elts_; i < m; i++) {
/* 5211 */         int v = this.blue_[i];
/* 5212 */         sink.putByte(24);
/* 5213 */         sink.putVarLong(v);
/*      */       }
/*      */ 
/* 5216 */       if (this.uninterpreted != null)
/* 5217 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 5222 */       boolean result = true;
/*      */ 
/* 5224 */       while (source.hasRemaining()) {
/* 5225 */         int tt = source.getVarInt();
/* 5226 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 5230 */           result = false;
/* 5231 */           break;
/*      */         case 8:
/* 5234 */           addRed(source.getVarInt());
/* 5235 */           break;
/*      */         case 16:
/* 5238 */           addGreen(source.getVarInt());
/* 5239 */           break;
/*      */         case 24:
/* 5242 */           addBlue(source.getVarInt());
/* 5243 */           break;
/*      */         default:
/* 5245 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5250 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesHistogram getDefaultInstanceForType()
/*      */     {
/* 5255 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesHistogram getDefaultInstance() {
/* 5259 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesHistogram freeze()
/*      */     {
/* 5329 */       this.red_ = ProtocolSupport.freezeArray(this.red_, this.red_elts_);
/* 5330 */       this.green_ = ProtocolSupport.freezeArray(this.green_, this.green_elts_);
/* 5331 */       this.blue_ = ProtocolSupport.freezeArray(this.blue_, this.blue_elts_);
/* 5332 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 5335 */       if (this.uninterpreted == null) {
/* 5336 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 5338 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 5263 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesHistogram()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogram clearRed()
/*      */         {
/* 5271 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram setRed(int i, int v) {
/* 5274 */           ProtocolSupport.unsupportedOperation();
/* 5275 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram addRed(int v) {
/* 5278 */           ProtocolSupport.unsupportedOperation();
/* 5279 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogram clearGreen()
/*      */         {
/* 5284 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram setGreen(int i, int v) {
/* 5287 */           ProtocolSupport.unsupportedOperation();
/* 5288 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram addGreen(int v) {
/* 5291 */           ProtocolSupport.unsupportedOperation();
/* 5292 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogram clearBlue()
/*      */         {
/* 5297 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram setBlue(int i, int v) {
/* 5300 */           ProtocolSupport.unsupportedOperation();
/* 5301 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram addBlue(int v) {
/* 5304 */           ProtocolSupport.unsupportedOperation();
/* 5305 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogram mergeFrom(ImagesServicePb.ImagesHistogram that) {
/* 5309 */           ProtocolSupport.unsupportedOperation();
/* 5310 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 5313 */           ProtocolSupport.unsupportedOperation();
/* 5314 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram freeze() {
/* 5317 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogram unfreeze() {
/* 5320 */           ProtocolSupport.unsupportedOperation();
/* 5321 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 5324 */           return true;
/*      */         }
/*      */       };
/* 5345 */       text = new String[4];
/*      */ 
/* 5347 */       text[0] = "ErrorCode";
/* 5348 */       text[1] = "red";
/* 5349 */       text[2] = "green";
/* 5350 */       text[3] = "blue";
/*      */ 
/* 5353 */       types = new int[4];
/*      */ 
/* 5355 */       Arrays.fill(types, 6);
/* 5356 */       types[0] = 0;
/* 5357 */       types[1] = 0;
/* 5358 */       types[2] = 0;
/* 5359 */       types[3] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 5178 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesHistogram.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("red", "red", 1, -1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("green", "green", 2, -1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("blue", "blue", 3, -1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REPEATED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesHistogramRequest extends ProtocolMessage<ImagesHistogramRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 4548 */     private ImagesServicePb.ImageData image_ = new ImagesServicePb.ImageData();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesHistogramRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kimage = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final ImagesServicePb.ImageData getImage()
/*      */     {
/* 4554 */       return this.image_;
/*      */     }
/*      */     public final boolean hasImage() {
/* 4557 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesHistogramRequest clearImage() {
/* 4560 */       this.optional_0_ &= -2;
/* 4561 */       this.image_.clear();
/* 4562 */       return this;
/*      */     }
/*      */     public ImagesHistogramRequest setImage(ImagesServicePb.ImageData x) {
/* 4565 */       if (x == null) throw new NullPointerException();
/* 4566 */       this.optional_0_ |= 1;
/* 4567 */       this.image_ = x;
/* 4568 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImageData getMutableImage() {
/* 4571 */       this.optional_0_ |= 1;
/* 4572 */       return this.image_;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramRequest mergeFrom(ImagesHistogramRequest that)
/*      */     {
/* 4579 */       assert (that != this);
/* 4580 */       int this_t0 = this.optional_0_;
/* 4581 */       int that_t0 = that.optional_0_;
/*      */ 
/* 4583 */       if ((that_t0 & 0x1) != 0) {
/* 4584 */         this_t0 |= 1;
/* 4585 */         ImagesServicePb.ImageData v = this.image_;
/* 4586 */         v.mergeFrom(that.image_);
/*      */       }
/*      */ 
/* 4589 */       if (that.uninterpreted != null) {
/* 4590 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 4592 */       this.optional_0_ = this_t0;
/* 4593 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesHistogramRequest that) {
/* 4597 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesHistogramRequest that) {
/* 4601 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesHistogramRequest that, boolean ignoreUninterpreted) {
/* 4605 */       if (that == null) return false;
/* 4606 */       if (that == this) return true;
/* 4607 */       int this_t0 = this.optional_0_;
/* 4608 */       int that_t0 = that.optional_0_;
/* 4609 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 4611 */       if (((this_t0 & 0x1) != 0) && 
/* 4612 */         (!this.image_.equals(that.image_, ignoreUninterpreted))) return false;
/*      */ 
/* 4615 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 4620 */       return ((that instanceof ImagesHistogramRequest)) && (equals((ImagesHistogramRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 4624 */       int hash = 1843104738;
/*      */ 
/* 4626 */       int this_t0 = this.optional_0_;
/* 4627 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.image_.hashCode() : -113);
/* 4628 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 4629 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 4631 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 4635 */       int this_t0 = this.optional_0_;
/* 4636 */       if ((this_t0 & 0x1) != 1) {
/* 4637 */         return false;
/*      */       }
/*      */ 
/* 4641 */       return this.image_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 4648 */       int n = 1 + Protocol.stringSize(this.image_.encodingSize());
/*      */ 
/* 4650 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 4656 */       int n = 6 + this.image_.maxEncodingSize();
/*      */ 
/* 4658 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 4663 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 4667 */       this.optional_0_ = 0;
/* 4668 */       this.image_.clear();
/* 4669 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramRequest newInstance() {
/* 4673 */       return new ImagesHistogramRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 4677 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 4697 */       sink.putByte(10);
/* 4698 */       sink.putForeign(this.image_);
/*      */ 
/* 4700 */       if (this.uninterpreted != null)
/* 4701 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 4706 */       boolean result = true;
/* 4707 */       int this_t0 = this.optional_0_;
/*      */ 
/* 4709 */       while (source.hasRemaining()) {
/* 4710 */         int tt = source.getVarInt();
/* 4711 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 4715 */           result = false;
/* 4716 */           break;
/*      */         case 10:
/* 4719 */           source.push(source.getVarInt());
/* 4720 */           if (!this.image_.merge(source)) { result = false; break label111; }
/* 4721 */           source.pop();
/* 4722 */           this_t0 |= 1;
/* 4723 */           break;
/*      */         default:
/* 4725 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4730 */       label111: this.optional_0_ = this_t0;
/* 4731 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramRequest getDefaultInstanceForType()
/*      */     {
/* 4736 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesHistogramRequest getDefaultInstance() {
/* 4740 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramRequest freeze()
/*      */     {
/* 4783 */       this.image_.freeze();
/* 4784 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesHistogramRequest unfreeze() {
/* 4788 */       this.image_.unfreeze();
/* 4789 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 4793 */       return this.image_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 4796 */       if (this.uninterpreted == null) {
/* 4797 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 4799 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4744 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesHistogramRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogramRequest clearImage()
/*      */         {
/* 4752 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogramRequest setImage(ImagesServicePb.ImageData x) {
/* 4755 */           ProtocolSupport.unsupportedOperation();
/* 4756 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData getMutableImage() {
/* 4759 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesHistogramRequest mergeFrom(ImagesServicePb.ImagesHistogramRequest that) {
/* 4763 */           ProtocolSupport.unsupportedOperation();
/* 4764 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 4767 */           ProtocolSupport.unsupportedOperation();
/* 4768 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogramRequest freeze() {
/* 4771 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesHistogramRequest unfreeze() {
/* 4774 */           ProtocolSupport.unsupportedOperation();
/* 4775 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 4778 */           return true;
/*      */         }
/*      */       };
/* 4804 */       text = new String[2];
/*      */ 
/* 4806 */       text[0] = "ErrorCode";
/* 4807 */       text[1] = "image";
/*      */ 
/* 4810 */       types = new int[2];
/*      */ 
/* 4812 */       Arrays.fill(types, 6);
/* 4813 */       types[0] = 0;
/* 4814 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 4681 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesHistogramRequest.class, "Z*apphosting/api/images/images_service.proto\n!apphosting.ImagesHistogramRequest\023\032\005image \001(\0020\0138\002J\024apphosting.ImageData\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("image", "image", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.ImageData.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesCompositeResponse extends ProtocolMessage<ImagesCompositeResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 4270 */     private ImagesServicePb.ImageData image_ = new ImagesServicePb.ImageData();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesCompositeResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kimage = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final ImagesServicePb.ImageData getImage()
/*      */     {
/* 4276 */       return this.image_;
/*      */     }
/*      */     public final boolean hasImage() {
/* 4279 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesCompositeResponse clearImage() {
/* 4282 */       this.optional_0_ &= -2;
/* 4283 */       this.image_.clear();
/* 4284 */       return this;
/*      */     }
/*      */     public ImagesCompositeResponse setImage(ImagesServicePb.ImageData x) {
/* 4287 */       if (x == null) throw new NullPointerException();
/* 4288 */       this.optional_0_ |= 1;
/* 4289 */       this.image_ = x;
/* 4290 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImageData getMutableImage() {
/* 4293 */       this.optional_0_ |= 1;
/* 4294 */       return this.image_;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeResponse mergeFrom(ImagesCompositeResponse that)
/*      */     {
/* 4301 */       assert (that != this);
/* 4302 */       int this_t0 = this.optional_0_;
/* 4303 */       int that_t0 = that.optional_0_;
/*      */ 
/* 4305 */       if ((that_t0 & 0x1) != 0) {
/* 4306 */         this_t0 |= 1;
/* 4307 */         ImagesServicePb.ImageData v = this.image_;
/* 4308 */         v.mergeFrom(that.image_);
/*      */       }
/*      */ 
/* 4311 */       if (that.uninterpreted != null) {
/* 4312 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 4314 */       this.optional_0_ = this_t0;
/* 4315 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesCompositeResponse that) {
/* 4319 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesCompositeResponse that) {
/* 4323 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesCompositeResponse that, boolean ignoreUninterpreted) {
/* 4327 */       if (that == null) return false;
/* 4328 */       if (that == this) return true;
/* 4329 */       int this_t0 = this.optional_0_;
/* 4330 */       int that_t0 = that.optional_0_;
/* 4331 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 4333 */       if (((this_t0 & 0x1) != 0) && 
/* 4334 */         (!this.image_.equals(that.image_, ignoreUninterpreted))) return false;
/*      */ 
/* 4337 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 4342 */       return ((that instanceof ImagesCompositeResponse)) && (equals((ImagesCompositeResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 4346 */       int hash = 931991777;
/*      */ 
/* 4348 */       int this_t0 = this.optional_0_;
/* 4349 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.image_.hashCode() : -113);
/* 4350 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 4351 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 4353 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 4357 */       int this_t0 = this.optional_0_;
/* 4358 */       if ((this_t0 & 0x1) != 1) {
/* 4359 */         return false;
/*      */       }
/*      */ 
/* 4363 */       return this.image_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 4370 */       int n = 1 + Protocol.stringSize(this.image_.encodingSize());
/*      */ 
/* 4372 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 4378 */       int n = 6 + this.image_.maxEncodingSize();
/*      */ 
/* 4380 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 4385 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 4389 */       this.optional_0_ = 0;
/* 4390 */       this.image_.clear();
/* 4391 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeResponse newInstance() {
/* 4395 */       return new ImagesCompositeResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 4399 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 4419 */       sink.putByte(10);
/* 4420 */       sink.putForeign(this.image_);
/*      */ 
/* 4422 */       if (this.uninterpreted != null)
/* 4423 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 4428 */       boolean result = true;
/* 4429 */       int this_t0 = this.optional_0_;
/*      */ 
/* 4431 */       while (source.hasRemaining()) {
/* 4432 */         int tt = source.getVarInt();
/* 4433 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 4437 */           result = false;
/* 4438 */           break;
/*      */         case 10:
/* 4441 */           source.push(source.getVarInt());
/* 4442 */           if (!this.image_.merge(source)) { result = false; break label111; }
/* 4443 */           source.pop();
/* 4444 */           this_t0 |= 1;
/* 4445 */           break;
/*      */         default:
/* 4447 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4452 */       label111: this.optional_0_ = this_t0;
/* 4453 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeResponse getDefaultInstanceForType()
/*      */     {
/* 4458 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesCompositeResponse getDefaultInstance() {
/* 4462 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeResponse freeze()
/*      */     {
/* 4505 */       this.image_.freeze();
/* 4506 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeResponse unfreeze() {
/* 4510 */       this.image_.unfreeze();
/* 4511 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 4515 */       return this.image_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 4518 */       if (this.uninterpreted == null) {
/* 4519 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 4521 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4466 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesCompositeResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesCompositeResponse clearImage()
/*      */         {
/* 4474 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCompositeResponse setImage(ImagesServicePb.ImageData x) {
/* 4477 */           ProtocolSupport.unsupportedOperation();
/* 4478 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData getMutableImage() {
/* 4481 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCompositeResponse mergeFrom(ImagesServicePb.ImagesCompositeResponse that) {
/* 4485 */           ProtocolSupport.unsupportedOperation();
/* 4486 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 4489 */           ProtocolSupport.unsupportedOperation();
/* 4490 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesCompositeResponse freeze() {
/* 4493 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCompositeResponse unfreeze() {
/* 4496 */           ProtocolSupport.unsupportedOperation();
/* 4497 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 4500 */           return true;
/*      */         }
/*      */       };
/* 4526 */       text = new String[2];
/*      */ 
/* 4528 */       text[0] = "ErrorCode";
/* 4529 */       text[1] = "image";
/*      */ 
/* 4532 */       types = new int[2];
/*      */ 
/* 4534 */       Arrays.fill(types, 6);
/* 4535 */       types[0] = 0;
/* 4536 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 4403 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesCompositeResponse.class, "Z*apphosting/api/images/images_service.proto\n\"apphosting.ImagesCompositeResponse\023\032\005image \001(\0020\0138\002J\024apphosting.ImageData\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("image", "image", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.ImageData.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesCompositeRequest extends ProtocolMessage<ImagesCompositeRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 3732 */     private List<ImagesServicePb.ImageData> image_ = null;
/* 3733 */     private List<ImagesServicePb.CompositeImageOptions> options_ = null;
/* 3734 */     private ImagesServicePb.ImagesCanvas canvas_ = new ImagesServicePb.ImagesCanvas();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesCompositeRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kimage = 1;
/*      */     public static final int koptions = 2;
/*      */     public static final int kcanvas = 3;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int imageSize()
/*      */     {
/* 3740 */       return this.image_ != null ? this.image_.size() : 0;
/*      */     }
/*      */     public final ImagesServicePb.ImageData getImage(int i) {
/* 3743 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.image_ != null ? this.image_.size() : 0)); } else throw new AssertionError();
/* 3744 */       return (ImagesServicePb.ImageData)this.image_.get(i);
/*      */     }
/*      */     public ImagesCompositeRequest clearImage() {
/* 3747 */       if (this.image_ != null) this.image_.clear();
/* 3748 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImageData getMutableImage(int i) {
/* 3751 */       assert ((i >= 0) && (this.image_ != null) && (i < this.image_.size()));
/* 3752 */       return (ImagesServicePb.ImageData)this.image_.get(i);
/*      */     }
/*      */     public ImagesServicePb.ImageData addImage() {
/* 3755 */       ImagesServicePb.ImageData v = new ImagesServicePb.ImageData();
/* 3756 */       if (this.image_ == null) this.image_ = new ArrayList(4);
/* 3757 */       this.image_.add(v);
/* 3758 */       return v;
/*      */     }
/*      */     public ImagesServicePb.ImageData addImage(ImagesServicePb.ImageData v) {
/* 3761 */       if (this.image_ == null) this.image_ = new ArrayList(4);
/* 3762 */       this.image_.add(v);
/* 3763 */       return v;
/*      */     }
/*      */     public ImagesServicePb.ImageData insertImage(int i, ImagesServicePb.ImageData v) {
/* 3766 */       if (this.image_ == null) this.image_ = new ArrayList(4);
/* 3767 */       this.image_.add(i, v);
/* 3768 */       return v;
/*      */     }
/*      */     public ImagesServicePb.ImageData removeImage(int i) {
/* 3771 */       return (ImagesServicePb.ImageData)this.image_.remove(i);
/*      */     }
/*      */     public final Iterator<ImagesServicePb.ImageData> imageIterator() {
/* 3774 */       if (this.image_ == null) {
/* 3775 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 3777 */       return this.image_.iterator();
/*      */     }
/*      */     public final List<ImagesServicePb.ImageData> images() {
/* 3780 */       return ProtocolSupport.unmodifiableList(this.image_);
/*      */     }
/*      */     public final List<ImagesServicePb.ImageData> mutableImages() {
/* 3783 */       if (this.image_ == null) this.image_ = new ArrayList(4);
/* 3784 */       return this.image_;
/*      */     }
/*      */ 
/*      */     public final int optionsSize()
/*      */     {
/* 3789 */       return this.options_ != null ? this.options_.size() : 0;
/*      */     }
/*      */     public final ImagesServicePb.CompositeImageOptions getOptions(int i) {
/* 3792 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.options_ != null ? this.options_.size() : 0)); } else throw new AssertionError();
/* 3793 */       return (ImagesServicePb.CompositeImageOptions)this.options_.get(i);
/*      */     }
/*      */     public ImagesCompositeRequest clearOptions() {
/* 3796 */       if (this.options_ != null) this.options_.clear();
/* 3797 */       return this;
/*      */     }
/*      */     public ImagesServicePb.CompositeImageOptions getMutableOptions(int i) {
/* 3800 */       assert ((i >= 0) && (this.options_ != null) && (i < this.options_.size()));
/* 3801 */       return (ImagesServicePb.CompositeImageOptions)this.options_.get(i);
/*      */     }
/*      */     public ImagesServicePb.CompositeImageOptions addOptions() {
/* 3804 */       ImagesServicePb.CompositeImageOptions v = new ImagesServicePb.CompositeImageOptions();
/* 3805 */       if (this.options_ == null) this.options_ = new ArrayList(4);
/* 3806 */       this.options_.add(v);
/* 3807 */       return v;
/*      */     }
/*      */     public ImagesServicePb.CompositeImageOptions addOptions(ImagesServicePb.CompositeImageOptions v) {
/* 3810 */       if (this.options_ == null) this.options_ = new ArrayList(4);
/* 3811 */       this.options_.add(v);
/* 3812 */       return v;
/*      */     }
/*      */     public ImagesServicePb.CompositeImageOptions insertOptions(int i, ImagesServicePb.CompositeImageOptions v) {
/* 3815 */       if (this.options_ == null) this.options_ = new ArrayList(4);
/* 3816 */       this.options_.add(i, v);
/* 3817 */       return v;
/*      */     }
/*      */     public ImagesServicePb.CompositeImageOptions removeOptions(int i) {
/* 3820 */       return (ImagesServicePb.CompositeImageOptions)this.options_.remove(i);
/*      */     }
/*      */     public final Iterator<ImagesServicePb.CompositeImageOptions> optionsIterator() {
/* 3823 */       if (this.options_ == null) {
/* 3824 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 3826 */       return this.options_.iterator();
/*      */     }
/*      */     public final List<ImagesServicePb.CompositeImageOptions> optionss() {
/* 3829 */       return ProtocolSupport.unmodifiableList(this.options_);
/*      */     }
/*      */     public final List<ImagesServicePb.CompositeImageOptions> mutableOptionss() {
/* 3832 */       if (this.options_ == null) this.options_ = new ArrayList(4);
/* 3833 */       return this.options_;
/*      */     }
/*      */ 
/*      */     public final ImagesServicePb.ImagesCanvas getCanvas()
/*      */     {
/* 3838 */       return this.canvas_;
/*      */     }
/*      */     public final boolean hasCanvas() {
/* 3841 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesCompositeRequest clearCanvas() {
/* 3844 */       this.optional_0_ &= -2;
/* 3845 */       this.canvas_.clear();
/* 3846 */       return this;
/*      */     }
/*      */     public ImagesCompositeRequest setCanvas(ImagesServicePb.ImagesCanvas x) {
/* 3849 */       if (x == null) throw new NullPointerException();
/* 3850 */       this.optional_0_ |= 1;
/* 3851 */       this.canvas_ = x;
/* 3852 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImagesCanvas getMutableCanvas() {
/* 3855 */       this.optional_0_ |= 1;
/* 3856 */       return this.canvas_;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeRequest mergeFrom(ImagesCompositeRequest that)
/*      */     {
/* 3863 */       assert (that != this);
/* 3864 */       int this_t0 = this.optional_0_;
/* 3865 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3867 */       if (that.image_ != null) {
/* 3868 */         for (ImagesServicePb.ImageData v : that.image_) {
/* 3869 */           addImage().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 3873 */       if (that.options_ != null) {
/* 3874 */         for (ImagesServicePb.CompositeImageOptions v : that.options_) {
/* 3875 */           addOptions().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 3879 */       if ((that_t0 & 0x1) != 0) {
/* 3880 */         this_t0 |= 1;
/* 3881 */         ImagesServicePb.ImagesCanvas v = this.canvas_;
/* 3882 */         v.mergeFrom(that.canvas_);
/*      */       }
/*      */ 
/* 3885 */       if (that.uninterpreted != null) {
/* 3886 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3888 */       this.optional_0_ = this_t0;
/* 3889 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesCompositeRequest that) {
/* 3893 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesCompositeRequest that) {
/* 3897 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesCompositeRequest that, boolean ignoreUninterpreted) {
/* 3901 */       if (that == null) return false;
/* 3902 */       if (that == this) return true;
/* 3903 */       int this_t0 = this.optional_0_;
/* 3904 */       int that_t0 = that.optional_0_;
/* 3905 */       if (this_t0 != that_t0) return false;
/* 3908 */       int n;
/* 3908 */       if ((n = this.image_ != null ? this.image_.size() : 0) != (that.image_ != null ? that.image_.size() : 0)) return false;
/* 3909 */       for (int i = 0; i < n; i++) {
/* 3910 */         if (!((ImagesServicePb.ImageData)this.image_.get(i)).equals((ImagesServicePb.ImageData)that.image_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 3913 */       if ((n = this.options_ != null ? this.options_.size() : 0) != (that.options_ != null ? that.options_.size() : 0)) return false;
/* 3914 */       for (int i = 0; i < n; i++) {
/* 3915 */         if (!((ImagesServicePb.CompositeImageOptions)this.options_.get(i)).equals((ImagesServicePb.CompositeImageOptions)that.options_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 3918 */       if (((this_t0 & 0x1) != 0) && 
/* 3919 */         (!this.canvas_.equals(that.canvas_, ignoreUninterpreted))) return false;
/*      */ 
/* 3922 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3927 */       return ((that instanceof ImagesCompositeRequest)) && (equals((ImagesCompositeRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3931 */       int hash = 680659642;
/*      */ 
/* 3933 */       hash *= 31;
/* 3934 */       int i = 0; for (int n = this.image_ != null ? this.image_.size() : 0; i < n; i++) {
/* 3935 */         hash = hash * 31 + ((ImagesServicePb.ImageData)this.image_.get(i)).hashCode();
/*      */       }
/*      */ 
/* 3938 */       hash *= 31;
/* 3939 */       int i = 0; for (int n = this.options_ != null ? this.options_.size() : 0; i < n; i++) {
/* 3940 */         hash = hash * 31 + ((ImagesServicePb.CompositeImageOptions)this.options_.get(i)).hashCode();
/*      */       }
/*      */ 
/* 3943 */       int this_t0 = this.optional_0_;
/* 3944 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.canvas_.hashCode() : -113);
/* 3945 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3946 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3948 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3952 */       int this_t0 = this.optional_0_;
/* 3953 */       if ((this_t0 & 0x1) != 1) {
/* 3954 */         return false;
/*      */       }
/*      */ 
/* 3957 */       if (this.image_ != null) {
/* 3958 */         for (ImagesServicePb.ImageData v : this.image_) {
/* 3959 */           if (!v.isInitialized()) {
/* 3960 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 3965 */       if (this.options_ != null) {
/* 3966 */         for (ImagesServicePb.CompositeImageOptions v : this.options_) {
/* 3967 */           if (!v.isInitialized()) {
/* 3968 */             return false;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3974 */       return this.canvas_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3981 */       int n = 1 + Protocol.stringSize(this.canvas_.encodingSize());
/*      */       int m;
/* 3984 */       n += (m = this.image_ != null ? this.image_.size() : 0);
/* 3985 */       for (int i = 0; i < m; i++) {
/* 3986 */         n += Protocol.stringSize(((ImagesServicePb.ImageData)this.image_.get(i)).encodingSize());
/*      */       }
/*      */ 
/* 3989 */       n += (m = this.options_ != null ? this.options_.size() : 0);
/* 3990 */       for (int i = 0; i < m; i++) {
/* 3991 */         n += Protocol.stringSize(((ImagesServicePb.CompositeImageOptions)this.options_.get(i)).encodingSize());
/*      */       }
/*      */ 
/* 3994 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 4000 */       int n = 6 + this.canvas_.maxEncodingSize();
/*      */       int m;
/* 4003 */       n += 6 * (m = this.image_ != null ? this.image_.size() : 0);
/* 4004 */       for (int i = 0; i < m; i++) {
/* 4005 */         n += ((ImagesServicePb.ImageData)this.image_.get(i)).maxEncodingSize();
/*      */       }
/*      */ 
/* 4008 */       n += 6 * (m = this.options_ != null ? this.options_.size() : 0);
/* 4009 */       for (int i = 0; i < m; i++) {
/* 4010 */         n += ((ImagesServicePb.CompositeImageOptions)this.options_.get(i)).maxEncodingSize();
/*      */       }
/*      */ 
/* 4013 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 4018 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 4022 */       this.optional_0_ = 0;
/* 4023 */       if (this.image_ != null) this.image_.clear();
/* 4024 */       if (this.options_ != null) this.options_.clear();
/* 4025 */       this.canvas_.clear();
/* 4026 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeRequest newInstance() {
/* 4030 */       return new ImagesCompositeRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 4034 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 4065 */       int i = 0; for (int m = this.image_ != null ? this.image_.size() : 0; i < m; i++) {
/* 4066 */         ImagesServicePb.ImageData v = (ImagesServicePb.ImageData)this.image_.get(i);
/* 4067 */         sink.putByte(10);
/* 4068 */         sink.putForeign(v);
/*      */       }
/*      */ 
/* 4071 */       int i = 0; for (int m = this.options_ != null ? this.options_.size() : 0; i < m; i++) {
/* 4072 */         ImagesServicePb.CompositeImageOptions v = (ImagesServicePb.CompositeImageOptions)this.options_.get(i);
/* 4073 */         sink.putByte(18);
/* 4074 */         sink.putForeign(v);
/*      */       }
/*      */ 
/* 4077 */       sink.putByte(26);
/* 4078 */       sink.putForeign(this.canvas_);
/*      */ 
/* 4080 */       if (this.uninterpreted != null)
/* 4081 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 4086 */       boolean result = true;
/* 4087 */       int this_t0 = this.optional_0_;
/*      */ 
/* 4089 */       while (source.hasRemaining()) {
/* 4090 */         int tt = source.getVarInt();
/* 4091 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 4095 */           result = false;
/* 4096 */           break;
/*      */         case 10:
/* 4099 */           source.push(source.getVarInt());
/* 4100 */           if (!addImage().merge(source)) { result = false; break label193; }
/* 4101 */           source.pop();
/* 4102 */           break;
/*      */         case 18:
/* 4105 */           source.push(source.getVarInt());
/* 4106 */           if (!addOptions().merge(source)) { result = false; break label193; }
/* 4107 */           source.pop();
/* 4108 */           break;
/*      */         case 26:
/* 4111 */           source.push(source.getVarInt());
/* 4112 */           if (!this.canvas_.merge(source)) { result = false; break label193; }
/* 4113 */           source.pop();
/* 4114 */           this_t0 |= 1;
/* 4115 */           break;
/*      */         default:
/* 4117 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4122 */       label193: this.optional_0_ = this_t0;
/* 4123 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeRequest getDefaultInstanceForType()
/*      */     {
/* 4128 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesCompositeRequest getDefaultInstance() {
/* 4132 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeRequest freeze()
/*      */     {
/* 4215 */       this.image_ = ProtocolSupport.freezeMessages(this.image_);
/* 4216 */       this.options_ = ProtocolSupport.freezeMessages(this.options_);
/* 4217 */       this.canvas_.freeze();
/* 4218 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesCompositeRequest unfreeze() {
/* 4222 */       this.image_ = ProtocolSupport.unfreezeMessages(this.image_);
/* 4223 */       this.options_ = ProtocolSupport.unfreezeMessages(this.options_);
/* 4224 */       this.canvas_.unfreeze();
/* 4225 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 4229 */       return (ProtocolSupport.isFrozenMessages(this.image_)) || (ProtocolSupport.isFrozenMessages(this.options_)) || (this.canvas_.isFrozen());
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 4234 */       if (this.uninterpreted == null) {
/* 4235 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 4237 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4136 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesCompositeRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesCompositeRequest clearImage()
/*      */         {
/* 4144 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData getMutableImage(int i) {
/* 4147 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.ImageData addImage() {
/* 4150 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.ImageData addImage(ImagesServicePb.ImageData v) {
/* 4153 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.ImageData insertImage(int i, ImagesServicePb.ImageData v) {
/* 4156 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.ImageData removeImage(int i) {
/* 4159 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCompositeRequest clearOptions()
/*      */         {
/* 4164 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions getMutableOptions(int i) {
/* 4167 */           return (ImagesServicePb.CompositeImageOptions)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions addOptions() {
/* 4170 */           return (ImagesServicePb.CompositeImageOptions)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions addOptions(ImagesServicePb.CompositeImageOptions v) {
/* 4173 */           return (ImagesServicePb.CompositeImageOptions)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions insertOptions(int i, ImagesServicePb.CompositeImageOptions v) {
/* 4176 */           return (ImagesServicePb.CompositeImageOptions)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions removeOptions(int i) {
/* 4179 */           return (ImagesServicePb.CompositeImageOptions)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCompositeRequest clearCanvas()
/*      */         {
/* 4184 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCompositeRequest setCanvas(ImagesServicePb.ImagesCanvas x) {
/* 4187 */           ProtocolSupport.unsupportedOperation();
/* 4188 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas getMutableCanvas() {
/* 4191 */           return (ImagesServicePb.ImagesCanvas)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCompositeRequest mergeFrom(ImagesServicePb.ImagesCompositeRequest that) {
/* 4195 */           ProtocolSupport.unsupportedOperation();
/* 4196 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 4199 */           ProtocolSupport.unsupportedOperation();
/* 4200 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesCompositeRequest freeze() {
/* 4203 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCompositeRequest unfreeze() {
/* 4206 */           ProtocolSupport.unsupportedOperation();
/* 4207 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 4210 */           return true;
/*      */         }
/*      */       };
/* 4244 */       text = new String[4];
/*      */ 
/* 4246 */       text[0] = "ErrorCode";
/* 4247 */       text[1] = "image";
/* 4248 */       text[2] = "options";
/* 4249 */       text[3] = "canvas";
/*      */ 
/* 4252 */       types = new int[4];
/*      */ 
/* 4254 */       Arrays.fill(types, 6);
/* 4255 */       types[0] = 0;
/* 4256 */       types[1] = 2;
/* 4257 */       types[2] = 2;
/* 4258 */       types[3] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 4038 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesCompositeRequest.class, "Z*apphosting/api/images/images_service.proto\n!apphosting.ImagesCompositeRequest\023\032\005image \001(\0020\0138\003J\024apphosting.ImageData\024\023\032\007options \002(\0020\0138\003J apphosting.CompositeImageOptions\024\023\032\006canvas \003(\0020\0138\002J\027apphosting.ImagesCanvas\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("image", "image", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, ImagesServicePb.ImageData.class), new ProtocolType.FieldType("options", "options", 2, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, ImagesServicePb.CompositeImageOptions.class), new ProtocolType.FieldType("canvas", "canvas", 3, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.ImagesCanvas.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesCanvas extends ProtocolMessage<ImagesCanvas>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 3270 */     private int width_ = 0;
/* 3271 */     private int height_ = 0;
/* 3272 */     private ImagesServicePb.OutputSettings output_ = new ImagesServicePb.OutputSettings();
/* 3273 */     private int color_ = -1;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesCanvas IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kwidth = 1;
/*      */     public static final int kheight = 2;
/*      */     public static final int koutput = 3;
/*      */     public static final int kcolor = 4;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int getWidth()
/*      */     {
/* 3279 */       return this.width_;
/*      */     }
/*      */     public final boolean hasWidth() {
/* 3282 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesCanvas clearWidth() {
/* 3285 */       this.optional_0_ &= -2;
/* 3286 */       this.width_ = 0;
/* 3287 */       return this;
/*      */     }
/*      */     public ImagesCanvas setWidth(int x) {
/* 3290 */       this.optional_0_ |= 1;
/* 3291 */       this.width_ = x;
/* 3292 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getHeight()
/*      */     {
/* 3297 */       return this.height_;
/*      */     }
/*      */     public final boolean hasHeight() {
/* 3300 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public ImagesCanvas clearHeight() {
/* 3303 */       this.optional_0_ &= -3;
/* 3304 */       this.height_ = 0;
/* 3305 */       return this;
/*      */     }
/*      */     public ImagesCanvas setHeight(int x) {
/* 3308 */       this.optional_0_ |= 2;
/* 3309 */       this.height_ = x;
/* 3310 */       return this;
/*      */     }
/*      */ 
/*      */     public final ImagesServicePb.OutputSettings getOutput()
/*      */     {
/* 3315 */       return this.output_;
/*      */     }
/*      */     public final boolean hasOutput() {
/* 3318 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public ImagesCanvas clearOutput() {
/* 3321 */       this.optional_0_ &= -5;
/* 3322 */       this.output_.clear();
/* 3323 */       return this;
/*      */     }
/*      */     public ImagesCanvas setOutput(ImagesServicePb.OutputSettings x) {
/* 3326 */       if (x == null) throw new NullPointerException();
/* 3327 */       this.optional_0_ |= 4;
/* 3328 */       this.output_ = x;
/* 3329 */       return this;
/*      */     }
/*      */     public ImagesServicePb.OutputSettings getMutableOutput() {
/* 3332 */       this.optional_0_ |= 4;
/* 3333 */       return this.output_;
/*      */     }
/*      */ 
/*      */     public final int getColor()
/*      */     {
/* 3338 */       return this.color_;
/*      */     }
/*      */     public final boolean hasColor() {
/* 3341 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public ImagesCanvas clearColor() {
/* 3344 */       this.optional_0_ &= -9;
/* 3345 */       this.color_ = -1;
/* 3346 */       return this;
/*      */     }
/*      */     public ImagesCanvas setColor(int x) {
/* 3349 */       this.optional_0_ |= 8;
/* 3350 */       this.color_ = x;
/* 3351 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesCanvas mergeFrom(ImagesCanvas that)
/*      */     {
/* 3358 */       assert (that != this);
/* 3359 */       int this_t0 = this.optional_0_;
/* 3360 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3362 */       if ((that_t0 & 0x1) != 0) {
/* 3363 */         this_t0 |= 1;
/* 3364 */         this.width_ = that.width_;
/*      */       }
/*      */ 
/* 3367 */       if ((that_t0 & 0x2) != 0) {
/* 3368 */         this_t0 |= 2;
/* 3369 */         this.height_ = that.height_;
/*      */       }
/*      */ 
/* 3372 */       if ((that_t0 & 0x4) != 0) {
/* 3373 */         this_t0 |= 4;
/* 3374 */         ImagesServicePb.OutputSettings v = this.output_;
/* 3375 */         v.mergeFrom(that.output_);
/*      */       }
/*      */ 
/* 3378 */       if ((that_t0 & 0x8) != 0) {
/* 3379 */         this_t0 |= 8;
/* 3380 */         this.color_ = that.color_;
/*      */       }
/*      */ 
/* 3383 */       if (that.uninterpreted != null) {
/* 3384 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3386 */       this.optional_0_ = this_t0;
/* 3387 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesCanvas that) {
/* 3391 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesCanvas that) {
/* 3395 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesCanvas that, boolean ignoreUninterpreted) {
/* 3399 */       if (that == null) return false;
/* 3400 */       if (that == this) return true;
/* 3401 */       int this_t0 = this.optional_0_;
/* 3402 */       int that_t0 = that.optional_0_;
/* 3403 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 3405 */       if (((this_t0 & 0x1) != 0) && 
/* 3406 */         (this.width_ != that.width_)) return false;
/*      */ 
/* 3409 */       if (((this_t0 & 0x2) != 0) && 
/* 3410 */         (this.height_ != that.height_)) return false;
/*      */ 
/* 3413 */       if (((this_t0 & 0x4) != 0) && 
/* 3414 */         (!this.output_.equals(that.output_, ignoreUninterpreted))) return false;
/*      */ 
/* 3417 */       if (((this_t0 & 0x8) != 0) && 
/* 3418 */         (this.color_ != that.color_)) return false;
/*      */ 
/* 3421 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3426 */       return ((that instanceof ImagesCanvas)) && (equals((ImagesCanvas)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3430 */       int hash = -1508660133;
/*      */ 
/* 3432 */       int this_t0 = this.optional_0_;
/* 3433 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.width_ : -113);
/*      */ 
/* 3435 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.height_ : -113);
/*      */ 
/* 3437 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.output_.hashCode() : -113);
/*      */ 
/* 3439 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.color_ : -113);
/* 3440 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3441 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3443 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3447 */       int this_t0 = this.optional_0_;
/* 3448 */       if ((this_t0 & 0x7) != 7) {
/* 3449 */         if ((this_t0 & 0x1) == 0) {
/* 3450 */           return false;
/*      */         }
/*      */ 
/* 3453 */         return (this_t0 & 0x2) != 0;
/*      */       }
/*      */ 
/* 3459 */       return this.output_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3468 */       int n = 3 + Protocol.varLongSize(this.width_) + Protocol.varLongSize(this.height_) + Protocol.stringSize(this.output_.encodingSize());
/*      */ 
/* 3470 */       int this_t0 = this.optional_0_;
/* 3471 */       if ((this_t0 & 0x8) != 0)
/*      */       {
/* 3473 */         n += 1 + Protocol.varLongSize(this.color_);
/*      */       }
/*      */ 
/* 3476 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3485 */       int n = 39 + this.output_.maxEncodingSize();
/*      */ 
/* 3487 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3492 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3496 */       this.optional_0_ = 0;
/* 3497 */       this.width_ = 0;
/* 3498 */       this.height_ = 0;
/* 3499 */       this.output_.clear();
/* 3500 */       this.color_ = -1;
/* 3501 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesCanvas newInstance() {
/* 3505 */       return new ImagesCanvas();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3509 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3540 */       sink.putByte(8);
/* 3541 */       sink.putVarLong(this.width_);
/*      */ 
/* 3543 */       sink.putByte(16);
/* 3544 */       sink.putVarLong(this.height_);
/*      */ 
/* 3546 */       sink.putByte(26);
/* 3547 */       sink.putForeign(this.output_);
/*      */ 
/* 3549 */       int this_t0 = this.optional_0_;
/* 3550 */       if ((this_t0 & 0x8) != 0) {
/* 3551 */         sink.putByte(32);
/* 3552 */         sink.putVarLong(this.color_);
/*      */       }
/*      */ 
/* 3555 */       if (this.uninterpreted != null)
/* 3556 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3561 */       boolean result = true;
/* 3562 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3564 */       while (source.hasRemaining()) {
/* 3565 */         int tt = source.getVarInt();
/* 3566 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3570 */           result = false;
/* 3571 */           break;
/*      */         case 8:
/* 3574 */           this.width_ = source.getVarInt();
/* 3575 */           this_t0 |= 1;
/* 3576 */           break;
/*      */         case 16:
/* 3579 */           this.height_ = source.getVarInt();
/* 3580 */           this_t0 |= 2;
/* 3581 */           break;
/*      */         case 26:
/* 3584 */           source.push(source.getVarInt());
/* 3585 */           if (!this.output_.merge(source)) { result = false; break label181; }
/* 3586 */           source.pop();
/* 3587 */           this_t0 |= 4;
/* 3588 */           break;
/*      */         case 32:
/* 3591 */           this.color_ = source.getVarInt();
/* 3592 */           this_t0 |= 8;
/* 3593 */           break;
/*      */         default:
/* 3595 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3600 */       label181: this.optional_0_ = this_t0;
/* 3601 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesCanvas getDefaultInstanceForType()
/*      */     {
/* 3606 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesCanvas getDefaultInstance() {
/* 3610 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesCanvas freeze()
/*      */     {
/* 3680 */       this.output_.freeze();
/* 3681 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesCanvas unfreeze() {
/* 3685 */       this.output_.unfreeze();
/* 3686 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 3690 */       return this.output_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 3693 */       if (this.uninterpreted == null) {
/* 3694 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3696 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3614 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesCanvas()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesCanvas clearWidth()
/*      */         {
/* 3622 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas setWidth(int x) {
/* 3625 */           ProtocolSupport.unsupportedOperation();
/* 3626 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCanvas clearHeight()
/*      */         {
/* 3631 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas setHeight(int x) {
/* 3634 */           ProtocolSupport.unsupportedOperation();
/* 3635 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCanvas clearOutput()
/*      */         {
/* 3640 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas setOutput(ImagesServicePb.OutputSettings x) {
/* 3643 */           ProtocolSupport.unsupportedOperation();
/* 3644 */           return this;
/*      */         }
/*      */         public ImagesServicePb.OutputSettings getMutableOutput() {
/* 3647 */           return (ImagesServicePb.OutputSettings)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCanvas clearColor()
/*      */         {
/* 3652 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas setColor(int x) {
/* 3655 */           ProtocolSupport.unsupportedOperation();
/* 3656 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesCanvas mergeFrom(ImagesServicePb.ImagesCanvas that) {
/* 3660 */           ProtocolSupport.unsupportedOperation();
/* 3661 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3664 */           ProtocolSupport.unsupportedOperation();
/* 3665 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas freeze() {
/* 3668 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesCanvas unfreeze() {
/* 3671 */           ProtocolSupport.unsupportedOperation();
/* 3672 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3675 */           return true;
/*      */         }
/*      */       };
/* 3704 */       text = new String[5];
/*      */ 
/* 3706 */       text[0] = "ErrorCode";
/* 3707 */       text[1] = "width";
/* 3708 */       text[2] = "height";
/* 3709 */       text[3] = "output";
/* 3710 */       text[4] = "color";
/*      */ 
/* 3713 */       types = new int[5];
/*      */ 
/* 3715 */       Arrays.fill(types, 6);
/* 3716 */       types[0] = 0;
/* 3717 */       types[1] = 0;
/* 3718 */       types[2] = 0;
/* 3719 */       types[3] = 2;
/* 3720 */       types[4] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3513 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesCanvas.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("width", "width", 1, 0, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("height", "height", 2, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("output", "output", 3, 2, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.OutputSettings.class), new ProtocolType.FieldType("color", "color", 4, 3, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CompositeImageOptions extends ProtocolMessage<CompositeImageOptions>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2725 */     private int source_index_ = 0;
/* 2726 */     private int x_offset_ = 0;
/* 2727 */     private int y_offset_ = 0;
/* 2728 */     private float opacity_ = 0.0F;
/* 2729 */     private int anchor_ = 0;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CompositeImageOptions IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int ksource_index = 1;
/*      */     public static final int kx_offset = 2;
/*      */     public static final int ky_offset = 3;
/*      */     public static final int kopacity = 4;
/*      */     public static final int kanchor = 5;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int getSourceIndex()
/*      */     {
/* 2770 */       return this.source_index_;
/*      */     }
/*      */     public final boolean hasSourceIndex() {
/* 2773 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CompositeImageOptions clearSourceIndex() {
/* 2776 */       this.optional_0_ &= -2;
/* 2777 */       this.source_index_ = 0;
/* 2778 */       return this;
/*      */     }
/*      */     public CompositeImageOptions setSourceIndex(int x) {
/* 2781 */       this.optional_0_ |= 1;
/* 2782 */       this.source_index_ = x;
/* 2783 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getXOffset()
/*      */     {
/* 2788 */       return this.x_offset_;
/*      */     }
/*      */     public final boolean hasXOffset() {
/* 2791 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public CompositeImageOptions clearXOffset() {
/* 2794 */       this.optional_0_ &= -3;
/* 2795 */       this.x_offset_ = 0;
/* 2796 */       return this;
/*      */     }
/*      */     public CompositeImageOptions setXOffset(int x) {
/* 2799 */       this.optional_0_ |= 2;
/* 2800 */       this.x_offset_ = x;
/* 2801 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getYOffset()
/*      */     {
/* 2806 */       return this.y_offset_;
/*      */     }
/*      */     public final boolean hasYOffset() {
/* 2809 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public CompositeImageOptions clearYOffset() {
/* 2812 */       this.optional_0_ &= -5;
/* 2813 */       this.y_offset_ = 0;
/* 2814 */       return this;
/*      */     }
/*      */     public CompositeImageOptions setYOffset(int x) {
/* 2817 */       this.optional_0_ |= 4;
/* 2818 */       this.y_offset_ = x;
/* 2819 */       return this;
/*      */     }
/*      */ 
/*      */     public final float getOpacity()
/*      */     {
/* 2824 */       return this.opacity_;
/*      */     }
/*      */     public final boolean hasOpacity() {
/* 2827 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public CompositeImageOptions clearOpacity() {
/* 2830 */       this.optional_0_ &= -9;
/* 2831 */       this.opacity_ = 0.0F;
/* 2832 */       return this;
/*      */     }
/*      */     public CompositeImageOptions setOpacity(float x) {
/* 2835 */       this.optional_0_ |= 8;
/* 2836 */       this.opacity_ = x;
/* 2837 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getAnchor()
/*      */     {
/* 2842 */       return this.anchor_;
/*      */     }
/*      */     public ANCHOR getAnchorEnum() {
/* 2845 */       return hasAnchor() ? ANCHOR.valueOf(getAnchor()) : null;
/*      */     }
/*      */     public final boolean hasAnchor() {
/* 2848 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public CompositeImageOptions clearAnchor() {
/* 2851 */       this.optional_0_ &= -17;
/* 2852 */       this.anchor_ = 0;
/* 2853 */       return this;
/*      */     }
/*      */     public CompositeImageOptions setAnchor(int x) {
/* 2856 */       this.optional_0_ |= 16;
/* 2857 */       this.anchor_ = x;
/* 2858 */       return this;
/*      */     }
/*      */     public CompositeImageOptions setAnchor(ANCHOR x) {
/* 2861 */       if (x == null) {
/* 2862 */         this.optional_0_ &= -17;
/* 2863 */         this.anchor_ = 0;
/*      */       } else {
/* 2865 */         setAnchor(x.getValue());
/*      */       }
/* 2867 */       return this;
/*      */     }
/*      */ 
/*      */     public CompositeImageOptions mergeFrom(CompositeImageOptions that)
/*      */     {
/* 2874 */       assert (that != this);
/* 2875 */       int this_t0 = this.optional_0_;
/* 2876 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2878 */       if ((that_t0 & 0x1) != 0) {
/* 2879 */         this_t0 |= 1;
/* 2880 */         this.source_index_ = that.source_index_;
/*      */       }
/*      */ 
/* 2883 */       if ((that_t0 & 0x2) != 0) {
/* 2884 */         this_t0 |= 2;
/* 2885 */         this.x_offset_ = that.x_offset_;
/*      */       }
/*      */ 
/* 2888 */       if ((that_t0 & 0x4) != 0) {
/* 2889 */         this_t0 |= 4;
/* 2890 */         this.y_offset_ = that.y_offset_;
/*      */       }
/*      */ 
/* 2893 */       if ((that_t0 & 0x8) != 0) {
/* 2894 */         this_t0 |= 8;
/* 2895 */         this.opacity_ = that.opacity_;
/*      */       }
/*      */ 
/* 2898 */       if ((that_t0 & 0x10) != 0) {
/* 2899 */         this_t0 |= 16;
/* 2900 */         this.anchor_ = that.anchor_;
/*      */       }
/*      */ 
/* 2903 */       if (that.uninterpreted != null) {
/* 2904 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2906 */       this.optional_0_ = this_t0;
/* 2907 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CompositeImageOptions that) {
/* 2911 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CompositeImageOptions that) {
/* 2915 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CompositeImageOptions that, boolean ignoreUninterpreted) {
/* 2919 */       if (that == null) return false;
/* 2920 */       if (that == this) return true;
/* 2921 */       int this_t0 = this.optional_0_;
/* 2922 */       int that_t0 = that.optional_0_;
/* 2923 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2925 */       if (((this_t0 & 0x1) != 0) && 
/* 2926 */         (this.source_index_ != that.source_index_)) return false;
/*      */ 
/* 2929 */       if (((this_t0 & 0x2) != 0) && 
/* 2930 */         (this.x_offset_ != that.x_offset_)) return false;
/*      */ 
/* 2933 */       if (((this_t0 & 0x4) != 0) && 
/* 2934 */         (this.y_offset_ != that.y_offset_)) return false;
/*      */ 
/* 2937 */       if (((this_t0 & 0x8) != 0) && 
/* 2938 */         (this.opacity_ != that.opacity_)) return false;
/*      */ 
/* 2941 */       if (((this_t0 & 0x10) != 0) && 
/* 2942 */         (this.anchor_ != that.anchor_)) return false;
/*      */ 
/* 2945 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2950 */       return ((that instanceof CompositeImageOptions)) && (equals((CompositeImageOptions)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2954 */       int hash = -2023561429;
/*      */ 
/* 2956 */       int this_t0 = this.optional_0_;
/* 2957 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.source_index_ : -113);
/*      */ 
/* 2959 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.x_offset_ : -113);
/*      */ 
/* 2961 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.y_offset_ : -113);
/*      */ 
/* 2963 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Float.floatToIntBits(this.opacity_) : -113);
/*      */ 
/* 2965 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? this.anchor_ : -113);
/* 2966 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2967 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2969 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2973 */       int this_t0 = this.optional_0_;
/* 2974 */       if ((this_t0 & 0x1F) != 31) {
/* 2975 */         if ((this_t0 & 0x1) == 0) {
/* 2976 */           return false;
/*      */         }
/* 2978 */         if ((this_t0 & 0x2) == 0) {
/* 2979 */           return false;
/*      */         }
/* 2981 */         if ((this_t0 & 0x4) == 0) {
/* 2982 */           return false;
/*      */         }
/*      */ 
/* 2985 */         return (this_t0 & 0x8) != 0;
/*      */       }
/*      */ 
/* 2989 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2998 */       int n = 9 + Protocol.varLongSize(this.source_index_) + Protocol.varLongSize(this.x_offset_) + Protocol.varLongSize(this.y_offset_) + Protocol.varLongSize(this.anchor_);
/*      */ 
/* 3002 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3012 */       int n = 49;
/*      */ 
/* 3014 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3019 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3023 */       this.optional_0_ = 0;
/* 3024 */       this.source_index_ = 0;
/* 3025 */       this.x_offset_ = 0;
/* 3026 */       this.y_offset_ = 0;
/* 3027 */       this.opacity_ = 0.0F;
/* 3028 */       this.anchor_ = 0;
/* 3029 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CompositeImageOptions newInstance() {
/* 3033 */       return new CompositeImageOptions();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3037 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3080 */       sink.putByte(8);
/* 3081 */       sink.putVarLong(this.source_index_);
/*      */ 
/* 3083 */       sink.putByte(16);
/* 3084 */       sink.putVarLong(this.x_offset_);
/*      */ 
/* 3086 */       sink.putByte(24);
/* 3087 */       sink.putVarLong(this.y_offset_);
/*      */ 
/* 3089 */       sink.putByte(37);
/* 3090 */       sink.putFloat(this.opacity_);
/*      */ 
/* 3092 */       sink.putByte(40);
/* 3093 */       sink.putVarLong(this.anchor_);
/*      */ 
/* 3095 */       if (this.uninterpreted != null)
/* 3096 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3101 */       boolean result = true;
/* 3102 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3104 */       while (source.hasRemaining()) {
/* 3105 */         int tt = source.getVarInt();
/* 3106 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3110 */           result = false;
/* 3111 */           break;
/*      */         case 8:
/* 3114 */           this.source_index_ = source.getVarInt();
/* 3115 */           this_t0 |= 1;
/* 3116 */           break;
/*      */         case 16:
/* 3119 */           this.x_offset_ = source.getVarInt();
/* 3120 */           this_t0 |= 2;
/* 3121 */           break;
/*      */         case 24:
/* 3124 */           this.y_offset_ = source.getVarInt();
/* 3125 */           this_t0 |= 4;
/* 3126 */           break;
/*      */         case 37:
/* 3129 */           this.opacity_ = source.getFloat();
/* 3130 */           this_t0 |= 8;
/* 3131 */           break;
/*      */         case 40:
/* 3134 */           this.anchor_ = source.getVarInt();
/* 3135 */           this_t0 |= 16;
/* 3136 */           break;
/*      */         default:
/* 3138 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3143 */       this.optional_0_ = this_t0;
/* 3144 */       return result;
/*      */     }
/*      */ 
/*      */     public CompositeImageOptions getDefaultInstanceForType()
/*      */     {
/* 3149 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CompositeImageOptions getDefaultInstance() {
/* 3153 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 3228 */       if (this.uninterpreted == null) {
/* 3229 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3231 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3157 */       IMMUTABLE_DEFAULT_INSTANCE = new CompositeImageOptions()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.CompositeImageOptions clearSourceIndex()
/*      */         {
/* 3165 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions setSourceIndex(int x) {
/* 3168 */           ProtocolSupport.unsupportedOperation();
/* 3169 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.CompositeImageOptions clearXOffset()
/*      */         {
/* 3174 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions setXOffset(int x) {
/* 3177 */           ProtocolSupport.unsupportedOperation();
/* 3178 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.CompositeImageOptions clearYOffset()
/*      */         {
/* 3183 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions setYOffset(int x) {
/* 3186 */           ProtocolSupport.unsupportedOperation();
/* 3187 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.CompositeImageOptions clearOpacity()
/*      */         {
/* 3192 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions setOpacity(float x) {
/* 3195 */           ProtocolSupport.unsupportedOperation();
/* 3196 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.CompositeImageOptions clearAnchor()
/*      */         {
/* 3201 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions setAnchor(int x) {
/* 3204 */           ProtocolSupport.unsupportedOperation();
/* 3205 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.CompositeImageOptions mergeFrom(ImagesServicePb.CompositeImageOptions that) {
/* 3209 */           ProtocolSupport.unsupportedOperation();
/* 3210 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3213 */           ProtocolSupport.unsupportedOperation();
/* 3214 */           return false;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions freeze() {
/* 3217 */           return this;
/*      */         }
/*      */         public ImagesServicePb.CompositeImageOptions unfreeze() {
/* 3220 */           ProtocolSupport.unsupportedOperation();
/* 3221 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3224 */           return true;
/*      */         }
/*      */       };
/* 3240 */       text = new String[6];
/*      */ 
/* 3242 */       text[0] = "ErrorCode";
/* 3243 */       text[1] = "source_index";
/* 3244 */       text[2] = "x_offset";
/* 3245 */       text[3] = "y_offset";
/* 3246 */       text[4] = "opacity";
/* 3247 */       text[5] = "anchor";
/*      */ 
/* 3250 */       types = new int[6];
/*      */ 
/* 3252 */       Arrays.fill(types, 6);
/* 3253 */       types[0] = 0;
/* 3254 */       types[1] = 0;
/* 3255 */       types[2] = 0;
/* 3256 */       types[3] = 0;
/* 3257 */       types[4] = 5;
/* 3258 */       types[5] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3041 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.CompositeImageOptions.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("source_index", "source_index", 1, 0, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("x_offset", "x_offset", 2, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("y_offset", "y_offset", 3, 2, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("opacity", "opacity", 4, 3, ProtocolType.FieldBaseType.FLOAT, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("anchor", "anchor", 5, 4, ProtocolType.Presence.REQUIRED, ImagesServicePb.CompositeImageOptions.ANCHOR.class) });
/*      */     }
/*      */ 
/*      */     public static enum ANCHOR
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 2734 */       TOP_LEFT(0), 
/* 2735 */       TOP(1), 
/* 2736 */       TOP_RIGHT(2), 
/* 2737 */       LEFT(3), 
/* 2738 */       CENTER(4), 
/* 2739 */       RIGHT(5), 
/* 2740 */       BOTTOM_LEFT(6), 
/* 2741 */       BOTTOM(7), 
/* 2742 */       BOTTOM_RIGHT(8);
/*      */ 
/*      */       public static final ANCHOR ANCHOR_MIN;
/*      */       public static final ANCHOR ANCHOR_MAX;
/*      */       private final int value;
/*      */ 
/* 2747 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ANCHOR valueOf(int value) {
/* 2750 */         switch (value) { case 0:
/* 2751 */           return TOP_LEFT;
/*      */         case 1:
/* 2752 */           return TOP;
/*      */         case 2:
/* 2753 */           return TOP_RIGHT;
/*      */         case 3:
/* 2754 */           return LEFT;
/*      */         case 4:
/* 2755 */           return CENTER;
/*      */         case 5:
/* 2756 */           return RIGHT;
/*      */         case 6:
/* 2757 */           return BOTTOM_LEFT;
/*      */         case 7:
/* 2758 */           return BOTTOM;
/*      */         case 8:
/* 2759 */           return BOTTOM_RIGHT;
/*      */         }
/* 2761 */         return null;
/*      */       }
/*      */ 
/*      */       private ANCHOR(int v) {
/* 2765 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 2744 */         ANCHOR_MIN = TOP_LEFT;
/* 2745 */         ANCHOR_MAX = BOTTOM_RIGHT;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesTransformResponse extends ProtocolMessage<ImagesTransformResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2447 */     private ImagesServicePb.ImageData image_ = new ImagesServicePb.ImageData();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesTransformResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kimage = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final ImagesServicePb.ImageData getImage()
/*      */     {
/* 2453 */       return this.image_;
/*      */     }
/*      */     public final boolean hasImage() {
/* 2456 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesTransformResponse clearImage() {
/* 2459 */       this.optional_0_ &= -2;
/* 2460 */       this.image_.clear();
/* 2461 */       return this;
/*      */     }
/*      */     public ImagesTransformResponse setImage(ImagesServicePb.ImageData x) {
/* 2464 */       if (x == null) throw new NullPointerException();
/* 2465 */       this.optional_0_ |= 1;
/* 2466 */       this.image_ = x;
/* 2467 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImageData getMutableImage() {
/* 2470 */       this.optional_0_ |= 1;
/* 2471 */       return this.image_;
/*      */     }
/*      */ 
/*      */     public ImagesTransformResponse mergeFrom(ImagesTransformResponse that)
/*      */     {
/* 2478 */       assert (that != this);
/* 2479 */       int this_t0 = this.optional_0_;
/* 2480 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2482 */       if ((that_t0 & 0x1) != 0) {
/* 2483 */         this_t0 |= 1;
/* 2484 */         ImagesServicePb.ImageData v = this.image_;
/* 2485 */         v.mergeFrom(that.image_);
/*      */       }
/*      */ 
/* 2488 */       if (that.uninterpreted != null) {
/* 2489 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2491 */       this.optional_0_ = this_t0;
/* 2492 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesTransformResponse that) {
/* 2496 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesTransformResponse that) {
/* 2500 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesTransformResponse that, boolean ignoreUninterpreted) {
/* 2504 */       if (that == null) return false;
/* 2505 */       if (that == this) return true;
/* 2506 */       int this_t0 = this.optional_0_;
/* 2507 */       int that_t0 = that.optional_0_;
/* 2508 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2510 */       if (((this_t0 & 0x1) != 0) && 
/* 2511 */         (!this.image_.equals(that.image_, ignoreUninterpreted))) return false;
/*      */ 
/* 2514 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2519 */       return ((that instanceof ImagesTransformResponse)) && (equals((ImagesTransformResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2523 */       int hash = -504859902;
/*      */ 
/* 2525 */       int this_t0 = this.optional_0_;
/* 2526 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.image_.hashCode() : -113);
/* 2527 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2528 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2530 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2534 */       int this_t0 = this.optional_0_;
/* 2535 */       if ((this_t0 & 0x1) != 1) {
/* 2536 */         return false;
/*      */       }
/*      */ 
/* 2540 */       return this.image_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2547 */       int n = 1 + Protocol.stringSize(this.image_.encodingSize());
/*      */ 
/* 2549 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2555 */       int n = 6 + this.image_.maxEncodingSize();
/*      */ 
/* 2557 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2562 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2566 */       this.optional_0_ = 0;
/* 2567 */       this.image_.clear();
/* 2568 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesTransformResponse newInstance() {
/* 2572 */       return new ImagesTransformResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2576 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2596 */       sink.putByte(10);
/* 2597 */       sink.putForeign(this.image_);
/*      */ 
/* 2599 */       if (this.uninterpreted != null)
/* 2600 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2605 */       boolean result = true;
/* 2606 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2608 */       while (source.hasRemaining()) {
/* 2609 */         int tt = source.getVarInt();
/* 2610 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2614 */           result = false;
/* 2615 */           break;
/*      */         case 10:
/* 2618 */           source.push(source.getVarInt());
/* 2619 */           if (!this.image_.merge(source)) { result = false; break label111; }
/* 2620 */           source.pop();
/* 2621 */           this_t0 |= 1;
/* 2622 */           break;
/*      */         default:
/* 2624 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2629 */       label111: this.optional_0_ = this_t0;
/* 2630 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesTransformResponse getDefaultInstanceForType()
/*      */     {
/* 2635 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesTransformResponse getDefaultInstance() {
/* 2639 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesTransformResponse freeze()
/*      */     {
/* 2682 */       this.image_.freeze();
/* 2683 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesTransformResponse unfreeze() {
/* 2687 */       this.image_.unfreeze();
/* 2688 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 2692 */       return this.image_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 2695 */       if (this.uninterpreted == null) {
/* 2696 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2698 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2643 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesTransformResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesTransformResponse clearImage()
/*      */         {
/* 2651 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformResponse setImage(ImagesServicePb.ImageData x) {
/* 2654 */           ProtocolSupport.unsupportedOperation();
/* 2655 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData getMutableImage() {
/* 2658 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesTransformResponse mergeFrom(ImagesServicePb.ImagesTransformResponse that) {
/* 2662 */           ProtocolSupport.unsupportedOperation();
/* 2663 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2666 */           ProtocolSupport.unsupportedOperation();
/* 2667 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformResponse freeze() {
/* 2670 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformResponse unfreeze() {
/* 2673 */           ProtocolSupport.unsupportedOperation();
/* 2674 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2677 */           return true;
/*      */         }
/*      */       };
/* 2703 */       text = new String[2];
/*      */ 
/* 2705 */       text[0] = "ErrorCode";
/* 2706 */       text[1] = "image";
/*      */ 
/* 2709 */       types = new int[2];
/*      */ 
/* 2711 */       Arrays.fill(types, 6);
/* 2712 */       types[0] = 0;
/* 2713 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2580 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesTransformResponse.class, "Z*apphosting/api/images/images_service.proto\n\"apphosting.ImagesTransformResponse\023\032\005image \001(\0020\0138\002J\024apphosting.ImageData\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("image", "image", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.ImageData.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesTransformRequest extends ProtocolMessage<ImagesTransformRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1958 */     private ImagesServicePb.ImageData image_ = new ImagesServicePb.ImageData();
/* 1959 */     private List<ImagesServicePb.Transform> transform_ = null;
/* 1960 */     private ImagesServicePb.OutputSettings output_ = new ImagesServicePb.OutputSettings();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImagesTransformRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kimage = 1;
/*      */     public static final int ktransform = 2;
/*      */     public static final int koutput = 3;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final ImagesServicePb.ImageData getImage()
/*      */     {
/* 1966 */       return this.image_;
/*      */     }
/*      */     public final boolean hasImage() {
/* 1969 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImagesTransformRequest clearImage() {
/* 1972 */       this.optional_0_ &= -2;
/* 1973 */       this.image_.clear();
/* 1974 */       return this;
/*      */     }
/*      */     public ImagesTransformRequest setImage(ImagesServicePb.ImageData x) {
/* 1977 */       if (x == null) throw new NullPointerException();
/* 1978 */       this.optional_0_ |= 1;
/* 1979 */       this.image_ = x;
/* 1980 */       return this;
/*      */     }
/*      */     public ImagesServicePb.ImageData getMutableImage() {
/* 1983 */       this.optional_0_ |= 1;
/* 1984 */       return this.image_;
/*      */     }
/*      */ 
/*      */     public final int transformSize()
/*      */     {
/* 1989 */       return this.transform_ != null ? this.transform_.size() : 0;
/*      */     }
/*      */     public final ImagesServicePb.Transform getTransform(int i) {
/* 1992 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.transform_ != null ? this.transform_.size() : 0)); } else throw new AssertionError();
/* 1993 */       return (ImagesServicePb.Transform)this.transform_.get(i);
/*      */     }
/*      */     public ImagesTransformRequest clearTransform() {
/* 1996 */       if (this.transform_ != null) this.transform_.clear();
/* 1997 */       return this;
/*      */     }
/*      */     public ImagesServicePb.Transform getMutableTransform(int i) {
/* 2000 */       assert ((i >= 0) && (this.transform_ != null) && (i < this.transform_.size()));
/* 2001 */       return (ImagesServicePb.Transform)this.transform_.get(i);
/*      */     }
/*      */     public ImagesServicePb.Transform addTransform() {
/* 2004 */       ImagesServicePb.Transform v = new ImagesServicePb.Transform();
/* 2005 */       if (this.transform_ == null) this.transform_ = new ArrayList(4);
/* 2006 */       this.transform_.add(v);
/* 2007 */       return v;
/*      */     }
/*      */     public ImagesServicePb.Transform addTransform(ImagesServicePb.Transform v) {
/* 2010 */       if (this.transform_ == null) this.transform_ = new ArrayList(4);
/* 2011 */       this.transform_.add(v);
/* 2012 */       return v;
/*      */     }
/*      */     public ImagesServicePb.Transform insertTransform(int i, ImagesServicePb.Transform v) {
/* 2015 */       if (this.transform_ == null) this.transform_ = new ArrayList(4);
/* 2016 */       this.transform_.add(i, v);
/* 2017 */       return v;
/*      */     }
/*      */     public ImagesServicePb.Transform removeTransform(int i) {
/* 2020 */       return (ImagesServicePb.Transform)this.transform_.remove(i);
/*      */     }
/*      */     public final Iterator<ImagesServicePb.Transform> transformIterator() {
/* 2023 */       if (this.transform_ == null) {
/* 2024 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 2026 */       return this.transform_.iterator();
/*      */     }
/*      */     public final List<ImagesServicePb.Transform> transforms() {
/* 2029 */       return ProtocolSupport.unmodifiableList(this.transform_);
/*      */     }
/*      */     public final List<ImagesServicePb.Transform> mutableTransforms() {
/* 2032 */       if (this.transform_ == null) this.transform_ = new ArrayList(4);
/* 2033 */       return this.transform_;
/*      */     }
/*      */ 
/*      */     public final ImagesServicePb.OutputSettings getOutput()
/*      */     {
/* 2038 */       return this.output_;
/*      */     }
/*      */     public final boolean hasOutput() {
/* 2041 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public ImagesTransformRequest clearOutput() {
/* 2044 */       this.optional_0_ &= -3;
/* 2045 */       this.output_.clear();
/* 2046 */       return this;
/*      */     }
/*      */     public ImagesTransformRequest setOutput(ImagesServicePb.OutputSettings x) {
/* 2049 */       if (x == null) throw new NullPointerException();
/* 2050 */       this.optional_0_ |= 2;
/* 2051 */       this.output_ = x;
/* 2052 */       return this;
/*      */     }
/*      */     public ImagesServicePb.OutputSettings getMutableOutput() {
/* 2055 */       this.optional_0_ |= 2;
/* 2056 */       return this.output_;
/*      */     }
/*      */ 
/*      */     public ImagesTransformRequest mergeFrom(ImagesTransformRequest that)
/*      */     {
/* 2063 */       assert (that != this);
/* 2064 */       int this_t0 = this.optional_0_;
/* 2065 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2067 */       if ((that_t0 & 0x1) != 0) {
/* 2068 */         this_t0 |= 1;
/* 2069 */         ImagesServicePb.ImageData v = this.image_;
/* 2070 */         v.mergeFrom(that.image_);
/*      */       }
/*      */ 
/* 2073 */       if (that.transform_ != null) {
/* 2074 */         for (ImagesServicePb.Transform v : that.transform_) {
/* 2075 */           addTransform().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 2079 */       if ((that_t0 & 0x2) != 0) {
/* 2080 */         this_t0 |= 2;
/* 2081 */         ImagesServicePb.OutputSettings v = this.output_;
/* 2082 */         v.mergeFrom(that.output_);
/*      */       }
/*      */ 
/* 2085 */       if (that.uninterpreted != null) {
/* 2086 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2088 */       this.optional_0_ = this_t0;
/* 2089 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesTransformRequest that) {
/* 2093 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesTransformRequest that) {
/* 2097 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesTransformRequest that, boolean ignoreUninterpreted) {
/* 2101 */       if (that == null) return false;
/* 2102 */       if (that == this) return true;
/* 2103 */       int this_t0 = this.optional_0_;
/* 2104 */       int that_t0 = that.optional_0_;
/* 2105 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2107 */       if (((this_t0 & 0x1) != 0) && 
/* 2108 */         (!this.image_.equals(that.image_, ignoreUninterpreted))) return false;
/* 2112 */       int n;
/* 2112 */       if ((n = this.transform_ != null ? this.transform_.size() : 0) != (that.transform_ != null ? that.transform_.size() : 0)) return false;
/* 2113 */       for (int i = 0; i < n; i++) {
/* 2114 */         if (!((ImagesServicePb.Transform)this.transform_.get(i)).equals((ImagesServicePb.Transform)that.transform_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 2117 */       if (((this_t0 & 0x2) != 0) && 
/* 2118 */         (!this.output_.equals(that.output_, ignoreUninterpreted))) return false;
/*      */ 
/* 2121 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2126 */       return ((that instanceof ImagesTransformRequest)) && (equals((ImagesTransformRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2130 */       int hash = 658349399;
/*      */ 
/* 2132 */       int this_t0 = this.optional_0_;
/* 2133 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.image_.hashCode() : -113);
/*      */ 
/* 2135 */       hash *= 31;
/* 2136 */       int i = 0; for (int n = this.transform_ != null ? this.transform_.size() : 0; i < n; i++) {
/* 2137 */         hash = hash * 31 + ((ImagesServicePb.Transform)this.transform_.get(i)).hashCode();
/*      */       }
/*      */ 
/* 2140 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.output_.hashCode() : -113);
/* 2141 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2142 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2144 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2148 */       int this_t0 = this.optional_0_;
/* 2149 */       if ((this_t0 & 0x3) != 3)
/*      */       {
/* 2151 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/* 2156 */       if (!this.image_.isInitialized()) {
/* 2157 */         return false;
/*      */       }
/*      */ 
/* 2160 */       if (this.transform_ != null) {
/* 2161 */         for (ImagesServicePb.Transform v : this.transform_) {
/* 2162 */           if (!v.isInitialized()) {
/* 2163 */             return false;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2169 */       return this.output_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2177 */       int n = 2 + Protocol.stringSize(this.image_.encodingSize()) + Protocol.stringSize(this.output_.encodingSize());
/*      */       int m;
/* 2181 */       n += (m = this.transform_ != null ? this.transform_.size() : 0);
/* 2182 */       for (int i = 0; i < m; i++) {
/* 2183 */         n += Protocol.stringSize(((ImagesServicePb.Transform)this.transform_.get(i)).encodingSize());
/*      */       }
/*      */ 
/* 2186 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2193 */       int n = 12 + this.image_.maxEncodingSize() + this.output_.maxEncodingSize();
/*      */       int m;
/* 2196 */       n += 6 * (m = this.transform_ != null ? this.transform_.size() : 0);
/* 2197 */       for (int i = 0; i < m; i++) {
/* 2198 */         n += ((ImagesServicePb.Transform)this.transform_.get(i)).maxEncodingSize();
/*      */       }
/*      */ 
/* 2201 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2206 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2210 */       this.optional_0_ = 0;
/* 2211 */       this.image_.clear();
/* 2212 */       if (this.transform_ != null) this.transform_.clear();
/* 2213 */       this.output_.clear();
/* 2214 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesTransformRequest newInstance() {
/* 2218 */       return new ImagesTransformRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2222 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2252 */       sink.putByte(10);
/* 2253 */       sink.putForeign(this.image_);
/*      */ 
/* 2255 */       int i = 0; for (int m = this.transform_ != null ? this.transform_.size() : 0; i < m; i++) {
/* 2256 */         ImagesServicePb.Transform v = (ImagesServicePb.Transform)this.transform_.get(i);
/* 2257 */         sink.putByte(18);
/* 2258 */         sink.putForeign(v);
/*      */       }
/*      */ 
/* 2261 */       sink.putByte(26);
/* 2262 */       sink.putForeign(this.output_);
/*      */ 
/* 2264 */       if (this.uninterpreted != null)
/* 2265 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2270 */       boolean result = true;
/* 2271 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2273 */       while (source.hasRemaining()) {
/* 2274 */         int tt = source.getVarInt();
/* 2275 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2279 */           result = false;
/* 2280 */           break;
/*      */         case 10:
/* 2283 */           source.push(source.getVarInt());
/* 2284 */           if (!this.image_.merge(source)) { result = false; break label197; }
/* 2285 */           source.pop();
/* 2286 */           this_t0 |= 1;
/* 2287 */           break;
/*      */         case 18:
/* 2290 */           source.push(source.getVarInt());
/* 2291 */           if (!addTransform().merge(source)) { result = false; break label197; }
/* 2292 */           source.pop();
/* 2293 */           break;
/*      */         case 26:
/* 2296 */           source.push(source.getVarInt());
/* 2297 */           if (!this.output_.merge(source)) { result = false; break label197; }
/* 2298 */           source.pop();
/* 2299 */           this_t0 |= 2;
/* 2300 */           break;
/*      */         default:
/* 2302 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2307 */       label197: this.optional_0_ = this_t0;
/* 2308 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesTransformRequest getDefaultInstanceForType()
/*      */     {
/* 2313 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesTransformRequest getDefaultInstance() {
/* 2317 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImagesTransformRequest freeze()
/*      */     {
/* 2392 */       this.image_.freeze();
/* 2393 */       this.transform_ = ProtocolSupport.freezeMessages(this.transform_);
/* 2394 */       this.output_.freeze();
/* 2395 */       return this;
/*      */     }
/*      */ 
/*      */     public ImagesTransformRequest unfreeze() {
/* 2399 */       this.image_.unfreeze();
/* 2400 */       this.transform_ = ProtocolSupport.unfreezeMessages(this.transform_);
/* 2401 */       this.output_.unfreeze();
/* 2402 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 2406 */       return (this.image_.isFrozen()) || (ProtocolSupport.isFrozenMessages(this.transform_)) || (this.output_.isFrozen());
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 2411 */       if (this.uninterpreted == null) {
/* 2412 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2414 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2321 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesTransformRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesTransformRequest clearImage()
/*      */         {
/* 2329 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformRequest setImage(ImagesServicePb.ImageData x) {
/* 2332 */           ProtocolSupport.unsupportedOperation();
/* 2333 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData getMutableImage() {
/* 2336 */           return (ImagesServicePb.ImageData)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesTransformRequest clearTransform()
/*      */         {
/* 2341 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform getMutableTransform(int i) {
/* 2344 */           return (ImagesServicePb.Transform)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.Transform addTransform() {
/* 2347 */           return (ImagesServicePb.Transform)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.Transform addTransform(ImagesServicePb.Transform v) {
/* 2350 */           return (ImagesServicePb.Transform)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.Transform insertTransform(int i, ImagesServicePb.Transform v) {
/* 2353 */           return (ImagesServicePb.Transform)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public ImagesServicePb.Transform removeTransform(int i) {
/* 2356 */           return (ImagesServicePb.Transform)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesTransformRequest clearOutput()
/*      */         {
/* 2361 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformRequest setOutput(ImagesServicePb.OutputSettings x) {
/* 2364 */           ProtocolSupport.unsupportedOperation();
/* 2365 */           return this;
/*      */         }
/*      */         public ImagesServicePb.OutputSettings getMutableOutput() {
/* 2368 */           return (ImagesServicePb.OutputSettings)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImagesTransformRequest mergeFrom(ImagesServicePb.ImagesTransformRequest that) {
/* 2372 */           ProtocolSupport.unsupportedOperation();
/* 2373 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2376 */           ProtocolSupport.unsupportedOperation();
/* 2377 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformRequest freeze() {
/* 2380 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesTransformRequest unfreeze() {
/* 2383 */           ProtocolSupport.unsupportedOperation();
/* 2384 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2387 */           return true;
/*      */         }
/*      */       };
/* 2421 */       text = new String[4];
/*      */ 
/* 2423 */       text[0] = "ErrorCode";
/* 2424 */       text[1] = "image";
/* 2425 */       text[2] = "transform";
/* 2426 */       text[3] = "output";
/*      */ 
/* 2429 */       types = new int[4];
/*      */ 
/* 2431 */       Arrays.fill(types, 6);
/* 2432 */       types[0] = 0;
/* 2433 */       types[1] = 2;
/* 2434 */       types[2] = 2;
/* 2435 */       types[3] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2226 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesTransformRequest.class, "Z*apphosting/api/images/images_service.proto\n!apphosting.ImagesTransformRequest\023\032\005image \001(\0020\0138\002J\024apphosting.ImageData\024\023\032\ttransform \002(\0020\0138\003J\024apphosting.Transform\024\023\032\006output \003(\0020\0138\002J\031apphosting.OutputSettings\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("image", "image", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.ImageData.class), new ProtocolType.FieldType("transform", "transform", 2, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, ImagesServicePb.Transform.class), new ProtocolType.FieldType("output", "output", 3, 1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, ImagesServicePb.OutputSettings.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class OutputSettings extends ProtocolMessage<OutputSettings>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1670 */     private int mime_type_ = 0;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final OutputSettings IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kmime_type = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int getMimeType()
/*      */     {
/* 1697 */       return this.mime_type_;
/*      */     }
/*      */     public MIME_TYPE getMimeTypeEnum() {
/* 1700 */       return MIME_TYPE.valueOf(getMimeType());
/*      */     }
/*      */     public final boolean hasMimeType() {
/* 1703 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public OutputSettings clearMimeType() {
/* 1706 */       this.optional_0_ &= -2;
/* 1707 */       this.mime_type_ = 0;
/* 1708 */       return this;
/*      */     }
/*      */     public OutputSettings setMimeType(int x) {
/* 1711 */       this.optional_0_ |= 1;
/* 1712 */       this.mime_type_ = x;
/* 1713 */       return this;
/*      */     }
/*      */     public OutputSettings setMimeType(MIME_TYPE x) {
/* 1716 */       if (x == null) {
/* 1717 */         this.optional_0_ &= -2;
/* 1718 */         this.mime_type_ = 0;
/*      */       } else {
/* 1720 */         setMimeType(x.getValue());
/*      */       }
/* 1722 */       return this;
/*      */     }
/*      */ 
/*      */     public OutputSettings mergeFrom(OutputSettings that)
/*      */     {
/* 1729 */       assert (that != this);
/* 1730 */       int this_t0 = this.optional_0_;
/* 1731 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1733 */       if ((that_t0 & 0x1) != 0) {
/* 1734 */         this_t0 |= 1;
/* 1735 */         this.mime_type_ = that.mime_type_;
/*      */       }
/*      */ 
/* 1738 */       if (that.uninterpreted != null) {
/* 1739 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1741 */       this.optional_0_ = this_t0;
/* 1742 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(OutputSettings that) {
/* 1746 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(OutputSettings that) {
/* 1750 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(OutputSettings that, boolean ignoreUninterpreted) {
/* 1754 */       if (that == null) return false;
/* 1755 */       if (that == this) return true;
/* 1756 */       int this_t0 = this.optional_0_;
/* 1757 */       int that_t0 = that.optional_0_;
/* 1758 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1760 */       if (((this_t0 & 0x1) != 0) && 
/* 1761 */         (this.mime_type_ != that.mime_type_)) return false;
/*      */ 
/* 1764 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1769 */       return ((that instanceof OutputSettings)) && (equals((OutputSettings)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1773 */       int hash = 1753766563;
/*      */ 
/* 1775 */       int this_t0 = this.optional_0_;
/* 1776 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.mime_type_ : -113);
/* 1777 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1778 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1780 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1784 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 1788 */       int n = 0;
/* 1789 */       int this_t0 = this.optional_0_;
/* 1790 */       if ((this_t0 & 0x1) != 0)
/*      */       {
/* 1792 */         n += 1 + Protocol.varLongSize(this.mime_type_);
/*      */       }
/*      */ 
/* 1795 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1801 */       int n = 11;
/*      */ 
/* 1803 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1808 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1812 */       this.optional_0_ = 0;
/* 1813 */       this.mime_type_ = 0;
/* 1814 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public OutputSettings newInstance() {
/* 1818 */       return new OutputSettings();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1822 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1845 */       int this_t0 = this.optional_0_;
/* 1846 */       if ((this_t0 & 0x1) != 0) {
/* 1847 */         sink.putByte(8);
/* 1848 */         sink.putVarLong(this.mime_type_);
/*      */       }
/*      */ 
/* 1851 */       if (this.uninterpreted != null)
/* 1852 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1857 */       boolean result = true;
/* 1858 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1860 */       while (source.hasRemaining()) {
/* 1861 */         int tt = source.getVarInt();
/* 1862 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1866 */           result = false;
/* 1867 */           break;
/*      */         case 8:
/* 1870 */           this.mime_type_ = source.getVarInt();
/* 1871 */           this_t0 |= 1;
/* 1872 */           break;
/*      */         default:
/* 1874 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1879 */       this.optional_0_ = this_t0;
/* 1880 */       return result;
/*      */     }
/*      */ 
/*      */     public OutputSettings getDefaultInstanceForType()
/*      */     {
/* 1885 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final OutputSettings getDefaultInstance() {
/* 1889 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1928 */       if (this.uninterpreted == null) {
/* 1929 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1931 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1893 */       IMMUTABLE_DEFAULT_INSTANCE = new OutputSettings()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.OutputSettings clearMimeType()
/*      */         {
/* 1901 */           return this;
/*      */         }
/*      */         public ImagesServicePb.OutputSettings setMimeType(int x) {
/* 1904 */           ProtocolSupport.unsupportedOperation();
/* 1905 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.OutputSettings mergeFrom(ImagesServicePb.OutputSettings that) {
/* 1909 */           ProtocolSupport.unsupportedOperation();
/* 1910 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1913 */           ProtocolSupport.unsupportedOperation();
/* 1914 */           return false;
/*      */         }
/*      */         public ImagesServicePb.OutputSettings freeze() {
/* 1917 */           return this;
/*      */         }
/*      */         public ImagesServicePb.OutputSettings unfreeze() {
/* 1920 */           ProtocolSupport.unsupportedOperation();
/* 1921 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1924 */           return true;
/*      */         }
/*      */       };
/* 1936 */       text = new String[2];
/*      */ 
/* 1938 */       text[0] = "ErrorCode";
/* 1939 */       text[1] = "mime_type";
/*      */ 
/* 1942 */       types = new int[2];
/*      */ 
/* 1944 */       Arrays.fill(types, 6);
/* 1945 */       types[0] = 0;
/* 1946 */       types[1] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1826 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.OutputSettings.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("mime_type", "mime_type", 1, 0, ProtocolType.Presence.OPTIONAL, ImagesServicePb.OutputSettings.MIME_TYPE.class) });
/*      */     }
/*      */ 
/*      */     public static enum MIME_TYPE
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 1675 */       PNG(0), 
/* 1676 */       JPEG(1);
/*      */ 
/*      */       public static final MIME_TYPE MIME_TYPE_MIN;
/*      */       public static final MIME_TYPE MIME_TYPE_MAX;
/*      */       private final int value;
/*      */ 
/* 1681 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static MIME_TYPE valueOf(int value) {
/* 1684 */         switch (value) { case 0:
/* 1685 */           return PNG;
/*      */         case 1:
/* 1686 */           return JPEG;
/*      */         }
/* 1688 */         return null;
/*      */       }
/*      */ 
/*      */       private MIME_TYPE(int v) {
/* 1692 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1678 */         MIME_TYPE_MIN = PNG;
/* 1679 */         MIME_TYPE_MAX = JPEG;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImageData extends ProtocolMessage<ImageData>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1298 */     private byte[] content_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1299 */     private byte[] blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final ImageData IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kcontent = 1;
/*      */     public static final int kblob_key = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getContentAsBytes()
/*      */     {
/* 1305 */       return this.content_;
/*      */     }
/*      */     public final boolean hasContent() {
/* 1308 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public ImageData clearContent() {
/* 1311 */       this.optional_0_ &= -2;
/* 1312 */       this.content_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1313 */       return this;
/*      */     }
/*      */     public ImageData setContentAsBytes(byte[] x) {
/* 1316 */       this.optional_0_ |= 1;
/* 1317 */       this.content_ = x;
/* 1318 */       return this;
/*      */     }
/*      */     public final String getContent() {
/* 1321 */       return ProtocolSupport.toStringUtf8(this.content_);
/*      */     }
/*      */     public ImageData setContent(String v) {
/* 1324 */       if (v == null) throw new NullPointerException();
/* 1325 */       this.optional_0_ |= 1;
/* 1326 */       this.content_ = ProtocolSupport.toBytesUtf8(v);
/* 1327 */       return this;
/*      */     }
/*      */     public final String getContent(Charset cs) {
/* 1330 */       return ProtocolSupport.toString(this.content_, cs);
/*      */     }
/*      */     public ImageData setContent(String v, Charset cs) {
/* 1333 */       if (v == null) throw new NullPointerException();
/* 1334 */       this.optional_0_ |= 1;
/* 1335 */       this.content_ = ProtocolSupport.toBytes(v, cs);
/* 1336 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getBlobKeyAsBytes()
/*      */     {
/* 1341 */       return this.blob_key_;
/*      */     }
/*      */     public final boolean hasBlobKey() {
/* 1344 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public ImageData clearBlobKey() {
/* 1347 */       this.optional_0_ &= -3;
/* 1348 */       this.blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1349 */       return this;
/*      */     }
/*      */     public ImageData setBlobKeyAsBytes(byte[] x) {
/* 1352 */       this.optional_0_ |= 2;
/* 1353 */       this.blob_key_ = x;
/* 1354 */       return this;
/*      */     }
/*      */     public final String getBlobKey() {
/* 1357 */       return ProtocolSupport.toStringUtf8(this.blob_key_);
/*      */     }
/*      */     public ImageData setBlobKey(String v) {
/* 1360 */       if (v == null) throw new NullPointerException();
/* 1361 */       this.optional_0_ |= 2;
/* 1362 */       this.blob_key_ = ProtocolSupport.toBytesUtf8(v);
/* 1363 */       return this;
/*      */     }
/*      */     public final String getBlobKey(Charset cs) {
/* 1366 */       return ProtocolSupport.toString(this.blob_key_, cs);
/*      */     }
/*      */     public ImageData setBlobKey(String v, Charset cs) {
/* 1369 */       if (v == null) throw new NullPointerException();
/* 1370 */       this.optional_0_ |= 2;
/* 1371 */       this.blob_key_ = ProtocolSupport.toBytes(v, cs);
/* 1372 */       return this;
/*      */     }
/*      */ 
/*      */     public ImageData mergeFrom(ImageData that)
/*      */     {
/* 1379 */       assert (that != this);
/* 1380 */       int this_t0 = this.optional_0_;
/* 1381 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1383 */       if ((that_t0 & 0x1) != 0) {
/* 1384 */         this_t0 |= 1;
/* 1385 */         this.content_ = that.content_;
/*      */       }
/*      */ 
/* 1388 */       if ((that_t0 & 0x2) != 0) {
/* 1389 */         this_t0 |= 2;
/* 1390 */         this.blob_key_ = that.blob_key_;
/*      */       }
/*      */ 
/* 1393 */       if (that.uninterpreted != null) {
/* 1394 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1396 */       this.optional_0_ = this_t0;
/* 1397 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImageData that) {
/* 1401 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImageData that) {
/* 1405 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImageData that, boolean ignoreUninterpreted) {
/* 1409 */       if (that == null) return false;
/* 1410 */       if (that == this) return true;
/* 1411 */       int this_t0 = this.optional_0_;
/* 1412 */       int that_t0 = that.optional_0_;
/* 1413 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1415 */       if (((this_t0 & 0x1) != 0) && 
/* 1416 */         (!Arrays.equals(this.content_, that.content_))) return false;
/*      */ 
/* 1419 */       if (((this_t0 & 0x2) != 0) && 
/* 1420 */         (!Arrays.equals(this.blob_key_, that.blob_key_))) return false;
/*      */ 
/* 1423 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1428 */       return ((that instanceof ImageData)) && (equals((ImageData)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1432 */       int hash = -837174300;
/*      */ 
/* 1434 */       int this_t0 = this.optional_0_;
/* 1435 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.content_) : -113);
/*      */ 
/* 1437 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.blob_key_) : -113);
/* 1438 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1439 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1441 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1445 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1447 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1454 */       int n = 1 + Protocol.stringSize(this.content_.length);
/* 1455 */       int this_t0 = this.optional_0_;
/* 1456 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 1458 */         n += 1 + Protocol.stringSize(this.blob_key_.length);
/*      */       }
/*      */ 
/* 1461 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1467 */       int n = 6 + this.content_.length;
/* 1468 */       int this_t0 = this.optional_0_;
/* 1469 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 1471 */         n += 6 + this.blob_key_.length;
/*      */       }
/*      */ 
/* 1474 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1479 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1483 */       this.optional_0_ = 0;
/* 1484 */       this.content_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1485 */       this.blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1486 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImageData newInstance() {
/* 1490 */       return new ImageData();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1494 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1515 */       sink.putByte(10);
/* 1516 */       sink.putPrefixedData(this.content_);
/*      */ 
/* 1518 */       int this_t0 = this.optional_0_;
/* 1519 */       if ((this_t0 & 0x2) != 0) {
/* 1520 */         sink.putByte(18);
/* 1521 */         sink.putPrefixedData(this.blob_key_);
/*      */       }
/*      */ 
/* 1524 */       if (this.uninterpreted != null)
/* 1525 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1530 */       boolean result = true;
/* 1531 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1533 */       while (source.hasRemaining()) {
/* 1534 */         int tt = source.getVarInt();
/* 1535 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1539 */           result = false;
/* 1540 */           break;
/*      */         case 10:
/* 1543 */           this.content_ = source.getPrefixedData();
/* 1544 */           this_t0 |= 1;
/* 1545 */           break;
/*      */         case 18:
/* 1548 */           this.blob_key_ = source.getPrefixedData();
/* 1549 */           this_t0 |= 2;
/* 1550 */           break;
/*      */         default:
/* 1552 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1557 */       this.optional_0_ = this_t0;
/* 1558 */       return result;
/*      */     }
/*      */ 
/*      */     public ImageData getDefaultInstanceForType()
/*      */     {
/* 1563 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImageData getDefaultInstance() {
/* 1567 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public ImageData freeze()
/*      */     {
/* 1632 */       this.content_ = ProtocolSupport.freezeString(this.content_);
/* 1633 */       this.blob_key_ = ProtocolSupport.freezeString(this.blob_key_);
/* 1634 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1637 */       if (this.uninterpreted == null) {
/* 1638 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1640 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1571 */       IMMUTABLE_DEFAULT_INSTANCE = new ImageData()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImageData clearContent()
/*      */         {
/* 1579 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData setContentAsBytes(byte[] x) {
/* 1582 */           ProtocolSupport.unsupportedOperation();
/* 1583 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData setContent(String v) {
/* 1586 */           ProtocolSupport.unsupportedOperation();
/* 1587 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData setContent(String v, Charset cs) {
/* 1590 */           ProtocolSupport.unsupportedOperation();
/* 1591 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImageData clearBlobKey()
/*      */         {
/* 1596 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData setBlobKeyAsBytes(byte[] x) {
/* 1599 */           ProtocolSupport.unsupportedOperation();
/* 1600 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData setBlobKey(String v) {
/* 1603 */           ProtocolSupport.unsupportedOperation();
/* 1604 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData setBlobKey(String v, Charset cs) {
/* 1607 */           ProtocolSupport.unsupportedOperation();
/* 1608 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.ImageData mergeFrom(ImagesServicePb.ImageData that) {
/* 1612 */           ProtocolSupport.unsupportedOperation();
/* 1613 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1616 */           ProtocolSupport.unsupportedOperation();
/* 1617 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImageData freeze() {
/* 1620 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImageData unfreeze() {
/* 1623 */           ProtocolSupport.unsupportedOperation();
/* 1624 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1627 */           return true;
/*      */         }
/*      */       };
/* 1646 */       text = new String[3];
/*      */ 
/* 1648 */       text[0] = "ErrorCode";
/* 1649 */       text[1] = "content";
/* 1650 */       text[2] = "blob_key";
/*      */ 
/* 1653 */       types = new int[3];
/*      */ 
/* 1655 */       Arrays.fill(types, 6);
/* 1656 */       types[0] = 0;
/* 1657 */       types[1] = 2;
/* 1658 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1498 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImageData.class, "Z*apphosting/api/images/images_service.proto\n\024apphosting.ImageData\023\032\007content \001(\0020\t8\002\024\023\032\bblob_key \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("content", "content", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("blob_key", "blob_key", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Transform extends ProtocolMessage<Transform>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  477 */     private int width_ = 0;
/*  478 */     private int height_ = 0;
/*  479 */     private int rotate_ = 0;
/*  480 */     private boolean horizontal_flip_ = false;
/*  481 */     private boolean vertical_flip_ = false;
/*  482 */     private float crop_left_x_ = 0.0F;
/*  483 */     private float crop_top_y_ = 0.0F;
/*  484 */     private float crop_right_x_ = 1.0F;
/*  485 */     private float crop_bottom_y_ = 1.0F;
/*  486 */     private boolean autolevels_ = false;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final Transform IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kwidth = 1;
/*      */     public static final int kheight = 2;
/*      */     public static final int krotate = 3;
/*      */     public static final int khorizontal_flip = 4;
/*      */     public static final int kvertical_flip = 5;
/*      */     public static final int kcrop_left_x = 6;
/*      */     public static final int kcrop_top_y = 7;
/*      */     public static final int kcrop_right_x = 8;
/*      */     public static final int kcrop_bottom_y = 9;
/*      */     public static final int kautolevels = 10;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int getWidth()
/*      */     {
/*  492 */       return this.width_;
/*      */     }
/*      */     public final boolean hasWidth() {
/*  495 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public Transform clearWidth() {
/*  498 */       this.optional_0_ &= -2;
/*  499 */       this.width_ = 0;
/*  500 */       return this;
/*      */     }
/*      */     public Transform setWidth(int x) {
/*  503 */       this.optional_0_ |= 1;
/*  504 */       this.width_ = x;
/*  505 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getHeight()
/*      */     {
/*  510 */       return this.height_;
/*      */     }
/*      */     public final boolean hasHeight() {
/*  513 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public Transform clearHeight() {
/*  516 */       this.optional_0_ &= -3;
/*  517 */       this.height_ = 0;
/*  518 */       return this;
/*      */     }
/*      */     public Transform setHeight(int x) {
/*  521 */       this.optional_0_ |= 2;
/*  522 */       this.height_ = x;
/*  523 */       return this;
/*      */     }
/*      */ 
/*      */     public final int getRotate()
/*      */     {
/*  528 */       return this.rotate_;
/*      */     }
/*      */     public final boolean hasRotate() {
/*  531 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public Transform clearRotate() {
/*  534 */       this.optional_0_ &= -5;
/*  535 */       this.rotate_ = 0;
/*  536 */       return this;
/*      */     }
/*      */     public Transform setRotate(int x) {
/*  539 */       this.optional_0_ |= 4;
/*  540 */       this.rotate_ = x;
/*  541 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isHorizontalFlip()
/*      */     {
/*  546 */       return this.horizontal_flip_;
/*      */     }
/*      */     public final boolean hasHorizontalFlip() {
/*  549 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public Transform clearHorizontalFlip() {
/*  552 */       this.optional_0_ &= -9;
/*  553 */       this.horizontal_flip_ = false;
/*  554 */       return this;
/*      */     }
/*      */     public Transform setHorizontalFlip(boolean x) {
/*  557 */       this.optional_0_ |= 8;
/*  558 */       this.horizontal_flip_ = x;
/*  559 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isVerticalFlip()
/*      */     {
/*  564 */       return this.vertical_flip_;
/*      */     }
/*      */     public final boolean hasVerticalFlip() {
/*  567 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public Transform clearVerticalFlip() {
/*  570 */       this.optional_0_ &= -17;
/*  571 */       this.vertical_flip_ = false;
/*  572 */       return this;
/*      */     }
/*      */     public Transform setVerticalFlip(boolean x) {
/*  575 */       this.optional_0_ |= 16;
/*  576 */       this.vertical_flip_ = x;
/*  577 */       return this;
/*      */     }
/*      */ 
/*      */     public final float getCropLeftX()
/*      */     {
/*  582 */       return this.crop_left_x_;
/*      */     }
/*      */     public final boolean hasCropLeftX() {
/*  585 */       return (this.optional_0_ & 0x20) != 0;
/*      */     }
/*      */     public Transform clearCropLeftX() {
/*  588 */       this.optional_0_ &= -33;
/*  589 */       this.crop_left_x_ = 0.0F;
/*  590 */       return this;
/*      */     }
/*      */     public Transform setCropLeftX(float x) {
/*  593 */       this.optional_0_ |= 32;
/*  594 */       this.crop_left_x_ = x;
/*  595 */       return this;
/*      */     }
/*      */ 
/*      */     public final float getCropTopY()
/*      */     {
/*  600 */       return this.crop_top_y_;
/*      */     }
/*      */     public final boolean hasCropTopY() {
/*  603 */       return (this.optional_0_ & 0x40) != 0;
/*      */     }
/*      */     public Transform clearCropTopY() {
/*  606 */       this.optional_0_ &= -65;
/*  607 */       this.crop_top_y_ = 0.0F;
/*  608 */       return this;
/*      */     }
/*      */     public Transform setCropTopY(float x) {
/*  611 */       this.optional_0_ |= 64;
/*  612 */       this.crop_top_y_ = x;
/*  613 */       return this;
/*      */     }
/*      */ 
/*      */     public final float getCropRightX()
/*      */     {
/*  618 */       return this.crop_right_x_;
/*      */     }
/*      */     public final boolean hasCropRightX() {
/*  621 */       return (this.optional_0_ & 0x80) != 0;
/*      */     }
/*      */     public Transform clearCropRightX() {
/*  624 */       this.optional_0_ &= -129;
/*  625 */       this.crop_right_x_ = 1.0F;
/*  626 */       return this;
/*      */     }
/*      */     public Transform setCropRightX(float x) {
/*  629 */       this.optional_0_ |= 128;
/*  630 */       this.crop_right_x_ = x;
/*  631 */       return this;
/*      */     }
/*      */ 
/*      */     public final float getCropBottomY()
/*      */     {
/*  636 */       return this.crop_bottom_y_;
/*      */     }
/*      */     public final boolean hasCropBottomY() {
/*  639 */       return (this.optional_0_ & 0x100) != 0;
/*      */     }
/*      */     public Transform clearCropBottomY() {
/*  642 */       this.optional_0_ &= -257;
/*  643 */       this.crop_bottom_y_ = 1.0F;
/*  644 */       return this;
/*      */     }
/*      */     public Transform setCropBottomY(float x) {
/*  647 */       this.optional_0_ |= 256;
/*  648 */       this.crop_bottom_y_ = x;
/*  649 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isAutolevels()
/*      */     {
/*  654 */       return this.autolevels_;
/*      */     }
/*      */     public final boolean hasAutolevels() {
/*  657 */       return (this.optional_0_ & 0x200) != 0;
/*      */     }
/*      */     public Transform clearAutolevels() {
/*  660 */       this.optional_0_ &= -513;
/*  661 */       this.autolevels_ = false;
/*  662 */       return this;
/*      */     }
/*      */     public Transform setAutolevels(boolean x) {
/*  665 */       this.optional_0_ |= 512;
/*  666 */       this.autolevels_ = x;
/*  667 */       return this;
/*      */     }
/*      */ 
/*      */     public Transform mergeFrom(Transform that)
/*      */     {
/*  674 */       assert (that != this);
/*  675 */       int this_t0 = this.optional_0_;
/*  676 */       int that_t0 = that.optional_0_;
/*      */ 
/*  678 */       if ((that_t0 & 0x1) != 0) {
/*  679 */         this_t0 |= 1;
/*  680 */         this.width_ = that.width_;
/*      */       }
/*      */ 
/*  683 */       if ((that_t0 & 0x2) != 0) {
/*  684 */         this_t0 |= 2;
/*  685 */         this.height_ = that.height_;
/*      */       }
/*      */ 
/*  688 */       if ((that_t0 & 0x4) != 0) {
/*  689 */         this_t0 |= 4;
/*  690 */         this.rotate_ = that.rotate_;
/*      */       }
/*      */ 
/*  693 */       if ((that_t0 & 0x8) != 0) {
/*  694 */         this_t0 |= 8;
/*  695 */         this.horizontal_flip_ = that.horizontal_flip_;
/*      */       }
/*      */ 
/*  698 */       if ((that_t0 & 0x10) != 0) {
/*  699 */         this_t0 |= 16;
/*  700 */         this.vertical_flip_ = that.vertical_flip_;
/*      */       }
/*      */ 
/*  703 */       if ((that_t0 & 0x20) != 0) {
/*  704 */         this_t0 |= 32;
/*  705 */         this.crop_left_x_ = that.crop_left_x_;
/*      */       }
/*      */ 
/*  708 */       if ((that_t0 & 0x40) != 0) {
/*  709 */         this_t0 |= 64;
/*  710 */         this.crop_top_y_ = that.crop_top_y_;
/*      */       }
/*      */ 
/*  713 */       if ((that_t0 & 0x80) != 0) {
/*  714 */         this_t0 |= 128;
/*  715 */         this.crop_right_x_ = that.crop_right_x_;
/*      */       }
/*      */ 
/*  718 */       if ((that_t0 & 0x100) != 0) {
/*  719 */         this_t0 |= 256;
/*  720 */         this.crop_bottom_y_ = that.crop_bottom_y_;
/*      */       }
/*      */ 
/*  723 */       if ((that_t0 & 0x200) != 0) {
/*  724 */         this_t0 |= 512;
/*  725 */         this.autolevels_ = that.autolevels_;
/*      */       }
/*      */ 
/*  728 */       if (that.uninterpreted != null) {
/*  729 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  731 */       this.optional_0_ = this_t0;
/*  732 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Transform that) {
/*  736 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Transform that) {
/*  740 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Transform that, boolean ignoreUninterpreted) {
/*  744 */       if (that == null) return false;
/*  745 */       if (that == this) return true;
/*  746 */       int this_t0 = this.optional_0_;
/*  747 */       int that_t0 = that.optional_0_;
/*  748 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  750 */       if (((this_t0 & 0x1) != 0) && 
/*  751 */         (this.width_ != that.width_)) return false;
/*      */ 
/*  754 */       if (((this_t0 & 0x2) != 0) && 
/*  755 */         (this.height_ != that.height_)) return false;
/*      */ 
/*  758 */       if (((this_t0 & 0x4) != 0) && 
/*  759 */         (this.rotate_ != that.rotate_)) return false;
/*      */ 
/*  762 */       if (((this_t0 & 0x8) != 0) && 
/*  763 */         (this.horizontal_flip_ != that.horizontal_flip_)) return false;
/*      */ 
/*  766 */       if (((this_t0 & 0x10) != 0) && 
/*  767 */         (this.vertical_flip_ != that.vertical_flip_)) return false;
/*      */ 
/*  770 */       if (((this_t0 & 0x20) != 0) && 
/*  771 */         (this.crop_left_x_ != that.crop_left_x_)) return false;
/*      */ 
/*  774 */       if (((this_t0 & 0x40) != 0) && 
/*  775 */         (this.crop_top_y_ != that.crop_top_y_)) return false;
/*      */ 
/*  778 */       if (((this_t0 & 0x80) != 0) && 
/*  779 */         (this.crop_right_x_ != that.crop_right_x_)) return false;
/*      */ 
/*  782 */       if (((this_t0 & 0x100) != 0) && 
/*  783 */         (this.crop_bottom_y_ != that.crop_bottom_y_)) return false;
/*      */ 
/*  786 */       if (((this_t0 & 0x200) != 0) && 
/*  787 */         (this.autolevels_ != that.autolevels_)) return false;
/*      */ 
/*  790 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  795 */       return ((that instanceof Transform)) && (equals((Transform)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  799 */       int hash = -885251810;
/*      */ 
/*  801 */       int this_t0 = this.optional_0_;
/*  802 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.width_ : -113);
/*      */ 
/*  804 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.height_ : -113);
/*      */ 
/*  806 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.rotate_ : -113);
/*      */ 
/*  808 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? 1237 : this.horizontal_flip_ ? 1231 : -113);
/*      */ 
/*  810 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? 1237 : this.vertical_flip_ ? 1231 : -113);
/*      */ 
/*  812 */       hash = hash * 31 + ((this_t0 & 0x20) != 0 ? Float.floatToIntBits(this.crop_left_x_) : -113);
/*      */ 
/*  814 */       hash = hash * 31 + ((this_t0 & 0x40) != 0 ? Float.floatToIntBits(this.crop_top_y_) : -113);
/*      */ 
/*  816 */       hash = hash * 31 + ((this_t0 & 0x80) != 0 ? Float.floatToIntBits(this.crop_right_x_) : -113);
/*      */ 
/*  818 */       hash = hash * 31 + ((this_t0 & 0x100) != 0 ? Float.floatToIntBits(this.crop_bottom_y_) : -113);
/*      */ 
/*  820 */       hash = hash * 31 + ((this_t0 & 0x200) != 0 ? 1237 : this.autolevels_ ? 1231 : -113);
/*  821 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  822 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  824 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  828 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  832 */       int n = 0;
/*  833 */       int this_t0 = this.optional_0_;
/*  834 */       if ((this_t0 & 0xFF) != 0) {
/*  835 */         if ((this_t0 & 0x1) != 0)
/*      */         {
/*  837 */           n += 1 + Protocol.varLongSize(this.width_);
/*      */         }
/*  839 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/*  841 */           n += 1 + Protocol.varLongSize(this.height_);
/*      */         }
/*  843 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/*  845 */           n += 1 + Protocol.varLongSize(this.rotate_);
/*      */         }
/*  847 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/*  849 */           n += 2;
/*      */         }
/*  851 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/*  853 */           n += 2;
/*      */         }
/*  855 */         if ((this_t0 & 0x20) != 0)
/*      */         {
/*  857 */           n += 5;
/*      */         }
/*  859 */         if ((this_t0 & 0x40) != 0)
/*      */         {
/*  861 */           n += 5;
/*      */         }
/*  863 */         if ((this_t0 & 0x80) != 0)
/*      */         {
/*  865 */           n += 5;
/*      */         }
/*      */       }
/*  868 */       if ((this_t0 & 0x300) != 0) {
/*  869 */         if ((this_t0 & 0x100) != 0)
/*      */         {
/*  871 */           n += 5;
/*      */         }
/*  873 */         if ((this_t0 & 0x200) != 0)
/*      */         {
/*  875 */           n += 2;
/*      */         }
/*      */       }
/*      */ 
/*  879 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  894 */       int n = 59;
/*      */ 
/*  896 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  901 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  905 */       this.optional_0_ = 0;
/*  906 */       this.width_ = 0;
/*  907 */       this.height_ = 0;
/*  908 */       this.rotate_ = 0;
/*  909 */       this.horizontal_flip_ = false;
/*  910 */       this.vertical_flip_ = false;
/*  911 */       this.crop_left_x_ = 0.0F;
/*  912 */       this.crop_top_y_ = 0.0F;
/*  913 */       this.crop_right_x_ = 1.0F;
/*  914 */       this.crop_bottom_y_ = 1.0F;
/*  915 */       this.autolevels_ = false;
/*  916 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Transform newInstance() {
/*  920 */       return new Transform();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  924 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  987 */       int this_t0 = this.optional_0_;
/*  988 */       if ((this_t0 & 0x1) != 0) {
/*  989 */         sink.putByte(8);
/*  990 */         sink.putVarLong(this.width_);
/*      */       }
/*      */ 
/*  993 */       if ((this_t0 & 0x2) != 0) {
/*  994 */         sink.putByte(16);
/*  995 */         sink.putVarLong(this.height_);
/*      */       }
/*      */ 
/*  998 */       if ((this_t0 & 0x4) != 0) {
/*  999 */         sink.putByte(24);
/* 1000 */         sink.putVarLong(this.rotate_);
/*      */       }
/*      */ 
/* 1003 */       if ((this_t0 & 0x8) != 0) {
/* 1004 */         sink.putByte(32);
/* 1005 */         sink.putBoolean(this.horizontal_flip_);
/*      */       }
/*      */ 
/* 1008 */       if ((this_t0 & 0x10) != 0) {
/* 1009 */         sink.putByte(40);
/* 1010 */         sink.putBoolean(this.vertical_flip_);
/*      */       }
/*      */ 
/* 1013 */       if ((this_t0 & 0x20) != 0) {
/* 1014 */         sink.putByte(53);
/* 1015 */         sink.putFloat(this.crop_left_x_);
/*      */       }
/*      */ 
/* 1018 */       if ((this_t0 & 0x40) != 0) {
/* 1019 */         sink.putByte(61);
/* 1020 */         sink.putFloat(this.crop_top_y_);
/*      */       }
/*      */ 
/* 1023 */       if ((this_t0 & 0x80) != 0) {
/* 1024 */         sink.putByte(69);
/* 1025 */         sink.putFloat(this.crop_right_x_);
/*      */       }
/*      */ 
/* 1028 */       if ((this_t0 & 0x100) != 0) {
/* 1029 */         sink.putByte(77);
/* 1030 */         sink.putFloat(this.crop_bottom_y_);
/*      */       }
/*      */ 
/* 1033 */       if ((this_t0 & 0x200) != 0) {
/* 1034 */         sink.putByte(80);
/* 1035 */         sink.putBoolean(this.autolevels_);
/*      */       }
/*      */ 
/* 1038 */       if (this.uninterpreted != null)
/* 1039 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1044 */       boolean result = true;
/* 1045 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1047 */       while (source.hasRemaining()) {
/* 1048 */         int tt = source.getVarInt();
/* 1049 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1053 */           result = false;
/* 1054 */           break;
/*      */         case 8:
/* 1057 */           this.width_ = source.getVarInt();
/* 1058 */           this_t0 |= 1;
/* 1059 */           break;
/*      */         case 16:
/* 1062 */           this.height_ = source.getVarInt();
/* 1063 */           this_t0 |= 2;
/* 1064 */           break;
/*      */         case 24:
/* 1067 */           this.rotate_ = source.getVarInt();
/* 1068 */           this_t0 |= 4;
/* 1069 */           break;
/*      */         case 32:
/* 1072 */           this.horizontal_flip_ = source.getBoolean();
/* 1073 */           this_t0 |= 8;
/* 1074 */           break;
/*      */         case 40:
/* 1077 */           this.vertical_flip_ = source.getBoolean();
/* 1078 */           this_t0 |= 16;
/* 1079 */           break;
/*      */         case 53:
/* 1082 */           this.crop_left_x_ = source.getFloat();
/* 1083 */           this_t0 |= 32;
/* 1084 */           break;
/*      */         case 61:
/* 1087 */           this.crop_top_y_ = source.getFloat();
/* 1088 */           this_t0 |= 64;
/* 1089 */           break;
/*      */         case 69:
/* 1092 */           this.crop_right_x_ = source.getFloat();
/* 1093 */           this_t0 |= 128;
/* 1094 */           break;
/*      */         case 77:
/* 1097 */           this.crop_bottom_y_ = source.getFloat();
/* 1098 */           this_t0 |= 256;
/* 1099 */           break;
/*      */         case 80:
/* 1102 */           this.autolevels_ = source.getBoolean();
/* 1103 */           this_t0 |= 512;
/* 1104 */           break;
/*      */         default:
/* 1106 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1111 */       this.optional_0_ = this_t0;
/* 1112 */       return result;
/*      */     }
/*      */ 
/*      */     public Transform getDefaultInstanceForType()
/*      */     {
/* 1117 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Transform getDefaultInstance() {
/* 1121 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1241 */       if (this.uninterpreted == null) {
/* 1242 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1244 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1125 */       IMMUTABLE_DEFAULT_INSTANCE = new Transform()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.Transform clearWidth()
/*      */         {
/* 1133 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setWidth(int x) {
/* 1136 */           ProtocolSupport.unsupportedOperation();
/* 1137 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearHeight()
/*      */         {
/* 1142 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setHeight(int x) {
/* 1145 */           ProtocolSupport.unsupportedOperation();
/* 1146 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearRotate()
/*      */         {
/* 1151 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setRotate(int x) {
/* 1154 */           ProtocolSupport.unsupportedOperation();
/* 1155 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearHorizontalFlip()
/*      */         {
/* 1160 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setHorizontalFlip(boolean x) {
/* 1163 */           ProtocolSupport.unsupportedOperation();
/* 1164 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearVerticalFlip()
/*      */         {
/* 1169 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setVerticalFlip(boolean x) {
/* 1172 */           ProtocolSupport.unsupportedOperation();
/* 1173 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearCropLeftX()
/*      */         {
/* 1178 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setCropLeftX(float x) {
/* 1181 */           ProtocolSupport.unsupportedOperation();
/* 1182 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearCropTopY()
/*      */         {
/* 1187 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setCropTopY(float x) {
/* 1190 */           ProtocolSupport.unsupportedOperation();
/* 1191 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearCropRightX()
/*      */         {
/* 1196 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setCropRightX(float x) {
/* 1199 */           ProtocolSupport.unsupportedOperation();
/* 1200 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearCropBottomY()
/*      */         {
/* 1205 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setCropBottomY(float x) {
/* 1208 */           ProtocolSupport.unsupportedOperation();
/* 1209 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform clearAutolevels()
/*      */         {
/* 1214 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform setAutolevels(boolean x) {
/* 1217 */           ProtocolSupport.unsupportedOperation();
/* 1218 */           return this;
/*      */         }
/*      */ 
/*      */         public ImagesServicePb.Transform mergeFrom(ImagesServicePb.Transform that) {
/* 1222 */           ProtocolSupport.unsupportedOperation();
/* 1223 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1226 */           ProtocolSupport.unsupportedOperation();
/* 1227 */           return false;
/*      */         }
/*      */         public ImagesServicePb.Transform freeze() {
/* 1230 */           return this;
/*      */         }
/*      */         public ImagesServicePb.Transform unfreeze() {
/* 1233 */           ProtocolSupport.unsupportedOperation();
/* 1234 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1237 */           return true;
/*      */         }
/*      */       };
/* 1258 */       text = new String[11];
/*      */ 
/* 1260 */       text[0] = "ErrorCode";
/* 1261 */       text[1] = "width";
/* 1262 */       text[2] = "height";
/* 1263 */       text[3] = "rotate";
/* 1264 */       text[4] = "horizontal_flip";
/* 1265 */       text[5] = "vertical_flip";
/* 1266 */       text[6] = "crop_left_x";
/* 1267 */       text[7] = "crop_top_y";
/* 1268 */       text[8] = "crop_right_x";
/* 1269 */       text[9] = "crop_bottom_y";
/* 1270 */       text[10] = "autolevels";
/*      */ 
/* 1273 */       types = new int[11];
/*      */ 
/* 1275 */       Arrays.fill(types, 6);
/* 1276 */       types[0] = 0;
/* 1277 */       types[1] = 0;
/* 1278 */       types[2] = 0;
/* 1279 */       types[3] = 0;
/* 1280 */       types[4] = 0;
/* 1281 */       types[5] = 0;
/* 1282 */       types[6] = 5;
/* 1283 */       types[7] = 5;
/* 1284 */       types[8] = 5;
/* 1285 */       types[9] = 5;
/* 1286 */       types[10] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  928 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.Transform.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("width", "width", 1, 0, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("height", "height", 2, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("rotate", "rotate", 3, 2, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("horizontal_flip", "horizontal_flip", 4, 3, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("vertical_flip", "vertical_flip", 5, 4, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("crop_left_x", "crop_left_x", 6, 5, ProtocolType.FieldBaseType.FLOAT, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("crop_top_y", "crop_top_y", 7, 6, ProtocolType.FieldBaseType.FLOAT, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("crop_right_x", "crop_right_x", 8, 7, ProtocolType.FieldBaseType.FLOAT, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("crop_bottom_y", "crop_bottom_y", 9, 8, ProtocolType.FieldBaseType.FLOAT, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("autolevels", "autolevels", 10, 9, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesServiceTransform extends ProtocolMessage<ImagesServiceTransform>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final ImagesServiceTransform IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public ImagesServiceTransform mergeFrom(ImagesServiceTransform that)
/*      */     {
/*  298 */       assert (that != this);
/*      */ 
/*  300 */       if (that.uninterpreted != null) {
/*  301 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  303 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesServiceTransform that) {
/*  307 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesServiceTransform that) {
/*  311 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesServiceTransform that, boolean ignoreUninterpreted) {
/*  315 */       if (that == null) return false;
/*  316 */       if (that == this) return true;
/*      */ 
/*  318 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  323 */       return ((that instanceof ImagesServiceTransform)) && (equals((ImagesServiceTransform)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  327 */       int hash = 958144054;
/*  328 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  329 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  331 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  335 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  339 */       int n = 0;
/*      */ 
/*  341 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  346 */       int n = 0;
/*      */ 
/*  348 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  353 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  357 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesServiceTransform newInstance() {
/*  361 */       return new ImagesServiceTransform();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  365 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  389 */       if (this.uninterpreted != null)
/*  390 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  395 */       boolean result = true;
/*      */ 
/*  397 */       while (source.hasRemaining()) {
/*  398 */         int tt = source.getVarInt();
/*  399 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  403 */           result = false;
/*  404 */           break;
/*      */         default:
/*  406 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  411 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesServiceTransform getDefaultInstanceForType()
/*      */     {
/*  416 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesServiceTransform getDefaultInstance() {
/*  420 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  450 */       if (this.uninterpreted == null) {
/*  451 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  453 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  424 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesServiceTransform()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesServiceTransform mergeFrom(ImagesServicePb.ImagesServiceTransform that)
/*      */         {
/*  431 */           ProtocolSupport.unsupportedOperation();
/*  432 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  435 */           ProtocolSupport.unsupportedOperation();
/*  436 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesServiceTransform freeze() {
/*  439 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesServiceTransform unfreeze() {
/*  442 */           ProtocolSupport.unsupportedOperation();
/*  443 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  446 */           return true;
/*      */         }
/*      */       };
/*  457 */       text = new String[1];
/*      */ 
/*  459 */       text[0] = "ErrorCode";
/*      */ 
/*  462 */       types = new int[1];
/*      */ 
/*  464 */       Arrays.fill(types, 6);
/*  465 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  369 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesServiceTransform.class, "Z*apphosting/api/images/images_service.proto\n!apphosting.ImagesServiceTransformsz\004Type\001\001\006RESIZE\001\001\001\001\001\006ROTATE\001\002\001\001\001\017HORIZONTAL_FLIP\001\003\001\001\001\rVERTICAL_FLIP\001\004\001\001\001\004CROP\001\005\001\001\001\020IM_FEELING_LUCKY\001\006\001t", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum Type
/*      */       implements ProtocolMessageEnum
/*      */     {
/*  266 */       RESIZE(1), 
/*  267 */       ROTATE(2), 
/*  268 */       HORIZONTAL_FLIP(3), 
/*  269 */       VERTICAL_FLIP(4), 
/*  270 */       CROP(5), 
/*  271 */       IM_FEELING_LUCKY(6);
/*      */ 
/*      */       public static final Type Type_MIN;
/*      */       public static final Type Type_MAX;
/*      */       private final int value;
/*      */ 
/*  276 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static Type valueOf(int value) {
/*  279 */         switch (value) { case 1:
/*  280 */           return RESIZE;
/*      */         case 2:
/*  281 */           return ROTATE;
/*      */         case 3:
/*  282 */           return HORIZONTAL_FLIP;
/*      */         case 4:
/*  283 */           return VERTICAL_FLIP;
/*      */         case 5:
/*  284 */           return CROP;
/*      */         case 6:
/*  285 */           return IM_FEELING_LUCKY;
/*      */         }
/*  287 */         return null;
/*      */       }
/*      */ 
/*      */       private Type(int v) {
/*  291 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  273 */         Type_MIN = RESIZE;
/*  274 */         Type_MAX = IM_FEELING_LUCKY;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ImagesServiceError extends ProtocolMessage<ImagesServiceError>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final ImagesServiceError IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public ImagesServiceError mergeFrom(ImagesServiceError that)
/*      */     {
/*   83 */       assert (that != this);
/*      */ 
/*   85 */       if (that.uninterpreted != null) {
/*   86 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   88 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ImagesServiceError that) {
/*   92 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesServiceError that) {
/*   96 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ImagesServiceError that, boolean ignoreUninterpreted) {
/*  100 */       if (that == null) return false;
/*  101 */       if (that == this) return true;
/*      */ 
/*  103 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  108 */       return ((that instanceof ImagesServiceError)) && (equals((ImagesServiceError)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  112 */       int hash = -473360572;
/*  113 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  114 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  116 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  120 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  124 */       int n = 0;
/*      */ 
/*  126 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  131 */       int n = 0;
/*      */ 
/*  133 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  138 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  142 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ImagesServiceError newInstance() {
/*  146 */       return new ImagesServiceError();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  150 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  176 */       if (this.uninterpreted != null)
/*  177 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  182 */       boolean result = true;
/*      */ 
/*  184 */       while (source.hasRemaining()) {
/*  185 */         int tt = source.getVarInt();
/*  186 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  190 */           result = false;
/*  191 */           break;
/*      */         default:
/*  193 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  198 */       return result;
/*      */     }
/*      */ 
/*      */     public ImagesServiceError getDefaultInstanceForType()
/*      */     {
/*  203 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ImagesServiceError getDefaultInstance() {
/*  207 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  237 */       if (this.uninterpreted == null) {
/*  238 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  240 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  211 */       IMMUTABLE_DEFAULT_INSTANCE = new ImagesServiceError()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ImagesServicePb.ImagesServiceError mergeFrom(ImagesServicePb.ImagesServiceError that)
/*      */         {
/*  218 */           ProtocolSupport.unsupportedOperation();
/*  219 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  222 */           ProtocolSupport.unsupportedOperation();
/*  223 */           return false;
/*      */         }
/*      */         public ImagesServicePb.ImagesServiceError freeze() {
/*  226 */           return this;
/*      */         }
/*      */         public ImagesServicePb.ImagesServiceError unfreeze() {
/*  229 */           ProtocolSupport.unsupportedOperation();
/*  230 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  233 */           return true;
/*      */         }
/*      */       };
/*  244 */       text = new String[1];
/*      */ 
/*  246 */       text[0] = "ErrorCode";
/*      */ 
/*  249 */       types = new int[1];
/*      */ 
/*  251 */       Arrays.fill(types, 6);
/*  252 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  154 */       private static final ProtocolType protocolType = new ProtocolType(ImagesServicePb.ImagesServiceError.class, "Z*apphosting/api/images/images_service.proto\n\035apphosting.ImagesServiceErrorsz\tErrorCode\001\001\021UNSPECIFIED_ERROR\001\001\001\001\001\022BAD_TRANSFORM_DATA\001\002\001\001\001\tNOT_IMAGE\001\003\001\001\001\016BAD_IMAGE_DATA\001\004\001\001\001\017IMAGE_TOO_LARGE\001\005\001\001\001\020INVALID_BLOB_KEY\001\006\001t", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   51 */       UNSPECIFIED_ERROR(1), 
/*   52 */       BAD_TRANSFORM_DATA(2), 
/*   53 */       NOT_IMAGE(3), 
/*   54 */       BAD_IMAGE_DATA(4), 
/*   55 */       IMAGE_TOO_LARGE(5), 
/*   56 */       INVALID_BLOB_KEY(6);
/*      */ 
/*      */       public static final ErrorCode ErrorCode_MIN;
/*      */       public static final ErrorCode ErrorCode_MAX;
/*      */       private final int value;
/*      */ 
/*   61 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   64 */         switch (value) { case 1:
/*   65 */           return UNSPECIFIED_ERROR;
/*      */         case 2:
/*   66 */           return BAD_TRANSFORM_DATA;
/*      */         case 3:
/*   67 */           return NOT_IMAGE;
/*      */         case 4:
/*   68 */           return BAD_IMAGE_DATA;
/*      */         case 5:
/*   69 */           return IMAGE_TOO_LARGE;
/*      */         case 6:
/*   70 */           return INVALID_BLOB_KEY;
/*      */         }
/*   72 */         return null;
/*      */       }
/*      */ 
/*      */       private ErrorCode(int v) {
/*   76 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   58 */         ErrorCode_MIN = UNSPECIFIED_ERROR;
/*   59 */         ErrorCode_MAX = INVALID_BLOB_KEY;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImagesServicePb
 * JD-Core Version:    0.6.0
 */