/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.util.Base64;
/*     */ import com.google.appengine.repackaged.com.google.common.util.Base64DecoderException;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*     */ 
/*     */ public class KeyFactory
/*     */ {
/*     */   public static Key createKey(String kind, long id)
/*     */   {
/*  31 */     return createKey(null, kind, id);
/*     */   }
/*     */ 
/*     */   public static Key createKey(Key parent, String kind, long id)
/*     */   {
/*  43 */     if (id == 0L) {
/*  44 */       throw new IllegalArgumentException("id cannot be zero");
/*     */     }
/*  46 */     return new Key(kind, parent, id);
/*     */   }
/*     */ 
/*     */   public static Key createKey(String kind, String name)
/*     */   {
/*  57 */     return createKey(null, kind, name);
/*     */   }
/*     */ 
/*     */   public static Key createKey(Key parent, String kind, String name)
/*     */   {
/*  69 */     if ((name == null) || (name.length() == 0)) {
/*  70 */       throw new IllegalArgumentException("name cannot be null or empty");
/*     */     }
/*  72 */     return new Key(kind, parent, name);
/*     */   }
/*     */ 
/*     */   public static String createKeyString(String kind, long id)
/*     */   {
/*  86 */     return keyToString(createKey(kind, id));
/*     */   }
/*     */ 
/*     */   public static String createKeyString(Key parent, String kind, long id)
/*     */   {
/* 101 */     return keyToString(createKey(parent, kind, id));
/*     */   }
/*     */ 
/*     */   public static String createKeyString(String kind, String name)
/*     */   {
/* 115 */     return keyToString(createKey(kind, name));
/*     */   }
/*     */ 
/*     */   public static String createKeyString(Key parent, String kind, String name)
/*     */   {
/* 130 */     return keyToString(createKey(parent, kind, name));
/*     */   }
/*     */ 
/*     */   public static String keyToString(Key key)
/*     */   {
/* 154 */     if (!key.isComplete()) {
/* 155 */       throw new IllegalArgumentException("Key is incomplete.");
/*     */     }
/* 157 */     OnestoreEntity.Reference reference = KeyTranslator.convertToPb(key);
/* 158 */     return Base64.encodeWebSafe(reference.toByteArray(), false);
/*     */   }
/*     */ 
/*     */   public static Key stringToKey(String encoded)
/*     */   {
/* 181 */     int modulo = encoded.length() % 4;
/* 182 */     if (modulo != 0)
/*     */     {
/* 184 */       encoded = encoded + "====".substring(modulo);
/* 187 */     }
/*     */ byte[] encodedBytes = encoded.getBytes();
/*     */     byte[] decodedBytes;
/*     */     try { decodedBytes = Base64.decodeWebSafe(encodedBytes, 0, encodedBytes.length);
/*     */     } catch (Base64DecoderException ex) {
/* 192 */       throw new IllegalArgumentException("Cannot parse: " + encoded, ex);
/*     */     }
/*     */ 
/* 195 */     OnestoreEntity.Reference reference = new OnestoreEntity.Reference();
/* 196 */     reference.parseFrom(decodedBytes);
/* 197 */     return KeyTranslator.createFromPb(reference);
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*     */     private Key current;
/*     */ 
/*     */     public Builder(String kind, String name)
/*     */     {
/* 235 */       this.current = KeyFactory.createKey(null, kind, name);
/*     */     }
/*     */ 
/*     */     public Builder(String kind, long id)
/*     */     {
/* 247 */       this.current = KeyFactory.createKey(null, kind, id);
/*     */     }
/*     */ 
/*     */     public Builder(Key key)
/*     */     {
/* 257 */       this.current = key;
/*     */     }
/*     */ 
/*     */     public Builder addChild(String kind, String name)
/*     */     {
/* 271 */       this.current = KeyFactory.createKey(this.current, kind, name);
/* 272 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder addChild(String kind, long id)
/*     */     {
/* 287 */       this.current = KeyFactory.createKey(this.current, kind, id);
/* 288 */       return this;
/*     */     }
/*     */ 
/*     */     public Key getKey()
/*     */     {
/* 295 */       return this.current;
/*     */     }
/*     */ 
/*     */     public String getString()
/*     */     {
/* 303 */       return KeyFactory.keyToString(this.current);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.KeyFactory
 * JD-Core Version:    0.6.0
 */