/*      */ package com.google.appengine.repackaged.com.google.io.protocol;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.CharEscaper;
/*      */ import com.google.appengine.repackaged.com.google.common.base.CharEscapers;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Charsets;
/*      */ import com.google.appengine.repackaged.com.google.common.base.StringUtil;
/*      */ import com.google.appengine.repackaged.com.google.common.collect.Maps;
/*      */ import com.google.appengine.repackaged.com.google.common.parameterset.ParameterSet;
/*      */ import com.google.appengine.repackaged.com.google.common.util.Base64;
/*      */ import com.google.appengine.repackaged.com.google.common.util.Base64DecoderException;
/*      */ import com.google.appengine.repackaged.com.google.io.base.IORuntimeException;
/*      */ import com.google.common.annotations.VisibleForTesting;
/*      */ import com.google.httputil.HttpHeaders;
/*      */ import com.google.httputil.HttpHeaders.Protocol;
/*      */ import com.google.httputil.HttpHeaders.ResponseCode;
/*      */ import com.google.httputil.HttpHeaders.Version;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public final class HtmlFormGenerator
/*      */ {
/*      */   private static final int MAXIMUM_INDENT = 25;
/*      */   private static final int COLUMNS_PER_INDENT = 2;
/*      */   private static final String EXPAND_VARIABLE = "expand";
/*      */ 
/*      */   @VisibleForTesting
/*      */   static final String INDIVIDUAL_FIELDS_VALUE = "Individual Fields";
/*      */ 
/*      */   @VisibleForTesting
/*      */   static final String SINGLE_TEXT_AREA_VALUE = "Single Text Area";
/*      */ 
/*      */   @VisibleForTesting
/*      */   static final String FORM_TYPE_VARIABLE = "formType";
/*      */ 
/*      */   @VisibleForTesting
/*      */   static final String PRIMARY_TEXT_AREA_VARIABLE = "primaryTextArea";
/*      */   private static final String SUBMIT_VARIABLE = "submit";
/*      */   private static final String RELOAD_VARIABLE = "reload";
/*      */   private static final String CLEAR_VARIABLE = "clear";
/*      */   private static final String CREATE_ACTION = "Create";
/*      */   private static final String DELETE_ACTION = "Delete";
/*      */   private static final String ADD_ACTION = "Add";
/*      */   private static final String ENCLOSING_FORM_NAME = "Editor";
/*  187 */   private static final String[] STRIPE_COLORS = { "00ee00", "00cc00", "00aa00", "008800", "006600" };
/*      */   private static final String STRIPES_WIDTH = "12px";
/*      */   private static final String BETWEEN_STRIPES_WIDTH = "8px";
/*      */   private static final char STRUCT_SEPARATOR = '.';
/*      */   private static final char ARRAY_SEPARATOR = '-';
/*      */   private static final String LINE_BREAK_CHARACTER_STRING = "\r\n";
/*      */   protected static final String UNINTERPRETED_PREFIX = "utags-";
/*      */   private final ParameterSet parameterSet;
/*  210 */   private final Map<String, String> errors = Maps.newHashMap();
/*      */   private final FormInfo formInfo;
/*      */   private final PrintWriter out;
/*      */   private final EnumSet<Options> options;
/*      */ 
/*      */   public HtmlFormGenerator(ParameterSet parameterSet, FormInfo formInfo, PrintWriter out, EnumSet<Options> options)
/*      */   {
/*  326 */     this.parameterSet = parameterSet;
/*  327 */     this.formInfo = formInfo;
/*  328 */     this.out = out;
/*  329 */     this.options = options;
/*      */   }
/*      */ 
/*      */   public HtmlFormGenerator(ParameterSet parameterSet, FormInfo formInfo, PrintWriter out)
/*      */   {
/*  341 */     this.parameterSet = parameterSet;
/*  342 */     this.formInfo = formInfo;
/*  343 */     this.out = out;
/*  344 */     this.options = EnumSet.noneOf(Options.class);
/*      */   }
/*      */ 
/*      */   public HtmlFormGenerator(ParameterSet parameterSet, String formName, PrintWriter out)
/*      */   {
/*  357 */     this.parameterSet = parameterSet;
/*  358 */     this.formInfo = new BasicFormInfo(formName);
/*  359 */     this.out = out;
/*  360 */     this.options = EnumSet.noneOf(Options.class);
/*      */   }
/*      */ 
/*      */   public void renderHttpHeader(String contentType)
/*      */   {
/*  370 */     HttpHeaders headers = new HttpHeaders();
/*  371 */     headers.setHttpVersion(HttpHeaders.Version.HTTP_10);
/*  372 */     headers.setResponseCode(HttpHeaders.ResponseCode.REQUEST_OK);
/*  373 */     headers.setHeader("Pragma", "no-cache", true);
/*  374 */     headers.setHeader(HttpHeaders.CONTENT_TYPE, contentType, true);
/*      */     try {
/*  376 */       headers.outputToWriterWithNewLine(this.out);
/*      */     } catch (IOException e) {
/*  378 */       throw new IORuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void renderHeader(String title)
/*      */   {
/*  389 */     PrintWriter out = this.out;
/*  390 */     if (this.options.contains(Options.INCLUDE_HTTP_HEADER)) {
/*  391 */       String contentType = this.options.contains(Options.XHTML) ? "text/xhtml" : "text/html";
/*      */ 
/*  393 */       renderHttpHeader(contentType);
/*      */     }
/*  395 */     if (this.options.contains(Options.XHTML))
/*      */     {
/*  397 */       out.println("<?xml version='1.0' encoding='utf-8'?>");
/*  398 */       out.println("<!DOCTYPE html");
/*  399 */       out.println("   PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"");
/*  400 */       out.println("    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
/*  401 */       out.println("<html xmlns='http://www.w3.org/1999/xhtml'");
/*  402 */       out.println("      xml:lang='en' lang='en'>");
/*      */     } else {
/*  404 */       out.println("<!DOCTYPE html");
/*  405 */       out.println("    PUBLIC \"-//W3C//DTD HTML 4.01 //EN\"");
/*  406 */       out.println("    \"http://www.w3.org/TR/html4/strict.dtd\">");
/*  407 */       out.println("<html>");
/*      */     }
/*  409 */     out.println("<head>");
/*  410 */     out.format("   <title>%s</title>\n", new Object[] { title });
/*  411 */     out.println("  <meta http-equiv=\"Content-Type\"");
/*  412 */     out.println("        content=\"text/html; charset=utf-8\" />");
/*  413 */     out.println("  <style type='text/css' id='internalStyle'>");
/*  414 */     out.println("     h1 { text-align : center }");
/*      */ 
/*  416 */     out.println("    .smallgray { color : #666666; font-size: 80%}");
/*  417 */     out.println("    .smalldebug { color : blue; font-size: 75%}");
/*  418 */     out.println("    .result    { color : blue  }");
/*      */ 
/*  420 */     out.println("    .red       { color: red }");
/*  421 */     out.format("    .nostripe  { width: %s }\n", new Object[] { "8px" });
/*      */ 
/*  423 */     for (int i = 0; i < STRIPE_COLORS.length; i++) {
/*  424 */       out.format("    .stripe%d   { background-color: #%s; width : %s }\n", new Object[] { Integer.valueOf(i), STRIPE_COLORS[i], "12px" });
/*      */     }
/*      */ 
/*  427 */     out.println("  </style>");
/*  428 */     out.println("</head>");
/*  429 */     out.println("<body>");
/*      */   }
/*      */ 
/*      */   public void renderFooter()
/*      */   {
/*  437 */     this.out.println("</body>");
/*  438 */     this.out.println("</html>");
/*  439 */     this.out.flush();
/*      */   }
/*      */ 
/*      */   public <T extends ProtocolMessage<T>> T handleFormSubmit(String title, Class<? extends T> clazz, T protoMessage)
/*      */   {
/*  463 */     ProtocolMessage request = parseRequest(clazz, protoMessage);
/*  464 */     if ((!hasErrors()) && (hasParameter("submit"))) {
/*  465 */       return request;
/*      */     }
/*      */ 
/*  468 */     renderMessage(title, request);
/*  469 */     return null;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public <T extends ProtocolMessage<T>> T handleFormSubmit(String title, Class<T> clazz)
/*      */   {
/*  495 */     return handleFormSubmit(title, clazz, ProtocolSupport.newInstance(clazz));
/*      */   }
/*      */ 
/*      */   public void renderMessage(String title, ProtocolMessage message)
/*      */   {
/*  507 */     PrintWriter out = this.out;
/*      */ 
/*  509 */     if (!this.options.contains(Options.EXCLUDE_HTML_HEADER_FOOTER)) {
/*  510 */       renderHeader(title);
/*      */     }
/*      */ 
/*  514 */     out.print("<a name='top'></a>");
/*      */ 
/*  516 */     if (title != null) {
/*  517 */       out.format("<h1>%s</h1>", new Object[] { title });
/*      */     }
/*  519 */     boolean debugging = this.options.contains(Options.DEBUG);
/*      */ 
/*  524 */     if ((debugging) && (hasErrors())) {
/*  525 */       out.println("<h2>Errors</h2>");
/*  526 */       showErrors();
/*  527 */       out.println("<hr />");
/*      */     }
/*      */ 
/*  530 */     if (message != null)
/*      */     {
/*  532 */       renderTopLevelStructure(message);
/*      */     } else {
/*  534 */       renderHeader("Internal Error");
/*  535 */       out.format("<p><b>Unexpected error</b></p>\n", new Object[0]);
/*  536 */       out.format("<p>Internal message was '%s'</p>\n", new Object[] { this.errors.get("main") });
/*      */     }
/*      */ 
/*  539 */     if ((debugging) && (message != null))
/*      */     {
/*  541 */       out.println("<hr />");
/*  542 */       out.println("<h2>Message as string</h2>");
/*  543 */       out.println("<pre>");
/*  544 */       out.print(escape(message));
/*  545 */       out.println("</pre>");
/*      */     }
/*      */ 
/*  548 */     if (debugging) {
/*  549 */       out.println("<hr />");
/*  550 */       out.println("<h2>Parameter Map</h2>");
/*  551 */       showParameterMap();
/*      */     }
/*      */ 
/*  555 */     out.println("<p><a href='#top'>Back to the top</a></p>\n");
/*      */ 
/*  558 */     if (!this.options.contains(Options.EXCLUDE_HTML_HEADER_FOOTER))
/*  559 */       renderFooter();
/*      */   }
/*      */ 
/*      */   private void renderTopLevelStructure(ProtocolMessage message)
/*      */   {
/*  569 */     PrintWriter out = this.out;
/*  570 */     boolean readOnly = this.options.contains(Options.READONLY);
/*  571 */     CategoryInformation categoryInformation = message.messageCategoryInformation();
/*      */ 
/*  575 */     String className = categoryInformation == null ? message.getClass().getSimpleName() : categoryInformation.getSimpleClassName(message);
/*      */ 
/*  578 */     out.format("<h2>%s</h2>", new Object[] { className });
/*  579 */     if (hasErrors()) {
/*  580 */       out.println("<p class='red'><b>Input has errors!</b></p>");
/*      */     }
/*  582 */     if (!readOnly) {
/*  583 */       out.format("<form method='%s' action='%s' name='%s' id='%s'>\n", new Object[] { this.formInfo.getProtocolType(), escape(this.formInfo.getURI()), "Editor", "Editor" });
/*      */ 
/*  587 */       Map hiddenInputs = this.formInfo.getHiddenInputs();
/*  588 */       for (String key : hiddenInputs.keySet()) {
/*  589 */         out.format("<input type='hidden' name='%s' value='%s' />\n", new Object[] { escape(key), escape(hiddenInputs.get(key)) });
/*      */       }
/*      */ 
/*  594 */       String buttonFormat = "<input type='submit' name='%s' value='%s' />\n";
/*  595 */       out.format(buttonFormat, new Object[] { "reload", "Reload" });
/*  596 */       if ((singleTextArea()) || (categoryInformation != null)) {
/*  597 */         out.format(buttonFormat, new Object[] { "formType", "Individual Fields" });
/*      */       } else {
/*  599 */         out.format(buttonFormat, new Object[] { "expand", "Expand" });
/*  600 */         out.format(buttonFormat, new Object[] { "formType", "Single Text Area" });
/*      */       }
/*  602 */       out.format(buttonFormat, new Object[] { "clear", "Clear" });
/*  603 */       out.format(buttonFormat, new Object[] { "submit", escape(this.formInfo.getSubmitButtonName()) });
/*      */ 
/*  605 */       out.println("<br /><br />");
/*      */     }
/*      */ 
/*  608 */     out.format("<table cellspacing='0' cellpadding='0' border='0'>\n", new Object[0]);
/*      */ 
/*  610 */     renderProtocolMessage(message, "", 0);
/*  611 */     out.println("</table>");
/*  612 */     if (!readOnly) {
/*  613 */       this.formInfo.generatePostMessageHtml(message);
/*  614 */       out.println("</form>");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void renderProtocolMessage(ProtocolMessage message, String structureID, int indent)
/*      */   {
/*  629 */     String uninterpretedTags = encodeUninterpretedTagsFrom(message);
/*  630 */     if (uninterpretedTags != null)
/*      */     {
/*  633 */       this.out.format("<input type='hidden' name='%s%s' value='%s' />", new Object[] { "utags-", structureID, uninterpretedTags });
/*      */     }
/*      */ 
/*  637 */     if ((singleTextArea()) || (message.messageCategoryInformation() != null)) {
/*  638 */       boolean readOnly = this.options.contains(Options.READONLY);
/*  639 */       this.out.append("<b>Text representation of protocol buffer:</b><br />");
/*  640 */       this.out.format("<textarea name='%s' %s rows='20' cols='75'>%s</textarea>", new Object[] { "primaryTextArea", readOnly ? "readonly " : "", message });
/*      */     }
/*      */     else {
/*  643 */       List tags = ProtocolType.getTags(message);
/*  644 */       for (ProtocolType.FieldType tag : tags)
/*  645 */         renderOneField(message, structureID + tag.getTag(), tag, indent);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean singleTextArea()
/*      */   {
/*  651 */     return "Single Text Area".equals(getParameter("formType"));
/*      */   }
/*      */ 
/*      */   private void renderOneField(ProtocolMessage message, String fieldID, ProtocolType.FieldType fieldType, int indent)
/*      */   {
/*  664 */     boolean readOnly = this.options.contains(Options.READONLY);
/*      */ 
/*  666 */     ProtocolType.Presence presence = fieldType.getPresence();
/*      */ 
/*  668 */     ProtocolType.FieldBaseType baseType = fieldType.getBaseType();
/*      */ 
/*  670 */     boolean isStructure = (baseType == ProtocolType.FieldBaseType.GROUP) || (baseType == ProtocolType.FieldBaseType.FOREIGN);
/*      */ 
/*  672 */     String extra = "";
/*      */ 
/*  674 */     int count = fieldType.size(message);
/*      */ 
/*  676 */     if (presence != ProtocolType.Presence.REPEATED)
/*      */     {
/*  679 */       Object value = fieldType.getSingleValue(message);
/*      */ 
/*  681 */       if (presence == ProtocolType.Presence.OPTIONAL) {
/*  682 */         if (readOnly) {
/*  683 */           extra = String.format("<span>Optional %s</span>", new Object[] { count == 0 ? "missing" : "present" });
/*      */         }
/*  686 */         else if (isStructure)
/*      */         {
/*  688 */           extra = String.format("<input type='submit' name='%s.' value='%s' />", new Object[] { fieldID, count == 0 ? "Create" : "Delete" });
/*      */         }
/*      */         else
/*      */         {
/*  694 */           String checked = count > 0 ? " checked='checked'" : "";
/*  695 */           extra = String.format("<label><input type='checkbox' name='%s.' id='id%s' value='y'%s />include this field</label>", new Object[] { fieldID, fieldID, checked });
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  703 */         count = 1;
/*      */       }
/*  705 */       renderOneValue(value, indent, fieldType, fieldID, extra, count);
/*      */     }
/*  708 */     else if (count == 0)
/*      */     {
/*  711 */       String elementID = fieldID + '-' + "0";
/*  712 */       Object value = null;
/*  713 */       if (readOnly)
/*  714 */         extra = "<span>Empty array</span>";
/*      */       else {
/*  716 */         extra = String.format("<input type='submit' name='%s.' value='%s' />", new Object[] { elementID, "Create" });
/*      */       }
/*      */ 
/*  720 */       renderOneValue(value, indent, fieldType, elementID, extra, 0);
/*      */     }
/*      */     else
/*      */     {
/*  724 */       for (int i = 0; i < count; i++) {
/*  725 */         Object value = fieldType.getNthValue(message, i);
/*  726 */         String elementID = fieldID + '-' + i;
/*  727 */         if (!readOnly) {
/*  728 */           extra = String.format("<input type='submit' name='%s.' value='%s' /><input type='submit' name='%s.' value='%s' />", new Object[] { elementID, "Add", elementID, "Delete" });
/*      */         }
/*      */ 
/*  733 */         renderOneValue(value, indent, fieldType, elementID, extra, i + 1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void renderOneValue(Object value, int indent, ProtocolType.FieldType fieldType, String valueID, String extra, int count)
/*      */   {
/*  756 */     PrintWriter out = this.out;
/*  757 */     boolean readOnly = this.options.contains(Options.READONLY);
/*  758 */     String fieldName = fieldType.getName();
/*  759 */     ProtocolType.Presence presence = fieldType.getPresence();
/*  760 */     ProtocolType.FieldBaseType baseType = fieldType.getBaseType();
/*  761 */     boolean isStructure = (baseType == ProtocolType.FieldBaseType.GROUP) || (baseType == ProtocolType.FieldBaseType.FOREIGN);
/*      */ 
/*  763 */     boolean isRepeated = presence == ProtocolType.Presence.REPEATED;
/*  764 */     Class enumType = fieldType.getEnumType();
/*      */ 
/*  766 */     String javaScript = "";
/*  767 */     if ((presence == ProtocolType.Presence.OPTIONAL) && (!isStructure) && (!readOnly))
/*      */     {
/*  771 */       String checkbox = this.options.contains(Options.XHTML) ? String.format("getElementById('id%s')", new Object[] { valueID }) : String.format("%s.elements['%s.']", new Object[] { "Editor", valueID });
/*      */ 
/*  775 */       javaScript = String.format(" onfocus=\"document.%s.checked=true;\"", new Object[] { checkbox });
/*      */     }
/*      */ 
/*  778 */     if (extra.length() > 0)
/*      */     {
/*  780 */       extra = "<td>&nbsp;</td><td class='smallgray'>\n" + extra + "\n</td>";
/*      */     }
/*      */ 
/*  783 */     out.format("<tr>", new Object[0]);
/*      */ 
/*  785 */     for (int i = 0; i < indent; i++) {
/*  786 */       out.format("<td class='stripe%s' />\n", new Object[] { Integer.valueOf(i % STRIPE_COLORS.length) });
/*  787 */       out.format("<td class='nostripe' />\n", new Object[0]);
/*      */     }
/*      */ 
/*  790 */     out.format("<td colspan='%s'>%s", new Object[] { Integer.valueOf(2 * (25 - indent)), fieldName });
/*      */ 
/*  792 */     if ((isRepeated) && (count >= 1)) {
/*  793 */       out.format(" #%d", new Object[] { Integer.valueOf(count) });
/*      */     }
/*  795 */     if (this.options.contains(Options.DEBUG)) {
/*  796 */       out.format("<span class='smalldebug'> %s </span>", new Object[] { valueID });
/*      */     }
/*  798 */     String errorValue = (String)this.errors.get(valueID);
/*  799 */     out.format(":\n", new Object[0]);
/*  800 */     if (errorValue != null) {
/*  801 */       out.format("<span class='red'> Illegal %s value </span>\n", new Object[] { baseType });
/*      */     }
/*  803 */     if ((count == 0) && ((isRepeated) || (isStructure)))
/*      */     {
/*  805 */       out.format("</td>%s</tr>\n", new Object[] { extra });
/*  806 */     } else if (isStructure) {
/*  807 */       ProtocolMessage message = (ProtocolMessage)value;
/*  808 */       if (message == null)
/*      */       {
/*  810 */         message = ProtocolSupport.newInstance(fieldType.getSubclass());
/*      */       }
/*      */ 
/*  813 */       out.format("<input type='hidden' name='%s' value='t' />", new Object[] { valueID });
/*  814 */       out.format("</td>%s</tr>\n", new Object[] { extra });
/*      */ 
/*  816 */       renderProtocolMessage(message, valueID + '.', indent + 1);
/*      */     }
/*  818 */     else if (enumType != null) {
/*  819 */       generateEnumerationField(value, valueID, enumType, javaScript, extra);
/*  820 */     } else if (baseType == ProtocolType.FieldBaseType.BOOL) {
/*  821 */       generateBooleanField(value, valueID, javaScript, extra);
/*      */     } else {
/*  823 */       generateTextField(value, valueID, baseType, errorValue, javaScript, extra);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void generateEnumerationField(Object value, String valueID, Class<? extends Enum> enumClass, String javaScript, String extra)
/*      */   {
/*  839 */     boolean readOnly = this.options.contains(Options.READONLY);
/*      */ 
/*  842 */     boolean skipSelect = (readOnly) || (this.options.contains(Options.XHTML)) || (this.options.contains(Options.DEBUG)) || (this.options.contains(Options.USE_INPUT_FOR_ENUM));
/*      */ 
/*  845 */     Enum enumm = null;
/*  846 */     this.out.format("<label>", new Object[0]);
/*  847 */     if (!skipSelect) {
/*      */       try {
/*  849 */         Method method = enumClass.getMethod("valueOf", new Class[] { Integer.TYPE });
/*  850 */         enumm = (Enum)method.invoke(null, new Object[] { value });
/*      */       } catch (NoSuchMethodException nsmEx) {
/*  852 */         nsmEx.printStackTrace();
/*      */       } catch (IllegalAccessException illEx) {
/*  854 */         illEx.printStackTrace();
/*      */       } catch (InvocationTargetException itEx) {
/*  856 */         itEx.printStackTrace();
/*      */       }
/*      */     }
/*      */ 
/*  860 */     if (enumm != null) {
/*  861 */       if (javaScript.length() > 0) {
/*  862 */         javaScript = javaScript.replaceFirst("onfocus=", "onchange=");
/*      */       }
/*      */ 
/*  865 */       this.out.format("<select name='%s' %s %s>\n", new Object[] { valueID, readOnly ? "disabled" : "", javaScript });
/*  866 */       for (Enum enumName : (Enum[])enumClass.getEnumConstants()) {
/*  867 */         int evalue = ((ProtocolMessageEnum)enumName).getValue();
/*  868 */         this.out.format("<option value='%s' %s>%s (%s)</option>\n", new Object[] { Integer.valueOf(evalue), enumm == enumName ? "selected" : "", enumName, Integer.valueOf(evalue) });
/*      */       }
/*      */ 
/*  871 */       this.out.print("</select>");
/*      */     } else {
/*  873 */       this.out.format("<input type='text' name='%s' value='%s' %s %s/>", new Object[] { valueID, value, readOnly ? "disabled" : "", javaScript });
/*      */     }
/*      */ 
/*  876 */     this.out.format("</label></td>%s</tr>\n", new Object[] { extra });
/*      */   }
/*      */ 
/*      */   private void generateBooleanField(Object value, String valueID, String javaScript, String extra)
/*      */   {
/*  890 */     boolean readOnly = this.options.contains(Options.READONLY);
/*      */ 
/*  893 */     if (javaScript.length() > 0) {
/*  894 */       javaScript = javaScript.replaceFirst("onfocus=", "onclick=");
/*      */     }
/*  896 */     boolean isTrue = ((Boolean)value).booleanValue();
/*      */ 
/*  898 */     this.out.format("<label><input type='radio' name='%s' value='t'%s%s %s/>true</label>\n", new Object[] { valueID, isTrue ? " checked='checked' " : " ", readOnly ? " disabled" : " ", javaScript });
/*      */ 
/*  902 */     this.out.format("<label><input type='radio' name='%s' value='f'%s%s %s/>false</label>\n", new Object[] { valueID, isTrue ? " " : " checked='checked' ", readOnly ? " disabled" : " ", javaScript });
/*      */ 
/*  907 */     this.out.format("</td>%s</tr>\n", new Object[] { extra });
/*      */   }
/*      */ 
/*      */   private void generateTextField(Object value, String valueID, ProtocolType.FieldBaseType baseType, String errorValue, String javaScript, String extra)
/*      */   {
/*  924 */     boolean readOnly = this.options.contains(Options.READONLY);
/*      */ 
/*  927 */     if (errorValue != null)
/*      */     {
/*  929 */       this.out.format("<input class='red' type='text' name='%s' value='%s'%s /></td>%s</tr>\n", new Object[] { valueID, errorValue, javaScript, extra });
/*      */     }
/*      */     else
/*      */     {
/*  933 */       if (value == null) {
/*  934 */         value = "";
/*      */       }
/*      */ 
/*  938 */       int rows = 10;
/*  939 */       boolean useTextArea = false;
/*  940 */       if (baseType == ProtocolType.FieldBaseType.STRING)
/*      */       {
/*  942 */         if ((value instanceof byte[])) {
/*  943 */           value = Protocol.toStringUtf8((byte[])(byte[])value);
/*      */         }
/*      */ 
/*  946 */         if (this.options.contains(Options.USE_TEXT_AREA))
/*      */         {
/*  950 */           if (value.toString().contains("\r\n")) {
/*  951 */             useTextArea = true;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  958 */       boolean containsHtml = false;
/*  959 */       if (StringUtil.containsCharRef(value.toString())) {
/*  960 */         containsHtml = true;
/*  961 */         rows = 25;
/*      */       }
/*      */ 
/*  966 */       if (this.options.contains(Options.HTML_ESCAPE_FIELDS)) {
/*  967 */         value = escape(value);
/*      */       }
/*      */ 
/*  970 */       if (readOnly) {
/*  971 */         if ((containsHtml) || (useTextArea)) {
/*  972 */           this.out.format("<textarea rows='%s' cols='75' readonly>%s</textarea>", new Object[] { Integer.valueOf(rows), value });
/*      */         }
/*      */         else {
/*  975 */           this.out.format("<span class='result'>%s</span>", new Object[] { value });
/*      */         }
/*      */       }
/*  978 */       else if ((containsHtml) || (useTextArea)) {
/*  979 */         this.out.format("<textarea name='%s' rows='%s' cols='75'%s>%s</textarea>", new Object[] { valueID, Integer.valueOf(rows), javaScript, value });
/*      */       }
/*      */       else {
/*  982 */         this.out.format("<input type='text' name='%s' value='%s'%s />", new Object[] { valueID, value, javaScript });
/*      */       }
/*      */ 
/*  986 */       this.out.format("</td>%s</tr>\n", new Object[] { extra });
/*      */     }
/*      */   }
/*      */ 
/*      */   private <T extends ProtocolMessage<T>> T parseRequest(Class<? extends T> clazz, T protoMessage)
/*      */   {
/* 1000 */     ProtocolMessage newInstance = (ProtocolMessage)clazz.cast(protoMessage.newInstance());
/* 1001 */     if (hasParameter("clear"))
/*      */     {
/* 1003 */       return newInstance;
/*      */     }
/* 1005 */     if (hasParameter("primaryTextArea")) {
/*      */       try {
/* 1007 */         return ProtocolTextParser.parse(getParameter("primaryTextArea"), newInstance);
/*      */       } catch (RuntimeException e) {
/* 1009 */         this.errors.put("main", e.getMessage());
/* 1010 */         return null;
/*      */       }
/*      */     }
/*      */ 
/* 1014 */     GrowableProtocolSink ps = new GrowableProtocolSink();
/* 1015 */     structureToSink("", "", clazz, ps);
/* 1016 */     if (newInstance.mergeFrom(new ProtocolSource(ps.array(), 0, ps.position()))) {
/* 1017 */       return newInstance;
/*      */     }
/*      */ 
/* 1020 */     this.errors.put("main", "Internal error parsing Data Sink");
/* 1021 */     return null;
/*      */   }
/*      */ 
/*      */   private void structureToSink(String inStructureID, String outStructureID, Class<? extends ProtocolMessage> clazz, GrowableProtocolSink sink)
/*      */   {
/* 1038 */     List tags = ProtocolType.getTags(clazz);
/* 1039 */     for (int i = 0; i < tags.size(); i++) {
/* 1040 */       ProtocolType.FieldType tag = (ProtocolType.FieldType)tags.get(i);
/* 1041 */       int outSuffix = tag.getTag();
/* 1042 */       int inSuffix = this.options.contains(Options.LEGACY_INPUT_FORMAT) ? i : outSuffix;
/*      */ 
/* 1044 */       fieldToSink(inStructureID + inSuffix, outStructureID + outSuffix, tag, sink, clazz);
/*      */     }
/*      */ 
/* 1049 */     String uninterpretedTags = getParameter("utags-" + inStructureID);
/*      */ 
/* 1051 */     if (uninterpretedTags != null)
/* 1052 */       mergeUninterpretedTagsInto(sink, uninterpretedTags);
/*      */   }
/*      */ 
/*      */   private void fieldToSink(String inFieldID, String outFieldID, ProtocolType.FieldType fieldType, GrowableProtocolSink sink, Class<? extends ProtocolMessage> clazz)
/*      */   {
/* 1070 */     ProtocolType.Presence presence = fieldType.getPresence();
/* 1071 */     ProtocolType.FieldBaseType baseType = fieldType.getBaseType();
/* 1072 */     boolean isStructure = (baseType == ProtocolType.FieldBaseType.GROUP) || (baseType == ProtocolType.FieldBaseType.FOREIGN);
/*      */ 
/* 1074 */     if (presence != ProtocolType.Presence.REPEATED)
/*      */     {
/* 1077 */       String value = getParameter(inFieldID);
/* 1078 */       if (presence == ProtocolType.Presence.OPTIONAL)
/*      */       {
/* 1080 */         String secondParameterKey = inFieldID + ".";
/* 1081 */         String secondParameterValue = getParameter(secondParameterKey);
/* 1082 */         if (!isStructure)
/*      */         {
/* 1085 */           if (secondParameterValue == null) {
/* 1086 */             return;
/*      */           }
/*      */ 
/*      */         }
/* 1094 */         else if ("Create".equals(secondParameterValue)) {
/* 1095 */           value = null; } else {
/* 1096 */           if ("Delete".equals(secondParameterValue))
/* 1097 */             return;
/* 1098 */           if ((value == null) && (!hasParameter("expand"))) {
/* 1099 */             return;
/*      */           }
/*      */         }
/*      */       }
/* 1103 */       valueToSink(clazz, fieldType, inFieldID, outFieldID, value, sink);
/*      */     }
/*      */     else
/*      */     {
/* 1108 */       int count = 0;
/* 1109 */       for (int i = 0; ; i++) {
/* 1110 */         String inkey = inFieldID + '-' + i;
/* 1111 */         String outkey = outFieldID + '-' + count;
/* 1112 */         String actionKey = inkey + ".";
/* 1113 */         String value = getParameter(inkey);
/* 1114 */         String actionValue = getParameter(actionKey);
/* 1115 */         if ((i == 0) && ("Create".equals(actionValue)))
/*      */         {
/* 1118 */           count++;
/* 1119 */           valueToSink(clazz, fieldType, inkey, outkey, null, sink);
/*      */         }
/* 1121 */         if (value == null)
/*      */         {
/*      */           break;
/*      */         }
/* 1125 */         if (!"Delete".equals(actionValue))
/*      */         {
/* 1127 */           count++;
/* 1128 */           valueToSink(clazz, fieldType, inkey, outkey, value, sink);
/*      */         }
/* 1130 */         if (!"Add".equals(actionValue))
/*      */           continue;
/* 1132 */         count++;
/* 1133 */         valueToSink(clazz, fieldType, inkey, outkey, null, sink);
/*      */       }
/*      */ 
/* 1136 */       if ((count == 0) && (hasParameter("expand"))) {
/* 1137 */         String inkey = inFieldID + '-' + 0;
/* 1138 */         String outkey = outFieldID + '-' + 0;
/*      */ 
/* 1141 */         valueToSink(clazz, fieldType, inkey, outkey, null, sink);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void valueToSink(Class<? extends ProtocolMessage> clazz, ProtocolType.FieldType fieldType, String inValueID, String outValueID, String value, GrowableProtocolSink sink)
/*      */   {
/* 1160 */     if (value == null) {
/* 1161 */       value = "";
/*      */     }
/* 1163 */     sink.putVarInt(fieldType.getWireTag());
/* 1164 */     switch (1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[fieldType.getBaseType().ordinal()])
/*      */     {
/*      */     case 1:
/* 1167 */       boolean result = (value.length() > 0) && (value.charAt(0) == 't');
/* 1168 */       sink.putBoolean(result);
/* 1169 */       break;
/*      */     case 2:
/*      */     case 3:
/*      */       int result;
/*      */       try
/*      */       {
/* 1176 */         result = value.length() == 0 ? defaultFieldValue(clazz, fieldType).intValue() : Integer.parseInt(value);
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/* 1180 */         this.errors.put(outValueID, value);
/* 1181 */         result = 0;
/*      */       }
/* 1183 */       if (fieldType.getBaseType().isFixed())
/* 1184 */         sink.putInt(result);
/*      */       else {
/* 1186 */         sink.putVarInt(result);
/*      */       }
/* 1188 */       break;
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */       long result;
/*      */       try
/*      */       {
/* 1196 */         result = value.length() == 0 ? defaultFieldValue(clazz, fieldType).longValue() : Long.parseLong(value);
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/* 1200 */         this.errors.put(outValueID, value);
/* 1201 */         result = 0L;
/*      */       }
/* 1203 */       if (fieldType.getBaseType().isFixed())
/* 1204 */         sink.putLong(result);
/*      */       else {
/* 1206 */         sink.putVarLong(result);
/*      */       }
/* 1208 */       break;
/*      */     case 7:
/*      */       double result;
/*      */       try
/*      */       {
/* 1214 */         result = value.length() == 0 ? defaultFieldValue(clazz, fieldType).doubleValue() : Double.parseDouble(value);
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/* 1218 */         this.errors.put(outValueID, value);
/* 1219 */         result = 0.0D;
/*      */       }
/* 1221 */       sink.putDouble(result);
/* 1222 */       break;
/*      */     case 8:
/*      */       float result;
/*      */       try
/*      */       {
/* 1229 */         result = value.length() == 0 ? defaultFieldValue(clazz, fieldType).floatValue() : Float.parseFloat(value);
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/* 1233 */         this.errors.put(outValueID, value);
/* 1234 */         result = 0.0F;
/*      */       }
/* 1236 */       sink.putFloat(result);
/* 1237 */       break;
/*      */     case 9:
/* 1243 */       if (value.length() == 0) {
/* 1244 */         ProtocolMessage message = ProtocolSupport.newInstance(fieldType.getSubclass());
/*      */ 
/* 1246 */         ProtocolSink pSink = message.toProtocolSink();
/* 1247 */         sink.putVarInt(pSink.position());
/* 1248 */         sink.putBytes(pSink.array(), 0, pSink.position());
/*      */       } else {
/* 1250 */         GrowableProtocolSink newSink = new GrowableProtocolSink();
/* 1251 */         structureToSink(inValueID + '.', outValueID + '.', fieldType.getSubclass(), newSink);
/*      */ 
/* 1254 */         sink.putPrefixedData(newSink.toArray());
/*      */       }
/* 1256 */       break;
/*      */     case 10:
/* 1262 */       if (value.length() == 0) {
/* 1263 */         ProtocolMessage message = ProtocolSupport.newInstance(fieldType.getSubclass());
/*      */ 
/* 1265 */         ProtocolSink pSink = message.toProtocolSink();
/* 1266 */         sink.putBytes(pSink.array(), 0, pSink.position());
/*      */       } else {
/* 1268 */         structureToSink(inValueID + '.', outValueID + '.', fieldType.getSubclass(), sink);
/*      */ 
/* 1271 */         if (!fieldType.groupsGenerateOwnEndTag()) break;
/* 1272 */         sink.putVarInt(fieldType.getWireTag() + 1); } break;
/*      */     case 11:
/* 1280 */       if (this.options.contains(Options.HTML_ESCAPE_FIELDS)) {
/* 1281 */         value = unescape(value);
/*      */       }
/* 1283 */       byte[] bytes = value.getBytes(Charsets.UTF_8);
/* 1284 */       sink.putVarInt(bytes.length);
/* 1285 */       sink.putBytes(bytes);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Number defaultFieldValue(Class<? extends ProtocolMessage> clazz, ProtocolType.FieldType fieldType)
/*      */   {
/* 1299 */     if (fieldType.getPresence() == ProtocolType.Presence.REPEATED)
/*      */     {
/* 1301 */       return Integer.valueOf(0);
/*      */     }
/*      */ 
/* 1304 */     return (Number)fieldType.getSingleValue(ProtocolSupport.newInstance(clazz));
/*      */   }
/*      */ 
/*      */   protected void mergeUninterpretedTagsInto(GrowableProtocolSink sink, String uninterpretedTags)
/*      */   {
/* 1314 */     if (uninterpretedTags == null) {
/* 1315 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 1319 */       sink.putBytes(Base64.decodeWebSafe(uninterpretedTags));
/*      */     } catch (Base64DecoderException e) {
/* 1321 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String encodeUninterpretedTagsFrom(ProtocolMessage pb)
/*      */   {
/* 1329 */     UninterpretedTags utags = ProtocolSupport.getUninterpreted(pb);
/*      */ 
/* 1331 */     if (utags == null)
/*      */     {
/* 1333 */       return null;
/*      */     }
/*      */ 
/* 1336 */     ProtocolSink sink = new ProtocolSink(utags.encodingSize());
/* 1337 */     utags.put(sink);
/*      */ 
/* 1340 */     return Base64.encodeWebSafe(sink.array(), true);
/*      */   }
/*      */ 
/*      */   private void showParameterMap()
/*      */   {
/* 1348 */     List list = new ArrayList();
/* 1349 */     Iterator iterator = this.parameterSet.getParameterNames();
/* 1350 */     while (iterator.hasNext()) {
/* 1351 */       list.add(iterator.next());
/*      */     }
/* 1353 */     Collections.sort(list);
/*      */ 
/* 1355 */     this.out.println("<table border='1' cellpadding='2' summary='Arguments'>");
/* 1356 */     this.out.println("<tr><th>Parameter</th> <th>Value</th></tr>");
/* 1357 */     for (String key : list) {
/* 1358 */       String value = getParameter(key);
/* 1359 */       String ekey = escape(key);
/* 1360 */       String evalue = value.length() == 0 ? "<span class='red'>&lt;empty&gt;</span>" : escape(value);
/*      */ 
/* 1364 */       this.out.format("<tr><td><code>%s</code></td><td><code>%s</code></td></tr>\n", new Object[] { ekey, evalue });
/*      */     }
/*      */ 
/* 1367 */     this.out.println("</table>");
/*      */   }
/*      */ 
/*      */   private void showErrors()
/*      */   {
/* 1374 */     this.out.println("<table border='1' cellpadding='2' summary='Errors'>");
/*      */ 
/* 1376 */     for (String key : this.errors.keySet()) {
/* 1377 */       String value = (String)this.errors.get(key);
/* 1378 */       this.out.format("<tr><td><code>%s</code></td><td><code>%s</code></td></tr>\n", new Object[] { escape(key), escape(value) });
/*      */     }
/*      */ 
/* 1381 */     this.out.println("</table>");
/*      */   }
/*      */ 
/*      */   private boolean hasErrors()
/*      */   {
/* 1388 */     return !this.errors.isEmpty();
/*      */   }
/*      */ 
/*      */   private String getParameter(String key)
/*      */   {
/* 1398 */     return this.parameterSet.getParameter(key);
/*      */   }
/*      */ 
/*      */   private boolean hasParameter(String key)
/*      */   {
/* 1405 */     return this.parameterSet.getParameter(key) != null;
/*      */   }
/*      */ 
/*      */   private String escape(Object obj)
/*      */   {
/* 1415 */     return this.options.contains(Options.XHTML) ? CharEscapers.xmlEscaper().escape(obj.toString()) : CharEscapers.asciiHtmlEscaper().escape(obj.toString());
/*      */   }
/*      */ 
/*      */   private String unescape(String escapedString)
/*      */   {
/* 1427 */     return StringUtil.unescapeHTML(escapedString);
/*      */   }
/*      */ 
/*      */   public static enum Options
/*      */   {
/*  297 */     XHTML, 
/*      */ 
/*  299 */     DEBUG, 
/*      */ 
/*  301 */     READONLY, 
/*      */ 
/*  303 */     INCLUDE_HTTP_HEADER, 
/*      */ 
/*  305 */     EXCLUDE_HTML_HEADER_FOOTER, 
/*      */ 
/*  307 */     HTML_ESCAPE_FIELDS, 
/*      */ 
/*  309 */     LEGACY_INPUT_FORMAT, 
/*      */ 
/*  311 */     USE_TEXT_AREA, 
/*      */ 
/*  313 */     USE_INPUT_FOR_ENUM;
/*      */   }
/*      */ 
/*      */   public static class BasicFormInfo
/*      */     implements HtmlFormGenerator.FormInfo
/*      */   {
/*      */     private final String uri;
/*      */ 
/*      */     public BasicFormInfo(String uri)
/*      */     {
/*  254 */       this.uri = uri;
/*      */     }
/*      */ 
/*      */     public Map<String, String> getHiddenInputs()
/*      */     {
/*  264 */       return Maps.newHashMap();
/*      */     }
/*      */ 
/*      */     public String getURI()
/*      */     {
/*  272 */       return this.uri;
/*      */     }
/*      */ 
/*      */     public HttpHeaders.Protocol getProtocolType()
/*      */     {
/*  280 */       return HttpHeaders.Protocol.GET;
/*      */     }
/*      */ 
/*      */     public String getSubmitButtonName()
/*      */     {
/*  288 */       return "Submit";
/*      */     }
/*      */ 
/*      */     public void generatePostMessageHtml(ProtocolMessage message)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface FormInfo
/*      */   {
/*      */     public abstract Map<String, String> getHiddenInputs();
/*      */ 
/*      */     public abstract String getURI();
/*      */ 
/*      */     public abstract HttpHeaders.Protocol getProtocolType();
/*      */ 
/*      */     public abstract String getSubmitButtonName();
/*      */ 
/*      */     public abstract void generatePostMessageHtml(ProtocolMessage paramProtocolMessage);
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.HtmlFormGenerator
 * JD-Core Version:    0.6.0
 */