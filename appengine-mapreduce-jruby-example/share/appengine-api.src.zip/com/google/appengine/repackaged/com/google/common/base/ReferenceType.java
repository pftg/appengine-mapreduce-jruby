/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ 
/*    */ @GoogleInternal
/*    */ @GwtCompatible
/*    */ public enum ReferenceType
/*    */ {
/* 36 */   STRONG, 
/*    */ 
/* 44 */   SOFT, 
/*    */ 
/* 51 */   WEAK, 
/*    */ 
/* 59 */   PHANTOM;
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.ReferenceType
 * JD-Core Version:    0.6.0
 */