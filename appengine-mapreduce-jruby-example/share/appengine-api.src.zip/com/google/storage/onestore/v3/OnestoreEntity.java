/*      */ package com.google.storage.onestore.v3;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ 
/*      */ public class OnestoreEntity
/*      */ {
/*      */   public static class CompositeIndex extends ProtocolMessage<CompositeIndex>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 7631 */     private byte[] app_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 7632 */     private long id_ = 0L;
/* 7633 */     private OnestoreEntity.Index definition_ = new OnestoreEntity.Index();
/* 7634 */     private int state_ = 0;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CompositeIndex IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kapp_id = 1;
/*      */     public static final int kid = 2;
/*      */     public static final int kdefinition = 3;
/*      */     public static final int kstate = 4;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getAppIdAsBytes()
/*      */     {
/* 7665 */       return this.app_id_;
/*      */     }
/*      */     public final boolean hasAppId() {
/* 7668 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CompositeIndex clearAppId() {
/* 7671 */       this.optional_0_ &= -2;
/* 7672 */       this.app_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 7673 */       return this;
/*      */     }
/*      */     public CompositeIndex setAppIdAsBytes(byte[] x) {
/* 7676 */       this.optional_0_ |= 1;
/* 7677 */       this.app_id_ = x;
/* 7678 */       return this;
/*      */     }
/*      */     public final String getAppId() {
/* 7681 */       return ProtocolSupport.toStringUtf8(this.app_id_);
/*      */     }
/*      */     public CompositeIndex setAppId(String v) {
/* 7684 */       if (v == null) throw new NullPointerException();
/* 7685 */       this.optional_0_ |= 1;
/* 7686 */       this.app_id_ = ProtocolSupport.toBytesUtf8(v);
/* 7687 */       return this;
/*      */     }
/*      */     public final String getAppId(Charset cs) {
/* 7690 */       return ProtocolSupport.toString(this.app_id_, cs);
/*      */     }
/*      */     public CompositeIndex setAppId(String v, Charset cs) {
/* 7693 */       if (v == null) throw new NullPointerException();
/* 7694 */       this.optional_0_ |= 1;
/* 7695 */       this.app_id_ = ProtocolSupport.toBytes(v, cs);
/* 7696 */       return this;
/*      */     }
/*      */ 
/*      */     public final long getId()
/*      */     {
/* 7701 */       return this.id_;
/*      */     }
/*      */     public final boolean hasId() {
/* 7704 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public CompositeIndex clearId() {
/* 7707 */       this.optional_0_ &= -3;
/* 7708 */       this.id_ = 0L;
/* 7709 */       return this;
/*      */     }
/*      */     public CompositeIndex setId(long x) {
/* 7712 */       this.optional_0_ |= 2;
/* 7713 */       this.id_ = x;
/* 7714 */       return this;
/*      */     }
/*      */ 
/*      */     public final OnestoreEntity.Index getDefinition()
/*      */     {
/* 7719 */       return this.definition_;
/*      */     }
/*      */     public final boolean hasDefinition() {
/* 7722 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public CompositeIndex clearDefinition() {
/* 7725 */       this.optional_0_ &= -5;
/* 7726 */       this.definition_.clear();
/* 7727 */       return this;
/*      */     }
/*      */     public CompositeIndex setDefinition(OnestoreEntity.Index x) {
/* 7730 */       if (x == null) throw new NullPointerException();
/* 7731 */       this.optional_0_ |= 4;
/* 7732 */       this.definition_ = x;
/* 7733 */       return this;
/*      */     }
/*      */     public OnestoreEntity.Index getMutableDefinition() {
/* 7736 */       this.optional_0_ |= 4;
/* 7737 */       return this.definition_;
/*      */     }
/*      */ 
/*      */     public final int getState()
/*      */     {
/* 7742 */       return this.state_;
/*      */     }
/*      */     public State getStateEnum() {
/* 7745 */       return hasState() ? State.valueOf(getState()) : null;
/*      */     }
/*      */     public final boolean hasState() {
/* 7748 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public CompositeIndex clearState() {
/* 7751 */       this.optional_0_ &= -9;
/* 7752 */       this.state_ = 0;
/* 7753 */       return this;
/*      */     }
/*      */     public CompositeIndex setState(int x) {
/* 7756 */       this.optional_0_ |= 8;
/* 7757 */       this.state_ = x;
/* 7758 */       return this;
/*      */     }
/*      */     public CompositeIndex setState(State x) {
/* 7761 */       if (x == null) {
/* 7762 */         this.optional_0_ &= -9;
/* 7763 */         this.state_ = 0;
/*      */       } else {
/* 7765 */         setState(x.getValue());
/*      */       }
/* 7767 */       return this;
/*      */     }
/*      */ 
/*      */     public CompositeIndex mergeFrom(CompositeIndex that)
/*      */     {
/* 7774 */       assert (that != this);
/* 7775 */       int this_t0 = this.optional_0_;
/* 7776 */       int that_t0 = that.optional_0_;
/*      */ 
/* 7778 */       if ((that_t0 & 0x1) != 0) {
/* 7779 */         this_t0 |= 1;
/* 7780 */         this.app_id_ = that.app_id_;
/*      */       }
/*      */ 
/* 7783 */       if ((that_t0 & 0x2) != 0) {
/* 7784 */         this_t0 |= 2;
/* 7785 */         this.id_ = that.id_;
/*      */       }
/*      */ 
/* 7788 */       if ((that_t0 & 0x4) != 0) {
/* 7789 */         this_t0 |= 4;
/* 7790 */         OnestoreEntity.Index v = this.definition_;
/* 7791 */         v.mergeFrom(that.definition_);
/*      */       }
/*      */ 
/* 7794 */       if ((that_t0 & 0x8) != 0) {
/* 7795 */         this_t0 |= 8;
/* 7796 */         this.state_ = that.state_;
/*      */       }
/*      */ 
/* 7799 */       if (that.uninterpreted != null) {
/* 7800 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 7802 */       this.optional_0_ = this_t0;
/* 7803 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CompositeIndex that) {
/* 7807 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CompositeIndex that) {
/* 7811 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CompositeIndex that, boolean ignoreUninterpreted) {
/* 7815 */       if (that == null) return false;
/* 7816 */       if (that == this) return true;
/* 7817 */       int this_t0 = this.optional_0_;
/* 7818 */       int that_t0 = that.optional_0_;
/* 7819 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 7821 */       if (((this_t0 & 0x1) != 0) && 
/* 7822 */         (!Arrays.equals(this.app_id_, that.app_id_))) return false;
/*      */ 
/* 7825 */       if (((this_t0 & 0x2) != 0) && 
/* 7826 */         (this.id_ != that.id_)) return false;
/*      */ 
/* 7829 */       if (((this_t0 & 0x4) != 0) && 
/* 7830 */         (!this.definition_.equals(that.definition_, ignoreUninterpreted))) return false;
/*      */ 
/* 7833 */       if (((this_t0 & 0x8) != 0) && 
/* 7834 */         (this.state_ != that.state_)) return false;
/*      */ 
/* 7837 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 7842 */       return ((that instanceof CompositeIndex)) && (equals((CompositeIndex)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 7846 */       int hash = -774668916;
/*      */ 
/* 7848 */       int this_t0 = this.optional_0_;
/* 7849 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_id_) : -113);
/*      */ 
/* 7851 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.id_) : -113);
/*      */ 
/* 7853 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.definition_.hashCode() : -113);
/*      */ 
/* 7855 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.state_ : -113);
/* 7856 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 7857 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 7859 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 7863 */       int this_t0 = this.optional_0_;
/* 7864 */       if ((this_t0 & 0xF) != 15) {
/* 7865 */         if ((this_t0 & 0x1) == 0) {
/* 7866 */           return false;
/*      */         }
/* 7868 */         if ((this_t0 & 0x2) == 0) {
/* 7869 */           return false;
/*      */         }
/*      */ 
/* 7872 */         return (this_t0 & 0x4) != 0;
/*      */       }
/*      */ 
/* 7878 */       return this.definition_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 7888 */       int n = 4 + Protocol.stringSize(this.app_id_.length) + Protocol.varLongSize(this.id_) + Protocol.stringSize(this.definition_.encodingSize()) + Protocol.varLongSize(this.state_);
/*      */ 
/* 7893 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 7902 */       int n = 34 + this.app_id_.length + this.definition_.maxEncodingSize();
/*      */ 
/* 7904 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 7909 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 7913 */       this.optional_0_ = 0;
/* 7914 */       this.app_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 7915 */       this.id_ = 0L;
/* 7916 */       this.definition_.clear();
/* 7917 */       this.state_ = 0;
/* 7918 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CompositeIndex newInstance() {
/* 7922 */       return new CompositeIndex();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 7926 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 7961 */       sink.putByte(10);
/* 7962 */       sink.putPrefixedData(this.app_id_);
/*      */ 
/* 7964 */       sink.putByte(16);
/* 7965 */       sink.putVarLong(this.id_);
/*      */ 
/* 7967 */       sink.putByte(26);
/* 7968 */       sink.putForeign(this.definition_);
/*      */ 
/* 7970 */       sink.putByte(32);
/* 7971 */       sink.putVarLong(this.state_);
/*      */ 
/* 7973 */       if (this.uninterpreted != null)
/* 7974 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 7979 */       boolean result = true;
/* 7980 */       int this_t0 = this.optional_0_;
/*      */ 
/* 7982 */       while (source.hasRemaining()) {
/* 7983 */         int tt = source.getVarInt();
/* 7984 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 7988 */           result = false;
/* 7989 */           break;
/*      */         case 10:
/* 7992 */           this.app_id_ = source.getPrefixedData();
/* 7993 */           this_t0 |= 1;
/* 7994 */           break;
/*      */         case 16:
/* 7997 */           this.id_ = source.getVarLong();
/* 7998 */           this_t0 |= 2;
/* 7999 */           break;
/*      */         case 26:
/* 8002 */           source.push(source.getVarInt());
/* 8003 */           if (!this.definition_.merge(source)) { result = false; break label181; }
/* 8004 */           source.pop();
/* 8005 */           this_t0 |= 4;
/* 8006 */           break;
/*      */         case 32:
/* 8009 */           this.state_ = source.getVarInt();
/* 8010 */           this_t0 |= 8;
/* 8011 */           break;
/*      */         default:
/* 8013 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 8018 */       label181: this.optional_0_ = this_t0;
/* 8019 */       return result;
/*      */     }
/*      */ 
/*      */     public CompositeIndex getDefaultInstanceForType()
/*      */     {
/* 8024 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CompositeIndex getDefaultInstance() {
/* 8028 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CompositeIndex freeze()
/*      */     {
/* 8106 */       this.app_id_ = ProtocolSupport.freezeString(this.app_id_);
/* 8107 */       this.definition_.freeze();
/* 8108 */       return this;
/*      */     }
/*      */ 
/*      */     public CompositeIndex unfreeze() {
/* 8112 */       this.definition_.unfreeze();
/* 8113 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 8117 */       return this.definition_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 8120 */       if (this.uninterpreted == null) {
/* 8121 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 8123 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 8032 */       IMMUTABLE_DEFAULT_INSTANCE = new CompositeIndex()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.CompositeIndex clearAppId()
/*      */         {
/* 8040 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex setAppIdAsBytes(byte[] x) {
/* 8043 */           ProtocolSupport.unsupportedOperation();
/* 8044 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex setAppId(String v) {
/* 8047 */           ProtocolSupport.unsupportedOperation();
/* 8048 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex setAppId(String v, Charset cs) {
/* 8051 */           ProtocolSupport.unsupportedOperation();
/* 8052 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeIndex clearId()
/*      */         {
/* 8057 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex setId(long x) {
/* 8060 */           ProtocolSupport.unsupportedOperation();
/* 8061 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeIndex clearDefinition()
/*      */         {
/* 8066 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex setDefinition(OnestoreEntity.Index x) {
/* 8069 */           ProtocolSupport.unsupportedOperation();
/* 8070 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index getMutableDefinition() {
/* 8073 */           return (OnestoreEntity.Index)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeIndex clearState()
/*      */         {
/* 8078 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex setState(int x) {
/* 8081 */           ProtocolSupport.unsupportedOperation();
/* 8082 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeIndex mergeFrom(OnestoreEntity.CompositeIndex that) {
/* 8086 */           ProtocolSupport.unsupportedOperation();
/* 8087 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 8090 */           ProtocolSupport.unsupportedOperation();
/* 8091 */           return false;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex freeze() {
/* 8094 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeIndex unfreeze() {
/* 8097 */           ProtocolSupport.unsupportedOperation();
/* 8098 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 8101 */           return true;
/*      */         }
/*      */       };
/* 8131 */       text = new String[5];
/*      */ 
/* 8133 */       text[0] = "ErrorCode";
/* 8134 */       text[1] = "app_id";
/* 8135 */       text[2] = "id";
/* 8136 */       text[3] = "definition";
/* 8137 */       text[4] = "state";
/*      */ 
/* 8140 */       types = new int[5];
/*      */ 
/* 8142 */       Arrays.fill(types, 6);
/* 8143 */       types[0] = 0;
/* 8144 */       types[1] = 2;
/* 8145 */       types[2] = 0;
/* 8146 */       types[3] = 2;
/* 8147 */       types[4] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 7930 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.CompositeIndex.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app_id", "app_id", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("id", "id", 2, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("definition", "definition", 3, 2, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, OnestoreEntity.Index.class), new ProtocolType.FieldType("state", "state", 4, 3, ProtocolType.Presence.REQUIRED, OnestoreEntity.CompositeIndex.State.class) });
/*      */     }
/*      */ 
/*      */     public static enum State
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 7639 */       WRITE_ONLY(1), 
/* 7640 */       READ_WRITE(2), 
/* 7641 */       DELETED(3), 
/* 7642 */       ERROR(4);
/*      */ 
/*      */       public static final State State_MIN;
/*      */       public static final State State_MAX;
/*      */       private final int value;
/*      */ 
/* 7647 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static State valueOf(int value) {
/* 7650 */         switch (value) { case 1:
/* 7651 */           return WRITE_ONLY;
/*      */         case 2:
/* 7652 */           return READ_WRITE;
/*      */         case 3:
/* 7653 */           return DELETED;
/*      */         case 4:
/* 7654 */           return ERROR;
/*      */         }
/* 7656 */         return null;
/*      */       }
/*      */ 
/*      */       private State(int v) {
/* 7660 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 7644 */         State_MIN = WRITE_ONLY;
/* 7645 */         State_MAX = ERROR;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Index extends ProtocolMessage<Index>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 7144 */     private byte[] entity_type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 7145 */     private boolean ancestor_ = false;
/* 7146 */     private List<Property> property_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final Index IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kentity_type = 1;
/*      */     public static final int kancestor = 5;
/*      */     public static final int kPropertyGroup = 2;
/*      */     public static final int kPropertyname = 3;
/*      */     public static final int kPropertydirection = 4;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getEntityTypeAsBytes()
/*      */     {
/* 7152 */       return this.entity_type_;
/*      */     }
/*      */     public final boolean hasEntityType() {
/* 7155 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public Index clearEntityType() {
/* 7158 */       this.optional_0_ &= -2;
/* 7159 */       this.entity_type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 7160 */       return this;
/*      */     }
/*      */     public Index setEntityTypeAsBytes(byte[] x) {
/* 7163 */       this.optional_0_ |= 1;
/* 7164 */       this.entity_type_ = x;
/* 7165 */       return this;
/*      */     }
/*      */     public final String getEntityType() {
/* 7168 */       return ProtocolSupport.toStringUtf8(this.entity_type_);
/*      */     }
/*      */     public Index setEntityType(String v) {
/* 7171 */       if (v == null) throw new NullPointerException();
/* 7172 */       this.optional_0_ |= 1;
/* 7173 */       this.entity_type_ = ProtocolSupport.toBytesUtf8(v);
/* 7174 */       return this;
/*      */     }
/*      */     public final String getEntityType(Charset cs) {
/* 7177 */       return ProtocolSupport.toString(this.entity_type_, cs);
/*      */     }
/*      */     public Index setEntityType(String v, Charset cs) {
/* 7180 */       if (v == null) throw new NullPointerException();
/* 7181 */       this.optional_0_ |= 1;
/* 7182 */       this.entity_type_ = ProtocolSupport.toBytes(v, cs);
/* 7183 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isAncestor()
/*      */     {
/* 7188 */       return this.ancestor_;
/*      */     }
/*      */     public final boolean hasAncestor() {
/* 7191 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public Index clearAncestor() {
/* 7194 */       this.optional_0_ &= -3;
/* 7195 */       this.ancestor_ = false;
/* 7196 */       return this;
/*      */     }
/*      */     public Index setAncestor(boolean x) {
/* 7199 */       this.optional_0_ |= 2;
/* 7200 */       this.ancestor_ = x;
/* 7201 */       return this;
/*      */     }
/*      */ 
/*      */     public final int propertySize()
/*      */     {
/* 7206 */       return this.property_ != null ? this.property_.size() : 0;
/*      */     }
/*      */     public final Property getProperty(int i) {
/* 7209 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.property_ != null ? this.property_.size() : 0)); } else throw new AssertionError();
/* 7210 */       return (Property)this.property_.get(i);
/*      */     }
/*      */     public Index clearProperty() {
/* 7213 */       if (this.property_ != null) this.property_.clear();
/* 7214 */       return this;
/*      */     }
/*      */     public Property getMutableProperty(int i) {
/* 7217 */       assert ((i >= 0) && (this.property_ != null) && (i < this.property_.size()));
/* 7218 */       return (Property)this.property_.get(i);
/*      */     }
/*      */     public Property addProperty() {
/* 7221 */       Property v = new Property();
/* 7222 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 7223 */       this.property_.add(v);
/* 7224 */       return v;
/*      */     }
/*      */     public Property addProperty(Property v) {
/* 7227 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 7228 */       this.property_.add(v);
/* 7229 */       return v;
/*      */     }
/*      */     public Property insertProperty(int i, Property v) {
/* 7232 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 7233 */       this.property_.add(i, v);
/* 7234 */       return v;
/*      */     }
/*      */     public Property removeProperty(int i) {
/* 7237 */       return (Property)this.property_.remove(i);
/*      */     }
/*      */     public final Iterator<Property> propertyIterator() {
/* 7240 */       if (this.property_ == null) {
/* 7241 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 7243 */       return this.property_.iterator();
/*      */     }
/*      */     public final List<Property> propertys() {
/* 7246 */       return ProtocolSupport.unmodifiableList(this.property_);
/*      */     }
/*      */     public final List<Property> mutablePropertys() {
/* 7249 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 7250 */       return this.property_;
/*      */     }
/*      */ 
/*      */     public Index mergeFrom(Index that)
/*      */     {
/* 7257 */       assert (that != this);
/* 7258 */       int this_t0 = this.optional_0_;
/* 7259 */       int that_t0 = that.optional_0_;
/*      */ 
/* 7261 */       if ((that_t0 & 0x1) != 0) {
/* 7262 */         this_t0 |= 1;
/* 7263 */         this.entity_type_ = that.entity_type_;
/*      */       }
/*      */ 
/* 7266 */       if ((that_t0 & 0x2) != 0) {
/* 7267 */         this_t0 |= 2;
/* 7268 */         this.ancestor_ = that.ancestor_;
/*      */       }
/*      */ 
/* 7271 */       if (that.property_ != null) {
/* 7272 */         for (Property v : that.property_) {
/* 7273 */           addProperty().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 7277 */       if (that.uninterpreted != null) {
/* 7278 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 7280 */       this.optional_0_ = this_t0;
/* 7281 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Index that) {
/* 7285 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Index that) {
/* 7289 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Index that, boolean ignoreUninterpreted) {
/* 7293 */       if (that == null) return false;
/* 7294 */       if (that == this) return true;
/* 7295 */       int this_t0 = this.optional_0_;
/* 7296 */       int that_t0 = that.optional_0_;
/* 7297 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 7299 */       if (((this_t0 & 0x1) != 0) && 
/* 7300 */         (!Arrays.equals(this.entity_type_, that.entity_type_))) return false;
/*      */ 
/* 7303 */       if (((this_t0 & 0x2) != 0) && 
/* 7304 */         (this.ancestor_ != that.ancestor_)) return false;
/* 7308 */       int n;
/* 7308 */       if ((n = this.property_ != null ? this.property_.size() : 0) != (that.property_ != null ? that.property_.size() : 0)) return false;
/* 7309 */       for (int i = 0; i < n; i++) {
/* 7310 */         if (!((Property)this.property_.get(i)).equals((Property)that.property_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 7313 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 7318 */       return ((that instanceof Index)) && (equals((Index)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 7322 */       int hash = 1786770010;
/*      */ 
/* 7324 */       int this_t0 = this.optional_0_;
/* 7325 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.entity_type_) : -113);
/*      */ 
/* 7327 */       hash *= 31;
/* 7328 */       int i = 0; for (int n = this.property_ != null ? this.property_.size() : 0; i < n; i++) {
/* 7329 */         hash = hash * 31 + ((Property)this.property_.get(i)).hashCode();
/*      */       }
/*      */ 
/* 7332 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? 1237 : this.ancestor_ ? 1231 : -113);
/* 7333 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 7334 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 7336 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 7340 */       int this_t0 = this.optional_0_;
/* 7341 */       if ((this_t0 & 0x3) != 3)
/*      */       {
/* 7343 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/* 7348 */       if (this.property_ != null) {
/* 7349 */         for (Property v : this.property_) {
/* 7350 */           if (!v.isInitialized()) {
/* 7351 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 7355 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 7361 */       int n = 3 + Protocol.stringSize(this.entity_type_.length);
/*      */       int m;
/* 7364 */       n += (m = this.property_ != null ? this.property_.size() : 0);
/* 7365 */       for (int i = 0; i < m; i++) {
/* 7366 */         n += ((Property)this.property_.get(i)).encodingSize();
/*      */       }
/*      */ 
/* 7369 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 7376 */       int n = 8 + this.entity_type_.length;
/*      */       int m;
/* 7379 */       n += (m = this.property_ != null ? this.property_.size() : 0);
/* 7380 */       for (int i = 0; i < m; i++) {
/* 7381 */         n += ((Property)this.property_.get(i)).maxEncodingSize();
/*      */       }
/*      */ 
/* 7384 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 7389 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 7393 */       this.optional_0_ = 0;
/* 7394 */       this.entity_type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 7395 */       this.ancestor_ = false;
/* 7396 */       if (this.property_ != null) this.property_.clear();
/* 7397 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Index newInstance() {
/* 7401 */       return new Index();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 7405 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 7439 */       sink.putByte(10);
/* 7440 */       sink.putPrefixedData(this.entity_type_);
/*      */ 
/* 7442 */       int i = 0; for (int m = this.property_ != null ? this.property_.size() : 0; i < m; i++) {
/* 7443 */         Property v = (Property)this.property_.get(i);
/* 7444 */         sink.putByte(19);
/* 7445 */         v.outputTo(sink);
/*      */       }
/*      */ 
/* 7448 */       sink.putByte(40);
/* 7449 */       sink.putBoolean(this.ancestor_);
/*      */ 
/* 7451 */       if (this.uninterpreted != null)
/* 7452 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 7457 */       boolean result = true;
/* 7458 */       int this_t0 = this.optional_0_;
/*      */ 
/* 7460 */       while (source.hasRemaining()) {
/* 7461 */         int tt = source.getVarInt();
/* 7462 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 7466 */           result = false;
/* 7467 */           break;
/*      */         case 10:
/* 7470 */           this.entity_type_ = source.getPrefixedData();
/* 7471 */           this_t0 |= 1;
/* 7472 */           break;
/*      */         case 19:
/* 7475 */           if (addProperty().merge(source)) break; result = false; break;
/*      */         case 40:
/* 7479 */           this.ancestor_ = source.getBoolean();
/* 7480 */           this_t0 |= 2;
/* 7481 */           break;
/*      */         default:
/* 7483 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 7488 */       this.optional_0_ = this_t0;
/* 7489 */       return result;
/*      */     }
/*      */ 
/*      */     public Index getDefaultInstanceForType()
/*      */     {
/* 7494 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Index getDefaultInstance() {
/* 7498 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public Index freeze()
/*      */     {
/* 7575 */       this.entity_type_ = ProtocolSupport.freezeString(this.entity_type_);
/* 7576 */       this.property_ = ProtocolSupport.freezeMessages(this.property_);
/* 7577 */       return this;
/*      */     }
/*      */ 
/*      */     public Index unfreeze() {
/* 7581 */       this.property_ = ProtocolSupport.unfreezeMessages(this.property_);
/* 7582 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 7586 */       return ProtocolSupport.isFrozenMessages(this.property_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 7589 */       if (this.uninterpreted == null) {
/* 7590 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 7592 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 7502 */       IMMUTABLE_DEFAULT_INSTANCE = new Index()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.Index clearEntityType()
/*      */         {
/* 7510 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index setEntityTypeAsBytes(byte[] x) {
/* 7513 */           ProtocolSupport.unsupportedOperation();
/* 7514 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index setEntityType(String v) {
/* 7517 */           ProtocolSupport.unsupportedOperation();
/* 7518 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index setEntityType(String v, Charset cs) {
/* 7521 */           ProtocolSupport.unsupportedOperation();
/* 7522 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Index clearAncestor()
/*      */         {
/* 7527 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index setAncestor(boolean x) {
/* 7530 */           ProtocolSupport.unsupportedOperation();
/* 7531 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Index clearProperty()
/*      */         {
/* 7536 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index.Property getMutableProperty(int i) {
/* 7539 */           return (OnestoreEntity.Index.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Index.Property addProperty() {
/* 7542 */           return (OnestoreEntity.Index.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Index.Property addProperty(OnestoreEntity.Index.Property v) {
/* 7545 */           return (OnestoreEntity.Index.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Index.Property insertProperty(int i, OnestoreEntity.Index.Property v) {
/* 7548 */           return (OnestoreEntity.Index.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Index.Property removeProperty(int i) {
/* 7551 */           return (OnestoreEntity.Index.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Index mergeFrom(OnestoreEntity.Index that) {
/* 7555 */           ProtocolSupport.unsupportedOperation();
/* 7556 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 7559 */           ProtocolSupport.unsupportedOperation();
/* 7560 */           return false;
/*      */         }
/*      */         public OnestoreEntity.Index freeze() {
/* 7563 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Index unfreeze() {
/* 7566 */           ProtocolSupport.unsupportedOperation();
/* 7567 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 7570 */           return true;
/*      */         }
/*      */       };
/* 7601 */       text = new String[6];
/*      */ 
/* 7603 */       text[0] = "ErrorCode";
/* 7604 */       text[1] = "entity_type";
/* 7605 */       text[2] = "Property";
/* 7606 */       text[3] = "name";
/* 7607 */       text[4] = "direction";
/* 7608 */       text[5] = "ancestor";
/*      */ 
/* 7611 */       types = new int[6];
/*      */ 
/* 7613 */       Arrays.fill(types, 6);
/* 7614 */       types[0] = 0;
/* 7615 */       types[1] = 2;
/* 7616 */       types[2] = 3;
/* 7617 */       types[3] = 2;
/* 7618 */       types[4] = 0;
/* 7619 */       types[5] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 7409 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.Index.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("entity_type", "entity_type", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("ancestor", "ancestor", 5, 1, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("Property", "property", 2, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, OnestoreEntity.Index.Property.class) });
/*      */     }
/*      */ 
/*      */     public static class Property extends ProtocolMessage<Property>
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/* 6794 */       private byte[] name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 6795 */       private int direction_ = 1;
/*      */       private UninterpretedTags uninterpreted;
/*      */       private int optional_0_;
/*      */       public static final Property IMMUTABLE_DEFAULT_INSTANCE;
/*      */ 
/*      */       public final byte[] getNameAsBytes()
/*      */       {
/* 6822 */         return this.name_;
/*      */       }
/*      */       public final boolean hasName() {
/* 6825 */         return (this.optional_0_ & 0x1) != 0;
/*      */       }
/*      */       public Property clearName() {
/* 6828 */         this.optional_0_ &= -2;
/* 6829 */         this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 6830 */         return this;
/*      */       }
/*      */       public Property setNameAsBytes(byte[] x) {
/* 6833 */         this.optional_0_ |= 1;
/* 6834 */         this.name_ = x;
/* 6835 */         return this;
/*      */       }
/*      */       public final String getName() {
/* 6838 */         return ProtocolSupport.toStringUtf8(this.name_);
/*      */       }
/*      */       public Property setName(String v) {
/* 6841 */         if (v == null) throw new NullPointerException();
/* 6842 */         this.optional_0_ |= 1;
/* 6843 */         this.name_ = ProtocolSupport.toBytesUtf8(v);
/* 6844 */         return this;
/*      */       }
/*      */       public final String getName(Charset cs) {
/* 6847 */         return ProtocolSupport.toString(this.name_, cs);
/*      */       }
/*      */       public Property setName(String v, Charset cs) {
/* 6850 */         if (v == null) throw new NullPointerException();
/* 6851 */         this.optional_0_ |= 1;
/* 6852 */         this.name_ = ProtocolSupport.toBytes(v, cs);
/* 6853 */         return this;
/*      */       }
/*      */ 
/*      */       public final int getDirection()
/*      */       {
/* 6858 */         return this.direction_;
/*      */       }
/*      */       public Direction getDirectionEnum() {
/* 6861 */         return Direction.valueOf(getDirection());
/*      */       }
/*      */       public final boolean hasDirection() {
/* 6864 */         return (this.optional_0_ & 0x2) != 0;
/*      */       }
/*      */       public Property clearDirection() {
/* 6867 */         this.optional_0_ &= -3;
/* 6868 */         this.direction_ = 1;
/* 6869 */         return this;
/*      */       }
/*      */       public Property setDirection(int x) {
/* 6872 */         this.optional_0_ |= 2;
/* 6873 */         this.direction_ = x;
/* 6874 */         return this;
/*      */       }
/*      */       public Property setDirection(Direction x) {
/* 6877 */         if (x == null) {
/* 6878 */           this.optional_0_ &= -3;
/* 6879 */           this.direction_ = 1;
/*      */         } else {
/* 6881 */           setDirection(x.getValue());
/*      */         }
/* 6883 */         return this;
/*      */       }
/*      */ 
/*      */       public Property mergeFrom(Property that)
/*      */       {
/* 6890 */         assert (that != this);
/* 6891 */         int this_t0 = this.optional_0_;
/* 6892 */         int that_t0 = that.optional_0_;
/*      */ 
/* 6894 */         if ((that_t0 & 0x1) != 0) {
/* 6895 */           this_t0 |= 1;
/* 6896 */           this.name_ = that.name_;
/*      */         }
/*      */ 
/* 6899 */         if ((that_t0 & 0x2) != 0) {
/* 6900 */           this_t0 |= 2;
/* 6901 */           this.direction_ = that.direction_;
/*      */         }
/*      */ 
/* 6904 */         if (that.uninterpreted != null) {
/* 6905 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */         }
/* 6907 */         this.optional_0_ = this_t0;
/* 6908 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean equalsIgnoreUninterpreted(Property that) {
/* 6912 */         return equals(that, true);
/*      */       }
/*      */ 
/*      */       public boolean equals(Property that) {
/* 6916 */         return equals(that, false);
/*      */       }
/*      */ 
/*      */       public boolean equals(Property that, boolean ignoreUninterpreted) {
/* 6920 */         if (that == null) return false;
/* 6921 */         if (that == this) return true;
/* 6922 */         int this_t0 = this.optional_0_;
/* 6923 */         int that_t0 = that.optional_0_;
/* 6924 */         if (this_t0 != that_t0) return false;
/*      */ 
/* 6926 */         if (((this_t0 & 0x1) != 0) && 
/* 6927 */           (!Arrays.equals(this.name_, that.name_))) return false;
/*      */ 
/* 6930 */         if (((this_t0 & 0x2) != 0) && 
/* 6931 */           (this.direction_ != that.direction_)) return false;
/*      */ 
/* 6934 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object that)
/*      */       {
/* 6939 */         return ((that instanceof Property)) && (equals((Property)that));
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/* 6943 */         int hash = -1811859523;
/*      */ 
/* 6945 */         int this_t0 = this.optional_0_;
/* 6946 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.name_) : -113);
/*      */ 
/* 6948 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.direction_ : -113);
/* 6949 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 6950 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*      */         }
/* 6952 */         return hash;
/*      */       }
/*      */ 
/*      */       public boolean isInitialized() {
/* 6956 */         int this_t0 = this.optional_0_;
/*      */ 
/* 6958 */         return (this_t0 & 0x1) == 1;
/*      */       }
/*      */ 
/*      */       public int encodingSize()
/*      */       {
/* 6966 */         int n = 2 + Protocol.stringSize(this.name_.length);
/* 6967 */         int this_t0 = this.optional_0_;
/* 6968 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 6970 */           n += 1 + Protocol.varLongSize(this.direction_);
/*      */         }
/*      */ 
/* 6973 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */       }
/*      */ 
/*      */       public int maxEncodingSize()
/*      */       {
/* 6981 */         int n = 18 + this.name_.length;
/*      */ 
/* 6983 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */       }
/*      */ 
/*      */       public MessageAppender getMessageAppender()
/*      */       {
/* 6988 */         return getUninterpretedForWrite();
/*      */       }
/*      */ 
/*      */       public void clear() {
/* 6992 */         this.optional_0_ = 0;
/* 6993 */         this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 6994 */         this.direction_ = 1;
/* 6995 */         this.uninterpreted = null;
/*      */       }
/*      */ 
/*      */       public Property newInstance() {
/* 6999 */         return new Property();
/*      */       }
/*      */ 
/*      */       public ProtocolType getProtocolType() {
/* 7003 */         return StaticHolder.protocolType;
/*      */       }
/*      */ 
/*      */       public void outputTo(ProtocolSink sink)
/*      */       {
/* 7018 */         sink.putByte(26);
/* 7019 */         sink.putPrefixedData(this.name_);
/*      */ 
/* 7021 */         int this_t0 = this.optional_0_;
/* 7022 */         if ((this_t0 & 0x2) != 0) {
/* 7023 */           sink.putByte(32);
/* 7024 */           sink.putVarLong(this.direction_);
/*      */         }
/*      */ 
/* 7027 */         if (this.uninterpreted != null) {
/* 7028 */           this.uninterpreted.put(sink);
/*      */         }
/*      */ 
/* 7031 */         sink.putByte(20);
/*      */       }
/*      */ 
/*      */       public boolean merge(ProtocolSource source) {
/* 7035 */         boolean result = true;
/* 7036 */         int this_t0 = this.optional_0_;
/*      */         while (true)
/*      */         {
/* 7039 */           int tt = source.getVarInt();
/* 7040 */           switch (tt)
/*      */           {
/*      */           case 20:
/* 7043 */             break;
/*      */           case 0:
/* 7047 */             result = false;
/* 7048 */             break;
/*      */           case 26:
/* 7051 */             this.name_ = source.getPrefixedData();
/* 7052 */             this_t0 |= 1;
/* 7053 */             break;
/*      */           case 32:
/* 7056 */             this.direction_ = source.getVarInt();
/* 7057 */             this_t0 |= 2;
/* 7058 */             break;
/*      */           default:
/* 7060 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 7065 */         this.optional_0_ = this_t0;
/* 7066 */         return result;
/*      */       }
/*      */ 
/*      */       public Property getDefaultInstanceForType()
/*      */       {
/* 7071 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public static final Property getDefaultInstance() {
/* 7075 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public Property freeze()
/*      */       {
/* 7132 */         this.name_ = ProtocolSupport.freezeString(this.name_);
/* 7133 */         return this;
/*      */       }
/*      */       public UninterpretedTags getUninterpretedForWrite() {
/* 7136 */         if (this.uninterpreted == null) {
/* 7137 */           this.uninterpreted = new UninterpretedTags();
/*      */         }
/* 7139 */         return this.uninterpreted;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 7079 */         IMMUTABLE_DEFAULT_INSTANCE = new Property()
/*      */         {
/*      */           private static final long serialVersionUID = 1L;
/*      */ 
/*      */           public OnestoreEntity.Index.Property clearName()
/*      */           {
/* 7087 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Index.Property setNameAsBytes(byte[] x) {
/* 7090 */             ProtocolSupport.unsupportedOperation();
/* 7091 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Index.Property setName(String v) {
/* 7094 */             ProtocolSupport.unsupportedOperation();
/* 7095 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Index.Property setName(String v, Charset cs) {
/* 7098 */             ProtocolSupport.unsupportedOperation();
/* 7099 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.Index.Property clearDirection()
/*      */           {
/* 7104 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Index.Property setDirection(int x) {
/* 7107 */             ProtocolSupport.unsupportedOperation();
/* 7108 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.Index.Property mergeFrom(OnestoreEntity.Index.Property that) {
/* 7112 */             ProtocolSupport.unsupportedOperation();
/* 7113 */             return this;
/*      */           }
/*      */           public boolean merge(ProtocolSource source) {
/* 7116 */             ProtocolSupport.unsupportedOperation();
/* 7117 */             return false;
/*      */           }
/*      */           public OnestoreEntity.Index.Property freeze() {
/* 7120 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Index.Property unfreeze() {
/* 7123 */             ProtocolSupport.unsupportedOperation();
/* 7124 */             return this;
/*      */           }
/*      */           public boolean isFrozen() {
/* 7127 */             return true;
/*      */           }
/*      */         };
/*      */       }
/*      */ 
/*      */       private static class StaticHolder
/*      */       {
/* 7007 */         private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.Index.Property.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("name", "name", 3, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("direction", "direction", 4, 1, ProtocolType.Presence.OPTIONAL, OnestoreEntity.Index.Property.Direction.class) });
/*      */       }
/*      */ 
/*      */       public static enum Direction
/*      */         implements ProtocolMessageEnum
/*      */       {
/* 6800 */         ASCENDING(1), 
/* 6801 */         DESCENDING(2);
/*      */ 
/*      */         public static final Direction Direction_MIN;
/*      */         public static final Direction Direction_MAX;
/*      */         private final int value;
/*      */ 
/* 6806 */         public int getValue() { return this.value; }
/*      */ 
/*      */         public static Direction valueOf(int value) {
/* 6809 */           switch (value) { case 1:
/* 6810 */             return ASCENDING;
/*      */           case 2:
/* 6811 */             return DESCENDING;
/*      */           }
/* 6813 */           return null;
/*      */         }
/*      */ 
/*      */         private Direction(int v) {
/* 6817 */           this.value = v;
/*      */         }
/*      */ 
/*      */         static
/*      */         {
/* 6803 */           Direction_MIN = ASCENDING;
/* 6804 */           Direction_MAX = DESCENDING;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CompositeProperty extends ProtocolMessage<CompositeProperty>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 6372 */     private long index_id_ = 0L;
/* 6373 */     private List<byte[]> value_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CompositeProperty IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kindex_id = 1;
/*      */     public static final int kvalue = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final long getIndexId()
/*      */     {
/* 6379 */       return this.index_id_;
/*      */     }
/*      */     public final boolean hasIndexId() {
/* 6382 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CompositeProperty clearIndexId() {
/* 6385 */       this.optional_0_ &= -2;
/* 6386 */       this.index_id_ = 0L;
/* 6387 */       return this;
/*      */     }
/*      */     public CompositeProperty setIndexId(long x) {
/* 6390 */       this.optional_0_ |= 1;
/* 6391 */       this.index_id_ = x;
/* 6392 */       return this;
/*      */     }
/*      */ 
/*      */     public final int valueSize()
/*      */     {
/* 6397 */       return this.value_ != null ? this.value_.size() : 0;
/*      */     }
/*      */     public final byte[] getValueAsBytes(int i) {
/* 6400 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.value_ != null ? this.value_.size() : 0)); } else throw new AssertionError();
/* 6401 */       return (byte[])this.value_.get(i);
/*      */     }
/*      */     public CompositeProperty clearValue() {
/* 6404 */       if (this.value_ != null) this.value_.clear();
/* 6405 */       return this;
/*      */     }
/*      */     public final String getValue(int i) {
/* 6408 */       return ProtocolSupport.toStringUtf8((byte[])this.value_.get(i));
/*      */     }
/*      */     public CompositeProperty setValueAsBytes(int i, byte[] v) {
/* 6411 */       this.value_.set(i, v);
/* 6412 */       return this;
/*      */     }
/*      */     public CompositeProperty setValue(int i, String v) {
/* 6415 */       if (v == null) throw new NullPointerException();
/* 6416 */       this.value_.set(i, ProtocolSupport.toBytesUtf8(v));
/* 6417 */       return this;
/*      */     }
/*      */     public CompositeProperty addValueAsBytes(byte[] v) {
/* 6420 */       if (this.value_ == null) this.value_ = new ArrayList(4);
/* 6421 */       this.value_.add(v);
/* 6422 */       return this;
/*      */     }
/*      */     public CompositeProperty addValue(String v) {
/* 6425 */       if (v == null) throw new NullPointerException();
/* 6426 */       if (this.value_ == null) this.value_ = new ArrayList(4);
/* 6427 */       this.value_.add(ProtocolSupport.toBytesUtf8(v));
/* 6428 */       return this;
/*      */     }
/*      */     public final Iterator<String> valueIterator() {
/* 6431 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.value_);
/*      */     }
/*      */     public final List<String> values() {
/* 6434 */       return ProtocolSupport.byteArrayToUnicodeList(this.value_);
/*      */     }
/*      */     public final Iterator<byte[]> valueAsBytesIterator() {
/* 6437 */       return this.value_ == null ? ProtocolSupport.emptyIterator() : this.value_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> valuesAsBytes()
/*      */     {
/* 6442 */       return ProtocolSupport.unmodifiableList(this.value_);
/*      */     }
/*      */     public final List<byte[]> mutableValuesAsBytes() {
/* 6445 */       if (this.value_ == null) this.value_ = new ArrayList(4);
/* 6446 */       return this.value_;
/*      */     }
/*      */     public final String getValue(int i, Charset cs) {
/* 6449 */       return ProtocolSupport.toString((byte[])this.value_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public CompositeProperty setValue(int i, String v, Charset cs) {
/* 6453 */       if (v == null) throw new NullPointerException();
/* 6454 */       this.value_.set(i, ProtocolSupport.toBytes(v, cs));
/* 6455 */       return this;
/*      */     }
/*      */ 
/*      */     public CompositeProperty addValue(String v, Charset cs) {
/* 6459 */       if (v == null) throw new NullPointerException();
/* 6460 */       if (this.value_ == null) this.value_ = new ArrayList(4);
/* 6461 */       this.value_.add(ProtocolSupport.toBytes(v, cs));
/* 6462 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> valueIterator(Charset cs) {
/* 6466 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.value_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> values(Charset cs) {
/* 6470 */       return ProtocolSupport.byteArrayToUnicodeList(this.value_, cs);
/*      */     }
/*      */ 
/*      */     public CompositeProperty mergeFrom(CompositeProperty that)
/*      */     {
/* 6477 */       assert (that != this);
/* 6478 */       int this_t0 = this.optional_0_;
/* 6479 */       int that_t0 = that.optional_0_;
/*      */ 
/* 6481 */       if ((that_t0 & 0x1) != 0) {
/* 6482 */         this_t0 |= 1;
/* 6483 */         this.index_id_ = that.index_id_;
/*      */       }
/*      */ 
/* 6486 */       if ((that.value_ != null) && (that.value_.size() > 0)) {
/* 6487 */         if (this.value_ == null)
/* 6488 */           this.value_ = new ArrayList(that.value_);
/*      */         else {
/* 6490 */           this.value_.addAll(that.value_);
/*      */         }
/*      */       }
/*      */ 
/* 6494 */       if (that.uninterpreted != null) {
/* 6495 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 6497 */       this.optional_0_ = this_t0;
/* 6498 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CompositeProperty that) {
/* 6502 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CompositeProperty that) {
/* 6506 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CompositeProperty that, boolean ignoreUninterpreted) {
/* 6510 */       if (that == null) return false;
/* 6511 */       if (that == this) return true;
/* 6512 */       int this_t0 = this.optional_0_;
/* 6513 */       int that_t0 = that.optional_0_;
/* 6514 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 6516 */       if (((this_t0 & 0x1) != 0) && 
/* 6517 */         (this.index_id_ != that.index_id_)) return false;
/* 6521 */       int n;
/* 6521 */       if ((n = this.value_ != null ? this.value_.size() : 0) != (that.value_ != null ? that.value_.size() : 0)) return false;
/* 6522 */       for (int i = 0; i < n; i++) {
/* 6523 */         if (!Arrays.equals((byte[])this.value_.get(i), (byte[])that.value_.get(i))) return false;
/*      */       }
/*      */ 
/* 6526 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 6531 */       return ((that instanceof CompositeProperty)) && (equals((CompositeProperty)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 6535 */       int hash = -203795551;
/*      */ 
/* 6537 */       int this_t0 = this.optional_0_;
/* 6538 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.index_id_) : -113);
/*      */ 
/* 6540 */       hash *= 31;
/* 6541 */       int i = 0; for (int n = this.value_ != null ? this.value_.size() : 0; i < n; i++) {
/* 6542 */         hash = hash * 31 + Arrays.hashCode((byte[])this.value_.get(i));
/*      */       }
/* 6544 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 6545 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 6547 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 6551 */       int this_t0 = this.optional_0_;
/*      */ 
/* 6553 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 6560 */       int n = 1 + Protocol.varLongSize(this.index_id_);
/*      */       int m;
/* 6563 */       n += (m = this.value_ != null ? this.value_.size() : 0);
/* 6564 */       for (int i = 0; i < m; i++) {
/* 6565 */         n += Protocol.stringSize(((byte[])this.value_.get(i)).length);
/*      */       }
/*      */ 
/* 6568 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 6574 */       int n = 11;
/*      */       int m;
/* 6577 */       n += 6 * (m = this.value_ != null ? this.value_.size() : 0);
/* 6578 */       for (int i = 0; i < m; i++) {
/* 6579 */         n += ((byte[])this.value_.get(i)).length;
/*      */       }
/*      */ 
/* 6582 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 6587 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 6591 */       this.optional_0_ = 0;
/* 6592 */       this.index_id_ = 0L;
/* 6593 */       if (this.value_ != null) this.value_.clear();
/* 6594 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CompositeProperty newInstance() {
/* 6598 */       return new CompositeProperty();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 6602 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 6624 */       sink.putByte(8);
/* 6625 */       sink.putVarLong(this.index_id_);
/*      */ 
/* 6627 */       int i = 0; for (int m = this.value_ != null ? this.value_.size() : 0; i < m; i++) {
/* 6628 */         byte[] v = (byte[])this.value_.get(i);
/* 6629 */         sink.putByte(18);
/* 6630 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 6633 */       if (this.uninterpreted != null)
/* 6634 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 6639 */       boolean result = true;
/* 6640 */       int this_t0 = this.optional_0_;
/*      */ 
/* 6642 */       while (source.hasRemaining()) {
/* 6643 */         int tt = source.getVarInt();
/* 6644 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 6648 */           result = false;
/* 6649 */           break;
/*      */         case 8:
/* 6652 */           this.index_id_ = source.getVarLong();
/* 6653 */           this_t0 |= 1;
/* 6654 */           break;
/*      */         case 18:
/* 6657 */           addValueAsBytes(source.getPrefixedData());
/* 6658 */           break;
/*      */         default:
/* 6660 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 6665 */       this.optional_0_ = this_t0;
/* 6666 */       return result;
/*      */     }
/*      */ 
/*      */     public CompositeProperty getDefaultInstanceForType()
/*      */     {
/* 6671 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CompositeProperty getDefaultInstance() {
/* 6675 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CompositeProperty freeze()
/*      */     {
/* 6746 */       this.value_ = ProtocolSupport.freezeStrings(this.value_);
/* 6747 */       return this;
/*      */     }
/*      */ 
/*      */     public CompositeProperty unfreeze() {
/* 6751 */       this.value_ = ProtocolSupport.unfreezeStrings(this.value_);
/* 6752 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 6756 */       return ProtocolSupport.isFrozenStrings(this.value_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 6759 */       if (this.uninterpreted == null) {
/* 6760 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 6762 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6679 */       IMMUTABLE_DEFAULT_INSTANCE = new CompositeProperty()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.CompositeProperty clearIndexId()
/*      */         {
/* 6687 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty setIndexId(long x) {
/* 6690 */           ProtocolSupport.unsupportedOperation();
/* 6691 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeProperty clearValue()
/*      */         {
/* 6696 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty setValueAsBytes(int i, byte[] v) {
/* 6699 */           ProtocolSupport.unsupportedOperation();
/* 6700 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty setValue(int i, String v) {
/* 6703 */           ProtocolSupport.unsupportedOperation();
/* 6704 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty addValueAsBytes(byte[] v) {
/* 6707 */           ProtocolSupport.unsupportedOperation();
/* 6708 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty addValue(String v) {
/* 6711 */           ProtocolSupport.unsupportedOperation();
/* 6712 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeProperty setValue(int i, String v, Charset cs) {
/* 6716 */           ProtocolSupport.unsupportedOperation();
/* 6717 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeProperty addValue(String v, Charset cs) {
/* 6721 */           ProtocolSupport.unsupportedOperation();
/* 6722 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.CompositeProperty mergeFrom(OnestoreEntity.CompositeProperty that) {
/* 6726 */           ProtocolSupport.unsupportedOperation();
/* 6727 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 6730 */           ProtocolSupport.unsupportedOperation();
/* 6731 */           return false;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty freeze() {
/* 6734 */           return this;
/*      */         }
/*      */         public OnestoreEntity.CompositeProperty unfreeze() {
/* 6737 */           ProtocolSupport.unsupportedOperation();
/* 6738 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 6741 */           return true;
/*      */         }
/*      */       };
/* 6768 */       text = new String[3];
/*      */ 
/* 6770 */       text[0] = "ErrorCode";
/* 6771 */       text[1] = "index_id";
/* 6772 */       text[2] = "value";
/*      */ 
/* 6775 */       types = new int[3];
/*      */ 
/* 6777 */       Arrays.fill(types, 6);
/* 6778 */       types[0] = 0;
/* 6779 */       types[1] = 0;
/* 6780 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 6606 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.CompositeProperty.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("index_id", "index_id", 1, 0, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("value", "value", 2, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class EntityProto extends ProtocolMessage<EntityProto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 5460 */     private OnestoreEntity.Reference key_ = new OnestoreEntity.Reference();
/* 5461 */     private OnestoreEntity.Path entity_group_ = new OnestoreEntity.Path();
/* 5462 */     private OnestoreEntity.User owner_ = null;
/* 5463 */     private int kind_ = 0;
/* 5464 */     private byte[] kind_uri_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5465 */     private List<OnestoreEntity.Property> property_ = null;
/* 5466 */     private List<OnestoreEntity.Property> raw_property_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final EntityProto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kkey = 13;
/*      */     public static final int kentity_group = 16;
/*      */     public static final int kowner = 17;
/*      */     public static final int kkind = 4;
/*      */     public static final int kkind_uri = 5;
/*      */     public static final int kproperty = 14;
/*      */     public static final int kraw_property = 15;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final OnestoreEntity.Reference getKey()
/*      */     {
/* 5495 */       return this.key_;
/*      */     }
/*      */     public final boolean hasKey() {
/* 5498 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public EntityProto clearKey() {
/* 5501 */       this.optional_0_ &= -2;
/* 5502 */       this.key_.clear();
/* 5503 */       return this;
/*      */     }
/*      */     public EntityProto setKey(OnestoreEntity.Reference x) {
/* 5506 */       if (x == null) throw new NullPointerException();
/* 5507 */       this.optional_0_ |= 1;
/* 5508 */       this.key_ = x;
/* 5509 */       return this;
/*      */     }
/*      */     public OnestoreEntity.Reference getMutableKey() {
/* 5512 */       this.optional_0_ |= 1;
/* 5513 */       return this.key_;
/*      */     }
/*      */ 
/*      */     public final OnestoreEntity.Path getEntityGroup()
/*      */     {
/* 5518 */       return this.entity_group_;
/*      */     }
/*      */     public final boolean hasEntityGroup() {
/* 5521 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public EntityProto clearEntityGroup() {
/* 5524 */       this.optional_0_ &= -3;
/* 5525 */       this.entity_group_.clear();
/* 5526 */       return this;
/*      */     }
/*      */     public EntityProto setEntityGroup(OnestoreEntity.Path x) {
/* 5529 */       if (x == null) throw new NullPointerException();
/* 5530 */       this.optional_0_ |= 2;
/* 5531 */       this.entity_group_ = x;
/* 5532 */       return this;
/*      */     }
/*      */     public OnestoreEntity.Path getMutableEntityGroup() {
/* 5535 */       this.optional_0_ |= 2;
/* 5536 */       return this.entity_group_;
/*      */     }
/*      */ 
/*      */     public final OnestoreEntity.User getOwner()
/*      */     {
/* 5541 */       if (this.owner_ == null) {
/* 5542 */         return OnestoreEntity.User.IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/* 5544 */       return this.owner_;
/*      */     }
/*      */     public final boolean hasOwner() {
/* 5547 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public EntityProto clearOwner() {
/* 5550 */       this.optional_0_ &= -5;
/* 5551 */       if (this.owner_ != null) this.owner_.clear();
/* 5552 */       return this;
/*      */     }
/*      */     public EntityProto setOwner(OnestoreEntity.User x) {
/* 5555 */       if (x == null) throw new NullPointerException();
/* 5556 */       this.optional_0_ |= 4;
/* 5557 */       this.owner_ = x;
/* 5558 */       return this;
/*      */     }
/*      */     public OnestoreEntity.User getMutableOwner() {
/* 5561 */       this.optional_0_ |= 4;
/* 5562 */       if (this.owner_ == null) this.owner_ = new OnestoreEntity.User();
/* 5563 */       return this.owner_;
/*      */     }
/*      */ 
/*      */     public final int getKind()
/*      */     {
/* 5568 */       return this.kind_;
/*      */     }
/*      */     public Kind getKindEnum() {
/* 5571 */       return Kind.valueOf(getKind());
/*      */     }
/*      */     public final boolean hasKind() {
/* 5574 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public EntityProto clearKind() {
/* 5577 */       this.optional_0_ &= -9;
/* 5578 */       this.kind_ = 0;
/* 5579 */       return this;
/*      */     }
/*      */     public EntityProto setKind(int x) {
/* 5582 */       this.optional_0_ |= 8;
/* 5583 */       this.kind_ = x;
/* 5584 */       return this;
/*      */     }
/*      */     public EntityProto setKind(Kind x) {
/* 5587 */       if (x == null) {
/* 5588 */         this.optional_0_ &= -9;
/* 5589 */         this.kind_ = 0;
/*      */       } else {
/* 5591 */         setKind(x.getValue());
/*      */       }
/* 5593 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getKindUriAsBytes()
/*      */     {
/* 5598 */       return this.kind_uri_;
/*      */     }
/*      */     public final boolean hasKindUri() {
/* 5601 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public EntityProto clearKindUri() {
/* 5604 */       this.optional_0_ &= -17;
/* 5605 */       this.kind_uri_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5606 */       return this;
/*      */     }
/*      */     public EntityProto setKindUriAsBytes(byte[] x) {
/* 5609 */       this.optional_0_ |= 16;
/* 5610 */       this.kind_uri_ = x;
/* 5611 */       return this;
/*      */     }
/*      */     public final String getKindUri() {
/* 5614 */       return ProtocolSupport.toStringUtf8(this.kind_uri_);
/*      */     }
/*      */     public EntityProto setKindUri(String v) {
/* 5617 */       if (v == null) throw new NullPointerException();
/* 5618 */       this.optional_0_ |= 16;
/* 5619 */       this.kind_uri_ = ProtocolSupport.toBytesUtf8(v);
/* 5620 */       return this;
/*      */     }
/*      */     public final String getKindUri(Charset cs) {
/* 5623 */       return ProtocolSupport.toString(this.kind_uri_, cs);
/*      */     }
/*      */     public EntityProto setKindUri(String v, Charset cs) {
/* 5626 */       if (v == null) throw new NullPointerException();
/* 5627 */       this.optional_0_ |= 16;
/* 5628 */       this.kind_uri_ = ProtocolSupport.toBytes(v, cs);
/* 5629 */       return this;
/*      */     }
/*      */ 
/*      */     public final int propertySize()
/*      */     {
/* 5634 */       return this.property_ != null ? this.property_.size() : 0;
/*      */     }
/*      */     public final OnestoreEntity.Property getProperty(int i) {
/* 5637 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.property_ != null ? this.property_.size() : 0)); } else throw new AssertionError();
/* 5638 */       return (OnestoreEntity.Property)this.property_.get(i);
/*      */     }
/*      */     public EntityProto clearProperty() {
/* 5641 */       if (this.property_ != null) this.property_.clear();
/* 5642 */       return this;
/*      */     }
/*      */     public OnestoreEntity.Property getMutableProperty(int i) {
/* 5645 */       assert ((i >= 0) && (this.property_ != null) && (i < this.property_.size()));
/* 5646 */       return (OnestoreEntity.Property)this.property_.get(i);
/*      */     }
/*      */     public OnestoreEntity.Property addProperty() {
/* 5649 */       OnestoreEntity.Property v = new OnestoreEntity.Property();
/* 5650 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 5651 */       this.property_.add(v);
/* 5652 */       return v;
/*      */     }
/*      */     public OnestoreEntity.Property addProperty(OnestoreEntity.Property v) {
/* 5655 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 5656 */       this.property_.add(v);
/* 5657 */       return v;
/*      */     }
/*      */     public OnestoreEntity.Property insertProperty(int i, OnestoreEntity.Property v) {
/* 5660 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 5661 */       this.property_.add(i, v);
/* 5662 */       return v;
/*      */     }
/*      */     public OnestoreEntity.Property removeProperty(int i) {
/* 5665 */       return (OnestoreEntity.Property)this.property_.remove(i);
/*      */     }
/*      */     public final Iterator<OnestoreEntity.Property> propertyIterator() {
/* 5668 */       if (this.property_ == null) {
/* 5669 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 5671 */       return this.property_.iterator();
/*      */     }
/*      */     public final List<OnestoreEntity.Property> propertys() {
/* 5674 */       return ProtocolSupport.unmodifiableList(this.property_);
/*      */     }
/*      */     public final List<OnestoreEntity.Property> mutablePropertys() {
/* 5677 */       if (this.property_ == null) this.property_ = new ArrayList(4);
/* 5678 */       return this.property_;
/*      */     }
/*      */ 
/*      */     public final int rawPropertySize()
/*      */     {
/* 5683 */       return this.raw_property_ != null ? this.raw_property_.size() : 0;
/*      */     }
/*      */     public final OnestoreEntity.Property getRawProperty(int i) {
/* 5686 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.raw_property_ != null ? this.raw_property_.size() : 0)); } else throw new AssertionError();
/* 5687 */       return (OnestoreEntity.Property)this.raw_property_.get(i);
/*      */     }
/*      */     public EntityProto clearRawProperty() {
/* 5690 */       if (this.raw_property_ != null) this.raw_property_.clear();
/* 5691 */       return this;
/*      */     }
/*      */     public OnestoreEntity.Property getMutableRawProperty(int i) {
/* 5694 */       assert ((i >= 0) && (this.raw_property_ != null) && (i < this.raw_property_.size()));
/* 5695 */       return (OnestoreEntity.Property)this.raw_property_.get(i);
/*      */     }
/*      */     public OnestoreEntity.Property addRawProperty() {
/* 5698 */       OnestoreEntity.Property v = new OnestoreEntity.Property();
/* 5699 */       if (this.raw_property_ == null) this.raw_property_ = new ArrayList(4);
/* 5700 */       this.raw_property_.add(v);
/* 5701 */       return v;
/*      */     }
/*      */     public OnestoreEntity.Property addRawProperty(OnestoreEntity.Property v) {
/* 5704 */       if (this.raw_property_ == null) this.raw_property_ = new ArrayList(4);
/* 5705 */       this.raw_property_.add(v);
/* 5706 */       return v;
/*      */     }
/*      */     public OnestoreEntity.Property insertRawProperty(int i, OnestoreEntity.Property v) {
/* 5709 */       if (this.raw_property_ == null) this.raw_property_ = new ArrayList(4);
/* 5710 */       this.raw_property_.add(i, v);
/* 5711 */       return v;
/*      */     }
/*      */     public OnestoreEntity.Property removeRawProperty(int i) {
/* 5714 */       return (OnestoreEntity.Property)this.raw_property_.remove(i);
/*      */     }
/*      */     public final Iterator<OnestoreEntity.Property> rawPropertyIterator() {
/* 5717 */       if (this.raw_property_ == null) {
/* 5718 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 5720 */       return this.raw_property_.iterator();
/*      */     }
/*      */     public final List<OnestoreEntity.Property> rawPropertys() {
/* 5723 */       return ProtocolSupport.unmodifiableList(this.raw_property_);
/*      */     }
/*      */     public final List<OnestoreEntity.Property> mutableRawPropertys() {
/* 5726 */       if (this.raw_property_ == null) this.raw_property_ = new ArrayList(4);
/* 5727 */       return this.raw_property_;
/*      */     }
/*      */ 
/*      */     public EntityProto mergeFrom(EntityProto that)
/*      */     {
/* 5734 */       assert (that != this);
/* 5735 */       int this_t0 = this.optional_0_;
/* 5736 */       int that_t0 = that.optional_0_;
/*      */ 
/* 5738 */       if ((that_t0 & 0x1) != 0) {
/* 5739 */         this_t0 |= 1;
/* 5740 */         OnestoreEntity.Reference v = this.key_;
/* 5741 */         v.mergeFrom(that.key_);
/*      */       }
/*      */ 
/* 5744 */       if ((that_t0 & 0x2) != 0) {
/* 5745 */         this_t0 |= 2;
/* 5746 */         OnestoreEntity.Path v = this.entity_group_;
/* 5747 */         v.mergeFrom(that.entity_group_);
/*      */       }
/*      */ 
/* 5750 */       if ((that_t0 & 0x4) != 0) {
/* 5751 */         this_t0 |= 4;
/* 5752 */         OnestoreEntity.User v = this.owner_;
/* 5753 */         if (v == null) this.owner_ = (v = new OnestoreEntity.User());
/* 5754 */         v.mergeFrom(that.owner_);
/*      */       }
/*      */ 
/* 5757 */       if ((that_t0 & 0x8) != 0) {
/* 5758 */         this_t0 |= 8;
/* 5759 */         this.kind_ = that.kind_;
/*      */       }
/*      */ 
/* 5762 */       if ((that_t0 & 0x10) != 0) {
/* 5763 */         this_t0 |= 16;
/* 5764 */         this.kind_uri_ = that.kind_uri_;
/*      */       }
/*      */ 
/* 5767 */       if (that.property_ != null) {
/* 5768 */         for (OnestoreEntity.Property v : that.property_) {
/* 5769 */           addProperty().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 5773 */       if (that.raw_property_ != null) {
/* 5774 */         for (OnestoreEntity.Property v : that.raw_property_) {
/* 5775 */           addRawProperty().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 5779 */       if (that.uninterpreted != null) {
/* 5780 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 5782 */       this.optional_0_ = this_t0;
/* 5783 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(EntityProto that) {
/* 5787 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(EntityProto that) {
/* 5791 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(EntityProto that, boolean ignoreUninterpreted) {
/* 5795 */       if (that == null) return false;
/* 5796 */       if (that == this) return true;
/* 5797 */       int this_t0 = this.optional_0_;
/* 5798 */       int that_t0 = that.optional_0_;
/* 5799 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 5801 */       if (((this_t0 & 0x1) != 0) && 
/* 5802 */         (!this.key_.equals(that.key_, ignoreUninterpreted))) return false;
/*      */ 
/* 5805 */       if (((this_t0 & 0x2) != 0) && 
/* 5806 */         (!this.entity_group_.equals(that.entity_group_, ignoreUninterpreted))) return false;
/*      */ 
/* 5809 */       if (((this_t0 & 0x4) != 0) && 
/* 5810 */         (!this.owner_.equals(that.owner_, ignoreUninterpreted))) return false;
/*      */ 
/* 5813 */       if (((this_t0 & 0x8) != 0) && 
/* 5814 */         (this.kind_ != that.kind_)) return false;
/*      */ 
/* 5817 */       if (((this_t0 & 0x10) != 0) && 
/* 5818 */         (!Arrays.equals(this.kind_uri_, that.kind_uri_))) return false;
/* 5822 */       int n;
/* 5822 */       if ((n = this.property_ != null ? this.property_.size() : 0) != (that.property_ != null ? that.property_.size() : 0)) return false;
/* 5823 */       for (int i = 0; i < n; i++) {
/* 5824 */         if (!((OnestoreEntity.Property)this.property_.get(i)).equals((OnestoreEntity.Property)that.property_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 5827 */       if ((n = this.raw_property_ != null ? this.raw_property_.size() : 0) != (that.raw_property_ != null ? that.raw_property_.size() : 0)) return false;
/* 5828 */       for (int i = 0; i < n; i++) {
/* 5829 */         if (!((OnestoreEntity.Property)this.raw_property_.get(i)).equals((OnestoreEntity.Property)that.raw_property_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 5832 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 5837 */       return ((that instanceof EntityProto)) && (equals((EntityProto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 5841 */       int hash = 64892885;
/*      */ 
/* 5843 */       int this_t0 = this.optional_0_;
/* 5844 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.kind_ : -113);
/*      */ 
/* 5846 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? Arrays.hashCode(this.kind_uri_) : -113);
/*      */ 
/* 5848 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.key_.hashCode() : -113);
/*      */ 
/* 5850 */       hash *= 31;
/* 5851 */       int i = 0; for (int n = this.property_ != null ? this.property_.size() : 0; i < n; i++) {
/* 5852 */         hash = hash * 31 + ((OnestoreEntity.Property)this.property_.get(i)).hashCode();
/*      */       }
/*      */ 
/* 5855 */       hash *= 31;
/* 5856 */       int i = 0; for (int n = this.raw_property_ != null ? this.raw_property_.size() : 0; i < n; i++) {
/* 5857 */         hash = hash * 31 + ((OnestoreEntity.Property)this.raw_property_.get(i)).hashCode();
/*      */       }
/*      */ 
/* 5860 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.entity_group_.hashCode() : -113);
/*      */ 
/* 5862 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.owner_.hashCode() : -113);
/* 5863 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 5864 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 5866 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 5870 */       int this_t0 = this.optional_0_;
/* 5871 */       if ((this_t0 & 0x3) != 3)
/*      */       {
/* 5873 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/* 5878 */       if (!this.key_.isInitialized()) {
/* 5879 */         return false;
/*      */       }
/*      */ 
/* 5882 */       if (!this.entity_group_.isInitialized()) {
/* 5883 */         return false;
/*      */       }
/*      */ 
/* 5886 */       if (((this_t0 & 0x4) != 0) && 
/* 5887 */         (!this.owner_.isInitialized())) {
/* 5888 */         return false;
/*      */       }
/*      */ 
/* 5892 */       if (this.property_ != null) {
/* 5893 */         for (OnestoreEntity.Property v : this.property_) {
/* 5894 */           if (!v.isInitialized()) {
/* 5895 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 5900 */       if (this.raw_property_ != null) {
/* 5901 */         for (OnestoreEntity.Property v : this.raw_property_) {
/* 5902 */           if (!v.isInitialized()) {
/* 5903 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 5907 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 5913 */       int n = 3 + Protocol.stringSize(this.key_.encodingSize()) + Protocol.stringSize(this.entity_group_.encodingSize());
/*      */       int m;
/* 5917 */       n += (m = this.property_ != null ? this.property_.size() : 0);
/* 5918 */       for (int i = 0; i < m; i++) {
/* 5919 */         n += Protocol.stringSize(((OnestoreEntity.Property)this.property_.get(i)).encodingSize());
/*      */       }
/*      */ 
/* 5922 */       n += (m = this.raw_property_ != null ? this.raw_property_.size() : 0);
/* 5923 */       for (int i = 0; i < m; i++) {
/* 5924 */         n += Protocol.stringSize(((OnestoreEntity.Property)this.raw_property_.get(i)).encodingSize());
/*      */       }
/* 5926 */       int this_t0 = this.optional_0_;
/* 5927 */       if ((this_t0 & 0x1C) != 0) {
/* 5928 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 5930 */           n += 2 + Protocol.stringSize(this.owner_.encodingSize());
/*      */         }
/* 5932 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 5934 */           n += 1 + Protocol.varLongSize(this.kind_);
/*      */         }
/* 5936 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 5938 */           n += 1 + Protocol.stringSize(this.kind_uri_.length);
/*      */         }
/*      */       }
/*      */ 
/* 5942 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 5950 */       int n = 24 + this.key_.maxEncodingSize() + this.entity_group_.maxEncodingSize();
/*      */       int m;
/* 5953 */       n += 6 * (m = this.property_ != null ? this.property_.size() : 0);
/* 5954 */       for (int i = 0; i < m; i++) {
/* 5955 */         n += ((OnestoreEntity.Property)this.property_.get(i)).maxEncodingSize();
/*      */       }
/*      */ 
/* 5958 */       n += 6 * (m = this.raw_property_ != null ? this.raw_property_.size() : 0);
/* 5959 */       for (int i = 0; i < m; i++) {
/* 5960 */         n += ((OnestoreEntity.Property)this.raw_property_.get(i)).maxEncodingSize();
/*      */       }
/* 5962 */       int this_t0 = this.optional_0_;
/* 5963 */       if ((this_t0 & 0x14) != 0) {
/* 5964 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 5966 */           n += 7 + this.owner_.maxEncodingSize();
/*      */         }
/* 5968 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 5970 */           n += 6 + this.kind_uri_.length;
/*      */         }
/*      */       }
/*      */ 
/* 5974 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 5979 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 5983 */       this.optional_0_ = 0;
/* 5984 */       this.key_.clear();
/* 5985 */       this.entity_group_.clear();
/* 5986 */       if (this.owner_ != null) this.owner_.clear();
/* 5987 */       this.kind_ = 0;
/* 5988 */       this.kind_uri_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5989 */       if (this.property_ != null) this.property_.clear();
/* 5990 */       if (this.raw_property_ != null) this.raw_property_.clear();
/* 5991 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public EntityProto newInstance() {
/* 5995 */       return new EntityProto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 5999 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 6051 */       int this_t0 = this.optional_0_;
/* 6052 */       if ((this_t0 & 0x8) != 0) {
/* 6053 */         sink.putByte(32);
/* 6054 */         sink.putVarLong(this.kind_);
/*      */       }
/*      */ 
/* 6057 */       if ((this_t0 & 0x10) != 0) {
/* 6058 */         sink.putByte(42);
/* 6059 */         sink.putPrefixedData(this.kind_uri_);
/*      */       }
/*      */ 
/* 6062 */       sink.putByte(106);
/* 6063 */       sink.putForeign(this.key_);
/*      */ 
/* 6065 */       int i = 0; for (int m = this.property_ != null ? this.property_.size() : 0; i < m; i++) {
/* 6066 */         OnestoreEntity.Property v = (OnestoreEntity.Property)this.property_.get(i);
/* 6067 */         sink.putByte(114);
/* 6068 */         sink.putForeign(v);
/*      */       }
/*      */ 
/* 6071 */       int i = 0; for (int m = this.raw_property_ != null ? this.raw_property_.size() : 0; i < m; i++) {
/* 6072 */         OnestoreEntity.Property v = (OnestoreEntity.Property)this.raw_property_.get(i);
/* 6073 */         sink.putByte(122);
/* 6074 */         sink.putForeign(v);
/*      */       }
/*      */ 
/* 6077 */       sink.putByte(-126);
/* 6078 */       sink.putByte(1);
/* 6079 */       sink.putForeign(this.entity_group_);
/*      */ 
/* 6081 */       if ((this_t0 & 0x4) != 0) {
/* 6082 */         sink.putByte(-118);
/* 6083 */         sink.putByte(1);
/* 6084 */         sink.putForeign(this.owner_);
/*      */       }
/*      */ 
/* 6087 */       if (this.uninterpreted != null)
/* 6088 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 6093 */       boolean result = true;
/* 6094 */       int this_t0 = this.optional_0_;
/*      */ 
/* 6096 */       while (source.hasRemaining()) {
/* 6097 */         int tt = source.getVarInt();
/* 6098 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 6102 */           result = false;
/* 6103 */           break;
/*      */         case 32:
/* 6106 */           this.kind_ = source.getVarInt();
/* 6107 */           this_t0 |= 8;
/* 6108 */           break;
/*      */         case 42:
/* 6111 */           this.kind_uri_ = source.getPrefixedData();
/* 6112 */           this_t0 |= 16;
/* 6113 */           break;
/*      */         case 106:
/* 6116 */           source.push(source.getVarInt());
/* 6117 */           if (!this.key_.merge(source)) { result = false; break label354; }
/* 6118 */           source.pop();
/* 6119 */           this_t0 |= 1;
/* 6120 */           break;
/*      */         case 114:
/* 6123 */           source.push(source.getVarInt());
/* 6124 */           if (!addProperty().merge(source)) { result = false; break label354; }
/* 6125 */           source.pop();
/* 6126 */           break;
/*      */         case 122:
/* 6129 */           source.push(source.getVarInt());
/* 6130 */           if (!addRawProperty().merge(source)) { result = false; break label354; }
/* 6131 */           source.pop();
/* 6132 */           break;
/*      */         case 130:
/* 6135 */           source.push(source.getVarInt());
/* 6136 */           if (!this.entity_group_.merge(source)) { result = false; break label354; }
/* 6137 */           source.pop();
/* 6138 */           this_t0 |= 2;
/* 6139 */           break;
/*      */         case 138:
/* 6142 */           source.push(source.getVarInt());
/* 6143 */           OnestoreEntity.User v17 = this.owner_;
/* 6144 */           if (v17 == null) this.owner_ = (v17 = new OnestoreEntity.User());
/* 6145 */           if (!v17.merge(source)) { result = false; break label354; }
/* 6146 */           source.pop();
/* 6147 */           this_t0 |= 4;
/* 6148 */           break;
/*      */         default:
/* 6150 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 6155 */       label354: this.optional_0_ = this_t0;
/* 6156 */       return result;
/*      */     }
/*      */ 
/*      */     public EntityProto getDefaultInstanceForType()
/*      */     {
/* 6161 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final EntityProto getDefaultInstance() {
/* 6165 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public EntityProto freeze()
/*      */     {
/* 6298 */       this.key_.freeze();
/* 6299 */       this.entity_group_.freeze();
/* 6300 */       if (this.owner_ != null) this.owner_.freeze();
/* 6301 */       this.kind_uri_ = ProtocolSupport.freezeString(this.kind_uri_);
/* 6302 */       this.property_ = ProtocolSupport.freezeMessages(this.property_);
/* 6303 */       this.raw_property_ = ProtocolSupport.freezeMessages(this.raw_property_);
/* 6304 */       return this;
/*      */     }
/*      */ 
/*      */     public EntityProto unfreeze() {
/* 6308 */       this.key_.unfreeze();
/* 6309 */       this.entity_group_.unfreeze();
/* 6310 */       if (this.owner_ != null) this.owner_.unfreeze();
/* 6311 */       this.property_ = ProtocolSupport.unfreezeMessages(this.property_);
/* 6312 */       this.raw_property_ = ProtocolSupport.unfreezeMessages(this.raw_property_);
/* 6313 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 6317 */       return (this.key_.isFrozen()) || (this.entity_group_.isFrozen()) || ((this.owner_ != null) && (this.owner_.isFrozen())) || (ProtocolSupport.isFrozenMessages(this.property_)) || (ProtocolSupport.isFrozenMessages(this.raw_property_));
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 6324 */       if (this.uninterpreted == null) {
/* 6325 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 6327 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6169 */       IMMUTABLE_DEFAULT_INSTANCE = new EntityProto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearKey()
/*      */         {
/* 6177 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setKey(OnestoreEntity.Reference x) {
/* 6180 */           ProtocolSupport.unsupportedOperation();
/* 6181 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference getMutableKey() {
/* 6184 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearEntityGroup()
/*      */         {
/* 6189 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setEntityGroup(OnestoreEntity.Path x) {
/* 6192 */           ProtocolSupport.unsupportedOperation();
/* 6193 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Path getMutableEntityGroup() {
/* 6196 */           return (OnestoreEntity.Path)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearOwner()
/*      */         {
/* 6201 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setOwner(OnestoreEntity.User x) {
/* 6204 */           ProtocolSupport.unsupportedOperation();
/* 6205 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User getMutableOwner() {
/* 6208 */           return (OnestoreEntity.User)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearKind()
/*      */         {
/* 6213 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setKind(int x) {
/* 6216 */           ProtocolSupport.unsupportedOperation();
/* 6217 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearKindUri()
/*      */         {
/* 6222 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setKindUriAsBytes(byte[] x) {
/* 6225 */           ProtocolSupport.unsupportedOperation();
/* 6226 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setKindUri(String v) {
/* 6229 */           ProtocolSupport.unsupportedOperation();
/* 6230 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto setKindUri(String v, Charset cs) {
/* 6233 */           ProtocolSupport.unsupportedOperation();
/* 6234 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearProperty()
/*      */         {
/* 6239 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property getMutableProperty(int i) {
/* 6242 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property addProperty() {
/* 6245 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property addProperty(OnestoreEntity.Property v) {
/* 6248 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property insertProperty(int i, OnestoreEntity.Property v) {
/* 6251 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property removeProperty(int i) {
/* 6254 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto clearRawProperty()
/*      */         {
/* 6259 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property getMutableRawProperty(int i) {
/* 6262 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property addRawProperty() {
/* 6265 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property addRawProperty(OnestoreEntity.Property v) {
/* 6268 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property insertRawProperty(int i, OnestoreEntity.Property v) {
/* 6271 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Property removeRawProperty(int i) {
/* 6274 */           return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.EntityProto mergeFrom(OnestoreEntity.EntityProto that) {
/* 6278 */           ProtocolSupport.unsupportedOperation();
/* 6279 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 6282 */           ProtocolSupport.unsupportedOperation();
/* 6283 */           return false;
/*      */         }
/*      */         public OnestoreEntity.EntityProto freeze() {
/* 6286 */           return this;
/*      */         }
/*      */         public OnestoreEntity.EntityProto unfreeze() {
/* 6289 */           ProtocolSupport.unsupportedOperation();
/* 6290 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 6293 */           return true;
/*      */         }
/*      */       };
/* 6338 */       text = new String[18];
/*      */ 
/* 6340 */       text[0] = "ErrorCode";
/* 6341 */       text[4] = "kind";
/* 6342 */       text[5] = "kind_uri";
/* 6343 */       text[13] = "key";
/* 6344 */       text[14] = "property";
/* 6345 */       text[15] = "raw_property";
/* 6346 */       text[16] = "entity_group";
/* 6347 */       text[17] = "owner";
/*      */ 
/* 6350 */       types = new int[18];
/*      */ 
/* 6352 */       Arrays.fill(types, 6);
/* 6353 */       types[0] = 0;
/* 6354 */       types[4] = 0;
/* 6355 */       types[5] = 2;
/* 6356 */       types[13] = 2;
/* 6357 */       types[14] = 2;
/* 6358 */       types[15] = 2;
/* 6359 */       types[16] = 2;
/* 6360 */       types[17] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 6003 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.EntityProto.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("key", "key", 13, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, OnestoreEntity.Reference.class), new ProtocolType.FieldType("entity_group", "entity_group", 16, 1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, OnestoreEntity.Path.class), new ProtocolType.FieldType("owner", "owner", 17, 2, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, OnestoreEntity.User.class), new ProtocolType.FieldType("kind", "kind", 4, 3, ProtocolType.Presence.OPTIONAL, OnestoreEntity.EntityProto.Kind.class), new ProtocolType.FieldType("kind_uri", "kind_uri", 5, 4, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("property", "property", 14, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Property.class), new ProtocolType.FieldType("raw_property", "raw_property", 15, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Property.class) });
/*      */     }
/*      */ 
/*      */     public static enum Kind
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 5471 */       GD_CONTACT(1), 
/* 5472 */       GD_EVENT(2), 
/* 5473 */       GD_MESSAGE(3);
/*      */ 
/*      */       public static final Kind Kind_MIN;
/*      */       public static final Kind Kind_MAX;
/*      */       private final int value;
/*      */ 
/* 5478 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static Kind valueOf(int value) {
/* 5481 */         switch (value) { case 1:
/* 5482 */           return GD_CONTACT;
/*      */         case 2:
/* 5483 */           return GD_EVENT;
/*      */         case 3:
/* 5484 */           return GD_MESSAGE;
/*      */         }
/* 5486 */         return null;
/*      */       }
/*      */ 
/*      */       private Kind(int v) {
/* 5490 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 5475 */         Kind_MIN = GD_CONTACT;
/* 5476 */         Kind_MAX = GD_MESSAGE;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class User extends ProtocolMessage<User>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 4660 */     private byte[] email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4661 */     private byte[] auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4662 */     private byte[] nickname_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4663 */     private long gaiaid_ = 0L;
/* 4664 */     private byte[] obfuscated_gaiaid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4665 */     private byte[] federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4666 */     private byte[] federated_provider_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final User IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kemail = 1;
/*      */     public static final int kauth_domain = 2;
/*      */     public static final int knickname = 3;
/*      */     public static final int kgaiaid = 4;
/*      */     public static final int kobfuscated_gaiaid = 5;
/*      */     public static final int kfederated_identity = 6;
/*      */     public static final int kfederated_provider = 7;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getEmailAsBytes()
/*      */     {
/* 4672 */       return this.email_;
/*      */     }
/*      */     public final boolean hasEmail() {
/* 4675 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public User clearEmail() {
/* 4678 */       this.optional_0_ &= -2;
/* 4679 */       this.email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4680 */       return this;
/*      */     }
/*      */     public User setEmailAsBytes(byte[] x) {
/* 4683 */       this.optional_0_ |= 1;
/* 4684 */       this.email_ = x;
/* 4685 */       return this;
/*      */     }
/*      */     public final String getEmail() {
/* 4688 */       return ProtocolSupport.toStringUtf8(this.email_);
/*      */     }
/*      */     public User setEmail(String v) {
/* 4691 */       if (v == null) throw new NullPointerException();
/* 4692 */       this.optional_0_ |= 1;
/* 4693 */       this.email_ = ProtocolSupport.toBytesUtf8(v);
/* 4694 */       return this;
/*      */     }
/*      */     public final String getEmail(Charset cs) {
/* 4697 */       return ProtocolSupport.toString(this.email_, cs);
/*      */     }
/*      */     public User setEmail(String v, Charset cs) {
/* 4700 */       if (v == null) throw new NullPointerException();
/* 4701 */       this.optional_0_ |= 1;
/* 4702 */       this.email_ = ProtocolSupport.toBytes(v, cs);
/* 4703 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getAuthDomainAsBytes()
/*      */     {
/* 4708 */       return this.auth_domain_;
/*      */     }
/*      */     public final boolean hasAuthDomain() {
/* 4711 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public User clearAuthDomain() {
/* 4714 */       this.optional_0_ &= -3;
/* 4715 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4716 */       return this;
/*      */     }
/*      */     public User setAuthDomainAsBytes(byte[] x) {
/* 4719 */       this.optional_0_ |= 2;
/* 4720 */       this.auth_domain_ = x;
/* 4721 */       return this;
/*      */     }
/*      */     public final String getAuthDomain() {
/* 4724 */       return ProtocolSupport.toStringUtf8(this.auth_domain_);
/*      */     }
/*      */     public User setAuthDomain(String v) {
/* 4727 */       if (v == null) throw new NullPointerException();
/* 4728 */       this.optional_0_ |= 2;
/* 4729 */       this.auth_domain_ = ProtocolSupport.toBytesUtf8(v);
/* 4730 */       return this;
/*      */     }
/*      */     public final String getAuthDomain(Charset cs) {
/* 4733 */       return ProtocolSupport.toString(this.auth_domain_, cs);
/*      */     }
/*      */     public User setAuthDomain(String v, Charset cs) {
/* 4736 */       if (v == null) throw new NullPointerException();
/* 4737 */       this.optional_0_ |= 2;
/* 4738 */       this.auth_domain_ = ProtocolSupport.toBytes(v, cs);
/* 4739 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getNicknameAsBytes()
/*      */     {
/* 4744 */       return this.nickname_;
/*      */     }
/*      */     public final boolean hasNickname() {
/* 4747 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public User clearNickname() {
/* 4750 */       this.optional_0_ &= -5;
/* 4751 */       this.nickname_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4752 */       return this;
/*      */     }
/*      */     public User setNicknameAsBytes(byte[] x) {
/* 4755 */       this.optional_0_ |= 4;
/* 4756 */       this.nickname_ = x;
/* 4757 */       return this;
/*      */     }
/*      */     public final String getNickname() {
/* 4760 */       return ProtocolSupport.toStringUtf8(this.nickname_);
/*      */     }
/*      */     public User setNickname(String v) {
/* 4763 */       if (v == null) throw new NullPointerException();
/* 4764 */       this.optional_0_ |= 4;
/* 4765 */       this.nickname_ = ProtocolSupport.toBytesUtf8(v);
/* 4766 */       return this;
/*      */     }
/*      */     public final String getNickname(Charset cs) {
/* 4769 */       return ProtocolSupport.toString(this.nickname_, cs);
/*      */     }
/*      */     public User setNickname(String v, Charset cs) {
/* 4772 */       if (v == null) throw new NullPointerException();
/* 4773 */       this.optional_0_ |= 4;
/* 4774 */       this.nickname_ = ProtocolSupport.toBytes(v, cs);
/* 4775 */       return this;
/*      */     }
/*      */ 
/*      */     public final long getGaiaid()
/*      */     {
/* 4780 */       return this.gaiaid_;
/*      */     }
/*      */     public final boolean hasGaiaid() {
/* 4783 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public User clearGaiaid() {
/* 4786 */       this.optional_0_ &= -9;
/* 4787 */       this.gaiaid_ = 0L;
/* 4788 */       return this;
/*      */     }
/*      */     public User setGaiaid(long x) {
/* 4791 */       this.optional_0_ |= 8;
/* 4792 */       this.gaiaid_ = x;
/* 4793 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getObfuscatedGaiaidAsBytes()
/*      */     {
/* 4798 */       return this.obfuscated_gaiaid_;
/*      */     }
/*      */     public final boolean hasObfuscatedGaiaid() {
/* 4801 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public User clearObfuscatedGaiaid() {
/* 4804 */       this.optional_0_ &= -17;
/* 4805 */       this.obfuscated_gaiaid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4806 */       return this;
/*      */     }
/*      */     public User setObfuscatedGaiaidAsBytes(byte[] x) {
/* 4809 */       this.optional_0_ |= 16;
/* 4810 */       this.obfuscated_gaiaid_ = x;
/* 4811 */       return this;
/*      */     }
/*      */     public final String getObfuscatedGaiaid() {
/* 4814 */       return ProtocolSupport.toStringUtf8(this.obfuscated_gaiaid_);
/*      */     }
/*      */     public User setObfuscatedGaiaid(String v) {
/* 4817 */       if (v == null) throw new NullPointerException();
/* 4818 */       this.optional_0_ |= 16;
/* 4819 */       this.obfuscated_gaiaid_ = ProtocolSupport.toBytesUtf8(v);
/* 4820 */       return this;
/*      */     }
/*      */     public final String getObfuscatedGaiaid(Charset cs) {
/* 4823 */       return ProtocolSupport.toString(this.obfuscated_gaiaid_, cs);
/*      */     }
/*      */     public User setObfuscatedGaiaid(String v, Charset cs) {
/* 4826 */       if (v == null) throw new NullPointerException();
/* 4827 */       this.optional_0_ |= 16;
/* 4828 */       this.obfuscated_gaiaid_ = ProtocolSupport.toBytes(v, cs);
/* 4829 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFederatedIdentityAsBytes()
/*      */     {
/* 4834 */       return this.federated_identity_;
/*      */     }
/*      */     public final boolean hasFederatedIdentity() {
/* 4837 */       return (this.optional_0_ & 0x20) != 0;
/*      */     }
/*      */     public User clearFederatedIdentity() {
/* 4840 */       this.optional_0_ &= -33;
/* 4841 */       this.federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4842 */       return this;
/*      */     }
/*      */     public User setFederatedIdentityAsBytes(byte[] x) {
/* 4845 */       this.optional_0_ |= 32;
/* 4846 */       this.federated_identity_ = x;
/* 4847 */       return this;
/*      */     }
/*      */     public final String getFederatedIdentity() {
/* 4850 */       return ProtocolSupport.toStringUtf8(this.federated_identity_);
/*      */     }
/*      */     public User setFederatedIdentity(String v) {
/* 4853 */       if (v == null) throw new NullPointerException();
/* 4854 */       this.optional_0_ |= 32;
/* 4855 */       this.federated_identity_ = ProtocolSupport.toBytesUtf8(v);
/* 4856 */       return this;
/*      */     }
/*      */     public final String getFederatedIdentity(Charset cs) {
/* 4859 */       return ProtocolSupport.toString(this.federated_identity_, cs);
/*      */     }
/*      */     public User setFederatedIdentity(String v, Charset cs) {
/* 4862 */       if (v == null) throw new NullPointerException();
/* 4863 */       this.optional_0_ |= 32;
/* 4864 */       this.federated_identity_ = ProtocolSupport.toBytes(v, cs);
/* 4865 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getFederatedProviderAsBytes()
/*      */     {
/* 4870 */       return this.federated_provider_;
/*      */     }
/*      */     public final boolean hasFederatedProvider() {
/* 4873 */       return (this.optional_0_ & 0x40) != 0;
/*      */     }
/*      */     public User clearFederatedProvider() {
/* 4876 */       this.optional_0_ &= -65;
/* 4877 */       this.federated_provider_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4878 */       return this;
/*      */     }
/*      */     public User setFederatedProviderAsBytes(byte[] x) {
/* 4881 */       this.optional_0_ |= 64;
/* 4882 */       this.federated_provider_ = x;
/* 4883 */       return this;
/*      */     }
/*      */     public final String getFederatedProvider() {
/* 4886 */       return ProtocolSupport.toStringUtf8(this.federated_provider_);
/*      */     }
/*      */     public User setFederatedProvider(String v) {
/* 4889 */       if (v == null) throw new NullPointerException();
/* 4890 */       this.optional_0_ |= 64;
/* 4891 */       this.federated_provider_ = ProtocolSupport.toBytesUtf8(v);
/* 4892 */       return this;
/*      */     }
/*      */     public final String getFederatedProvider(Charset cs) {
/* 4895 */       return ProtocolSupport.toString(this.federated_provider_, cs);
/*      */     }
/*      */     public User setFederatedProvider(String v, Charset cs) {
/* 4898 */       if (v == null) throw new NullPointerException();
/* 4899 */       this.optional_0_ |= 64;
/* 4900 */       this.federated_provider_ = ProtocolSupport.toBytes(v, cs);
/* 4901 */       return this;
/*      */     }
/*      */ 
/*      */     public User mergeFrom(User that)
/*      */     {
/* 4908 */       assert (that != this);
/* 4909 */       int this_t0 = this.optional_0_;
/* 4910 */       int that_t0 = that.optional_0_;
/*      */ 
/* 4912 */       if ((that_t0 & 0x1) != 0) {
/* 4913 */         this_t0 |= 1;
/* 4914 */         this.email_ = that.email_;
/*      */       }
/*      */ 
/* 4917 */       if ((that_t0 & 0x2) != 0) {
/* 4918 */         this_t0 |= 2;
/* 4919 */         this.auth_domain_ = that.auth_domain_;
/*      */       }
/*      */ 
/* 4922 */       if ((that_t0 & 0x4) != 0) {
/* 4923 */         this_t0 |= 4;
/* 4924 */         this.nickname_ = that.nickname_;
/*      */       }
/*      */ 
/* 4927 */       if ((that_t0 & 0x8) != 0) {
/* 4928 */         this_t0 |= 8;
/* 4929 */         this.gaiaid_ = that.gaiaid_;
/*      */       }
/*      */ 
/* 4932 */       if ((that_t0 & 0x10) != 0) {
/* 4933 */         this_t0 |= 16;
/* 4934 */         this.obfuscated_gaiaid_ = that.obfuscated_gaiaid_;
/*      */       }
/*      */ 
/* 4937 */       if ((that_t0 & 0x20) != 0) {
/* 4938 */         this_t0 |= 32;
/* 4939 */         this.federated_identity_ = that.federated_identity_;
/*      */       }
/*      */ 
/* 4942 */       if ((that_t0 & 0x40) != 0) {
/* 4943 */         this_t0 |= 64;
/* 4944 */         this.federated_provider_ = that.federated_provider_;
/*      */       }
/*      */ 
/* 4947 */       if (that.uninterpreted != null) {
/* 4948 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 4950 */       this.optional_0_ = this_t0;
/* 4951 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(User that) {
/* 4955 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(User that) {
/* 4959 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(User that, boolean ignoreUninterpreted) {
/* 4963 */       if (that == null) return false;
/* 4964 */       if (that == this) return true;
/* 4965 */       int this_t0 = this.optional_0_;
/* 4966 */       int that_t0 = that.optional_0_;
/* 4967 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 4969 */       if (((this_t0 & 0x1) != 0) && 
/* 4970 */         (!Arrays.equals(this.email_, that.email_))) return false;
/*      */ 
/* 4973 */       if (((this_t0 & 0x2) != 0) && 
/* 4974 */         (!Arrays.equals(this.auth_domain_, that.auth_domain_))) return false;
/*      */ 
/* 4977 */       if (((this_t0 & 0x4) != 0) && 
/* 4978 */         (!Arrays.equals(this.nickname_, that.nickname_))) return false;
/*      */ 
/* 4981 */       if (((this_t0 & 0x8) != 0) && 
/* 4982 */         (this.gaiaid_ != that.gaiaid_)) return false;
/*      */ 
/* 4985 */       if (((this_t0 & 0x10) != 0) && 
/* 4986 */         (!Arrays.equals(this.obfuscated_gaiaid_, that.obfuscated_gaiaid_))) return false;
/*      */ 
/* 4989 */       if (((this_t0 & 0x20) != 0) && 
/* 4990 */         (!Arrays.equals(this.federated_identity_, that.federated_identity_))) return false;
/*      */ 
/* 4993 */       if (((this_t0 & 0x40) != 0) && 
/* 4994 */         (!Arrays.equals(this.federated_provider_, that.federated_provider_))) return false;
/*      */ 
/* 4997 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 5002 */       return ((that instanceof User)) && (equals((User)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 5006 */       int hash = 88532482;
/*      */ 
/* 5008 */       int this_t0 = this.optional_0_;
/* 5009 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.email_) : -113);
/*      */ 
/* 5011 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.auth_domain_) : -113);
/*      */ 
/* 5013 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.nickname_) : -113);
/*      */ 
/* 5015 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? ProtocolSupport.hashCode(this.gaiaid_) : -113);
/*      */ 
/* 5017 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? Arrays.hashCode(this.obfuscated_gaiaid_) : -113);
/*      */ 
/* 5019 */       hash = hash * 31 + ((this_t0 & 0x20) != 0 ? Arrays.hashCode(this.federated_identity_) : -113);
/*      */ 
/* 5021 */       hash = hash * 31 + ((this_t0 & 0x40) != 0 ? Arrays.hashCode(this.federated_provider_) : -113);
/* 5022 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 5023 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 5025 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 5029 */       int this_t0 = this.optional_0_;
/* 5030 */       if ((this_t0 & 0xB) != 11) {
/* 5031 */         if ((this_t0 & 0x1) == 0) {
/* 5032 */           return false;
/*      */         }
/*      */ 
/* 5035 */         return (this_t0 & 0x2) != 0;
/*      */       }
/*      */ 
/* 5039 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 5046 */       int n = 3 + Protocol.stringSize(this.email_.length) + Protocol.stringSize(this.auth_domain_.length) + Protocol.varLongSize(this.gaiaid_);
/*      */ 
/* 5049 */       int this_t0 = this.optional_0_;
/* 5050 */       if ((this_t0 & 0x74) != 0) {
/* 5051 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 5053 */           n += 1 + Protocol.stringSize(this.nickname_.length);
/*      */         }
/* 5055 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 5057 */           n += 1 + Protocol.stringSize(this.obfuscated_gaiaid_.length);
/*      */         }
/* 5059 */         if ((this_t0 & 0x20) != 0)
/*      */         {
/* 5061 */           n += 1 + Protocol.stringSize(this.federated_identity_.length);
/*      */         }
/* 5063 */         if ((this_t0 & 0x40) != 0)
/*      */         {
/* 5065 */           n += 1 + Protocol.stringSize(this.federated_provider_.length);
/*      */         }
/*      */       }
/*      */ 
/* 5069 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 5077 */       int n = 23 + this.email_.length + this.auth_domain_.length;
/* 5078 */       int this_t0 = this.optional_0_;
/* 5079 */       if ((this_t0 & 0x74) != 0) {
/* 5080 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 5082 */           n += 6 + this.nickname_.length;
/*      */         }
/* 5084 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 5086 */           n += 6 + this.obfuscated_gaiaid_.length;
/*      */         }
/* 5088 */         if ((this_t0 & 0x20) != 0)
/*      */         {
/* 5090 */           n += 6 + this.federated_identity_.length;
/*      */         }
/* 5092 */         if ((this_t0 & 0x40) != 0)
/*      */         {
/* 5094 */           n += 6 + this.federated_provider_.length;
/*      */         }
/*      */       }
/*      */ 
/* 5098 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 5103 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 5107 */       this.optional_0_ = 0;
/* 5108 */       this.email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5109 */       this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5110 */       this.nickname_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5111 */       this.gaiaid_ = 0L;
/* 5112 */       this.obfuscated_gaiaid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5113 */       this.federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5114 */       this.federated_provider_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 5115 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public User newInstance() {
/* 5119 */       return new User();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 5123 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 5163 */       sink.putByte(10);
/* 5164 */       sink.putPrefixedData(this.email_);
/*      */ 
/* 5166 */       sink.putByte(18);
/* 5167 */       sink.putPrefixedData(this.auth_domain_);
/*      */ 
/* 5169 */       int this_t0 = this.optional_0_;
/* 5170 */       if ((this_t0 & 0x4) != 0) {
/* 5171 */         sink.putByte(26);
/* 5172 */         sink.putPrefixedData(this.nickname_);
/*      */       }
/*      */ 
/* 5175 */       sink.putByte(32);
/* 5176 */       sink.putVarLong(this.gaiaid_);
/*      */ 
/* 5178 */       if ((this_t0 & 0x10) != 0) {
/* 5179 */         sink.putByte(42);
/* 5180 */         sink.putPrefixedData(this.obfuscated_gaiaid_);
/*      */       }
/*      */ 
/* 5183 */       if ((this_t0 & 0x20) != 0) {
/* 5184 */         sink.putByte(50);
/* 5185 */         sink.putPrefixedData(this.federated_identity_);
/*      */       }
/*      */ 
/* 5188 */       if ((this_t0 & 0x40) != 0) {
/* 5189 */         sink.putByte(58);
/* 5190 */         sink.putPrefixedData(this.federated_provider_);
/*      */       }
/*      */ 
/* 5193 */       if (this.uninterpreted != null)
/* 5194 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 5199 */       boolean result = true;
/* 5200 */       int this_t0 = this.optional_0_;
/*      */ 
/* 5202 */       while (source.hasRemaining()) {
/* 5203 */         int tt = source.getVarInt();
/* 5204 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 5208 */           result = false;
/* 5209 */           break;
/*      */         case 10:
/* 5212 */           this.email_ = source.getPrefixedData();
/* 5213 */           this_t0 |= 1;
/* 5214 */           break;
/*      */         case 18:
/* 5217 */           this.auth_domain_ = source.getPrefixedData();
/* 5218 */           this_t0 |= 2;
/* 5219 */           break;
/*      */         case 26:
/* 5222 */           this.nickname_ = source.getPrefixedData();
/* 5223 */           this_t0 |= 4;
/* 5224 */           break;
/*      */         case 32:
/* 5227 */           this.gaiaid_ = source.getVarLong();
/* 5228 */           this_t0 |= 8;
/* 5229 */           break;
/*      */         case 42:
/* 5232 */           this.obfuscated_gaiaid_ = source.getPrefixedData();
/* 5233 */           this_t0 |= 16;
/* 5234 */           break;
/*      */         case 50:
/* 5237 */           this.federated_identity_ = source.getPrefixedData();
/* 5238 */           this_t0 |= 32;
/* 5239 */           break;
/*      */         case 58:
/* 5242 */           this.federated_provider_ = source.getPrefixedData();
/* 5243 */           this_t0 |= 64;
/* 5244 */           break;
/*      */         default:
/* 5246 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5251 */       this.optional_0_ = this_t0;
/* 5252 */       return result;
/*      */     }
/*      */ 
/*      */     public User getDefaultInstanceForType()
/*      */     {
/* 5257 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final User getDefaultInstance() {
/* 5261 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public User freeze()
/*      */     {
/* 5403 */       this.email_ = ProtocolSupport.freezeString(this.email_);
/* 5404 */       this.auth_domain_ = ProtocolSupport.freezeString(this.auth_domain_);
/* 5405 */       this.nickname_ = ProtocolSupport.freezeString(this.nickname_);
/* 5406 */       this.obfuscated_gaiaid_ = ProtocolSupport.freezeString(this.obfuscated_gaiaid_);
/* 5407 */       this.federated_identity_ = ProtocolSupport.freezeString(this.federated_identity_);
/* 5408 */       this.federated_provider_ = ProtocolSupport.freezeString(this.federated_provider_);
/* 5409 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 5412 */       if (this.uninterpreted == null) {
/* 5413 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 5415 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 5265 */       IMMUTABLE_DEFAULT_INSTANCE = new User()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.User clearEmail()
/*      */         {
/* 5273 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setEmailAsBytes(byte[] x) {
/* 5276 */           ProtocolSupport.unsupportedOperation();
/* 5277 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setEmail(String v) {
/* 5280 */           ProtocolSupport.unsupportedOperation();
/* 5281 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setEmail(String v, Charset cs) {
/* 5284 */           ProtocolSupport.unsupportedOperation();
/* 5285 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User clearAuthDomain()
/*      */         {
/* 5290 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setAuthDomainAsBytes(byte[] x) {
/* 5293 */           ProtocolSupport.unsupportedOperation();
/* 5294 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setAuthDomain(String v) {
/* 5297 */           ProtocolSupport.unsupportedOperation();
/* 5298 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setAuthDomain(String v, Charset cs) {
/* 5301 */           ProtocolSupport.unsupportedOperation();
/* 5302 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User clearNickname()
/*      */         {
/* 5307 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setNicknameAsBytes(byte[] x) {
/* 5310 */           ProtocolSupport.unsupportedOperation();
/* 5311 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setNickname(String v) {
/* 5314 */           ProtocolSupport.unsupportedOperation();
/* 5315 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setNickname(String v, Charset cs) {
/* 5318 */           ProtocolSupport.unsupportedOperation();
/* 5319 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User clearGaiaid()
/*      */         {
/* 5324 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setGaiaid(long x) {
/* 5327 */           ProtocolSupport.unsupportedOperation();
/* 5328 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User clearObfuscatedGaiaid()
/*      */         {
/* 5333 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setObfuscatedGaiaidAsBytes(byte[] x) {
/* 5336 */           ProtocolSupport.unsupportedOperation();
/* 5337 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setObfuscatedGaiaid(String v) {
/* 5340 */           ProtocolSupport.unsupportedOperation();
/* 5341 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setObfuscatedGaiaid(String v, Charset cs) {
/* 5344 */           ProtocolSupport.unsupportedOperation();
/* 5345 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User clearFederatedIdentity()
/*      */         {
/* 5350 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setFederatedIdentityAsBytes(byte[] x) {
/* 5353 */           ProtocolSupport.unsupportedOperation();
/* 5354 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setFederatedIdentity(String v) {
/* 5357 */           ProtocolSupport.unsupportedOperation();
/* 5358 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setFederatedIdentity(String v, Charset cs) {
/* 5361 */           ProtocolSupport.unsupportedOperation();
/* 5362 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User clearFederatedProvider()
/*      */         {
/* 5367 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setFederatedProviderAsBytes(byte[] x) {
/* 5370 */           ProtocolSupport.unsupportedOperation();
/* 5371 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setFederatedProvider(String v) {
/* 5374 */           ProtocolSupport.unsupportedOperation();
/* 5375 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User setFederatedProvider(String v, Charset cs) {
/* 5378 */           ProtocolSupport.unsupportedOperation();
/* 5379 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.User mergeFrom(OnestoreEntity.User that) {
/* 5383 */           ProtocolSupport.unsupportedOperation();
/* 5384 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 5387 */           ProtocolSupport.unsupportedOperation();
/* 5388 */           return false;
/*      */         }
/*      */         public OnestoreEntity.User freeze() {
/* 5391 */           return this;
/*      */         }
/*      */         public OnestoreEntity.User unfreeze() {
/* 5394 */           ProtocolSupport.unsupportedOperation();
/* 5395 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 5398 */           return true;
/*      */         }
/*      */       };
/* 5426 */       text = new String[8];
/*      */ 
/* 5428 */       text[0] = "ErrorCode";
/* 5429 */       text[1] = "email";
/* 5430 */       text[2] = "auth_domain";
/* 5431 */       text[3] = "nickname";
/* 5432 */       text[4] = "gaiaid";
/* 5433 */       text[5] = "obfuscated_gaiaid";
/* 5434 */       text[6] = "federated_identity";
/* 5435 */       text[7] = "federated_provider";
/*      */ 
/* 5438 */       types = new int[8];
/*      */ 
/* 5440 */       Arrays.fill(types, 6);
/* 5441 */       types[0] = 0;
/* 5442 */       types[1] = 2;
/* 5443 */       types[2] = 2;
/* 5444 */       types[3] = 2;
/* 5445 */       types[4] = 0;
/* 5446 */       types[5] = 2;
/* 5447 */       types[6] = 2;
/* 5448 */       types[7] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 5127 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.User.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("email", "email", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("auth_domain", "auth_domain", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("nickname", "nickname", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("gaiaid", "gaiaid", 4, 3, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("obfuscated_gaiaid", "obfuscated_gaiaid", 5, 4, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("federated_identity", "federated_identity", 6, 5, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("federated_provider", "federated_provider", 7, 6, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Reference extends ProtocolMessage<Reference>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 4200 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4201 */     private byte[] name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4202 */     private OnestoreEntity.Path path_ = new OnestoreEntity.Path();
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final Reference IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kapp = 13;
/*      */     public static final int kname_space = 20;
/*      */     public static final int kpath = 14;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getAppAsBytes()
/*      */     {
/* 4208 */       return this.app_;
/*      */     }
/*      */     public final boolean hasApp() {
/* 4211 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public Reference clearApp() {
/* 4214 */       this.optional_0_ &= -2;
/* 4215 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4216 */       return this;
/*      */     }
/*      */     public Reference setAppAsBytes(byte[] x) {
/* 4219 */       this.optional_0_ |= 1;
/* 4220 */       this.app_ = x;
/* 4221 */       return this;
/*      */     }
/*      */     public final String getApp() {
/* 4224 */       return ProtocolSupport.toStringUtf8(this.app_);
/*      */     }
/*      */     public Reference setApp(String v) {
/* 4227 */       if (v == null) throw new NullPointerException();
/* 4228 */       this.optional_0_ |= 1;
/* 4229 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/* 4230 */       return this;
/*      */     }
/*      */     public final String getApp(Charset cs) {
/* 4233 */       return ProtocolSupport.toString(this.app_, cs);
/*      */     }
/*      */     public Reference setApp(String v, Charset cs) {
/* 4236 */       if (v == null) throw new NullPointerException();
/* 4237 */       this.optional_0_ |= 1;
/* 4238 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/* 4239 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getNameSpaceAsBytes()
/*      */     {
/* 4244 */       return this.name_space_;
/*      */     }
/*      */     public final boolean hasNameSpace() {
/* 4247 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public Reference clearNameSpace() {
/* 4250 */       this.optional_0_ &= -3;
/* 4251 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4252 */       return this;
/*      */     }
/*      */     public Reference setNameSpaceAsBytes(byte[] x) {
/* 4255 */       this.optional_0_ |= 2;
/* 4256 */       this.name_space_ = x;
/* 4257 */       return this;
/*      */     }
/*      */     public final String getNameSpace() {
/* 4260 */       return ProtocolSupport.toStringUtf8(this.name_space_);
/*      */     }
/*      */     public Reference setNameSpace(String v) {
/* 4263 */       if (v == null) throw new NullPointerException();
/* 4264 */       this.optional_0_ |= 2;
/* 4265 */       this.name_space_ = ProtocolSupport.toBytesUtf8(v);
/* 4266 */       return this;
/*      */     }
/*      */     public final String getNameSpace(Charset cs) {
/* 4269 */       return ProtocolSupport.toString(this.name_space_, cs);
/*      */     }
/*      */     public Reference setNameSpace(String v, Charset cs) {
/* 4272 */       if (v == null) throw new NullPointerException();
/* 4273 */       this.optional_0_ |= 2;
/* 4274 */       this.name_space_ = ProtocolSupport.toBytes(v, cs);
/* 4275 */       return this;
/*      */     }
/*      */ 
/*      */     public final OnestoreEntity.Path getPath()
/*      */     {
/* 4280 */       return this.path_;
/*      */     }
/*      */     public final boolean hasPath() {
/* 4283 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public Reference clearPath() {
/* 4286 */       this.optional_0_ &= -5;
/* 4287 */       this.path_.clear();
/* 4288 */       return this;
/*      */     }
/*      */     public Reference setPath(OnestoreEntity.Path x) {
/* 4291 */       if (x == null) throw new NullPointerException();
/* 4292 */       this.optional_0_ |= 4;
/* 4293 */       this.path_ = x;
/* 4294 */       return this;
/*      */     }
/*      */     public OnestoreEntity.Path getMutablePath() {
/* 4297 */       this.optional_0_ |= 4;
/* 4298 */       return this.path_;
/*      */     }
/*      */ 
/*      */     public Reference mergeFrom(Reference that)
/*      */     {
/* 4305 */       assert (that != this);
/* 4306 */       int this_t0 = this.optional_0_;
/* 4307 */       int that_t0 = that.optional_0_;
/*      */ 
/* 4309 */       if ((that_t0 & 0x1) != 0) {
/* 4310 */         this_t0 |= 1;
/* 4311 */         this.app_ = that.app_;
/*      */       }
/*      */ 
/* 4314 */       if ((that_t0 & 0x2) != 0) {
/* 4315 */         this_t0 |= 2;
/* 4316 */         this.name_space_ = that.name_space_;
/*      */       }
/*      */ 
/* 4319 */       if ((that_t0 & 0x4) != 0) {
/* 4320 */         this_t0 |= 4;
/* 4321 */         OnestoreEntity.Path v = this.path_;
/* 4322 */         v.mergeFrom(that.path_);
/*      */       }
/*      */ 
/* 4325 */       if (that.uninterpreted != null) {
/* 4326 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 4328 */       this.optional_0_ = this_t0;
/* 4329 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Reference that) {
/* 4333 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Reference that) {
/* 4337 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Reference that, boolean ignoreUninterpreted) {
/* 4341 */       if (that == null) return false;
/* 4342 */       if (that == this) return true;
/* 4343 */       int this_t0 = this.optional_0_;
/* 4344 */       int that_t0 = that.optional_0_;
/* 4345 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 4347 */       if (((this_t0 & 0x1) != 0) && 
/* 4348 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*      */ 
/* 4351 */       if (((this_t0 & 0x2) != 0) && 
/* 4352 */         (!Arrays.equals(this.name_space_, that.name_space_))) return false;
/*      */ 
/* 4355 */       if (((this_t0 & 0x4) != 0) && 
/* 4356 */         (!this.path_.equals(that.path_, ignoreUninterpreted))) return false;
/*      */ 
/* 4359 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 4364 */       return ((that instanceof Reference)) && (equals((Reference)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 4368 */       int hash = 2110099379;
/*      */ 
/* 4370 */       int this_t0 = this.optional_0_;
/* 4371 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/*      */ 
/* 4373 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.path_.hashCode() : -113);
/*      */ 
/* 4375 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.name_space_) : -113);
/* 4376 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 4377 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 4379 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 4383 */       int this_t0 = this.optional_0_;
/* 4384 */       if ((this_t0 & 0x5) != 5)
/*      */       {
/* 4386 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/* 4392 */       return this.path_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 4400 */       int n = 2 + Protocol.stringSize(this.app_.length) + Protocol.stringSize(this.path_.encodingSize());
/*      */ 
/* 4402 */       int this_t0 = this.optional_0_;
/* 4403 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 4405 */         n += 2 + Protocol.stringSize(this.name_space_.length);
/*      */       }
/*      */ 
/* 4408 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 4415 */       int n = 12 + this.app_.length + this.path_.maxEncodingSize();
/* 4416 */       int this_t0 = this.optional_0_;
/* 4417 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 4419 */         n += 7 + this.name_space_.length;
/*      */       }
/*      */ 
/* 4422 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 4427 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 4431 */       this.optional_0_ = 0;
/* 4432 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4433 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 4434 */       this.path_.clear();
/* 4435 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Reference newInstance() {
/* 4439 */       return new Reference();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 4443 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 4469 */       sink.putByte(106);
/* 4470 */       sink.putPrefixedData(this.app_);
/*      */ 
/* 4472 */       sink.putByte(114);
/* 4473 */       sink.putForeign(this.path_);
/*      */ 
/* 4475 */       int this_t0 = this.optional_0_;
/* 4476 */       if ((this_t0 & 0x2) != 0) {
/* 4477 */         sink.putByte(-94);
/* 4478 */         sink.putByte(1);
/* 4479 */         sink.putPrefixedData(this.name_space_);
/*      */       }
/*      */ 
/* 4482 */       if (this.uninterpreted != null)
/* 4483 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 4488 */       boolean result = true;
/* 4489 */       int this_t0 = this.optional_0_;
/*      */ 
/* 4491 */       while (source.hasRemaining()) {
/* 4492 */         int tt = source.getVarInt();
/* 4493 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 4497 */           result = false;
/* 4498 */           break;
/*      */         case 106:
/* 4501 */           this.app_ = source.getPrefixedData();
/* 4502 */           this_t0 |= 1;
/* 4503 */           break;
/*      */         case 114:
/* 4506 */           source.push(source.getVarInt());
/* 4507 */           if (!this.path_.merge(source)) { result = false; break label157; }
/* 4508 */           source.pop();
/* 4509 */           this_t0 |= 4;
/* 4510 */           break;
/*      */         case 162:
/* 4513 */           this.name_space_ = source.getPrefixedData();
/* 4514 */           this_t0 |= 2;
/* 4515 */           break;
/*      */         default:
/* 4517 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4522 */       label157: this.optional_0_ = this_t0;
/* 4523 */       return result;
/*      */     }
/*      */ 
/*      */     public Reference getDefaultInstanceForType()
/*      */     {
/* 4528 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Reference getDefaultInstance() {
/* 4532 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public Reference freeze()
/*      */     {
/* 4609 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/* 4610 */       this.name_space_ = ProtocolSupport.freezeString(this.name_space_);
/* 4611 */       this.path_.freeze();
/* 4612 */       return this;
/*      */     }
/*      */ 
/*      */     public Reference unfreeze() {
/* 4616 */       this.path_.unfreeze();
/* 4617 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 4621 */       return this.path_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 4624 */       if (this.uninterpreted == null) {
/* 4625 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 4627 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4536 */       IMMUTABLE_DEFAULT_INSTANCE = new Reference()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.Reference clearApp()
/*      */         {
/* 4544 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setAppAsBytes(byte[] x) {
/* 4547 */           ProtocolSupport.unsupportedOperation();
/* 4548 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setApp(String v) {
/* 4551 */           ProtocolSupport.unsupportedOperation();
/* 4552 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setApp(String v, Charset cs) {
/* 4555 */           ProtocolSupport.unsupportedOperation();
/* 4556 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Reference clearNameSpace()
/*      */         {
/* 4561 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setNameSpaceAsBytes(byte[] x) {
/* 4564 */           ProtocolSupport.unsupportedOperation();
/* 4565 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setNameSpace(String v) {
/* 4568 */           ProtocolSupport.unsupportedOperation();
/* 4569 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setNameSpace(String v, Charset cs) {
/* 4572 */           ProtocolSupport.unsupportedOperation();
/* 4573 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Reference clearPath()
/*      */         {
/* 4578 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference setPath(OnestoreEntity.Path x) {
/* 4581 */           ProtocolSupport.unsupportedOperation();
/* 4582 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Path getMutablePath() {
/* 4585 */           return (OnestoreEntity.Path)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Reference mergeFrom(OnestoreEntity.Reference that) {
/* 4589 */           ProtocolSupport.unsupportedOperation();
/* 4590 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 4593 */           ProtocolSupport.unsupportedOperation();
/* 4594 */           return false;
/*      */         }
/*      */         public OnestoreEntity.Reference freeze() {
/* 4597 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Reference unfreeze() {
/* 4600 */           ProtocolSupport.unsupportedOperation();
/* 4601 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 4604 */           return true;
/*      */         }
/*      */       };
/* 4634 */       text = new String[21];
/*      */ 
/* 4636 */       text[0] = "ErrorCode";
/* 4637 */       text[13] = "app";
/* 4638 */       text[14] = "path";
/* 4639 */       text[20] = "name_space";
/*      */ 
/* 4642 */       types = new int[21];
/*      */ 
/* 4644 */       Arrays.fill(types, 6);
/* 4645 */       types[0] = 0;
/* 4646 */       types[13] = 2;
/* 4647 */       types[14] = 2;
/* 4648 */       types[20] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 4447 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.Reference.class, "Z storage/onestore/v3/entity.proto\n\035storage_onestore_v3.Reference\023\032\003app \r(\0020\t8\002\024\023\032\nname_space \024(\0020\t8\001\024\023\032\004path \016(\0020\0138\002J\030storage_onestore_v3.Path\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 13, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("name_space", "name_space", 20, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("path", "path", 14, 2, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, OnestoreEntity.Path.class) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Path extends ProtocolMessage<Path>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 3872 */     private List<Element> element_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final Path IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kElementGroup = 1;
/*      */     public static final int kElementtype = 2;
/*      */     public static final int kElementid = 3;
/*      */     public static final int kElementname = 4;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int elementSize()
/*      */     {
/* 3877 */       return this.element_ != null ? this.element_.size() : 0;
/*      */     }
/*      */     public final Element getElement(int i) {
/* 3880 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.element_ != null ? this.element_.size() : 0)); } else throw new AssertionError();
/* 3881 */       return (Element)this.element_.get(i);
/*      */     }
/*      */     public Path clearElement() {
/* 3884 */       if (this.element_ != null) this.element_.clear();
/* 3885 */       return this;
/*      */     }
/*      */     public Element getMutableElement(int i) {
/* 3888 */       assert ((i >= 0) && (this.element_ != null) && (i < this.element_.size()));
/* 3889 */       return (Element)this.element_.get(i);
/*      */     }
/*      */     public Element addElement() {
/* 3892 */       Element v = new Element();
/* 3893 */       if (this.element_ == null) this.element_ = new ArrayList(4);
/* 3894 */       this.element_.add(v);
/* 3895 */       return v;
/*      */     }
/*      */     public Element addElement(Element v) {
/* 3898 */       if (this.element_ == null) this.element_ = new ArrayList(4);
/* 3899 */       this.element_.add(v);
/* 3900 */       return v;
/*      */     }
/*      */     public Element insertElement(int i, Element v) {
/* 3903 */       if (this.element_ == null) this.element_ = new ArrayList(4);
/* 3904 */       this.element_.add(i, v);
/* 3905 */       return v;
/*      */     }
/*      */     public Element removeElement(int i) {
/* 3908 */       return (Element)this.element_.remove(i);
/*      */     }
/*      */     public final Iterator<Element> elementIterator() {
/* 3911 */       if (this.element_ == null) {
/* 3912 */         return ProtocolSupport.emptyIterator();
/*      */       }
/* 3914 */       return this.element_.iterator();
/*      */     }
/*      */     public final List<Element> elements() {
/* 3917 */       return ProtocolSupport.unmodifiableList(this.element_);
/*      */     }
/*      */     public final List<Element> mutableElements() {
/* 3920 */       if (this.element_ == null) this.element_ = new ArrayList(4);
/* 3921 */       return this.element_;
/*      */     }
/*      */ 
/*      */     public Path mergeFrom(Path that)
/*      */     {
/* 3928 */       assert (that != this);
/*      */ 
/* 3930 */       if (that.element_ != null) {
/* 3931 */         for (Element v : that.element_) {
/* 3932 */           addElement().mergeFrom(v);
/*      */         }
/*      */       }
/*      */ 
/* 3936 */       if (that.uninterpreted != null) {
/* 3937 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3939 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Path that) {
/* 3943 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Path that) {
/* 3947 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Path that, boolean ignoreUninterpreted) {
/* 3951 */       if (that == null) return false;
/* 3952 */       if (that == this) return true;
/* 3955 */       int n;
/* 3955 */       if ((n = this.element_ != null ? this.element_.size() : 0) != (that.element_ != null ? that.element_.size() : 0)) return false;
/* 3956 */       for (int i = 0; i < n; i++) {
/* 3957 */         if (!((Element)this.element_.get(i)).equals((Element)that.element_.get(i), ignoreUninterpreted)) return false;
/*      */       }
/*      */ 
/* 3960 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3965 */       return ((that instanceof Path)) && (equals((Path)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3969 */       int hash = 501963979;
/*      */ 
/* 3971 */       hash *= 31;
/* 3972 */       int i = 0; for (int n = this.element_ != null ? this.element_.size() : 0; i < n; i++) {
/* 3973 */         hash = hash * 31 + ((Element)this.element_.get(i)).hashCode();
/*      */       }
/* 3975 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3976 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3978 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized()
/*      */     {
/* 3983 */       if (this.element_ != null) {
/* 3984 */         for (Element v : this.element_) {
/* 3985 */           if (!v.isInitialized()) {
/* 3986 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 3990 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 3994 */       int n = 0;
/*      */       int m;
/* 3997 */       n += (m = this.element_ != null ? this.element_.size() : 0);
/* 3998 */       for (int i = 0; i < m; i++) {
/* 3999 */         n += ((Element)this.element_.get(i)).encodingSize();
/*      */       }
/*      */ 
/* 4002 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 4007 */       int n = 0;
/*      */       int m;
/* 4010 */       n += (m = this.element_ != null ? this.element_.size() : 0);
/* 4011 */       for (int i = 0; i < m; i++) {
/* 4012 */         n += ((Element)this.element_.get(i)).maxEncodingSize();
/*      */       }
/*      */ 
/* 4015 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 4020 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 4024 */       if (this.element_ != null) this.element_.clear();
/* 4025 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Path newInstance() {
/* 4029 */       return new Path();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 4033 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 4056 */       int i = 0; for (int m = this.element_ != null ? this.element_.size() : 0; i < m; i++) {
/* 4057 */         Element v = (Element)this.element_.get(i);
/* 4058 */         sink.putByte(11);
/* 4059 */         v.outputTo(sink);
/*      */       }
/*      */ 
/* 4062 */       if (this.uninterpreted != null)
/* 4063 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 4068 */       boolean result = true;
/*      */ 
/* 4070 */       while (source.hasRemaining()) {
/* 4071 */         int tt = source.getVarInt();
/* 4072 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 4076 */           result = false;
/* 4077 */           break;
/*      */         case 11:
/* 4080 */           if (addElement().merge(source)) break; result = false; break;
/*      */         default:
/* 4083 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4088 */       return result;
/*      */     }
/*      */ 
/*      */     public Path getDefaultInstanceForType()
/*      */     {
/* 4093 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Path getDefaultInstance() {
/* 4097 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public Path freeze()
/*      */     {
/* 4148 */       this.element_ = ProtocolSupport.freezeMessages(this.element_);
/* 4149 */       return this;
/*      */     }
/*      */ 
/*      */     public Path unfreeze() {
/* 4153 */       this.element_ = ProtocolSupport.unfreezeMessages(this.element_);
/* 4154 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 4158 */       return ProtocolSupport.isFrozenMessages(this.element_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 4161 */       if (this.uninterpreted == null) {
/* 4162 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 4164 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4101 */       IMMUTABLE_DEFAULT_INSTANCE = new Path()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.Path clearElement()
/*      */         {
/* 4109 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Path.Element getMutableElement(int i) {
/* 4112 */           return (OnestoreEntity.Path.Element)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Path.Element addElement() {
/* 4115 */           return (OnestoreEntity.Path.Element)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Path.Element addElement(OnestoreEntity.Path.Element v) {
/* 4118 */           return (OnestoreEntity.Path.Element)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Path.Element insertElement(int i, OnestoreEntity.Path.Element v) {
/* 4121 */           return (OnestoreEntity.Path.Element)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */         public OnestoreEntity.Path.Element removeElement(int i) {
/* 4124 */           return (OnestoreEntity.Path.Element)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Path mergeFrom(OnestoreEntity.Path that) {
/* 4128 */           ProtocolSupport.unsupportedOperation();
/* 4129 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 4132 */           ProtocolSupport.unsupportedOperation();
/* 4133 */           return false;
/*      */         }
/*      */         public OnestoreEntity.Path freeze() {
/* 4136 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Path unfreeze() {
/* 4139 */           ProtocolSupport.unsupportedOperation();
/* 4140 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 4143 */           return true;
/*      */         }
/*      */       };
/* 4172 */       text = new String[5];
/*      */ 
/* 4174 */       text[0] = "ErrorCode";
/* 4175 */       text[1] = "Element";
/* 4176 */       text[2] = "type";
/* 4177 */       text[3] = "id";
/* 4178 */       text[4] = "name";
/*      */ 
/* 4181 */       types = new int[5];
/*      */ 
/* 4183 */       Arrays.fill(types, 6);
/* 4184 */       types[0] = 0;
/* 4185 */       types[1] = 3;
/* 4186 */       types[2] = 2;
/* 4187 */       types[3] = 0;
/* 4188 */       types[4] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 4037 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.Path.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("Element", "element", 1, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, OnestoreEntity.Path.Element.class) });
/*      */     }
/*      */ 
/*      */     public static class Element extends ProtocolMessage<Element>
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/* 3465 */       private byte[] type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3466 */       private long id_ = 0L;
/* 3467 */       private byte[] name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */       private UninterpretedTags uninterpreted;
/*      */       private int optional_0_;
/*      */       public static final Element IMMUTABLE_DEFAULT_INSTANCE;
/*      */ 
/*      */       public final byte[] getTypeAsBytes()
/*      */       {
/* 3473 */         return this.type_;
/*      */       }
/*      */       public final boolean hasType() {
/* 3476 */         return (this.optional_0_ & 0x1) != 0;
/*      */       }
/*      */       public Element clearType() {
/* 3479 */         this.optional_0_ &= -2;
/* 3480 */         this.type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3481 */         return this;
/*      */       }
/*      */       public Element setTypeAsBytes(byte[] x) {
/* 3484 */         this.optional_0_ |= 1;
/* 3485 */         this.type_ = x;
/* 3486 */         return this;
/*      */       }
/*      */       public final String getType() {
/* 3489 */         return ProtocolSupport.toStringUtf8(this.type_);
/*      */       }
/*      */       public Element setType(String v) {
/* 3492 */         if (v == null) throw new NullPointerException();
/* 3493 */         this.optional_0_ |= 1;
/* 3494 */         this.type_ = ProtocolSupport.toBytesUtf8(v);
/* 3495 */         return this;
/*      */       }
/*      */       public final String getType(Charset cs) {
/* 3498 */         return ProtocolSupport.toString(this.type_, cs);
/*      */       }
/*      */       public Element setType(String v, Charset cs) {
/* 3501 */         if (v == null) throw new NullPointerException();
/* 3502 */         this.optional_0_ |= 1;
/* 3503 */         this.type_ = ProtocolSupport.toBytes(v, cs);
/* 3504 */         return this;
/*      */       }
/*      */ 
/*      */       public final long getId()
/*      */       {
/* 3509 */         return this.id_;
/*      */       }
/*      */       public final boolean hasId() {
/* 3512 */         return (this.optional_0_ & 0x2) != 0;
/*      */       }
/*      */       public Element clearId() {
/* 3515 */         this.optional_0_ &= -3;
/* 3516 */         this.id_ = 0L;
/* 3517 */         return this;
/*      */       }
/*      */       public Element setId(long x) {
/* 3520 */         this.optional_0_ |= 2;
/* 3521 */         this.id_ = x;
/* 3522 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getNameAsBytes()
/*      */       {
/* 3527 */         return this.name_;
/*      */       }
/*      */       public final boolean hasName() {
/* 3530 */         return (this.optional_0_ & 0x4) != 0;
/*      */       }
/*      */       public Element clearName() {
/* 3533 */         this.optional_0_ &= -5;
/* 3534 */         this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3535 */         return this;
/*      */       }
/*      */       public Element setNameAsBytes(byte[] x) {
/* 3538 */         this.optional_0_ |= 4;
/* 3539 */         this.name_ = x;
/* 3540 */         return this;
/*      */       }
/*      */       public final String getName() {
/* 3543 */         return ProtocolSupport.toStringUtf8(this.name_);
/*      */       }
/*      */       public Element setName(String v) {
/* 3546 */         if (v == null) throw new NullPointerException();
/* 3547 */         this.optional_0_ |= 4;
/* 3548 */         this.name_ = ProtocolSupport.toBytesUtf8(v);
/* 3549 */         return this;
/*      */       }
/*      */       public final String getName(Charset cs) {
/* 3552 */         return ProtocolSupport.toString(this.name_, cs);
/*      */       }
/*      */       public Element setName(String v, Charset cs) {
/* 3555 */         if (v == null) throw new NullPointerException();
/* 3556 */         this.optional_0_ |= 4;
/* 3557 */         this.name_ = ProtocolSupport.toBytes(v, cs);
/* 3558 */         return this;
/*      */       }
/*      */ 
/*      */       public Element mergeFrom(Element that)
/*      */       {
/* 3565 */         assert (that != this);
/* 3566 */         int this_t0 = this.optional_0_;
/* 3567 */         int that_t0 = that.optional_0_;
/*      */ 
/* 3569 */         if ((that_t0 & 0x1) != 0) {
/* 3570 */           this_t0 |= 1;
/* 3571 */           this.type_ = that.type_;
/*      */         }
/*      */ 
/* 3574 */         if ((that_t0 & 0x2) != 0) {
/* 3575 */           this_t0 |= 2;
/* 3576 */           this.id_ = that.id_;
/*      */         }
/*      */ 
/* 3579 */         if ((that_t0 & 0x4) != 0) {
/* 3580 */           this_t0 |= 4;
/* 3581 */           this.name_ = that.name_;
/*      */         }
/*      */ 
/* 3584 */         if (that.uninterpreted != null) {
/* 3585 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */         }
/* 3587 */         this.optional_0_ = this_t0;
/* 3588 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean equalsIgnoreUninterpreted(Element that) {
/* 3592 */         return equals(that, true);
/*      */       }
/*      */ 
/*      */       public boolean equals(Element that) {
/* 3596 */         return equals(that, false);
/*      */       }
/*      */ 
/*      */       public boolean equals(Element that, boolean ignoreUninterpreted) {
/* 3600 */         if (that == null) return false;
/* 3601 */         if (that == this) return true;
/* 3602 */         int this_t0 = this.optional_0_;
/* 3603 */         int that_t0 = that.optional_0_;
/* 3604 */         if (this_t0 != that_t0) return false;
/*      */ 
/* 3606 */         if (((this_t0 & 0x1) != 0) && 
/* 3607 */           (!Arrays.equals(this.type_, that.type_))) return false;
/*      */ 
/* 3610 */         if (((this_t0 & 0x2) != 0) && 
/* 3611 */           (this.id_ != that.id_)) return false;
/*      */ 
/* 3614 */         if (((this_t0 & 0x4) != 0) && 
/* 3615 */           (!Arrays.equals(this.name_, that.name_))) return false;
/*      */ 
/* 3618 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object that)
/*      */       {
/* 3623 */         return ((that instanceof Element)) && (equals((Element)that));
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/* 3627 */         int hash = -1771826010;
/*      */ 
/* 3629 */         int this_t0 = this.optional_0_;
/* 3630 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.type_) : -113);
/*      */ 
/* 3632 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.id_) : -113);
/*      */ 
/* 3634 */         hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.name_) : -113);
/* 3635 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3636 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*      */         }
/* 3638 */         return hash;
/*      */       }
/*      */ 
/*      */       public boolean isInitialized() {
/* 3642 */         int this_t0 = this.optional_0_;
/*      */ 
/* 3644 */         return (this_t0 & 0x1) == 1;
/*      */       }
/*      */ 
/*      */       public int encodingSize()
/*      */       {
/* 3652 */         int n = 2 + Protocol.stringSize(this.type_.length);
/* 3653 */         int this_t0 = this.optional_0_;
/* 3654 */         if ((this_t0 & 0x6) != 0) {
/* 3655 */           if ((this_t0 & 0x2) != 0)
/*      */           {
/* 3657 */             n += 1 + Protocol.varLongSize(this.id_);
/*      */           }
/* 3659 */           if ((this_t0 & 0x4) != 0)
/*      */           {
/* 3661 */             n += 1 + Protocol.stringSize(this.name_.length);
/*      */           }
/*      */         }
/*      */ 
/* 3665 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */       }
/*      */ 
/*      */       public int maxEncodingSize()
/*      */       {
/* 3673 */         int n = 18 + this.type_.length;
/* 3674 */         int this_t0 = this.optional_0_;
/* 3675 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 3677 */           n += 6 + this.name_.length;
/*      */         }
/*      */ 
/* 3680 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */       }
/*      */ 
/*      */       public MessageAppender getMessageAppender()
/*      */       {
/* 3685 */         return getUninterpretedForWrite();
/*      */       }
/*      */ 
/*      */       public void clear() {
/* 3689 */         this.optional_0_ = 0;
/* 3690 */         this.type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3691 */         this.id_ = 0L;
/* 3692 */         this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3693 */         this.uninterpreted = null;
/*      */       }
/*      */ 
/*      */       public Element newInstance() {
/* 3697 */         return new Element();
/*      */       }
/*      */ 
/*      */       public ProtocolType getProtocolType() {
/* 3701 */         return StaticHolder.protocolType;
/*      */       }
/*      */ 
/*      */       public void outputTo(ProtocolSink sink)
/*      */       {
/* 3718 */         sink.putByte(18);
/* 3719 */         sink.putPrefixedData(this.type_);
/*      */ 
/* 3721 */         int this_t0 = this.optional_0_;
/* 3722 */         if ((this_t0 & 0x2) != 0) {
/* 3723 */           sink.putByte(24);
/* 3724 */           sink.putVarLong(this.id_);
/*      */         }
/*      */ 
/* 3727 */         if ((this_t0 & 0x4) != 0) {
/* 3728 */           sink.putByte(34);
/* 3729 */           sink.putPrefixedData(this.name_);
/*      */         }
/*      */ 
/* 3732 */         if (this.uninterpreted != null) {
/* 3733 */           this.uninterpreted.put(sink);
/*      */         }
/*      */ 
/* 3736 */         sink.putByte(12);
/*      */       }
/*      */ 
/*      */       public boolean merge(ProtocolSource source) {
/* 3740 */         boolean result = true;
/* 3741 */         int this_t0 = this.optional_0_;
/*      */         while (true)
/*      */         {
/* 3744 */           int tt = source.getVarInt();
/* 3745 */           switch (tt)
/*      */           {
/*      */           case 12:
/* 3748 */             break;
/*      */           case 0:
/* 3752 */             result = false;
/* 3753 */             break;
/*      */           case 18:
/* 3756 */             this.type_ = source.getPrefixedData();
/* 3757 */             this_t0 |= 1;
/* 3758 */             break;
/*      */           case 24:
/* 3761 */             this.id_ = source.getVarLong();
/* 3762 */             this_t0 |= 2;
/* 3763 */             break;
/*      */           case 34:
/* 3766 */             this.name_ = source.getPrefixedData();
/* 3767 */             this_t0 |= 4;
/* 3768 */             break;
/*      */           default:
/* 3770 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 3775 */         this.optional_0_ = this_t0;
/* 3776 */         return result;
/*      */       }
/*      */ 
/*      */       public Element getDefaultInstanceForType()
/*      */       {
/* 3781 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public static final Element getDefaultInstance() {
/* 3785 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public Element freeze()
/*      */       {
/* 3859 */         this.type_ = ProtocolSupport.freezeString(this.type_);
/* 3860 */         this.name_ = ProtocolSupport.freezeString(this.name_);
/* 3861 */         return this;
/*      */       }
/*      */       public UninterpretedTags getUninterpretedForWrite() {
/* 3864 */         if (this.uninterpreted == null) {
/* 3865 */           this.uninterpreted = new UninterpretedTags();
/*      */         }
/* 3867 */         return this.uninterpreted;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 3789 */         IMMUTABLE_DEFAULT_INSTANCE = new Element()
/*      */         {
/*      */           private static final long serialVersionUID = 1L;
/*      */ 
/*      */           public OnestoreEntity.Path.Element clearType()
/*      */           {
/* 3797 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setTypeAsBytes(byte[] x) {
/* 3800 */             ProtocolSupport.unsupportedOperation();
/* 3801 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setType(String v) {
/* 3804 */             ProtocolSupport.unsupportedOperation();
/* 3805 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setType(String v, Charset cs) {
/* 3808 */             ProtocolSupport.unsupportedOperation();
/* 3809 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.Path.Element clearId()
/*      */           {
/* 3814 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setId(long x) {
/* 3817 */             ProtocolSupport.unsupportedOperation();
/* 3818 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.Path.Element clearName()
/*      */           {
/* 3823 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setNameAsBytes(byte[] x) {
/* 3826 */             ProtocolSupport.unsupportedOperation();
/* 3827 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setName(String v) {
/* 3830 */             ProtocolSupport.unsupportedOperation();
/* 3831 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element setName(String v, Charset cs) {
/* 3834 */             ProtocolSupport.unsupportedOperation();
/* 3835 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.Path.Element mergeFrom(OnestoreEntity.Path.Element that) {
/* 3839 */             ProtocolSupport.unsupportedOperation();
/* 3840 */             return this;
/*      */           }
/*      */           public boolean merge(ProtocolSource source) {
/* 3843 */             ProtocolSupport.unsupportedOperation();
/* 3844 */             return false;
/*      */           }
/*      */           public OnestoreEntity.Path.Element freeze() {
/* 3847 */             return this;
/*      */           }
/*      */           public OnestoreEntity.Path.Element unfreeze() {
/* 3850 */             ProtocolSupport.unsupportedOperation();
/* 3851 */             return this;
/*      */           }
/*      */           public boolean isFrozen() {
/* 3854 */             return true;
/*      */           }
/*      */         };
/*      */       }
/*      */ 
/*      */       private static class StaticHolder
/*      */       {
/* 3705 */         private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.Path.Element.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("type", "type", 2, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("id", "id", 3, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("name", "name", 4, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Property extends ProtocolMessage<Property>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2795 */     private int meaning_ = 0;
/* 2796 */     private byte[] meaning_uri_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2797 */     private byte[] name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2798 */     private OnestoreEntity.PropertyValue value_ = new OnestoreEntity.PropertyValue();
/* 2799 */     private boolean multiple_ = false;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final Property IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kmeaning = 1;
/*      */     public static final int kmeaning_uri = 2;
/*      */     public static final int kname = 3;
/*      */     public static final int kvalue = 5;
/*      */     public static final int kmultiple = 4;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int getMeaning()
/*      */     {
/* 2856 */       return this.meaning_;
/*      */     }
/*      */     public Meaning getMeaningEnum() {
/* 2859 */       return Meaning.valueOf(getMeaning());
/*      */     }
/*      */     public final boolean hasMeaning() {
/* 2862 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public Property clearMeaning() {
/* 2865 */       this.optional_0_ &= -2;
/* 2866 */       this.meaning_ = 0;
/* 2867 */       return this;
/*      */     }
/*      */     public Property setMeaning(int x) {
/* 2870 */       this.optional_0_ |= 1;
/* 2871 */       this.meaning_ = x;
/* 2872 */       return this;
/*      */     }
/*      */     public Property setMeaning(Meaning x) {
/* 2875 */       if (x == null) {
/* 2876 */         this.optional_0_ &= -2;
/* 2877 */         this.meaning_ = 0;
/*      */       } else {
/* 2879 */         setMeaning(x.getValue());
/*      */       }
/* 2881 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getMeaningUriAsBytes()
/*      */     {
/* 2886 */       return this.meaning_uri_;
/*      */     }
/*      */     public final boolean hasMeaningUri() {
/* 2889 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public Property clearMeaningUri() {
/* 2892 */       this.optional_0_ &= -3;
/* 2893 */       this.meaning_uri_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2894 */       return this;
/*      */     }
/*      */     public Property setMeaningUriAsBytes(byte[] x) {
/* 2897 */       this.optional_0_ |= 2;
/* 2898 */       this.meaning_uri_ = x;
/* 2899 */       return this;
/*      */     }
/*      */     public final String getMeaningUri() {
/* 2902 */       return ProtocolSupport.toStringUtf8(this.meaning_uri_);
/*      */     }
/*      */     public Property setMeaningUri(String v) {
/* 2905 */       if (v == null) throw new NullPointerException();
/* 2906 */       this.optional_0_ |= 2;
/* 2907 */       this.meaning_uri_ = ProtocolSupport.toBytesUtf8(v);
/* 2908 */       return this;
/*      */     }
/*      */     public final String getMeaningUri(Charset cs) {
/* 2911 */       return ProtocolSupport.toString(this.meaning_uri_, cs);
/*      */     }
/*      */     public Property setMeaningUri(String v, Charset cs) {
/* 2914 */       if (v == null) throw new NullPointerException();
/* 2915 */       this.optional_0_ |= 2;
/* 2916 */       this.meaning_uri_ = ProtocolSupport.toBytes(v, cs);
/* 2917 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getNameAsBytes()
/*      */     {
/* 2922 */       return this.name_;
/*      */     }
/*      */     public final boolean hasName() {
/* 2925 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public Property clearName() {
/* 2928 */       this.optional_0_ &= -5;
/* 2929 */       this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2930 */       return this;
/*      */     }
/*      */     public Property setNameAsBytes(byte[] x) {
/* 2933 */       this.optional_0_ |= 4;
/* 2934 */       this.name_ = x;
/* 2935 */       return this;
/*      */     }
/*      */     public final String getName() {
/* 2938 */       return ProtocolSupport.toStringUtf8(this.name_);
/*      */     }
/*      */     public Property setName(String v) {
/* 2941 */       if (v == null) throw new NullPointerException();
/* 2942 */       this.optional_0_ |= 4;
/* 2943 */       this.name_ = ProtocolSupport.toBytesUtf8(v);
/* 2944 */       return this;
/*      */     }
/*      */     public final String getName(Charset cs) {
/* 2947 */       return ProtocolSupport.toString(this.name_, cs);
/*      */     }
/*      */     public Property setName(String v, Charset cs) {
/* 2950 */       if (v == null) throw new NullPointerException();
/* 2951 */       this.optional_0_ |= 4;
/* 2952 */       this.name_ = ProtocolSupport.toBytes(v, cs);
/* 2953 */       return this;
/*      */     }
/*      */ 
/*      */     public final OnestoreEntity.PropertyValue getValue()
/*      */     {
/* 2958 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/* 2961 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public Property clearValue() {
/* 2964 */       this.optional_0_ &= -9;
/* 2965 */       this.value_.clear();
/* 2966 */       return this;
/*      */     }
/*      */     public Property setValue(OnestoreEntity.PropertyValue x) {
/* 2969 */       if (x == null) throw new NullPointerException();
/* 2970 */       this.optional_0_ |= 8;
/* 2971 */       this.value_ = x;
/* 2972 */       return this;
/*      */     }
/*      */     public OnestoreEntity.PropertyValue getMutableValue() {
/* 2975 */       this.optional_0_ |= 8;
/* 2976 */       return this.value_;
/*      */     }
/*      */ 
/*      */     public final boolean isMultiple()
/*      */     {
/* 2981 */       return this.multiple_;
/*      */     }
/*      */     public final boolean hasMultiple() {
/* 2984 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public Property clearMultiple() {
/* 2987 */       this.optional_0_ &= -17;
/* 2988 */       this.multiple_ = false;
/* 2989 */       return this;
/*      */     }
/*      */     public Property setMultiple(boolean x) {
/* 2992 */       this.optional_0_ |= 16;
/* 2993 */       this.multiple_ = x;
/* 2994 */       return this;
/*      */     }
/*      */ 
/*      */     public Property mergeFrom(Property that)
/*      */     {
/* 3001 */       assert (that != this);
/* 3002 */       int this_t0 = this.optional_0_;
/* 3003 */       int that_t0 = that.optional_0_;
/*      */ 
/* 3005 */       if ((that_t0 & 0x1) != 0) {
/* 3006 */         this_t0 |= 1;
/* 3007 */         this.meaning_ = that.meaning_;
/*      */       }
/*      */ 
/* 3010 */       if ((that_t0 & 0x2) != 0) {
/* 3011 */         this_t0 |= 2;
/* 3012 */         this.meaning_uri_ = that.meaning_uri_;
/*      */       }
/*      */ 
/* 3015 */       if ((that_t0 & 0x4) != 0) {
/* 3016 */         this_t0 |= 4;
/* 3017 */         this.name_ = that.name_;
/*      */       }
/*      */ 
/* 3020 */       if ((that_t0 & 0x8) != 0) {
/* 3021 */         this_t0 |= 8;
/* 3022 */         OnestoreEntity.PropertyValue v = this.value_;
/* 3023 */         v.mergeFrom(that.value_);
/*      */       }
/*      */ 
/* 3026 */       if ((that_t0 & 0x10) != 0) {
/* 3027 */         this_t0 |= 16;
/* 3028 */         this.multiple_ = that.multiple_;
/*      */       }
/*      */ 
/* 3031 */       if (that.uninterpreted != null) {
/* 3032 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 3034 */       this.optional_0_ = this_t0;
/* 3035 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Property that) {
/* 3039 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Property that) {
/* 3043 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Property that, boolean ignoreUninterpreted) {
/* 3047 */       if (that == null) return false;
/* 3048 */       if (that == this) return true;
/* 3049 */       int this_t0 = this.optional_0_;
/* 3050 */       int that_t0 = that.optional_0_;
/* 3051 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 3053 */       if (((this_t0 & 0x1) != 0) && 
/* 3054 */         (this.meaning_ != that.meaning_)) return false;
/*      */ 
/* 3057 */       if (((this_t0 & 0x2) != 0) && 
/* 3058 */         (!Arrays.equals(this.meaning_uri_, that.meaning_uri_))) return false;
/*      */ 
/* 3061 */       if (((this_t0 & 0x4) != 0) && 
/* 3062 */         (!Arrays.equals(this.name_, that.name_))) return false;
/*      */ 
/* 3065 */       if (((this_t0 & 0x8) != 0) && 
/* 3066 */         (!this.value_.equals(that.value_, ignoreUninterpreted))) return false;
/*      */ 
/* 3069 */       if (((this_t0 & 0x10) != 0) && 
/* 3070 */         (this.multiple_ != that.multiple_)) return false;
/*      */ 
/* 3073 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 3078 */       return ((that instanceof Property)) && (equals((Property)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 3082 */       int hash = -1811859523;
/*      */ 
/* 3084 */       int this_t0 = this.optional_0_;
/* 3085 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.meaning_ : -113);
/*      */ 
/* 3087 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.meaning_uri_) : -113);
/*      */ 
/* 3089 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.name_) : -113);
/*      */ 
/* 3091 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? 1237 : this.multiple_ ? 1231 : -113);
/*      */ 
/* 3093 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.value_.hashCode() : -113);
/* 3094 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 3095 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 3097 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 3101 */       int this_t0 = this.optional_0_;
/* 3102 */       if ((this_t0 & 0x1C) != 28) {
/* 3103 */         if ((this_t0 & 0x4) == 0) {
/* 3104 */           return false;
/*      */         }
/*      */ 
/* 3107 */         return (this_t0 & 0x8) != 0;
/*      */       }
/*      */ 
/* 3113 */       return this.value_.isInitialized();
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 3122 */       int n = 4 + Protocol.stringSize(this.name_.length) + Protocol.stringSize(this.value_.encodingSize());
/*      */ 
/* 3124 */       int this_t0 = this.optional_0_;
/* 3125 */       if ((this_t0 & 0x3) != 0) {
/* 3126 */         if ((this_t0 & 0x1) != 0)
/*      */         {
/* 3128 */           n += 1 + Protocol.varLongSize(this.meaning_);
/*      */         }
/* 3130 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 3132 */           n += 1 + Protocol.stringSize(this.meaning_uri_.length);
/*      */         }
/*      */       }
/*      */ 
/* 3136 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 3145 */       int n = 25 + this.name_.length + this.value_.maxEncodingSize();
/* 3146 */       int this_t0 = this.optional_0_;
/* 3147 */       if ((this_t0 & 0x2) != 0)
/*      */       {
/* 3149 */         n += 6 + this.meaning_uri_.length;
/*      */       }
/*      */ 
/* 3152 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 3157 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 3161 */       this.optional_0_ = 0;
/* 3162 */       this.meaning_ = 0;
/* 3163 */       this.meaning_uri_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3164 */       this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 3165 */       this.value_.clear();
/* 3166 */       this.multiple_ = false;
/* 3167 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Property newInstance() {
/* 3171 */       return new Property();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 3175 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 3231 */       int this_t0 = this.optional_0_;
/* 3232 */       if ((this_t0 & 0x1) != 0) {
/* 3233 */         sink.putByte(8);
/* 3234 */         sink.putVarLong(this.meaning_);
/*      */       }
/*      */ 
/* 3237 */       if ((this_t0 & 0x2) != 0) {
/* 3238 */         sink.putByte(18);
/* 3239 */         sink.putPrefixedData(this.meaning_uri_);
/*      */       }
/*      */ 
/* 3242 */       sink.putByte(26);
/* 3243 */       sink.putPrefixedData(this.name_);
/*      */ 
/* 3245 */       sink.putByte(32);
/* 3246 */       sink.putBoolean(this.multiple_);
/*      */ 
/* 3248 */       sink.putByte(42);
/* 3249 */       sink.putForeign(this.value_);
/*      */ 
/* 3251 */       if (this.uninterpreted != null)
/* 3252 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 3257 */       boolean result = true;
/* 3258 */       int this_t0 = this.optional_0_;
/*      */ 
/* 3260 */       while (source.hasRemaining()) {
/* 3261 */         int tt = source.getVarInt();
/* 3262 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 3266 */           result = false;
/* 3267 */           break;
/*      */         case 8:
/* 3270 */           this.meaning_ = source.getVarInt();
/* 3271 */           this_t0 |= 1;
/* 3272 */           break;
/*      */         case 18:
/* 3275 */           this.meaning_uri_ = source.getPrefixedData();
/* 3276 */           this_t0 |= 2;
/* 3277 */           break;
/*      */         case 26:
/* 3280 */           this.name_ = source.getPrefixedData();
/* 3281 */           this_t0 |= 4;
/* 3282 */           break;
/*      */         case 32:
/* 3285 */           this.multiple_ = source.getBoolean();
/* 3286 */           this_t0 |= 16;
/* 3287 */           break;
/*      */         case 42:
/* 3290 */           source.push(source.getVarInt());
/* 3291 */           if (!this.value_.merge(source)) { result = false; break label205; }
/* 3292 */           source.pop();
/* 3293 */           this_t0 |= 8;
/* 3294 */           break;
/*      */         default:
/* 3296 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3301 */       label205: this.optional_0_ = this_t0;
/* 3302 */       return result;
/*      */     }
/*      */ 
/*      */     public Property getDefaultInstanceForType()
/*      */     {
/* 3307 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Property getDefaultInstance() {
/* 3311 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public Property freeze()
/*      */     {
/* 3406 */       this.meaning_uri_ = ProtocolSupport.freezeString(this.meaning_uri_);
/* 3407 */       this.name_ = ProtocolSupport.freezeString(this.name_);
/* 3408 */       this.value_.freeze();
/* 3409 */       return this;
/*      */     }
/*      */ 
/*      */     public Property unfreeze() {
/* 3413 */       this.value_.unfreeze();
/* 3414 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 3418 */       return this.value_.isFrozen();
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 3421 */       if (this.uninterpreted == null) {
/* 3422 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 3424 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3315 */       IMMUTABLE_DEFAULT_INSTANCE = new Property()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.Property clearMeaning()
/*      */         {
/* 3323 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setMeaning(int x) {
/* 3326 */           ProtocolSupport.unsupportedOperation();
/* 3327 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Property clearMeaningUri()
/*      */         {
/* 3332 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setMeaningUriAsBytes(byte[] x) {
/* 3335 */           ProtocolSupport.unsupportedOperation();
/* 3336 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setMeaningUri(String v) {
/* 3339 */           ProtocolSupport.unsupportedOperation();
/* 3340 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setMeaningUri(String v, Charset cs) {
/* 3343 */           ProtocolSupport.unsupportedOperation();
/* 3344 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Property clearName()
/*      */         {
/* 3349 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setNameAsBytes(byte[] x) {
/* 3352 */           ProtocolSupport.unsupportedOperation();
/* 3353 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setName(String v) {
/* 3356 */           ProtocolSupport.unsupportedOperation();
/* 3357 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setName(String v, Charset cs) {
/* 3360 */           ProtocolSupport.unsupportedOperation();
/* 3361 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Property clearValue()
/*      */         {
/* 3366 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setValue(OnestoreEntity.PropertyValue x) {
/* 3369 */           ProtocolSupport.unsupportedOperation();
/* 3370 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue getMutableValue() {
/* 3373 */           return (OnestoreEntity.PropertyValue)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Property clearMultiple()
/*      */         {
/* 3378 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property setMultiple(boolean x) {
/* 3381 */           ProtocolSupport.unsupportedOperation();
/* 3382 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.Property mergeFrom(OnestoreEntity.Property that) {
/* 3386 */           ProtocolSupport.unsupportedOperation();
/* 3387 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 3390 */           ProtocolSupport.unsupportedOperation();
/* 3391 */           return false;
/*      */         }
/*      */         public OnestoreEntity.Property freeze() {
/* 3394 */           return this;
/*      */         }
/*      */         public OnestoreEntity.Property unfreeze() {
/* 3397 */           ProtocolSupport.unsupportedOperation();
/* 3398 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 3401 */           return true;
/*      */         }
/*      */       };
/* 3433 */       text = new String[6];
/*      */ 
/* 3435 */       text[0] = "ErrorCode";
/* 3436 */       text[1] = "meaning";
/* 3437 */       text[2] = "meaning_uri";
/* 3438 */       text[3] = "name";
/* 3439 */       text[4] = "multiple";
/* 3440 */       text[5] = "value";
/*      */ 
/* 3443 */       types = new int[6];
/*      */ 
/* 3445 */       Arrays.fill(types, 6);
/* 3446 */       types[0] = 0;
/* 3447 */       types[1] = 0;
/* 3448 */       types[2] = 2;
/* 3449 */       types[3] = 2;
/* 3450 */       types[4] = 0;
/* 3451 */       types[5] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 3179 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.Property.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("meaning", "meaning", 1, 0, ProtocolType.Presence.OPTIONAL, OnestoreEntity.Property.Meaning.class), new ProtocolType.FieldType("meaning_uri", "meaning_uri", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("name", "name", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("value", "value", 5, 3, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, OnestoreEntity.PropertyValue.class), new ProtocolType.FieldType("multiple", "multiple", 4, 4, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */ 
/*      */     public static enum Meaning
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 2804 */       BLOB(14), 
/* 2805 */       TEXT(15), 
/* 2806 */       BYTESTRING(16), 
/* 2807 */       ATOM_CATEGORY(1), 
/* 2808 */       ATOM_LINK(2), 
/* 2809 */       ATOM_TITLE(3), 
/* 2810 */       ATOM_CONTENT(4), 
/* 2811 */       ATOM_SUMMARY(5), 
/* 2812 */       ATOM_AUTHOR(6), 
/* 2813 */       GD_WHEN(7), 
/* 2814 */       GD_EMAIL(8), 
/* 2815 */       GEORSS_POINT(9), 
/* 2816 */       GD_IM(10), 
/* 2817 */       GD_PHONENUMBER(11), 
/* 2818 */       GD_POSTALADDRESS(12), 
/* 2819 */       GD_RATING(13), 
/* 2820 */       BLOBKEY(17);
/*      */ 
/*      */       public static final Meaning Meaning_MIN;
/*      */       public static final Meaning Meaning_MAX;
/*      */       private final int value;
/*      */ 
/* 2825 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static Meaning valueOf(int value) {
/* 2828 */         switch (value) { case 1:
/* 2829 */           return ATOM_CATEGORY;
/*      */         case 2:
/* 2830 */           return ATOM_LINK;
/*      */         case 3:
/* 2831 */           return ATOM_TITLE;
/*      */         case 4:
/* 2832 */           return ATOM_CONTENT;
/*      */         case 5:
/* 2833 */           return ATOM_SUMMARY;
/*      */         case 6:
/* 2834 */           return ATOM_AUTHOR;
/*      */         case 7:
/* 2835 */           return GD_WHEN;
/*      */         case 8:
/* 2836 */           return GD_EMAIL;
/*      */         case 9:
/* 2837 */           return GEORSS_POINT;
/*      */         case 10:
/* 2838 */           return GD_IM;
/*      */         case 11:
/* 2839 */           return GD_PHONENUMBER;
/*      */         case 12:
/* 2840 */           return GD_POSTALADDRESS;
/*      */         case 13:
/* 2841 */           return GD_RATING;
/*      */         case 14:
/* 2842 */           return BLOB;
/*      */         case 15:
/* 2843 */           return TEXT;
/*      */         case 16:
/* 2844 */           return BYTESTRING;
/*      */         case 17:
/* 2845 */           return BLOBKEY;
/*      */         }
/* 2847 */         return null;
/*      */       }
/*      */ 
/*      */       private Meaning(int v) {
/* 2851 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 2822 */         Meaning_MIN = ATOM_CATEGORY;
/* 2823 */         Meaning_MAX = BLOBKEY;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class PropertyValue extends ProtocolMessage<PropertyValue>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1963 */     private long int64value_ = 0L;
/* 1964 */     private boolean booleanvalue_ = false;
/* 1965 */     private byte[] stringvalue_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1966 */     private double doublevalue_ = 0.0D;
/* 1967 */     private PointValue pointvalue_ = null;
/* 1968 */     private UserValue uservalue_ = null;
/* 1969 */     private ReferenceValue referencevalue_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final PropertyValue IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kint64Value = 1;
/*      */     public static final int kbooleanValue = 2;
/*      */     public static final int kstringValue = 3;
/*      */     public static final int kdoubleValue = 4;
/*      */     public static final int kPointValueGroup = 5;
/*      */     public static final int kPointValuex = 6;
/*      */     public static final int kPointValuey = 7;
/*      */     public static final int kUserValueGroup = 8;
/*      */     public static final int kUserValueemail = 9;
/*      */     public static final int kUserValueauth_domain = 10;
/*      */     public static final int kUserValuenickname = 11;
/*      */     public static final int kUserValuegaiaid = 18;
/*      */     public static final int kUserValueobfuscated_gaiaid = 19;
/*      */     public static final int kUserValuefederated_identity = 21;
/*      */     public static final int kUserValuefederated_provider = 22;
/*      */     public static final int kReferenceValueGroup = 12;
/*      */     public static final int kReferenceValueapp = 13;
/*      */     public static final int kReferenceValuename_space = 20;
/*      */     public static final int kReferenceValuePathElementGroup = 14;
/*      */     public static final int kReferenceValuePathElementtype = 15;
/*      */     public static final int kReferenceValuePathElementid = 16;
/*      */     public static final int kReferenceValuePathElementname = 17;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final long getInt64Value()
/*      */     {
/* 1975 */       return this.int64value_;
/*      */     }
/*      */     public final boolean hasInt64Value() {
/* 1978 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public PropertyValue clearInt64Value() {
/* 1981 */       this.optional_0_ &= -2;
/* 1982 */       this.int64value_ = 0L;
/* 1983 */       return this;
/*      */     }
/*      */     public PropertyValue setInt64Value(long x) {
/* 1986 */       this.optional_0_ |= 1;
/* 1987 */       this.int64value_ = x;
/* 1988 */       return this;
/*      */     }
/*      */ 
/*      */     public final boolean isBooleanValue()
/*      */     {
/* 1993 */       return this.booleanvalue_;
/*      */     }
/*      */     public final boolean hasBooleanValue() {
/* 1996 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public PropertyValue clearBooleanValue() {
/* 1999 */       this.optional_0_ &= -3;
/* 2000 */       this.booleanvalue_ = false;
/* 2001 */       return this;
/*      */     }
/*      */     public PropertyValue setBooleanValue(boolean x) {
/* 2004 */       this.optional_0_ |= 2;
/* 2005 */       this.booleanvalue_ = x;
/* 2006 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getStringValueAsBytes()
/*      */     {
/* 2011 */       return this.stringvalue_;
/*      */     }
/*      */     public final boolean hasStringValue() {
/* 2014 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public PropertyValue clearStringValue() {
/* 2017 */       this.optional_0_ &= -5;
/* 2018 */       this.stringvalue_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2019 */       return this;
/*      */     }
/*      */     public PropertyValue setStringValueAsBytes(byte[] x) {
/* 2022 */       this.optional_0_ |= 4;
/* 2023 */       this.stringvalue_ = x;
/* 2024 */       return this;
/*      */     }
/*      */     public final String getStringValue() {
/* 2027 */       return ProtocolSupport.toStringUtf8(this.stringvalue_);
/*      */     }
/*      */     public PropertyValue setStringValue(String v) {
/* 2030 */       if (v == null) throw new NullPointerException();
/* 2031 */       this.optional_0_ |= 4;
/* 2032 */       this.stringvalue_ = ProtocolSupport.toBytesUtf8(v);
/* 2033 */       return this;
/*      */     }
/*      */     public final String getStringValue(Charset cs) {
/* 2036 */       return ProtocolSupport.toString(this.stringvalue_, cs);
/*      */     }
/*      */     public PropertyValue setStringValue(String v, Charset cs) {
/* 2039 */       if (v == null) throw new NullPointerException();
/* 2040 */       this.optional_0_ |= 4;
/* 2041 */       this.stringvalue_ = ProtocolSupport.toBytes(v, cs);
/* 2042 */       return this;
/*      */     }
/*      */ 
/*      */     public final double getDoubleValue()
/*      */     {
/* 2047 */       return this.doublevalue_;
/*      */     }
/*      */     public final boolean hasDoubleValue() {
/* 2050 */       return (this.optional_0_ & 0x8) != 0;
/*      */     }
/*      */     public PropertyValue clearDoubleValue() {
/* 2053 */       this.optional_0_ &= -9;
/* 2054 */       this.doublevalue_ = 0.0D;
/* 2055 */       return this;
/*      */     }
/*      */     public PropertyValue setDoubleValue(double x) {
/* 2058 */       this.optional_0_ |= 8;
/* 2059 */       this.doublevalue_ = x;
/* 2060 */       return this;
/*      */     }
/*      */ 
/*      */     public final PointValue getPointValue()
/*      */     {
/* 2065 */       if (this.pointvalue_ == null) {
/* 2066 */         return PointValue.IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/* 2068 */       return this.pointvalue_;
/*      */     }
/*      */     public final boolean hasPointValue() {
/* 2071 */       return (this.optional_0_ & 0x10) != 0;
/*      */     }
/*      */     public PropertyValue clearPointValue() {
/* 2074 */       this.optional_0_ &= -17;
/* 2075 */       if (this.pointvalue_ != null) this.pointvalue_.clear();
/* 2076 */       return this;
/*      */     }
/*      */     public PropertyValue setPointValue(PointValue x) {
/* 2079 */       if (x == null) throw new NullPointerException();
/* 2080 */       this.optional_0_ |= 16;
/* 2081 */       this.pointvalue_ = x;
/* 2082 */       return this;
/*      */     }
/*      */     public PointValue getMutablePointValue() {
/* 2085 */       this.optional_0_ |= 16;
/* 2086 */       if (this.pointvalue_ == null) this.pointvalue_ = new PointValue();
/* 2087 */       return this.pointvalue_;
/*      */     }
/*      */ 
/*      */     public final UserValue getUserValue()
/*      */     {
/* 2092 */       if (this.uservalue_ == null) {
/* 2093 */         return UserValue.IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/* 2095 */       return this.uservalue_;
/*      */     }
/*      */     public final boolean hasUserValue() {
/* 2098 */       return (this.optional_0_ & 0x20) != 0;
/*      */     }
/*      */     public PropertyValue clearUserValue() {
/* 2101 */       this.optional_0_ &= -33;
/* 2102 */       if (this.uservalue_ != null) this.uservalue_.clear();
/* 2103 */       return this;
/*      */     }
/*      */     public PropertyValue setUserValue(UserValue x) {
/* 2106 */       if (x == null) throw new NullPointerException();
/* 2107 */       this.optional_0_ |= 32;
/* 2108 */       this.uservalue_ = x;
/* 2109 */       return this;
/*      */     }
/*      */     public UserValue getMutableUserValue() {
/* 2112 */       this.optional_0_ |= 32;
/* 2113 */       if (this.uservalue_ == null) this.uservalue_ = new UserValue();
/* 2114 */       return this.uservalue_;
/*      */     }
/*      */ 
/*      */     public final ReferenceValue getReferenceValue()
/*      */     {
/* 2119 */       if (this.referencevalue_ == null) {
/* 2120 */         return ReferenceValue.IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/* 2122 */       return this.referencevalue_;
/*      */     }
/*      */     public final boolean hasReferenceValue() {
/* 2125 */       return (this.optional_0_ & 0x40) != 0;
/*      */     }
/*      */     public PropertyValue clearReferenceValue() {
/* 2128 */       this.optional_0_ &= -65;
/* 2129 */       if (this.referencevalue_ != null) this.referencevalue_.clear();
/* 2130 */       return this;
/*      */     }
/*      */     public PropertyValue setReferenceValue(ReferenceValue x) {
/* 2133 */       if (x == null) throw new NullPointerException();
/* 2134 */       this.optional_0_ |= 64;
/* 2135 */       this.referencevalue_ = x;
/* 2136 */       return this;
/*      */     }
/*      */     public ReferenceValue getMutableReferenceValue() {
/* 2139 */       this.optional_0_ |= 64;
/* 2140 */       if (this.referencevalue_ == null) this.referencevalue_ = new ReferenceValue();
/* 2141 */       return this.referencevalue_;
/*      */     }
/*      */ 
/*      */     public PropertyValue mergeFrom(PropertyValue that)
/*      */     {
/* 2148 */       assert (that != this);
/* 2149 */       int this_t0 = this.optional_0_;
/* 2150 */       int that_t0 = that.optional_0_;
/*      */ 
/* 2152 */       if ((that_t0 & 0x1) != 0) {
/* 2153 */         this_t0 |= 1;
/* 2154 */         this.int64value_ = that.int64value_;
/*      */       }
/*      */ 
/* 2157 */       if ((that_t0 & 0x2) != 0) {
/* 2158 */         this_t0 |= 2;
/* 2159 */         this.booleanvalue_ = that.booleanvalue_;
/*      */       }
/*      */ 
/* 2162 */       if ((that_t0 & 0x4) != 0) {
/* 2163 */         this_t0 |= 4;
/* 2164 */         this.stringvalue_ = that.stringvalue_;
/*      */       }
/*      */ 
/* 2167 */       if ((that_t0 & 0x8) != 0) {
/* 2168 */         this_t0 |= 8;
/* 2169 */         this.doublevalue_ = that.doublevalue_;
/*      */       }
/*      */ 
/* 2172 */       if ((that_t0 & 0x10) != 0) {
/* 2173 */         this_t0 |= 16;
/* 2174 */         PointValue v = this.pointvalue_;
/* 2175 */         if (v == null) this.pointvalue_ = (v = new PointValue());
/* 2176 */         v.mergeFrom(that.pointvalue_);
/*      */       }
/*      */ 
/* 2179 */       if ((that_t0 & 0x20) != 0) {
/* 2180 */         this_t0 |= 32;
/* 2181 */         UserValue v = this.uservalue_;
/* 2182 */         if (v == null) this.uservalue_ = (v = new UserValue());
/* 2183 */         v.mergeFrom(that.uservalue_);
/*      */       }
/*      */ 
/* 2186 */       if ((that_t0 & 0x40) != 0) {
/* 2187 */         this_t0 |= 64;
/* 2188 */         ReferenceValue v = this.referencevalue_;
/* 2189 */         if (v == null) this.referencevalue_ = (v = new ReferenceValue());
/* 2190 */         v.mergeFrom(that.referencevalue_);
/*      */       }
/*      */ 
/* 2193 */       if (that.uninterpreted != null) {
/* 2194 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2196 */       this.optional_0_ = this_t0;
/* 2197 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(PropertyValue that) {
/* 2201 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(PropertyValue that) {
/* 2205 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(PropertyValue that, boolean ignoreUninterpreted) {
/* 2209 */       if (that == null) return false;
/* 2210 */       if (that == this) return true;
/* 2211 */       int this_t0 = this.optional_0_;
/* 2212 */       int that_t0 = that.optional_0_;
/* 2213 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 2215 */       if (((this_t0 & 0x1) != 0) && 
/* 2216 */         (this.int64value_ != that.int64value_)) return false;
/*      */ 
/* 2219 */       if (((this_t0 & 0x2) != 0) && 
/* 2220 */         (this.booleanvalue_ != that.booleanvalue_)) return false;
/*      */ 
/* 2223 */       if (((this_t0 & 0x4) != 0) && 
/* 2224 */         (!Arrays.equals(this.stringvalue_, that.stringvalue_))) return false;
/*      */ 
/* 2227 */       if (((this_t0 & 0x8) != 0) && 
/* 2228 */         (this.doublevalue_ != that.doublevalue_)) return false;
/*      */ 
/* 2231 */       if (((this_t0 & 0x10) != 0) && 
/* 2232 */         (!this.pointvalue_.equals(that.pointvalue_, ignoreUninterpreted))) return false;
/*      */ 
/* 2235 */       if (((this_t0 & 0x20) != 0) && 
/* 2236 */         (!this.uservalue_.equals(that.uservalue_, ignoreUninterpreted))) return false;
/*      */ 
/* 2239 */       if (((this_t0 & 0x40) != 0) && 
/* 2240 */         (!this.referencevalue_.equals(that.referencevalue_, ignoreUninterpreted))) return false;
/*      */ 
/* 2243 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2248 */       return ((that instanceof PropertyValue)) && (equals((PropertyValue)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2252 */       int hash = 198073609;
/*      */ 
/* 2254 */       int this_t0 = this.optional_0_;
/* 2255 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.int64value_) : -113);
/*      */ 
/* 2257 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? 1237 : this.booleanvalue_ ? 1231 : -113);
/*      */ 
/* 2259 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.stringvalue_) : -113);
/*      */ 
/* 2261 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? ProtocolSupport.hashCode(this.doublevalue_) : -113);
/*      */ 
/* 2263 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? this.pointvalue_.hashCode() : -113);
/*      */ 
/* 2265 */       hash = hash * 31 + ((this_t0 & 0x20) != 0 ? this.uservalue_.hashCode() : -113);
/*      */ 
/* 2267 */       hash = hash * 31 + ((this_t0 & 0x40) != 0 ? this.referencevalue_.hashCode() : -113);
/* 2268 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2269 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2271 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized()
/*      */     {
/* 2276 */       int this_t0 = this.optional_0_;
/* 2277 */       if (((this_t0 & 0x10) != 0) && 
/* 2278 */         (!this.pointvalue_.isInitialized())) {
/* 2279 */         return false;
/*      */       }
/*      */ 
/* 2283 */       if (((this_t0 & 0x20) != 0) && 
/* 2284 */         (!this.uservalue_.isInitialized())) {
/* 2285 */         return false;
/*      */       }
/*      */ 
/* 2291 */       return ((this_t0 & 0x40) == 0) || 
/* 2290 */         (this.referencevalue_.isInitialized());
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 2298 */       int n = 0;
/* 2299 */       int this_t0 = this.optional_0_;
/* 2300 */       if ((this_t0 & 0x7F) != 0) {
/* 2301 */         if ((this_t0 & 0x1) != 0)
/*      */         {
/* 2303 */           n += 1 + Protocol.varLongSize(this.int64value_);
/*      */         }
/* 2305 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 2307 */           n += 2;
/*      */         }
/* 2309 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 2311 */           n += 1 + Protocol.stringSize(this.stringvalue_.length);
/*      */         }
/* 2313 */         if ((this_t0 & 0x8) != 0)
/*      */         {
/* 2315 */           n += 9;
/*      */         }
/* 2317 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 2319 */           n += 1 + this.pointvalue_.encodingSize();
/*      */         }
/* 2321 */         if ((this_t0 & 0x20) != 0)
/*      */         {
/* 2323 */           n += 1 + this.uservalue_.encodingSize();
/*      */         }
/* 2325 */         if ((this_t0 & 0x40) != 0)
/*      */         {
/* 2327 */           n += 1 + this.referencevalue_.encodingSize();
/*      */         }
/*      */       }
/*      */ 
/* 2331 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2339 */       int n = 22;
/* 2340 */       int this_t0 = this.optional_0_;
/* 2341 */       if ((this_t0 & 0x74) != 0) {
/* 2342 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/* 2344 */           n += 6 + this.stringvalue_.length;
/*      */         }
/* 2346 */         if ((this_t0 & 0x10) != 0)
/*      */         {
/* 2348 */           n += 1 + this.pointvalue_.maxEncodingSize();
/*      */         }
/* 2350 */         if ((this_t0 & 0x20) != 0)
/*      */         {
/* 2352 */           n += 1 + this.uservalue_.maxEncodingSize();
/*      */         }
/* 2354 */         if ((this_t0 & 0x40) != 0)
/*      */         {
/* 2356 */           n += 1 + this.referencevalue_.maxEncodingSize();
/*      */         }
/*      */       }
/*      */ 
/* 2360 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2365 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2369 */       this.optional_0_ = 0;
/* 2370 */       this.int64value_ = 0L;
/* 2371 */       this.booleanvalue_ = false;
/* 2372 */       this.stringvalue_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 2373 */       this.doublevalue_ = 0.0D;
/* 2374 */       if (this.pointvalue_ != null) this.pointvalue_.clear();
/* 2375 */       if (this.uservalue_ != null) this.uservalue_.clear();
/* 2376 */       if (this.referencevalue_ != null) this.referencevalue_.clear();
/* 2377 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public PropertyValue newInstance() {
/* 2381 */       return new PropertyValue();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2385 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2461 */       int this_t0 = this.optional_0_;
/* 2462 */       if ((this_t0 & 0x1) != 0) {
/* 2463 */         sink.putByte(8);
/* 2464 */         sink.putVarLong(this.int64value_);
/*      */       }
/*      */ 
/* 2467 */       if ((this_t0 & 0x2) != 0) {
/* 2468 */         sink.putByte(16);
/* 2469 */         sink.putBoolean(this.booleanvalue_);
/*      */       }
/*      */ 
/* 2472 */       if ((this_t0 & 0x4) != 0) {
/* 2473 */         sink.putByte(26);
/* 2474 */         sink.putPrefixedData(this.stringvalue_);
/*      */       }
/*      */ 
/* 2477 */       if ((this_t0 & 0x8) != 0) {
/* 2478 */         sink.putByte(33);
/* 2479 */         sink.putDouble(this.doublevalue_);
/*      */       }
/*      */ 
/* 2482 */       if ((this_t0 & 0x10) != 0) {
/* 2483 */         sink.putByte(43);
/* 2484 */         this.pointvalue_.outputTo(sink);
/*      */       }
/*      */ 
/* 2487 */       if ((this_t0 & 0x20) != 0) {
/* 2488 */         sink.putByte(67);
/* 2489 */         this.uservalue_.outputTo(sink);
/*      */       }
/*      */ 
/* 2492 */       if ((this_t0 & 0x40) != 0) {
/* 2493 */         sink.putByte(99);
/* 2494 */         this.referencevalue_.outputTo(sink);
/*      */       }
/*      */ 
/* 2497 */       if (this.uninterpreted != null)
/* 2498 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2503 */       boolean result = true;
/* 2504 */       int this_t0 = this.optional_0_;
/*      */ 
/* 2506 */       while (source.hasRemaining()) {
/* 2507 */         int tt = source.getVarInt();
/* 2508 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2512 */           result = false;
/* 2513 */           break;
/*      */         case 8:
/* 2516 */           this.int64value_ = source.getVarLong();
/* 2517 */           this_t0 |= 1;
/* 2518 */           break;
/*      */         case 16:
/* 2521 */           this.booleanvalue_ = source.getBoolean();
/* 2522 */           this_t0 |= 2;
/* 2523 */           break;
/*      */         case 26:
/* 2526 */           this.stringvalue_ = source.getPrefixedData();
/* 2527 */           this_t0 |= 4;
/* 2528 */           break;
/*      */         case 33:
/* 2531 */           this.doublevalue_ = source.getDouble();
/* 2532 */           this_t0 |= 8;
/* 2533 */           break;
/*      */         case 43:
/* 2536 */           PointValue v5 = this.pointvalue_;
/* 2537 */           if (v5 == null) this.pointvalue_ = (v5 = new PointValue());
/* 2538 */           if (!v5.merge(source)) { result = false; break label324; }
/* 2539 */           this_t0 |= 16;
/* 2540 */           break;
/*      */         case 67:
/* 2543 */           UserValue v8 = this.uservalue_;
/* 2544 */           if (v8 == null) this.uservalue_ = (v8 = new UserValue());
/* 2545 */           if (!v8.merge(source)) { result = false; break label324; }
/* 2546 */           this_t0 |= 32;
/* 2547 */           break;
/*      */         case 99:
/* 2550 */           ReferenceValue v12 = this.referencevalue_;
/* 2551 */           if (v12 == null) this.referencevalue_ = (v12 = new ReferenceValue());
/* 2552 */           if (!v12.merge(source)) { result = false; break label324; }
/* 2553 */           this_t0 |= 64;
/* 2554 */           break;
/*      */         default:
/* 2556 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2561 */       label324: this.optional_0_ = this_t0;
/* 2562 */       return result;
/*      */     }
/*      */ 
/*      */     public PropertyValue getDefaultInstanceForType()
/*      */     {
/* 2567 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final PropertyValue getDefaultInstance() {
/* 2571 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public PropertyValue freeze()
/*      */     {
/* 2682 */       this.stringvalue_ = ProtocolSupport.freezeString(this.stringvalue_);
/* 2683 */       if (this.pointvalue_ != null) this.pointvalue_.freeze();
/* 2684 */       if (this.uservalue_ != null) this.uservalue_.freeze();
/* 2685 */       if (this.referencevalue_ != null) this.referencevalue_.freeze();
/* 2686 */       return this;
/*      */     }
/*      */ 
/*      */     public PropertyValue unfreeze() {
/* 2690 */       if (this.pointvalue_ != null) this.pointvalue_.unfreeze();
/* 2691 */       if (this.uservalue_ != null) this.uservalue_.unfreeze();
/* 2692 */       if (this.referencevalue_ != null) this.referencevalue_.unfreeze();
/* 2693 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 2697 */       return ((this.pointvalue_ != null) && (this.pointvalue_.isFrozen())) || ((this.uservalue_ != null) && (this.uservalue_.isFrozen())) || ((this.referencevalue_ != null) && (this.referencevalue_.isFrozen()));
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 2702 */       if (this.uninterpreted == null) {
/* 2703 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2705 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2575 */       IMMUTABLE_DEFAULT_INSTANCE = new PropertyValue()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearInt64Value()
/*      */         {
/* 2583 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setInt64Value(long x) {
/* 2586 */           ProtocolSupport.unsupportedOperation();
/* 2587 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearBooleanValue()
/*      */         {
/* 2592 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setBooleanValue(boolean x) {
/* 2595 */           ProtocolSupport.unsupportedOperation();
/* 2596 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearStringValue()
/*      */         {
/* 2601 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setStringValueAsBytes(byte[] x) {
/* 2604 */           ProtocolSupport.unsupportedOperation();
/* 2605 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setStringValue(String v) {
/* 2608 */           ProtocolSupport.unsupportedOperation();
/* 2609 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setStringValue(String v, Charset cs) {
/* 2612 */           ProtocolSupport.unsupportedOperation();
/* 2613 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearDoubleValue()
/*      */         {
/* 2618 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setDoubleValue(double x) {
/* 2621 */           ProtocolSupport.unsupportedOperation();
/* 2622 */           return this;
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearPointValue()
/*      */         {
/* 2627 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setPointValue(OnestoreEntity.PropertyValue.PointValue x) {
/* 2630 */           ProtocolSupport.unsupportedOperation();
/* 2631 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue.PointValue getMutablePointValue() {
/* 2634 */           return (OnestoreEntity.PropertyValue.PointValue)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearUserValue()
/*      */         {
/* 2639 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setUserValue(OnestoreEntity.PropertyValue.UserValue x) {
/* 2642 */           ProtocolSupport.unsupportedOperation();
/* 2643 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue.UserValue getMutableUserValue() {
/* 2646 */           return (OnestoreEntity.PropertyValue.UserValue)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue clearReferenceValue()
/*      */         {
/* 2651 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue setReferenceValue(OnestoreEntity.PropertyValue.ReferenceValue x) {
/* 2654 */           ProtocolSupport.unsupportedOperation();
/* 2655 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue.ReferenceValue getMutableReferenceValue() {
/* 2658 */           return (OnestoreEntity.PropertyValue.ReferenceValue)ProtocolSupport.unsupportedOperation();
/*      */         }
/*      */ 
/*      */         public OnestoreEntity.PropertyValue mergeFrom(OnestoreEntity.PropertyValue that) {
/* 2662 */           ProtocolSupport.unsupportedOperation();
/* 2663 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2666 */           ProtocolSupport.unsupportedOperation();
/* 2667 */           return false;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue freeze() {
/* 2670 */           return this;
/*      */         }
/*      */         public OnestoreEntity.PropertyValue unfreeze() {
/* 2673 */           ProtocolSupport.unsupportedOperation();
/* 2674 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2677 */           return true;
/*      */         }
/*      */       };
/* 2731 */       text = new String[23];
/*      */ 
/* 2733 */       text[0] = "ErrorCode";
/* 2734 */       text[1] = "int64Value";
/* 2735 */       text[2] = "booleanValue";
/* 2736 */       text[3] = "stringValue";
/* 2737 */       text[4] = "doubleValue";
/* 2738 */       text[5] = "PointValue";
/* 2739 */       text[6] = "x";
/* 2740 */       text[7] = "y";
/* 2741 */       text[8] = "UserValue";
/* 2742 */       text[9] = "email";
/* 2743 */       text[10] = "auth_domain";
/* 2744 */       text[11] = "nickname";
/* 2745 */       text[12] = "ReferenceValue";
/* 2746 */       text[13] = "app";
/* 2747 */       text[14] = "PathElement";
/* 2748 */       text[15] = "type";
/* 2749 */       text[16] = "id";
/* 2750 */       text[17] = "name";
/* 2751 */       text[18] = "gaiaid";
/* 2752 */       text[19] = "obfuscated_gaiaid";
/* 2753 */       text[20] = "name_space";
/* 2754 */       text[21] = "federated_identity";
/* 2755 */       text[22] = "federated_provider";
/*      */ 
/* 2758 */       types = new int[23];
/*      */ 
/* 2760 */       Arrays.fill(types, 6);
/* 2761 */       types[0] = 0;
/* 2762 */       types[1] = 0;
/* 2763 */       types[2] = 0;
/* 2764 */       types[3] = 2;
/* 2765 */       types[4] = 1;
/* 2766 */       types[5] = 3;
/* 2767 */       types[6] = 1;
/* 2768 */       types[7] = 1;
/* 2769 */       types[8] = 3;
/* 2770 */       types[9] = 2;
/* 2771 */       types[10] = 2;
/* 2772 */       types[11] = 2;
/* 2773 */       types[12] = 3;
/* 2774 */       types[13] = 2;
/* 2775 */       types[14] = 3;
/* 2776 */       types[15] = 2;
/* 2777 */       types[16] = 0;
/* 2778 */       types[17] = 2;
/* 2779 */       types[18] = 0;
/* 2780 */       types[19] = 2;
/* 2781 */       types[20] = 2;
/* 2782 */       types[21] = 2;
/* 2783 */       types[22] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2389 */       private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.PropertyValue.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("int64Value", "int64value", 1, 0, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("booleanValue", "booleanvalue", 2, 1, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("stringValue", "stringvalue", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("doubleValue", "doublevalue", 4, 3, ProtocolType.FieldBaseType.DOUBLE, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("PointValue", "pointvalue", 5, 4, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.OPTIONAL, OnestoreEntity.PropertyValue.PointValue.class), new ProtocolType.FieldType("UserValue", "uservalue", 8, 5, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.OPTIONAL, OnestoreEntity.PropertyValue.UserValue.class), new ProtocolType.FieldType("ReferenceValue", "referencevalue", 12, 6, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.OPTIONAL, OnestoreEntity.PropertyValue.ReferenceValue.class) });
/*      */     }
/*      */ 
/*      */     public static class ReferenceValue extends ProtocolMessage<ReferenceValue>
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/* 1484 */       private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1485 */       private byte[] name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1486 */       private List<OnestoreEntity.PropertyValue.ReferenceValuePathElement> pathelement_ = null;
/*      */       private UninterpretedTags uninterpreted;
/*      */       private int optional_0_;
/*      */       public static final ReferenceValue IMMUTABLE_DEFAULT_INSTANCE;
/*      */ 
/*      */       public final byte[] getAppAsBytes()
/*      */       {
/* 1492 */         return this.app_;
/*      */       }
/*      */       public final boolean hasApp() {
/* 1495 */         return (this.optional_0_ & 0x1) != 0;
/*      */       }
/*      */       public ReferenceValue clearApp() {
/* 1498 */         this.optional_0_ &= -2;
/* 1499 */         this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1500 */         return this;
/*      */       }
/*      */       public ReferenceValue setAppAsBytes(byte[] x) {
/* 1503 */         this.optional_0_ |= 1;
/* 1504 */         this.app_ = x;
/* 1505 */         return this;
/*      */       }
/*      */       public final String getApp() {
/* 1508 */         return ProtocolSupport.toStringUtf8(this.app_);
/*      */       }
/*      */       public ReferenceValue setApp(String v) {
/* 1511 */         if (v == null) throw new NullPointerException();
/* 1512 */         this.optional_0_ |= 1;
/* 1513 */         this.app_ = ProtocolSupport.toBytesUtf8(v);
/* 1514 */         return this;
/*      */       }
/*      */       public final String getApp(Charset cs) {
/* 1517 */         return ProtocolSupport.toString(this.app_, cs);
/*      */       }
/*      */       public ReferenceValue setApp(String v, Charset cs) {
/* 1520 */         if (v == null) throw new NullPointerException();
/* 1521 */         this.optional_0_ |= 1;
/* 1522 */         this.app_ = ProtocolSupport.toBytes(v, cs);
/* 1523 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getNameSpaceAsBytes()
/*      */       {
/* 1528 */         return this.name_space_;
/*      */       }
/*      */       public final boolean hasNameSpace() {
/* 1531 */         return (this.optional_0_ & 0x2) != 0;
/*      */       }
/*      */       public ReferenceValue clearNameSpace() {
/* 1534 */         this.optional_0_ &= -3;
/* 1535 */         this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1536 */         return this;
/*      */       }
/*      */       public ReferenceValue setNameSpaceAsBytes(byte[] x) {
/* 1539 */         this.optional_0_ |= 2;
/* 1540 */         this.name_space_ = x;
/* 1541 */         return this;
/*      */       }
/*      */       public final String getNameSpace() {
/* 1544 */         return ProtocolSupport.toStringUtf8(this.name_space_);
/*      */       }
/*      */       public ReferenceValue setNameSpace(String v) {
/* 1547 */         if (v == null) throw new NullPointerException();
/* 1548 */         this.optional_0_ |= 2;
/* 1549 */         this.name_space_ = ProtocolSupport.toBytesUtf8(v);
/* 1550 */         return this;
/*      */       }
/*      */       public final String getNameSpace(Charset cs) {
/* 1553 */         return ProtocolSupport.toString(this.name_space_, cs);
/*      */       }
/*      */       public ReferenceValue setNameSpace(String v, Charset cs) {
/* 1556 */         if (v == null) throw new NullPointerException();
/* 1557 */         this.optional_0_ |= 2;
/* 1558 */         this.name_space_ = ProtocolSupport.toBytes(v, cs);
/* 1559 */         return this;
/*      */       }
/*      */ 
/*      */       public final int pathElementSize()
/*      */       {
/* 1564 */         return this.pathelement_ != null ? this.pathelement_.size() : 0;
/*      */       }
/*      */       public final OnestoreEntity.PropertyValue.ReferenceValuePathElement getPathElement(int i) {
/* 1567 */         if (!$assertionsDisabled) if (i >= 0) { if (i < (this.pathelement_ != null ? this.pathelement_.size() : 0)); } else throw new AssertionError();
/* 1568 */         return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i);
/*      */       }
/*      */       public ReferenceValue clearPathElement() {
/* 1571 */         if (this.pathelement_ != null) this.pathelement_.clear();
/* 1572 */         return this;
/*      */       }
/*      */       public OnestoreEntity.PropertyValue.ReferenceValuePathElement getMutablePathElement(int i) {
/* 1575 */         assert ((i >= 0) && (this.pathelement_ != null) && (i < this.pathelement_.size()));
/* 1576 */         return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i);
/*      */       }
/*      */       public OnestoreEntity.PropertyValue.ReferenceValuePathElement addPathElement() {
/* 1579 */         OnestoreEntity.PropertyValue.ReferenceValuePathElement v = new OnestoreEntity.PropertyValue.ReferenceValuePathElement();
/* 1580 */         if (this.pathelement_ == null) this.pathelement_ = new ArrayList(4);
/* 1581 */         this.pathelement_.add(v);
/* 1582 */         return v;
/*      */       }
/*      */       public OnestoreEntity.PropertyValue.ReferenceValuePathElement addPathElement(OnestoreEntity.PropertyValue.ReferenceValuePathElement v) {
/* 1585 */         if (this.pathelement_ == null) this.pathelement_ = new ArrayList(4);
/* 1586 */         this.pathelement_.add(v);
/* 1587 */         return v;
/*      */       }
/*      */       public OnestoreEntity.PropertyValue.ReferenceValuePathElement insertPathElement(int i, OnestoreEntity.PropertyValue.ReferenceValuePathElement v) {
/* 1590 */         if (this.pathelement_ == null) this.pathelement_ = new ArrayList(4);
/* 1591 */         this.pathelement_.add(i, v);
/* 1592 */         return v;
/*      */       }
/*      */       public OnestoreEntity.PropertyValue.ReferenceValuePathElement removePathElement(int i) {
/* 1595 */         return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.remove(i);
/*      */       }
/*      */       public final Iterator<OnestoreEntity.PropertyValue.ReferenceValuePathElement> pathElementIterator() {
/* 1598 */         if (this.pathelement_ == null) {
/* 1599 */           return ProtocolSupport.emptyIterator();
/*      */         }
/* 1601 */         return this.pathelement_.iterator();
/*      */       }
/*      */       public final List<OnestoreEntity.PropertyValue.ReferenceValuePathElement> pathElements() {
/* 1604 */         return ProtocolSupport.unmodifiableList(this.pathelement_);
/*      */       }
/*      */       public final List<OnestoreEntity.PropertyValue.ReferenceValuePathElement> mutablePathElements() {
/* 1607 */         if (this.pathelement_ == null) this.pathelement_ = new ArrayList(4);
/* 1608 */         return this.pathelement_;
/*      */       }
/*      */ 
/*      */       public ReferenceValue mergeFrom(ReferenceValue that)
/*      */       {
/* 1615 */         assert (that != this);
/* 1616 */         int this_t0 = this.optional_0_;
/* 1617 */         int that_t0 = that.optional_0_;
/*      */ 
/* 1619 */         if ((that_t0 & 0x1) != 0) {
/* 1620 */           this_t0 |= 1;
/* 1621 */           this.app_ = that.app_;
/*      */         }
/*      */ 
/* 1624 */         if ((that_t0 & 0x2) != 0) {
/* 1625 */           this_t0 |= 2;
/* 1626 */           this.name_space_ = that.name_space_;
/*      */         }
/*      */ 
/* 1629 */         if (that.pathelement_ != null) {
/* 1630 */           for (OnestoreEntity.PropertyValue.ReferenceValuePathElement v : that.pathelement_) {
/* 1631 */             addPathElement().mergeFrom(v);
/*      */           }
/*      */         }
/*      */ 
/* 1635 */         if (that.uninterpreted != null) {
/* 1636 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */         }
/* 1638 */         this.optional_0_ = this_t0;
/* 1639 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean equalsIgnoreUninterpreted(ReferenceValue that) {
/* 1643 */         return equals(that, true);
/*      */       }
/*      */ 
/*      */       public boolean equals(ReferenceValue that) {
/* 1647 */         return equals(that, false);
/*      */       }
/*      */ 
/*      */       public boolean equals(ReferenceValue that, boolean ignoreUninterpreted) {
/* 1651 */         if (that == null) return false;
/* 1652 */         if (that == this) return true;
/* 1653 */         int this_t0 = this.optional_0_;
/* 1654 */         int that_t0 = that.optional_0_;
/* 1655 */         if (this_t0 != that_t0) return false;
/*      */ 
/* 1657 */         if (((this_t0 & 0x1) != 0) && 
/* 1658 */           (!Arrays.equals(this.app_, that.app_))) return false;
/*      */ 
/* 1661 */         if (((this_t0 & 0x2) != 0) && 
/* 1662 */           (!Arrays.equals(this.name_space_, that.name_space_))) return false;
/* 1666 */         int n;
/* 1666 */         if ((n = this.pathelement_ != null ? this.pathelement_.size() : 0) != (that.pathelement_ != null ? that.pathelement_.size() : 0)) return false;
/* 1667 */         for (int i = 0; i < n; i++) {
/* 1668 */           if (!((OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i)).equals((OnestoreEntity.PropertyValue.ReferenceValuePathElement)that.pathelement_.get(i), ignoreUninterpreted)) return false;
/*      */         }
/*      */ 
/* 1671 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object that)
/*      */       {
/* 1676 */         return ((that instanceof ReferenceValue)) && (equals((ReferenceValue)that));
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/* 1680 */         int hash = 542700058;
/*      */ 
/* 1682 */         int this_t0 = this.optional_0_;
/* 1683 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/*      */ 
/* 1685 */         hash *= 31;
/* 1686 */         int i = 0; for (int n = this.pathelement_ != null ? this.pathelement_.size() : 0; i < n; i++) {
/* 1687 */           hash = hash * 31 + ((OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i)).hashCode();
/*      */         }
/*      */ 
/* 1690 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.name_space_) : -113);
/* 1691 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1692 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*      */         }
/* 1694 */         return hash;
/*      */       }
/*      */ 
/*      */       public boolean isInitialized() {
/* 1698 */         int this_t0 = this.optional_0_;
/* 1699 */         if ((this_t0 & 0x1) != 1) {
/* 1700 */           return false;
/*      */         }
/*      */ 
/* 1703 */         if (this.pathelement_ != null) {
/* 1704 */           for (OnestoreEntity.PropertyValue.ReferenceValuePathElement v : this.pathelement_) {
/* 1705 */             if (!v.isInitialized()) {
/* 1706 */               return false;
/*      */             }
/*      */           }
/*      */         }
/* 1710 */         return true;
/*      */       }
/*      */ 
/*      */       public int encodingSize()
/*      */       {
/* 1716 */         int n = 2 + Protocol.stringSize(this.app_.length);
/*      */         int m;
/* 1719 */         n += (m = this.pathelement_ != null ? this.pathelement_.size() : 0);
/* 1720 */         for (int i = 0; i < m; i++) {
/* 1721 */           n += ((OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i)).encodingSize();
/*      */         }
/* 1723 */         int this_t0 = this.optional_0_;
/* 1724 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 1726 */           n += 2 + Protocol.stringSize(this.name_space_.length);
/*      */         }
/*      */ 
/* 1729 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */       }
/*      */ 
/*      */       public int maxEncodingSize()
/*      */       {
/* 1736 */         int n = 7 + this.app_.length;
/*      */         int m;
/* 1739 */         n += (m = this.pathelement_ != null ? this.pathelement_.size() : 0);
/* 1740 */         for (int i = 0; i < m; i++) {
/* 1741 */           n += ((OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i)).maxEncodingSize();
/*      */         }
/* 1743 */         int this_t0 = this.optional_0_;
/* 1744 */         if ((this_t0 & 0x2) != 0)
/*      */         {
/* 1746 */           n += 7 + this.name_space_.length;
/*      */         }
/*      */ 
/* 1749 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */       }
/*      */ 
/*      */       public MessageAppender getMessageAppender()
/*      */       {
/* 1754 */         return getUninterpretedForWrite();
/*      */       }
/*      */ 
/*      */       public void clear() {
/* 1758 */         this.optional_0_ = 0;
/* 1759 */         this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1760 */         this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1761 */         if (this.pathelement_ != null) this.pathelement_.clear();
/* 1762 */         this.uninterpreted = null;
/*      */       }
/*      */ 
/*      */       public ReferenceValue newInstance() {
/* 1766 */         return new ReferenceValue();
/*      */       }
/*      */ 
/*      */       public ProtocolType getProtocolType() {
/* 1770 */         return StaticHolder.protocolType;
/*      */       }
/*      */ 
/*      */       public void outputTo(ProtocolSink sink)
/*      */       {
/* 1787 */         sink.putByte(106);
/* 1788 */         sink.putPrefixedData(this.app_);
/*      */ 
/* 1790 */         int i = 0; for (int m = this.pathelement_ != null ? this.pathelement_.size() : 0; i < m; i++) {
/* 1791 */           OnestoreEntity.PropertyValue.ReferenceValuePathElement v = (OnestoreEntity.PropertyValue.ReferenceValuePathElement)this.pathelement_.get(i);
/* 1792 */           sink.putByte(115);
/* 1793 */           v.outputTo(sink);
/*      */         }
/*      */ 
/* 1796 */         int this_t0 = this.optional_0_;
/* 1797 */         if ((this_t0 & 0x2) != 0) {
/* 1798 */           sink.putByte(-94);
/* 1799 */           sink.putByte(1);
/* 1800 */           sink.putPrefixedData(this.name_space_);
/*      */         }
/*      */ 
/* 1803 */         if (this.uninterpreted != null) {
/* 1804 */           this.uninterpreted.put(sink);
/*      */         }
/*      */ 
/* 1807 */         sink.putByte(100);
/*      */       }
/*      */ 
/*      */       public boolean merge(ProtocolSource source) {
/* 1811 */         boolean result = true;
/* 1812 */         int this_t0 = this.optional_0_;
/*      */         while (true)
/*      */         {
/* 1815 */           int tt = source.getVarInt();
/* 1816 */           switch (tt)
/*      */           {
/*      */           case 100:
/* 1819 */             break;
/*      */           case 0:
/* 1823 */             result = false;
/* 1824 */             break;
/*      */           case 106:
/* 1827 */             this.app_ = source.getPrefixedData();
/* 1828 */             this_t0 |= 1;
/* 1829 */             break;
/*      */           case 115:
/* 1832 */             if (addPathElement().merge(source)) break; result = false; break;
/*      */           case 162:
/* 1836 */             this.name_space_ = source.getPrefixedData();
/* 1837 */             this_t0 |= 2;
/* 1838 */             break;
/*      */           default:
/* 1840 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1845 */         this.optional_0_ = this_t0;
/* 1846 */         return result;
/*      */       }
/*      */ 
/*      */       public ReferenceValue getDefaultInstanceForType()
/*      */       {
/* 1851 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public static final ReferenceValue getDefaultInstance() {
/* 1855 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public ReferenceValue freeze()
/*      */       {
/* 1940 */         this.app_ = ProtocolSupport.freezeString(this.app_);
/* 1941 */         this.name_space_ = ProtocolSupport.freezeString(this.name_space_);
/* 1942 */         this.pathelement_ = ProtocolSupport.freezeMessages(this.pathelement_);
/* 1943 */         return this;
/*      */       }
/*      */ 
/*      */       public ReferenceValue unfreeze() {
/* 1947 */         this.pathelement_ = ProtocolSupport.unfreezeMessages(this.pathelement_);
/* 1948 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean isFrozen() {
/* 1952 */         return ProtocolSupport.isFrozenMessages(this.pathelement_);
/*      */       }
/*      */       public UninterpretedTags getUninterpretedForWrite() {
/* 1955 */         if (this.uninterpreted == null) {
/* 1956 */           this.uninterpreted = new UninterpretedTags();
/*      */         }
/* 1958 */         return this.uninterpreted;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1859 */         IMMUTABLE_DEFAULT_INSTANCE = new ReferenceValue()
/*      */         {
/*      */           private static final long serialVersionUID = 1L;
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue clearApp()
/*      */           {
/* 1867 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue setAppAsBytes(byte[] x) {
/* 1870 */             ProtocolSupport.unsupportedOperation();
/* 1871 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue setApp(String v) {
/* 1874 */             ProtocolSupport.unsupportedOperation();
/* 1875 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue setApp(String v, Charset cs) {
/* 1878 */             ProtocolSupport.unsupportedOperation();
/* 1879 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue clearNameSpace()
/*      */           {
/* 1884 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue setNameSpaceAsBytes(byte[] x) {
/* 1887 */             ProtocolSupport.unsupportedOperation();
/* 1888 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue setNameSpace(String v) {
/* 1891 */             ProtocolSupport.unsupportedOperation();
/* 1892 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue setNameSpace(String v, Charset cs) {
/* 1895 */             ProtocolSupport.unsupportedOperation();
/* 1896 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue clearPathElement()
/*      */           {
/* 1901 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement getMutablePathElement(int i) {
/* 1904 */             return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)ProtocolSupport.unsupportedOperation();
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement addPathElement() {
/* 1907 */             return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)ProtocolSupport.unsupportedOperation();
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement addPathElement(OnestoreEntity.PropertyValue.ReferenceValuePathElement v) {
/* 1910 */             return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)ProtocolSupport.unsupportedOperation();
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement insertPathElement(int i, OnestoreEntity.PropertyValue.ReferenceValuePathElement v) {
/* 1913 */             return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)ProtocolSupport.unsupportedOperation();
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement removePathElement(int i) {
/* 1916 */             return (OnestoreEntity.PropertyValue.ReferenceValuePathElement)ProtocolSupport.unsupportedOperation();
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue mergeFrom(OnestoreEntity.PropertyValue.ReferenceValue that) {
/* 1920 */             ProtocolSupport.unsupportedOperation();
/* 1921 */             return this;
/*      */           }
/*      */           public boolean merge(ProtocolSource source) {
/* 1924 */             ProtocolSupport.unsupportedOperation();
/* 1925 */             return false;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue freeze() {
/* 1928 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValue unfreeze() {
/* 1931 */             ProtocolSupport.unsupportedOperation();
/* 1932 */             return this;
/*      */           }
/*      */           public boolean isFrozen() {
/* 1935 */             return true;
/*      */           }
/*      */         };
/*      */       }
/*      */ 
/*      */       private static class StaticHolder
/*      */       {
/* 1774 */         private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.PropertyValue.ReferenceValue.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 13, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("name_space", "name_space", 20, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("PathElement", "pathelement", 14, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, OnestoreEntity.PropertyValue.ReferenceValuePathElement.class) });
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class UserValue extends ProtocolMessage<UserValue>
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*  726 */       private byte[] email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  727 */       private byte[] auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  728 */       private byte[] nickname_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  729 */       private long gaiaid_ = 0L;
/*  730 */       private byte[] obfuscated_gaiaid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  731 */       private byte[] federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  732 */       private byte[] federated_provider_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */       private UninterpretedTags uninterpreted;
/*      */       private int optional_0_;
/*      */       public static final UserValue IMMUTABLE_DEFAULT_INSTANCE;
/*      */ 
/*      */       public final byte[] getEmailAsBytes()
/*      */       {
/*  738 */         return this.email_;
/*      */       }
/*      */       public final boolean hasEmail() {
/*  741 */         return (this.optional_0_ & 0x1) != 0;
/*      */       }
/*      */       public UserValue clearEmail() {
/*  744 */         this.optional_0_ &= -2;
/*  745 */         this.email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  746 */         return this;
/*      */       }
/*      */       public UserValue setEmailAsBytes(byte[] x) {
/*  749 */         this.optional_0_ |= 1;
/*  750 */         this.email_ = x;
/*  751 */         return this;
/*      */       }
/*      */       public final String getEmail() {
/*  754 */         return ProtocolSupport.toStringUtf8(this.email_);
/*      */       }
/*      */       public UserValue setEmail(String v) {
/*  757 */         if (v == null) throw new NullPointerException();
/*  758 */         this.optional_0_ |= 1;
/*  759 */         this.email_ = ProtocolSupport.toBytesUtf8(v);
/*  760 */         return this;
/*      */       }
/*      */       public final String getEmail(Charset cs) {
/*  763 */         return ProtocolSupport.toString(this.email_, cs);
/*      */       }
/*      */       public UserValue setEmail(String v, Charset cs) {
/*  766 */         if (v == null) throw new NullPointerException();
/*  767 */         this.optional_0_ |= 1;
/*  768 */         this.email_ = ProtocolSupport.toBytes(v, cs);
/*  769 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getAuthDomainAsBytes()
/*      */       {
/*  774 */         return this.auth_domain_;
/*      */       }
/*      */       public final boolean hasAuthDomain() {
/*  777 */         return (this.optional_0_ & 0x2) != 0;
/*      */       }
/*      */       public UserValue clearAuthDomain() {
/*  780 */         this.optional_0_ &= -3;
/*  781 */         this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  782 */         return this;
/*      */       }
/*      */       public UserValue setAuthDomainAsBytes(byte[] x) {
/*  785 */         this.optional_0_ |= 2;
/*  786 */         this.auth_domain_ = x;
/*  787 */         return this;
/*      */       }
/*      */       public final String getAuthDomain() {
/*  790 */         return ProtocolSupport.toStringUtf8(this.auth_domain_);
/*      */       }
/*      */       public UserValue setAuthDomain(String v) {
/*  793 */         if (v == null) throw new NullPointerException();
/*  794 */         this.optional_0_ |= 2;
/*  795 */         this.auth_domain_ = ProtocolSupport.toBytesUtf8(v);
/*  796 */         return this;
/*      */       }
/*      */       public final String getAuthDomain(Charset cs) {
/*  799 */         return ProtocolSupport.toString(this.auth_domain_, cs);
/*      */       }
/*      */       public UserValue setAuthDomain(String v, Charset cs) {
/*  802 */         if (v == null) throw new NullPointerException();
/*  803 */         this.optional_0_ |= 2;
/*  804 */         this.auth_domain_ = ProtocolSupport.toBytes(v, cs);
/*  805 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getNicknameAsBytes()
/*      */       {
/*  810 */         return this.nickname_;
/*      */       }
/*      */       public final boolean hasNickname() {
/*  813 */         return (this.optional_0_ & 0x4) != 0;
/*      */       }
/*      */       public UserValue clearNickname() {
/*  816 */         this.optional_0_ &= -5;
/*  817 */         this.nickname_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  818 */         return this;
/*      */       }
/*      */       public UserValue setNicknameAsBytes(byte[] x) {
/*  821 */         this.optional_0_ |= 4;
/*  822 */         this.nickname_ = x;
/*  823 */         return this;
/*      */       }
/*      */       public final String getNickname() {
/*  826 */         return ProtocolSupport.toStringUtf8(this.nickname_);
/*      */       }
/*      */       public UserValue setNickname(String v) {
/*  829 */         if (v == null) throw new NullPointerException();
/*  830 */         this.optional_0_ |= 4;
/*  831 */         this.nickname_ = ProtocolSupport.toBytesUtf8(v);
/*  832 */         return this;
/*      */       }
/*      */       public final String getNickname(Charset cs) {
/*  835 */         return ProtocolSupport.toString(this.nickname_, cs);
/*      */       }
/*      */       public UserValue setNickname(String v, Charset cs) {
/*  838 */         if (v == null) throw new NullPointerException();
/*  839 */         this.optional_0_ |= 4;
/*  840 */         this.nickname_ = ProtocolSupport.toBytes(v, cs);
/*  841 */         return this;
/*      */       }
/*      */ 
/*      */       public final long getGaiaid()
/*      */       {
/*  846 */         return this.gaiaid_;
/*      */       }
/*      */       public final boolean hasGaiaid() {
/*  849 */         return (this.optional_0_ & 0x8) != 0;
/*      */       }
/*      */       public UserValue clearGaiaid() {
/*  852 */         this.optional_0_ &= -9;
/*  853 */         this.gaiaid_ = 0L;
/*  854 */         return this;
/*      */       }
/*      */       public UserValue setGaiaid(long x) {
/*  857 */         this.optional_0_ |= 8;
/*  858 */         this.gaiaid_ = x;
/*  859 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getObfuscatedGaiaidAsBytes()
/*      */       {
/*  864 */         return this.obfuscated_gaiaid_;
/*      */       }
/*      */       public final boolean hasObfuscatedGaiaid() {
/*  867 */         return (this.optional_0_ & 0x10) != 0;
/*      */       }
/*      */       public UserValue clearObfuscatedGaiaid() {
/*  870 */         this.optional_0_ &= -17;
/*  871 */         this.obfuscated_gaiaid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  872 */         return this;
/*      */       }
/*      */       public UserValue setObfuscatedGaiaidAsBytes(byte[] x) {
/*  875 */         this.optional_0_ |= 16;
/*  876 */         this.obfuscated_gaiaid_ = x;
/*  877 */         return this;
/*      */       }
/*      */       public final String getObfuscatedGaiaid() {
/*  880 */         return ProtocolSupport.toStringUtf8(this.obfuscated_gaiaid_);
/*      */       }
/*      */       public UserValue setObfuscatedGaiaid(String v) {
/*  883 */         if (v == null) throw new NullPointerException();
/*  884 */         this.optional_0_ |= 16;
/*  885 */         this.obfuscated_gaiaid_ = ProtocolSupport.toBytesUtf8(v);
/*  886 */         return this;
/*      */       }
/*      */       public final String getObfuscatedGaiaid(Charset cs) {
/*  889 */         return ProtocolSupport.toString(this.obfuscated_gaiaid_, cs);
/*      */       }
/*      */       public UserValue setObfuscatedGaiaid(String v, Charset cs) {
/*  892 */         if (v == null) throw new NullPointerException();
/*  893 */         this.optional_0_ |= 16;
/*  894 */         this.obfuscated_gaiaid_ = ProtocolSupport.toBytes(v, cs);
/*  895 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getFederatedIdentityAsBytes()
/*      */       {
/*  900 */         return this.federated_identity_;
/*      */       }
/*      */       public final boolean hasFederatedIdentity() {
/*  903 */         return (this.optional_0_ & 0x20) != 0;
/*      */       }
/*      */       public UserValue clearFederatedIdentity() {
/*  906 */         this.optional_0_ &= -33;
/*  907 */         this.federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  908 */         return this;
/*      */       }
/*      */       public UserValue setFederatedIdentityAsBytes(byte[] x) {
/*  911 */         this.optional_0_ |= 32;
/*  912 */         this.federated_identity_ = x;
/*  913 */         return this;
/*      */       }
/*      */       public final String getFederatedIdentity() {
/*  916 */         return ProtocolSupport.toStringUtf8(this.federated_identity_);
/*      */       }
/*      */       public UserValue setFederatedIdentity(String v) {
/*  919 */         if (v == null) throw new NullPointerException();
/*  920 */         this.optional_0_ |= 32;
/*  921 */         this.federated_identity_ = ProtocolSupport.toBytesUtf8(v);
/*  922 */         return this;
/*      */       }
/*      */       public final String getFederatedIdentity(Charset cs) {
/*  925 */         return ProtocolSupport.toString(this.federated_identity_, cs);
/*      */       }
/*      */       public UserValue setFederatedIdentity(String v, Charset cs) {
/*  928 */         if (v == null) throw new NullPointerException();
/*  929 */         this.optional_0_ |= 32;
/*  930 */         this.federated_identity_ = ProtocolSupport.toBytes(v, cs);
/*  931 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getFederatedProviderAsBytes()
/*      */       {
/*  936 */         return this.federated_provider_;
/*      */       }
/*      */       public final boolean hasFederatedProvider() {
/*  939 */         return (this.optional_0_ & 0x40) != 0;
/*      */       }
/*      */       public UserValue clearFederatedProvider() {
/*  942 */         this.optional_0_ &= -65;
/*  943 */         this.federated_provider_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  944 */         return this;
/*      */       }
/*      */       public UserValue setFederatedProviderAsBytes(byte[] x) {
/*  947 */         this.optional_0_ |= 64;
/*  948 */         this.federated_provider_ = x;
/*  949 */         return this;
/*      */       }
/*      */       public final String getFederatedProvider() {
/*  952 */         return ProtocolSupport.toStringUtf8(this.federated_provider_);
/*      */       }
/*      */       public UserValue setFederatedProvider(String v) {
/*  955 */         if (v == null) throw new NullPointerException();
/*  956 */         this.optional_0_ |= 64;
/*  957 */         this.federated_provider_ = ProtocolSupport.toBytesUtf8(v);
/*  958 */         return this;
/*      */       }
/*      */       public final String getFederatedProvider(Charset cs) {
/*  961 */         return ProtocolSupport.toString(this.federated_provider_, cs);
/*      */       }
/*      */       public UserValue setFederatedProvider(String v, Charset cs) {
/*  964 */         if (v == null) throw new NullPointerException();
/*  965 */         this.optional_0_ |= 64;
/*  966 */         this.federated_provider_ = ProtocolSupport.toBytes(v, cs);
/*  967 */         return this;
/*      */       }
/*      */ 
/*      */       public UserValue mergeFrom(UserValue that)
/*      */       {
/*  974 */         assert (that != this);
/*  975 */         int this_t0 = this.optional_0_;
/*  976 */         int that_t0 = that.optional_0_;
/*      */ 
/*  978 */         if ((that_t0 & 0x1) != 0) {
/*  979 */           this_t0 |= 1;
/*  980 */           this.email_ = that.email_;
/*      */         }
/*      */ 
/*  983 */         if ((that_t0 & 0x2) != 0) {
/*  984 */           this_t0 |= 2;
/*  985 */           this.auth_domain_ = that.auth_domain_;
/*      */         }
/*      */ 
/*  988 */         if ((that_t0 & 0x4) != 0) {
/*  989 */           this_t0 |= 4;
/*  990 */           this.nickname_ = that.nickname_;
/*      */         }
/*      */ 
/*  993 */         if ((that_t0 & 0x8) != 0) {
/*  994 */           this_t0 |= 8;
/*  995 */           this.gaiaid_ = that.gaiaid_;
/*      */         }
/*      */ 
/*  998 */         if ((that_t0 & 0x10) != 0) {
/*  999 */           this_t0 |= 16;
/* 1000 */           this.obfuscated_gaiaid_ = that.obfuscated_gaiaid_;
/*      */         }
/*      */ 
/* 1003 */         if ((that_t0 & 0x20) != 0) {
/* 1004 */           this_t0 |= 32;
/* 1005 */           this.federated_identity_ = that.federated_identity_;
/*      */         }
/*      */ 
/* 1008 */         if ((that_t0 & 0x40) != 0) {
/* 1009 */           this_t0 |= 64;
/* 1010 */           this.federated_provider_ = that.federated_provider_;
/*      */         }
/*      */ 
/* 1013 */         if (that.uninterpreted != null) {
/* 1014 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */         }
/* 1016 */         this.optional_0_ = this_t0;
/* 1017 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean equalsIgnoreUninterpreted(UserValue that) {
/* 1021 */         return equals(that, true);
/*      */       }
/*      */ 
/*      */       public boolean equals(UserValue that) {
/* 1025 */         return equals(that, false);
/*      */       }
/*      */ 
/*      */       public boolean equals(UserValue that, boolean ignoreUninterpreted) {
/* 1029 */         if (that == null) return false;
/* 1030 */         if (that == this) return true;
/* 1031 */         int this_t0 = this.optional_0_;
/* 1032 */         int that_t0 = that.optional_0_;
/* 1033 */         if (this_t0 != that_t0) return false;
/*      */ 
/* 1035 */         if (((this_t0 & 0x1) != 0) && 
/* 1036 */           (!Arrays.equals(this.email_, that.email_))) return false;
/*      */ 
/* 1039 */         if (((this_t0 & 0x2) != 0) && 
/* 1040 */           (!Arrays.equals(this.auth_domain_, that.auth_domain_))) return false;
/*      */ 
/* 1043 */         if (((this_t0 & 0x4) != 0) && 
/* 1044 */           (!Arrays.equals(this.nickname_, that.nickname_))) return false;
/*      */ 
/* 1047 */         if (((this_t0 & 0x8) != 0) && 
/* 1048 */           (this.gaiaid_ != that.gaiaid_)) return false;
/*      */ 
/* 1051 */         if (((this_t0 & 0x10) != 0) && 
/* 1052 */           (!Arrays.equals(this.obfuscated_gaiaid_, that.obfuscated_gaiaid_))) return false;
/*      */ 
/* 1055 */         if (((this_t0 & 0x20) != 0) && 
/* 1056 */           (!Arrays.equals(this.federated_identity_, that.federated_identity_))) return false;
/*      */ 
/* 1059 */         if (((this_t0 & 0x40) != 0) && 
/* 1060 */           (!Arrays.equals(this.federated_provider_, that.federated_provider_))) return false;
/*      */ 
/* 1063 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object that)
/*      */       {
/* 1068 */         return ((that instanceof UserValue)) && (equals((UserValue)that));
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/* 1072 */         int hash = 1449383662;
/*      */ 
/* 1074 */         int this_t0 = this.optional_0_;
/* 1075 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.email_) : -113);
/*      */ 
/* 1077 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.auth_domain_) : -113);
/*      */ 
/* 1079 */         hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.nickname_) : -113);
/*      */ 
/* 1081 */         hash = hash * 31 + ((this_t0 & 0x8) != 0 ? ProtocolSupport.hashCode(this.gaiaid_) : -113);
/*      */ 
/* 1083 */         hash = hash * 31 + ((this_t0 & 0x10) != 0 ? Arrays.hashCode(this.obfuscated_gaiaid_) : -113);
/*      */ 
/* 1085 */         hash = hash * 31 + ((this_t0 & 0x20) != 0 ? Arrays.hashCode(this.federated_identity_) : -113);
/*      */ 
/* 1087 */         hash = hash * 31 + ((this_t0 & 0x40) != 0 ? Arrays.hashCode(this.federated_provider_) : -113);
/* 1088 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1089 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*      */         }
/* 1091 */         return hash;
/*      */       }
/*      */ 
/*      */       public boolean isInitialized() {
/* 1095 */         int this_t0 = this.optional_0_;
/* 1096 */         if ((this_t0 & 0xB) != 11) {
/* 1097 */           if ((this_t0 & 0x1) == 0) {
/* 1098 */             return false;
/*      */           }
/*      */ 
/* 1101 */           return (this_t0 & 0x2) != 0;
/*      */         }
/*      */ 
/* 1105 */         return true;
/*      */       }
/*      */ 
/*      */       public int encodingSize()
/*      */       {
/* 1113 */         int n = 5 + Protocol.stringSize(this.email_.length) + Protocol.stringSize(this.auth_domain_.length) + Protocol.varLongSize(this.gaiaid_);
/*      */ 
/* 1116 */         int this_t0 = this.optional_0_;
/* 1117 */         if ((this_t0 & 0x74) != 0) {
/* 1118 */           if ((this_t0 & 0x4) != 0)
/*      */           {
/* 1120 */             n += 1 + Protocol.stringSize(this.nickname_.length);
/*      */           }
/* 1122 */           if ((this_t0 & 0x10) != 0)
/*      */           {
/* 1124 */             n += 2 + Protocol.stringSize(this.obfuscated_gaiaid_.length);
/*      */           }
/* 1126 */           if ((this_t0 & 0x20) != 0)
/*      */           {
/* 1128 */             n += 2 + Protocol.stringSize(this.federated_identity_.length);
/*      */           }
/* 1130 */           if ((this_t0 & 0x40) != 0)
/*      */           {
/* 1132 */             n += 2 + Protocol.stringSize(this.federated_provider_.length);
/*      */           }
/*      */         }
/*      */ 
/* 1136 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */       }
/*      */ 
/*      */       public int maxEncodingSize()
/*      */       {
/* 1145 */         int n = 25 + this.email_.length + this.auth_domain_.length;
/* 1146 */         int this_t0 = this.optional_0_;
/* 1147 */         if ((this_t0 & 0x74) != 0) {
/* 1148 */           if ((this_t0 & 0x4) != 0)
/*      */           {
/* 1150 */             n += 6 + this.nickname_.length;
/*      */           }
/* 1152 */           if ((this_t0 & 0x10) != 0)
/*      */           {
/* 1154 */             n += 7 + this.obfuscated_gaiaid_.length;
/*      */           }
/* 1156 */           if ((this_t0 & 0x20) != 0)
/*      */           {
/* 1158 */             n += 7 + this.federated_identity_.length;
/*      */           }
/* 1160 */           if ((this_t0 & 0x40) != 0)
/*      */           {
/* 1162 */             n += 7 + this.federated_provider_.length;
/*      */           }
/*      */         }
/*      */ 
/* 1166 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */       }
/*      */ 
/*      */       public MessageAppender getMessageAppender()
/*      */       {
/* 1171 */         return getUninterpretedForWrite();
/*      */       }
/*      */ 
/*      */       public void clear() {
/* 1175 */         this.optional_0_ = 0;
/* 1176 */         this.email_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1177 */         this.auth_domain_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1178 */         this.nickname_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1179 */         this.gaiaid_ = 0L;
/* 1180 */         this.obfuscated_gaiaid_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1181 */         this.federated_identity_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1182 */         this.federated_provider_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1183 */         this.uninterpreted = null;
/*      */       }
/*      */ 
/*      */       public UserValue newInstance() {
/* 1187 */         return new UserValue();
/*      */       }
/*      */ 
/*      */       public ProtocolType getProtocolType() {
/* 1191 */         return StaticHolder.protocolType;
/*      */       }
/*      */ 
/*      */       public void outputTo(ProtocolSink sink)
/*      */       {
/* 1216 */         sink.putByte(74);
/* 1217 */         sink.putPrefixedData(this.email_);
/*      */ 
/* 1219 */         sink.putByte(82);
/* 1220 */         sink.putPrefixedData(this.auth_domain_);
/*      */ 
/* 1222 */         int this_t0 = this.optional_0_;
/* 1223 */         if ((this_t0 & 0x4) != 0) {
/* 1224 */           sink.putByte(90);
/* 1225 */           sink.putPrefixedData(this.nickname_);
/*      */         }
/*      */ 
/* 1228 */         sink.putByte(-112);
/* 1229 */         sink.putByte(1);
/* 1230 */         sink.putVarLong(this.gaiaid_);
/*      */ 
/* 1232 */         if ((this_t0 & 0x10) != 0) {
/* 1233 */           sink.putByte(-102);
/* 1234 */           sink.putByte(1);
/* 1235 */           sink.putPrefixedData(this.obfuscated_gaiaid_);
/*      */         }
/*      */ 
/* 1238 */         if ((this_t0 & 0x20) != 0) {
/* 1239 */           sink.putByte(-86);
/* 1240 */           sink.putByte(1);
/* 1241 */           sink.putPrefixedData(this.federated_identity_);
/*      */         }
/*      */ 
/* 1244 */         if ((this_t0 & 0x40) != 0) {
/* 1245 */           sink.putByte(-78);
/* 1246 */           sink.putByte(1);
/* 1247 */           sink.putPrefixedData(this.federated_provider_);
/*      */         }
/*      */ 
/* 1250 */         if (this.uninterpreted != null) {
/* 1251 */           this.uninterpreted.put(sink);
/*      */         }
/*      */ 
/* 1254 */         sink.putByte(68);
/*      */       }
/*      */ 
/*      */       public boolean merge(ProtocolSource source) {
/* 1258 */         boolean result = true;
/* 1259 */         int this_t0 = this.optional_0_;
/*      */         while (true)
/*      */         {
/* 1262 */           int tt = source.getVarInt();
/* 1263 */           switch (tt)
/*      */           {
/*      */           case 68:
/* 1266 */             break;
/*      */           case 0:
/* 1270 */             result = false;
/* 1271 */             break;
/*      */           case 74:
/* 1274 */             this.email_ = source.getPrefixedData();
/* 1275 */             this_t0 |= 1;
/* 1276 */             break;
/*      */           case 82:
/* 1279 */             this.auth_domain_ = source.getPrefixedData();
/* 1280 */             this_t0 |= 2;
/* 1281 */             break;
/*      */           case 90:
/* 1284 */             this.nickname_ = source.getPrefixedData();
/* 1285 */             this_t0 |= 4;
/* 1286 */             break;
/*      */           case 144:
/* 1289 */             this.gaiaid_ = source.getVarLong();
/* 1290 */             this_t0 |= 8;
/* 1291 */             break;
/*      */           case 154:
/* 1294 */             this.obfuscated_gaiaid_ = source.getPrefixedData();
/* 1295 */             this_t0 |= 16;
/* 1296 */             break;
/*      */           case 170:
/* 1299 */             this.federated_identity_ = source.getPrefixedData();
/* 1300 */             this_t0 |= 32;
/* 1301 */             break;
/*      */           case 178:
/* 1304 */             this.federated_provider_ = source.getPrefixedData();
/* 1305 */             this_t0 |= 64;
/* 1306 */             break;
/*      */           default:
/* 1308 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1313 */         this.optional_0_ = this_t0;
/* 1314 */         return result;
/*      */       }
/*      */ 
/*      */       public UserValue getDefaultInstanceForType()
/*      */       {
/* 1319 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public static final UserValue getDefaultInstance() {
/* 1323 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public UserValue freeze()
/*      */       {
/* 1465 */         this.email_ = ProtocolSupport.freezeString(this.email_);
/* 1466 */         this.auth_domain_ = ProtocolSupport.freezeString(this.auth_domain_);
/* 1467 */         this.nickname_ = ProtocolSupport.freezeString(this.nickname_);
/* 1468 */         this.obfuscated_gaiaid_ = ProtocolSupport.freezeString(this.obfuscated_gaiaid_);
/* 1469 */         this.federated_identity_ = ProtocolSupport.freezeString(this.federated_identity_);
/* 1470 */         this.federated_provider_ = ProtocolSupport.freezeString(this.federated_provider_);
/* 1471 */         return this;
/*      */       }
/*      */       public UninterpretedTags getUninterpretedForWrite() {
/* 1474 */         if (this.uninterpreted == null) {
/* 1475 */           this.uninterpreted = new UninterpretedTags();
/*      */         }
/* 1477 */         return this.uninterpreted;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1327 */         IMMUTABLE_DEFAULT_INSTANCE = new UserValue()
/*      */         {
/*      */           private static final long serialVersionUID = 1L;
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearEmail()
/*      */           {
/* 1335 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setEmailAsBytes(byte[] x) {
/* 1338 */             ProtocolSupport.unsupportedOperation();
/* 1339 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setEmail(String v) {
/* 1342 */             ProtocolSupport.unsupportedOperation();
/* 1343 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setEmail(String v, Charset cs) {
/* 1346 */             ProtocolSupport.unsupportedOperation();
/* 1347 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearAuthDomain()
/*      */           {
/* 1352 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setAuthDomainAsBytes(byte[] x) {
/* 1355 */             ProtocolSupport.unsupportedOperation();
/* 1356 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setAuthDomain(String v) {
/* 1359 */             ProtocolSupport.unsupportedOperation();
/* 1360 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setAuthDomain(String v, Charset cs) {
/* 1363 */             ProtocolSupport.unsupportedOperation();
/* 1364 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearNickname()
/*      */           {
/* 1369 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setNicknameAsBytes(byte[] x) {
/* 1372 */             ProtocolSupport.unsupportedOperation();
/* 1373 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setNickname(String v) {
/* 1376 */             ProtocolSupport.unsupportedOperation();
/* 1377 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setNickname(String v, Charset cs) {
/* 1380 */             ProtocolSupport.unsupportedOperation();
/* 1381 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearGaiaid()
/*      */           {
/* 1386 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setGaiaid(long x) {
/* 1389 */             ProtocolSupport.unsupportedOperation();
/* 1390 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearObfuscatedGaiaid()
/*      */           {
/* 1395 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setObfuscatedGaiaidAsBytes(byte[] x) {
/* 1398 */             ProtocolSupport.unsupportedOperation();
/* 1399 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setObfuscatedGaiaid(String v) {
/* 1402 */             ProtocolSupport.unsupportedOperation();
/* 1403 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setObfuscatedGaiaid(String v, Charset cs) {
/* 1406 */             ProtocolSupport.unsupportedOperation();
/* 1407 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearFederatedIdentity()
/*      */           {
/* 1412 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setFederatedIdentityAsBytes(byte[] x) {
/* 1415 */             ProtocolSupport.unsupportedOperation();
/* 1416 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setFederatedIdentity(String v) {
/* 1419 */             ProtocolSupport.unsupportedOperation();
/* 1420 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setFederatedIdentity(String v, Charset cs) {
/* 1423 */             ProtocolSupport.unsupportedOperation();
/* 1424 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue clearFederatedProvider()
/*      */           {
/* 1429 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setFederatedProviderAsBytes(byte[] x) {
/* 1432 */             ProtocolSupport.unsupportedOperation();
/* 1433 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setFederatedProvider(String v) {
/* 1436 */             ProtocolSupport.unsupportedOperation();
/* 1437 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue setFederatedProvider(String v, Charset cs) {
/* 1440 */             ProtocolSupport.unsupportedOperation();
/* 1441 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.UserValue mergeFrom(OnestoreEntity.PropertyValue.UserValue that) {
/* 1445 */             ProtocolSupport.unsupportedOperation();
/* 1446 */             return this;
/*      */           }
/*      */           public boolean merge(ProtocolSource source) {
/* 1449 */             ProtocolSupport.unsupportedOperation();
/* 1450 */             return false;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue freeze() {
/* 1453 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.UserValue unfreeze() {
/* 1456 */             ProtocolSupport.unsupportedOperation();
/* 1457 */             return this;
/*      */           }
/*      */           public boolean isFrozen() {
/* 1460 */             return true;
/*      */           }
/*      */         };
/*      */       }
/*      */ 
/*      */       private static class StaticHolder
/*      */       {
/* 1195 */         private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.PropertyValue.UserValue.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("email", "email", 9, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("auth_domain", "auth_domain", 10, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("nickname", "nickname", 11, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("gaiaid", "gaiaid", 18, 3, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("obfuscated_gaiaid", "obfuscated_gaiaid", 19, 4, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("federated_identity", "federated_identity", 21, 5, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("federated_provider", "federated_provider", 22, 6, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class PointValue extends ProtocolMessage<PointValue>
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*  442 */       private double x_ = 0.0D;
/*  443 */       private double y_ = 0.0D;
/*      */       private UninterpretedTags uninterpreted;
/*      */       private int optional_0_;
/*      */       public static final PointValue IMMUTABLE_DEFAULT_INSTANCE;
/*      */ 
/*      */       public final double getX()
/*      */       {
/*  449 */         return this.x_;
/*      */       }
/*      */       public final boolean hasX() {
/*  452 */         return (this.optional_0_ & 0x1) != 0;
/*      */       }
/*      */       public PointValue clearX() {
/*  455 */         this.optional_0_ &= -2;
/*  456 */         this.x_ = 0.0D;
/*  457 */         return this;
/*      */       }
/*      */       public PointValue setX(double x) {
/*  460 */         this.optional_0_ |= 1;
/*  461 */         this.x_ = x;
/*  462 */         return this;
/*      */       }
/*      */ 
/*      */       public final double getY()
/*      */       {
/*  467 */         return this.y_;
/*      */       }
/*      */       public final boolean hasY() {
/*  470 */         return (this.optional_0_ & 0x2) != 0;
/*      */       }
/*      */       public PointValue clearY() {
/*  473 */         this.optional_0_ &= -3;
/*  474 */         this.y_ = 0.0D;
/*  475 */         return this;
/*      */       }
/*      */       public PointValue setY(double x) {
/*  478 */         this.optional_0_ |= 2;
/*  479 */         this.y_ = x;
/*  480 */         return this;
/*      */       }
/*      */ 
/*      */       public PointValue mergeFrom(PointValue that)
/*      */       {
/*  487 */         assert (that != this);
/*  488 */         int this_t0 = this.optional_0_;
/*  489 */         int that_t0 = that.optional_0_;
/*      */ 
/*  491 */         if ((that_t0 & 0x1) != 0) {
/*  492 */           this_t0 |= 1;
/*  493 */           this.x_ = that.x_;
/*      */         }
/*      */ 
/*  496 */         if ((that_t0 & 0x2) != 0) {
/*  497 */           this_t0 |= 2;
/*  498 */           this.y_ = that.y_;
/*      */         }
/*      */ 
/*  501 */         if (that.uninterpreted != null) {
/*  502 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */         }
/*  504 */         this.optional_0_ = this_t0;
/*  505 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean equalsIgnoreUninterpreted(PointValue that) {
/*  509 */         return equals(that, true);
/*      */       }
/*      */ 
/*      */       public boolean equals(PointValue that) {
/*  513 */         return equals(that, false);
/*      */       }
/*      */ 
/*      */       public boolean equals(PointValue that, boolean ignoreUninterpreted) {
/*  517 */         if (that == null) return false;
/*  518 */         if (that == this) return true;
/*  519 */         int this_t0 = this.optional_0_;
/*  520 */         int that_t0 = that.optional_0_;
/*  521 */         if (this_t0 != that_t0) return false;
/*      */ 
/*  523 */         if (((this_t0 & 0x1) != 0) && 
/*  524 */           (this.x_ != that.x_)) return false;
/*      */ 
/*  527 */         if (((this_t0 & 0x2) != 0) && 
/*  528 */           (this.y_ != that.y_)) return false;
/*      */ 
/*  531 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object that)
/*      */       {
/*  536 */         return ((that instanceof PointValue)) && (equals((PointValue)that));
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/*  540 */         int hash = -1122997688;
/*      */ 
/*  542 */         int this_t0 = this.optional_0_;
/*  543 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.x_) : -113);
/*      */ 
/*  545 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.y_) : -113);
/*  546 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  547 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*      */         }
/*  549 */         return hash;
/*      */       }
/*      */ 
/*      */       public boolean isInitialized() {
/*  553 */         int this_t0 = this.optional_0_;
/*  554 */         if ((this_t0 & 0x3) != 3)
/*      */         {
/*  556 */           return (this_t0 & 0x1) != 0;
/*      */         }
/*      */ 
/*  560 */         return true;
/*      */       }
/*      */ 
/*      */       public int encodingSize()
/*      */       {
/*  567 */         int n = 19;
/*      */ 
/*  569 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */       }
/*      */ 
/*      */       public int maxEncodingSize()
/*      */       {
/*  577 */         int n = 19;
/*      */ 
/*  579 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */       }
/*      */ 
/*      */       public MessageAppender getMessageAppender()
/*      */       {
/*  584 */         return getUninterpretedForWrite();
/*      */       }
/*      */ 
/*      */       public void clear() {
/*  588 */         this.optional_0_ = 0;
/*  589 */         this.x_ = 0.0D;
/*  590 */         this.y_ = 0.0D;
/*  591 */         this.uninterpreted = null;
/*      */       }
/*      */ 
/*      */       public PointValue newInstance() {
/*  595 */         return new PointValue();
/*      */       }
/*      */ 
/*      */       public ProtocolType getProtocolType() {
/*  599 */         return StaticHolder.protocolType;
/*      */       }
/*      */ 
/*      */       public void outputTo(ProtocolSink sink)
/*      */       {
/*  614 */         sink.putByte(49);
/*  615 */         sink.putDouble(this.x_);
/*      */ 
/*  617 */         sink.putByte(57);
/*  618 */         sink.putDouble(this.y_);
/*      */ 
/*  620 */         if (this.uninterpreted != null) {
/*  621 */           this.uninterpreted.put(sink);
/*      */         }
/*      */ 
/*  624 */         sink.putByte(44);
/*      */       }
/*      */ 
/*      */       public boolean merge(ProtocolSource source) {
/*  628 */         boolean result = true;
/*  629 */         int this_t0 = this.optional_0_;
/*      */         while (true)
/*      */         {
/*  632 */           int tt = source.getVarInt();
/*  633 */           switch (tt)
/*      */           {
/*      */           case 44:
/*  636 */             break;
/*      */           case 0:
/*  640 */             result = false;
/*  641 */             break;
/*      */           case 49:
/*  644 */             this.x_ = source.getDouble();
/*  645 */             this_t0 |= 1;
/*  646 */             break;
/*      */           case 57:
/*  649 */             this.y_ = source.getDouble();
/*  650 */             this_t0 |= 2;
/*  651 */             break;
/*      */           default:
/*  653 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  658 */         this.optional_0_ = this_t0;
/*  659 */         return result;
/*      */       }
/*      */ 
/*      */       public PointValue getDefaultInstanceForType()
/*      */       {
/*  664 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public static final PointValue getDefaultInstance() {
/*  668 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public UninterpretedTags getUninterpretedForWrite()
/*      */       {
/*  716 */         if (this.uninterpreted == null) {
/*  717 */           this.uninterpreted = new UninterpretedTags();
/*      */         }
/*  719 */         return this.uninterpreted;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  672 */         IMMUTABLE_DEFAULT_INSTANCE = new PointValue()
/*      */         {
/*      */           private static final long serialVersionUID = 1L;
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.PointValue clearX()
/*      */           {
/*  680 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.PointValue setX(double x) {
/*  683 */             ProtocolSupport.unsupportedOperation();
/*  684 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.PointValue clearY()
/*      */           {
/*  689 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.PointValue setY(double x) {
/*  692 */             ProtocolSupport.unsupportedOperation();
/*  693 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.PointValue mergeFrom(OnestoreEntity.PropertyValue.PointValue that) {
/*  697 */             ProtocolSupport.unsupportedOperation();
/*  698 */             return this;
/*      */           }
/*      */           public boolean merge(ProtocolSource source) {
/*  701 */             ProtocolSupport.unsupportedOperation();
/*  702 */             return false;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.PointValue freeze() {
/*  705 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.PointValue unfreeze() {
/*  708 */             ProtocolSupport.unsupportedOperation();
/*  709 */             return this;
/*      */           }
/*      */           public boolean isFrozen() {
/*  712 */             return true;
/*      */           }
/*      */         };
/*      */       }
/*      */ 
/*      */       private static class StaticHolder
/*      */       {
/*  603 */         private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.PropertyValue.PointValue.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("x", "x", 6, 0, ProtocolType.FieldBaseType.DOUBLE, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("y", "y", 7, 1, ProtocolType.FieldBaseType.DOUBLE, ProtocolType.Presence.REQUIRED) });
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class ReferenceValuePathElement extends ProtocolMessage<ReferenceValuePathElement>
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*   31 */       private byte[] type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*   32 */       private long id_ = 0L;
/*   33 */       private byte[] name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */       private UninterpretedTags uninterpreted;
/*      */       private int optional_0_;
/*      */       public static final ReferenceValuePathElement IMMUTABLE_DEFAULT_INSTANCE;
/*      */ 
/*      */       public final byte[] getTypeAsBytes()
/*      */       {
/*   39 */         return this.type_;
/*      */       }
/*      */       public final boolean hasType() {
/*   42 */         return (this.optional_0_ & 0x1) != 0;
/*      */       }
/*      */       public ReferenceValuePathElement clearType() {
/*   45 */         this.optional_0_ &= -2;
/*   46 */         this.type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*   47 */         return this;
/*      */       }
/*      */       public ReferenceValuePathElement setTypeAsBytes(byte[] x) {
/*   50 */         this.optional_0_ |= 1;
/*   51 */         this.type_ = x;
/*   52 */         return this;
/*      */       }
/*      */       public final String getType() {
/*   55 */         return ProtocolSupport.toStringUtf8(this.type_);
/*      */       }
/*      */       public ReferenceValuePathElement setType(String v) {
/*   58 */         if (v == null) throw new NullPointerException();
/*   59 */         this.optional_0_ |= 1;
/*   60 */         this.type_ = ProtocolSupport.toBytesUtf8(v);
/*   61 */         return this;
/*      */       }
/*      */       public final String getType(Charset cs) {
/*   64 */         return ProtocolSupport.toString(this.type_, cs);
/*      */       }
/*      */       public ReferenceValuePathElement setType(String v, Charset cs) {
/*   67 */         if (v == null) throw new NullPointerException();
/*   68 */         this.optional_0_ |= 1;
/*   69 */         this.type_ = ProtocolSupport.toBytes(v, cs);
/*   70 */         return this;
/*      */       }
/*      */ 
/*      */       public final long getId()
/*      */       {
/*   75 */         return this.id_;
/*      */       }
/*      */       public final boolean hasId() {
/*   78 */         return (this.optional_0_ & 0x2) != 0;
/*      */       }
/*      */       public ReferenceValuePathElement clearId() {
/*   81 */         this.optional_0_ &= -3;
/*   82 */         this.id_ = 0L;
/*   83 */         return this;
/*      */       }
/*      */       public ReferenceValuePathElement setId(long x) {
/*   86 */         this.optional_0_ |= 2;
/*   87 */         this.id_ = x;
/*   88 */         return this;
/*      */       }
/*      */ 
/*      */       public final byte[] getNameAsBytes()
/*      */       {
/*   93 */         return this.name_;
/*      */       }
/*      */       public final boolean hasName() {
/*   96 */         return (this.optional_0_ & 0x4) != 0;
/*      */       }
/*      */       public ReferenceValuePathElement clearName() {
/*   99 */         this.optional_0_ &= -5;
/*  100 */         this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  101 */         return this;
/*      */       }
/*      */       public ReferenceValuePathElement setNameAsBytes(byte[] x) {
/*  104 */         this.optional_0_ |= 4;
/*  105 */         this.name_ = x;
/*  106 */         return this;
/*      */       }
/*      */       public final String getName() {
/*  109 */         return ProtocolSupport.toStringUtf8(this.name_);
/*      */       }
/*      */       public ReferenceValuePathElement setName(String v) {
/*  112 */         if (v == null) throw new NullPointerException();
/*  113 */         this.optional_0_ |= 4;
/*  114 */         this.name_ = ProtocolSupport.toBytesUtf8(v);
/*  115 */         return this;
/*      */       }
/*      */       public final String getName(Charset cs) {
/*  118 */         return ProtocolSupport.toString(this.name_, cs);
/*      */       }
/*      */       public ReferenceValuePathElement setName(String v, Charset cs) {
/*  121 */         if (v == null) throw new NullPointerException();
/*  122 */         this.optional_0_ |= 4;
/*  123 */         this.name_ = ProtocolSupport.toBytes(v, cs);
/*  124 */         return this;
/*      */       }
/*      */ 
/*      */       public ReferenceValuePathElement mergeFrom(ReferenceValuePathElement that)
/*      */       {
/*  131 */         assert (that != this);
/*  132 */         int this_t0 = this.optional_0_;
/*  133 */         int that_t0 = that.optional_0_;
/*      */ 
/*  135 */         if ((that_t0 & 0x1) != 0) {
/*  136 */           this_t0 |= 1;
/*  137 */           this.type_ = that.type_;
/*      */         }
/*      */ 
/*  140 */         if ((that_t0 & 0x2) != 0) {
/*  141 */           this_t0 |= 2;
/*  142 */           this.id_ = that.id_;
/*      */         }
/*      */ 
/*  145 */         if ((that_t0 & 0x4) != 0) {
/*  146 */           this_t0 |= 4;
/*  147 */           this.name_ = that.name_;
/*      */         }
/*      */ 
/*  150 */         if (that.uninterpreted != null) {
/*  151 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */         }
/*  153 */         this.optional_0_ = this_t0;
/*  154 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean equalsIgnoreUninterpreted(ReferenceValuePathElement that) {
/*  158 */         return equals(that, true);
/*      */       }
/*      */ 
/*      */       public boolean equals(ReferenceValuePathElement that) {
/*  162 */         return equals(that, false);
/*      */       }
/*      */ 
/*      */       public boolean equals(ReferenceValuePathElement that, boolean ignoreUninterpreted) {
/*  166 */         if (that == null) return false;
/*  167 */         if (that == this) return true;
/*  168 */         int this_t0 = this.optional_0_;
/*  169 */         int that_t0 = that.optional_0_;
/*  170 */         if (this_t0 != that_t0) return false;
/*      */ 
/*  172 */         if (((this_t0 & 0x1) != 0) && 
/*  173 */           (!Arrays.equals(this.type_, that.type_))) return false;
/*      */ 
/*  176 */         if (((this_t0 & 0x2) != 0) && 
/*  177 */           (this.id_ != that.id_)) return false;
/*      */ 
/*  180 */         if (((this_t0 & 0x4) != 0) && 
/*  181 */           (!Arrays.equals(this.name_, that.name_))) return false;
/*      */ 
/*  184 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */       }
/*      */ 
/*      */       public boolean equals(Object that)
/*      */       {
/*  189 */         return ((that instanceof ReferenceValuePathElement)) && (equals((ReferenceValuePathElement)that));
/*      */       }
/*      */ 
/*      */       public int hashCode() {
/*  193 */         int hash = 1895909375;
/*      */ 
/*  195 */         int this_t0 = this.optional_0_;
/*  196 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.type_) : -113);
/*      */ 
/*  198 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.id_) : -113);
/*      */ 
/*  200 */         hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.name_) : -113);
/*  201 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  202 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*      */         }
/*  204 */         return hash;
/*      */       }
/*      */ 
/*      */       public boolean isInitialized() {
/*  208 */         int this_t0 = this.optional_0_;
/*      */ 
/*  210 */         return (this_t0 & 0x1) == 1;
/*      */       }
/*      */ 
/*      */       public int encodingSize()
/*      */       {
/*  218 */         int n = 2 + Protocol.stringSize(this.type_.length);
/*  219 */         int this_t0 = this.optional_0_;
/*  220 */         if ((this_t0 & 0x6) != 0) {
/*  221 */           if ((this_t0 & 0x2) != 0)
/*      */           {
/*  223 */             n += 2 + Protocol.varLongSize(this.id_);
/*      */           }
/*  225 */           if ((this_t0 & 0x4) != 0)
/*      */           {
/*  227 */             n += 2 + Protocol.stringSize(this.name_.length);
/*      */           }
/*      */         }
/*      */ 
/*  231 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */       }
/*      */ 
/*      */       public int maxEncodingSize()
/*      */       {
/*  239 */         int n = 19 + this.type_.length;
/*  240 */         int this_t0 = this.optional_0_;
/*  241 */         if ((this_t0 & 0x4) != 0)
/*      */         {
/*  243 */           n += 7 + this.name_.length;
/*      */         }
/*      */ 
/*  246 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */       }
/*      */ 
/*      */       public MessageAppender getMessageAppender()
/*      */       {
/*  251 */         return getUninterpretedForWrite();
/*      */       }
/*      */ 
/*      */       public void clear() {
/*  255 */         this.optional_0_ = 0;
/*  256 */         this.type_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  257 */         this.id_ = 0L;
/*  258 */         this.name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  259 */         this.uninterpreted = null;
/*      */       }
/*      */ 
/*      */       public ReferenceValuePathElement newInstance() {
/*  263 */         return new ReferenceValuePathElement();
/*      */       }
/*      */ 
/*      */       public ProtocolType getProtocolType() {
/*  267 */         return StaticHolder.protocolType;
/*      */       }
/*      */ 
/*      */       public void outputTo(ProtocolSink sink)
/*      */       {
/*  284 */         sink.putByte(122);
/*  285 */         sink.putPrefixedData(this.type_);
/*      */ 
/*  287 */         int this_t0 = this.optional_0_;
/*  288 */         if ((this_t0 & 0x2) != 0) {
/*  289 */           sink.putByte(-128);
/*  290 */           sink.putByte(1);
/*  291 */           sink.putVarLong(this.id_);
/*      */         }
/*      */ 
/*  294 */         if ((this_t0 & 0x4) != 0) {
/*  295 */           sink.putByte(-118);
/*  296 */           sink.putByte(1);
/*  297 */           sink.putPrefixedData(this.name_);
/*      */         }
/*      */ 
/*  300 */         if (this.uninterpreted != null) {
/*  301 */           this.uninterpreted.put(sink);
/*      */         }
/*      */ 
/*  304 */         sink.putByte(116);
/*      */       }
/*      */ 
/*      */       public boolean merge(ProtocolSource source) {
/*  308 */         boolean result = true;
/*  309 */         int this_t0 = this.optional_0_;
/*      */         while (true)
/*      */         {
/*  312 */           int tt = source.getVarInt();
/*  313 */           switch (tt)
/*      */           {
/*      */           case 116:
/*  316 */             break;
/*      */           case 0:
/*  320 */             result = false;
/*  321 */             break;
/*      */           case 122:
/*  324 */             this.type_ = source.getPrefixedData();
/*  325 */             this_t0 |= 1;
/*  326 */             break;
/*      */           case 128:
/*  329 */             this.id_ = source.getVarLong();
/*  330 */             this_t0 |= 2;
/*  331 */             break;
/*      */           case 138:
/*  334 */             this.name_ = source.getPrefixedData();
/*  335 */             this_t0 |= 4;
/*  336 */             break;
/*      */           default:
/*  338 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  343 */         this.optional_0_ = this_t0;
/*  344 */         return result;
/*      */       }
/*      */ 
/*      */       public ReferenceValuePathElement getDefaultInstanceForType()
/*      */       {
/*  349 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public static final ReferenceValuePathElement getDefaultInstance() {
/*  353 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*      */       }
/*      */ 
/*      */       public ReferenceValuePathElement freeze()
/*      */       {
/*  427 */         this.type_ = ProtocolSupport.freezeString(this.type_);
/*  428 */         this.name_ = ProtocolSupport.freezeString(this.name_);
/*  429 */         return this;
/*      */       }
/*      */       public UninterpretedTags getUninterpretedForWrite() {
/*  432 */         if (this.uninterpreted == null) {
/*  433 */           this.uninterpreted = new UninterpretedTags();
/*      */         }
/*  435 */         return this.uninterpreted;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  357 */         IMMUTABLE_DEFAULT_INSTANCE = new ReferenceValuePathElement()
/*      */         {
/*      */           private static final long serialVersionUID = 1L;
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement clearType()
/*      */           {
/*  365 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setTypeAsBytes(byte[] x) {
/*  368 */             ProtocolSupport.unsupportedOperation();
/*  369 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setType(String v) {
/*  372 */             ProtocolSupport.unsupportedOperation();
/*  373 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setType(String v, Charset cs) {
/*  376 */             ProtocolSupport.unsupportedOperation();
/*  377 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement clearId()
/*      */           {
/*  382 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setId(long x) {
/*  385 */             ProtocolSupport.unsupportedOperation();
/*  386 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement clearName()
/*      */           {
/*  391 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setNameAsBytes(byte[] x) {
/*  394 */             ProtocolSupport.unsupportedOperation();
/*  395 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setName(String v) {
/*  398 */             ProtocolSupport.unsupportedOperation();
/*  399 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement setName(String v, Charset cs) {
/*  402 */             ProtocolSupport.unsupportedOperation();
/*  403 */             return this;
/*      */           }
/*      */ 
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement mergeFrom(OnestoreEntity.PropertyValue.ReferenceValuePathElement that) {
/*  407 */             ProtocolSupport.unsupportedOperation();
/*  408 */             return this;
/*      */           }
/*      */           public boolean merge(ProtocolSource source) {
/*  411 */             ProtocolSupport.unsupportedOperation();
/*  412 */             return false;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement freeze() {
/*  415 */             return this;
/*      */           }
/*      */           public OnestoreEntity.PropertyValue.ReferenceValuePathElement unfreeze() {
/*  418 */             ProtocolSupport.unsupportedOperation();
/*  419 */             return this;
/*      */           }
/*      */           public boolean isFrozen() {
/*  422 */             return true;
/*      */           }
/*      */         };
/*      */       }
/*      */ 
/*      */       private static class StaticHolder
/*      */       {
/*  271 */         private static final ProtocolType protocolType = new ProtocolType(OnestoreEntity.PropertyValue.ReferenceValuePathElement.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("type", "type", 15, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("id", "id", 16, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("name", "name", 17, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.storage.onestore.v3.OnestoreEntity
 * JD-Core Version:    0.6.0
 */