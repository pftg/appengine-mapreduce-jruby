/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Map.Entry;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingMapEntry<K, V> extends ForwardingObject
/*    */   implements Map.Entry<K, V>
/*    */ {
/*    */   protected abstract Map.Entry<K, V> delegate();
/*    */ 
/*    */   public K getKey()
/*    */   {
/* 44 */     return delegate().getKey();
/*    */   }
/*    */ 
/*    */   public V getValue() {
/* 48 */     return delegate().getValue();
/*    */   }
/*    */ 
/*    */   public V setValue(V value) {
/* 52 */     return delegate().setValue(value);
/*    */   }
/*    */ 
/*    */   public boolean equals(@Nullable Object object) {
/* 56 */     return delegate().equals(object);
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 60 */     return delegate().hashCode();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingMapEntry
 * JD-Core Version:    0.6.0
 */