package com.google.appengine.api.images;

import java.io.Serializable;

public abstract class Transform
  implements Serializable
{
  abstract void apply(ImagesServicePb.ImagesTransformRequest paramImagesTransformRequest);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.Transform
 * JD-Core Version:    0.6.0
 */