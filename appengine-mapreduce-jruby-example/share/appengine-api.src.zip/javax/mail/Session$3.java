/*      */ package javax.mail;
/*      */ 
/*      */ import java.security.PrivilegedAction;
/*      */ 
/*      */ class Session$3
/*      */   implements PrivilegedAction
/*      */ {
/*      */   public Object run()
/*      */   {
/* 1192 */     ClassLoader cl = null;
/*      */     try {
/* 1194 */       cl = Thread.currentThread().getContextClassLoader(); } catch (SecurityException ex) {
/*      */     }
/* 1196 */     return cl;
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Session.3
 * JD-Core Version:    0.6.0
 */