/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ abstract class AbstractMultiset<E> extends AbstractCollection<E>
/*     */   implements Multiset<E>
/*     */ {
/*     */   private transient Set<E> elementSet;
/*     */ 
/*     */   public abstract Set<Multiset.Entry<E>> entrySet();
/*     */ 
/*     */   public int size()
/*     */   {
/*  58 */     long sum = 0L;
/*  59 */     for (Multiset.Entry entry : entrySet()) {
/*  60 */       sum += entry.getCount();
/*     */     }
/*  62 */     return Ints.saturatedCast(sum);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  66 */     return entrySet().isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean contains(@Nullable Object element) {
/*  70 */     return elementSet().contains(element);
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator() {
/*  74 */     return new MultisetIterator();
/*     */   }
/*     */ 
/*     */   public int count(Object element)
/*     */   {
/* 121 */     for (Multiset.Entry entry : entrySet()) {
/* 122 */       if (Objects.equal(entry.getElement(), element)) {
/* 123 */         return entry.getCount();
/*     */       }
/*     */     }
/* 126 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean add(@Nullable E element)
/*     */   {
/* 132 */     add(element, 1);
/* 133 */     return true;
/*     */   }
/*     */ 
/*     */   public int add(E element, int occurrences) {
/* 137 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean remove(Object element) {
/* 141 */     return remove(element, 1) > 0;
/*     */   }
/*     */ 
/*     */   public int remove(Object element, int occurrences) {
/* 145 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int setCount(E element, int count) {
/* 149 */     return Multisets.setCountImpl(this, element, count);
/*     */   }
/*     */ 
/*     */   public boolean setCount(E element, int oldCount, int newCount) {
/* 153 */     return Multisets.setCountImpl(this, element, oldCount, newCount);
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection<?> elements)
/*     */   {
/* 159 */     return elementSet().containsAll(elements);
/*     */   }
/*     */ 
/*     */   public boolean addAll(Collection<? extends E> elementsToAdd) {
/* 163 */     if (elementsToAdd.isEmpty()) {
/* 164 */       return false;
/*     */     }
/* 166 */     if ((elementsToAdd instanceof Multiset))
/*     */     {
/* 168 */       Multiset that = (Multiset)elementsToAdd;
/* 169 */       for (Multiset.Entry entry : that.entrySet())
/* 170 */         add(entry.getElement(), entry.getCount());
/*     */     }
/*     */     else {
/* 173 */       super.addAll(elementsToAdd);
/*     */     }
/* 175 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean removeAll(Collection<?> elementsToRemove) {
/* 179 */     Collection collection = (elementsToRemove instanceof Multiset) ? ((Multiset)elementsToRemove).elementSet() : elementsToRemove;
/*     */ 
/* 182 */     return elementSet().removeAll(collection);
/*     */   }
/*     */ 
/*     */   public boolean retainAll(Collection<?> elementsToRetain)
/*     */   {
/* 187 */     Preconditions.checkNotNull(elementsToRetain);
/* 188 */     Iterator entries = entrySet().iterator();
/* 189 */     boolean modified = false;
/* 190 */     while (entries.hasNext()) {
/* 191 */       Multiset.Entry entry = (Multiset.Entry)entries.next();
/* 192 */       if (!elementsToRetain.contains(entry.getElement())) {
/* 193 */         entries.remove();
/* 194 */         modified = true;
/*     */       }
/*     */     }
/* 197 */     return modified;
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 201 */     entrySet().clear();
/*     */   }
/*     */ 
/*     */   public Set<E> elementSet()
/*     */   {
/* 209 */     Set result = this.elementSet;
/* 210 */     if (result == null) {
/* 211 */       this.elementSet = (result = createElementSet());
/*     */     }
/* 213 */     return result;
/*     */   }
/*     */ 
/*     */   Set<E> createElementSet()
/*     */   {
/* 221 */     return new ElementSet(null);
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object)
/*     */   {
/* 254 */     if (object == this) {
/* 255 */       return true;
/*     */     }
/* 257 */     if ((object instanceof Multiset)) {
/* 258 */       Multiset that = (Multiset)object;
/*     */ 
/* 265 */       if (size() != that.size()) {
/* 266 */         return false;
/*     */       }
/* 268 */       for (Multiset.Entry entry : that.entrySet()) {
/* 269 */         if (count(entry.getElement()) != entry.getCount()) {
/* 270 */           return false;
/*     */         }
/*     */       }
/* 273 */       return true;
/*     */     }
/* 275 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 285 */     return entrySet().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 295 */     return entrySet().toString();
/*     */   }
/*     */ 
/*     */   private class ElementSet extends AbstractSet<E>
/*     */   {
/*     */     private ElementSet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<E> iterator()
/*     */     {
/* 226 */       Iterator entryIterator = AbstractMultiset.this.entrySet().iterator();
/* 227 */       return new Iterator(entryIterator) {
/*     */         public boolean hasNext() {
/* 229 */           return this.val$entryIterator.hasNext();
/*     */         }
/*     */         public E next() {
/* 232 */           return ((Multiset.Entry)this.val$entryIterator.next()).getElement();
/*     */         }
/*     */         public void remove() {
/* 235 */           this.val$entryIterator.remove();
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 240 */       return AbstractMultiset.this.entrySet().size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MultisetIterator
/*     */     implements Iterator<E>
/*     */   {
/*     */     private final Iterator<Multiset.Entry<E>> entryIterator;
/*     */     private Multiset.Entry<E> currentEntry;
/*     */     private int laterCount;
/*     */     private int totalCount;
/*     */     private boolean canRemove;
/*     */ 
/*     */     MultisetIterator()
/*     */     {
/*  87 */       this.entryIterator = AbstractMultiset.this.entrySet().iterator();
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/*  91 */       return (this.laterCount > 0) || (this.entryIterator.hasNext());
/*     */     }
/*     */ 
/*     */     public E next() {
/*  95 */       if (!hasNext()) {
/*  96 */         throw new NoSuchElementException();
/*     */       }
/*  98 */       if (this.laterCount == 0) {
/*  99 */         this.currentEntry = ((Multiset.Entry)this.entryIterator.next());
/* 100 */         this.totalCount = (this.laterCount = this.currentEntry.getCount());
/*     */       }
/* 102 */       this.laterCount -= 1;
/* 103 */       this.canRemove = true;
/* 104 */       return this.currentEntry.getElement();
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 108 */       Preconditions.checkState(this.canRemove, "no calls to next() since the last call to remove()");
/*     */ 
/* 110 */       if (this.totalCount == 1)
/* 111 */         this.entryIterator.remove();
/*     */       else {
/* 113 */         AbstractMultiset.this.remove(this.currentEntry.getElement());
/*     */       }
/* 115 */       this.totalCount -= 1;
/* 116 */       this.canRemove = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.AbstractMultiset
 * JD-Core Version:    0.6.0
 */