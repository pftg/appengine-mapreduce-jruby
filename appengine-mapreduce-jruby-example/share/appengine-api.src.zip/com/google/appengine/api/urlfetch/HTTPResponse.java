/*    */ package com.google.appengine.api.urlfetch;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class HTTPResponse
/*    */   implements Serializable
/*    */ {
/*    */   static final long serialVersionUID = -4270789523885950851L;
/*    */   private final int responseCode;
/*    */   private final List<HTTPHeader> headers;
/*    */   private byte[] content;
/*    */   private URL finalUrl;
/*    */ 
/*    */   HTTPResponse(int responseCode)
/*    */   {
/* 26 */     this.responseCode = responseCode;
/* 27 */     this.headers = new ArrayList();
/* 28 */     this.finalUrl = null;
/*    */   }
/*    */ 
/*    */   public int getResponseCode()
/*    */   {
/* 36 */     return this.responseCode;
/*    */   }
/*    */ 
/*    */   public byte[] getContent()
/*    */   {
/* 44 */     return this.content;
/*    */   }
/*    */ 
/*    */   public URL getFinalUrl()
/*    */   {
/* 53 */     return this.finalUrl;
/*    */   }
/*    */ 
/*    */   public List<HTTPHeader> getHeaders()
/*    */   {
/* 66 */     return Collections.unmodifiableList(this.headers);
/*    */   }
/*    */ 
/*    */   void addHeader(String name, String value) {
/* 70 */     this.headers.add(new HTTPHeader(name, value));
/*    */   }
/*    */ 
/*    */   void setContent(byte[] content) {
/* 74 */     this.content = content;
/*    */   }
/*    */ 
/*    */   void setFinalUrl(URL finalUrl) {
/* 78 */     this.finalUrl = finalUrl;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.HTTPResponse
 * JD-Core Version:    0.6.0
 */