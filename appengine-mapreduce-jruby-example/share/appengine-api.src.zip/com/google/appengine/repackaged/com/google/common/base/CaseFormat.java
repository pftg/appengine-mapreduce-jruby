/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ 
/*     */ @GwtCompatible
/*     */ public enum CaseFormat
/*     */ {
/*  31 */   LOWER_HYPHEN(CharMatcher.is('-'), "-"), 
/*     */ 
/*  36 */   LOWER_UNDERSCORE(CharMatcher.is('_'), "_"), 
/*     */ 
/*  41 */   LOWER_CAMEL(CharMatcher.inRange('A', 'Z'), ""), 
/*     */ 
/*  46 */   UPPER_CAMEL(CharMatcher.inRange('A', 'Z'), ""), 
/*     */ 
/*  51 */   UPPER_UNDERSCORE(CharMatcher.is('_'), "_");
/*     */ 
/*     */   private final CharMatcher wordBoundary;
/*     */   private final String wordSeparator;
/*     */ 
/*  57 */   private CaseFormat(CharMatcher wordBoundary, String wordSeparator) { this.wordBoundary = wordBoundary;
/*  58 */     this.wordSeparator = wordSeparator;
/*     */   }
/*     */ 
/*     */   public String to(CaseFormat format, String s)
/*     */   {
/*  67 */     if (format == null) {
/*  68 */       throw new NullPointerException();
/*     */     }
/*  70 */     if (s == null) {
/*  71 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*  74 */     if (format == this) {
/*  75 */       return s;
/*     */     }
/*     */ 
/*  79 */     switch (1.$SwitchMap$com$google$common$base$CaseFormat[ordinal()]) {
/*     */     case 3:
/*  81 */       switch (1.$SwitchMap$com$google$common$base$CaseFormat[format.ordinal()]) {
/*     */       case 1:
/*  83 */         return s.replace('-', '_');
/*     */       case 2:
/*  85 */         return toUpperCaseAscii(s.replace('-', '_'));
/*     */       }
/*  87 */       break;
/*     */     case 1:
/*  89 */       switch (1.$SwitchMap$com$google$common$base$CaseFormat[format.ordinal()]) {
/*     */       case 3:
/*  91 */         return s.replace('_', '-');
/*     */       case 2:
/*  93 */         return toUpperCaseAscii(s);
/*     */       }
/*  95 */       break;
/*     */     case 2:
/*  97 */       switch (1.$SwitchMap$com$google$common$base$CaseFormat[format.ordinal()]) {
/*     */       case 3:
/*  99 */         return toLowerCaseAscii(s.replace('_', '-'));
/*     */       case 1:
/* 101 */         return toLowerCaseAscii(s);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 107 */     StringBuilder out = null;
/* 108 */     int i = 0;
/* 109 */     int j = -1;
/*     */     while (true) { j++; if ((j = this.wordBoundary.indexIn(s, j)) == -1) break;
/* 111 */       if (i == 0)
/*     */       {
/* 113 */         out = new StringBuilder(s.length() + 4 * this.wordSeparator.length());
/* 114 */         out.append(format.normalizeFirstWord(s.substring(i, j)));
/*     */       } else {
/* 116 */         out.append(format.normalizeWord(s.substring(i, j)));
/*     */       }
/* 118 */       out.append(format.wordSeparator);
/* 119 */       i = j + this.wordSeparator.length();
/*     */     }
/* 121 */     if (i == 0) {
/* 122 */       return format.normalizeFirstWord(s);
/*     */     }
/* 124 */     out.append(format.normalizeWord(s.substring(i)));
/* 125 */     return out.toString();
/*     */   }
/*     */ 
/*     */   private String normalizeFirstWord(String word) {
/* 129 */     switch (1.$SwitchMap$com$google$common$base$CaseFormat[ordinal()]) {
/*     */     case 4:
/* 131 */       return toLowerCaseAscii(word);
/*     */     }
/* 133 */     return normalizeWord(word);
/*     */   }
/*     */ 
/*     */   private String normalizeWord(String word)
/*     */   {
/* 138 */     switch (1.$SwitchMap$com$google$common$base$CaseFormat[ordinal()]) {
/*     */     case 3:
/* 140 */       return toLowerCaseAscii(word);
/*     */     case 1:
/* 142 */       return toLowerCaseAscii(word);
/*     */     case 4:
/* 144 */       return firstCharOnlyToUpper(word);
/*     */     case 5:
/* 146 */       return firstCharOnlyToUpper(word);
/*     */     case 2:
/* 148 */       return toUpperCaseAscii(word);
/*     */     }
/* 150 */     throw new RuntimeException("unknown case: " + this);
/*     */   }
/*     */ 
/*     */   private static String firstCharOnlyToUpper(String word) {
/* 154 */     int length = word.length();
/* 155 */     if (length == 0) {
/* 156 */       return word;
/*     */     }
/* 158 */     return length + charToUpperCaseAscii(word.charAt(0)) + toLowerCaseAscii(word.substring(1));
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static String toUpperCaseAscii(String string)
/*     */   {
/* 165 */     int length = string.length();
/* 166 */     StringBuilder builder = new StringBuilder(length);
/* 167 */     for (int i = 0; i < length; i++) {
/* 168 */       builder.append(charToUpperCaseAscii(string.charAt(i)));
/*     */     }
/* 170 */     return builder.toString();
/*     */   }
/* 174 */   @VisibleForTesting
/*     */   static String toLowerCaseAscii(String string) { int length = string.length();
/* 175 */     StringBuilder builder = new StringBuilder(length);
/* 176 */     for (int i = 0; i < length; i++) {
/* 177 */       builder.append(charToLowerCaseAscii(string.charAt(i)));
/*     */     }
/* 179 */     return builder.toString(); }
/*     */ 
/*     */   private static char charToUpperCaseAscii(char c)
/*     */   {
/* 183 */     return isLowerCase(c) ? (char)(c & 0x5F) : c;
/*     */   }
/*     */ 
/*     */   private static char charToLowerCaseAscii(char c) {
/* 187 */     return isUpperCase(c) ? (char)(c ^ 0x20) : c;
/*     */   }
/*     */ 
/*     */   private static boolean isLowerCase(char c) {
/* 191 */     return (c >= 'a') && (c <= 'z');
/*     */   }
/*     */ 
/*     */   private static boolean isUpperCase(char c) {
/* 195 */     return (c >= 'A') && (c <= 'Z');
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.CaseFormat
 * JD-Core Version:    0.6.0
 */