/*      */ package javax.mail;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ 
/*      */ class Session$6
/*      */   implements PrivilegedAction
/*      */ {
/*      */   public Object run()
/*      */   {
/* 1243 */     URL[] ret = null;
/*      */     try {
/* 1245 */       Vector v = new Vector();
/* 1246 */       Enumeration e = ClassLoader.getSystemResources(this.val$name);
/* 1247 */       while ((e != null) && (e.hasMoreElements())) {
/* 1248 */         URL url = (URL)e.nextElement();
/* 1249 */         if (url != null)
/* 1250 */           v.addElement(url);
/*      */       }
/* 1252 */       if (v.size() > 0) {
/* 1253 */         ret = new URL[v.size()];
/* 1254 */         v.copyInto(ret);
/*      */       }
/*      */     } catch (IOException ioex) {
/*      */     } catch (SecurityException ex) {
/*      */     }
/* 1258 */     return ret;
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Session.6
 * JD-Core Version:    0.6.0
 */