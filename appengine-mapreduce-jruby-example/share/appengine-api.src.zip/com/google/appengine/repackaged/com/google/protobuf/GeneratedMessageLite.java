/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public abstract class GeneratedMessageLite extends AbstractMessageLite
/*     */   implements Serializable
/*     */ {
/*     */   protected GeneratedMessageLite()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected GeneratedMessageLite(Builder builder)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static <ContainingType extends MessageLite, Type> GeneratedExtension<ContainingType, Type> newGeneratedExtension()
/*     */   {
/* 464 */     return new GeneratedExtension(null);
/*     */   }
/*     */ 
/*     */   protected Object writeReplace()
/*     */     throws ObjectStreamException
/*     */   {
/* 662 */     return new SerializedForm(this);
/*     */   }
/*     */ 
/*     */   static final class SerializedForm
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 0L;
/*     */     private String messageClassName;
/*     */     private byte[] asBytes;
/*     */ 
/*     */     SerializedForm(MessageLite regularForm)
/*     */     {
/* 623 */       this.messageClassName = regularForm.getClass().getName();
/* 624 */       this.asBytes = regularForm.toByteArray();
/*     */     }
/*     */ 
/*     */     protected Object readResolve()
/*     */       throws ObjectStreamException
/*     */     {
/*     */       try
/*     */       {
/* 635 */         Class messageClass = Class.forName(this.messageClassName);
/* 636 */         Method newBuilder = messageClass.getMethod("newBuilder", new Class[0]);
/* 637 */         MessageLite.Builder builder = (MessageLite.Builder)newBuilder.invoke(null, new Object[0]);
/*     */ 
/* 639 */         builder.mergeFrom(this.asBytes);
/* 640 */         return builder.buildPartial();
/*     */       } catch (ClassNotFoundException e) {
/* 642 */         throw new RuntimeException("Unable to find proto buffer class", e);
/*     */       } catch (NoSuchMethodException e) {
/* 644 */         throw new RuntimeException("Unable to find newBuilder method", e);
/*     */       } catch (IllegalAccessException e) {
/* 646 */         throw new RuntimeException("Unable to call newBuilder method", e);
/*     */       } catch (InvocationTargetException e) {
/* 648 */         throw new RuntimeException("Error calling newBuilder", e.getCause()); } catch (InvalidProtocolBufferException e) {
/*     */       }
/* 650 */       throw new RuntimeException("Unable to understand proto buffer", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class GeneratedExtension<ContainingType extends MessageLite, Type>
/*     */   {
/*     */     private ContainingType containingTypeDefaultInstance;
/*     */     private Type defaultValue;
/*     */     private MessageLite messageDefaultInstance;
/*     */     private GeneratedMessageLite.ExtensionDescriptor descriptor;
/*     */ 
/*     */     private void internalInit(ContainingType containingTypeDefaultInstance, Type defaultValue, MessageLite messageDefaultInstance, GeneratedMessageLite.ExtensionDescriptor descriptor)
/*     */     {
/* 546 */       this.containingTypeDefaultInstance = containingTypeDefaultInstance;
/* 547 */       this.defaultValue = defaultValue;
/* 548 */       this.messageDefaultInstance = messageDefaultInstance;
/* 549 */       this.descriptor = descriptor;
/*     */     }
/*     */ 
/*     */     public void internalInitSingular(ContainingType containingTypeDefaultInstance, Type defaultValue, MessageLite messageDefaultInstance, Internal.EnumLiteMap<?> enumTypeMap, int number, WireFormat.FieldType type)
/*     */     {
/* 560 */       internalInit(containingTypeDefaultInstance, defaultValue, messageDefaultInstance, new GeneratedMessageLite.ExtensionDescriptor(enumTypeMap, number, type, false, false, null));
/*     */     }
/*     */ 
/*     */     public void internalInitRepeated(ContainingType containingTypeDefaultInstance, MessageLite messageDefaultInstance, Internal.EnumLiteMap<?> enumTypeMap, int number, WireFormat.FieldType type, boolean isPacked)
/*     */     {
/* 575 */       Object emptyList = Collections.emptyList();
/* 576 */       internalInit(containingTypeDefaultInstance, emptyList, messageDefaultInstance, new GeneratedMessageLite.ExtensionDescriptor(enumTypeMap, number, type, true, isPacked, null));
/*     */     }
/*     */ 
/*     */     public ContainingType getContainingTypeDefaultInstance()
/*     */     {
/* 591 */       return this.containingTypeDefaultInstance;
/*     */     }
/*     */ 
/*     */     public int getNumber()
/*     */     {
/* 596 */       return this.descriptor.getNumber();
/*     */     }
/*     */ 
/*     */     public MessageLite getMessageDefaultInstance()
/*     */     {
/* 604 */       return this.messageDefaultInstance;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class ExtensionDescriptor
/*     */     implements FieldSet.FieldDescriptorLite<ExtensionDescriptor>
/*     */   {
/*     */     private final Internal.EnumLiteMap<?> enumTypeMap;
/*     */     private final int number;
/*     */     private final WireFormat.FieldType type;
/*     */     private final boolean isRepeated;
/*     */     private final boolean isPacked;
/*     */ 
/*     */     private ExtensionDescriptor(Internal.EnumLiteMap<?> enumTypeMap, int number, WireFormat.FieldType type, boolean isRepeated, boolean isPacked)
/*     */     {
/* 476 */       this.enumTypeMap = enumTypeMap;
/* 477 */       this.number = number;
/* 478 */       this.type = type;
/* 479 */       this.isRepeated = isRepeated;
/* 480 */       this.isPacked = isPacked;
/*     */     }
/*     */ 
/*     */     public int getNumber()
/*     */     {
/* 490 */       return this.number;
/*     */     }
/*     */ 
/*     */     public WireFormat.FieldType getLiteType() {
/* 494 */       return this.type;
/*     */     }
/*     */ 
/*     */     public WireFormat.JavaType getLiteJavaType() {
/* 498 */       return this.type.getJavaType();
/*     */     }
/*     */ 
/*     */     public boolean isRepeated() {
/* 502 */       return this.isRepeated;
/*     */     }
/*     */ 
/*     */     public boolean isPacked() {
/* 506 */       return this.isPacked;
/*     */     }
/*     */ 
/*     */     public Internal.EnumLiteMap<?> getEnumType() {
/* 510 */       return this.enumTypeMap;
/*     */     }
/*     */ 
/*     */     public MessageLite.Builder internalMergeFrom(MessageLite.Builder to, MessageLite from)
/*     */     {
/* 516 */       return ((GeneratedMessageLite.Builder)to).mergeFrom((GeneratedMessageLite)from);
/*     */     }
/*     */ 
/*     */     public int compareTo(ExtensionDescriptor other) {
/* 520 */       return this.number - other.number;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class ExtendableBuilder<MessageType extends GeneratedMessageLite.ExtendableMessage<MessageType>, BuilderType extends ExtendableBuilder<MessageType, BuilderType>> extends GeneratedMessageLite.Builder<MessageType, BuilderType>
/*     */   {
/* 208 */     private FieldSet<GeneratedMessageLite.ExtensionDescriptor> extensions = FieldSet.emptySet();
/*     */     private boolean extensionsIsMutable;
/*     */ 
/*     */     public BuilderType clear()
/*     */     {
/* 213 */       this.extensions.clear();
/* 214 */       this.extensionsIsMutable = false;
/* 215 */       return (ExtendableBuilder)super.clear();
/*     */     }
/*     */ 
/*     */     private void ensureExtensionsIsMutable() {
/* 219 */       if (!this.extensionsIsMutable) {
/* 220 */         this.extensions = this.extensions.clone();
/* 221 */         this.extensionsIsMutable = true;
/*     */       }
/*     */     }
/*     */ 
/*     */     private FieldSet<GeneratedMessageLite.ExtensionDescriptor> buildExtensions()
/*     */     {
/* 230 */       this.extensions.makeImmutable();
/* 231 */       this.extensionsIsMutable = false;
/* 232 */       return this.extensions;
/*     */     }
/*     */ 
/*     */     private void verifyExtensionContainingType(GeneratedMessageLite.GeneratedExtension<MessageType, ?> extension)
/*     */     {
/* 237 */       if (extension.getContainingTypeDefaultInstance() != getDefaultInstanceForType())
/*     */       {
/* 240 */         throw new IllegalArgumentException("This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.");
/*     */       }
/*     */     }
/*     */ 
/*     */     public final boolean hasExtension(GeneratedMessageLite.GeneratedExtension<MessageType, ?> extension)
/*     */     {
/* 249 */       verifyExtensionContainingType(extension);
/* 250 */       return this.extensions.hasField(extension.descriptor);
/*     */     }
/*     */ 
/*     */     public final <Type> int getExtensionCount(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> extension)
/*     */     {
/* 256 */       verifyExtensionContainingType(extension);
/* 257 */       return this.extensions.getRepeatedFieldCount(extension.descriptor);
/*     */     }
/*     */ 
/*     */     public final <Type> Type getExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> extension)
/*     */     {
/* 264 */       verifyExtensionContainingType(extension);
/* 265 */       Object value = this.extensions.getField(extension.descriptor);
/* 266 */       if (value == null) {
/* 267 */         return extension.defaultValue;
/*     */       }
/* 269 */       return value;
/*     */     }
/*     */ 
/*     */     public final <Type> Type getExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> extension, int index)
/*     */     {
/* 278 */       verifyExtensionContainingType(extension);
/* 279 */       return this.extensions.getRepeatedField(extension.descriptor, index);
/*     */     }
/*     */ 
/*     */     public BuilderType clone()
/*     */     {
/* 287 */       throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
/*     */     }
/*     */ 
/*     */     public final <Type> BuilderType setExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> extension, Type value)
/*     */     {
/* 295 */       verifyExtensionContainingType(extension);
/* 296 */       ensureExtensionsIsMutable();
/* 297 */       this.extensions.setField(extension.descriptor, value);
/* 298 */       return this;
/*     */     }
/*     */ 
/*     */     public final <Type> BuilderType setExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> extension, int index, Type value)
/*     */     {
/* 305 */       verifyExtensionContainingType(extension);
/* 306 */       ensureExtensionsIsMutable();
/* 307 */       this.extensions.setRepeatedField(extension.descriptor, index, value);
/* 308 */       return this;
/*     */     }
/*     */ 
/*     */     public final <Type> BuilderType addExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> extension, Type value)
/*     */     {
/* 315 */       verifyExtensionContainingType(extension);
/* 316 */       ensureExtensionsIsMutable();
/* 317 */       this.extensions.addRepeatedField(extension.descriptor, value);
/* 318 */       return this;
/*     */     }
/*     */ 
/*     */     public final <Type> BuilderType clearExtension(GeneratedMessageLite.GeneratedExtension<MessageType, ?> extension)
/*     */     {
/* 324 */       verifyExtensionContainingType(extension);
/* 325 */       ensureExtensionsIsMutable();
/* 326 */       this.extensions.clearField(extension.descriptor);
/* 327 */       return this;
/*     */     }
/*     */ 
/*     */     protected boolean extensionsAreInitialized()
/*     */     {
/* 332 */       return this.extensions.isInitialized();
/*     */     }
/*     */ 
/*     */     protected boolean parseUnknownField(CodedInputStream input, ExtensionRegistryLite extensionRegistry, int tag)
/*     */       throws IOException
/*     */     {
/* 344 */       int wireType = WireFormat.getTagWireType(tag);
/* 345 */       int fieldNumber = WireFormat.getTagFieldNumber(tag);
/*     */ 
/* 347 */       GeneratedMessageLite.GeneratedExtension extension = extensionRegistry.findLiteExtensionByNumber(getDefaultInstanceForType(), fieldNumber);
/*     */ 
/* 351 */       boolean unknown = false;
/* 352 */       boolean packed = false;
/* 353 */       if (extension == null)
/* 354 */         unknown = true;
/* 355 */       else if (wireType == FieldSet.getWireFormatForFieldType(extension.descriptor.getLiteType(), false))
/*     */       {
/* 358 */         packed = false;
/* 359 */       } else if ((GeneratedMessageLite.GeneratedExtension.access$100(extension).isRepeated) && (GeneratedMessageLite.GeneratedExtension.access$100(extension).type.isPackable()) && (wireType == FieldSet.getWireFormatForFieldType(extension.descriptor.getLiteType(), true)))
/*     */       {
/* 364 */         packed = true;
/*     */       }
/* 366 */       else unknown = true;
/*     */ 
/* 369 */       if (unknown) {
/* 370 */         return input.skipField(tag);
/*     */       }
/*     */ 
/* 373 */       if (packed) {
/* 374 */         int length = input.readRawVarint32();
/* 375 */         int limit = input.pushLimit(length);
/* 376 */         if (extension.descriptor.getLiteType() == WireFormat.FieldType.ENUM) {
/* 377 */           while (input.getBytesUntilLimit() > 0) {
/* 378 */             int rawValue = input.readEnum();
/* 379 */             Object value = extension.descriptor.getEnumType().findValueByNumber(rawValue);
/*     */ 
/* 381 */             if (value == null)
/*     */             {
/* 384 */               return true;
/*     */             }
/* 386 */             ensureExtensionsIsMutable();
/* 387 */             this.extensions.addRepeatedField(extension.descriptor, value);
/*     */           }
/*     */         }
/* 390 */         while (input.getBytesUntilLimit() > 0) {
/* 391 */           Object value = FieldSet.readPrimitiveField(input, extension.descriptor.getLiteType());
/*     */ 
/* 394 */           ensureExtensionsIsMutable();
/* 395 */           this.extensions.addRepeatedField(extension.descriptor, value);
/*     */         }
/*     */ 
/* 398 */         input.popLimit(limit);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object value;
/* 401 */         switch (GeneratedMessageLite.1.$SwitchMap$com$google$protobuf$WireFormat$JavaType[extension.descriptor.getLiteJavaType().ordinal()]) {
/*     */         case 1:
/* 403 */           MessageLite.Builder subBuilder = null;
/* 404 */           if (!extension.descriptor.isRepeated()) {
/* 405 */             MessageLite existingValue = (MessageLite)this.extensions.getField(extension.descriptor);
/*     */ 
/* 407 */             if (existingValue != null) {
/* 408 */               subBuilder = existingValue.toBuilder();
/*     */             }
/*     */           }
/* 411 */           if (subBuilder == null) {
/* 412 */             subBuilder = extension.messageDefaultInstance.newBuilderForType();
/*     */           }
/* 414 */           if (extension.descriptor.getLiteType() == WireFormat.FieldType.GROUP)
/*     */           {
/* 416 */             input.readGroup(extension.getNumber(), subBuilder, extensionRegistry);
/*     */           }
/*     */           else {
/* 419 */             input.readMessage(subBuilder, extensionRegistry);
/*     */           }
/* 421 */           value = subBuilder.build();
/* 422 */           break;
/*     */         case 2:
/* 425 */           int rawValue = input.readEnum();
/* 426 */           value = extension.descriptor.getEnumType().findValueByNumber(rawValue);
/*     */ 
/* 430 */           if (value != null) break;
/* 431 */           return true;
/*     */         default:
/* 435 */           value = FieldSet.readPrimitiveField(input, extension.descriptor.getLiteType());
/*     */         }
/*     */ 
/* 440 */         if (extension.descriptor.isRepeated()) {
/* 441 */           ensureExtensionsIsMutable();
/* 442 */           this.extensions.addRepeatedField(extension.descriptor, value);
/*     */         } else {
/* 444 */           ensureExtensionsIsMutable();
/* 445 */           this.extensions.setField(extension.descriptor, value);
/*     */         }
/*     */       }
/*     */ 
/* 449 */       return true;
/*     */     }
/*     */ 
/*     */     protected final void mergeExtensionFields(MessageType other) {
/* 453 */       ensureExtensionsIsMutable();
/* 454 */       this.extensions.mergeFrom(GeneratedMessageLite.ExtendableMessage.access$300(other));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class ExtendableMessage<MessageType extends ExtendableMessage<MessageType>> extends GeneratedMessageLite
/*     */   {
/*     */     private final FieldSet<GeneratedMessageLite.ExtensionDescriptor> extensions;
/*     */ 
/*     */     protected ExtendableMessage()
/*     */     {
/*  80 */       this.extensions = FieldSet.newFieldSet();
/*     */     }
/*     */ 
/*     */     protected ExtendableMessage(GeneratedMessageLite.ExtendableBuilder<MessageType, ?> builder) {
/*  84 */       this.extensions = builder.buildExtensions();
/*     */     }
/*     */ 
/*     */     private void verifyExtensionContainingType(GeneratedMessageLite.GeneratedExtension<MessageType, ?> extension)
/*     */     {
/*  89 */       if (extension.getContainingTypeDefaultInstance() != getDefaultInstanceForType())
/*     */       {
/*  92 */         throw new IllegalArgumentException("This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.");
/*     */       }
/*     */     }
/*     */ 
/*     */     public final boolean hasExtension(GeneratedMessageLite.GeneratedExtension<MessageType, ?> extension)
/*     */     {
/* 101 */       verifyExtensionContainingType(extension);
/* 102 */       return this.extensions.hasField(extension.descriptor);
/*     */     }
/*     */ 
/*     */     public final <Type> int getExtensionCount(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> extension)
/*     */     {
/* 108 */       verifyExtensionContainingType(extension);
/* 109 */       return this.extensions.getRepeatedFieldCount(extension.descriptor);
/*     */     }
/*     */ 
/*     */     public final <Type> Type getExtension(GeneratedMessageLite.GeneratedExtension<MessageType, Type> extension)
/*     */     {
/* 116 */       verifyExtensionContainingType(extension);
/* 117 */       Object value = this.extensions.getField(extension.descriptor);
/* 118 */       if (value == null) {
/* 119 */         return extension.defaultValue;
/*     */       }
/* 121 */       return value;
/*     */     }
/*     */ 
/*     */     public final <Type> Type getExtension(GeneratedMessageLite.GeneratedExtension<MessageType, List<Type>> extension, int index)
/*     */     {
/* 130 */       verifyExtensionContainingType(extension);
/* 131 */       return this.extensions.getRepeatedField(extension.descriptor, index);
/*     */     }
/*     */ 
/*     */     protected boolean extensionsAreInitialized()
/*     */     {
/* 136 */       return this.extensions.isInitialized();
/*     */     }
/*     */ 
/*     */     protected ExtendableMessage<MessageType>.ExtensionWriter newExtensionWriter()
/*     */     {
/* 183 */       return new ExtensionWriter(false, null);
/*     */     }
/*     */     protected ExtendableMessage<MessageType>.ExtensionWriter newMessageSetExtensionWriter() {
/* 186 */       return new ExtensionWriter(true, null);
/*     */     }
/*     */ 
/*     */     protected int extensionsSerializedSize()
/*     */     {
/* 191 */       return this.extensions.getSerializedSize();
/*     */     }
/*     */     protected int extensionsSerializedSizeAsMessageSet() {
/* 194 */       return this.extensions.getMessageSetSerializedSize();
/*     */     }
/*     */ 
/*     */     protected class ExtensionWriter
/*     */     {
/* 149 */       private final Iterator<Map.Entry<GeneratedMessageLite.ExtensionDescriptor, Object>> iter = GeneratedMessageLite.ExtendableMessage.this.extensions.iterator();
/*     */       private Map.Entry<GeneratedMessageLite.ExtensionDescriptor, Object> next;
/*     */       private final boolean messageSetWireFormat;
/*     */ 
/*     */       private ExtensionWriter(boolean messageSetWireFormat)
/*     */       {
/* 155 */         if (this.iter.hasNext()) {
/* 156 */           this.next = ((Map.Entry)this.iter.next());
/*     */         }
/* 158 */         this.messageSetWireFormat = messageSetWireFormat;
/*     */       }
/*     */ 
/*     */       public void writeUntil(int end, CodedOutputStream output) throws IOException
/*     */       {
/* 163 */         while ((this.next != null) && (((GeneratedMessageLite.ExtensionDescriptor)this.next.getKey()).getNumber() < end)) {
/* 164 */           GeneratedMessageLite.ExtensionDescriptor extension = (GeneratedMessageLite.ExtensionDescriptor)this.next.getKey();
/* 165 */           if ((this.messageSetWireFormat) && (extension.getLiteJavaType() == WireFormat.JavaType.MESSAGE) && (!extension.isRepeated()))
/*     */           {
/* 168 */             output.writeMessageSetExtension(extension.getNumber(), (MessageLite)this.next.getValue());
/*     */           }
/*     */           else {
/* 171 */             FieldSet.writeField(extension, this.next.getValue(), output);
/*     */           }
/* 173 */           if (this.iter.hasNext())
/* 174 */             this.next = ((Map.Entry)this.iter.next());
/*     */           else
/* 176 */             this.next = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class Builder<MessageType extends GeneratedMessageLite, BuilderType extends Builder> extends AbstractMessageLite.Builder<BuilderType>
/*     */   {
/*     */     public BuilderType clear()
/*     */     {
/*  37 */       return this;
/*     */     }
/*     */ 
/*     */     public BuilderType clone()
/*     */     {
/*  45 */       throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
/*     */     }
/*     */ 
/*     */     public abstract BuilderType mergeFrom(MessageType paramMessageType);
/*     */ 
/*     */     public abstract MessageType getDefaultInstanceForType();
/*     */ 
/*     */     protected boolean parseUnknownField(CodedInputStream input, ExtensionRegistryLite extensionRegistry, int tag)
/*     */       throws IOException
/*     */     {
/*  63 */       return input.skipField(tag);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.GeneratedMessageLite
 * JD-Core Version:    0.6.0
 */