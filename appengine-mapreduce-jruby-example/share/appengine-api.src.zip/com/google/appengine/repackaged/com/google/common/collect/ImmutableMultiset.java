/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true)
/*     */ public class ImmutableMultiset<E> extends ImmutableCollection<E>
/*     */   implements Multiset<E>
/*     */ {
/*     */   private final transient ImmutableMap<E, Integer> map;
/*     */   private final transient int size;
/*     */   private transient ImmutableSet<Multiset.Entry<E>> entrySet;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of()
/*     */   {
/*  60 */     return EmptyImmutableMultiset.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of(E element)
/*     */   {
/*  70 */     return copyOfInternal(new Object[] { element });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of(E e1, E e2)
/*     */   {
/*  80 */     return copyOfInternal(new Object[] { e1, e2 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3)
/*     */   {
/*  90 */     return copyOfInternal(new Object[] { e1, e2, e3 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4)
/*     */   {
/* 100 */     return copyOfInternal(new Object[] { e1, e2, e3, e4 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5)
/*     */   {
/* 110 */     return copyOfInternal(new Object[] { e1, e2, e3, e4, e5 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E[] others)
/*     */   {
/* 121 */     int size = others.length + 6;
/* 122 */     List all = new ArrayList(size);
/* 123 */     Collections.addAll(all, new Object[] { e1, e2, e3, e4, e5, e6 });
/* 124 */     Collections.addAll(all, others);
/* 125 */     return copyOf(all);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static <E> ImmutableMultiset<E> of(E[] elements)
/*     */   {
/* 140 */     return copyOf(Arrays.asList(elements));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> copyOf(E[] elements)
/*     */   {
/* 154 */     return copyOf(Arrays.asList(elements));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> copyOf(Iterable<? extends E> elements)
/*     */   {
/* 179 */     if ((elements instanceof ImmutableMultiset))
/*     */     {
/* 181 */       ImmutableMultiset result = (ImmutableMultiset)elements;
/* 182 */       return result;
/*     */     }
/*     */ 
/* 186 */     Multiset multiset = (elements instanceof Multiset) ? (Multiset)elements : LinkedHashMultiset.create(elements);
/*     */ 
/* 190 */     return copyOfInternal(multiset);
/*     */   }
/*     */ 
/*     */   private static <E> ImmutableMultiset<E> copyOfInternal(E[] elements) {
/* 194 */     return copyOf(Arrays.asList(elements));
/*     */   }
/*     */ 
/*     */   private static <E> ImmutableMultiset<E> copyOfInternal(Multiset<? extends E> multiset)
/*     */   {
/* 199 */     long size = 0L;
/* 200 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/*     */ 
/* 202 */     for (Multiset.Entry entry : multiset.entrySet()) {
/* 203 */       int count = entry.getCount();
/* 204 */       if (count > 0)
/*     */       {
/* 207 */         builder.put(entry.getElement(), Integer.valueOf(count));
/* 208 */         size += count;
/*     */       }
/*     */     }
/*     */ 
/* 212 */     if (size == 0L) {
/* 213 */       return of();
/*     */     }
/* 215 */     return new ImmutableMultiset(builder.build(), Ints.saturatedCast(size));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableMultiset<E> copyOf(Iterator<? extends E> elements)
/*     */   {
/* 230 */     Multiset multiset = LinkedHashMultiset.create();
/* 231 */     Iterators.addAll(multiset, elements);
/* 232 */     return copyOfInternal(multiset);
/*     */   }
/*     */ 
/*     */   ImmutableMultiset(ImmutableMap<E, Integer> map, int size)
/*     */   {
/* 252 */     this.map = map;
/* 253 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public int count(@Nullable Object element) {
/* 257 */     Integer value = (Integer)this.map.get(element);
/* 258 */     return value == null ? 0 : value.intValue();
/*     */   }
/*     */ 
/*     */   public UnmodifiableIterator<E> iterator() {
/* 262 */     Iterator mapIterator = this.map.entrySet().iterator();
/*     */ 
/* 265 */     return new UnmodifiableIterator(mapIterator) { int remaining;
/*     */       E element;
/*     */ 
/* 270 */       public boolean hasNext() { return (this.remaining > 0) || (this.val$mapIterator.hasNext()); }
/*     */ 
/*     */       public E next()
/*     */       {
/* 274 */         if (this.remaining <= 0) {
/* 275 */           Map.Entry entry = (Map.Entry)this.val$mapIterator.next();
/* 276 */           this.element = entry.getKey();
/* 277 */           this.remaining = ((Integer)entry.getValue()).intValue();
/*     */         }
/* 279 */         this.remaining -= 1;
/* 280 */         return this.element;
/*     */       } } ;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 286 */     return this.size;
/*     */   }
/*     */ 
/*     */   public boolean contains(@Nullable Object element) {
/* 290 */     return this.map.containsKey(element);
/*     */   }
/*     */ 
/*     */   public int add(E element, int occurrences)
/*     */   {
/* 299 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int remove(Object element, int occurrences)
/*     */   {
/* 308 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int setCount(E element, int count)
/*     */   {
/* 317 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean setCount(E element, int oldCount, int newCount)
/*     */   {
/* 326 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object) {
/* 330 */     if (object == this) {
/* 331 */       return true;
/*     */     }
/* 333 */     if ((object instanceof Multiset)) {
/* 334 */       Multiset that = (Multiset)object;
/* 335 */       if (size() != that.size()) {
/* 336 */         return false;
/*     */       }
/* 338 */       for (Multiset.Entry entry : that.entrySet()) {
/* 339 */         if (count(entry.getElement()) != entry.getCount()) {
/* 340 */           return false;
/*     */         }
/*     */       }
/* 343 */       return true;
/*     */     }
/* 345 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 350 */     return this.map.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 354 */     return entrySet().toString();
/*     */   }
/*     */ 
/*     */   public Set<E> elementSet()
/*     */   {
/* 362 */     return this.map.keySet();
/*     */   }
/*     */ 
/*     */   public Set<Multiset.Entry<E>> entrySet()
/*     */   {
/* 368 */     ImmutableSet es = this.entrySet;
/* 369 */     return es == null ? (this.entrySet = new EntrySet(this)) : es;
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 452 */     stream.defaultWriteObject();
/* 453 */     Serialization.writeMultiset(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 459 */     stream.defaultReadObject();
/* 460 */     int entryCount = stream.readInt();
/* 461 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/* 462 */     long tmpSize = 0L;
/* 463 */     for (int i = 0; i < entryCount; i++)
/*     */     {
/* 465 */       Object element = stream.readObject();
/* 466 */       int count = stream.readInt();
/* 467 */       if (count <= 0) {
/* 468 */         throw new InvalidObjectException("Invalid count " + count);
/*     */       }
/* 470 */       builder.put(element, Integer.valueOf(count));
/* 471 */       tmpSize += count;
/*     */     }
/*     */ 
/* 474 */     FieldSettersHolder.MAP_FIELD_SETTER.set(this, builder.build());
/* 475 */     FieldSettersHolder.SIZE_FIELD_SETTER.set(this, Ints.saturatedCast(tmpSize));
/*     */   }
/*     */   @GwtIncompatible("java serialization not supported.")
/*     */   Object writeReplace() {
/* 480 */     return this;
/*     */   }
/*     */ 
/*     */   public static <E> Builder<E> builder()
/*     */   {
/* 490 */     return new Builder();
/*     */   }
/*     */ 
/*     */   public static final class Builder<E> extends ImmutableCollection.Builder<E>
/*     */   {
/* 512 */     private final Multiset<E> contents = LinkedHashMultiset.create();
/*     */ 
/*     */     public Builder<E> add(E element)
/*     */     {
/* 528 */       this.contents.add(Preconditions.checkNotNull(element));
/* 529 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addCopies(E element, int occurrences)
/*     */     {
/* 546 */       this.contents.add(Preconditions.checkNotNull(element), occurrences);
/* 547 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> setCount(E element, int count)
/*     */     {
/* 561 */       this.contents.setCount(Preconditions.checkNotNull(element), count);
/* 562 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> add(E[] elements)
/*     */     {
/* 574 */       super.add(elements);
/* 575 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterable<? extends E> elements)
/*     */     {
/* 588 */       if ((elements instanceof Multiset))
/*     */       {
/* 590 */         Multiset multiset = (Multiset)elements;
/* 591 */         for (Multiset.Entry entry : multiset.entrySet())
/* 592 */           addCopies(entry.getElement(), entry.getCount());
/*     */       }
/*     */       else {
/* 595 */         super.addAll(elements);
/*     */       }
/* 597 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterator<? extends E> elements)
/*     */     {
/* 609 */       super.addAll(elements);
/* 610 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableMultiset<E> build()
/*     */     {
/* 618 */       return ImmutableMultiset.copyOf(this.contents);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EntrySet<E> extends ImmutableSet<Multiset.Entry<E>>
/*     */   {
/*     */     final ImmutableMultiset<E> multiset;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     public EntrySet(ImmutableMultiset<E> multiset)
/*     */     {
/* 376 */       this.multiset = multiset;
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<Multiset.Entry<E>> iterator() {
/* 380 */       Iterator mapIterator = this.multiset.map.entrySet().iterator();
/*     */ 
/* 382 */       return new UnmodifiableIterator(mapIterator) {
/*     */         public boolean hasNext() {
/* 384 */           return this.val$mapIterator.hasNext();
/*     */         }
/*     */         public Multiset.Entry<E> next() {
/* 387 */           Map.Entry mapEntry = (Map.Entry)this.val$mapIterator.next();
/* 388 */           return Multisets.immutableEntry(mapEntry.getKey(), ((Integer)mapEntry.getValue()).intValue());
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public int size() {
/* 395 */       return this.multiset.map.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 399 */       if ((o instanceof Multiset.Entry)) {
/* 400 */         Multiset.Entry entry = (Multiset.Entry)o;
/* 401 */         if (entry.getCount() <= 0) {
/* 402 */           return false;
/*     */         }
/* 404 */         int count = this.multiset.count(entry.getElement());
/* 405 */         return count == entry.getCount();
/*     */       }
/* 407 */       return false;
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 412 */       Object[] newArray = new Object[size()];
/* 413 */       return toArray(newArray);
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] other)
/*     */     {
/* 418 */       int size = size();
/* 419 */       if (other.length < size)
/* 420 */         other = ObjectArrays.newArray(other, size);
/* 421 */       else if (other.length > size) {
/* 422 */         other[size] = null;
/*     */       }
/*     */ 
/* 426 */       Object[] otherAsObjectArray = other;
/* 427 */       int index = 0;
/* 428 */       for (Multiset.Entry element : this) {
/* 429 */         otherAsObjectArray[(index++)] = element;
/*     */       }
/* 431 */       return other;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 435 */       return this.multiset.map.hashCode();
/*     */     }
/*     */     @GwtIncompatible("not needed in emulated source.")
/*     */     Object writeReplace() {
/* 440 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java serialization is not supported.")
/*     */   private static class FieldSettersHolder
/*     */   {
/* 245 */     static final Serialization.FieldSetter<ImmutableMultiset> MAP_FIELD_SETTER = Serialization.getFieldSetter(ImmutableMultiset.class, "map");
/*     */ 
/* 247 */     static final Serialization.FieldSetter<ImmutableMultiset> SIZE_FIELD_SETTER = Serialization.getFieldSetter(ImmutableMultiset.class, "size");
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableMultiset
 * JD-Core Version:    0.6.0
 */