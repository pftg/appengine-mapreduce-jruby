/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public final class DatastoreServiceFactory
/*    */ {
/*    */   public static DatastoreService getDatastoreService()
/*    */   {
/* 20 */     return getDatastoreService(DatastoreServiceConfig.Builder.withDefaults());
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public static DatastoreService getDatastoreService(DatastoreConfig oldConfig)
/*    */   {
/* 30 */     DatastoreServiceConfig newConfig = DatastoreServiceConfig.Builder.withImplicitTransactionManagementPolicy(oldConfig.getImplicitTransactionManagementPolicy());
/*    */ 
/* 32 */     return getDatastoreService(newConfig);
/*    */   }
/*    */ 
/*    */   public static DatastoreService getDatastoreService(DatastoreServiceConfig config)
/*    */   {
/* 39 */     return new DatastoreServiceImpl(config, new TransactionStackImpl());
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public static DatastoreConfig getDefaultDatastoreConfig()
/*    */   {
/* 48 */     return DatastoreConfig.DEFAULT;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreServiceFactory
 * JD-Core Version:    0.6.0
 */