/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractList;
/*     */ import java.util.AbstractSequentialList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.RandomAccess;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Lists
/*     */ {
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> ArrayList<E> newArrayList()
/*     */   {
/*  68 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> ArrayList<E> newArrayList(E[] elements)
/*     */   {
/*  84 */     Preconditions.checkNotNull(elements);
/*     */ 
/*  86 */     int capacity = computeArrayListCapacity(elements.length);
/*  87 */     ArrayList list = new ArrayList(capacity);
/*  88 */     Collections.addAll(list, elements);
/*  89 */     return list;
/*     */   }
/*  93 */   @VisibleForTesting
/*     */   static int computeArrayListCapacity(int arraySize) { Preconditions.checkArgument(arraySize >= 0);
/*     */ 
/*  96 */     return Ints.saturatedCast(5L + arraySize + arraySize / 10);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> ArrayList<E> newArrayList(Iterable<? extends E> elements)
/*     */   {
/* 111 */     Preconditions.checkNotNull(elements);
/*     */ 
/* 113 */     if ((elements instanceof Collection))
/*     */     {
/* 115 */       Collection collection = (Collection)elements;
/* 116 */       return new ArrayList(collection);
/*     */     }
/* 118 */     return newArrayList(elements.iterator());
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> ArrayList<E> newArrayList(Iterator<? extends E> elements)
/*     */   {
/* 134 */     Preconditions.checkNotNull(elements);
/* 135 */     ArrayList list = newArrayList();
/* 136 */     while (elements.hasNext()) {
/* 137 */       list.add(elements.next());
/*     */     }
/* 139 */     return list;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> ArrayList<E> newArrayListWithCapacity(int initialArraySize)
/*     */   {
/* 165 */     return new ArrayList(initialArraySize);
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> ArrayList<E> newArrayListWithExpectedSize(int estimatedSize)
/*     */   {
/* 186 */     return new ArrayList(computeArrayListCapacity(estimatedSize));
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> LinkedList<E> newLinkedList()
/*     */   {
/* 201 */     return new LinkedList();
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   @GoogleInternal
/*     */   public static <E> LinkedList<E> newLinkedList(E[] elements)
/*     */   {
/* 213 */     LinkedList list = newLinkedList();
/* 214 */     Collections.addAll(list, elements);
/* 215 */     return list;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <E> LinkedList<E> newLinkedList(Iterable<? extends E> elements)
/*     */   {
/* 227 */     LinkedList list = newLinkedList();
/* 228 */     for (Iterator i$ = elements.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 229 */       list.add(element);
/*     */     }
/* 231 */     return list;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   @GoogleInternal
/*     */   public static <E> LinkedList<E> newLinkedList(Iterator<? extends E> elements)
/*     */   {
/* 244 */     LinkedList list = newLinkedList();
/* 245 */     while (elements.hasNext()) {
/* 246 */       list.add(elements.next());
/*     */     }
/* 248 */     return list;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   @GoogleInternal
/*     */   public static <E> List<E> newUnmodifiableArrayList(E[] elements)
/*     */   {
/* 262 */     return Collections.unmodifiableList(Arrays.asList(Platform.clone(elements)));
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <E> List<E> newUnmodifiableArrayList(Iterable<? extends E> elements)
/*     */   {
/* 277 */     return Collections.unmodifiableList(newArrayList(elements));
/*     */   }
/*     */ 
/*     */   public static <E> List<E> asList(@Nullable E first, E[] rest)
/*     */   {
/* 297 */     return new OnePlusArrayList(first, rest);
/*     */   }
/*     */ 
/*     */   public static <E> List<E> asList(@Nullable E first, @Nullable E second, E[] rest)
/*     */   {
/* 340 */     return new TwoPlusArrayList(first, second, rest);
/*     */   }
/*     */ 
/*     */   public static <F, T> List<T> transform(List<F> fromList, Function<? super F, ? extends T> function)
/*     */   {
/* 399 */     return (fromList instanceof RandomAccess) ? new TransformingRandomAccessList(fromList, function) : new TransformingSequentialList(fromList, function);
/*     */   }
/*     */ 
/*     */   public static <T> List<List<T>> partition(List<T> list, int size)
/*     */   {
/* 529 */     Preconditions.checkNotNull(list);
/* 530 */     Preconditions.checkArgument(size > 0);
/* 531 */     return (list instanceof RandomAccess) ? new RandomAccessPartition(list, size) : new Partition(list, size);
/*     */   }
/*     */ 
/*     */   private static class RandomAccessPartition<T> extends Lists.Partition<T>
/*     */     implements RandomAccess
/*     */   {
/*     */     RandomAccessPartition(List<T> list, int size)
/*     */     {
/* 565 */       super(size);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Partition<T> extends AbstractList<List<T>>
/*     */   {
/*     */     final List<T> list;
/*     */     final int size;
/*     */ 
/*     */     Partition(List<T> list, int size)
/*     */     {
/* 541 */       this.list = list;
/* 542 */       this.size = size;
/*     */     }
/*     */ 
/*     */     public List<T> get(int index) {
/* 546 */       int listSize = size();
/* 547 */       Preconditions.checkElementIndex(index, listSize);
/* 548 */       int start = index * this.size;
/* 549 */       int end = Math.min(start + this.size, this.list.size());
/* 550 */       return this.list.subList(start, end);
/*     */     }
/*     */ 
/*     */     public int size() {
/* 554 */       return (this.list.size() + this.size - 1) / this.size;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 558 */       return this.list.isEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TransformingRandomAccessList<F, T> extends AbstractList<T>
/*     */     implements RandomAccess, Serializable
/*     */   {
/*     */     final List<F> fromList;
/*     */     final Function<? super F, ? extends T> function;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     TransformingRandomAccessList(List<F> fromList, Function<? super F, ? extends T> function)
/*     */     {
/* 489 */       this.fromList = ((List)Preconditions.checkNotNull(fromList));
/* 490 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*     */     }
/*     */     public void clear() {
/* 493 */       this.fromList.clear();
/*     */     }
/*     */     public T get(int index) {
/* 496 */       return this.function.apply(this.fromList.get(index));
/*     */     }
/*     */     public boolean isEmpty() {
/* 499 */       return this.fromList.isEmpty();
/*     */     }
/*     */     public T remove(int index) {
/* 502 */       return this.function.apply(this.fromList.remove(index));
/*     */     }
/*     */     public int size() {
/* 505 */       return this.fromList.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TransformingSequentialList<F, T> extends AbstractSequentialList<T>
/*     */     implements Serializable
/*     */   {
/*     */     final List<F> fromList;
/*     */     final Function<? super F, ? extends T> function;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     TransformingSequentialList(List<F> fromList, Function<? super F, ? extends T> function)
/*     */     {
/* 416 */       this.fromList = ((List)Preconditions.checkNotNull(fromList));
/* 417 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 425 */       this.fromList.clear();
/*     */     }
/*     */     public int size() {
/* 428 */       return this.fromList.size();
/*     */     }
/*     */     public ListIterator<T> listIterator(int index) {
/* 431 */       ListIterator delegate = this.fromList.listIterator(index);
/* 432 */       return new ListIterator(delegate) {
/*     */         public void add(T e) {
/* 434 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public boolean hasNext() {
/* 438 */           return this.val$delegate.hasNext();
/*     */         }
/*     */ 
/*     */         public boolean hasPrevious() {
/* 442 */           return this.val$delegate.hasPrevious();
/*     */         }
/*     */ 
/*     */         public T next() {
/* 446 */           return Lists.TransformingSequentialList.this.function.apply(this.val$delegate.next());
/*     */         }
/*     */ 
/*     */         public int nextIndex() {
/* 450 */           return this.val$delegate.nextIndex();
/*     */         }
/*     */ 
/*     */         public T previous() {
/* 454 */           return Lists.TransformingSequentialList.this.function.apply(this.val$delegate.previous());
/*     */         }
/*     */ 
/*     */         public int previousIndex() {
/* 458 */           return this.val$delegate.previousIndex();
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 462 */           this.val$delegate.remove();
/*     */         }
/*     */ 
/*     */         public void set(T e) {
/* 466 */           throw new UnsupportedOperationException("not supported");
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TwoPlusArrayList<E> extends AbstractList<E>
/*     */     implements Serializable, RandomAccess
/*     */   {
/*     */     final E first;
/*     */     final E second;
/*     */     final E[] rest;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     TwoPlusArrayList(@Nullable E first, @Nullable E second, E[] rest)
/*     */     {
/* 351 */       this.first = first;
/* 352 */       this.second = second;
/* 353 */       this.rest = ((Object[])Preconditions.checkNotNull(rest));
/*     */     }
/*     */     public int size() {
/* 356 */       return this.rest.length + 2;
/*     */     }
/*     */     public E get(int index) {
/* 359 */       switch (index) {
/*     */       case 0:
/* 361 */         return this.first;
/*     */       case 1:
/* 363 */         return this.second;
/*     */       }
/*     */ 
/* 366 */       Preconditions.checkElementIndex(index, size());
/* 367 */       return this.rest[(index - 2)];
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class OnePlusArrayList<E> extends AbstractList<E>
/*     */     implements Serializable, RandomAccess
/*     */   {
/*     */     final E first;
/*     */     final E[] rest;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     OnePlusArrayList(@Nullable E first, E[] rest)
/*     */     {
/* 307 */       this.first = first;
/* 308 */       this.rest = ((Object[])Preconditions.checkNotNull(rest));
/*     */     }
/*     */     public int size() {
/* 311 */       return this.rest.length + 1;
/*     */     }
/*     */ 
/*     */     public E get(int index) {
/* 315 */       Preconditions.checkElementIndex(index, size());
/* 316 */       return index == 0 ? this.first : this.rest[(index - 1)];
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Lists
 * JD-Core Version:    0.6.0
 */