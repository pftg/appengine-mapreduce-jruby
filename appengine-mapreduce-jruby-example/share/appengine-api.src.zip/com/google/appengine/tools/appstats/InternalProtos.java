/*     */ package com.google.appengine.tools.appstats;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.Descriptor;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.Builder;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet.Builder;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class InternalProtos
/*     */ {
/*     */   private static Descriptors.Descriptor internal_static_appstats_EmptyProto_descriptor;
/*     */   private static GeneratedMessage.FieldAccessorTable internal_static_appstats_EmptyProto_fieldAccessorTable;
/*     */   private static Descriptors.FileDescriptor descriptor;
/*     */ 
/*     */   public static void registerAllExtensions(ExtensionRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static Descriptors.FileDescriptor getDescriptor()
/*     */   {
/* 266 */     return descriptor;
/*     */   }
/*     */   public static void internalForceInit() {
/*     */   }
/*     */   static {
/* 271 */     String[] descriptorData = { "\n7java/com/google/appengine/tools/appstats/internal.proto\022\bappstats\"\f\n\nEmptyProtoB7\n#com.google.appengine.tools.appstatsB\016InternalProtosH\001" };
/*     */ 
/* 277 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*     */     {
/*     */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*     */       {
/* 281 */         InternalProtos.access$502(root);
/* 282 */         InternalProtos.access$002((Descriptors.Descriptor)InternalProtos.getDescriptor().getMessageTypes().get(0));
/*     */ 
/* 284 */         InternalProtos.access$102(new GeneratedMessage.FieldAccessorTable(InternalProtos.internal_static_appstats_EmptyProto_descriptor, new String[0], InternalProtos.EmptyProto.class, InternalProtos.EmptyProto.Builder.class));
/*     */ 
/* 290 */         return null;
/*     */       }
/*     */     };
/* 293 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/*     */   }
/*     */ 
/*     */   public static final class EmptyProto extends GeneratedMessage
/*     */   {
/* 250 */     private static final EmptyProto defaultInstance = new EmptyProto(true);
/*     */ 
/*  50 */     private int memoizedSerializedSize = -1;
/*     */ 
/*     */     private EmptyProto(Builder builder)
/*     */     {
/*  15 */       super();
/*     */     }
/*     */     private EmptyProto(boolean noInit) {
/*     */     }
/*     */ 
/*     */     public static EmptyProto getDefaultInstance() {
/*  21 */       return defaultInstance;
/*     */     }
/*     */ 
/*     */     public EmptyProto getDefaultInstanceForType() {
/*  25 */       return defaultInstance;
/*     */     }
/*     */ 
/*     */     public static final Descriptors.Descriptor getDescriptor()
/*     */     {
/*  30 */       return InternalProtos.internal_static_appstats_EmptyProto_descriptor;
/*     */     }
/*     */ 
/*     */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*     */     {
/*  35 */       return InternalProtos.internal_static_appstats_EmptyProto_fieldAccessorTable;
/*     */     }
/*     */     private void initFields() {
/*     */     }
/*     */ 
/*     */     public final boolean isInitialized() {
/*  41 */       return true;
/*     */     }
/*     */ 
/*     */     public void writeTo(CodedOutputStream output) throws IOException
/*     */     {
/*  46 */       getSerializedSize();
/*  47 */       getUnknownFields().writeTo(output);
/*     */     }
/*     */ 
/*     */     public int getSerializedSize()
/*     */     {
/*  52 */       int size = this.memoizedSerializedSize;
/*  53 */       if (size != -1) return size;
/*     */ 
/*  55 */       size = 0;
/*  56 */       size += getUnknownFields().getSerializedSize();
/*  57 */       this.memoizedSerializedSize = size;
/*  58 */       return size;
/*     */     }
/*     */ 
/*     */     protected Object writeReplace() throws ObjectStreamException
/*     */     {
/*  63 */       return super.writeReplace();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(ByteString data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*  69 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*  75 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*     */     {
/*  80 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*  86 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(InputStream input) throws IOException
/*     */     {
/*  91 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/*  97 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseDelimitedFrom(InputStream input) throws IOException
/*     */     {
/* 102 */       Builder builder = newBuilder();
/* 103 */       if (builder.mergeDelimitedFrom(input)) {
/* 104 */         return builder.buildParsed();
/*     */       }
/* 106 */       return null;
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 113 */       Builder builder = newBuilder();
/* 114 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 115 */         return builder.buildParsed();
/*     */       }
/* 117 */       return null;
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(CodedInputStream input)
/*     */       throws IOException
/*     */     {
/* 123 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*     */     }
/*     */ 
/*     */     public static EmptyProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 129 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*     */     }
/*     */ 
/*     */     public static Builder newBuilder() {
/* 133 */       return Builder.access$300(); } 
/* 134 */     public Builder newBuilderForType() { return newBuilder(); } 
/*     */     public static Builder newBuilder(EmptyProto prototype) {
/* 136 */       return newBuilder().mergeFrom(prototype);
/*     */     }
/* 138 */     public Builder toBuilder() { return newBuilder(this);
/*     */     }
/*     */ 
/*     */     static
/*     */     {
/* 251 */       InternalProtos.internalForceInit();
/* 252 */       defaultInstance.initFields();
/*     */     }
/*     */ 
/*     */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*     */     {
/*     */       public static final Descriptors.Descriptor getDescriptor()
/*     */       {
/* 144 */         return InternalProtos.internal_static_appstats_EmptyProto_descriptor;
/*     */       }
/*     */ 
/*     */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*     */       {
/* 149 */         return InternalProtos.internal_static_appstats_EmptyProto_fieldAccessorTable;
/*     */       }
/*     */ 
/*     */       private static Builder create()
/*     */       {
/* 157 */         return new Builder();
/*     */       }
/*     */ 
/*     */       public Builder clear() {
/* 161 */         super.clear();
/* 162 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder clone() {
/* 166 */         return create().mergeFrom(buildPartial());
/*     */       }
/*     */ 
/*     */       public Descriptors.Descriptor getDescriptorForType()
/*     */       {
/* 171 */         return InternalProtos.EmptyProto.getDescriptor();
/*     */       }
/*     */ 
/*     */       public InternalProtos.EmptyProto getDefaultInstanceForType() {
/* 175 */         return InternalProtos.EmptyProto.getDefaultInstance();
/*     */       }
/*     */ 
/*     */       public InternalProtos.EmptyProto build() {
/* 179 */         InternalProtos.EmptyProto result = buildPartial();
/* 180 */         if (!result.isInitialized()) {
/* 181 */           throw newUninitializedMessageException(result);
/*     */         }
/* 183 */         return result;
/*     */       }
/*     */ 
/*     */       private InternalProtos.EmptyProto buildParsed() throws InvalidProtocolBufferException
/*     */       {
/* 188 */         InternalProtos.EmptyProto result = buildPartial();
/* 189 */         if (!result.isInitialized()) {
/* 190 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*     */         }
/*     */ 
/* 193 */         return result;
/*     */       }
/*     */ 
/*     */       public InternalProtos.EmptyProto buildPartial() {
/* 197 */         InternalProtos.EmptyProto result = new InternalProtos.EmptyProto(this, null);
/* 198 */         return result;
/*     */       }
/*     */ 
/*     */       public Builder mergeFrom(Message other) {
/* 202 */         if ((other instanceof InternalProtos.EmptyProto)) {
/* 203 */           return mergeFrom((InternalProtos.EmptyProto)other);
/*     */         }
/* 205 */         super.mergeFrom(other);
/* 206 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder mergeFrom(InternalProtos.EmptyProto other)
/*     */       {
/* 211 */         if (other == InternalProtos.EmptyProto.getDefaultInstance()) return this;
/* 212 */         mergeUnknownFields(other.getUnknownFields());
/* 213 */         return this;
/*     */       }
/*     */ 
/*     */       public final boolean isInitialized() {
/* 217 */         return true;
/*     */       }
/*     */ 
/*     */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*     */         throws IOException
/*     */       {
/* 224 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*     */         while (true)
/*     */         {
/* 228 */           int tag = input.readTag();
/* 229 */           switch (tag) {
/*     */           case 0:
/* 231 */             setUnknownFields(unknownFields.build());
/* 232 */             return this;
/*     */           }
/* 234 */           if (!parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*     */           {
/* 236 */             setUnknownFields(unknownFields.build());
/* 237 */             return this;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.tools.appstats.InternalProtos
 * JD-Core Version:    0.6.0
 */