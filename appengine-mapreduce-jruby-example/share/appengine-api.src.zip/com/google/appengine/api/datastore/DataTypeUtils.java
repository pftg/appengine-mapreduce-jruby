/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.appengine.api.blobstore.BlobKey;
/*     */ import com.google.appengine.api.users.User;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public final class DataTypeUtils
/*     */ {
/*  52 */   private static final Logger logger = Logger.getLogger(DataTypeUtils.class.getName());
/*     */   public static final int MAX_STRING_PROPERTY_LENGTH = 500;
/*     */   public static final int MAX_SHORT_BLOB_PROPERTY_LENGTH = 500;
/*     */   public static final int MAX_LINK_PROPERTY_LENGTH = 2038;
/*  71 */   private static final Set<Class<?>> supportedTypes = new HashSet();
/*     */ 
/*     */   public static void checkSupportedValue(Object value)
/*     */   {
/* 110 */     checkSupportedValue(null, value);
/*     */   }
/*     */ 
/*     */   public static void checkSupportedValue(String name, Object value)
/*     */   {
/* 123 */     checkSupportedValue(name, value, true, false);
/*     */   }
/*     */ 
/*     */   static void checkSupportedValue(String name, Object value, boolean allowMultiValue, boolean requireMultiValue)
/*     */   {
/* 141 */     if ((value instanceof Collection)) {
/* 142 */       if (!allowMultiValue) {
/* 143 */         throw new IllegalArgumentException("A collection of values is not allowed.");
/*     */       }
/*     */ 
/* 146 */       Collection values = (Collection)value;
/*     */       Iterator i$;
/* 147 */       if (!values.isEmpty())
/* 148 */         for (i$ = values.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 149 */           checkSupportedSingleValue(name, obj);
/*     */         }
/* 151 */       else if (requireMultiValue)
/* 152 */         throw new IllegalArgumentException("A colleciton with at least one value is required.");
/*     */     } else {
/* 154 */       if (requireMultiValue) {
/* 155 */         throw new IllegalArgumentException("A collection of values is required.");
/*     */       }
/* 157 */       checkSupportedSingleValue(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void checkSupportedSingleValue(String name, Object value)
/*     */   {
/* 164 */     if (value == null) {
/* 165 */       return;
/*     */     }
/*     */ 
/* 169 */     if (("__key__".equals(name)) && 
/* 170 */       (!(value instanceof Key)))
/*     */     {
/* 172 */       logger.warning("__key__ value should be of type Key");
/*     */     }
/*     */     String prefix;
/*     */     String prefix;
/* 177 */     if (name == null)
/* 178 */       prefix = "";
/*     */     else {
/* 180 */       prefix = name + ": ";
/*     */     }
/*     */ 
/* 183 */     if (!isSupportedType(value.getClass())) {
/* 184 */       throw new IllegalArgumentException(prefix + value.getClass().getName() + " is not a supported property type.");
/*     */     }
/*     */ 
/* 189 */     if ((value instanceof String)) {
/* 190 */       int length = ((String)value).length();
/* 191 */       if (length > 500) {
/* 192 */         throw new IllegalArgumentException(prefix + "String properties must be " + 500 + " characters or less.  Instead, use " + Text.class.getName() + ", which can store " + "strings of any length.");
/*     */       }
/*     */ 
/*     */     }
/* 197 */     else if ((value instanceof Link)) {
/* 198 */       int length = ((Link)value).getValue().length();
/* 199 */       if (length > 2038) {
/* 200 */         throw new IllegalArgumentException(prefix + "Link properties must be " + 2038 + " characters or less.  Instead, use " + Text.class.getName() + ", which can store " + "strings of any length.");
/*     */       }
/*     */ 
/*     */     }
/* 205 */     else if ((value instanceof ShortBlob)) {
/* 206 */       int length = ((ShortBlob)value).getBytes().length;
/* 207 */       if (length > 500)
/* 208 */         throw new IllegalArgumentException(prefix + "byte[] properties must be " + 500 + " bytes or less.  Instead, use " + Blob.class.getName() + ", which can store binary " + "data of any size.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isSupportedType(Class<?> clazz)
/*     */   {
/* 221 */     return supportedTypes.contains(clazz);
/*     */   }
/*     */ 
/*     */   public static Set<Class<?>> getSupportedTypes()
/*     */   {
/* 229 */     return Collections.unmodifiableSet(supportedTypes);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  75 */     supportedTypes.add(Boolean.class);
/*  76 */     supportedTypes.add(String.class);
/*  77 */     supportedTypes.add(Byte.class);
/*  78 */     supportedTypes.add(Short.class);
/*  79 */     supportedTypes.add(Integer.class);
/*  80 */     supportedTypes.add(Long.class);
/*  81 */     supportedTypes.add(Float.class);
/*  82 */     supportedTypes.add(Double.class);
/*  83 */     supportedTypes.add(User.class);
/*  84 */     supportedTypes.add(Key.class);
/*  85 */     supportedTypes.add(Blob.class);
/*  86 */     supportedTypes.add(Text.class);
/*  87 */     supportedTypes.add(Date.class);
/*  88 */     supportedTypes.add(Link.class);
/*  89 */     supportedTypes.add(ShortBlob.class);
/*  90 */     supportedTypes.add(GeoPt.class);
/*  91 */     supportedTypes.add(Category.class);
/*  92 */     supportedTypes.add(Rating.class);
/*  93 */     supportedTypes.add(PhoneNumber.class);
/*  94 */     supportedTypes.add(PostalAddress.class);
/*  95 */     supportedTypes.add(Email.class);
/*  96 */     supportedTypes.add(IMHandle.class);
/*  97 */     supportedTypes.add(BlobKey.class);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DataTypeUtils
 * JD-Core Version:    0.6.0
 */