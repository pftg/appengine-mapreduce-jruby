/*    */ package com.google.appengine.repackaged.com.google.common.util;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ 
/*    */ @GwtCompatible
/*    */ public class Base64DecoderException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Base64DecoderException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Base64DecoderException(String s)
/*    */   {
/* 31 */     super(s);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.util.Base64DecoderException
 * JD-Core Version:    0.6.0
 */