/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public abstract class AbstractMessage extends AbstractMessageLite
/*     */   implements Message
/*     */ {
/*     */   private int memoizedSize;
/*     */ 
/*     */   public AbstractMessage()
/*     */   {
/*  85 */     this.memoizedSize = -1;
/*     */   }
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/*  25 */     for (Descriptors.FieldDescriptor field : getDescriptorForType().getFields()) {
/*  26 */       if ((field.isRequired()) && 
/*  27 */         (!hasField(field))) {
/*  28 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  35 */     for (Map.Entry entry : getAllFields().entrySet()) {
/*  36 */       Descriptors.FieldDescriptor field = (Descriptors.FieldDescriptor)entry.getKey();
/*  37 */       if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/*  38 */         if (field.isRepeated()) {
/*  39 */           for (Message element : (List)entry.getValue()) {
/*  40 */             if (!element.isInitialized()) {
/*  41 */               return false;
/*     */             }
/*     */           }
/*     */         }
/*  45 */         else if (!((Message)entry.getValue()).isInitialized()) {
/*  46 */           return false;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  52 */     return true;
/*     */   }
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  57 */     return TextFormat.printToString(this);
/*     */   }
/*     */ 
/*     */   public void writeTo(CodedOutputStream output) throws IOException {
/*  61 */     boolean isMessageSet = getDescriptorForType().getOptions().getMessageSetWireFormat();
/*     */ 
/*  65 */     for (Map.Entry entry : getAllFields().entrySet()) {
/*  66 */       Descriptors.FieldDescriptor field = (Descriptors.FieldDescriptor)entry.getKey();
/*  67 */       Object value = entry.getValue();
/*  68 */       if ((isMessageSet) && (field.isExtension()) && (field.getType() == Descriptors.FieldDescriptor.Type.MESSAGE) && (!field.isRepeated()))
/*     */       {
/*  71 */         output.writeMessageSetExtension(field.getNumber(), (Message)value);
/*     */       }
/*  73 */       else FieldSet.writeField(field, value, output);
/*     */ 
/*     */     }
/*     */ 
/*  77 */     UnknownFieldSet unknownFields = getUnknownFields();
/*  78 */     if (isMessageSet)
/*  79 */       unknownFields.writeAsMessageSetTo(output);
/*     */     else
/*  81 */       unknownFields.writeTo(output);
/*     */   }
/*     */ 
/*     */   public int getSerializedSize()
/*     */   {
/*  88 */     int size = this.memoizedSize;
/*  89 */     if (size != -1) {
/*  90 */       return size;
/*     */     }
/*     */ 
/*  93 */     size = 0;
/*  94 */     boolean isMessageSet = getDescriptorForType().getOptions().getMessageSetWireFormat();
/*     */ 
/*  98 */     for (Map.Entry entry : getAllFields().entrySet()) {
/*  99 */       Descriptors.FieldDescriptor field = (Descriptors.FieldDescriptor)entry.getKey();
/* 100 */       Object value = entry.getValue();
/* 101 */       if ((isMessageSet) && (field.isExtension()) && (field.getType() == Descriptors.FieldDescriptor.Type.MESSAGE) && (!field.isRepeated()))
/*     */       {
/* 104 */         size += CodedOutputStream.computeMessageSetExtensionSize(field.getNumber(), (Message)value);
/*     */       }
/*     */       else {
/* 107 */         size += FieldSet.computeFieldSize(field, value);
/*     */       }
/*     */     }
/*     */ 
/* 111 */     UnknownFieldSet unknownFields = getUnknownFields();
/* 112 */     if (isMessageSet)
/* 113 */       size += unknownFields.getSerializedSizeAsMessageSet();
/*     */     else {
/* 115 */       size += unknownFields.getSerializedSize();
/*     */     }
/*     */ 
/* 118 */     this.memoizedSize = size;
/* 119 */     return size;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 124 */     if (other == this) {
/* 125 */       return true;
/*     */     }
/* 127 */     if (!(other instanceof Message)) {
/* 128 */       return false;
/*     */     }
/* 130 */     Message otherMessage = (Message)other;
/* 131 */     if (getDescriptorForType() != otherMessage.getDescriptorForType()) {
/* 132 */       return false;
/*     */     }
/* 134 */     return (getAllFields().equals(otherMessage.getAllFields())) && (getUnknownFields().equals(otherMessage.getUnknownFields()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 140 */     int hash = 41;
/* 141 */     hash = 19 * hash + getDescriptorForType().hashCode();
/* 142 */     hash = 53 * hash + getAllFields().hashCode();
/* 143 */     hash = 29 * hash + getUnknownFields().hashCode();
/* 144 */     return hash;
/*     */   }
/*     */ 
/*     */   public static abstract class Builder<BuilderType extends Builder> extends AbstractMessageLite.Builder<BuilderType>
/*     */     implements Message.Builder
/*     */   {
/*     */     public abstract BuilderType clone();
/*     */ 
/*     */     public BuilderType clear()
/*     */     {
/* 164 */       for (Map.Entry entry : getAllFields().entrySet()) {
/* 165 */         clearField((Descriptors.FieldDescriptor)entry.getKey());
/*     */       }
/* 167 */       return this;
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(Message other) {
/* 171 */       if (other.getDescriptorForType() != getDescriptorForType()) {
/* 172 */         throw new IllegalArgumentException("mergeFrom(Message) can only merge messages of the same type.");
/*     */       }
/*     */ 
/* 186 */       for (Map.Entry entry : other.getAllFields().entrySet()) {
/* 187 */         Descriptors.FieldDescriptor field = (Descriptors.FieldDescriptor)entry.getKey();
/*     */         Iterator i$;
/* 188 */         if (field.isRepeated()) {
/* 189 */           for (i$ = ((List)entry.getValue()).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 190 */             addRepeatedField(field, element); }
/*     */         }
/* 192 */         else if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 193 */           Message existingValue = (Message)getField(field);
/* 194 */           if (existingValue == existingValue.getDefaultInstanceForType())
/* 195 */             setField(field, entry.getValue());
/*     */           else {
/* 197 */             setField(field, existingValue.newBuilderForType().mergeFrom(existingValue).mergeFrom((Message)entry.getValue()).build());
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 204 */           setField(field, entry.getValue());
/*     */         }
/*     */       }
/*     */ 
/* 208 */       mergeUnknownFields(other.getUnknownFields());
/*     */ 
/* 210 */       return this;
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(CodedInputStream input)
/*     */       throws IOException
/*     */     {
/* 216 */       return mergeFrom(input, ExtensionRegistry.getEmptyRegistry());
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 224 */       UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*     */       while (true)
/*     */       {
/* 227 */         int tag = input.readTag();
/* 228 */         if (tag == 0)
/*     */         {
/*     */           break;
/*     */         }
/* 232 */         if (!mergeFieldFrom(input, unknownFields, extensionRegistry, this, tag))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/* 238 */       setUnknownFields(unknownFields.build());
/* 239 */       return this;
/*     */     }
/*     */ 
/*     */     static boolean mergeFieldFrom(CodedInputStream input, UnknownFieldSet.Builder unknownFields, ExtensionRegistryLite extensionRegistry, Message.Builder builder, int tag)
/*     */       throws IOException
/*     */     {
/* 256 */       Descriptors.Descriptor type = builder.getDescriptorForType();
/*     */ 
/* 258 */       if ((type.getOptions().getMessageSetWireFormat()) && (tag == WireFormat.MESSAGE_SET_ITEM_TAG))
/*     */       {
/* 260 */         mergeMessageSetExtensionFromCodedStream(input, unknownFields, extensionRegistry, builder);
/*     */ 
/* 262 */         return true;
/*     */       }
/*     */ 
/* 265 */       int wireType = WireFormat.getTagWireType(tag);
/* 266 */       int fieldNumber = WireFormat.getTagFieldNumber(tag);
/*     */ 
/* 269 */       Message defaultInstance = null;
/*     */       Descriptors.FieldDescriptor field;
/*     */       Descriptors.FieldDescriptor field;
/* 271 */       if (type.isExtensionNumber(fieldNumber))
/*     */       {
/* 277 */         if ((extensionRegistry instanceof ExtensionRegistry)) {
/* 278 */           ExtensionRegistry.ExtensionInfo extension = ((ExtensionRegistry)extensionRegistry).findExtensionByNumber(type, fieldNumber);
/*     */           Descriptors.FieldDescriptor field;
/* 281 */           if (extension == null) {
/* 282 */             field = null;
/*     */           } else {
/* 284 */             Descriptors.FieldDescriptor field = extension.descriptor;
/* 285 */             defaultInstance = extension.defaultInstance;
/* 286 */             if ((defaultInstance == null) && (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE))
/*     */             {
/* 288 */               throw new IllegalStateException("Message-typed extension lacked default instance: " + field.getFullName());
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 294 */           field = null;
/*     */         }
/*     */       }
/* 297 */       else field = type.findFieldByNumber(fieldNumber);
/*     */ 
/* 300 */       boolean unknown = false;
/* 301 */       boolean packed = false;
/* 302 */       if (field == null)
/* 303 */         unknown = true;
/* 304 */       else if (wireType == FieldSet.getWireFormatForFieldType(field.getLiteType(), false))
/*     */       {
/* 307 */         packed = false;
/* 308 */       } else if ((field.isPackable()) && (wireType == FieldSet.getWireFormatForFieldType(field.getLiteType(), true)))
/*     */       {
/* 312 */         packed = true;
/*     */       }
/* 314 */       else unknown = true;
/*     */ 
/* 317 */       if (unknown) {
/* 318 */         return unknownFields.mergeFieldFrom(tag, input);
/*     */       }
/*     */ 
/* 321 */       if (packed) {
/* 322 */         int length = input.readRawVarint32();
/* 323 */         int limit = input.pushLimit(length);
/* 324 */         if (field.getLiteType() == WireFormat.FieldType.ENUM) {
/* 325 */           while (input.getBytesUntilLimit() > 0) {
/* 326 */             int rawValue = input.readEnum();
/* 327 */             Object value = field.getEnumType().findValueByNumber(rawValue);
/* 328 */             if (value == null)
/*     */             {
/* 331 */               return true;
/*     */             }
/* 333 */             builder.addRepeatedField(field, value);
/*     */           }
/*     */         }
/* 336 */         while (input.getBytesUntilLimit() > 0) {
/* 337 */           Object value = FieldSet.readPrimitiveField(input, field.getLiteType());
/*     */ 
/* 339 */           builder.addRepeatedField(field, value);
/*     */         }
/*     */ 
/* 342 */         input.popLimit(limit);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object value;
/* 345 */         switch (AbstractMessage.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$Type[field.getType().ordinal()])
/*     */         {
/*     */         case 1:
/*     */           Message.Builder subBuilder;
/*     */           Message.Builder subBuilder;
/* 348 */           if (defaultInstance != null)
/* 349 */             subBuilder = defaultInstance.newBuilderForType();
/*     */           else {
/* 351 */             subBuilder = builder.newBuilderForField(field);
/*     */           }
/* 353 */           if (!field.isRepeated()) {
/* 354 */             subBuilder.mergeFrom((Message)builder.getField(field));
/*     */           }
/* 356 */           input.readGroup(field.getNumber(), subBuilder, extensionRegistry);
/* 357 */           value = subBuilder.build();
/* 358 */           break;
/*     */         case 2:
/*     */           Message.Builder subBuilder;
/*     */           Message.Builder subBuilder;
/* 362 */           if (defaultInstance != null)
/* 363 */             subBuilder = defaultInstance.newBuilderForType();
/*     */           else {
/* 365 */             subBuilder = builder.newBuilderForField(field);
/*     */           }
/* 367 */           if (!field.isRepeated()) {
/* 368 */             subBuilder.mergeFrom((Message)builder.getField(field));
/*     */           }
/* 370 */           input.readMessage(subBuilder, extensionRegistry);
/* 371 */           value = subBuilder.build();
/* 372 */           break;
/*     */         case 3:
/* 375 */           int rawValue = input.readEnum();
/* 376 */           value = field.getEnumType().findValueByNumber(rawValue);
/*     */ 
/* 379 */           if (value != null) break;
/* 380 */           unknownFields.mergeVarintField(fieldNumber, rawValue);
/* 381 */           return true;
/*     */         default:
/* 385 */           value = FieldSet.readPrimitiveField(input, field.getLiteType());
/*     */         }
/*     */ 
/* 389 */         if (field.isRepeated())
/* 390 */           builder.addRepeatedField(field, value);
/*     */         else {
/* 392 */           builder.setField(field, value);
/*     */         }
/*     */       }
/*     */ 
/* 396 */       return true;
/*     */     }
/*     */ 
/*     */     private static void mergeMessageSetExtensionFromCodedStream(CodedInputStream input, UnknownFieldSet.Builder unknownFields, ExtensionRegistryLite extensionRegistry, Message.Builder builder)
/*     */       throws IOException
/*     */     {
/* 405 */       Descriptors.Descriptor type = builder.getDescriptorForType();
/*     */ 
/* 423 */       int typeId = 0;
/* 424 */       ByteString rawBytes = null;
/* 425 */       Message.Builder subBuilder = null;
/* 426 */       Descriptors.FieldDescriptor field = null;
/*     */       while (true)
/*     */       {
/* 429 */         int tag = input.readTag();
/* 430 */         if (tag == 0)
/*     */         {
/*     */           break;
/*     */         }
/* 434 */         if (tag == WireFormat.MESSAGE_SET_TYPE_ID_TAG) {
/* 435 */           typeId = input.readUInt32();
/*     */ 
/* 437 */           if (typeId != 0)
/*     */           {
/*     */             ExtensionRegistry.ExtensionInfo extension;
/*     */             ExtensionRegistry.ExtensionInfo extension;
/* 445 */             if ((extensionRegistry instanceof ExtensionRegistry)) {
/* 446 */               extension = ((ExtensionRegistry)extensionRegistry).findExtensionByNumber(type, typeId);
/*     */             }
/*     */             else {
/* 449 */               extension = null;
/*     */             }
/*     */ 
/* 452 */             if (extension != null) {
/* 453 */               field = extension.descriptor;
/* 454 */               subBuilder = extension.defaultInstance.newBuilderForType();
/* 455 */               Message originalMessage = (Message)builder.getField(field);
/* 456 */               if (originalMessage != null) {
/* 457 */                 subBuilder.mergeFrom(originalMessage);
/*     */               }
/* 459 */               if (rawBytes != null)
/*     */               {
/* 461 */                 subBuilder.mergeFrom(CodedInputStream.newInstance(rawBytes.newInput()));
/*     */ 
/* 463 */                 rawBytes = null;
/*     */               }
/*     */ 
/*     */             }
/* 468 */             else if (rawBytes != null) {
/* 469 */               unknownFields.mergeField(typeId, UnknownFieldSet.Field.newBuilder().addLengthDelimited(rawBytes).build());
/*     */ 
/* 473 */               rawBytes = null;
/*     */             }
/*     */           }
/*     */         }
/* 477 */         else if (tag == WireFormat.MESSAGE_SET_MESSAGE_TAG) {
/* 478 */           if (typeId == 0)
/*     */           {
/* 481 */             rawBytes = input.readBytes();
/* 482 */           } else if (subBuilder == null)
/*     */           {
/* 484 */             unknownFields.mergeField(typeId, UnknownFieldSet.Field.newBuilder().addLengthDelimited(input.readBytes()).build());
/*     */           }
/*     */           else
/*     */           {
/* 491 */             input.readMessage(subBuilder, extensionRegistry);
/*     */           }
/*     */         }
/*     */         else {
/* 495 */           if (!input.skipField(tag))
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 501 */       input.checkLastTagWas(WireFormat.MESSAGE_SET_ITEM_END_TAG);
/*     */ 
/* 503 */       if (subBuilder != null)
/* 504 */         builder.setField(field, subBuilder.build());
/*     */     }
/*     */ 
/*     */     public BuilderType mergeUnknownFields(UnknownFieldSet unknownFields)
/*     */     {
/* 509 */       setUnknownFields(UnknownFieldSet.newBuilder(getUnknownFields()).mergeFrom(unknownFields).build());
/*     */ 
/* 513 */       return this;
/*     */     }
/*     */ 
/*     */     protected static UninitializedMessageException newUninitializedMessageException(Message message)
/*     */     {
/* 522 */       return new UninitializedMessageException(findMissingFields(message));
/*     */     }
/*     */ 
/*     */     private static List<String> findMissingFields(Message message)
/*     */     {
/* 530 */       List results = new ArrayList();
/* 531 */       findMissingFields(message, "", results);
/* 532 */       return results;
/*     */     }
/*     */ 
/*     */     private static void findMissingFields(Message message, String prefix, List<String> results)
/*     */     {
/* 540 */       for (Descriptors.FieldDescriptor field : message.getDescriptorForType().getFields()) {
/* 541 */         if ((field.isRequired()) && (!message.hasField(field))) {
/* 542 */           results.add(prefix + field.getName());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 547 */       for (Map.Entry entry : message.getAllFields().entrySet()) {
/* 548 */         Descriptors.FieldDescriptor field = (Descriptors.FieldDescriptor)entry.getKey();
/* 549 */         Object value = entry.getValue();
/*     */ 
/* 551 */         if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/*     */         {
/*     */           int i;
/*     */           Iterator i$;
/* 552 */           if (field.isRepeated()) {
/* 553 */             i = 0;
/* 554 */             for (i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 555 */               findMissingFields((Message)element, subMessagePrefix(prefix, field, i++), results);
/*     */             }
/*     */ 
/*     */           }
/* 560 */           else if (message.hasField(field)) {
/* 561 */             findMissingFields((Message)value, subMessagePrefix(prefix, field, -1), results);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private static String subMessagePrefix(String prefix, Descriptors.FieldDescriptor field, int index)
/*     */     {
/* 573 */       StringBuilder result = new StringBuilder(prefix);
/* 574 */       if (field.isExtension()) {
/* 575 */         result.append('(').append(field.getFullName()).append(')');
/*     */       }
/*     */       else
/*     */       {
/* 579 */         result.append(field.getName());
/*     */       }
/* 581 */       if (index != -1) {
/* 582 */         result.append('[').append(index).append(']');
/*     */       }
/*     */ 
/* 586 */       result.append('.');
/* 587 */       return result.toString();
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(ByteString data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 612 */       return (Builder)super.mergeFrom(data);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 620 */       return (Builder)super.mergeFrom(data, extensionRegistry);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 626 */       return (Builder)super.mergeFrom(data);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data, int off, int len)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 633 */       return (Builder)super.mergeFrom(data, off, len);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 641 */       return (Builder)super.mergeFrom(data, extensionRegistry);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data, int off, int len, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 649 */       return (Builder)super.mergeFrom(data, off, len, extensionRegistry);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(InputStream input)
/*     */       throws IOException
/*     */     {
/* 655 */       return (Builder)super.mergeFrom(input);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 663 */       return (Builder)super.mergeFrom(input, extensionRegistry);
/*     */     }
/*     */ 
/*     */     public boolean mergeDelimitedFrom(InputStream input)
/*     */       throws IOException
/*     */     {
/* 669 */       return super.mergeDelimitedFrom(input);
/*     */     }
/*     */ 
/*     */     public boolean mergeDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 677 */       return super.mergeDelimitedFrom(input, extensionRegistry);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.AbstractMessage
 * JD-Core Version:    0.6.0
 */