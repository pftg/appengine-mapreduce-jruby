/*      */ package com.google.appengine.repackaged.com.google.protobuf;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public final class Descriptors
/*      */ {
/*      */   private static String computeFullName(FileDescriptor file, Descriptor parent, String name)
/*      */   {
/* 1469 */     if (parent != null)
/* 1470 */       return parent.getFullName() + '.' + name;
/* 1471 */     if (file.getPackage().length() > 0) {
/* 1472 */       return file.getPackage() + '.' + name;
/*      */     }
/* 1474 */     return name;
/*      */   }
/*      */ 
/*      */   private static final class DescriptorPool
/*      */   {
/*      */     private final DescriptorPool[] dependencies;
/* 1578 */     private final Map<String, Descriptors.GenericDescriptor> descriptorsByName = new HashMap();
/*      */ 
/* 1580 */     private final Map<DescriptorIntPair, Descriptors.FieldDescriptor> fieldsByNumber = new HashMap();
/*      */ 
/* 1582 */     private final Map<DescriptorIntPair, Descriptors.EnumValueDescriptor> enumValuesByNumber = new HashMap();
/*      */ 
/*      */     DescriptorPool(Descriptors.FileDescriptor[] dependencies)
/*      */     {
/* 1558 */       this.dependencies = new DescriptorPool[dependencies.length];
/*      */ 
/* 1560 */       for (int i = 0; i < dependencies.length; i++) {
/* 1561 */         this.dependencies[i] = Descriptors.FileDescriptor.access$1200(dependencies[i]);
/*      */       }
/*      */ 
/* 1564 */       for (Descriptors.FileDescriptor dependency : dependencies)
/*      */         try {
/* 1566 */           addPackage(dependency.getPackage(), dependency);
/*      */         }
/*      */         catch (Descriptors.DescriptorValidationException e)
/*      */         {
/* 1571 */           if ($assertionsDisabled) continue; throw new AssertionError();
/*      */         }
/*      */     }
/*      */ 
/*      */     Descriptors.GenericDescriptor findSymbol(String fullName)
/*      */     {
/* 1587 */       Descriptors.GenericDescriptor result = (Descriptors.GenericDescriptor)this.descriptorsByName.get(fullName);
/* 1588 */       if (result != null) {
/* 1589 */         return result;
/*      */       }
/*      */ 
/* 1592 */       for (DescriptorPool dependency : this.dependencies) {
/* 1593 */         result = (Descriptors.GenericDescriptor)dependency.descriptorsByName.get(fullName);
/* 1594 */         if (result != null) {
/* 1595 */           return result;
/*      */         }
/*      */       }
/*      */ 
/* 1599 */       return null;
/*      */     }
/*      */ 
/*      */     Descriptors.GenericDescriptor lookupSymbol(String name, Descriptors.GenericDescriptor relativeTo)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/*      */       Descriptors.GenericDescriptor result;
/*      */       Descriptors.GenericDescriptor result;
/* 1614 */       if (name.startsWith("."))
/*      */       {
/* 1616 */         result = findSymbol(name.substring(1));
/*      */       }
/*      */       else
/*      */       {
/* 1620 */         int firstPartLength = name.indexOf('.');
/*      */         String firstPart;
/*      */         String firstPart;
/* 1622 */         if (firstPartLength == -1)
/* 1623 */           firstPart = name;
/*      */         else {
/* 1625 */           firstPart = name.substring(0, firstPartLength);
/*      */         }
/*      */ 
/* 1630 */         StringBuilder scopeToTry = new StringBuilder(relativeTo.getFullName());
/*      */         while (true)
/*      */         {
/* 1635 */           int dotpos = scopeToTry.lastIndexOf(".");
/* 1636 */           if (dotpos == -1) {
/* 1637 */             Descriptors.GenericDescriptor result = findSymbol(name);
/* 1638 */             break;
/*      */           }
/* 1640 */           scopeToTry.setLength(dotpos + 1);
/*      */ 
/* 1643 */           scopeToTry.append(firstPart);
/* 1644 */           result = findSymbol(scopeToTry.toString());
/*      */ 
/* 1646 */           if (result != null) {
/* 1647 */             if (firstPartLength == -1)
/*      */             {
/*      */               break;
/*      */             }
/* 1651 */             scopeToTry.setLength(dotpos + 1);
/* 1652 */             scopeToTry.append(name);
/* 1653 */             result = findSymbol(scopeToTry.toString()); break;
/*      */           }
/*      */ 
/* 1659 */           scopeToTry.setLength(dotpos);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1664 */       if (result == null) {
/* 1665 */         throw new Descriptors.DescriptorValidationException(relativeTo, '"' + name + "\" is not defined.", null);
/*      */       }
/*      */ 
/* 1668 */       return result;
/*      */     }
/*      */ 
/*      */     void addSymbol(Descriptors.GenericDescriptor descriptor)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1678 */       validateSymbolName(descriptor);
/*      */ 
/* 1680 */       String fullName = descriptor.getFullName();
/* 1681 */       int dotpos = fullName.lastIndexOf('.');
/*      */ 
/* 1683 */       Descriptors.GenericDescriptor old = (Descriptors.GenericDescriptor)this.descriptorsByName.put(fullName, descriptor);
/* 1684 */       if (old != null) {
/* 1685 */         this.descriptorsByName.put(fullName, old);
/*      */ 
/* 1687 */         if (descriptor.getFile() == old.getFile()) {
/* 1688 */           if (dotpos == -1) {
/* 1689 */             throw new Descriptors.DescriptorValidationException(descriptor, '"' + fullName + "\" is already defined.", null);
/*      */           }
/*      */ 
/* 1692 */           throw new Descriptors.DescriptorValidationException(descriptor, '"' + fullName.substring(dotpos + 1) + "\" is already defined in \"" + fullName.substring(0, dotpos) + "\".", null);
/*      */         }
/*      */ 
/* 1698 */         throw new Descriptors.DescriptorValidationException(descriptor, '"' + fullName + "\" is already defined in file \"" + old.getFile().getName() + "\".", null);
/*      */       }
/*      */     }
/*      */ 
/*      */     void addPackage(String fullName, Descriptors.FileDescriptor file)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1736 */       int dotpos = fullName.lastIndexOf('.');
/*      */       String name;
/*      */       String name;
/* 1738 */       if (dotpos == -1) {
/* 1739 */         name = fullName;
/*      */       } else {
/* 1741 */         addPackage(fullName.substring(0, dotpos), file);
/* 1742 */         name = fullName.substring(dotpos + 1);
/*      */       }
/*      */ 
/* 1745 */       Descriptors.GenericDescriptor old = (Descriptors.GenericDescriptor)this.descriptorsByName.put(fullName, new PackageDescriptor(name, fullName, file));
/*      */ 
/* 1748 */       if (old != null) {
/* 1749 */         this.descriptorsByName.put(fullName, old);
/* 1750 */         if (!(old instanceof PackageDescriptor))
/* 1751 */           throw new Descriptors.DescriptorValidationException(file, '"' + name + "\" is already defined (as something other than a " + "package) in file \"" + old.getFile().getName() + "\".", null);
/*      */       }
/*      */     }
/*      */ 
/*      */     void addFieldByNumber(Descriptors.FieldDescriptor field)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1788 */       DescriptorIntPair key = new DescriptorIntPair(field.getContainingType(), field.getNumber());
/*      */ 
/* 1790 */       Descriptors.FieldDescriptor old = (Descriptors.FieldDescriptor)this.fieldsByNumber.put(key, field);
/* 1791 */       if (old != null) {
/* 1792 */         this.fieldsByNumber.put(key, old);
/* 1793 */         throw new Descriptors.DescriptorValidationException(field, "Field number " + field.getNumber() + "has already been used in \"" + field.getContainingType().getFullName() + "\" by field \"" + old.getName() + "\".", null);
/*      */       }
/*      */     }
/*      */ 
/*      */     void addEnumValueByNumber(Descriptors.EnumValueDescriptor value)
/*      */     {
/* 1807 */       DescriptorIntPair key = new DescriptorIntPair(value.getType(), value.getNumber());
/*      */ 
/* 1809 */       Descriptors.EnumValueDescriptor old = (Descriptors.EnumValueDescriptor)this.enumValuesByNumber.put(key, value);
/* 1810 */       if (old != null)
/* 1811 */         this.enumValuesByNumber.put(key, old);
/*      */     }
/*      */ 
/*      */     static void validateSymbolName(Descriptors.GenericDescriptor descriptor)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1823 */       String name = descriptor.getName();
/* 1824 */       if (name.length() == 0) {
/* 1825 */         throw new Descriptors.DescriptorValidationException(descriptor, "Missing name.", null);
/*      */       }
/* 1827 */       boolean valid = true;
/* 1828 */       for (int i = 0; i < name.length(); i++) {
/* 1829 */         char c = name.charAt(i);
/*      */ 
/* 1832 */         if (c >= '') {
/* 1833 */           valid = false;
/*      */         }
/*      */ 
/* 1837 */         if ((Character.isLetter(c)) || (c == '_') || ((Character.isDigit(c)) && (i > 0)))
/*      */         {
/*      */           continue;
/*      */         }
/* 1841 */         valid = false;
/*      */       }
/*      */ 
/* 1844 */       if (!valid)
/* 1845 */         throw new Descriptors.DescriptorValidationException(descriptor, '"' + name + "\" is not a valid identifier.", null);
/*      */     }
/*      */ 
/*      */     private static final class DescriptorIntPair
/*      */     {
/*      */       private final Descriptors.GenericDescriptor descriptor;
/*      */       private final int number;
/*      */ 
/*      */       DescriptorIntPair(Descriptors.GenericDescriptor descriptor, int number)
/*      */       {
/* 1764 */         this.descriptor = descriptor;
/* 1765 */         this.number = number;
/*      */       }
/*      */ 
/*      */       public int hashCode()
/*      */       {
/* 1770 */         return this.descriptor.hashCode() * 65535 + this.number;
/*      */       }
/*      */ 
/*      */       public boolean equals(Object obj) {
/* 1774 */         if (!(obj instanceof DescriptorIntPair)) {
/* 1775 */           return false;
/*      */         }
/* 1777 */         DescriptorIntPair other = (DescriptorIntPair)obj;
/* 1778 */         return (this.descriptor == other.descriptor) && (this.number == other.number);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class PackageDescriptor
/*      */       implements Descriptors.GenericDescriptor
/*      */     {
/*      */       private final String name;
/*      */       private final String fullName;
/*      */       private final Descriptors.FileDescriptor file;
/*      */ 
/*      */       public Message toProto()
/*      */       {
/* 1711 */         return this.file.toProto(); } 
/* 1712 */       public String getName() { return this.name; } 
/* 1713 */       public String getFullName() { return this.fullName; } 
/* 1714 */       public Descriptors.FileDescriptor getFile() { return this.file; }
/*      */ 
/*      */       PackageDescriptor(String name, String fullName, Descriptors.FileDescriptor file)
/*      */       {
/* 1718 */         this.file = file;
/* 1719 */         this.fullName = fullName;
/* 1720 */         this.name = name;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DescriptorValidationException extends Exception
/*      */   {
/*      */     private static final long serialVersionUID = 5750205775490483148L;
/*      */     private final String name;
/*      */     private final Message proto;
/*      */     private final String description;
/*      */ 
/*      */     public String getProblemSymbolName()
/*      */     {
/* 1499 */       return this.name;
/*      */     }
/*      */ 
/*      */     public Message getProblemProto()
/*      */     {
/* 1504 */       return this.proto;
/*      */     }
/*      */ 
/*      */     public String getDescription()
/*      */     {
/* 1509 */       return this.description;
/*      */     }
/*      */ 
/*      */     private DescriptorValidationException(Descriptors.GenericDescriptor problemDescriptor, String description)
/*      */     {
/* 1518 */       super();
/*      */ 
/* 1523 */       this.name = problemDescriptor.getFullName();
/* 1524 */       this.proto = problemDescriptor.toProto();
/* 1525 */       this.description = description;
/*      */     }
/*      */ 
/*      */     private DescriptorValidationException(Descriptors.GenericDescriptor problemDescriptor, String description, Throwable cause)
/*      */     {
/* 1532 */       this(problemDescriptor, description);
/* 1533 */       initCause(cause);
/*      */     }
/*      */ 
/*      */     private DescriptorValidationException(Descriptors.FileDescriptor problemDescriptor, String description)
/*      */     {
/* 1539 */       super();
/*      */ 
/* 1544 */       this.name = problemDescriptor.getName();
/* 1545 */       this.proto = problemDescriptor.toProto();
/* 1546 */       this.description = description;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract interface GenericDescriptor
/*      */   {
/*      */     public abstract Message toProto();
/*      */ 
/*      */     public abstract String getName();
/*      */ 
/*      */     public abstract String getFullName();
/*      */ 
/*      */     public abstract Descriptors.FileDescriptor getFile();
/*      */   }
/*      */ 
/*      */   public static final class MethodDescriptor
/*      */     implements Descriptors.GenericDescriptor
/*      */   {
/*      */     private final int index;
/*      */     private DescriptorProtos.MethodDescriptorProto proto;
/*      */     private final String fullName;
/*      */     private final Descriptors.FileDescriptor file;
/*      */     private final Descriptors.ServiceDescriptor service;
/*      */     private Descriptors.Descriptor inputType;
/*      */     private Descriptors.Descriptor outputType;
/*      */ 
/*      */     public int getIndex()
/*      */     {
/* 1384 */       return this.index;
/*      */     }
/*      */     public DescriptorProtos.MethodDescriptorProto toProto() {
/* 1387 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/* 1390 */       return this.proto.getName();
/*      */     }
/*      */ 
/*      */     public String getFullName()
/*      */     {
/* 1396 */       return this.fullName;
/*      */     }
/*      */     public Descriptors.FileDescriptor getFile() {
/* 1399 */       return this.file;
/*      */     }
/*      */     public Descriptors.ServiceDescriptor getService() {
/* 1402 */       return this.service;
/*      */     }
/*      */     public Descriptors.Descriptor getInputType() {
/* 1405 */       return this.inputType;
/*      */     }
/*      */     public Descriptors.Descriptor getOutputType() {
/* 1408 */       return this.outputType;
/*      */     }
/*      */ 
/*      */     public DescriptorProtos.MethodOptions getOptions()
/*      */     {
/* 1413 */       return this.proto.getOptions();
/*      */     }
/*      */ 
/*      */     private MethodDescriptor(DescriptorProtos.MethodDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.ServiceDescriptor parent, int index)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1430 */       this.index = index;
/* 1431 */       this.proto = proto;
/* 1432 */       this.file = file;
/* 1433 */       this.service = parent;
/*      */ 
/* 1435 */       this.fullName = (parent.getFullName() + '.' + proto.getName());
/*      */ 
/* 1437 */       Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
/*      */     }
/*      */ 
/*      */     private void crossLink() throws Descriptors.DescriptorValidationException {
/* 1441 */       Descriptors.GenericDescriptor input = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getInputType(), this);
/*      */ 
/* 1443 */       if (!(input instanceof Descriptors.Descriptor)) {
/* 1444 */         throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getInputType() + "\" is not a message type.", null);
/*      */       }
/*      */ 
/* 1447 */       this.inputType = ((Descriptors.Descriptor)input);
/*      */ 
/* 1449 */       Descriptors.GenericDescriptor output = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getOutputType(), this);
/*      */ 
/* 1451 */       if (!(output instanceof Descriptors.Descriptor)) {
/* 1452 */         throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getOutputType() + "\" is not a message type.", null);
/*      */       }
/*      */ 
/* 1455 */       this.outputType = ((Descriptors.Descriptor)output);
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.MethodDescriptorProto proto)
/*      */     {
/* 1460 */       this.proto = proto;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class ServiceDescriptor
/*      */     implements Descriptors.GenericDescriptor
/*      */   {
/*      */     private final int index;
/*      */     private DescriptorProtos.ServiceDescriptorProto proto;
/*      */     private final String fullName;
/*      */     private final Descriptors.FileDescriptor file;
/*      */     private Descriptors.MethodDescriptor[] methods;
/*      */ 
/*      */     public int getIndex()
/*      */     {
/* 1294 */       return this.index;
/*      */     }
/*      */     public DescriptorProtos.ServiceDescriptorProto toProto() {
/* 1297 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/* 1300 */       return this.proto.getName();
/*      */     }
/*      */ 
/*      */     public String getFullName()
/*      */     {
/* 1306 */       return this.fullName;
/*      */     }
/*      */     public Descriptors.FileDescriptor getFile() {
/* 1309 */       return this.file;
/*      */     }
/*      */     public DescriptorProtos.ServiceOptions getOptions() {
/* 1312 */       return this.proto.getOptions();
/*      */     }
/*      */ 
/*      */     public List<Descriptors.MethodDescriptor> getMethods() {
/* 1316 */       return Collections.unmodifiableList(Arrays.asList(this.methods));
/*      */     }
/*      */ 
/*      */     public Descriptors.MethodDescriptor findMethodByName(String name)
/*      */     {
/* 1325 */       Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
/*      */ 
/* 1327 */       if ((result != null) && ((result instanceof Descriptors.MethodDescriptor))) {
/* 1328 */         return (Descriptors.MethodDescriptor)result;
/*      */       }
/* 1330 */       return null;
/*      */     }
/*      */ 
/*      */     private ServiceDescriptor(DescriptorProtos.ServiceDescriptorProto proto, Descriptors.FileDescriptor file, int index)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1344 */       this.index = index;
/* 1345 */       this.proto = proto;
/* 1346 */       this.fullName = Descriptors.access$1400(file, null, proto.getName());
/* 1347 */       this.file = file;
/*      */ 
/* 1349 */       this.methods = new Descriptors.MethodDescriptor[proto.getMethodCount()];
/* 1350 */       for (int i = 0; i < proto.getMethodCount(); i++) {
/* 1351 */         this.methods[i] = new Descriptors.MethodDescriptor(proto.getMethod(i), file, this, i, null);
/*      */       }
/*      */ 
/* 1355 */       Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
/*      */     }
/*      */ 
/*      */     private void crossLink() throws Descriptors.DescriptorValidationException {
/* 1359 */       for (Descriptors.MethodDescriptor method : this.methods)
/* 1360 */         method.crossLink();
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.ServiceDescriptorProto proto)
/*      */     {
/* 1366 */       this.proto = proto;
/*      */ 
/* 1368 */       for (int i = 0; i < this.methods.length; i++)
/* 1369 */         this.methods[i].setProto(proto.getMethod(i));
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class EnumValueDescriptor
/*      */     implements Descriptors.GenericDescriptor, Internal.EnumLite
/*      */   {
/*      */     private final int index;
/*      */     private DescriptorProtos.EnumValueDescriptorProto proto;
/*      */     private final String fullName;
/*      */     private final Descriptors.FileDescriptor file;
/*      */     private final Descriptors.EnumDescriptor type;
/*      */ 
/*      */     public int getIndex()
/*      */     {
/* 1230 */       return this.index;
/*      */     }
/*      */     public DescriptorProtos.EnumValueDescriptorProto toProto() {
/* 1233 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/* 1236 */       return this.proto.getName();
/*      */     }
/*      */     public int getNumber() {
/* 1239 */       return this.proto.getNumber();
/*      */     }
/*      */ 
/*      */     public String getFullName()
/*      */     {
/* 1245 */       return this.fullName;
/*      */     }
/*      */     public Descriptors.FileDescriptor getFile() {
/* 1248 */       return this.file;
/*      */     }
/*      */     public Descriptors.EnumDescriptor getType() {
/* 1251 */       return this.type;
/*      */     }
/*      */ 
/*      */     public DescriptorProtos.EnumValueOptions getOptions()
/*      */     {
/* 1256 */       return this.proto.getOptions();
/*      */     }
/*      */ 
/*      */     private EnumValueDescriptor(DescriptorProtos.EnumValueDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.EnumDescriptor parent, int index)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1269 */       this.index = index;
/* 1270 */       this.proto = proto;
/* 1271 */       this.file = file;
/* 1272 */       this.type = parent;
/*      */ 
/* 1274 */       this.fullName = (parent.getFullName() + '.' + proto.getName());
/*      */ 
/* 1276 */       Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
/* 1277 */       Descriptors.FileDescriptor.access$1200(file).addEnumValueByNumber(this);
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.EnumValueDescriptorProto proto)
/*      */     {
/* 1282 */       this.proto = proto;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class EnumDescriptor
/*      */     implements Descriptors.GenericDescriptor, Internal.EnumLiteMap<Descriptors.EnumValueDescriptor>
/*      */   {
/*      */     private final int index;
/*      */     private DescriptorProtos.EnumDescriptorProto proto;
/*      */     private final String fullName;
/*      */     private final Descriptors.FileDescriptor file;
/*      */     private final Descriptors.Descriptor containingType;
/*      */     private Descriptors.EnumValueDescriptor[] values;
/*      */ 
/*      */     public int getIndex()
/*      */     {
/* 1118 */       return this.index;
/*      */     }
/*      */     public DescriptorProtos.EnumDescriptorProto toProto() {
/* 1121 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/* 1124 */       return this.proto.getName();
/*      */     }
/*      */ 
/*      */     public String getFullName()
/*      */     {
/* 1130 */       return this.fullName;
/*      */     }
/*      */     public Descriptors.FileDescriptor getFile() {
/* 1133 */       return this.file;
/*      */     }
/*      */     public Descriptors.Descriptor getContainingType() {
/* 1136 */       return this.containingType;
/*      */     }
/*      */     public DescriptorProtos.EnumOptions getOptions() {
/* 1139 */       return this.proto.getOptions();
/*      */     }
/*      */ 
/*      */     public List<Descriptors.EnumValueDescriptor> getValues() {
/* 1143 */       return Collections.unmodifiableList(Arrays.asList(this.values));
/*      */     }
/*      */ 
/*      */     public Descriptors.EnumValueDescriptor findValueByName(String name)
/*      */     {
/* 1152 */       Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
/*      */ 
/* 1154 */       if ((result != null) && ((result instanceof Descriptors.EnumValueDescriptor))) {
/* 1155 */         return (Descriptors.EnumValueDescriptor)result;
/*      */       }
/* 1157 */       return null;
/*      */     }
/*      */ 
/*      */     public Descriptors.EnumValueDescriptor findValueByNumber(int number)
/*      */     {
/* 1168 */       return (Descriptors.EnumValueDescriptor)Descriptors.FileDescriptor.access$1200(this.file).enumValuesByNumber.get(new Descriptors.DescriptorPool.DescriptorIntPair(this, number));
/*      */     }
/*      */ 
/*      */     private EnumDescriptor(DescriptorProtos.EnumDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.Descriptor parent, int index)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/* 1184 */       this.index = index;
/* 1185 */       this.proto = proto;
/* 1186 */       this.fullName = Descriptors.access$1400(file, parent, proto.getName());
/* 1187 */       this.file = file;
/* 1188 */       this.containingType = parent;
/*      */ 
/* 1190 */       if (proto.getValueCount() == 0)
/*      */       {
/* 1193 */         throw new Descriptors.DescriptorValidationException(this, "Enums must contain at least one value.", null);
/*      */       }
/*      */ 
/* 1197 */       this.values = new Descriptors.EnumValueDescriptor[proto.getValueCount()];
/* 1198 */       for (int i = 0; i < proto.getValueCount(); i++) {
/* 1199 */         this.values[i] = new Descriptors.EnumValueDescriptor(proto.getValue(i), file, this, i, null);
/*      */       }
/*      */ 
/* 1203 */       Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.EnumDescriptorProto proto)
/*      */     {
/* 1208 */       this.proto = proto;
/*      */ 
/* 1210 */       for (int i = 0; i < this.values.length; i++)
/* 1211 */         this.values[i].setProto(proto.getValue(i));
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class FieldDescriptor
/*      */     implements Descriptors.GenericDescriptor, Comparable<FieldDescriptor>, FieldSet.FieldDescriptorLite<FieldDescriptor>
/*      */   {
/*  651 */     private static final WireFormat.FieldType[] table = WireFormat.FieldType.values();
/*      */     private final int index;
/*      */     private DescriptorProtos.FieldDescriptorProto proto;
/*      */     private final String fullName;
/*      */     private final Descriptors.FileDescriptor file;
/*      */     private final Descriptors.Descriptor extensionScope;
/*      */     private Type type;
/*      */     private Descriptors.Descriptor containingType;
/*      */     private Descriptors.Descriptor messageType;
/*      */     private Descriptors.EnumDescriptor enumType;
/*      */     private Object defaultValue;
/*      */ 
/*      */     public int getIndex()
/*      */     {
/*  610 */       return this.index;
/*      */     }
/*      */     public DescriptorProtos.FieldDescriptorProto toProto() {
/*  613 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/*  616 */       return this.proto.getName();
/*      */     }
/*      */     public int getNumber() {
/*  619 */       return this.proto.getNumber();
/*      */     }
/*      */ 
/*      */     public String getFullName()
/*      */     {
/*  625 */       return this.fullName;
/*      */     }
/*      */ 
/*      */     public JavaType getJavaType()
/*      */     {
/*  631 */       return this.type.getJavaType();
/*      */     }
/*      */ 
/*      */     public WireFormat.JavaType getLiteJavaType() {
/*  635 */       return getLiteType().getJavaType();
/*      */     }
/*      */ 
/*      */     public Descriptors.FileDescriptor getFile() {
/*  639 */       return this.file;
/*      */     }
/*      */     public Type getType() {
/*  642 */       return this.type;
/*      */     }
/*      */ 
/*      */     public WireFormat.FieldType getLiteType() {
/*  646 */       return table[this.type.ordinal()];
/*      */     }
/*      */ 
/*      */     public boolean isRequired()
/*      */     {
/*  656 */       return this.proto.getLabel() == DescriptorProtos.FieldDescriptorProto.Label.LABEL_REQUIRED;
/*      */     }
/*      */ 
/*      */     public boolean isOptional()
/*      */     {
/*  661 */       return this.proto.getLabel() == DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
/*      */     }
/*      */ 
/*      */     public boolean isRepeated()
/*      */     {
/*  666 */       return this.proto.getLabel() == DescriptorProtos.FieldDescriptorProto.Label.LABEL_REPEATED;
/*      */     }
/*      */ 
/*      */     public boolean isPacked()
/*      */     {
/*  671 */       return getOptions().getPacked();
/*      */     }
/*      */ 
/*      */     public boolean isPackable()
/*      */     {
/*  676 */       return (isRepeated()) && (getLiteType().isPackable());
/*      */     }
/*      */ 
/*      */     public boolean hasDefaultValue() {
/*  680 */       return this.proto.hasDefaultValue();
/*      */     }
/*      */ 
/*      */     public Object getDefaultValue()
/*      */     {
/*  688 */       if (getJavaType() == JavaType.MESSAGE) {
/*  689 */         throw new UnsupportedOperationException("FieldDescriptor.getDefaultValue() called on an embedded message field.");
/*      */       }
/*      */ 
/*  693 */       return this.defaultValue;
/*      */     }
/*      */ 
/*      */     public DescriptorProtos.FieldOptions getOptions() {
/*  697 */       return this.proto.getOptions();
/*      */     }
/*      */     public boolean isExtension() {
/*  700 */       return this.proto.hasExtendee();
/*      */     }
/*      */ 
/*      */     public Descriptors.Descriptor getContainingType()
/*      */     {
/*  707 */       return this.containingType;
/*      */     }
/*      */ 
/*      */     public Descriptors.Descriptor getExtensionScope()
/*      */     {
/*  731 */       if (!isExtension()) {
/*  732 */         throw new UnsupportedOperationException("This field is not an extension.");
/*      */       }
/*      */ 
/*  735 */       return this.extensionScope;
/*      */     }
/*      */ 
/*      */     public Descriptors.Descriptor getMessageType()
/*      */     {
/*  740 */       if (getJavaType() != JavaType.MESSAGE) {
/*  741 */         throw new UnsupportedOperationException("This field is not of message type.");
/*      */       }
/*      */ 
/*  744 */       return this.messageType;
/*      */     }
/*      */ 
/*      */     public Descriptors.EnumDescriptor getEnumType()
/*      */     {
/*  749 */       if (getJavaType() != JavaType.ENUM) {
/*  750 */         throw new UnsupportedOperationException("This field is not of enum type.");
/*      */       }
/*      */ 
/*  753 */       return this.enumType;
/*      */     }
/*      */ 
/*      */     public int compareTo(FieldDescriptor other)
/*      */     {
/*  767 */       if (other.containingType != this.containingType) {
/*  768 */         throw new IllegalArgumentException("FieldDescriptors can only be compared to other FieldDescriptors for fields of the same message type.");
/*      */       }
/*      */ 
/*  772 */       return getNumber() - other.getNumber();
/*      */     }
/*      */ 
/*      */     private FieldDescriptor(DescriptorProtos.FieldDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.Descriptor parent, int index, boolean isExtension)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/*  862 */       this.index = index;
/*  863 */       this.proto = proto;
/*  864 */       this.fullName = Descriptors.access$1400(file, parent, proto.getName());
/*  865 */       this.file = file;
/*      */ 
/*  867 */       if (proto.hasType()) {
/*  868 */         this.type = Type.valueOf(proto.getType());
/*      */       }
/*      */ 
/*  871 */       if (getNumber() <= 0) {
/*  872 */         throw new Descriptors.DescriptorValidationException(this, "Field numbers must be positive integers.", null);
/*      */       }
/*      */ 
/*  877 */       if ((proto.getOptions().getPacked()) && (!isPackable())) {
/*  878 */         throw new Descriptors.DescriptorValidationException(this, "[packed = true] can only be specified for repeated primitive fields.", null);
/*      */       }
/*      */ 
/*  883 */       if (isExtension) {
/*  884 */         if (!proto.hasExtendee()) {
/*  885 */           throw new Descriptors.DescriptorValidationException(this, "FieldDescriptorProto.extendee not set for extension field.", null);
/*      */         }
/*      */ 
/*  888 */         this.containingType = null;
/*  889 */         if (parent != null)
/*  890 */           this.extensionScope = parent;
/*      */         else
/*  892 */           this.extensionScope = null;
/*      */       }
/*      */       else {
/*  895 */         if (proto.hasExtendee()) {
/*  896 */           throw new Descriptors.DescriptorValidationException(this, "FieldDescriptorProto.extendee set for non-extension field.", null);
/*      */         }
/*      */ 
/*  899 */         this.containingType = parent;
/*  900 */         this.extensionScope = null;
/*      */       }
/*      */ 
/*  903 */       Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
/*      */     }
/*      */ 
/*      */     private void crossLink() throws Descriptors.DescriptorValidationException
/*      */     {
/*  908 */       if (this.proto.hasExtendee()) {
/*  909 */         Descriptors.GenericDescriptor extendee = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getExtendee(), this);
/*      */ 
/*  911 */         if (!(extendee instanceof Descriptors.Descriptor)) {
/*  912 */           throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getExtendee() + "\" is not a message type.", null);
/*      */         }
/*      */ 
/*  915 */         this.containingType = ((Descriptors.Descriptor)extendee);
/*      */ 
/*  917 */         if (!getContainingType().isExtensionNumber(getNumber())) {
/*  918 */           throw new Descriptors.DescriptorValidationException(this, '"' + getContainingType().getFullName() + "\" does not declare " + getNumber() + " as an extension number.", null);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  925 */       if (this.proto.hasTypeName()) {
/*  926 */         Descriptors.GenericDescriptor typeDescriptor = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getTypeName(), this);
/*      */ 
/*  929 */         if (!this.proto.hasType())
/*      */         {
/*  931 */           if ((typeDescriptor instanceof Descriptors.Descriptor))
/*  932 */             this.type = Type.MESSAGE;
/*  933 */           else if ((typeDescriptor instanceof Descriptors.EnumDescriptor))
/*  934 */             this.type = Type.ENUM;
/*      */           else {
/*  936 */             throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getTypeName() + "\" is not a type.", null);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  941 */         if (getJavaType() == JavaType.MESSAGE) {
/*  942 */           if (!(typeDescriptor instanceof Descriptors.Descriptor)) {
/*  943 */             throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getTypeName() + "\" is not a message type.", null);
/*      */           }
/*      */ 
/*  946 */           this.messageType = ((Descriptors.Descriptor)typeDescriptor);
/*      */ 
/*  948 */           if (this.proto.hasDefaultValue()) {
/*  949 */             throw new Descriptors.DescriptorValidationException(this, "Messages can't have default values.", null);
/*      */           }
/*      */         }
/*  952 */         else if (getJavaType() == JavaType.ENUM) {
/*  953 */           if (!(typeDescriptor instanceof Descriptors.EnumDescriptor)) {
/*  954 */             throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getTypeName() + "\" is not an enum type.", null);
/*      */           }
/*      */ 
/*  957 */           this.enumType = ((Descriptors.EnumDescriptor)typeDescriptor);
/*      */         } else {
/*  959 */           throw new Descriptors.DescriptorValidationException(this, "Field with primitive type has type_name.", null);
/*      */         }
/*      */ 
/*      */       }
/*  963 */       else if ((getJavaType() == JavaType.MESSAGE) || (getJavaType() == JavaType.ENUM))
/*      */       {
/*  965 */         throw new Descriptors.DescriptorValidationException(this, "Field with message or enum type missing type_name.", null);
/*      */       }
/*      */ 
/*  972 */       if (this.proto.hasDefaultValue()) {
/*  973 */         if (isRepeated()) {
/*  974 */           throw new Descriptors.DescriptorValidationException(this, "Repeated fields cannot have default values.", null);
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/*  979 */           switch (Descriptors.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$Type[getType().ordinal()]) {
/*      */           case 1:
/*      */           case 2:
/*      */           case 3:
/*  983 */             this.defaultValue = Integer.valueOf(TextFormat.parseInt32(this.proto.getDefaultValue()));
/*  984 */             break;
/*      */           case 4:
/*      */           case 5:
/*  987 */             this.defaultValue = Integer.valueOf(TextFormat.parseUInt32(this.proto.getDefaultValue()));
/*  988 */             break;
/*      */           case 6:
/*      */           case 7:
/*      */           case 8:
/*  992 */             this.defaultValue = Long.valueOf(TextFormat.parseInt64(this.proto.getDefaultValue()));
/*  993 */             break;
/*      */           case 9:
/*      */           case 10:
/*  996 */             this.defaultValue = Long.valueOf(TextFormat.parseUInt64(this.proto.getDefaultValue()));
/*  997 */             break;
/*      */           case 11:
/*  999 */             if (this.proto.getDefaultValue().equals("inf"))
/* 1000 */               this.defaultValue = Float.valueOf((1.0F / 1.0F));
/* 1001 */             else if (this.proto.getDefaultValue().equals("-inf"))
/* 1002 */               this.defaultValue = Float.valueOf((1.0F / -1.0F));
/* 1003 */             else if (this.proto.getDefaultValue().equals("nan"))
/* 1004 */               this.defaultValue = Float.valueOf((0.0F / 0.0F));
/*      */             else {
/* 1006 */               this.defaultValue = Float.valueOf(this.proto.getDefaultValue());
/*      */             }
/* 1008 */             break;
/*      */           case 12:
/* 1010 */             if (this.proto.getDefaultValue().equals("inf"))
/* 1011 */               this.defaultValue = Double.valueOf((1.0D / 0.0D));
/* 1012 */             else if (this.proto.getDefaultValue().equals("-inf"))
/* 1013 */               this.defaultValue = Double.valueOf((-1.0D / 0.0D));
/* 1014 */             else if (this.proto.getDefaultValue().equals("nan"))
/* 1015 */               this.defaultValue = Double.valueOf((0.0D / 0.0D));
/*      */             else {
/* 1017 */               this.defaultValue = Double.valueOf(this.proto.getDefaultValue());
/*      */             }
/* 1019 */             break;
/*      */           case 13:
/* 1021 */             this.defaultValue = Boolean.valueOf(this.proto.getDefaultValue());
/* 1022 */             break;
/*      */           case 14:
/* 1024 */             this.defaultValue = this.proto.getDefaultValue();
/* 1025 */             break;
/*      */           case 15:
/*      */             try {
/* 1028 */               this.defaultValue = TextFormat.unescapeBytes(this.proto.getDefaultValue());
/*      */             }
/*      */             catch (TextFormat.InvalidEscapeSequenceException e) {
/* 1031 */               throw new Descriptors.DescriptorValidationException(this, "Couldn't parse default value: " + e.getMessage(), e, null);
/*      */             }
/*      */ 
/*      */           case 16:
/* 1036 */             this.defaultValue = this.enumType.findValueByName(this.proto.getDefaultValue());
/* 1037 */             if (this.defaultValue != null) break;
/* 1038 */             throw new Descriptors.DescriptorValidationException(this, "Unknown enum default value: \"" + this.proto.getDefaultValue() + '"', null);
/*      */           case 17:
/*      */           case 18:
/* 1045 */             throw new Descriptors.DescriptorValidationException(this, "Message type had default value.", null);
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException e) {
/* 1049 */           throw new Descriptors.DescriptorValidationException(this, "Could not parse default value: \"" + this.proto.getDefaultValue() + '"', e, null);
/*      */         }
/*      */ 
/*      */       }
/* 1055 */       else if (isRepeated()) {
/* 1056 */         this.defaultValue = Collections.emptyList();
/*      */       } else {
/* 1058 */         switch (Descriptors.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$JavaType[getJavaType().ordinal()])
/*      */         {
/*      */         case 1:
/* 1062 */           this.defaultValue = this.enumType.getValues().get(0);
/* 1063 */           break;
/*      */         case 2:
/* 1065 */           this.defaultValue = null;
/* 1066 */           break;
/*      */         default:
/* 1068 */           this.defaultValue = getJavaType().defaultDefault;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1074 */       if (!isExtension()) {
/* 1075 */         Descriptors.FileDescriptor.access$1200(this.file).addFieldByNumber(this);
/*      */       }
/*      */ 
/* 1078 */       if ((this.containingType != null) && (this.containingType.getOptions().getMessageSetWireFormat()))
/*      */       {
/* 1080 */         if (isExtension()) {
/* 1081 */           if ((!isOptional()) || (getType() != Type.MESSAGE)) {
/* 1082 */             throw new Descriptors.DescriptorValidationException(this, "Extensions of MessageSets must be optional messages.", null);
/*      */           }
/*      */         }
/*      */         else
/* 1086 */           throw new Descriptors.DescriptorValidationException(this, "MessageSets cannot have fields, only extensions.", null);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.FieldDescriptorProto proto)
/*      */     {
/* 1094 */       this.proto = proto;
/*      */     }
/*      */ 
/*      */     public MessageLite.Builder internalMergeFrom(MessageLite.Builder to, MessageLite from)
/*      */     {
/* 1105 */       return ((Message.Builder)to).mergeFrom((Message)from);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  827 */       if (Type.values().length != DescriptorProtos.FieldDescriptorProto.Type.values().length)
/*  828 */         throw new RuntimeException("descriptor.proto has a new declared type but Desrciptors.java wasn't updated.");
/*      */     }
/*      */ 
/*      */     public static enum JavaType
/*      */     {
/*  835 */       INT(Integer.valueOf(0)), 
/*  836 */       LONG(Long.valueOf(0L)), 
/*  837 */       FLOAT(Float.valueOf(0.0F)), 
/*  838 */       DOUBLE(Double.valueOf(0.0D)), 
/*  839 */       BOOLEAN(Boolean.valueOf(false)), 
/*  840 */       STRING(""), 
/*  841 */       BYTE_STRING(ByteString.EMPTY), 
/*  842 */       ENUM(null), 
/*  843 */       MESSAGE(null);
/*      */ 
/*      */       private final Object defaultDefault;
/*      */ 
/*  846 */       private JavaType(Object defaultDefault) { this.defaultDefault = defaultDefault;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Type
/*      */     {
/*  790 */       DOUBLE(Descriptors.FieldDescriptor.JavaType.DOUBLE), 
/*  791 */       FLOAT(Descriptors.FieldDescriptor.JavaType.FLOAT), 
/*  792 */       INT64(Descriptors.FieldDescriptor.JavaType.LONG), 
/*  793 */       UINT64(Descriptors.FieldDescriptor.JavaType.LONG), 
/*  794 */       INT32(Descriptors.FieldDescriptor.JavaType.INT), 
/*  795 */       FIXED64(Descriptors.FieldDescriptor.JavaType.LONG), 
/*  796 */       FIXED32(Descriptors.FieldDescriptor.JavaType.INT), 
/*  797 */       BOOL(Descriptors.FieldDescriptor.JavaType.BOOLEAN), 
/*  798 */       STRING(Descriptors.FieldDescriptor.JavaType.STRING), 
/*  799 */       GROUP(Descriptors.FieldDescriptor.JavaType.MESSAGE), 
/*  800 */       MESSAGE(Descriptors.FieldDescriptor.JavaType.MESSAGE), 
/*  801 */       BYTES(Descriptors.FieldDescriptor.JavaType.BYTE_STRING), 
/*  802 */       UINT32(Descriptors.FieldDescriptor.JavaType.INT), 
/*  803 */       ENUM(Descriptors.FieldDescriptor.JavaType.ENUM), 
/*  804 */       SFIXED32(Descriptors.FieldDescriptor.JavaType.INT), 
/*  805 */       SFIXED64(Descriptors.FieldDescriptor.JavaType.LONG), 
/*  806 */       SINT32(Descriptors.FieldDescriptor.JavaType.INT), 
/*  807 */       SINT64(Descriptors.FieldDescriptor.JavaType.LONG);
/*      */ 
/*      */       private Descriptors.FieldDescriptor.JavaType javaType;
/*      */ 
/*  810 */       private Type(Descriptors.FieldDescriptor.JavaType javaType) { this.javaType = javaType;
/*      */       }
/*      */ 
/*      */       public DescriptorProtos.FieldDescriptorProto.Type toProto()
/*      */       {
/*  816 */         return DescriptorProtos.FieldDescriptorProto.Type.valueOf(ordinal() + 1);
/*      */       }
/*  818 */       public Descriptors.FieldDescriptor.JavaType getJavaType() { return this.javaType; }
/*      */ 
/*      */       public static Type valueOf(DescriptorProtos.FieldDescriptorProto.Type type) {
/*  821 */         return values()[(type.getNumber() - 1)];
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class Descriptor
/*      */     implements Descriptors.GenericDescriptor
/*      */   {
/*      */     private final int index;
/*      */     private DescriptorProtos.DescriptorProto proto;
/*      */     private final String fullName;
/*      */     private final Descriptors.FileDescriptor file;
/*      */     private final Descriptor containingType;
/*      */     private final Descriptor[] nestedTypes;
/*      */     private final Descriptors.EnumDescriptor[] enumTypes;
/*      */     private final Descriptors.FieldDescriptor[] fields;
/*      */     private final Descriptors.FieldDescriptor[] extensions;
/*      */ 
/*      */     public int getIndex()
/*      */     {
/*  399 */       return this.index;
/*      */     }
/*      */     public DescriptorProtos.DescriptorProto toProto() {
/*  402 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/*  405 */       return this.proto.getName();
/*      */     }
/*      */ 
/*      */     public String getFullName()
/*      */     {
/*  418 */       return this.fullName;
/*      */     }
/*      */     public Descriptors.FileDescriptor getFile() {
/*  421 */       return this.file;
/*      */     }
/*      */     public Descriptor getContainingType() {
/*  424 */       return this.containingType;
/*      */     }
/*      */     public DescriptorProtos.MessageOptions getOptions() {
/*  427 */       return this.proto.getOptions();
/*      */     }
/*      */ 
/*      */     public List<Descriptors.FieldDescriptor> getFields() {
/*  431 */       return Collections.unmodifiableList(Arrays.asList(this.fields));
/*      */     }
/*      */ 
/*      */     public List<Descriptors.FieldDescriptor> getExtensions()
/*      */     {
/*  436 */       return Collections.unmodifiableList(Arrays.asList(this.extensions));
/*      */     }
/*      */ 
/*      */     public List<Descriptor> getNestedTypes()
/*      */     {
/*  441 */       return Collections.unmodifiableList(Arrays.asList(this.nestedTypes));
/*      */     }
/*      */ 
/*      */     public List<Descriptors.EnumDescriptor> getEnumTypes()
/*      */     {
/*  446 */       return Collections.unmodifiableList(Arrays.asList(this.enumTypes));
/*      */     }
/*      */ 
/*      */     public boolean isExtensionNumber(int number)
/*      */     {
/*  452 */       for (DescriptorProtos.DescriptorProto.ExtensionRange range : this.proto.getExtensionRangeList()) {
/*  453 */         if ((range.getStart() <= number) && (number < range.getEnd())) {
/*  454 */           return true;
/*      */         }
/*      */       }
/*  457 */       return false;
/*      */     }
/*      */ 
/*      */     public Descriptors.FieldDescriptor findFieldByName(String name)
/*      */     {
/*  466 */       Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
/*      */ 
/*  468 */       if ((result != null) && ((result instanceof Descriptors.FieldDescriptor))) {
/*  469 */         return (Descriptors.FieldDescriptor)result;
/*      */       }
/*  471 */       return null;
/*      */     }
/*      */ 
/*      */     public Descriptors.FieldDescriptor findFieldByNumber(int number)
/*      */     {
/*  481 */       return (Descriptors.FieldDescriptor)Descriptors.FileDescriptor.access$1200(this.file).fieldsByNumber.get(new Descriptors.DescriptorPool.DescriptorIntPair(this, number));
/*      */     }
/*      */ 
/*      */     public Descriptor findNestedTypeByName(String name)
/*      */     {
/*  491 */       Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
/*      */ 
/*  493 */       if ((result != null) && ((result instanceof Descriptor))) {
/*  494 */         return (Descriptor)result;
/*      */       }
/*  496 */       return null;
/*      */     }
/*      */ 
/*      */     public Descriptors.EnumDescriptor findEnumTypeByName(String name)
/*      */     {
/*  506 */       Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
/*      */ 
/*  508 */       if ((result != null) && ((result instanceof Descriptors.EnumDescriptor))) {
/*  509 */         return (Descriptors.EnumDescriptor)result;
/*      */       }
/*  511 */       return null;
/*      */     }
/*      */ 
/*      */     private Descriptor(DescriptorProtos.DescriptorProto proto, Descriptors.FileDescriptor file, Descriptor parent, int index)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/*  530 */       this.index = index;
/*  531 */       this.proto = proto;
/*  532 */       this.fullName = Descriptors.access$1400(file, parent, proto.getName());
/*  533 */       this.file = file;
/*  534 */       this.containingType = parent;
/*      */ 
/*  536 */       this.nestedTypes = new Descriptor[proto.getNestedTypeCount()];
/*  537 */       for (int i = 0; i < proto.getNestedTypeCount(); i++) {
/*  538 */         this.nestedTypes[i] = new Descriptor(proto.getNestedType(i), file, this, i);
/*      */       }
/*      */ 
/*  542 */       this.enumTypes = new Descriptors.EnumDescriptor[proto.getEnumTypeCount()];
/*  543 */       for (int i = 0; i < proto.getEnumTypeCount(); i++) {
/*  544 */         this.enumTypes[i] = new Descriptors.EnumDescriptor(proto.getEnumType(i), file, this, i, null);
/*      */       }
/*      */ 
/*  548 */       this.fields = new Descriptors.FieldDescriptor[proto.getFieldCount()];
/*  549 */       for (int i = 0; i < proto.getFieldCount(); i++) {
/*  550 */         this.fields[i] = new Descriptors.FieldDescriptor(proto.getField(i), file, this, i, false, null);
/*      */       }
/*      */ 
/*  554 */       this.extensions = new Descriptors.FieldDescriptor[proto.getExtensionCount()];
/*  555 */       for (int i = 0; i < proto.getExtensionCount(); i++) {
/*  556 */         this.extensions[i] = new Descriptors.FieldDescriptor(proto.getExtension(i), file, this, i, true, null);
/*      */       }
/*      */ 
/*  560 */       Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
/*      */     }
/*      */ 
/*      */     private void crossLink() throws Descriptors.DescriptorValidationException
/*      */     {
/*  565 */       for (Descriptor nestedType : this.nestedTypes) {
/*  566 */         nestedType.crossLink();
/*      */       }
/*      */ 
/*  569 */       for (Descriptors.FieldDescriptor field : this.fields) {
/*  570 */         field.crossLink();
/*      */       }
/*      */ 
/*  573 */       for (Descriptors.FieldDescriptor extension : this.extensions)
/*  574 */         extension.crossLink();
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.DescriptorProto proto)
/*      */     {
/*  580 */       this.proto = proto;
/*      */ 
/*  582 */       for (int i = 0; i < this.nestedTypes.length; i++) {
/*  583 */         this.nestedTypes[i].setProto(proto.getNestedType(i));
/*      */       }
/*      */ 
/*  586 */       for (int i = 0; i < this.enumTypes.length; i++) {
/*  587 */         this.enumTypes[i].setProto(proto.getEnumType(i));
/*      */       }
/*      */ 
/*  590 */       for (int i = 0; i < this.fields.length; i++) {
/*  591 */         this.fields[i].setProto(proto.getField(i));
/*      */       }
/*      */ 
/*  594 */       for (int i = 0; i < this.extensions.length; i++)
/*  595 */         this.extensions[i].setProto(proto.getExtension(i));
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class FileDescriptor
/*      */   {
/*      */     private DescriptorProtos.FileDescriptorProto proto;
/*      */     private final Descriptors.Descriptor[] messageTypes;
/*      */     private final Descriptors.EnumDescriptor[] enumTypes;
/*      */     private final Descriptors.ServiceDescriptor[] services;
/*      */     private final Descriptors.FieldDescriptor[] extensions;
/*      */     private final FileDescriptor[] dependencies;
/*      */     private final Descriptors.DescriptorPool pool;
/*      */ 
/*      */     public DescriptorProtos.FileDescriptorProto toProto()
/*      */     {
/*   33 */       return this.proto;
/*      */     }
/*      */     public String getName() {
/*   36 */       return this.proto.getName();
/*      */     }
/*      */ 
/*      */     public String getPackage()
/*      */     {
/*   43 */       return this.proto.getPackage();
/*      */     }
/*      */     public DescriptorProtos.FileOptions getOptions() {
/*   46 */       return this.proto.getOptions();
/*      */     }
/*      */ 
/*      */     public List<Descriptors.Descriptor> getMessageTypes() {
/*   50 */       return Collections.unmodifiableList(Arrays.asList(this.messageTypes));
/*      */     }
/*      */ 
/*      */     public List<Descriptors.EnumDescriptor> getEnumTypes()
/*      */     {
/*   55 */       return Collections.unmodifiableList(Arrays.asList(this.enumTypes));
/*      */     }
/*      */ 
/*      */     public List<Descriptors.ServiceDescriptor> getServices()
/*      */     {
/*   60 */       return Collections.unmodifiableList(Arrays.asList(this.services));
/*      */     }
/*      */ 
/*      */     public List<Descriptors.FieldDescriptor> getExtensions()
/*      */     {
/*   65 */       return Collections.unmodifiableList(Arrays.asList(this.extensions));
/*      */     }
/*      */ 
/*      */     public List<FileDescriptor> getDependencies()
/*      */     {
/*   70 */       return Collections.unmodifiableList(Arrays.asList(this.dependencies));
/*      */     }
/*      */ 
/*      */     public Descriptors.Descriptor findMessageTypeByName(String name)
/*      */     {
/*   82 */       if (name.indexOf('.') != -1) {
/*   83 */         return null;
/*      */       }
/*   85 */       if (getPackage().length() > 0) {
/*   86 */         name = getPackage() + '.' + name;
/*      */       }
/*   88 */       Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
/*   89 */       if ((result != null) && ((result instanceof Descriptors.Descriptor)) && (result.getFile() == this))
/*      */       {
/*   91 */         return (Descriptors.Descriptor)result;
/*      */       }
/*   93 */       return null;
/*      */     }
/*      */ 
/*      */     public Descriptors.EnumDescriptor findEnumTypeByName(String name)
/*      */     {
/*  106 */       if (name.indexOf('.') != -1) {
/*  107 */         return null;
/*      */       }
/*  109 */       if (getPackage().length() > 0) {
/*  110 */         name = getPackage() + '.' + name;
/*      */       }
/*  112 */       Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
/*  113 */       if ((result != null) && ((result instanceof Descriptors.EnumDescriptor)) && (result.getFile() == this))
/*      */       {
/*  115 */         return (Descriptors.EnumDescriptor)result;
/*      */       }
/*  117 */       return null;
/*      */     }
/*      */ 
/*      */     public Descriptors.ServiceDescriptor findServiceByName(String name)
/*      */     {
/*  130 */       if (name.indexOf('.') != -1) {
/*  131 */         return null;
/*      */       }
/*  133 */       if (getPackage().length() > 0) {
/*  134 */         name = getPackage() + '.' + name;
/*      */       }
/*  136 */       Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
/*  137 */       if ((result != null) && ((result instanceof Descriptors.ServiceDescriptor)) && (result.getFile() == this))
/*      */       {
/*  139 */         return (Descriptors.ServiceDescriptor)result;
/*      */       }
/*  141 */       return null;
/*      */     }
/*      */ 
/*      */     public Descriptors.FieldDescriptor findExtensionByName(String name)
/*      */     {
/*  153 */       if (name.indexOf('.') != -1) {
/*  154 */         return null;
/*      */       }
/*  156 */       if (getPackage().length() > 0) {
/*  157 */         name = getPackage() + '.' + name;
/*      */       }
/*  159 */       Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
/*  160 */       if ((result != null) && ((result instanceof Descriptors.FieldDescriptor)) && (result.getFile() == this))
/*      */       {
/*  162 */         return (Descriptors.FieldDescriptor)result;
/*      */       }
/*  164 */       return null;
/*      */     }
/*      */ 
/*      */     public static FileDescriptor buildFrom(DescriptorProtos.FileDescriptorProto proto, FileDescriptor[] dependencies)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/*  192 */       Descriptors.DescriptorPool pool = new Descriptors.DescriptorPool(dependencies);
/*  193 */       FileDescriptor result = new FileDescriptor(proto, dependencies, pool);
/*      */ 
/*  196 */       if (dependencies.length != proto.getDependencyCount()) {
/*  197 */         throw new Descriptors.DescriptorValidationException(result, "Dependencies passed to FileDescriptor.buildFrom() don't match those listed in the FileDescriptorProto.", null);
/*      */       }
/*      */ 
/*  201 */       for (int i = 0; i < proto.getDependencyCount(); i++) {
/*  202 */         if (!dependencies[i].getName().equals(proto.getDependency(i))) {
/*  203 */           throw new Descriptors.DescriptorValidationException(result, "Dependencies passed to FileDescriptor.buildFrom() don't match those listed in the FileDescriptorProto.", null);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  209 */       result.crossLink();
/*  210 */       return result;
/*      */     }
/*      */ 
/*      */     public static void internalBuildGeneratedFileFrom(String[] descriptorDataParts, FileDescriptor[] dependencies, InternalDescriptorAssigner descriptorAssigner)
/*      */     {
/*  233 */       StringBuilder descriptorData = new StringBuilder();
/*  234 */       for (String part : descriptorDataParts)
/*  235 */         descriptorData.append(part);
/*      */       byte[] descriptorBytes;
/*      */       try
/*      */       {
/*  240 */         descriptorBytes = descriptorData.toString().getBytes("ISO-8859-1");
/*      */       } catch (UnsupportedEncodingException e) {
/*  242 */         throw new RuntimeException("Standard encoding ISO-8859-1 not supported by JVM.", e);
/*      */       }
/*      */       DescriptorProtos.FileDescriptorProto proto;
/*      */       try
/*      */       {
/*  248 */         proto = DescriptorProtos.FileDescriptorProto.parseFrom(descriptorBytes);
/*      */       } catch (InvalidProtocolBufferException e) {
/*  250 */         throw new IllegalArgumentException("Failed to parse protocol buffer descriptor for generated code.", e);
/*      */       }
/*      */       FileDescriptor result;
/*      */       try
/*      */       {
/*  256 */         result = buildFrom(proto, dependencies);
/*      */       } catch (Descriptors.DescriptorValidationException e) {
/*  258 */         throw new IllegalArgumentException("Invalid embedded descriptor for \"" + proto.getName() + "\".", e);
/*      */       }
/*      */ 
/*  262 */       ExtensionRegistry registry = descriptorAssigner.assignDescriptors(result);
/*      */ 
/*  265 */       if (registry != null)
/*      */       {
/*      */         try {
/*  268 */           proto = DescriptorProtos.FileDescriptorProto.parseFrom(descriptorBytes, registry);
/*      */         } catch (InvalidProtocolBufferException e) {
/*  270 */           throw new IllegalArgumentException("Failed to parse protocol buffer descriptor for generated code.", e);
/*      */         }
/*      */ 
/*  275 */         result.setProto(proto);
/*      */       }
/*      */     }
/*      */ 
/*      */     private FileDescriptor(DescriptorProtos.FileDescriptorProto proto, FileDescriptor[] dependencies, Descriptors.DescriptorPool pool)
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/*  307 */       this.pool = pool;
/*  308 */       this.proto = proto;
/*  309 */       this.dependencies = ((FileDescriptor[])dependencies.clone());
/*      */ 
/*  311 */       pool.addPackage(getPackage(), this);
/*      */ 
/*  313 */       this.messageTypes = new Descriptors.Descriptor[proto.getMessageTypeCount()];
/*  314 */       for (int i = 0; i < proto.getMessageTypeCount(); i++) {
/*  315 */         this.messageTypes[i] = new Descriptors.Descriptor(proto.getMessageType(i), this, null, i, null);
/*      */       }
/*      */ 
/*  319 */       this.enumTypes = new Descriptors.EnumDescriptor[proto.getEnumTypeCount()];
/*  320 */       for (int i = 0; i < proto.getEnumTypeCount(); i++) {
/*  321 */         this.enumTypes[i] = new Descriptors.EnumDescriptor(proto.getEnumType(i), this, null, i, null);
/*      */       }
/*      */ 
/*  324 */       this.services = new Descriptors.ServiceDescriptor[proto.getServiceCount()];
/*  325 */       for (int i = 0; i < proto.getServiceCount(); i++) {
/*  326 */         this.services[i] = new Descriptors.ServiceDescriptor(proto.getService(i), this, i, null);
/*      */       }
/*      */ 
/*  329 */       this.extensions = new Descriptors.FieldDescriptor[proto.getExtensionCount()];
/*  330 */       for (int i = 0; i < proto.getExtensionCount(); i++)
/*  331 */         this.extensions[i] = new Descriptors.FieldDescriptor(proto.getExtension(i), this, null, i, true, null);
/*      */     }
/*      */ 
/*      */     private void crossLink()
/*      */       throws Descriptors.DescriptorValidationException
/*      */     {
/*  338 */       for (Descriptors.Descriptor messageType : this.messageTypes) {
/*  339 */         messageType.crossLink();
/*      */       }
/*      */ 
/*  342 */       for (Descriptors.ServiceDescriptor service : this.services) {
/*  343 */         service.crossLink();
/*      */       }
/*      */ 
/*  346 */       for (Descriptors.FieldDescriptor extension : this.extensions)
/*  347 */         extension.crossLink();
/*      */     }
/*      */ 
/*      */     private void setProto(DescriptorProtos.FileDescriptorProto proto)
/*      */     {
/*  362 */       this.proto = proto;
/*      */ 
/*  364 */       for (int i = 0; i < this.messageTypes.length; i++) {
/*  365 */         this.messageTypes[i].setProto(proto.getMessageType(i));
/*      */       }
/*      */ 
/*  368 */       for (int i = 0; i < this.enumTypes.length; i++) {
/*  369 */         this.enumTypes[i].setProto(proto.getEnumType(i));
/*      */       }
/*      */ 
/*  372 */       for (int i = 0; i < this.services.length; i++) {
/*  373 */         this.services[i].setProto(proto.getService(i));
/*      */       }
/*      */ 
/*  376 */       for (int i = 0; i < this.extensions.length; i++)
/*  377 */         this.extensions[i].setProto(proto.getExtension(i));
/*      */     }
/*      */ 
/*      */     public static abstract interface InternalDescriptorAssigner
/*      */     {
/*      */       public abstract ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor paramFileDescriptor);
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.Descriptors
 * JD-Core Version:    0.6.0
 */