/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.io.ByteStreams;
/*     */ import com.google.appengine.repackaged.com.google.common.util.Base64;
/*     */ import com.google.appengine.repackaged.com.google.common.util.Base64DecoderException;
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*     */ import com.google.apphosting.api.DatastorePb.CompiledCursor;
/*     */ import com.google.apphosting.api.DatastorePb.CompiledCursor.Position;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public final class Cursor
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 3515556366838971499L;
/*     */   private DatastorePb.CompiledCursor compiledCursor;
/*     */ 
/*     */   Cursor()
/*     */   {
/*  55 */     this.compiledCursor = new DatastorePb.CompiledCursor();
/*     */   }
/*     */ 
/*     */   Cursor(Cursor previousCursor) {
/*  59 */     this(previousCursor.compiledCursor);
/*     */   }
/*     */ 
/*     */   Cursor(DatastorePb.CompiledCursor compiledCursor) {
/*  63 */     this.compiledCursor = ((DatastorePb.CompiledCursor)compiledCursor.clone());
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out) throws IOException
/*     */   {
/*  68 */     out.write(this.compiledCursor.toByteArray());
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException {
/*  72 */     this.compiledCursor = fromByteArray(ByteStreams.toByteArray(in)).compiledCursor;
/*     */   }
/*     */ 
/*     */   void advance(int n, PreparedQuery query)
/*     */   {
/*  77 */     if (n > 0) {
/*  78 */       this.compiledCursor = query.asQueryResultIterator(FetchOptions.Builder.withStartCursor(this).offset(n).prefetchSize(0).limit(1)).getCursor().compiledCursor;
/*     */     }
/*  82 */     else if ((n == -1) && (this.compiledCursor.positionSize() == 1) && (this.compiledCursor.getPosition(0).hasStartKey()) && (!this.compiledCursor.getPosition(0).isStartInclusive()))
/*     */     {
/*  87 */       this.compiledCursor.getPosition(0).setStartInclusive(true);
/*  88 */     } else if (n != 0)
/*  89 */       throw new IllegalArgumentException("Unable to offset cursor by " + n + " results.");
/*     */   }
/*     */ 
/*     */   public String toWebSafeString()
/*     */   {
/*  98 */     return Base64.encodeWebSafe(this.compiledCursor.toByteArray(), false);
/*     */   }
/*     */ 
/*     */   public static Cursor fromWebSafeString(String encodedCursor)
/*     */   {
/* 109 */     if (encodedCursor == null) {
/* 110 */       throw new NullPointerException("encodedCursor must not be null");
/*     */     }
/*     */     try
/*     */     {
/* 114 */       return fromByteArray(Base64.decodeWebSafe(encodedCursor)); } catch (Base64DecoderException e) {
/*     */     }
/* 116 */     throw new IllegalArgumentException("Unable to decode provided cursor.", e);
/*     */   }
/*     */ 
/*     */   private static Cursor fromByteArray(byte[] bytes)
/*     */   {
/* 121 */     Cursor result = new Cursor();
/* 122 */     if (!result.compiledCursor.merge(new ProtocolSource(bytes))) {
/* 123 */       throw new IllegalArgumentException("Unable to decode provided cursor.");
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ 
/*     */   DatastorePb.CompiledCursor convertToPb() {
/* 129 */     return this.compiledCursor;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 134 */     if (obj == null) {
/* 135 */       return false;
/*     */     }
/*     */ 
/* 138 */     if (obj.getClass() != getClass()) {
/* 139 */       return false;
/*     */     }
/*     */ 
/* 142 */     return this.compiledCursor.equals(((Cursor)obj).compiledCursor);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 147 */     return this.compiledCursor.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 152 */     return this.compiledCursor.toString();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Cursor
 * JD-Core Version:    0.6.0
 */