/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Booleans;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ abstract class Cut<C extends Comparable>
/*     */   implements Comparable<Cut<C>>
/*     */ {
/*     */   final C endpoint;
/* 100 */   static final Cut<Comparable<?>> BELOW_ALL = new Cut()
/*     */   {
/*     */     Comparable<?> endpoint() {
/* 103 */       throw new IllegalStateException("range unbounded on this side");
/*     */     }
/*     */     boolean isLessThan(Comparable<?> value) {
/* 106 */       return true;
/*     */     }
/*     */     Range.BoundType typeAsLowerBound() {
/* 109 */       throw new IllegalStateException();
/*     */     }
/*     */     Range.BoundType typeAsUpperBound() {
/* 112 */       throw new AssertionError("this statement should be unreachable");
/*     */     }
/*     */     void describeAsLowerBound(StringBuilder sb) {
/* 115 */       sb.append("(-∞");
/*     */     }
/*     */     void describeAsUpperBound(StringBuilder sb) {
/* 118 */       throw new AssertionError();
/*     */     }
/*     */ 
/*     */     Comparable<?> leastValueAbove(DiscreteType<Comparable<?>> typeDescriptor) {
/* 122 */       return typeDescriptor.minValue();
/*     */     }
/*     */ 
/*     */     Comparable<?> greatestValueBelow(DiscreteType<Comparable<?>> typeDescriptor) {
/* 126 */       throw new AssertionError();
/*     */     }
/*     */ 
/*     */     Cut<Comparable<?>> canonical(DiscreteType<Comparable<?>> typeDescriptor) {
/*     */       try {
/* 131 */         return new Cut.BelowValue(typeDescriptor.minValue()); } catch (NoSuchElementException e) {
/*     */       }
/* 133 */       return this;
/*     */     }
/*     */ 
/*     */     public int compareTo(Cut<Comparable<?>> o) {
/* 137 */       return o == this ? 0 : -1;
/*     */     }
/* 100 */   };
/*     */ 
/* 141 */   static final Cut<Comparable<?>> ABOVE_ALL = new Cut()
/*     */   {
/*     */     Comparable<?> endpoint() {
/* 144 */       throw new IllegalStateException("range unbounded on this side");
/*     */     }
/*     */     boolean isLessThan(Comparable<?> value) {
/* 147 */       return false;
/*     */     }
/*     */     Range.BoundType typeAsLowerBound() {
/* 150 */       throw new AssertionError("this statement should be unreachable");
/*     */     }
/*     */     Range.BoundType typeAsUpperBound() {
/* 153 */       throw new IllegalStateException();
/*     */     }
/*     */     void describeAsLowerBound(StringBuilder sb) {
/* 156 */       throw new AssertionError();
/*     */     }
/*     */     void describeAsUpperBound(StringBuilder sb) {
/* 159 */       sb.append("+∞)");
/*     */     }
/*     */ 
/*     */     Comparable<?> leastValueAbove(DiscreteType<Comparable<?>> typeDescriptor) {
/* 163 */       throw new AssertionError();
/*     */     }
/*     */ 
/*     */     Comparable<?> greatestValueBelow(DiscreteType<Comparable<?>> typeDescriptor) {
/* 167 */       return typeDescriptor.maxValue();
/*     */     }
/*     */     public int compareTo(Cut<Comparable<?>> o) {
/* 170 */       return o == this ? 0 : 1;
/*     */     }
/* 141 */   };
/*     */ 
/*     */   Cut(C endpoint)
/*     */   {
/*  45 */     this.endpoint = endpoint; } 
/*     */   abstract boolean isLessThan(C paramC);
/*     */ 
/*     */   abstract Range.BoundType typeAsLowerBound();
/*     */ 
/*     */   abstract Range.BoundType typeAsUpperBound();
/*     */ 
/*     */   abstract void describeAsLowerBound(StringBuilder paramStringBuilder);
/*     */ 
/*     */   abstract void describeAsUpperBound(StringBuilder paramStringBuilder);
/*     */ 
/*     */   abstract C leastValueAbove(DiscreteType<C> paramDiscreteType);
/*     */ 
/*     */   abstract C greatestValueBelow(DiscreteType<C> paramDiscreteType);
/*     */ 
/*  63 */   Cut<C> canonical(DiscreteType<C> typeDescriptor) { return this;
/*     */   }
/*     */ 
/*     */   public int compareTo(Cut<C> that)
/*     */   {
/*  68 */     if (that == BELOW_ALL) {
/*  69 */       return 1;
/*     */     }
/*  71 */     if (that == ABOVE_ALL) {
/*  72 */       return -1;
/*     */     }
/*  74 */     int result = compareOrThrow(this.endpoint, that.endpoint);
/*  75 */     if (result != 0) {
/*  76 */       return result;
/*     */     }
/*     */ 
/*  79 */     return Booleans.compare(this instanceof AboveValue, that instanceof AboveValue);
/*     */   }
/*     */ 
/*     */   C endpoint()
/*     */   {
/*  84 */     return this.endpoint;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  89 */     if ((obj instanceof Cut)) {
/*  90 */       Cut that = (Cut)obj;
/*     */       try {
/*  92 */         int compareResult = compareTo(that);
/*  93 */         return compareResult == 0;
/*     */       } catch (ClassCastException ignored) {
/*     */       }
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   private static int compareOrThrow(Comparable left, Comparable right)
/*     */   {
/* 248 */     return left.compareTo(right);
/*     */   }
/*     */ 
/*     */   static final class AboveValue<C extends Comparable> extends Cut<C>
/*     */   {
/*     */     AboveValue(C endpoint)
/*     */     {
/* 207 */       super();
/*     */     }
/*     */ 
/*     */     boolean isLessThan(C value) {
/* 211 */       return Cut.access$000(this.endpoint, value) < 0;
/*     */     }
/*     */     Range.BoundType typeAsLowerBound() {
/* 214 */       return Range.BoundType.OPEN;
/*     */     }
/*     */     Range.BoundType typeAsUpperBound() {
/* 217 */       return Range.BoundType.CLOSED;
/*     */     }
/*     */     void describeAsLowerBound(StringBuilder sb) {
/* 220 */       sb.append('(').append(this.endpoint);
/*     */     }
/*     */     void describeAsUpperBound(StringBuilder sb) {
/* 223 */       sb.append(this.endpoint).append(']');
/*     */     }
/*     */     C leastValueAbove(DiscreteType<C> typeDescriptor) {
/* 226 */       return typeDescriptor.next(this.endpoint);
/*     */     }
/*     */     C greatestValueBelow(DiscreteType<C> typeDescriptor) {
/* 229 */       return this.endpoint;
/*     */     }
/*     */     Cut<C> canonical(DiscreteType<C> typeDescriptor) {
/* 232 */       Comparable next = leastValueAbove(typeDescriptor);
/* 233 */       if (next != null) {
/* 234 */         return new Cut.BelowValue(next);
/*     */       }
/*     */ 
/* 238 */       Cut aboveAll = ABOVE_ALL;
/* 239 */       return aboveAll;
/*     */     }
/*     */     public int hashCode() {
/* 242 */       return this.endpoint.hashCode() ^ 0xFFFFFFFF;
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class BelowValue<C extends Comparable> extends Cut<C>
/*     */   {
/*     */     BelowValue(C endpoint)
/*     */     {
/* 176 */       super();
/*     */     }
/*     */ 
/*     */     boolean isLessThan(C value) {
/* 180 */       return Cut.access$000(this.endpoint, value) <= 0;
/*     */     }
/*     */     Range.BoundType typeAsLowerBound() {
/* 183 */       return Range.BoundType.CLOSED;
/*     */     }
/*     */     Range.BoundType typeAsUpperBound() {
/* 186 */       return Range.BoundType.OPEN;
/*     */     }
/*     */     void describeAsLowerBound(StringBuilder sb) {
/* 189 */       sb.append('[').append(this.endpoint);
/*     */     }
/*     */     void describeAsUpperBound(StringBuilder sb) {
/* 192 */       sb.append(this.endpoint).append(')');
/*     */     }
/*     */     C leastValueAbove(DiscreteType<C> typeDescriptor) {
/* 195 */       return this.endpoint;
/*     */     }
/*     */     C greatestValueBelow(DiscreteType<C> typeDescriptor) {
/* 198 */       return typeDescriptor.previous(this.endpoint);
/*     */     }
/*     */     public int hashCode() {
/* 201 */       return this.endpoint.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Cut
 * JD-Core Version:    0.6.0
 */