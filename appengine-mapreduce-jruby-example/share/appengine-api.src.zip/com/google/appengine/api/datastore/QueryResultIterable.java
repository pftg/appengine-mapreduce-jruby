package com.google.appengine.api.datastore;

public abstract interface QueryResultIterable<T> extends Iterable<T>
{
  public abstract QueryResultIterator<T> iterator();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryResultIterable
 * JD-Core Version:    0.6.0
 */