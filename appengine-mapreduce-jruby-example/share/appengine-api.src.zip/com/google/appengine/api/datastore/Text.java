/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class Text
/*    */   implements Serializable
/*    */ {
/*    */   public static final long serialVersionUID = -8389037235415462280L;
/*    */   private String value;
/*    */ 
/*    */   private Text()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Text(String value)
/*    */   {
/* 51 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 58 */     return this.value;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 63 */     return this.value.hashCode();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 72 */     if ((object instanceof Text)) {
/* 73 */       Text key = (Text)object;
/* 74 */       return this.value.equals(key.value);
/*    */     }
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 84 */     String text = this.value;
/* 85 */     if (text.length() > 70) {
/* 86 */       text = text.substring(0, 70) + "...";
/*    */     }
/* 88 */     return "<Text: " + text + ">";
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Text
 * JD-Core Version:    0.6.0
 */