/*      */ package com.google.appengine.repackaged.com.google.common.base;
/*      */ 
/*      */ import com.google.common.annotations.Beta;
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ 
/*      */ @Beta
/*      */ @GwtCompatible
/*      */ public abstract class CharMatcher
/*      */   implements Predicate<Character>
/*      */ {
/*      */   private static final String BREAKING_WHITESPACE_CHARS = "\t\n\013\f\r     　";
/*      */   private static final String NON_BREAKING_WHITESPACE_CHARS = " ᠎ ";
/*   70 */   public static final CharMatcher WHITESPACE = anyOf("\t\n\013\f\r     　 ᠎ ").or(inRange(' ', ' ')).precomputed();
/*      */ 
/*   82 */   public static final CharMatcher BREAKING_WHITESPACE = anyOf("\t\n\013\f\r     　").or(inRange(' ', ' ')).or(inRange(' ', ' ')).precomputed();
/*      */ 
/*   91 */   public static final CharMatcher ASCII = inRange('\000', '');
/*      */   public static final CharMatcher DIGIT;
/*      */   public static final CharMatcher JAVA_WHITESPACE;
/*      */   public static final CharMatcher JAVA_DIGIT;
/*      */   public static final CharMatcher JAVA_LETTER;
/*      */   public static final CharMatcher JAVA_LETTER_OR_DIGIT;
/*      */   public static final CharMatcher JAVA_UPPER_CASE;
/*      */   public static final CharMatcher JAVA_LOWER_CASE;
/*      */   public static final CharMatcher JAVA_ISO_CONTROL;
/*      */   public static final CharMatcher INVISIBLE;
/*      */   public static final CharMatcher SINGLE_WIDTH;
/*      */ 
/*      */   @GoogleInternal
/*      */   public static final CharMatcher LEGACY_WHITESPACE;
/*      */   public static final CharMatcher ANY;
/*      */   public static final CharMatcher NONE;
/*      */ 
/*      */   public static CharMatcher is(char match)
/*      */   {
/*  406 */     return new CharMatcher(match) {
/*      */       public boolean matches(char c) {
/*  408 */         return c == this.val$match;
/*      */       }
/*      */ 
/*      */       public String replaceFrom(CharSequence sequence, char replacement) {
/*  412 */         return sequence.toString().replace(this.val$match, replacement);
/*      */       }
/*      */ 
/*      */       public CharMatcher and(CharMatcher other) {
/*  416 */         return other.matches(this.val$match) ? this : NONE;
/*      */       }
/*      */ 
/*      */       public CharMatcher or(CharMatcher other) {
/*  420 */         return other.matches(this.val$match) ? other : super.or(other);
/*      */       }
/*      */ 
/*      */       public CharMatcher negate() {
/*  424 */         return isNot(this.val$match);
/*      */       }
/*      */ 
/*      */       void setBits(CharMatcher.LookupTable table) {
/*  428 */         table.set(this.val$match);
/*      */       }
/*      */ 
/*      */       public CharMatcher precomputed() {
/*  432 */         return this;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static CharMatcher isNot(char match)
/*      */   {
/*  443 */     return new CharMatcher(match) {
/*      */       public boolean matches(char c) {
/*  445 */         return c != this.val$match;
/*      */       }
/*      */ 
/*      */       public CharMatcher and(CharMatcher other) {
/*  449 */         return other.matches(this.val$match) ? super.and(other) : other;
/*      */       }
/*      */ 
/*      */       public CharMatcher or(CharMatcher other) {
/*  453 */         return other.matches(this.val$match) ? ANY : this;
/*      */       }
/*      */ 
/*      */       public CharMatcher negate() {
/*  457 */         return is(this.val$match);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static CharMatcher anyOf(CharSequence sequence)
/*      */   {
/*  467 */     switch (sequence.length()) {
/*      */     case 0:
/*  469 */       return NONE;
/*      */     case 1:
/*  471 */       return is(sequence.charAt(0));
/*      */     case 2:
/*  473 */       char match1 = sequence.charAt(0);
/*  474 */       char match2 = sequence.charAt(1);
/*  475 */       return new CharMatcher(match1, match2) {
/*      */         public boolean matches(char c) {
/*  477 */           return (c == this.val$match1) || (c == this.val$match2);
/*      */         }
/*      */ 
/*      */         void setBits(CharMatcher.LookupTable table) {
/*  481 */           table.set(this.val$match1);
/*  482 */           table.set(this.val$match2);
/*      */         }
/*      */ 
/*      */         public CharMatcher precomputed() {
/*  486 */           return this;
/*      */         }
/*      */       };
/*      */     }
/*  491 */     char[] chars = sequence.toString().toCharArray();
/*  492 */     Arrays.sort(chars);
/*      */ 
/*  494 */     return new CharMatcher(chars) {
/*      */       public boolean matches(char c) {
/*  496 */         return Arrays.binarySearch(this.val$chars, c) >= 0;
/*      */       }
/*      */ 
/*      */       void setBits(CharMatcher.LookupTable table) {
/*  500 */         for (char c : this.val$chars)
/*  501 */           table.set(c);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static CharMatcher noneOf(CharSequence sequence)
/*      */   {
/*  512 */     return anyOf(sequence).negate();
/*      */   }
/*      */ 
/*      */   public static CharMatcher inRange(char startInclusive, char endInclusive)
/*      */   {
/*  523 */     Preconditions.checkArgument(endInclusive >= startInclusive);
/*  524 */     return new CharMatcher(startInclusive, endInclusive) {
/*      */       public boolean matches(char c) {
/*  526 */         return (this.val$startInclusive <= c) && (c <= this.val$endInclusive);
/*      */       }
/*      */ 
/*      */       void setBits(CharMatcher.LookupTable table) {
/*  530 */         char c = this.val$startInclusive;
/*      */         while (true) {
/*  532 */           table.set(c);
/*  533 */           c = (char)(c + '\001'); if (c == this.val$endInclusive)
/*  534 */             break;
/*      */         }
/*      */       }
/*      */ 
/*      */       public CharMatcher precomputed()
/*      */       {
/*  540 */         return this;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static CharMatcher forPredicate(Predicate<? super Character> predicate)
/*      */   {
/*  550 */     Preconditions.checkNotNull(predicate);
/*  551 */     if ((predicate instanceof CharMatcher)) {
/*  552 */       return (CharMatcher)predicate;
/*      */     }
/*  554 */     return new CharMatcher(predicate) {
/*      */       public boolean matches(char c) {
/*  556 */         return this.val$predicate.apply(Character.valueOf(c));
/*      */       }
/*      */ 
/*      */       public boolean apply(Character character) {
/*  560 */         return this.val$predicate.apply(Preconditions.checkNotNull(character));
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public abstract boolean matches(char paramChar);
/*      */ 
/*      */   public CharMatcher negate()
/*      */   {
/*  576 */     CharMatcher original = this;
/*  577 */     return new CharMatcher(original) {
/*      */       public boolean matches(char c) {
/*  579 */         return !this.val$original.matches(c);
/*      */       }
/*      */ 
/*      */       public boolean matchesAllOf(CharSequence sequence) {
/*  583 */         return this.val$original.matchesNoneOf(sequence);
/*      */       }
/*      */ 
/*      */       public boolean matchesNoneOf(CharSequence sequence) {
/*  587 */         return this.val$original.matchesAllOf(sequence);
/*      */       }
/*      */ 
/*      */       public int countIn(CharSequence sequence) {
/*  591 */         return sequence.length() - this.val$original.countIn(sequence);
/*      */       }
/*      */ 
/*      */       public CharMatcher negate() {
/*  595 */         return this.val$original;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public CharMatcher and(CharMatcher other)
/*      */   {
/*  604 */     return new And(Arrays.asList(new CharMatcher[] { this, (CharMatcher)Preconditions.checkNotNull(other) }));
/*      */   }
/*      */ 
/*      */   public CharMatcher or(CharMatcher other)
/*      */   {
/*  634 */     return new Or(Arrays.asList(new CharMatcher[] { this, (CharMatcher)Preconditions.checkNotNull(other) }));
/*      */   }
/*      */ 
/*      */   public CharMatcher precomputed()
/*      */   {
/*  676 */     return Platform.precomputeCharMatcher(this);
/*      */   }
/*      */ 
/*      */   CharMatcher precomputedInternal()
/*      */   {
/*  691 */     LookupTable table = new LookupTable(null);
/*  692 */     setBits(table);
/*      */ 
/*  694 */     return new CharMatcher(table) {
/*      */       public boolean matches(char c) {
/*  696 */         return this.val$table.get(c);
/*      */       }
/*      */ 
/*      */       public CharMatcher precomputed()
/*      */       {
/*  702 */         return this;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   void setBits(LookupTable table)
/*      */   {
/*  715 */     char c = '\000';
/*      */     while (true) {
/*  717 */       if (matches(c)) {
/*  718 */         table.set(c);
/*      */       }
/*  720 */       c = (char)(c + '\001'); if (c == 65535)
/*  721 */         break;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean matchesAllOf(CharSequence sequence)
/*      */   {
/*  757 */     for (int i = sequence.length() - 1; i >= 0; i--) {
/*  758 */       if (!matches(sequence.charAt(i))) {
/*  759 */         return false;
/*      */       }
/*      */     }
/*  762 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean matchesNoneOf(CharSequence sequence)
/*      */   {
/*  776 */     return indexIn(sequence) == -1;
/*      */   }
/*      */ 
/*      */   public int indexIn(CharSequence sequence)
/*      */   {
/*  792 */     int length = sequence.length();
/*  793 */     for (int i = 0; i < length; i++) {
/*  794 */       if (matches(sequence.charAt(i))) {
/*  795 */         return i;
/*      */       }
/*      */     }
/*  798 */     return -1;
/*      */   }
/*      */ 
/*      */   public int indexIn(CharSequence sequence, int start)
/*      */   {
/*  817 */     int length = sequence.length();
/*  818 */     Preconditions.checkPositionIndex(start, length);
/*  819 */     for (int i = start; i < length; i++) {
/*  820 */       if (matches(sequence.charAt(i))) {
/*  821 */         return i;
/*      */       }
/*      */     }
/*  824 */     return -1;
/*      */   }
/*      */ 
/*      */   public int lastIndexIn(CharSequence sequence)
/*      */   {
/*  838 */     for (int i = sequence.length() - 1; i >= 0; i--) {
/*  839 */       if (matches(sequence.charAt(i))) {
/*  840 */         return i;
/*      */       }
/*      */     }
/*  843 */     return -1;
/*      */   }
/*      */ 
/*      */   public int countIn(CharSequence sequence)
/*      */   {
/*  850 */     int count = 0;
/*  851 */     for (int i = 0; i < sequence.length(); i++) {
/*  852 */       if (matches(sequence.charAt(i))) {
/*  853 */         count++;
/*      */       }
/*      */     }
/*  856 */     return count;
/*      */   }
/*      */ 
/*      */   public String removeFrom(CharSequence sequence)
/*      */   {
/*  868 */     String string = sequence.toString();
/*  869 */     int pos = indexIn(string);
/*  870 */     if (pos == -1) {
/*  871 */       return string;
/*      */     }
/*      */ 
/*  874 */     char[] chars = string.toCharArray();
/*  875 */     int spread = 1;
/*      */     while (true)
/*      */     {
/*  879 */       pos++;
/*      */       while (true) {
/*  881 */         if (pos == chars.length)
/*      */           break label77;
/*  884 */         if (matches(chars[pos])) {
/*      */           break;
/*      */         }
/*  887 */         chars[(pos - spread)] = chars[pos];
/*  888 */         pos++;
/*      */       }
/*  890 */       spread++;
/*      */     }
/*  892 */     label77: return new String(chars, 0, pos - spread);
/*      */   }
/*      */ 
/*      */   public String retainFrom(CharSequence sequence)
/*      */   {
/*  904 */     return negate().removeFrom(sequence);
/*      */   }
/*      */ 
/*      */   public String replaceFrom(CharSequence sequence, char replacement)
/*      */   {
/*  925 */     String string = sequence.toString();
/*  926 */     int pos = indexIn(string);
/*  927 */     if (pos == -1) {
/*  928 */       return string;
/*      */     }
/*  930 */     char[] chars = string.toCharArray();
/*  931 */     chars[pos] = replacement;
/*  932 */     for (int i = pos + 1; i < chars.length; i++) {
/*  933 */       if (matches(chars[i])) {
/*  934 */         chars[i] = replacement;
/*      */       }
/*      */     }
/*  937 */     return new String(chars);
/*      */   }
/*      */ 
/*      */   public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*      */   {
/*  957 */     int replacementLen = replacement.length();
/*  958 */     if (replacementLen == 0) {
/*  959 */       return removeFrom(sequence);
/*      */     }
/*  961 */     if (replacementLen == 1) {
/*  962 */       return replaceFrom(sequence, replacement.charAt(0));
/*      */     }
/*      */ 
/*  965 */     String string = sequence.toString();
/*  966 */     int pos = indexIn(string);
/*  967 */     if (pos == -1) {
/*  968 */       return string;
/*      */     }
/*      */ 
/*  971 */     int len = string.length();
/*  972 */     StringBuilder buf = new StringBuilder(len * 3 / 2 + 16);
/*      */ 
/*  974 */     int oldpos = 0;
/*      */     do {
/*  976 */       buf.append(string, oldpos, pos);
/*  977 */       buf.append(replacement);
/*  978 */       oldpos = pos + 1;
/*  979 */       pos = indexIn(string, oldpos);
/*  980 */     }while (pos != -1);
/*      */ 
/*  982 */     buf.append(string, oldpos, len);
/*  983 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public String trimFrom(CharSequence sequence)
/*      */   {
/* 1001 */     int len = sequence.length();
/*      */ 
/* 1005 */     for (int first = 0; (first < len) && 
/* 1006 */       (matches(sequence.charAt(first))); first++);
/* 1010 */     for (int last = len - 1; (last > first) && 
/* 1011 */       (matches(sequence.charAt(last))); last--);
/* 1016 */     return sequence.subSequence(first, last + 1).toString();
/*      */   }
/*      */ 
/*      */   public String trimLeadingFrom(CharSequence sequence)
/*      */   {
/* 1028 */     int len = sequence.length();
/*      */ 
/* 1031 */     for (int first = 0; (first < len) && 
/* 1032 */       (matches(sequence.charAt(first))); first++);
/* 1037 */     return sequence.subSequence(first, len).toString();
/*      */   }
/*      */ 
/*      */   public String trimTrailingFrom(CharSequence sequence)
/*      */   {
/* 1049 */     int len = sequence.length();
/*      */ 
/* 1052 */     for (int last = len - 1; (last >= 0) && 
/* 1053 */       (matches(sequence.charAt(last))); last--);
/* 1058 */     return sequence.subSequence(0, last + 1).toString();
/*      */   }
/*      */ 
/*      */   public String collapseFrom(CharSequence sequence, char replacement)
/*      */   {
/* 1080 */     int first = indexIn(sequence);
/* 1081 */     if (first == -1) {
/* 1082 */       return sequence.toString();
/*      */     }
/*      */ 
/* 1087 */     StringBuilder builder = new StringBuilder(sequence.length()).append(sequence.subSequence(0, first)).append(replacement);
/*      */ 
/* 1090 */     boolean in = true;
/* 1091 */     for (int i = first + 1; i < sequence.length(); i++) {
/* 1092 */       char c = sequence.charAt(i);
/* 1093 */       if (apply(Character.valueOf(c))) {
/* 1094 */         if (!in) {
/* 1095 */           builder.append(replacement);
/* 1096 */           in = true;
/*      */         }
/*      */       } else {
/* 1099 */         builder.append(c);
/* 1100 */         in = false;
/*      */       }
/*      */     }
/* 1103 */     return builder.toString();
/*      */   }
/*      */ 
/*      */   public String trimAndCollapseFrom(CharSequence sequence, char replacement)
/*      */   {
/* 1112 */     int first = negate().indexIn(sequence);
/* 1113 */     if (first == -1) {
/* 1114 */       return "";
/*      */     }
/* 1116 */     StringBuilder builder = new StringBuilder(sequence.length());
/* 1117 */     boolean inMatchingGroup = false;
/* 1118 */     for (int i = first; i < sequence.length(); i++) {
/* 1119 */       char c = sequence.charAt(i);
/* 1120 */       if (apply(Character.valueOf(c))) {
/* 1121 */         inMatchingGroup = true;
/*      */       } else {
/* 1123 */         if (inMatchingGroup) {
/* 1124 */           builder.append(replacement);
/* 1125 */           inMatchingGroup = false;
/*      */         }
/* 1127 */         builder.append(c);
/*      */       }
/*      */     }
/* 1130 */     return builder.toString();
/*      */   }
/*      */ 
/*      */   public boolean apply(Character character)
/*      */   {
/* 1141 */     return matches(character.charValue());
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  100 */     CharMatcher digit = inRange('0', '9');
/*  101 */     String zeroes = "٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０";
/*      */ 
/*  105 */     for (char base : zeroes.toCharArray()) {
/*  106 */       digit = digit.or(inRange(base, (char)(base + '\t')));
/*      */     }
/*  108 */     DIGIT = digit.precomputed();
/*      */ 
/*  117 */     JAVA_WHITESPACE = inRange('\t', '\r').or(inRange('\034', ' ')).or(is(' ')).or(is('᠎')).or(inRange(' ', ' ')).or(inRange(' ', '​')).or(inRange(' ', ' ')).or(is(' ')).or(is('　')).precomputed();
/*      */ 
/*  133 */     JAVA_DIGIT = new CharMatcher() {
/*      */       public boolean matches(char c) {
/*  135 */         return Character.isDigit(c);
/*      */       }
/*      */     };
/*  144 */     JAVA_LETTER = new CharMatcher() {
/*      */       public boolean matches(char c) {
/*  146 */         return Character.isLetter(c);
/*      */       }
/*      */     };
/*  154 */     JAVA_LETTER_OR_DIGIT = new CharMatcher() {
/*      */       public boolean matches(char c) {
/*  156 */         return Character.isLetterOrDigit(c);
/*      */       }
/*      */     };
/*  164 */     JAVA_UPPER_CASE = new CharMatcher() {
/*      */       public boolean matches(char c) {
/*  166 */         return Character.isUpperCase(c);
/*      */       }
/*      */     };
/*  174 */     JAVA_LOWER_CASE = new CharMatcher() {
/*      */       public boolean matches(char c) {
/*  176 */         return Character.isLowerCase(c);
/*      */       }
/*      */     };
/*  184 */     JAVA_ISO_CONTROL = inRange('\000', '\037').or(inRange('', ''));
/*      */ 
/*  192 */     INVISIBLE = inRange('\000', ' ').or(inRange('', ' ')).or(is('­')).or(inRange('؀', '؃')).or(anyOf("۝܏ ឴឵᠎")).or(inRange(' ', '‏')).or(inRange(' ', ' ')).or(inRange(' ', '⁤')).or(inRange('⁪', '⁯')).or(is('　')).or(inRange(55296, 63743)).or(anyOf("﻿￹￺￻")).precomputed();
/*      */ 
/*  214 */     SINGLE_WIDTH = inRange('\000', 'ӹ').or(is('־')).or(inRange('א', 'ת')).or(is('׳')).or(is('״')).or(inRange('؀', 'ۿ')).or(inRange('ݐ', 'ݿ')).or(inRange('฀', '๿')).or(inRange('Ḁ', '₯')).or(inRange('℀', '℺')).or(inRange(64336, 65023)).or(inRange(65136, 65279)).or(inRange(65377, 65500)).precomputed();
/*      */ 
/*  239 */     LEGACY_WHITESPACE = anyOf(" \r\n\t　   ").precomputed();
/*      */ 
/*  243 */     ANY = new CharMatcher()
/*      */     {
/*      */       public boolean matches(char c) {
/*  246 */         return true;
/*      */       }
/*      */ 
/*      */       public int indexIn(CharSequence sequence) {
/*  250 */         return sequence.length() == 0 ? -1 : 0;
/*      */       }
/*      */ 
/*      */       public int indexIn(CharSequence sequence, int start) {
/*  254 */         int length = sequence.length();
/*  255 */         Preconditions.checkPositionIndex(start, length);
/*  256 */         return start == length ? -1 : start;
/*      */       }
/*      */ 
/*      */       public int lastIndexIn(CharSequence sequence) {
/*  260 */         return sequence.length() - 1;
/*      */       }
/*      */ 
/*      */       public boolean matchesAllOf(CharSequence sequence) {
/*  264 */         Preconditions.checkNotNull(sequence);
/*  265 */         return true;
/*      */       }
/*      */ 
/*      */       public boolean matchesNoneOf(CharSequence sequence) {
/*  269 */         return sequence.length() == 0;
/*      */       }
/*      */ 
/*      */       public String removeFrom(CharSequence sequence) {
/*  273 */         Preconditions.checkNotNull(sequence);
/*  274 */         return "";
/*      */       }
/*      */ 
/*      */       public String replaceFrom(CharSequence sequence, char replacement) {
/*  278 */         char[] array = new char[sequence.length()];
/*  279 */         Arrays.fill(array, replacement);
/*  280 */         return new String(array);
/*      */       }
/*      */ 
/*      */       public String replaceFrom(CharSequence sequence, CharSequence replacement) {
/*  284 */         StringBuilder retval = new StringBuilder(sequence.length() * replacement.length());
/*  285 */         for (int i = 0; i < sequence.length(); i++) {
/*  286 */           retval.append(replacement);
/*      */         }
/*  288 */         return retval.toString();
/*      */       }
/*      */ 
/*      */       public String collapseFrom(CharSequence sequence, char replacement) {
/*  292 */         return sequence.length() == 0 ? "" : String.valueOf(replacement);
/*      */       }
/*      */ 
/*      */       public String trimFrom(CharSequence sequence) {
/*  296 */         Preconditions.checkNotNull(sequence);
/*  297 */         return "";
/*      */       }
/*      */ 
/*      */       public int countIn(CharSequence sequence) {
/*  301 */         return sequence.length();
/*      */       }
/*      */ 
/*      */       public CharMatcher and(CharMatcher other) {
/*  305 */         return (CharMatcher)Preconditions.checkNotNull(other);
/*      */       }
/*      */ 
/*      */       public CharMatcher or(CharMatcher other) {
/*  309 */         Preconditions.checkNotNull(other);
/*  310 */         return this;
/*      */       }
/*      */ 
/*      */       public CharMatcher negate() {
/*  314 */         return NONE;
/*      */       }
/*      */ 
/*      */       public CharMatcher precomputed() {
/*  318 */         return this;
/*      */       }
/*      */     };
/*  323 */     NONE = new CharMatcher()
/*      */     {
/*      */       public boolean matches(char c) {
/*  326 */         return false;
/*      */       }
/*      */ 
/*      */       public int indexIn(CharSequence sequence) {
/*  330 */         Preconditions.checkNotNull(sequence);
/*  331 */         return -1;
/*      */       }
/*      */ 
/*      */       public int indexIn(CharSequence sequence, int start) {
/*  335 */         int length = sequence.length();
/*  336 */         Preconditions.checkPositionIndex(start, length);
/*  337 */         return -1;
/*      */       }
/*      */ 
/*      */       public int lastIndexIn(CharSequence sequence) {
/*  341 */         Preconditions.checkNotNull(sequence);
/*  342 */         return -1;
/*      */       }
/*      */ 
/*      */       public boolean matchesAllOf(CharSequence sequence) {
/*  346 */         return sequence.length() == 0;
/*      */       }
/*      */ 
/*      */       public boolean matchesNoneOf(CharSequence sequence) {
/*  350 */         Preconditions.checkNotNull(sequence);
/*  351 */         return true;
/*      */       }
/*      */ 
/*      */       public String removeFrom(CharSequence sequence) {
/*  355 */         return sequence.toString();
/*      */       }
/*      */ 
/*      */       public String replaceFrom(CharSequence sequence, char replacement) {
/*  359 */         return sequence.toString();
/*      */       }
/*      */ 
/*      */       public String replaceFrom(CharSequence sequence, CharSequence replacement) {
/*  363 */         Preconditions.checkNotNull(replacement);
/*  364 */         return sequence.toString();
/*      */       }
/*      */ 
/*      */       public String collapseFrom(CharSequence sequence, char replacement) {
/*  368 */         return sequence.toString();
/*      */       }
/*      */ 
/*      */       public String trimFrom(CharSequence sequence) {
/*  372 */         return sequence.toString();
/*      */       }
/*      */ 
/*      */       public int countIn(CharSequence sequence) {
/*  376 */         Preconditions.checkNotNull(sequence);
/*  377 */         return 0;
/*      */       }
/*      */ 
/*      */       public CharMatcher and(CharMatcher other) {
/*  381 */         Preconditions.checkNotNull(other);
/*  382 */         return this;
/*      */       }
/*      */ 
/*      */       public CharMatcher or(CharMatcher other) {
/*  386 */         return (CharMatcher)Preconditions.checkNotNull(other);
/*      */       }
/*      */ 
/*      */       public CharMatcher negate() {
/*  390 */         return ANY;
/*      */       }
/*      */       void setBits(CharMatcher.LookupTable table) {
/*      */       }
/*      */ 
/*      */       public CharMatcher precomputed() {
/*  396 */         return this;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private static final class LookupTable
/*      */   {
/*  733 */     int[] data = new int[2048];
/*      */ 
/*      */     void set(char index) {
/*  736 */       this.data[(index >> '\005')] |= '\001' << index;
/*      */     }
/*      */ 
/*      */     boolean get(char index) {
/*  740 */       return (this.data[(index >> '\005')] & '\001' << index) != 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class Or extends CharMatcher
/*      */   {
/*      */     List<CharMatcher> components;
/*      */ 
/*      */     Or(List<CharMatcher> components)
/*      */     {
/*  641 */       this.components = components;
/*      */     }
/*      */ 
/*      */     public boolean matches(char c) {
/*  645 */       for (CharMatcher matcher : this.components) {
/*  646 */         if (matcher.matches(c)) {
/*  647 */           return true;
/*      */         }
/*      */       }
/*  650 */       return false;
/*      */     }
/*      */ 
/*      */     public CharMatcher or(CharMatcher other) {
/*  654 */       List newComponents = new ArrayList(this.components);
/*  655 */       newComponents.add(Preconditions.checkNotNull(other));
/*  656 */       return new Or(newComponents);
/*      */     }
/*      */ 
/*      */     void setBits(CharMatcher.LookupTable table) {
/*  660 */       for (CharMatcher matcher : this.components)
/*  661 */         matcher.setBits(table);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class And extends CharMatcher
/*      */   {
/*      */     List<CharMatcher> components;
/*      */ 
/*      */     And(List<CharMatcher> components)
/*      */     {
/*  611 */       this.components = components;
/*      */     }
/*      */ 
/*      */     public boolean matches(char c) {
/*  615 */       for (CharMatcher matcher : this.components) {
/*  616 */         if (!matcher.matches(c)) {
/*  617 */           return false;
/*      */         }
/*      */       }
/*  620 */       return true;
/*      */     }
/*      */ 
/*      */     public CharMatcher and(CharMatcher other) {
/*  624 */       List newComponents = new ArrayList(this.components);
/*  625 */       newComponents.add(Preconditions.checkNotNull(other));
/*  626 */       return new And(newComponents);
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.CharMatcher
 * JD-Core Version:    0.6.0
 */