/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public final class Expiration
/*    */ {
/*    */   private boolean isOffset;
/*    */   private long millis;
/*    */ 
/*    */   public static Expiration onDate(Date expirationTime)
/*    */   {
/* 30 */     return new Expiration(expirationTime.getTime(), false);
/*    */   }
/*    */ 
/*    */   public static Expiration byDeltaMillis(int milliDelay)
/*    */   {
/* 42 */     return new Expiration(milliDelay, true);
/*    */   }
/*    */ 
/*    */   public static Expiration byDeltaSeconds(int secondsDelay)
/*    */   {
/* 53 */     return byDeltaMillis(secondsDelay * 1000);
/*    */   }
/*    */ 
/*    */   private Expiration(long millis, boolean isOffset) {
/* 57 */     this.millis = millis;
/* 58 */     this.isOffset = isOffset;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj) {
/* 62 */     if ((obj instanceof Expiration)) {
/* 63 */       return (((Expiration)obj).millis == this.millis) && (((Expiration)obj).isOffset == this.isOffset);
/*    */     }
/*    */ 
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 70 */     return (int)this.millis;
/*    */   }
/*    */ 
/*    */   public long getMillisecondsValue()
/*    */   {
/* 80 */     if (this.isOffset) {
/* 81 */       return System.currentTimeMillis() + this.millis;
/*    */     }
/* 83 */     return this.millis;
/*    */   }
/*    */ 
/*    */   public int getSecondsValue()
/*    */   {
/* 94 */     return (int)(getMillisecondsValue() / 1000L);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.Expiration
 * JD-Core Version:    0.6.0
 */