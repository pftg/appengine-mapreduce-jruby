/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ final class EmptyImmutableList extends ImmutableList<Object>
/*     */ {
/*  39 */   static final EmptyImmutableList INSTANCE = new EmptyImmutableList();
/*     */ 
/*  59 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public int size()
/*     */   {
/*  44 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  48 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean contains(Object target) {
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */   public UnmodifiableIterator<Object> iterator() {
/*  56 */     return Iterators.emptyIterator();
/*     */   }
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/*  62 */     return EMPTY_ARRAY;
/*     */   }
/*     */ 
/*     */   public <T> T[] toArray(T[] a) {
/*  66 */     if (a.length > 0) {
/*  67 */       a[0] = null;
/*     */     }
/*  69 */     return a;
/*     */   }
/*     */ 
/*     */   public Object get(int index)
/*     */   {
/*  74 */     Preconditions.checkElementIndex(index, 0);
/*  75 */     throw new AssertionError("unreachable");
/*     */   }
/*     */ 
/*     */   public int indexOf(Object target) {
/*  79 */     return -1;
/*     */   }
/*     */ 
/*     */   public int lastIndexOf(Object target) {
/*  83 */     return -1;
/*     */   }
/*     */ 
/*     */   public ImmutableList<Object> subList(int fromIndex, int toIndex) {
/*  87 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, 0);
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   public ListIterator<Object> listIterator() {
/*  92 */     return Collections.emptyList().listIterator();
/*     */   }
/*     */ 
/*     */   public ListIterator<Object> listIterator(int start) {
/*  96 */     Preconditions.checkPositionIndex(start, 0);
/*  97 */     return Collections.emptyList().listIterator();
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection<?> targets) {
/* 101 */     return targets.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object) {
/* 105 */     if ((object instanceof List)) {
/* 106 */       List that = (List)object;
/* 107 */       return that.isEmpty();
/*     */     }
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 113 */     return 1;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 117 */     return "[]";
/*     */   }
/*     */ 
/*     */   Object readResolve() {
/* 121 */     return INSTANCE;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.EmptyImmutableList
 * JD-Core Version:    0.6.0
 */