/*    */ package com.google.appengine.api.blobstore;
/*    */ 
/*    */ public final class BlobstoreServiceFactory
/*    */ {
/*    */   public static BlobstoreService getBlobstoreService()
/*    */   {
/* 16 */     return new BlobstoreServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobstoreServiceFactory
 * JD-Core Version:    0.6.0
 */