/*      */ package com.google.appengine.repackaged.com.google.protobuf;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public abstract class GeneratedMessage extends AbstractMessage
/*      */   implements Serializable
/*      */ {
/*      */   private final UnknownFieldSet unknownFields;
/*      */ 
/*      */   protected GeneratedMessage()
/*      */   {
/*   35 */     this.unknownFields = UnknownFieldSet.getDefaultInstance();
/*      */   }
/*      */ 
/*      */   protected GeneratedMessage(Builder<?> builder) {
/*   39 */     this.unknownFields = builder.getUnknownFields();
/*      */   }
/*      */ 
/*      */   protected abstract FieldAccessorTable internalGetFieldAccessorTable();
/*      */ 
/*      */   public Descriptors.Descriptor getDescriptorForType()
/*      */   {
/*   50 */     return internalGetFieldAccessorTable().descriptor;
/*      */   }
/*      */ 
/*      */   private Map<Descriptors.FieldDescriptor, Object> getAllFieldsMutable()
/*      */   {
/*   55 */     TreeMap result = new TreeMap();
/*      */ 
/*   57 */     Descriptors.Descriptor descriptor = internalGetFieldAccessorTable().descriptor;
/*   58 */     for (Descriptors.FieldDescriptor field : descriptor.getFields()) {
/*   59 */       if (field.isRepeated()) {
/*   60 */         List value = (List)getField(field);
/*   61 */         if (!value.isEmpty()) {
/*   62 */           result.put(field, value);
/*      */         }
/*      */       }
/*   65 */       else if (hasField(field)) {
/*   66 */         result.put(field, getField(field));
/*      */       }
/*      */     }
/*      */ 
/*   70 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean isInitialized()
/*      */   {
/*   75 */     for (Descriptors.FieldDescriptor field : getDescriptorForType().getFields())
/*      */     {
/*   77 */       if ((field.isRequired()) && 
/*   78 */         (!hasField(field))) {
/*   79 */         return false;
/*      */       }
/*      */ 
/*   83 */       if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/*   84 */         if (field.isRepeated())
/*      */         {
/*   86 */           List messageList = (List)getField(field);
/*   87 */           for (Message element : messageList) {
/*   88 */             if (!element.isInitialized()) {
/*   89 */               return false;
/*      */             }
/*      */           }
/*      */         }
/*   93 */         else if ((hasField(field)) && (!((Message)getField(field)).isInitialized())) {
/*   94 */           return false;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  100 */     return true;
/*      */   }
/*      */ 
/*      */   public Map<Descriptors.FieldDescriptor, Object> getAllFields() {
/*  104 */     return Collections.unmodifiableMap(getAllFieldsMutable());
/*      */   }
/*      */ 
/*      */   public boolean hasField(Descriptors.FieldDescriptor field) {
/*  108 */     return internalGetFieldAccessorTable().getField(field).has(this);
/*      */   }
/*      */ 
/*      */   public Object getField(Descriptors.FieldDescriptor field) {
/*  112 */     return internalGetFieldAccessorTable().getField(field).get(this);
/*      */   }
/*      */ 
/*      */   public int getRepeatedFieldCount(Descriptors.FieldDescriptor field) {
/*  116 */     return internalGetFieldAccessorTable().getField(field).getRepeatedCount(this);
/*      */   }
/*      */ 
/*      */   public Object getRepeatedField(Descriptors.FieldDescriptor field, int index)
/*      */   {
/*  121 */     return internalGetFieldAccessorTable().getField(field).getRepeated(this, index);
/*      */   }
/*      */ 
/*      */   public final UnknownFieldSet getUnknownFields()
/*      */   {
/*  126 */     return this.unknownFields;
/*      */   }
/*      */ 
/*      */   public static <ContainingType extends Message, Type> GeneratedExtension<ContainingType, Type> newGeneratedExtension()
/*      */   {
/*  899 */     return new GeneratedExtension(null);
/*      */   }
/*      */ 
/*      */   private static Method getMethodOrDie(Class clazz, String name, Class[] params)
/*      */   {
/*      */     try
/*      */     {
/* 1096 */       return clazz.getMethod(name, params); } catch (NoSuchMethodException e) {
/*      */     }
/* 1098 */     throw new RuntimeException("Generated message class \"" + clazz.getName() + "\" missing method \"" + name + "\".", e);
/*      */   }
/*      */ 
/*      */   private static Object invokeOrDie(Method method, Object object, Object[] params)
/*      */   {
/*      */     Throwable cause;
/*      */     try
/*      */     {
/* 1108 */       return method.invoke(object, params);
/*      */     } catch (IllegalAccessException e) {
/* 1110 */       throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e);
/*      */     }
/*      */     catch (InvocationTargetException e)
/*      */     {
/* 1114 */       cause = e.getCause();
/* 1115 */       if ((cause instanceof RuntimeException))
/* 1116 */         throw ((RuntimeException)cause);
/* 1117 */       if ((cause instanceof Error))
/* 1118 */         throw ((Error)cause);
/*      */     }
/* 1120 */     throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
/*      */   }
/*      */ 
/*      */   protected Object writeReplace()
/*      */     throws ObjectStreamException
/*      */   {
/* 1571 */     return new GeneratedMessageLite.SerializedForm(this);
/*      */   }
/*      */ 
/*      */   public static final class FieldAccessorTable
/*      */   {
/*      */     private final Descriptors.Descriptor descriptor;
/*      */     private final FieldAccessor[] fields;
/*      */ 
/*      */     public FieldAccessorTable(Descriptors.Descriptor descriptor, String[] camelCaseNames, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */     {
/* 1147 */       this.descriptor = descriptor;
/* 1148 */       this.fields = new FieldAccessor[descriptor.getFields().size()];
/*      */ 
/* 1150 */       for (int i = 0; i < this.fields.length; i++) {
/* 1151 */         Descriptors.FieldDescriptor field = (Descriptors.FieldDescriptor)descriptor.getFields().get(i);
/* 1152 */         if (field.isRepeated()) {
/* 1153 */           if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 1154 */             this.fields[i] = new RepeatedMessageFieldAccessor(field, camelCaseNames[i], messageClass, builderClass);
/*      */           }
/* 1156 */           else if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.ENUM) {
/* 1157 */             this.fields[i] = new RepeatedEnumFieldAccessor(field, camelCaseNames[i], messageClass, builderClass);
/*      */           }
/*      */           else {
/* 1160 */             this.fields[i] = new RepeatedFieldAccessor(field, camelCaseNames[i], messageClass, builderClass);
/*      */           }
/*      */ 
/*      */         }
/* 1164 */         else if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 1165 */           this.fields[i] = new SingularMessageFieldAccessor(field, camelCaseNames[i], messageClass, builderClass);
/*      */         }
/* 1167 */         else if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.ENUM) {
/* 1168 */           this.fields[i] = new SingularEnumFieldAccessor(field, camelCaseNames[i], messageClass, builderClass);
/*      */         }
/*      */         else
/* 1171 */           this.fields[i] = new SingularFieldAccessor(field, camelCaseNames[i], messageClass, builderClass);
/*      */       }
/*      */     }
/*      */ 
/*      */     private FieldAccessor getField(Descriptors.FieldDescriptor field)
/*      */     {
/* 1183 */       if (field.getContainingType() != this.descriptor) {
/* 1184 */         throw new IllegalArgumentException("FieldDescriptor does not match message type.");
/*      */       }
/* 1186 */       if (field.isExtension())
/*      */       {
/* 1189 */         throw new IllegalArgumentException("This type does not have extensions.");
/*      */       }
/*      */ 
/* 1192 */       return this.fields[field.getIndex()];
/*      */     }
/*      */ 
/*      */     private static final class RepeatedMessageFieldAccessor extends GeneratedMessage.FieldAccessorTable.RepeatedFieldAccessor
/*      */     {
/*      */       private final Method newBuilderMethod;
/*      */ 
/*      */       RepeatedMessageFieldAccessor(Descriptors.FieldDescriptor descriptor, String camelCaseName, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */       {
/* 1528 */         super(camelCaseName, messageClass, builderClass);
/*      */ 
/* 1530 */         this.newBuilderMethod = GeneratedMessage.access$1200(this.type, "newBuilder", new Class[0]);
/*      */       }
/*      */ 
/*      */       private Object coerceType(Object value)
/*      */       {
/* 1536 */         if (this.type.isInstance(value)) {
/* 1537 */           return value;
/*      */         }
/*      */ 
/* 1543 */         return ((Message.Builder)GeneratedMessage.access$1300(this.newBuilderMethod, null, new Object[0])).mergeFrom((Message)value).build();
/*      */       }
/*      */ 
/*      */       public void setRepeated(GeneratedMessage.Builder builder, int index, Object value)
/*      */       {
/* 1551 */         super.setRepeated(builder, index, coerceType(value));
/*      */       }
/*      */ 
/*      */       public void addRepeated(GeneratedMessage.Builder builder, Object value) {
/* 1555 */         super.addRepeated(builder, coerceType(value));
/*      */       }
/*      */ 
/*      */       public Message.Builder newBuilder() {
/* 1559 */         return (Message.Builder)GeneratedMessage.access$1300(this.newBuilderMethod, null, new Object[0]);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class SingularMessageFieldAccessor extends GeneratedMessage.FieldAccessorTable.SingularFieldAccessor
/*      */     {
/*      */       private final Method newBuilderMethod;
/*      */ 
/*      */       SingularMessageFieldAccessor(Descriptors.FieldDescriptor descriptor, String camelCaseName, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */       {
/* 1492 */         super(camelCaseName, messageClass, builderClass);
/*      */ 
/* 1494 */         this.newBuilderMethod = GeneratedMessage.access$1200(this.type, "newBuilder", new Class[0]);
/*      */       }
/*      */ 
/*      */       private Object coerceType(Object value)
/*      */       {
/* 1500 */         if (this.type.isInstance(value)) {
/* 1501 */           return value;
/*      */         }
/*      */ 
/* 1507 */         return ((Message.Builder)GeneratedMessage.access$1300(this.newBuilderMethod, null, new Object[0])).mergeFrom((Message)value).build();
/*      */       }
/*      */ 
/*      */       public void set(GeneratedMessage.Builder builder, Object value)
/*      */       {
/* 1514 */         super.set(builder, coerceType(value));
/*      */       }
/*      */ 
/*      */       public Message.Builder newBuilder() {
/* 1518 */         return (Message.Builder)GeneratedMessage.access$1300(this.newBuilderMethod, null, new Object[0]);
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class RepeatedEnumFieldAccessor extends GeneratedMessage.FieldAccessorTable.RepeatedFieldAccessor
/*      */     {
/*      */       private final Method valueOfMethod;
/*      */       private final Method getValueDescriptorMethod;
/*      */ 
/*      */       RepeatedEnumFieldAccessor(Descriptors.FieldDescriptor descriptor, String camelCaseName, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */       {
/* 1429 */         super(camelCaseName, messageClass, builderClass);
/*      */ 
/* 1431 */         this.valueOfMethod = GeneratedMessage.access$1200(this.type, "valueOf", new Class[] { Descriptors.EnumValueDescriptor.class });
/*      */ 
/* 1433 */         this.getValueDescriptorMethod = GeneratedMessage.access$1200(this.type, "getValueDescriptor", new Class[0]);
/*      */       }
/*      */ 
/*      */       public Object get(GeneratedMessage message)
/*      */       {
/* 1443 */         List newList = new ArrayList();
/* 1444 */         for (Iterator i$ = ((List)super.get(message)).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 1445 */           newList.add(GeneratedMessage.access$1300(this.getValueDescriptorMethod, element, new Object[0]));
/*      */         }
/* 1447 */         return Collections.unmodifiableList(newList);
/*      */       }
/*      */ 
/*      */       public Object get(GeneratedMessage.Builder builder)
/*      */       {
/* 1453 */         List newList = new ArrayList();
/* 1454 */         for (Iterator i$ = ((List)super.get(builder)).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 1455 */           newList.add(GeneratedMessage.access$1300(this.getValueDescriptorMethod, element, new Object[0]));
/*      */         }
/* 1457 */         return Collections.unmodifiableList(newList);
/*      */       }
/*      */ 
/*      */       public Object getRepeated(GeneratedMessage message, int index)
/*      */       {
/* 1463 */         return GeneratedMessage.access$1300(this.getValueDescriptorMethod, super.getRepeated(message, index), new Object[0]);
/*      */       }
/*      */ 
/*      */       public Object getRepeated(GeneratedMessage.Builder builder, int index)
/*      */       {
/* 1469 */         return GeneratedMessage.access$1300(this.getValueDescriptorMethod, super.getRepeated(builder, index), new Object[0]);
/*      */       }
/*      */ 
/*      */       public void setRepeated(GeneratedMessage.Builder builder, int index, Object value)
/*      */       {
/* 1475 */         super.setRepeated(builder, index, GeneratedMessage.access$1300(this.valueOfMethod, null, new Object[] { value }));
/*      */       }
/*      */ 
/*      */       public void addRepeated(GeneratedMessage.Builder builder, Object value)
/*      */       {
/* 1480 */         super.addRepeated(builder, GeneratedMessage.access$1300(this.valueOfMethod, null, new Object[] { value }));
/*      */       }
/*      */     }
/*      */ 
/*      */     private static final class SingularEnumFieldAccessor extends GeneratedMessage.FieldAccessorTable.SingularFieldAccessor
/*      */     {
/*      */       private Method valueOfMethod;
/*      */       private Method getValueDescriptorMethod;
/*      */ 
/*      */       SingularEnumFieldAccessor(Descriptors.FieldDescriptor descriptor, String camelCaseName, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */       {
/* 1396 */         super(camelCaseName, messageClass, builderClass);
/*      */ 
/* 1398 */         this.valueOfMethod = GeneratedMessage.access$1200(this.type, "valueOf", new Class[] { Descriptors.EnumValueDescriptor.class });
/*      */ 
/* 1400 */         this.getValueDescriptorMethod = GeneratedMessage.access$1200(this.type, "getValueDescriptor", new Class[0]);
/*      */       }
/*      */ 
/*      */       public Object get(GeneratedMessage message)
/*      */       {
/* 1409 */         return GeneratedMessage.access$1300(this.getValueDescriptorMethod, super.get(message), new Object[0]);
/*      */       }
/*      */ 
/*      */       public Object get(GeneratedMessage.Builder builder)
/*      */       {
/* 1414 */         return GeneratedMessage.access$1300(this.getValueDescriptorMethod, super.get(builder), new Object[0]);
/*      */       }
/*      */ 
/*      */       public void set(GeneratedMessage.Builder builder, Object value)
/*      */       {
/* 1419 */         super.set(builder, GeneratedMessage.access$1300(this.valueOfMethod, null, new Object[] { value }));
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class RepeatedFieldAccessor
/*      */       implements GeneratedMessage.FieldAccessorTable.FieldAccessor
/*      */     {
/*      */       protected final Class type;
/*      */       protected final Method getMethod;
/*      */       protected final Method getMethodBuilder;
/*      */       protected final Method getRepeatedMethod;
/*      */       protected final Method getRepeatedMethodBuilder;
/*      */       protected final Method setRepeatedMethod;
/*      */       protected final Method addRepeatedMethod;
/*      */       protected final Method getCountMethod;
/*      */       protected final Method getCountMethodBuilder;
/*      */       protected final Method clearMethod;
/*      */ 
/*      */       RepeatedFieldAccessor(Descriptors.FieldDescriptor descriptor, String camelCaseName, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */       {
/* 1311 */         this.getMethod = GeneratedMessage.access$1200(messageClass, "get" + camelCaseName + "List", new Class[0]);
/*      */ 
/* 1313 */         this.getMethodBuilder = GeneratedMessage.access$1200(builderClass, "get" + camelCaseName + "List", new Class[0]);
/*      */ 
/* 1317 */         this.getRepeatedMethod = GeneratedMessage.access$1200(messageClass, "get" + camelCaseName, new Class[] { Integer.TYPE });
/*      */ 
/* 1319 */         this.getRepeatedMethodBuilder = GeneratedMessage.access$1200(builderClass, "get" + camelCaseName, new Class[] { Integer.TYPE });
/*      */ 
/* 1321 */         this.type = this.getRepeatedMethod.getReturnType();
/* 1322 */         this.setRepeatedMethod = GeneratedMessage.access$1200(builderClass, "set" + camelCaseName, new Class[] { Integer.TYPE, this.type });
/*      */ 
/* 1325 */         this.addRepeatedMethod = GeneratedMessage.access$1200(builderClass, "add" + camelCaseName, new Class[] { this.type });
/*      */ 
/* 1327 */         this.getCountMethod = GeneratedMessage.access$1200(messageClass, "get" + camelCaseName + "Count", new Class[0]);
/*      */ 
/* 1329 */         this.getCountMethodBuilder = GeneratedMessage.access$1200(builderClass, "get" + camelCaseName + "Count", new Class[0]);
/*      */ 
/* 1332 */         this.clearMethod = GeneratedMessage.access$1200(builderClass, "clear" + camelCaseName, new Class[0]);
/*      */       }
/*      */ 
/*      */       public Object get(GeneratedMessage message) {
/* 1336 */         return GeneratedMessage.access$1300(this.getMethod, message, new Object[0]);
/*      */       }
/*      */       public Object get(GeneratedMessage.Builder builder) {
/* 1339 */         return GeneratedMessage.access$1300(this.getMethodBuilder, builder, new Object[0]);
/*      */       }
/*      */ 
/*      */       public void set(GeneratedMessage.Builder builder, Object value)
/*      */       {
/* 1346 */         clear(builder);
/* 1347 */         for (Iterator i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 1348 */           addRepeated(builder, element); }
/*      */       }
/*      */ 
/*      */       public Object getRepeated(GeneratedMessage message, int index)
/*      */       {
/* 1353 */         return GeneratedMessage.access$1300(this.getRepeatedMethod, message, new Object[] { Integer.valueOf(index) });
/*      */       }
/*      */       public Object getRepeated(GeneratedMessage.Builder builder, int index) {
/* 1356 */         return GeneratedMessage.access$1300(this.getRepeatedMethodBuilder, builder, new Object[] { Integer.valueOf(index) });
/*      */       }
/*      */ 
/*      */       public void setRepeated(GeneratedMessage.Builder builder, int index, Object value) {
/* 1360 */         GeneratedMessage.access$1300(this.setRepeatedMethod, builder, new Object[] { Integer.valueOf(index), value });
/*      */       }
/*      */       public void addRepeated(GeneratedMessage.Builder builder, Object value) {
/* 1363 */         GeneratedMessage.access$1300(this.addRepeatedMethod, builder, new Object[] { value });
/*      */       }
/*      */       public boolean has(GeneratedMessage message) {
/* 1366 */         throw new UnsupportedOperationException("hasField() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public boolean has(GeneratedMessage.Builder builder) {
/* 1370 */         throw new UnsupportedOperationException("hasField() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public int getRepeatedCount(GeneratedMessage message) {
/* 1374 */         return ((Integer)GeneratedMessage.access$1300(this.getCountMethod, message, new Object[0])).intValue();
/*      */       }
/*      */       public int getRepeatedCount(GeneratedMessage.Builder builder) {
/* 1377 */         return ((Integer)GeneratedMessage.access$1300(this.getCountMethodBuilder, builder, new Object[0])).intValue();
/*      */       }
/*      */       public void clear(GeneratedMessage.Builder builder) {
/* 1380 */         GeneratedMessage.access$1300(this.clearMethod, builder, new Object[0]);
/*      */       }
/*      */       public Message.Builder newBuilder() {
/* 1383 */         throw new UnsupportedOperationException("newBuilderForField() called on a non-Message type.");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class SingularFieldAccessor
/*      */       implements GeneratedMessage.FieldAccessorTable.FieldAccessor
/*      */     {
/*      */       protected final Class type;
/*      */       protected final Method getMethod;
/*      */       protected final Method getMethodBuilder;
/*      */       protected final Method setMethod;
/*      */       protected final Method hasMethod;
/*      */       protected final Method hasMethodBuilder;
/*      */       protected final Method clearMethod;
/*      */ 
/*      */       SingularFieldAccessor(Descriptors.FieldDescriptor descriptor, String camelCaseName, Class<? extends GeneratedMessage> messageClass, Class<? extends GeneratedMessage.Builder> builderClass)
/*      */       {
/* 1223 */         this.getMethod = GeneratedMessage.access$1200(messageClass, "get" + camelCaseName, new Class[0]);
/* 1224 */         this.getMethodBuilder = GeneratedMessage.access$1200(builderClass, "get" + camelCaseName, new Class[0]);
/* 1225 */         this.type = this.getMethod.getReturnType();
/* 1226 */         this.setMethod = GeneratedMessage.access$1200(builderClass, "set" + camelCaseName, new Class[] { this.type });
/* 1227 */         this.hasMethod = GeneratedMessage.access$1200(messageClass, "has" + camelCaseName, new Class[0]);
/*      */ 
/* 1229 */         this.hasMethodBuilder = GeneratedMessage.access$1200(builderClass, "has" + camelCaseName, new Class[0]);
/*      */ 
/* 1231 */         this.clearMethod = GeneratedMessage.access$1200(builderClass, "clear" + camelCaseName, new Class[0]);
/*      */       }
/*      */ 
/*      */       public Object get(GeneratedMessage message)
/*      */       {
/* 1246 */         return GeneratedMessage.access$1300(this.getMethod, message, new Object[0]);
/*      */       }
/*      */       public Object get(GeneratedMessage.Builder builder) {
/* 1249 */         return GeneratedMessage.access$1300(this.getMethodBuilder, builder, new Object[0]);
/*      */       }
/*      */       public void set(GeneratedMessage.Builder builder, Object value) {
/* 1252 */         GeneratedMessage.access$1300(this.setMethod, builder, new Object[] { value });
/*      */       }
/*      */ 
/*      */       public Object getRepeated(GeneratedMessage message, int index) {
/* 1256 */         throw new UnsupportedOperationException("getRepeatedField() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public Object getRepeated(GeneratedMessage.Builder builder, int index) {
/* 1260 */         throw new UnsupportedOperationException("getRepeatedField() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public void setRepeated(GeneratedMessage.Builder builder, int index, Object value)
/*      */       {
/* 1265 */         throw new UnsupportedOperationException("setRepeatedField() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public void addRepeated(GeneratedMessage.Builder builder, Object value) {
/* 1269 */         throw new UnsupportedOperationException("addRepeatedField() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public boolean has(GeneratedMessage message) {
/* 1273 */         return ((Boolean)GeneratedMessage.access$1300(this.hasMethod, message, new Object[0])).booleanValue();
/*      */       }
/*      */       public boolean has(GeneratedMessage.Builder builder) {
/* 1276 */         return ((Boolean)GeneratedMessage.access$1300(this.hasMethodBuilder, builder, new Object[0])).booleanValue();
/*      */       }
/*      */       public int getRepeatedCount(GeneratedMessage message) {
/* 1279 */         throw new UnsupportedOperationException("getRepeatedFieldSize() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public int getRepeatedCount(GeneratedMessage.Builder builder) {
/* 1283 */         throw new UnsupportedOperationException("getRepeatedFieldSize() called on a singular field.");
/*      */       }
/*      */ 
/*      */       public void clear(GeneratedMessage.Builder builder) {
/* 1287 */         GeneratedMessage.access$1300(this.clearMethod, builder, new Object[0]);
/*      */       }
/*      */       public Message.Builder newBuilder() {
/* 1290 */         throw new UnsupportedOperationException("newBuilderForField() called on a non-Message type.");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static abstract interface FieldAccessor
/*      */     {
/*      */       public abstract Object get(GeneratedMessage paramGeneratedMessage);
/*      */ 
/*      */       public abstract Object get(GeneratedMessage.Builder paramBuilder);
/*      */ 
/*      */       public abstract void set(GeneratedMessage.Builder paramBuilder, Object paramObject);
/*      */ 
/*      */       public abstract Object getRepeated(GeneratedMessage paramGeneratedMessage, int paramInt);
/*      */ 
/*      */       public abstract Object getRepeated(GeneratedMessage.Builder paramBuilder, int paramInt);
/*      */ 
/*      */       public abstract void setRepeated(GeneratedMessage.Builder paramBuilder, int paramInt, Object paramObject);
/*      */ 
/*      */       public abstract void addRepeated(GeneratedMessage.Builder paramBuilder, Object paramObject);
/*      */ 
/*      */       public abstract boolean has(GeneratedMessage paramGeneratedMessage);
/*      */ 
/*      */       public abstract boolean has(GeneratedMessage.Builder paramBuilder);
/*      */ 
/*      */       public abstract int getRepeatedCount(GeneratedMessage paramGeneratedMessage);
/*      */ 
/*      */       public abstract int getRepeatedCount(GeneratedMessage.Builder paramBuilder);
/*      */ 
/*      */       public abstract void clear(GeneratedMessage.Builder paramBuilder);
/*      */ 
/*      */       public abstract Message.Builder newBuilder();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class GeneratedExtension<ContainingType extends Message, Type>
/*      */   {
/*      */     private Descriptors.FieldDescriptor descriptor;
/*      */     private Class type;
/*      */     private Method enumValueOf;
/*      */     private Method enumGetValueDescriptor;
/*      */     private Message messageDefaultInstance;
/*      */ 
/*      */     public void internalInit(Descriptors.FieldDescriptor descriptor, Class type)
/*      */     {
/*  945 */       if (this.descriptor != null) {
/*  946 */         throw new IllegalStateException("Already initialized.");
/*      */       }
/*      */ 
/*  949 */       if (!descriptor.isExtension()) {
/*  950 */         throw new IllegalArgumentException("GeneratedExtension given a regular (non-extension) field.");
/*      */       }
/*      */ 
/*  954 */       this.descriptor = descriptor;
/*  955 */       this.type = type;
/*      */ 
/*  957 */       switch (GeneratedMessage.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$JavaType[descriptor.getJavaType().ordinal()]) {
/*      */       case 1:
/*  959 */         this.enumValueOf = null;
/*  960 */         this.enumGetValueDescriptor = null;
/*  961 */         this.messageDefaultInstance = ((Message)GeneratedMessage.access$1300(GeneratedMessage.access$1200(type, "getDefaultInstance", new Class[0]), null, new Object[0]));
/*      */ 
/*  964 */         if (this.messageDefaultInstance != null) break;
/*  965 */         throw new IllegalStateException(type.getName() + ".getDefaultInstance() returned null.");
/*      */       case 2:
/*  970 */         this.enumValueOf = GeneratedMessage.access$1200(type, "valueOf", new Class[] { Descriptors.EnumValueDescriptor.class });
/*      */ 
/*  972 */         this.enumGetValueDescriptor = GeneratedMessage.access$1200(type, "getValueDescriptor", new Class[0]);
/*  973 */         this.messageDefaultInstance = null;
/*  974 */         break;
/*      */       default:
/*  976 */         this.enumValueOf = null;
/*  977 */         this.enumGetValueDescriptor = null;
/*  978 */         this.messageDefaultInstance = null;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Descriptors.FieldDescriptor getDescriptor()
/*      */     {
/*  989 */       return this.descriptor;
/*      */     }
/*      */ 
/*      */     public Message getMessageDefaultInstance()
/*      */     {
/*  997 */       return this.messageDefaultInstance;
/*      */     }
/*      */ 
/*      */     private Object fromReflectionType(Object value)
/*      */     {
/* 1008 */       if (this.descriptor.isRepeated()) {
/* 1009 */         if ((this.descriptor.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) || (this.descriptor.getJavaType() == Descriptors.FieldDescriptor.JavaType.ENUM))
/*      */         {
/* 1012 */           List result = new ArrayList();
/* 1013 */           for (Iterator i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 1014 */             result.add(singularFromReflectionType(element));
/*      */           }
/* 1016 */           return result;
/*      */         }
/* 1018 */         return value;
/*      */       }
/*      */ 
/* 1021 */       return singularFromReflectionType(value);
/*      */     }
/*      */ 
/*      */     private Object singularFromReflectionType(Object value)
/*      */     {
/* 1030 */       switch (GeneratedMessage.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$JavaType[this.descriptor.getJavaType().ordinal()]) {
/*      */       case 1:
/* 1032 */         if (this.type.isInstance(value)) {
/* 1033 */           return value;
/*      */         }
/*      */ 
/* 1041 */         return this.messageDefaultInstance.newBuilderForType().mergeFrom((Message)value).build();
/*      */       case 2:
/* 1045 */         return GeneratedMessage.access$1300(this.enumValueOf, null, new Object[] { (Descriptors.EnumValueDescriptor)value });
/*      */       }
/* 1047 */       return value;
/*      */     }
/*      */ 
/*      */     private Object toReflectionType(Object value)
/*      */     {
/* 1059 */       if (this.descriptor.isRepeated()) {
/* 1060 */         if (this.descriptor.getJavaType() == Descriptors.FieldDescriptor.JavaType.ENUM)
/*      */         {
/* 1062 */           List result = new ArrayList();
/* 1063 */           for (Iterator i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 1064 */             result.add(singularToReflectionType(element));
/*      */           }
/* 1066 */           return result;
/*      */         }
/* 1068 */         return value;
/*      */       }
/*      */ 
/* 1071 */       return singularToReflectionType(value);
/*      */     }
/*      */ 
/*      */     private Object singularToReflectionType(Object value)
/*      */     {
/* 1080 */       switch (GeneratedMessage.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$JavaType[this.descriptor.getJavaType().ordinal()]) {
/*      */       case 2:
/* 1082 */         return GeneratedMessage.access$1300(this.enumGetValueDescriptor, value, new Object[0]);
/*      */       }
/* 1084 */       return value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class ExtendableBuilder<MessageType extends GeneratedMessage.ExtendableMessage, BuilderType extends ExtendableBuilder> extends GeneratedMessage.Builder<BuilderType>
/*      */   {
/*  605 */     private FieldSet<Descriptors.FieldDescriptor> extensions = FieldSet.emptySet();
/*      */ 
/*      */     public BuilderType clear()
/*      */     {
/*  611 */       this.extensions = FieldSet.emptySet();
/*  612 */       return (ExtendableBuilder)super.clear();
/*      */     }
/*      */ 
/*      */     public BuilderType clone()
/*      */     {
/*  620 */       throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
/*      */     }
/*      */ 
/*      */     private void ensureExtensionsIsMutable()
/*      */     {
/*  625 */       if (this.extensions.isImmutable())
/*  626 */         this.extensions = this.extensions.clone();
/*      */     }
/*      */ 
/*      */     private void verifyExtensionContainingType(GeneratedMessage.GeneratedExtension<MessageType, ?> extension)
/*      */     {
/*  632 */       if (extension.getDescriptor().getContainingType() != getDescriptorForType())
/*      */       {
/*  635 */         throw new IllegalArgumentException("Extension is for type \"" + extension.getDescriptor().getContainingType().getFullName() + "\" which does not match message type \"" + getDescriptorForType().getFullName() + "\".");
/*      */       }
/*      */     }
/*      */ 
/*      */     public final boolean hasExtension(GeneratedMessage.GeneratedExtension<MessageType, ?> extension)
/*      */     {
/*  646 */       verifyExtensionContainingType(extension);
/*  647 */       return this.extensions.hasField(extension.getDescriptor());
/*      */     }
/*      */ 
/*      */     public final <Type> int getExtensionCount(GeneratedMessage.GeneratedExtension<MessageType, List<Type>> extension)
/*      */     {
/*  653 */       verifyExtensionContainingType(extension);
/*  654 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  655 */       return this.extensions.getRepeatedFieldCount(descriptor);
/*      */     }
/*      */ 
/*      */     public final <Type> Type getExtension(GeneratedMessage.GeneratedExtension<MessageType, Type> extension)
/*      */     {
/*  661 */       verifyExtensionContainingType(extension);
/*  662 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  663 */       Object value = this.extensions.getField(descriptor);
/*  664 */       if (value == null) {
/*  665 */         if (descriptor.isRepeated())
/*  666 */           return Collections.emptyList();
/*  667 */         if (descriptor.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/*      */         {
/*  669 */           return extension.getMessageDefaultInstance();
/*      */         }
/*  671 */         return extension.fromReflectionType(descriptor.getDefaultValue());
/*      */       }
/*      */ 
/*  675 */       return extension.fromReflectionType(value);
/*      */     }
/*      */ 
/*      */     public final <Type> Type getExtension(GeneratedMessage.GeneratedExtension<MessageType, List<Type>> extension, int index)
/*      */     {
/*  683 */       verifyExtensionContainingType(extension);
/*  684 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  685 */       return extension.singularFromReflectionType(this.extensions.getRepeatedField(descriptor, index));
/*      */     }
/*      */ 
/*      */     public final <Type> BuilderType setExtension(GeneratedMessage.GeneratedExtension<MessageType, Type> extension, Type value)
/*      */     {
/*  693 */       verifyExtensionContainingType(extension);
/*  694 */       ensureExtensionsIsMutable();
/*  695 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  696 */       this.extensions.setField(descriptor, extension.toReflectionType(value));
/*  697 */       return this;
/*      */     }
/*      */ 
/*      */     public final <Type> BuilderType setExtension(GeneratedMessage.GeneratedExtension<MessageType, List<Type>> extension, int index, Type value)
/*      */     {
/*  704 */       verifyExtensionContainingType(extension);
/*  705 */       ensureExtensionsIsMutable();
/*  706 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  707 */       this.extensions.setRepeatedField(descriptor, index, extension.singularToReflectionType(value));
/*      */ 
/*  710 */       return this;
/*      */     }
/*      */ 
/*      */     public final <Type> BuilderType addExtension(GeneratedMessage.GeneratedExtension<MessageType, List<Type>> extension, Type value)
/*      */     {
/*  717 */       verifyExtensionContainingType(extension);
/*  718 */       ensureExtensionsIsMutable();
/*  719 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  720 */       this.extensions.addRepeatedField(descriptor, extension.singularToReflectionType(value));
/*      */ 
/*  722 */       return this;
/*      */     }
/*      */ 
/*      */     public final <Type> BuilderType clearExtension(GeneratedMessage.GeneratedExtension<MessageType, ?> extension)
/*      */     {
/*  728 */       verifyExtensionContainingType(extension);
/*  729 */       ensureExtensionsIsMutable();
/*  730 */       this.extensions.clearField(extension.getDescriptor());
/*  731 */       return this;
/*      */     }
/*      */ 
/*      */     protected boolean extensionsAreInitialized()
/*      */     {
/*  736 */       return this.extensions.isInitialized();
/*      */     }
/*      */ 
/*      */     private FieldSet<Descriptors.FieldDescriptor> buildExtensions()
/*      */     {
/*  744 */       this.extensions.makeImmutable();
/*  745 */       return this.extensions;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized()
/*      */     {
/*  750 */       return (super.isInitialized()) && (extensionsAreInitialized());
/*      */     }
/*      */ 
/*      */     protected boolean parseUnknownField(CodedInputStream input, UnknownFieldSet.Builder unknownFields, ExtensionRegistryLite extensionRegistry, int tag)
/*      */       throws IOException
/*      */     {
/*  763 */       return AbstractMessage.Builder.mergeFieldFrom(input, unknownFields, extensionRegistry, this, tag);
/*      */     }
/*      */ 
/*      */     public Map<Descriptors.FieldDescriptor, Object> getAllFields()
/*      */     {
/*  772 */       Map result = GeneratedMessage.Builder.access$1000(this);
/*  773 */       result.putAll(this.extensions.getAllFields());
/*  774 */       return Collections.unmodifiableMap(result);
/*      */     }
/*      */ 
/*      */     public Object getField(Descriptors.FieldDescriptor field)
/*      */     {
/*  779 */       if (field.isExtension()) {
/*  780 */         verifyContainingType(field);
/*  781 */         Object value = this.extensions.getField(field);
/*  782 */         if (value == null) {
/*  783 */           if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/*      */           {
/*  786 */             return DynamicMessage.getDefaultInstance(field.getMessageType());
/*      */           }
/*  788 */           return field.getDefaultValue();
/*      */         }
/*      */ 
/*  791 */         return value;
/*      */       }
/*      */ 
/*  794 */       return super.getField(field);
/*      */     }
/*      */ 
/*      */     public int getRepeatedFieldCount(Descriptors.FieldDescriptor field)
/*      */     {
/*  800 */       if (field.isExtension()) {
/*  801 */         verifyContainingType(field);
/*  802 */         return this.extensions.getRepeatedFieldCount(field);
/*      */       }
/*  804 */       return super.getRepeatedFieldCount(field);
/*      */     }
/*      */ 
/*      */     public Object getRepeatedField(Descriptors.FieldDescriptor field, int index)
/*      */     {
/*  811 */       if (field.isExtension()) {
/*  812 */         verifyContainingType(field);
/*  813 */         return this.extensions.getRepeatedField(field, index);
/*      */       }
/*  815 */       return super.getRepeatedField(field, index);
/*      */     }
/*      */ 
/*      */     public boolean hasField(Descriptors.FieldDescriptor field)
/*      */     {
/*  821 */       if (field.isExtension()) {
/*  822 */         verifyContainingType(field);
/*  823 */         return this.extensions.hasField(field);
/*      */       }
/*  825 */       return super.hasField(field);
/*      */     }
/*      */ 
/*      */     public BuilderType setField(Descriptors.FieldDescriptor field, Object value)
/*      */     {
/*  832 */       if (field.isExtension()) {
/*  833 */         verifyContainingType(field);
/*  834 */         ensureExtensionsIsMutable();
/*  835 */         this.extensions.setField(field, value);
/*  836 */         return this;
/*      */       }
/*  838 */       return (ExtendableBuilder)super.setField(field, value);
/*      */     }
/*      */ 
/*      */     public BuilderType clearField(Descriptors.FieldDescriptor field)
/*      */     {
/*  844 */       if (field.isExtension()) {
/*  845 */         verifyContainingType(field);
/*  846 */         ensureExtensionsIsMutable();
/*  847 */         this.extensions.clearField(field);
/*  848 */         return this;
/*      */       }
/*  850 */       return (ExtendableBuilder)super.clearField(field);
/*      */     }
/*      */ 
/*      */     public BuilderType setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
/*      */     {
/*  857 */       if (field.isExtension()) {
/*  858 */         verifyContainingType(field);
/*  859 */         ensureExtensionsIsMutable();
/*  860 */         this.extensions.setRepeatedField(field, index, value);
/*  861 */         return this;
/*      */       }
/*  863 */       return (ExtendableBuilder)super.setRepeatedField(field, index, value);
/*      */     }
/*      */ 
/*      */     public BuilderType addRepeatedField(Descriptors.FieldDescriptor field, Object value)
/*      */     {
/*  870 */       if (field.isExtension()) {
/*  871 */         verifyContainingType(field);
/*  872 */         ensureExtensionsIsMutable();
/*  873 */         this.extensions.addRepeatedField(field, value);
/*  874 */         return this;
/*      */       }
/*  876 */       return (ExtendableBuilder)super.addRepeatedField(field, value);
/*      */     }
/*      */ 
/*      */     protected final void mergeExtensionFields(GeneratedMessage.ExtendableMessage other)
/*      */     {
/*  881 */       ensureExtensionsIsMutable();
/*  882 */       this.extensions.mergeFrom(GeneratedMessage.ExtendableMessage.access$500(other));
/*      */     }
/*      */ 
/*      */     private void verifyContainingType(Descriptors.FieldDescriptor field) {
/*  886 */       if (field.getContainingType() != getDescriptorForType())
/*  887 */         throw new IllegalArgumentException("FieldDescriptor does not match message type.");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class ExtendableMessage<MessageType extends ExtendableMessage> extends GeneratedMessage
/*      */   {
/*      */     private final FieldSet<Descriptors.FieldDescriptor> extensions;
/*      */ 
/*      */     protected ExtendableMessage()
/*      */     {
/*  354 */       this.extensions = FieldSet.newFieldSet();
/*      */     }
/*      */ 
/*      */     protected ExtendableMessage(GeneratedMessage.ExtendableBuilder<MessageType, ?> builder)
/*      */     {
/*  359 */       super();
/*  360 */       this.extensions = builder.buildExtensions();
/*      */     }
/*      */ 
/*      */     private void verifyExtensionContainingType(GeneratedMessage.GeneratedExtension<MessageType, ?> extension)
/*      */     {
/*  365 */       if (extension.getDescriptor().getContainingType() != getDescriptorForType())
/*      */       {
/*  368 */         throw new IllegalArgumentException("Extension is for type \"" + extension.getDescriptor().getContainingType().getFullName() + "\" which does not match message type \"" + getDescriptorForType().getFullName() + "\".");
/*      */       }
/*      */     }
/*      */ 
/*      */     public final boolean hasExtension(GeneratedMessage.GeneratedExtension<MessageType, ?> extension)
/*      */     {
/*  379 */       verifyExtensionContainingType(extension);
/*  380 */       return this.extensions.hasField(extension.getDescriptor());
/*      */     }
/*      */ 
/*      */     public final <Type> int getExtensionCount(GeneratedMessage.GeneratedExtension<MessageType, List<Type>> extension)
/*      */     {
/*  386 */       verifyExtensionContainingType(extension);
/*  387 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  388 */       return this.extensions.getRepeatedFieldCount(descriptor);
/*      */     }
/*      */ 
/*      */     public final <Type> Type getExtension(GeneratedMessage.GeneratedExtension<MessageType, Type> extension)
/*      */     {
/*  395 */       verifyExtensionContainingType(extension);
/*  396 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  397 */       Object value = this.extensions.getField(descriptor);
/*  398 */       if (value == null) {
/*  399 */         if (descriptor.isRepeated())
/*  400 */           return Collections.emptyList();
/*  401 */         if (descriptor.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/*      */         {
/*  403 */           return extension.getMessageDefaultInstance();
/*      */         }
/*  405 */         return extension.fromReflectionType(descriptor.getDefaultValue());
/*      */       }
/*      */ 
/*  409 */       return extension.fromReflectionType(value);
/*      */     }
/*      */ 
/*      */     public final <Type> Type getExtension(GeneratedMessage.GeneratedExtension<MessageType, List<Type>> extension, int index)
/*      */     {
/*  418 */       verifyExtensionContainingType(extension);
/*  419 */       Descriptors.FieldDescriptor descriptor = extension.getDescriptor();
/*  420 */       return extension.singularFromReflectionType(this.extensions.getRepeatedField(descriptor, index));
/*      */     }
/*      */ 
/*      */     protected boolean extensionsAreInitialized()
/*      */     {
/*  426 */       return this.extensions.isInitialized();
/*      */     }
/*      */ 
/*      */     public boolean isInitialized()
/*      */     {
/*  431 */       return (super.isInitialized()) && (extensionsAreInitialized());
/*      */     }
/*      */ 
/*      */     protected ExtendableMessage<MessageType>.ExtensionWriter newExtensionWriter()
/*      */     {
/*  478 */       return new ExtensionWriter(false, null);
/*      */     }
/*      */     protected ExtendableMessage<MessageType>.ExtensionWriter newMessageSetExtensionWriter() {
/*  481 */       return new ExtensionWriter(true, null);
/*      */     }
/*      */ 
/*      */     protected int extensionsSerializedSize()
/*      */     {
/*  486 */       return this.extensions.getSerializedSize();
/*      */     }
/*      */     protected int extensionsSerializedSizeAsMessageSet() {
/*  489 */       return this.extensions.getMessageSetSerializedSize();
/*      */     }
/*      */ 
/*      */     public Map<Descriptors.FieldDescriptor, Object> getAllFields()
/*      */     {
/*  497 */       Map result = super.getAllFieldsMutable();
/*  498 */       result.putAll(this.extensions.getAllFields());
/*  499 */       return Collections.unmodifiableMap(result);
/*      */     }
/*      */ 
/*      */     public boolean hasField(Descriptors.FieldDescriptor field)
/*      */     {
/*  504 */       if (field.isExtension()) {
/*  505 */         verifyContainingType(field);
/*  506 */         return this.extensions.hasField(field);
/*      */       }
/*  508 */       return super.hasField(field);
/*      */     }
/*      */ 
/*      */     public Object getField(Descriptors.FieldDescriptor field)
/*      */     {
/*  514 */       if (field.isExtension()) {
/*  515 */         verifyContainingType(field);
/*  516 */         Object value = this.extensions.getField(field);
/*  517 */         if (value == null) {
/*  518 */           if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/*      */           {
/*  521 */             return DynamicMessage.getDefaultInstance(field.getMessageType());
/*      */           }
/*  523 */           return field.getDefaultValue();
/*      */         }
/*      */ 
/*  526 */         return value;
/*      */       }
/*      */ 
/*  529 */       return super.getField(field);
/*      */     }
/*      */ 
/*      */     public int getRepeatedFieldCount(Descriptors.FieldDescriptor field)
/*      */     {
/*  535 */       if (field.isExtension()) {
/*  536 */         verifyContainingType(field);
/*  537 */         return this.extensions.getRepeatedFieldCount(field);
/*      */       }
/*  539 */       return super.getRepeatedFieldCount(field);
/*      */     }
/*      */ 
/*      */     public Object getRepeatedField(Descriptors.FieldDescriptor field, int index)
/*      */     {
/*  546 */       if (field.isExtension()) {
/*  547 */         verifyContainingType(field);
/*  548 */         return this.extensions.getRepeatedField(field, index);
/*      */       }
/*  550 */       return super.getRepeatedField(field, index);
/*      */     }
/*      */ 
/*      */     private void verifyContainingType(Descriptors.FieldDescriptor field)
/*      */     {
/*  555 */       if (field.getContainingType() != getDescriptorForType())
/*  556 */         throw new IllegalArgumentException("FieldDescriptor does not match message type.");
/*      */     }
/*      */ 
/*      */     protected class ExtensionWriter
/*      */     {
/*  444 */       private final Iterator<Map.Entry<Descriptors.FieldDescriptor, Object>> iter = GeneratedMessage.ExtendableMessage.this.extensions.iterator();
/*      */       private Map.Entry<Descriptors.FieldDescriptor, Object> next;
/*      */       private final boolean messageSetWireFormat;
/*      */ 
/*      */       private ExtensionWriter(boolean messageSetWireFormat)
/*      */       {
/*  450 */         if (this.iter.hasNext()) {
/*  451 */           this.next = ((Map.Entry)this.iter.next());
/*      */         }
/*  453 */         this.messageSetWireFormat = messageSetWireFormat;
/*      */       }
/*      */ 
/*      */       public void writeUntil(int end, CodedOutputStream output) throws IOException
/*      */       {
/*  458 */         while ((this.next != null) && (((Descriptors.FieldDescriptor)this.next.getKey()).getNumber() < end)) {
/*  459 */           Descriptors.FieldDescriptor descriptor = (Descriptors.FieldDescriptor)this.next.getKey();
/*  460 */           if ((this.messageSetWireFormat) && (descriptor.getLiteJavaType() == WireFormat.JavaType.MESSAGE) && (!descriptor.isRepeated()))
/*      */           {
/*  463 */             output.writeMessageSetExtension(descriptor.getNumber(), (Message)this.next.getValue());
/*      */           }
/*      */           else {
/*  466 */             FieldSet.writeField(descriptor, this.next.getValue(), output);
/*      */           }
/*  468 */           if (this.iter.hasNext())
/*  469 */             this.next = ((Map.Entry)this.iter.next());
/*      */           else
/*  471 */             this.next = null;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class Builder<BuilderType extends Builder> extends AbstractMessage.Builder<BuilderType>
/*      */   {
/*  133 */     private UnknownFieldSet unknownFields = UnknownFieldSet.getDefaultInstance();
/*      */ 
/*      */     public BuilderType clone()
/*      */     {
/*  143 */       throw new UnsupportedOperationException("This is supposed to be overridden by subclasses.");
/*      */     }
/*      */ 
/*      */     public BuilderType clear()
/*      */     {
/*  152 */       this.unknownFields = UnknownFieldSet.getDefaultInstance();
/*  153 */       return this;
/*      */     }
/*      */ 
/*      */     protected abstract GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable();
/*      */ 
/*      */     public Descriptors.Descriptor getDescriptorForType()
/*      */     {
/*  164 */       return internalGetFieldAccessorTable().descriptor;
/*      */     }
/*      */ 
/*      */     public Map<Descriptors.FieldDescriptor, Object> getAllFields() {
/*  168 */       return Collections.unmodifiableMap(getAllFieldsMutable());
/*      */     }
/*      */ 
/*      */     private Map<Descriptors.FieldDescriptor, Object> getAllFieldsMutable()
/*      */     {
/*  173 */       TreeMap result = new TreeMap();
/*      */ 
/*  175 */       Descriptors.Descriptor descriptor = internalGetFieldAccessorTable().descriptor;
/*  176 */       for (Descriptors.FieldDescriptor field : descriptor.getFields()) {
/*  177 */         if (field.isRepeated()) {
/*  178 */           List value = (List)getField(field);
/*  179 */           if (!value.isEmpty()) {
/*  180 */             result.put(field, value);
/*      */           }
/*      */         }
/*  183 */         else if (hasField(field)) {
/*  184 */           result.put(field, getField(field));
/*      */         }
/*      */       }
/*      */ 
/*  188 */       return result;
/*      */     }
/*      */ 
/*      */     public Message.Builder newBuilderForField(Descriptors.FieldDescriptor field)
/*      */     {
/*  193 */       return internalGetFieldAccessorTable().getField(field).newBuilder();
/*      */     }
/*      */ 
/*      */     public boolean hasField(Descriptors.FieldDescriptor field) {
/*  197 */       return internalGetFieldAccessorTable().getField(field).has(this);
/*      */     }
/*      */ 
/*      */     public Object getField(Descriptors.FieldDescriptor field) {
/*  201 */       Object object = internalGetFieldAccessorTable().getField(field).get(this);
/*  202 */       if (field.isRepeated())
/*      */       {
/*  205 */         return Collections.unmodifiableList((List)object);
/*      */       }
/*  207 */       return object;
/*      */     }
/*      */ 
/*      */     public BuilderType setField(Descriptors.FieldDescriptor field, Object value)
/*      */     {
/*  213 */       internalGetFieldAccessorTable().getField(field).set(this, value);
/*  214 */       return this;
/*      */     }
/*      */ 
/*      */     public BuilderType clearField(Descriptors.FieldDescriptor field) {
/*  218 */       internalGetFieldAccessorTable().getField(field).clear(this);
/*  219 */       return this;
/*      */     }
/*      */ 
/*      */     public int getRepeatedFieldCount(Descriptors.FieldDescriptor field) {
/*  223 */       return internalGetFieldAccessorTable().getField(field).getRepeatedCount(this);
/*      */     }
/*      */ 
/*      */     public Object getRepeatedField(Descriptors.FieldDescriptor field, int index)
/*      */     {
/*  229 */       return internalGetFieldAccessorTable().getField(field).getRepeated(this, index);
/*      */     }
/*      */ 
/*      */     public BuilderType setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
/*      */     {
/*  235 */       internalGetFieldAccessorTable().getField(field).setRepeated(this, index, value);
/*      */ 
/*  237 */       return this;
/*      */     }
/*      */ 
/*      */     public BuilderType addRepeatedField(Descriptors.FieldDescriptor field, Object value)
/*      */     {
/*  242 */       internalGetFieldAccessorTable().getField(field).addRepeated(this, value);
/*  243 */       return this;
/*      */     }
/*      */ 
/*      */     public final BuilderType setUnknownFields(UnknownFieldSet unknownFields)
/*      */     {
/*  248 */       this.unknownFields = unknownFields;
/*  249 */       return this;
/*      */     }
/*      */ 
/*      */     public final BuilderType mergeUnknownFields(UnknownFieldSet unknownFields)
/*      */     {
/*  255 */       this.unknownFields = UnknownFieldSet.newBuilder(this.unknownFields).mergeFrom(unknownFields).build();
/*      */ 
/*  259 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized()
/*      */     {
/*  264 */       for (Descriptors.FieldDescriptor field : getDescriptorForType().getFields())
/*      */       {
/*  266 */         if ((field.isRequired()) && 
/*  267 */           (!hasField(field))) {
/*  268 */           return false;
/*      */         }
/*      */ 
/*  272 */         if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/*  273 */           if (field.isRepeated())
/*      */           {
/*  275 */             List messageList = (List)getField(field);
/*  276 */             for (Message element : messageList) {
/*  277 */               if (!element.isInitialized()) {
/*  278 */                 return false;
/*      */               }
/*      */             }
/*      */           }
/*  282 */           else if ((hasField(field)) && (!((Message)getField(field)).isInitialized()))
/*      */           {
/*  284 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  289 */       return true;
/*      */     }
/*      */ 
/*      */     public final UnknownFieldSet getUnknownFields() {
/*  293 */       return this.unknownFields;
/*      */     }
/*      */ 
/*      */     protected boolean parseUnknownField(CodedInputStream input, UnknownFieldSet.Builder unknownFields, ExtensionRegistryLite extensionRegistry, int tag)
/*      */       throws IOException
/*      */     {
/*  305 */       return unknownFields.mergeFieldFrom(tag, input);
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage
 * JD-Core Version:    0.6.0
 */