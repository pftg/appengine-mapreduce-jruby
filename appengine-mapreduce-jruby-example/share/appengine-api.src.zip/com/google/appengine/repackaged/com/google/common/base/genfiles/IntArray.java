/*     */ package com.google.appengine.repackaged.com.google.common.base.genfiles;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.X;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public final class IntArray
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int[] list;
/*     */   private int length;
/*     */ 
/*     */   @Deprecated
/*     */   public IntArray()
/*     */   {
/*  45 */     this.list = new int[4];
/*  46 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public IntArray(int capacity)
/*     */   {
/*  58 */     this.list = new int[capacity];
/*  59 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   public IntArray(int[] source, int start, int num)
/*     */   {
/*  64 */     X.assertTrue(num >= 0);
/*  65 */     this.list = new int[num];
/*  66 */     this.length = num;
/*  67 */     System.arraycopy(source, start, this.list, 0, num);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private IntArray(int[] array, int arrayLength)
/*     */   {
/*  78 */     this.list = array;
/*  79 */     this.length = arrayLength;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static IntArray newInstance(int[] array)
/*     */   {
/* 102 */     Preconditions.checkNotNull(array);
/* 103 */     return new IntArray(array, array.length);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static IntArray newInstance(int[] array, int length)
/*     */   {
/* 128 */     Preconditions.checkNotNull(array);
/* 129 */     Preconditions.checkArgument((length >= 0) && (length <= array.length));
/* 130 */     return new IntArray(array, length);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 135 */     return this.length;
/*     */   }
/*     */ 
/*     */   public int get(int i)
/*     */   {
/* 141 */     X.assertTrue((i >= 0) && (i < this.length));
/* 142 */     return this.list[i];
/*     */   }
/*     */ 
/*     */   public void set(int i, int x)
/*     */   {
/* 148 */     X.assertTrue((i >= 0) && (i < this.length));
/* 149 */     this.list[i] = x;
/*     */   }
/*     */ 
/*     */   public void add(int x)
/*     */   {
/* 154 */     if (this.length >= this.list.length) ensureCapacity(this.length + 1);
/* 155 */     this.list[(this.length++)] = x;
/*     */   }
/*     */ 
/*     */   public void prependSlow(int x)
/*     */   {
/* 161 */     ensureCapacity(this.length + 1);
/* 162 */     System.arraycopy(this.list, 0, this.list, 1, this.length);
/* 163 */     this.list[0] = x;
/* 164 */     this.length += 1;
/*     */   }
/*     */ 
/*     */   public void add(int[] source, int start, int num)
/*     */   {
/* 169 */     if (this.length + num > this.list.length) ensureCapacity(this.length + num);
/* 170 */     System.arraycopy(source, start, this.list, this.length, num);
/* 171 */     this.length += num;
/*     */   }
/*     */ 
/*     */   public void addArray(IntArray other)
/*     */   {
/* 176 */     add(other.rep(), 0, other.size());
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 181 */     this.length = 0;
/*     */   }
/*     */ 
/*     */   public void removeLast()
/*     */   {
/* 186 */     X.assertTrue(this.length > 0);
/*     */ 
/* 189 */     this.length -= 1;
/*     */   }
/*     */ 
/*     */   public int pop()
/*     */   {
/* 194 */     X.assertTrue(this.length > 0);
/*     */ 
/* 197 */     return this.list[(--this.length)];
/*     */   }
/*     */ 
/*     */   public void removeFast(int i)
/*     */   {
/* 203 */     X.assertTrue((i >= 0) && (i < this.length));
/* 204 */     this.list[i] = this.list[(this.length - 1)];
/* 205 */     removeLast();
/*     */   }
/*     */ 
/*     */   public int indexOf(int element)
/*     */   {
/* 212 */     for (int i = 0; i < this.length; i++) {
/* 213 */       if (this.list[i] == element) {
/* 214 */         return i;
/*     */       }
/*     */     }
/* 217 */     return -1;
/*     */   }
/*     */ 
/*     */   public void removeSlow(int i)
/*     */   {
/* 224 */     X.assertTrue((i >= 0) && (i < this.length));
/* 225 */     System.arraycopy(this.list, i + 1, this.list, i, this.length - (i + 1));
/* 226 */     this.length -= 1;
/*     */   }
/*     */ 
/*     */   public void replaceSlow(int start, int rangelen, IntArray other)
/*     */   {
/* 233 */     X.assertTrue(other.list != this.list);
/* 234 */     int end = start + rangelen;
/* 235 */     X.assertTrue((start >= 0) && (end <= this.length));
/* 236 */     ensureCapacity(this.length - rangelen + other.length);
/* 237 */     if (end < this.length) {
/* 238 */       System.arraycopy(this.list, end, this.list, start + other.length, this.length - end);
/*     */     }
/* 240 */     System.arraycopy(other.list, 0, this.list, start, other.length);
/* 241 */     this.length = (this.length - rangelen + other.length);
/*     */   }
/*     */ 
/*     */   public void ensureCapacity(int n)
/*     */   {
/* 248 */     if (this.list.length < n) {
/* 249 */       int new_size = this.list.length * 2;
/* 250 */       if (new_size < n) {
/* 251 */         new_size = n;
/*     */       }
/* 253 */       int[] copy = new int[new_size];
/* 254 */       System.arraycopy(this.list, 0, copy, 0, this.length);
/* 255 */       this.list = copy;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int[] rep()
/*     */   {
/* 264 */     return this.list;
/*     */   }
/*     */ 
/*     */   public void resize(int n)
/*     */   {
/* 272 */     X.assertTrue(n >= 0);
/* 273 */     ensureCapacity(n);
/* 274 */     this.length = n;
/*     */   }
/*     */ 
/*     */   public void trimToSize()
/*     */   {
/* 279 */     if (this.list.length != this.length)
/* 280 */       this.list = toArray();
/*     */   }
/*     */ 
/*     */   public void swap(IntArray other)
/*     */   {
/* 287 */     int tmp_length = this.length;
/* 288 */     this.length = other.length;
/* 289 */     other.length = tmp_length;
/* 290 */     int[] tmp_list = this.list;
/* 291 */     this.list = other.list;
/* 292 */     other.list = tmp_list;
/*     */   }
/*     */ 
/*     */   public int[] toArray()
/*     */   {
/* 297 */     int[] copy = new int[this.length];
/* 298 */     System.arraycopy(this.list, 0, copy, 0, this.length);
/* 299 */     return copy;
/*     */   }
/*     */ 
/*     */   public int[] subArray(int start, int len)
/*     */   {
/* 304 */     X.assertTrue(start >= 0);
/* 305 */     X.assertTrue(start + len <= this.length);
/* 306 */     int[] copy = new int[len];
/* 307 */     System.arraycopy(this.list, start, copy, 0, len);
/* 308 */     return copy;
/*     */   }
/*     */ 
/*     */   public void copy(int[] dest, int len, int src_pos, int dest_pos)
/*     */   {
/* 313 */     X.assertTrue(src_pos >= 0);
/* 314 */     X.assertTrue(dest_pos >= 0);
/* 315 */     X.assertTrue(len >= 0);
/* 316 */     X.assertTrue(src_pos + len <= this.length);
/* 317 */     X.assertTrue(dest_pos + len <= dest.length);
/* 318 */     System.arraycopy(this.list, src_pos, dest, dest_pos, len);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.genfiles.IntArray
 * JD-Core Version:    0.6.0
 */