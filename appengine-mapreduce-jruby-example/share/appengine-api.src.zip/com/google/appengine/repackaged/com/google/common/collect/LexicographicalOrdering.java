/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.io.Serializable;
/*    */ import java.util.Iterator;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible(serializable=true)
/*    */ final class LexicographicalOrdering<T> extends Ordering<Iterable<T>>
/*    */   implements Serializable
/*    */ {
/*    */   final Ordering<? super T> elementOrder;
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   LexicographicalOrdering(Ordering<? super T> elementOrder)
/*    */   {
/* 36 */     this.elementOrder = elementOrder;
/*    */   }
/*    */ 
/*    */   public int compare(Iterable<T> leftIterable, Iterable<T> rightIterable) {
/* 40 */     Iterator left = leftIterable.iterator();
/* 41 */     Iterator right = rightIterable.iterator();
/* 42 */     while (left.hasNext()) {
/* 43 */       if (!right.hasNext()) {
/* 44 */         return 1;
/*    */       }
/* 46 */       int result = this.elementOrder.compare(left.next(), right.next());
/* 47 */       if (result != 0) {
/* 48 */         return result;
/*    */       }
/*    */     }
/* 51 */     if (right.hasNext()) {
/* 52 */       return -1;
/*    */     }
/* 54 */     return 0;
/*    */   }
/*    */ 
/*    */   public boolean equals(@Nullable Object object) {
/* 58 */     if (object == this) {
/* 59 */       return true;
/*    */     }
/* 61 */     if ((object instanceof LexicographicalOrdering)) {
/* 62 */       LexicographicalOrdering that = (LexicographicalOrdering)object;
/* 63 */       return this.elementOrder.equals(that.elementOrder);
/*    */     }
/* 65 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 69 */     return this.elementOrder.hashCode() ^ 0x7BB78CF5;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 73 */     return this.elementOrder + ".lexicographical()";
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.LexicographicalOrdering
 * JD-Core Version:    0.6.0
 */