/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Splitter
/*     */ {
/*     */   private final CharMatcher trimmer;
/*     */   private final boolean omitEmptyStrings;
/*     */   private final Strategy strategy;
/*     */ 
/*     */   private Splitter(Strategy strategy)
/*     */   {
/*  99 */     this(strategy, false, CharMatcher.NONE);
/*     */   }
/*     */ 
/*     */   private Splitter(Strategy strategy, boolean omitEmptyStrings, CharMatcher trimmer)
/*     */   {
/* 104 */     this.strategy = strategy;
/* 105 */     this.omitEmptyStrings = omitEmptyStrings;
/* 106 */     this.trimmer = trimmer;
/*     */   }
/*     */ 
/*     */   public static Splitter on(char separator)
/*     */   {
/* 118 */     return on(CharMatcher.is(separator));
/*     */   }
/*     */ 
/*     */   public static Splitter on(CharMatcher separatorMatcher)
/*     */   {
/* 132 */     Preconditions.checkNotNull(separatorMatcher);
/*     */ 
/* 134 */     return new Splitter(new Strategy(separatorMatcher)
/*     */     {
/*     */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit) {
/* 137 */         return new Splitter.SplittingIterator(splitter, toSplit) {
/*     */           int separatorStart(int start) {
/* 139 */             return Splitter.1.this.val$separatorMatcher.indexIn(this.toSplit, start);
/*     */           }
/*     */ 
/*     */           int separatorEnd(int separatorPosition) {
/* 143 */             return separatorPosition + 1;
/*     */           }
/*     */         };
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static Splitter on(String separator)
/*     */   {
/* 159 */     Preconditions.checkArgument(separator.length() != 0, "The separator may not be the empty string.");
/*     */ 
/* 162 */     return new Splitter(new Strategy(separator)
/*     */     {
/*     */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit) {
/* 165 */         return new Splitter.SplittingIterator(splitter, toSplit) {
/*     */           public int separatorStart(int start) {
/* 167 */             int delimeterLength = Splitter.2.this.val$separator.length();
/*     */ 
/* 170 */             int p = start; int last = this.toSplit.length() - delimeterLength;
/* 171 */             for (; p <= last; p++) {
/* 172 */               int i = 0;
/*     */               while (true) if (i < delimeterLength) {
/* 173 */                   if (this.toSplit.charAt(i + p) != Splitter.2.this.val$separator.charAt(i))
/*     */                     break;
/* 172 */                   i++; continue;
/*     */                 }
/*     */                 else
/*     */                 {
/* 177 */                   return p;
/*     */                 } 
/*     */             }
/* 179 */             return -1;
/*     */           }
/*     */ 
/*     */           public int separatorEnd(int separatorPosition) {
/* 183 */             return separatorPosition + Splitter.2.this.val$separator.length();
/*     */           }
/*     */         };
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.util.regex")
/*     */   public static Splitter on(Pattern separatorPattern)
/*     */   {
/* 204 */     Preconditions.checkNotNull(separatorPattern);
/* 205 */     Preconditions.checkArgument(!separatorPattern.matcher("").matches(), "The pattern may not match the empty string: %s", new Object[] { separatorPattern });
/*     */ 
/* 208 */     return new Splitter(new Strategy(separatorPattern)
/*     */     {
/*     */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit) {
/* 211 */         Matcher matcher = this.val$separatorPattern.matcher(toSplit);
/* 212 */         return new Splitter.SplittingIterator(splitter, toSplit, matcher) {
/*     */           public int separatorStart(int start) {
/* 214 */             return this.val$matcher.find(start) ? this.val$matcher.start() : -1;
/*     */           }
/*     */ 
/*     */           public int separatorEnd(int separatorPosition) {
/* 218 */             return this.val$matcher.end();
/*     */           }
/*     */         };
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.util.regex")
/*     */   public static Splitter onPattern(String separatorPattern)
/*     */   {
/* 242 */     return on(Pattern.compile(separatorPattern));
/*     */   }
/*     */ 
/*     */   public static Splitter fixedLength(int length)
/*     */   {
/* 256 */     Preconditions.checkArgument(length > 0, "The length may not be less than 1");
/*     */ 
/* 258 */     return new Splitter(new Strategy(length)
/*     */     {
/*     */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit) {
/* 261 */         return new Splitter.SplittingIterator(splitter, toSplit) {
/*     */           public int separatorStart(int start) {
/* 263 */             int nextChunkStart = start + Splitter.4.this.val$length;
/* 264 */             return nextChunkStart < this.toSplit.length() ? nextChunkStart : -1;
/*     */           }
/*     */ 
/*     */           public int separatorEnd(int separatorPosition) {
/* 268 */             return separatorPosition;
/*     */           }
/*     */         };
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Splitter omitEmptyStrings()
/*     */   {
/* 294 */     return new Splitter(this.strategy, true, this.trimmer);
/*     */   }
/*     */ 
/*     */   public Splitter trimResults()
/*     */   {
/* 308 */     return trimResults(CharMatcher.WHITESPACE);
/*     */   }
/*     */ 
/*     */   public Splitter trimResults(CharMatcher trimmer)
/*     */   {
/* 324 */     Preconditions.checkNotNull(trimmer);
/* 325 */     return new Splitter(this.strategy, this.omitEmptyStrings, trimmer);
/*     */   }
/*     */ 
/*     */   public Iterable<String> split(CharSequence sequence)
/*     */   {
/* 335 */     Preconditions.checkNotNull(sequence);
/*     */ 
/* 337 */     return new Iterable(sequence) {
/*     */       public Iterator<String> iterator() {
/* 339 */         return Splitter.this.strategy.iterator(Splitter.this, this.val$sequence);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private static abstract class AbstractIterator<T>
/*     */     implements Iterator<T>
/*     */   {
/*     */     State state;
/*     */     T next;
/*     */ 
/*     */     private AbstractIterator()
/*     */     {
/* 411 */       this.state = State.NOT_READY;
/*     */     }
/*     */ 
/*     */     protected abstract T computeNext();
/*     */ 
/*     */     protected final T endOfData()
/*     */     {
/* 422 */       this.state = State.DONE;
/* 423 */       return null;
/*     */     }
/*     */ 
/*     */     public final boolean hasNext() {
/* 427 */       Preconditions.checkState(this.state != State.FAILED);
/* 428 */       switch (Splitter.6.$SwitchMap$com$google$common$base$Splitter$AbstractIterator$State[this.state.ordinal()]) {
/*     */       case 1:
/* 430 */         return false;
/*     */       case 2:
/* 432 */         return true;
/*     */       }
/*     */ 
/* 435 */       return tryToComputeNext();
/*     */     }
/*     */ 
/*     */     boolean tryToComputeNext() {
/* 439 */       this.state = State.FAILED;
/* 440 */       this.next = computeNext();
/* 441 */       if (this.state != State.DONE) {
/* 442 */         this.state = State.READY;
/* 443 */         return true;
/*     */       }
/* 445 */       return false;
/*     */     }
/*     */ 
/*     */     public final T next() {
/* 449 */       if (!hasNext()) {
/* 450 */         throw new NoSuchElementException();
/*     */       }
/* 452 */       this.state = State.NOT_READY;
/* 453 */       return this.next;
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 457 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     static enum State
/*     */     {
/* 414 */       READY, NOT_READY, DONE, FAILED;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract class SplittingIterator extends Splitter.AbstractIterator<String>
/*     */   {
/*     */     final CharSequence toSplit;
/*     */     final CharMatcher trimmer;
/*     */     final boolean omitEmptyStrings;
/* 367 */     int offset = 0;
/*     */ 
/*     */     abstract int separatorStart(int paramInt);
/*     */ 
/*     */     abstract int separatorEnd(int paramInt);
/*     */ 
/* 369 */     protected SplittingIterator(Splitter splitter, CharSequence toSplit) { super();
/* 370 */       this.trimmer = splitter.trimmer;
/* 371 */       this.omitEmptyStrings = splitter.omitEmptyStrings;
/* 372 */       this.toSplit = toSplit; }
/*     */ 
/*     */     protected String computeNext()
/*     */     {
/* 376 */       while (this.offset != -1) {
/* 377 */         int start = this.offset;
/*     */ 
/* 380 */         int separatorPosition = separatorStart(this.offset);
/*     */         int end;
/* 381 */         if (separatorPosition == -1) {
/* 382 */           int end = this.toSplit.length();
/* 383 */           this.offset = -1;
/*     */         } else {
/* 385 */           end = separatorPosition;
/* 386 */           this.offset = separatorEnd(separatorPosition);
/*     */         }
/*     */ 
/* 389 */         while ((start < end) && (this.trimmer.matches(this.toSplit.charAt(start)))) {
/* 390 */           start++;
/*     */         }
/* 392 */         while ((end > start) && (this.trimmer.matches(this.toSplit.charAt(end - 1)))) {
/* 393 */           end--;
/*     */         }
/*     */ 
/* 396 */         if ((!this.omitEmptyStrings) || (start != end))
/*     */         {
/* 400 */           return this.toSplit.subSequence(start, end).toString();
/*     */         }
/*     */       }
/* 402 */       return (String)endOfData();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface Strategy
/*     */   {
/*     */     public abstract Iterator<String> iterator(Splitter paramSplitter, CharSequence paramCharSequence);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Splitter
 * JD-Core Version:    0.6.0
 */