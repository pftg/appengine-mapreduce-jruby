/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.IOException;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public abstract class CharEscaper extends Escaper
/*     */ {
/*     */   private static final int DEST_PAD = 32;
/*     */ 
/*     */   public String escape(String string)
/*     */   {
/*  42 */     Preconditions.checkNotNull(string);
/*     */ 
/*  44 */     int length = string.length();
/*  45 */     for (int index = 0; index < length; index++) {
/*  46 */       if (escape(string.charAt(index)) != null) {
/*  47 */         return escapeSlow(string, index);
/*     */       }
/*     */     }
/*  50 */     return string;
/*     */   }
/*     */ 
/*     */   public Appendable escape(Appendable out)
/*     */   {
/*  73 */     Preconditions.checkNotNull(out);
/*     */ 
/*  75 */     return new Appendable(out) {
/*     */       public Appendable append(CharSequence csq) throws IOException {
/*  77 */         this.val$out.append(CharEscaper.this.escape(csq.toString()));
/*  78 */         return this;
/*     */       }
/*     */ 
/*     */       public Appendable append(CharSequence csq, int start, int end) throws IOException {
/*  82 */         this.val$out.append(CharEscaper.this.escape(csq.subSequence(start, end).toString()));
/*  83 */         return this;
/*     */       }
/*     */ 
/*     */       public Appendable append(char c) throws IOException {
/*  87 */         char[] escaped = CharEscaper.this.escape(c);
/*  88 */         if (escaped == null)
/*  89 */           this.val$out.append(c);
/*     */         else {
/*  91 */           for (char e : escaped) {
/*  92 */             this.val$out.append(e);
/*     */           }
/*     */         }
/*  95 */         return this;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   protected String escapeSlow(String s, int index)
/*     */   {
/* 112 */     int slen = s.length();
/*     */ 
/* 115 */     char[] dest = Platform.charBufferFromThreadLocal();
/* 116 */     int destSize = dest.length;
/* 117 */     int destIndex = 0;
/* 118 */     int lastEscape = 0;
/*     */ 
/* 122 */     for (; index < slen; index++)
/*     */     {
/* 125 */       char[] r = escape(s.charAt(index));
/*     */ 
/* 128 */       if (r == null)
/*     */         continue;
/* 130 */       int rlen = r.length;
/* 131 */       int charsSkipped = index - lastEscape;
/*     */ 
/* 135 */       int sizeNeeded = destIndex + charsSkipped + rlen;
/* 136 */       if (destSize < sizeNeeded) {
/* 137 */         destSize = sizeNeeded + (slen - index) + 32;
/* 138 */         dest = growBuffer(dest, destIndex, destSize);
/*     */       }
/*     */ 
/* 142 */       if (charsSkipped > 0) {
/* 143 */         s.getChars(lastEscape, index, dest, destIndex);
/* 144 */         destIndex += charsSkipped;
/*     */       }
/*     */ 
/* 148 */       if (rlen > 0) {
/* 149 */         System.arraycopy(r, 0, dest, destIndex, rlen);
/* 150 */         destIndex += rlen;
/*     */       }
/* 152 */       lastEscape = index + 1;
/*     */     }
/*     */ 
/* 156 */     int charsLeft = slen - lastEscape;
/* 157 */     if (charsLeft > 0) {
/* 158 */       int sizeNeeded = destIndex + charsLeft;
/* 159 */       if (destSize < sizeNeeded)
/*     */       {
/* 162 */         dest = growBuffer(dest, destIndex, sizeNeeded);
/*     */       }
/* 164 */       s.getChars(lastEscape, slen, dest, destIndex);
/* 165 */       destIndex = sizeNeeded;
/*     */     }
/* 167 */     return new String(dest, 0, destIndex);
/*     */   }
/*     */ 
/*     */   protected abstract char[] escape(char paramChar);
/*     */ 
/*     */   private static char[] growBuffer(char[] dest, int index, int size)
/*     */   {
/* 192 */     char[] copy = new char[size];
/* 193 */     if (index > 0) {
/* 194 */       System.arraycopy(dest, 0, copy, 0, index);
/*     */     }
/* 196 */     return copy;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.CharEscaper
 * JD-Core Version:    0.6.0
 */