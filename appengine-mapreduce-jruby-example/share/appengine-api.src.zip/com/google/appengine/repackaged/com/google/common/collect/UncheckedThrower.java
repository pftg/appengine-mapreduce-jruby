/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ 
/*    */ @GoogleInternal
/*    */ class UncheckedThrower<T extends Throwable>
/*    */ {
/*    */   private void throwAsUnchecked2(Throwable t)
/*    */     throws Throwable
/*    */   {
/* 32 */     throw t;
/*    */   }
/*    */ 
/*    */   static void throwAsUnchecked(Throwable t)
/*    */   {
/* 40 */     new UncheckedThrower().throwAsUnchecked2(t);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.UncheckedThrower
 * JD-Core Version:    0.6.0
 */