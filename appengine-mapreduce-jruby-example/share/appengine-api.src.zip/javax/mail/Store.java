/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.FolderEvent;
/*     */ import javax.mail.event.FolderListener;
/*     */ import javax.mail.event.StoreEvent;
/*     */ import javax.mail.event.StoreListener;
/*     */ 
/*     */ public abstract class Store extends Service
/*     */ {
/*  34 */   private static final Folder[] FOLDER_ARRAY = new Folder[0];
/*  35 */   private final Vector folderListeners = new Vector(2);
/*  36 */   private final Vector storeListeners = new Vector(2);
/*     */ 
/*     */   protected Store(Session session, URLName name)
/*     */   {
/*  46 */     super(session, name);
/*     */   }
/*     */ 
/*     */   public abstract Folder getDefaultFolder()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Folder getFolder(String paramString)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Folder getFolder(URLName paramURLName)
/*     */     throws MessagingException;
/*     */ 
/*     */   public Folder[] getPersonalNamespaces()
/*     */     throws MessagingException
/*     */   {
/*  88 */     return new Folder[] { getDefaultFolder() };
/*     */   }
/*     */ 
/*     */   public Folder[] getUserNamespaces(String user)
/*     */     throws MessagingException
/*     */   {
/* 101 */     return FOLDER_ARRAY;
/*     */   }
/*     */ 
/*     */   public Folder[] getSharedNamespaces()
/*     */     throws MessagingException
/*     */   {
/* 112 */     return FOLDER_ARRAY;
/*     */   }
/*     */ 
/*     */   public void addStoreListener(StoreListener listener)
/*     */   {
/* 117 */     this.storeListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeStoreListener(StoreListener listener) {
/* 121 */     this.storeListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyStoreListeners(int type, String message) {
/* 125 */     queueEvent(new StoreEvent(this, type, message), this.storeListeners);
/*     */   }
/*     */ 
/*     */   public void addFolderListener(FolderListener listener)
/*     */   {
/* 130 */     this.folderListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeFolderListener(FolderListener listener) {
/* 134 */     this.folderListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyFolderListeners(int type, Folder folder) {
/* 138 */     queueEvent(new FolderEvent(this, folder, type), this.folderListeners);
/*     */   }
/*     */ 
/*     */   protected void notifyFolderRenamedListeners(Folder oldFolder, Folder newFolder) {
/* 142 */     queueEvent(new FolderEvent(this, oldFolder, newFolder, 3), this.folderListeners);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Store
 * JD-Core Version:    0.6.0
 */