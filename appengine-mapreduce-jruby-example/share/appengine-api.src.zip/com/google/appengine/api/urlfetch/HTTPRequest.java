/*     */ package com.google.appengine.api.urlfetch;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class HTTPRequest
/*     */   implements Serializable
/*     */ {
/*     */   private final HTTPMethod method;
/*     */   private final URL url;
/*     */   private final LinkedHashMap<String, HTTPHeader> headers;
/*     */   private final FetchOptions fetchOptions;
/*  28 */   private byte[] payload = null;
/*     */ 
/*     */   public HTTPRequest(URL url)
/*     */   {
/*  35 */     this(url, HTTPMethod.GET);
/*     */   }
/*     */ 
/*     */   public HTTPRequest(URL url, HTTPMethod method)
/*     */   {
/*  44 */     this(url, method, FetchOptions.Builder.withDefaults());
/*     */   }
/*     */ 
/*     */   public HTTPRequest(URL url, HTTPMethod method, FetchOptions fetchOptions)
/*     */   {
/*  53 */     this.url = url;
/*  54 */     this.method = method;
/*  55 */     this.fetchOptions = fetchOptions;
/*  56 */     this.headers = new LinkedHashMap();
/*     */   }
/*     */ 
/*     */   public HTTPMethod getMethod()
/*     */   {
/*  63 */     return this.method;
/*     */   }
/*     */ 
/*     */   public URL getURL()
/*     */   {
/*  70 */     return this.url;
/*     */   }
/*     */ 
/*     */   public byte[] getPayload()
/*     */   {
/*  79 */     return this.payload;
/*     */   }
/*     */ 
/*     */   public void setPayload(byte[] payload)
/*     */   {
/*  87 */     this.payload = payload;
/*     */   }
/*     */ 
/*     */   public void addHeader(HTTPHeader header)
/*     */   {
/* 100 */     String name = header.getName();
/* 101 */     HTTPHeader newHeader = (HTTPHeader)this.headers.get(name);
/* 102 */     if (newHeader == null)
/* 103 */       this.headers.put(name, new HTTPHeader(name, header.getValue()));
/*     */     else
/* 105 */       this.headers.put(name, new HTTPHeader(name, newHeader.getValue() + ", " + header.getValue()));
/*     */   }
/*     */ 
/*     */   public void setHeader(HTTPHeader header)
/*     */   {
/* 115 */     this.headers.put(header.getName(), header);
/*     */   }
/*     */ 
/*     */   public List<HTTPHeader> getHeaders()
/*     */   {
/* 123 */     return Collections.unmodifiableList(new ArrayList(this.headers.values()));
/*     */   }
/*     */ 
/*     */   public FetchOptions getFetchOptions()
/*     */   {
/* 130 */     return this.fetchOptions;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.HTTPRequest
 * JD-Core Version:    0.6.0
 */