/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.ConnectionEvent;
/*     */ import javax.mail.event.ConnectionListener;
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ public abstract class Service
/*     */ {
/*     */   protected Session session;
/*     */   protected URLName url;
/*     */   protected boolean debug;
/*     */   private boolean connected;
/*  49 */   private final Vector connectionListeners = new Vector(2);
/*     */ 
/*  52 */   private EventQueue queue = null;
/*     */   private URLName exposedUrl;
/*     */ 
/*     */   protected Service(Session session, URLName url)
/*     */   {
/*  63 */     this.session = session;
/*  64 */     this.url = url;
/*  65 */     this.debug = session.getDebug();
/*     */   }
/*     */ 
/*     */   public void connect()
/*     */     throws MessagingException
/*     */   {
/*  76 */     connect(null, null, null);
/*     */   }
/*     */ 
/*     */   public void connect(String host, String user, String password)
/*     */     throws MessagingException
/*     */   {
/*  91 */     connect(host, -1, user, password);
/*     */   }
/*     */ 
/*     */   public void connect(String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 105 */     connect(null, -1, user, password);
/*     */   }
/*     */ 
/*     */   public void connect(String host, int port, String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 123 */     if (isConnected()) {
/* 124 */       throw new IllegalStateException("Already connected");
/*     */     }
/*     */ 
/* 135 */     String protocol = null;
/*     */ 
/* 138 */     if (this.url != null) {
/* 139 */       protocol = this.url.getProtocol();
/*     */     }
/*     */ 
/* 143 */     if ((port == -1) && 
/* 144 */       (protocol != null)) {
/* 145 */       port = this.url.getPort();
/*     */     }
/*     */ 
/* 150 */     if (host == null)
/*     */     {
/* 152 */       if (this.url != null) {
/* 153 */         host = this.url.getHost();
/*     */ 
/* 156 */         if ((host == null) && 
/* 157 */           (protocol != null)) {
/* 158 */           host = this.session.getProperty("mail." + protocol + ".host");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 163 */       if (host == null) {
/* 164 */         host = this.session.getProperty("mail.host");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 169 */     if (user == null)
/*     */     {
/* 171 */       if (this.url != null) {
/* 172 */         user = this.url.getUsername();
/*     */ 
/* 174 */         if (password == null) {
/* 175 */           password = this.url.getPassword();
/*     */         }
/*     */ 
/* 178 */         if ((user == null) && 
/* 179 */           (protocol != null)) {
/* 180 */           user = this.session.getProperty("mail." + protocol + ".user");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 186 */       if (user == null) {
/* 187 */         user = this.session.getProperty("mail.user");
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 192 */         user = System.getProperty("user.name");
/*     */       }
/*     */       catch (SecurityException e)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/* 200 */     else if ((this.url != null) && (user.equals(this.url.getUsername()))) {
/* 201 */       password = this.url.getPassword();
/*     */     }
/*     */ 
/* 208 */     String file = null;
/* 209 */     if (this.url != null) {
/* 210 */       file = this.url.getFile();
/*     */     }
/*     */ 
/* 215 */     boolean cachePassword = false;
/*     */ 
/* 219 */     if ((password == null) && (this.url != null))
/*     */     {
/* 221 */       setURLName(new URLName(protocol, host, port, file, user, password));
/*     */ 
/* 223 */       PasswordAuthentication cachedPassword = this.session.getPasswordAuthentication(getURLName());
/*     */ 
/* 226 */       if (cachedPassword != null)
/*     */       {
/* 228 */         if (user == null) {
/* 229 */           user = cachedPassword.getUserName();
/* 230 */           password = cachedPassword.getPassword();
/*     */         }
/* 233 */         else if (user.equals(cachedPassword.getUserName())) {
/* 234 */           password = cachedPassword.getPassword();
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 240 */         cachePassword = true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 248 */       this.connected = protocolConnect(host, port, user, password);
/*     */     }
/*     */     catch (AuthenticationFailedException e)
/*     */     {
/*     */     }
/* 253 */     if (!this.connected) {
/* 254 */       InetAddress ipAddress = null;
/*     */       try
/*     */       {
/* 257 */         ipAddress = InetAddress.getByName(host);
/*     */       }
/*     */       catch (UnknownHostException e)
/*     */       {
/*     */       }
/* 262 */       PasswordAuthentication promptPassword = this.session.requestPasswordAuthentication(ipAddress, port, protocol, null, user);
/*     */ 
/* 266 */       if (promptPassword != null) {
/* 267 */         user = promptPassword.getUserName();
/* 268 */         password = promptPassword.getPassword();
/*     */       }
/*     */ 
/* 271 */       this.connected = protocolConnect(host, port, user, password);
/*     */     }
/*     */ 
/* 276 */     if (!this.connected) {
/* 277 */       throw new AuthenticationFailedException();
/*     */     }
/*     */ 
/* 281 */     setURLName(new URLName(protocol, host, port, file, user, password));
/*     */ 
/* 284 */     if (cachePassword) {
/* 285 */       this.session.setPasswordAuthentication(getURLName(), new PasswordAuthentication(user, password));
/*     */     }
/*     */ 
/* 289 */     setConnected(this.connected);
/* 290 */     notifyConnectionListeners(1);
/*     */   }
/*     */ 
/*     */   protected boolean protocolConnect(String host, int port, String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 315 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/* 326 */     return this.connected;
/*     */   }
/*     */ 
/*     */   protected void setConnected(boolean connected)
/*     */   {
/* 338 */     this.connected = connected;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws MessagingException
/*     */   {
/* 352 */     setConnected(false);
/* 353 */     notifyConnectionListeners(3);
/*     */   }
/*     */ 
/*     */   public URLName getURLName()
/*     */   {
/* 364 */     if ((this.exposedUrl == null) && 
/* 365 */       (this.url != null)) {
/* 366 */       this.exposedUrl = new URLName(this.url.getProtocol(), this.url.getHost(), this.url.getPort(), null, this.url.getUsername(), null);
/*     */     }
/*     */ 
/* 369 */     return this.exposedUrl;
/*     */   }
/*     */ 
/*     */   protected void setURLName(URLName url)
/*     */   {
/* 377 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public void addConnectionListener(ConnectionListener listener) {
/* 381 */     this.connectionListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeConnectionListener(ConnectionListener listener) {
/* 385 */     this.connectionListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyConnectionListeners(int type) {
/* 389 */     queueEvent(new ConnectionEvent(this, type), this.connectionListeners);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 395 */     URLName url = getURLName();
/*     */ 
/* 397 */     return url == null ? super.toString() : url.toString();
/*     */   }
/*     */ 
/*     */   protected void queueEvent(MailEvent event, Vector listeners)
/*     */   {
/* 404 */     if (listeners.isEmpty()) {
/* 405 */       return;
/*     */     }
/*     */ 
/* 408 */     if (this.queue == null) {
/* 409 */       this.queue = new EventQueue();
/*     */     }
/*     */ 
/* 412 */     this.queue.queueEvent(event, (List)listeners.clone());
/*     */   }
/*     */ 
/*     */   protected void finalize() throws Throwable
/*     */   {
/* 417 */     if (this.queue != null) {
/* 418 */       this.queue.stop();
/*     */     }
/* 420 */     this.connectionListeners.clear();
/* 421 */     super.finalize();
/*     */   }
/*     */ 
/*     */   Session getSession()
/*     */   {
/* 432 */     return this.session;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Service
 * JD-Core Version:    0.6.0
 */