/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class FetchProfile
/*     */ {
/*  72 */   private final List items = new ArrayList();
/*  73 */   private final List headers = new ArrayList();
/*     */ 
/*     */   public void add(Item item)
/*     */   {
/*  81 */     this.items.add(item);
/*     */   }
/*     */ 
/*     */   public void add(String header)
/*     */   {
/*  89 */     this.headers.add(header);
/*     */   }
/*     */ 
/*     */   public boolean contains(Item item)
/*     */   {
/*  98 */     return this.items.contains(item);
/*     */   }
/*     */ 
/*     */   public boolean contains(String header)
/*     */   {
/* 107 */     return this.headers.contains(header);
/*     */   }
/*     */ 
/*     */   public Item[] getItems()
/*     */   {
/* 115 */     return (Item[])(Item[])this.items.toArray(new Item[this.items.size()]);
/*     */   }
/*     */ 
/*     */   public String[] getHeaderNames()
/*     */   {
/* 122 */     return (String[])(String[])this.headers.toArray(new String[this.headers.size()]);
/*     */   }
/*     */ 
/*     */   public static class Item
/*     */   {
/*  46 */     public static final Item CONTENT_INFO = new Item("CONTENT_INFO");
/*     */ 
/*  57 */     public static final Item ENVELOPE = new Item("ENVELOPE");
/*     */ 
/*  63 */     public static final Item FLAGS = new Item("FLAGS");
/*     */ 
/*     */     protected Item(String name)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.FetchProfile
 * JD-Core Version:    0.6.0
 */