/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public abstract class ImmutableSet<E> extends ImmutableCollection<E>
/*     */   implements Set<E>
/*     */ {
/*     */   public static <E> ImmutableSet<E> of()
/*     */   {
/*  79 */     return EmptyImmutableSet.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> of(E element)
/*     */   {
/*  89 */     return new SingletonImmutableSet(element);
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> of(E e1, E e2)
/*     */   {
/* 101 */     return create(new Object[] { e1, e2 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3)
/*     */   {
/* 113 */     return create(new Object[] { e1, e2, e3 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4)
/*     */   {
/* 125 */     return create(new Object[] { e1, e2, e3, e4 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4, E e5)
/*     */   {
/* 137 */     return create(new Object[] { e1, e2, e3, e4, e5 });
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E[] others)
/*     */   {
/* 150 */     int size = others.length + 6;
/* 151 */     List all = new ArrayList(size);
/* 152 */     Collections.addAll(all, new Object[] { e1, e2, e3, e4, e5, e6 });
/* 153 */     Collections.addAll(all, others);
/* 154 */     return create(all, size);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static <E> ImmutableSet<E> of(E[] elements)
/*     */   {
/* 168 */     return copyOf(elements);
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> copyOf(E[] elements)
/*     */   {
/* 179 */     switch (elements.length) {
/*     */     case 0:
/* 181 */       return of();
/*     */     case 1:
/* 183 */       return of(elements[0]);
/*     */     }
/* 185 */     return create(elements);
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> copyOf(Iterable<? extends E> elements)
/*     */   {
/* 208 */     if (((elements instanceof ImmutableSet)) && (!(elements instanceof ImmutableSortedSet)))
/*     */     {
/* 211 */       ImmutableSet set = (ImmutableSet)elements;
/* 212 */       return set;
/*     */     }
/* 214 */     return copyOfInternal(Collections2.toCollection(elements));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableSet<E> copyOf(Iterator<? extends E> elements)
/*     */   {
/* 225 */     Collection list = Lists.newArrayList(elements);
/* 226 */     return copyOfInternal(list);
/*     */   }
/*     */ 
/*     */   private static <E> ImmutableSet<E> copyOfInternal(Collection<? extends E> collection)
/*     */   {
/* 233 */     switch (collection.size()) {
/*     */     case 0:
/* 235 */       return of();
/*     */     case 1:
/* 238 */       return of(collection.iterator().next());
/*     */     }
/* 240 */     return create(collection, collection.size());
/*     */   }
/*     */ 
/*     */   boolean isHashCodeFast()
/*     */   {
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object) {
/* 252 */     if (object == this) {
/* 253 */       return true;
/*     */     }
/* 255 */     if (((object instanceof ImmutableSet)) && (isHashCodeFast()) && (((ImmutableSet)object).isHashCodeFast()) && (hashCode() != object.hashCode()))
/*     */     {
/* 259 */       return false;
/*     */     }
/* 261 */     return Collections2.setEquals(this, object);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 265 */     int hashCode = 0;
/* 266 */     for (Iterator i$ = iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 267 */       hashCode += o.hashCode();
/*     */     }
/* 269 */     return hashCode;
/*     */   }
/*     */ 
/*     */   public abstract UnmodifiableIterator<E> iterator();
/*     */ 
/*     */   private static <E> ImmutableSet<E> create(E[] elements)
/*     */   {
/* 277 */     return create(Arrays.asList(elements), elements.length);
/*     */   }
/*     */ 
/*     */   private static <E> ImmutableSet<E> create(Iterable<? extends E> iterable, int count)
/*     */   {
/* 283 */     int tableSize = Hashing.chooseTableSize(count);
/* 284 */     Object[] table = new Object[tableSize];
/* 285 */     int mask = tableSize - 1;
/*     */ 
/* 287 */     List elements = new ArrayList(count);
/* 288 */     int hashCode = 0;
/*     */ 
/* 290 */     for (Iterator i$ = iterable.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 291 */       int hash = element.hashCode();
/* 292 */       for (int i = Hashing.smear(hash); ; i++) {
/* 293 */         int index = i & mask;
/* 294 */         Object value = table[index];
/* 295 */         if (value == null)
/*     */         {
/* 297 */           table[index] = element;
/* 298 */           elements.add(element);
/* 299 */           hashCode += hash;
/* 300 */           break;
/* 301 */         }if (value.equals(element))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 307 */     if (elements.size() == 1)
/*     */     {
/* 309 */       return new SingletonImmutableSet(elements.get(0), hashCode);
/* 310 */     }if (tableSize > Hashing.chooseTableSize(elements.size()))
/*     */     {
/* 312 */       return create(elements, elements.size());
/*     */     }
/* 314 */     return new RegularImmutableSet(elements.toArray(), hashCode, table, mask);
/*     */   }
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 463 */     return new SerializedForm(toArray());
/*     */   }
/*     */ 
/*     */   public static <E> Builder<E> builder()
/*     */   {
/* 471 */     return new Builder();
/*     */   }
/*     */ 
/*     */   public static class Builder<E> extends ImmutableCollection.Builder<E>
/*     */   {
/* 492 */     final ArrayList<E> contents = Lists.newArrayList();
/*     */ 
/*     */     public Builder<E> add(E element)
/*     */     {
/* 510 */       this.contents.add(Preconditions.checkNotNull(element));
/* 511 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> add(E[] elements)
/*     */     {
/* 524 */       this.contents.ensureCapacity(this.contents.size() + elements.length);
/* 525 */       super.add(elements);
/* 526 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterable<? extends E> elements)
/*     */     {
/* 539 */       if ((elements instanceof Collection)) {
/* 540 */         Collection collection = (Collection)elements;
/* 541 */         this.contents.ensureCapacity(this.contents.size() + collection.size());
/*     */       }
/* 543 */       super.addAll(elements);
/* 544 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterator<? extends E> elements)
/*     */     {
/* 557 */       super.addAll(elements);
/* 558 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableSet<E> build()
/*     */     {
/* 566 */       return ImmutableSet.copyOf(this.contents);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SerializedForm
/*     */     implements Serializable
/*     */   {
/*     */     final Object[] elements;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SerializedForm(Object[] elements)
/*     */     {
/* 454 */       this.elements = elements;
/*     */     }
/*     */     Object readResolve() {
/* 457 */       return ImmutableSet.copyOf(this.elements);
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class TransformedImmutableSet<D, E> extends ImmutableSet<E>
/*     */   {
/*     */     final D[] source;
/*     */     final int hashCode;
/*     */ 
/*     */     TransformedImmutableSet(D[] source, int hashCode)
/*     */     {
/* 390 */       this.source = source;
/* 391 */       this.hashCode = hashCode;
/*     */     }
/*     */     abstract E transform(D paramD);
/*     */ 
/*     */     public int size() {
/* 397 */       return this.source.length;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 401 */       return false;
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<E> iterator() {
/* 405 */       return new AbstractIterator() {
/* 406 */         int index = 0;
/*     */ 
/* 408 */         protected E computeNext() { return this.index < ImmutableSet.TransformedImmutableSet.this.source.length ? ImmutableSet.TransformedImmutableSet.this.transform(ImmutableSet.TransformedImmutableSet.this.source[(this.index++)]) : endOfData();
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 416 */       return toArray(new Object[size()]);
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 420 */       int size = size();
/* 421 */       if (array.length < size)
/* 422 */         array = ObjectArrays.newArray(array, size);
/* 423 */       else if (array.length > size) {
/* 424 */         array[size] = null;
/*     */       }
/*     */ 
/* 428 */       Object[] objectArray = array;
/* 429 */       for (int i = 0; i < this.source.length; i++) {
/* 430 */         objectArray[i] = transform(this.source[i]);
/*     */       }
/* 432 */       return array;
/*     */     }
/*     */ 
/*     */     public final int hashCode() {
/* 436 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     boolean isHashCodeFast() {
/* 440 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class ArrayImmutableSet<E> extends ImmutableSet<E>
/*     */   {
/*     */     final transient Object[] elements;
/*     */ 
/*     */     ArrayImmutableSet(Object[] elements)
/*     */     {
/* 324 */       this.elements = elements;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 328 */       return this.elements.length;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 332 */       return false;
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<E> iterator()
/*     */     {
/* 341 */       return Iterators.forArray(this.elements);
/*     */     }
/*     */ 
/*     */     public Object[] toArray() {
/* 345 */       Object[] array = new Object[size()];
/* 346 */       System.arraycopy(this.elements, 0, array, 0, size());
/* 347 */       return array;
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 351 */       int size = size();
/* 352 */       if (array.length < size)
/* 353 */         array = ObjectArrays.newArray(array, size);
/* 354 */       else if (array.length > size) {
/* 355 */         array[size] = null;
/*     */       }
/* 357 */       System.arraycopy(this.elements, 0, array, 0, size);
/* 358 */       return array;
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection<?> targets) {
/* 362 */       if (targets == this) {
/* 363 */         return true;
/*     */       }
/* 365 */       if (!(targets instanceof ArrayImmutableSet)) {
/* 366 */         return super.containsAll(targets);
/*     */       }
/* 368 */       if (targets.size() > size()) {
/* 369 */         return false;
/*     */       }
/* 371 */       for (Object target : ((ArrayImmutableSet)targets).elements) {
/* 372 */         if (!contains(target)) {
/* 373 */           return false;
/*     */         }
/*     */       }
/* 376 */       return true;
/*     */     }
/*     */ 
/*     */     ImmutableList<E> createAsList() {
/* 380 */       return new ImmutableAsList(this.elements, this);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableSet
 * JD-Core Version:    0.6.0
 */