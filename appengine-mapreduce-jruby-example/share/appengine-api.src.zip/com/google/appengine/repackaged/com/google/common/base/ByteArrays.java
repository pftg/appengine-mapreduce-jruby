/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ 
/*    */ @GoogleInternal
/*    */ public final class ByteArrays
/*    */ {
/* 18 */   private static final char[] HEX_DIGITS = "0123456789abcdef".toCharArray();
/*    */ 
/*    */   public static String toHexString(byte[] bytes)
/*    */   {
/* 25 */     StringBuilder sb = new StringBuilder(2 * bytes.length);
/* 26 */     for (byte b : bytes) {
/* 27 */       sb.append(HEX_DIGITS[(b >> 4 & 0xF)]).append(HEX_DIGITS[(b & 0xF)]);
/*    */     }
/* 29 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.ByteArrays
 * JD-Core Version:    0.6.0
 */