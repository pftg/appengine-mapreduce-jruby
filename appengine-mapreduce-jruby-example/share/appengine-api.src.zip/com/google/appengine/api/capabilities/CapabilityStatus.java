/*    */ package com.google.appengine.api.capabilities;
/*    */ 
/*    */ public enum CapabilityStatus
/*    */ {
/* 14 */   ENABLED, 
/*    */ 
/* 18 */   SCHEDULED_MAINTENANCE, 
/*    */ 
/* 23 */   DISABLED, 
/*    */ 
/* 28 */   UNKNOWN;
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.CapabilityStatus
 * JD-Core Version:    0.6.0
 */