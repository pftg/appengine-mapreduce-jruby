/*      */ package javax.mail;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.Properties;
/*      */ 
/*      */ class Session$2
/*      */   implements StreamLoader
/*      */ {
/*      */   public void load(InputStream is)
/*      */     throws IOException
/*      */   {
/* 1007 */     Session.access$100(this.this$0).load(is);
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Session.2
 * JD-Core Version:    0.6.0
 */