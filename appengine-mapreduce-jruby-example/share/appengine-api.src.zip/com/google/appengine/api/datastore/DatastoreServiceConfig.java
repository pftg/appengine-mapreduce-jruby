/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ public final class DatastoreServiceConfig
/*     */ {
/*  33 */   private ImplicitTransactionManagementPolicy implicitTransactionManagementPolicy = ImplicitTransactionManagementPolicy.NONE;
/*     */ 
/*  36 */   private ReadPolicy readPolicy = new ReadPolicy(ReadPolicy.Consistency.STRONG);
/*     */   private Double deadline;
/*     */ 
/*     */   public DatastoreServiceConfig implicitTransactionManagementPolicy(ImplicitTransactionManagementPolicy p)
/*     */   {
/*  52 */     if (p == null) {
/*  53 */       throw new NullPointerException("implicit transaction management policy must not be null");
/*     */     }
/*  55 */     this.implicitTransactionManagementPolicy = p;
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */   public DatastoreServiceConfig readPolicy(ReadPolicy readPolicy)
/*     */   {
/*  65 */     if (readPolicy == null) {
/*  66 */       throw new NullPointerException("read policy must not be null");
/*     */     }
/*  68 */     this.readPolicy = readPolicy;
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */   public DatastoreServiceConfig deadline(double deadline)
/*     */   {
/*  80 */     if (deadline <= 0.0D) {
/*  81 */       throw new IllegalArgumentException("deadline must be > 0, got " + deadline);
/*     */     }
/*  83 */     this.deadline = Double.valueOf(deadline);
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   public ImplicitTransactionManagementPolicy getImplicitTransactionManagementPolicy()
/*     */   {
/*  91 */     return this.implicitTransactionManagementPolicy;
/*     */   }
/*     */ 
/*     */   public ReadPolicy getReadPolicy()
/*     */   {
/*  98 */     return this.readPolicy;
/*     */   }
/*     */ 
/*     */   public Double getDeadline()
/*     */   {
/* 105 */     return this.deadline;
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*     */     public static DatastoreServiceConfig withImplicitTransactionManagementPolicy(ImplicitTransactionManagementPolicy p)
/*     */     {
/* 121 */       return withDefaults().implicitTransactionManagementPolicy(p);
/*     */     }
/*     */ 
/*     */     public static DatastoreServiceConfig withReadPolicy(ReadPolicy readPolicy)
/*     */     {
/* 131 */       return withDefaults().readPolicy(readPolicy);
/*     */     }
/*     */ 
/*     */     public static DatastoreServiceConfig withDeadline(double deadline)
/*     */     {
/* 140 */       return withDefaults().deadline(deadline);
/*     */     }
/*     */ 
/*     */     public static DatastoreServiceConfig withDefaults()
/*     */     {
/* 151 */       return new DatastoreServiceConfig(null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreServiceConfig
 * JD-Core Version:    0.6.0
 */