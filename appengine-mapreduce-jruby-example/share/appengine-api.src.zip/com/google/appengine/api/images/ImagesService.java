/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ import com.google.appengine.api.blobstore.BlobKey;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ public abstract interface ImagesService
/*    */ {
/*    */   public static final int MAX_TRANSFORMS_PER_REQUEST = 10;
/*    */   public static final int MAX_RESIZE_DIMENSIONS = 4000;
/*    */   public static final int MAX_COMPOSITES_PER_REQUEST = 16;
/* 34 */   public static final Set<Integer> SERVING_SIZES = new TreeSet(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(32), Integer.valueOf(48), Integer.valueOf(64), Integer.valueOf(72), Integer.valueOf(80), Integer.valueOf(90), Integer.valueOf(94), Integer.valueOf(104), Integer.valueOf(110), Integer.valueOf(120), Integer.valueOf(128), Integer.valueOf(144), Integer.valueOf(150), Integer.valueOf(160), Integer.valueOf(200), Integer.valueOf(220), Integer.valueOf(288), Integer.valueOf(320), Integer.valueOf(400), Integer.valueOf(512), Integer.valueOf(576), Integer.valueOf(640), Integer.valueOf(720), Integer.valueOf(800), Integer.valueOf(912), Integer.valueOf(1024), Integer.valueOf(1152), Integer.valueOf(1280), Integer.valueOf(1440), Integer.valueOf(1600) }));
/*    */ 
/* 48 */   public static final Set<Integer> SERVING_CROP_SIZES = new TreeSet(Arrays.asList(new Integer[] { Integer.valueOf(32), Integer.valueOf(48), Integer.valueOf(64), Integer.valueOf(72), Integer.valueOf(80), Integer.valueOf(104), Integer.valueOf(136), Integer.valueOf(144), Integer.valueOf(150), Integer.valueOf(160) }));
/*    */ 
/*    */   public abstract Image applyTransform(Transform paramTransform, Image paramImage);
/*    */ 
/*    */   public abstract Image applyTransform(Transform paramTransform, Image paramImage, OutputEncoding paramOutputEncoding);
/*    */ 
/*    */   public abstract Image composite(Collection<Composite> paramCollection, int paramInt1, int paramInt2, long paramLong);
/*    */ 
/*    */   public abstract Image composite(Collection<Composite> paramCollection, int paramInt1, int paramInt2, long paramLong, OutputEncoding paramOutputEncoding);
/*    */ 
/*    */   public abstract int[][] histogram(Image paramImage);
/*    */ 
/*    */   public abstract String getServingUrl(BlobKey paramBlobKey);
/*    */ 
/*    */   public abstract String getServingUrl(BlobKey paramBlobKey, int paramInt, boolean paramBoolean);
/*    */ 
/* 55 */   public static enum OutputEncoding { PNG, JPEG;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImagesService
 * JD-Core Version:    0.6.0
 */