/*    */ package com.google.apphosting.api;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class ApiStats
/*    */ {
/* 18 */   private static final String KEY = ApiStats.class.getName();
/*    */ 
/*    */   public static ApiStats get(ApiProxy.Environment env)
/*    */   {
/* 25 */     return (ApiStats)env.getAttributes().get(KEY);
/*    */   }
/*    */ 
/*    */   public abstract long getApiTimeInMegaCycles();
/*    */ 
/*    */   public abstract long getCpuTimeInMegaCycles();
/*    */ 
/*    */   protected ApiStats(ApiProxy.Environment env)
/*    */   {
/* 45 */     bind(env);
/*    */   }
/*    */ 
/*    */   private void bind(ApiProxy.Environment env)
/*    */   {
/* 56 */     ApiStats original = get(env);
/* 57 */     if (original != null)
/*    */     {
/* 60 */       if (original != this) {
/* 61 */         throw new IllegalStateException("Cannot replace existing ApiStats object");
/*    */       }
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 68 */       env.getAttributes().put(KEY, this);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.api.ApiStats
 * JD-Core Version:    0.6.0
 */