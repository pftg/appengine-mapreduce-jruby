/*     */ package com.google.appengine.api.blobstore;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ class BlobstoreServiceImpl
/*     */   implements BlobstoreService
/*     */ {
/*     */   static final String PACKAGE = "blobstore";
/*     */   static final String SERVE_HEADER = "X-AppEngine-BlobKey";
/*     */   static final String UPLOADED_BLOBKEY_ATTR = "com.google.appengine.api.blobstore.upload.blobkeys";
/*     */   static final String BLOB_RANGE_HEADER = "X-AppEngine-BlobRange";
/*     */ 
/*     */   public String createUploadUrl(String successPath)
/*     */   {
/*  34 */     if (successPath == null) {
/*  35 */       throw new NullPointerException("Success path must not be null.");
/*  38 */     }
/*     */ BlobstoreServicePb.CreateUploadURLRequest request = new BlobstoreServicePb.CreateUploadURLRequest();
/*  39 */     request.setSuccessPath(successPath);
/*     */     byte[] responseBytes;
/*     */     try { responseBytes = ApiProxy.makeSyncCall("blobstore", "CreateUploadURL", request.toByteArray());
/*     */     } catch (ApiProxy.ApplicationException ex) {
/*  45 */       switch (1.$SwitchMap$com$google$appengine$api$blobstore$BlobstoreServicePb$BlobstoreServiceError$ErrorCode[BlobstoreServicePb.BlobstoreServiceError.ErrorCode.valueOf(ex.getApplicationError()).ordinal()]) {
/*     */       case 1:
/*  47 */         throw new IllegalArgumentException("The resulting URL was too long.");
/*     */       case 2:
/*     */       }
/*  49 */     }throw new BlobstoreFailureException("An internal blobstore error occured.");
/*     */ 
/*  51 */     throw new BlobstoreFailureException("An unexpected error occurred.", ex);
/*     */ 
/*  55 */     BlobstoreServicePb.CreateUploadURLResponse response = new BlobstoreServicePb.CreateUploadURLResponse();
/*  56 */     response.mergeFrom(responseBytes);
/*  57 */     return response.getUrl();
/*     */   }
/*     */ 
/*     */   public void serve(BlobKey blobKey, HttpServletResponse response) {
/*  61 */     serve(blobKey, (ByteRange)null, response);
/*     */   }
/*     */ 
/*     */   public void serve(BlobKey blobKey, String rangeHeader, HttpServletResponse response) {
/*  65 */     serve(blobKey, ByteRange.parse(rangeHeader), response);
/*     */   }
/*     */ 
/*     */   public void serve(BlobKey blobKey, ByteRange byteRange, HttpServletResponse response) {
/*  69 */     if (response.isCommitted()) {
/*  70 */       throw new IllegalStateException("Response was already committed.");
/*     */     }
/*     */ 
/*  74 */     response.setStatus(200);
/*  75 */     response.setHeader("X-AppEngine-BlobKey", blobKey.getKeyString());
/*  76 */     if (byteRange != null)
/*  77 */       response.setHeader("X-AppEngine-BlobRange", byteRange.toString());
/*     */   }
/*     */ 
/*     */   public ByteRange getByteRange(HttpServletRequest request)
/*     */   {
/*  83 */     Enumeration rangeHeaders = request.getHeaders("range");
/*  84 */     if (!rangeHeaders.hasMoreElements()) {
/*  85 */       return null;
/*     */     }
/*     */ 
/*  88 */     String rangeHeader = (String)rangeHeaders.nextElement();
/*  89 */     if (rangeHeaders.hasMoreElements()) {
/*  90 */       throw new UnsupportedRangeFormatException("Cannot accept multiple range headers.");
/*     */     }
/*     */ 
/*  93 */     return ByteRange.parse(rangeHeader);
/*     */   }
/*     */ 
/*     */   public void delete(BlobKey[] blobKeys) {
/*  97 */     BlobstoreServicePb.DeleteBlobRequest request = new BlobstoreServicePb.DeleteBlobRequest();
/*  98 */     for (BlobKey blobKey : blobKeys) {
/*  99 */       request.addBlobKey(blobKey.getKeyString());
/*     */     }
/*     */ 
/* 102 */     if (request.blobKeySize() == 0) {
/* 103 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 108 */       responseBytes = ApiProxy.makeSyncCall("blobstore", "DeleteBlob", request.toByteArray());
/*     */     }
/*     */     catch (ApiProxy.ApplicationException ex)
/*     */     {
/*     */       byte[] responseBytes;
/* 110 */       switch (1.$SwitchMap$com$google$appengine$api$blobstore$BlobstoreServicePb$BlobstoreServiceError$ErrorCode[BlobstoreServicePb.BlobstoreServiceError.ErrorCode.valueOf(ex.getApplicationError()).ordinal()]) {
/*     */       case 2:
/* 112 */         throw new BlobstoreFailureException("An internal blobstore error occured.");
/*     */       }
/*     */     }
/* 114 */     throw new BlobstoreFailureException("An unexpected error occurred.", ex);
/*     */   }
/*     */ 
/*     */   public Map<String, BlobKey> getUploadedBlobs(HttpServletRequest request)
/*     */   {
/* 125 */     Map attributes = (Map)request.getAttribute("com.google.appengine.api.blobstore.upload.blobkeys");
/*     */ 
/* 127 */     if (attributes == null) {
/* 128 */       throw new IllegalStateException("Must be called from a blob upload callback request.");
/*     */     }
/* 130 */     Map blobKeys = new HashMap(attributes.size());
/* 131 */     for (Map.Entry attr : attributes.entrySet()) {
/* 132 */       blobKeys.put(attr.getKey(), new BlobKey((String)attr.getValue()));
/*     */     }
/* 134 */     return blobKeys;
/*     */   }
/*     */ 
/*     */   public byte[] fetchData(BlobKey blobKey, long startIndex, long endIndex) {
/* 138 */     if (startIndex < 0L) {
/* 139 */       throw new IllegalArgumentException("Start index must be >= 0.");
/*     */     }
/*     */ 
/* 142 */     if (endIndex < startIndex) {
/* 143 */       throw new IllegalArgumentException("End index must be >= startIndex.");
/*     */     }
/*     */ 
/* 147 */     long fetchSize = endIndex - startIndex + 1L;
/* 148 */     if (fetchSize > 1015808L) {
/* 149 */       throw new IllegalArgumentException("Blob fetch size " + fetchSize + " it larger " + "than maximum size " + 1015808 + " bytes."); } 
/*     */ BlobstoreServicePb.FetchDataRequest request = new BlobstoreServicePb.FetchDataRequest();
/* 154 */     request.setBlobKey(blobKey.getKeyString());
/* 155 */     request.setStartIndex(startIndex);
/* 156 */     request.setEndIndex(endIndex);
/*     */     byte[] responseBytes;
/*     */     try { responseBytes = ApiProxy.makeSyncCall("blobstore", "FetchData", request.toByteArray());
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 162 */       switch (1.$SwitchMap$com$google$appengine$api$blobstore$BlobstoreServicePb$BlobstoreServiceError$ErrorCode[BlobstoreServicePb.BlobstoreServiceError.ErrorCode.valueOf(ex.getApplicationError()).ordinal()]) {
/*     */       case 3:
/* 164 */         throw new SecurityException("This application does not have access to that blob.");
/*     */       case 4:
/*     */       case 2: } 
/* 166 */     }throw new IllegalArgumentException("Blob not found.");
/*     */ 
/* 168 */     throw new BlobstoreFailureException("An internal blobstore error occured.");
/*     */ 
/* 170 */     throw new BlobstoreFailureException("An unexpected error occurred.", ex);
/*     */ 
/* 174 */     BlobstoreServicePb.FetchDataResponse response = new BlobstoreServicePb.FetchDataResponse();
/* 175 */     response.mergeFrom(responseBytes);
/* 176 */     return response.getDataAsBytes();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobstoreServiceImpl
 * JD-Core Version:    0.6.0
 */