/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ abstract class BasePreparedQuery
/*    */   implements PreparedQuery
/*    */ {
/*    */   public Iterable<Entity> asIterable(FetchOptions fetchOptions)
/*    */   {
/* 23 */     return new Iterable(fetchOptions)
/*    */     {
/*    */       public Iterator<Entity> iterator() {
/* 26 */         return BasePreparedQuery.this.asIterator(this.val$fetchOptions);
/*    */       }
/*    */     };
/*    */   }
/*    */ 
/*    */   public Iterable<Entity> asIterable() {
/* 33 */     return asIterable(FetchOptions.Builder.withDefaults());
/*    */   }
/*    */ 
/*    */   public Iterator<Entity> asIterator()
/*    */   {
/* 38 */     return asIterator(FetchOptions.Builder.withDefaults());
/*    */   }
/*    */ 
/*    */   public QueryResultIterable<Entity> asQueryResultIterable(FetchOptions fetchOptions)
/*    */   {
/* 43 */     return new QueryResultIterable(fetchOptions)
/*    */     {
/*    */       public QueryResultIterator<Entity> iterator() {
/* 46 */         return BasePreparedQuery.this.asQueryResultIterator(this.val$fetchOptions);
/*    */       }
/*    */     };
/*    */   }
/*    */ 
/*    */   public QueryResultIterable<Entity> asQueryResultIterable() {
/* 53 */     return asQueryResultIterable(FetchOptions.Builder.withDefaults());
/*    */   }
/*    */ 
/*    */   public QueryResultIterator<Entity> asQueryResultIterator()
/*    */   {
/* 58 */     return asQueryResultIterator(FetchOptions.Builder.withDefaults());
/*    */   }
/*    */ 
/*    */   static abstract class UncompilablePreparedQuery extends BasePreparedQuery
/*    */   {
/*    */     public QueryResultIterator<Entity> asQueryResultIterator(FetchOptions fetchOptions)
/*    */     {
/* 69 */       Iterator delegate = asIterator(fetchOptions);
/* 70 */       return new QueryResultIterator(delegate)
/*    */       {
/*    */         public Cursor getCursor() {
/* 73 */           return null;
/*    */         }
/*    */ 
/*    */         public boolean hasNext()
/*    */         {
/* 78 */           return this.val$delegate.hasNext();
/*    */         }
/*    */ 
/*    */         public Entity next()
/*    */         {
/* 83 */           return (Entity)this.val$delegate.next();
/*    */         }
/*    */ 
/*    */         public void remove()
/*    */         {
/* 88 */           this.val$delegate.remove();
/*    */         }
/*    */       };
/*    */     }
/*    */ 
/*    */     public QueryResultList<Entity> asQueryResultList(FetchOptions fetchOptions) {
/* 95 */       return new QueryResultListImpl(asList(fetchOptions), null);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.BasePreparedQuery
 * JD-Core Version:    0.6.0
 */