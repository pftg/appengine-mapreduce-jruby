/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ 
/*    */ @GwtCompatible(emulated=true)
/*    */ final class Platform
/*    */ {
/* 54 */   private static final ThreadLocal<char[]> DEST_TL = new ThreadLocal()
/*    */   {
/*    */     protected char[] initialValue() {
/* 57 */       return new char[1024];
/*    */     }
/* 54 */   };
/*    */ 
/*    */   static boolean isInstance(Class<?> clazz, Object obj)
/*    */   {
/* 36 */     return clazz.isInstance(obj);
/*    */   }
/*    */ 
/*    */   static char[] charBufferFromThreadLocal()
/*    */   {
/* 41 */     return (char[])DEST_TL.get();
/*    */   }
/*    */ 
/*    */   static long systemNanoTime()
/*    */   {
/* 46 */     return System.nanoTime();
/*    */   }
/*    */ 
/*    */   static CharMatcher precomputeCharMatcher(CharMatcher matcher)
/*    */   {
/* 62 */     return matcher.precomputedInternal();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Platform
 * JD-Core Version:    0.6.0
 */