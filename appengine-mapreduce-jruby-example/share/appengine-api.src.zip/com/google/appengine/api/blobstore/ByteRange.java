/*     */ package com.google.appengine.api.blobstore;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ByteRange
/*     */ {
/*     */   private long start;
/*     */   private Long end;
/*     */   static final String BYTES_UNIT = "bytes";
/*     */   static final String UNIT_REGEX = "([^=\\s]+)";
/*     */   static final String VALID_RANGE_HEADER_REGEX = "([^=\\s]+)\\s*=\\s*(\\d*)\\s*-\\s*(\\d*)";
/*     */   static final String INVALID_RANGE_HEADER_REGEX = "((?:\\s*,\\s*(?:\\d*)-(?:\\d*))*)";
/*  23 */   static final Pattern RANGE_HEADER_PATTERN = Pattern.compile("^\\s*([^=\\s]+)\\s*=\\s*(\\d*)\\s*-\\s*(\\d*)((?:\\s*,\\s*(?:\\d*)-(?:\\d*))*)\\s*$");
/*     */   static final String CONTENT_RANGE_UNIT_REGEX = "([^\\s]+)";
/*     */   static final String VALID_CONTENT_RANGE_HEADER_REGEX = "bytes\\s+(\\d+)-(\\d+)/(\\d+)";
/*  31 */   static final Pattern CONTENT_RANGE_HEADER_PATTERN = Pattern.compile("^\\s*bytes\\s+(\\d+)-(\\d+)/(\\d+)\\s*$");
/*     */ 
/*     */   public ByteRange(long start)
/*     */   {
/*  41 */     this(start, null);
/*     */   }
/*     */ 
/*     */   public ByteRange(long start, long end)
/*     */   {
/*  52 */     this(start, Long.valueOf(end));
/*     */ 
/*  54 */     if (start < 0L) {
/*  55 */       throw new IllegalArgumentException("If end is provided, start must be positive.");
/*     */     }
/*     */ 
/*  58 */     if (end < start)
/*  59 */       throw new IllegalArgumentException("end must be >= start.");
/*     */   }
/*     */ 
/*     */   protected ByteRange(long start, Long end)
/*     */   {
/*  64 */     this.start = start;
/*  65 */     this.end = end;
/*     */   }
/*     */ 
/*     */   public boolean hasEnd()
/*     */   {
/*  74 */     return this.end != null;
/*     */   }
/*     */ 
/*     */   public long getStart()
/*     */   {
/*  83 */     return this.start;
/*     */   }
/*     */ 
/*     */   public long getEnd()
/*     */   {
/*  94 */     if (!hasEnd()) {
/*  95 */       throw new IllegalStateException("Byte-range does not have end.  Check hasEnd() before use");
/*     */     }
/*  97 */     return this.end.longValue();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 105 */     if (this.end != null) {
/* 106 */       return "bytes=" + this.start + "-" + this.end;
/*     */     }
/* 108 */     if (this.start < 0L) {
/* 109 */       return "bytes=" + this.start;
/*     */     }
/* 111 */     return "bytes=" + this.start + "-";
/*     */   }
/*     */ 
/*     */   public static ByteRange parse(String byteRange)
/*     */   {
/* 129 */     Matcher matcher = RANGE_HEADER_PATTERN.matcher(byteRange);
/* 130 */     if (!matcher.matches()) {
/* 131 */       throw new RangeFormatException("Invalid range format: " + byteRange);
/*     */     }
/*     */ 
/* 134 */     String unsupportedRange = matcher.group(4);
/* 135 */     if (!"".equals(unsupportedRange)) {
/* 136 */       throw new UnsupportedRangeFormatException("Unsupported range format: " + byteRange);
/*     */     }
/*     */ 
/* 139 */     String units = matcher.group(1);
/* 140 */     if (!"bytes".equals(units)) {
/* 141 */       throw new UnsupportedRangeFormatException("Unsupported unit: " + units);
/*     */     }
/*     */ 
/* 144 */     String start = matcher.group(2);
/*     */     Long startValue;
/*     */     Long startValue;
/* 146 */     if ("".equals(start))
/* 147 */       startValue = null;
/*     */     else {
/* 149 */       startValue = Long.valueOf(Long.parseLong(start));
/*     */     }
/*     */ 
/* 152 */     String end = matcher.group(3);
/*     */     Long endValue;
/*     */     Long endValue;
/* 154 */     if ("".equals(end))
/* 155 */       endValue = null;
/*     */     else {
/* 157 */       endValue = Long.valueOf(Long.parseLong(end));
/*     */     }
/*     */ 
/* 161 */     if ((startValue == null) && (endValue != null)) {
/* 162 */       startValue = Long.valueOf(-endValue.longValue());
/* 163 */       endValue = null;
/*     */     }
/*     */ 
/* 166 */     if (endValue == null) {
/* 167 */       return new ByteRange(startValue.longValue());
/*     */     }
/* 169 */     return new ByteRange(startValue.longValue(), endValue.longValue());
/*     */   }
/*     */ 
/*     */   public static ByteRange parseContentRange(String contentRange)
/*     */   {
/* 184 */     Matcher matcher = CONTENT_RANGE_HEADER_PATTERN.matcher(contentRange);
/* 185 */     if (!matcher.matches()) {
/* 186 */       throw new RangeFormatException("Invalid content-range format: " + contentRange);
/*     */     }
/*     */ 
/* 189 */     return new ByteRange(Long.parseLong(matcher.group(1)), Long.parseLong(matcher.group(2)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 194 */     int hash = 17;
/* 195 */     hash = hash * 37 + Long.valueOf(this.start).hashCode();
/* 196 */     if (this.end != null) {
/* 197 */       hash = hash * 37 + this.end.hashCode();
/*     */     }
/* 199 */     return hash;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 207 */     if ((object instanceof ByteRange)) {
/* 208 */       ByteRange key = (ByteRange)object;
/* 209 */       if (this.start != key.getStart()) {
/* 210 */         return false;
/*     */       }
/*     */ 
/* 213 */       if (hasEnd() != key.hasEnd()) {
/* 214 */         return false;
/*     */       }
/*     */ 
/* 217 */       if (hasEnd()) {
/* 218 */         return this.end.equals(Long.valueOf(key.getEnd()));
/*     */       }
/* 220 */       return true;
/*     */     }
/*     */ 
/* 224 */     return false;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.ByteRange
 * JD-Core Version:    0.6.0
 */