/*      */ package com.google.appengine.repackaged.com.google.io.protocol;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Charsets;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Strings;
/*      */ import com.google.appengine.repackaged.com.google.common.collect.Lists;
/*      */ import com.google.appengine.repackaged.com.google.common.util.UnsignedLong;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.lang.reflect.Field;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.logging.Logger;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ public class ProtocolTextParser
/*      */ {
/*      */   private static final Logger logger;
/*      */   private static final Pattern PATTERN_LBRACE;
/*      */   private static final Pattern PATTERN_LSQUARE;
/*      */   private static final Pattern PATTERN_LANGLE_OR_LBRACE;
/*      */   private static final Pattern PATTERN_RBRACE;
/*      */   private static final Pattern PATTERN_RSQUARE;
/*      */   private static final Pattern PATTERN_RANGLE;
/*      */   private static final Pattern PATTERN_OPTIONAL_INDEX;
/*      */   private static final Pattern PATTERN_SEPARATOR;
/*      */   private static final Pattern PATTERN_ID;
/*      */   private static final Pattern PATTERN_CLASS_NAME;
/*      */   private static final Pattern PATTERN_INT;
/*      */   private static final Pattern PATTERN_FLOAT;
/*      */   private static final Pattern PATTERN_INFINITY;
/*      */   private static final Pattern PATTERN_NAN;
/*      */   private static final Pattern PATTERN_DQUOTE;
/*      */   private static final Pattern PATTERN_SIMPLE_STRING;
/*      */   private static final Pattern PATTERN_NEWLINE_TERMINATED_SIMPLE_STRING;
/*      */   private static final Pattern PATTERN_SINGLE_CHAR_ESCAPE_SEQ;
/*      */   private static final Pattern PATTERN_SINGLE_BYTE_ESCAPE_SEQ;
/*      */   private static final Pattern PATTERN_TERMINATOR;
/*      */   private static final Pattern PATTERN_END;
/*      */   private static final Pattern PATTERN_COMMENTS;
/*      */   private static final Pattern PATTERN_NEWLINE;
/*      */   private static final Pattern PATTERN_DOT;
/*      */   private static final Pattern PATTERN_TAG;
/*      */   private final Scanner in;
/*      */   private final boolean ignoreUndefinedTags;
/*      */   private final boolean interpretOctOrHexEscapeAsByte;
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> T parse(CharSequence sequence, Class<T> clazz)
/*      */   {
/*  123 */     return parse(sequence, ProtocolSupport.newInstance(clazz));
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> T parseCppCompatible(CharSequence sequence, Class<T> clazz)
/*      */   {
/*  138 */     return parse(sequence, ProtocolSupport.newInstance(clazz), false, true);
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<T>> T parse(CharSequence sequence, Class<T> clazz, boolean ignoreUndefinedTags)
/*      */   {
/*  151 */     return parse(sequence, ProtocolSupport.newInstance(clazz), ignoreUndefinedTags);
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> T parse(CharSequence sequence, T instance)
/*      */   {
/*  164 */     return parse(sequence, instance, false);
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> T parse(CharSequence sequence, T instance, boolean ignoreUndefinedTags)
/*      */   {
/*  178 */     return parse(sequence, instance, ignoreUndefinedTags, false);
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> T parse(CharSequence sequence, T instance, boolean ignoreUndefinedTags, boolean interpretOctOrHexEscapeAsByte)
/*      */   {
/*  194 */     CategoryInformation categoryInformation = instance.messageCategoryInformation();
/*  195 */     if (categoryInformation == null) {
/*  196 */       GrowableProtocolSink sink = new GrowableProtocolSink();
/*  197 */       new ProtocolTextParser(sequence, ignoreUndefinedTags, interpretOctOrHexEscapeAsByte).parse(instance.getProtocolType(), sink);
/*      */ 
/*  204 */       sink.putByte(0);
/*  205 */       instance.parseFrom(sink.array(), 0, sink.position());
/*  206 */       return instance;
/*      */     }
/*      */ 
/*  209 */     ProtocolMessage result = categoryInformation.parse(sequence, instance);
/*  210 */     return result;
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> List<T> loadFromFile(String filename, String separator, Class<T> protoClass)
/*      */     throws IOException
/*      */   {
/*  220 */     InputStream inputStream = new FileInputStream(filename);
/*      */     try {
/*  222 */       List localList = loadFromStream(inputStream, separator, protoClass);
/*      */       return localList; } finally { inputStream.close(); } throw localObject;
/*      */   }
/*      */ 
/*      */   private static <T extends ProtocolMessage<? super T>> List<T> loadFromStreamInternal(InputStream stream, String separator, Class<T> protoClass, boolean strictParse, boolean interpretOctOrHexEscapeAsByte)
/*      */     throws IOException, RuntimeException
/*      */   {
/*  246 */     List values = new ArrayList();
/*      */ 
/*  248 */     BufferedReader reader = new BufferedReader(new InputStreamReader(stream, Charset.forName("UTF-8")));
/*      */ 
/*  255 */     StringBuilder currentProtoAsString = new StringBuilder();
/*      */     while (true) {
/*  257 */       String line = reader.readLine();
/*  258 */       if ((line != null) && (!line.trim().equals(separator))) {
/*  259 */         if (line.startsWith("#"))
/*      */           continue;
/*  261 */         currentProtoAsString.append(line).append('\n'); continue;
/*      */       }
/*      */ 
/*  265 */       String s = currentProtoAsString.toString();
/*      */ 
/*  267 */       if (!Strings.isNullOrEmpty(s)) {
/*      */         try
/*      */         {
/*      */           ProtocolMessage msg;
/*      */           ProtocolMessage msg;
/*  270 */           if (interpretOctOrHexEscapeAsByte)
/*  271 */             msg = parseCppCompatible(s, protoClass);
/*      */           else {
/*  273 */             msg = parse(s, protoClass);
/*      */           }
/*  275 */           values.add(msg);
/*      */         } catch (RuntimeException exc) {
/*  277 */           if (strictParse)
/*      */           {
/*  279 */             throw exc;
/*      */           }
/*      */ 
/*  282 */           logger.warning("Error parsing protocol buffer: " + exc.getMessage());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  288 */       if (line == null)
/*      */       {
/*      */         break;
/*      */       }
/*  292 */       currentProtoAsString = new StringBuilder();
/*      */     }
/*      */ 
/*  296 */     return values;
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<T>> List<T> loadFromFileStrict(String filename, String separator, Class<T> protoClass)
/*      */     throws IOException, RuntimeException
/*      */   {
/*  305 */     InputStream inputStream = new FileInputStream(filename);
/*      */     try {
/*  307 */       List localList = loadFromStreamStrict(inputStream, separator, protoClass);
/*      */       return localList; } finally { inputStream.close(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<T>> List<T> loadFromFileStrictCppCompatible(String filename, String separator, Class<T> protoClass)
/*      */     throws IOException, RuntimeException
/*      */   {
/*  321 */     InputStream inputStream = new FileInputStream(filename);
/*      */     try {
/*  323 */       List localList = loadFromStreamStrictCppCompatible(inputStream, separator, protoClass);
/*      */       return localList; } finally { inputStream.close(); } throw localObject;
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<? super T>> List<T> loadFromStream(InputStream stream, String separator, Class<T> protoClass)
/*      */     throws IOException
/*      */   {
/*  348 */     return loadFromStreamInternal(stream, separator, protoClass, false, false);
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<T>> List<T> loadFromStreamStrict(InputStream stream, String separator, Class<T> protoClass)
/*      */     throws IOException, RuntimeException
/*      */   {
/*  370 */     return loadFromStreamInternal(stream, separator, protoClass, true, false);
/*      */   }
/*      */ 
/*      */   public static <T extends ProtocolMessage<T>> List<T> loadFromStreamStrictCppCompatible(InputStream stream, String separator, Class<T> protoClass)
/*      */     throws IOException, RuntimeException
/*      */   {
/*  395 */     return loadFromStreamInternal(stream, separator, protoClass, true, true);
/*      */   }
/*      */ 
/*      */   private ProtocolTextParser(CharSequence sequence, boolean ignoreUndefinedTags, boolean interpretOctOrHexEscapeAsByte)
/*      */   {
/*  404 */     this.in = new Scanner(sequence);
/*  405 */     this.in.consume(PATTERN_COMMENTS);
/*  406 */     this.ignoreUndefinedTags = ignoreUndefinedTags;
/*  407 */     this.interpretOctOrHexEscapeAsByte = interpretOctOrHexEscapeAsByte;
/*      */   }
/*      */ 
/*      */   private void parse(ProtocolType protocolType, GrowableProtocolSink sink)
/*      */   {
/*  416 */     Class protocolMessageClass = protocolType.getProtocolMessageClass();
/*      */ 
/*  418 */     boolean isMessageSet = protocolMessageClass == MessageSet.class;
/*  419 */     boolean isRawMessage = protocolMessageClass == RawMessage.class;
/*  420 */     while ((!this.in.lookingAt(PATTERN_END)) && (!this.in.lookingAt(PATTERN_RBRACE)) && (!this.in.lookingAt(PATTERN_RANGLE)))
/*      */     {
/*  422 */       if (isRawMessage) {
/*  423 */         parseByteInRawMessage(sink); continue;
/*  424 */       }if (isMessageSet) {
/*  425 */         parseMessageInMessageSet(sink); continue;
/*      */       }
/*  427 */       parseSlot(protocolType, sink);
/*      */     }
/*      */ 
/*  430 */     this.in.consume(PATTERN_END);
/*      */   }
/*      */ 
/*      */   void parseSlot(ProtocolType protocolType, GrowableProtocolSink sink)
/*      */   {
/*  439 */     ProtocolType.FieldType tagInfo = null;
/*      */ 
/*  441 */     String matchedTagId = null;
/*  442 */     if (this.in.consume(PATTERN_ID)) {
/*  443 */       matchedTagId = this.in.getMatch();
/*  444 */       tagInfo = protocolType.getTagInfo(matchedTagId);
/*  445 */       if (tagInfo == null)
/*  446 */         if (this.ignoreUndefinedTags) {
/*  447 */           this.in.consume(PATTERN_SEPARATOR);
/*  448 */           if (skipValue()) {
/*  449 */             return;
/*      */           }
/*  451 */           error("Unable to skip tag \"%s\"", new Object[] { matchedTagId });
/*      */         }
/*      */         else
/*      */         {
/*  455 */           error("Unknown field \"%s\"", new Object[] { matchedTagId });
/*      */         }
/*      */     }
/*  458 */     else if (this.in.consume(PATTERN_INT)) {
/*  459 */       matchedTagId = this.in.getMatch();
/*  460 */       int tag = Integer.parseInt(matchedTagId, 10);
/*  461 */       tagInfo = protocolType.getTagInfo(tag);
/*  462 */       if (tagInfo == null)
/*  463 */         error("Unknown tag \"%d\"", new Object[] { Integer.valueOf(tag) });
/*      */     }
/*      */     else {
/*  466 */       error("Missing field tag", new Object[0]);
/*      */     }
/*  468 */     if (tagInfo.getPresence() == ProtocolType.Presence.REPEATED) {
/*  469 */       this.in.consume(PATTERN_OPTIONAL_INDEX);
/*      */     }
/*  471 */     this.in.consume(PATTERN_SEPARATOR);
/*      */     try {
/*  473 */       parseValue(tagInfo, sink);
/*      */     } catch (RuntimeException e) {
/*  475 */       error(e, "While processing %s at %s", new Object[] { matchedTagId, this.in.toString() });
/*      */     }
/*  477 */     this.in.consume(PATTERN_TERMINATOR);
/*      */   }
/*      */ 
/*      */   private void parseMessageInMessageSet(GrowableProtocolSink sink)
/*      */   {
/*  485 */     if (!this.in.consume(PATTERN_LSQUARE)) {
/*  486 */       error("Expected to see a left square bracket", new Object[0]);
/*      */     }
/*  488 */     if (!this.in.consume(PATTERN_CLASS_NAME)) {
/*  489 */       error("Expected to see a class name", new Object[0]);
/*      */     }
/*  491 */     String className = this.in.getMatch();
/*  492 */     if (!this.in.consume(PATTERN_RSQUARE)) {
/*  493 */       error("expected to see a right square bracket", new Object[0]);
/*      */     }
/*  495 */     Class clazz = MessageSet.findClass(className);
/*  496 */     if (clazz == null) {
/*  497 */       error("Cannot find class \"%s\"", new Object[] { className });
/*      */     }
/*  499 */     int typeId = MessageSet.getTypeId(clazz);
/*  500 */     MessageSet.outputTo(sink, typeId, parseForeign(clazz));
/*      */   }
/*      */ 
/*      */   private void parseByteInRawMessage(GrowableProtocolSink sink)
/*      */   {
/*  506 */     if (!this.in.consume(PATTERN_INT)) {
/*  507 */       error("Expected byte value", new Object[0]);
/*      */     }
/*  509 */     String match = this.in.getMatch();
/*      */     byte value;
/*      */     byte value;
/*  510 */     if ((match.startsWith("0x")) || (match.startsWith("0X")))
/*  511 */       value = (byte)Integer.parseInt(match.substring(2), 16);
/*      */     else {
/*  513 */       value = (byte)Integer.parseInt(match, 10);
/*      */     }
/*  515 */     sink.putByte(value);
/*      */   }
/*      */ 
/*      */   private void parseValue(ProtocolType.FieldType tagInfo, GrowableProtocolSink sink)
/*      */   {
/*  524 */     sink.putVarInt(tagInfo.getWireTag());
/*      */ 
/*  526 */     switch (1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[tagInfo.getBaseType().ordinal()])
/*      */     {
/*      */     case 1:
/*      */     case 2:
/*      */       int value;
/*      */       int value;
/*  531 */       if (this.in.consume(PATTERN_INT)) {
/*  532 */         String match = this.in.getMatch();
/*      */         int value;
/*  533 */         if ((match.startsWith("0x")) || (match.startsWith("0X")))
/*  534 */           value = (int)Long.parseLong(match.substring(2), 16);
/*      */         else
/*  536 */           value = Integer.parseInt(match, 10);
/*      */       }
/*  538 */       else if (this.in.consume(PATTERN_ID)) {
/*  539 */         String enumValue = this.in.getMatch();
/*      */         try
/*      */         {
/*      */           Field valueField;
/*      */           Field valueField;
/*  546 */           if (tagInfo.getEnumType() != null)
/*  547 */             valueField = tagInfo.getEnumType().getField(enumValue);
/*      */           else {
/*  549 */             valueField = tagInfo.getParentClass().getField(enumValue);
/*      */           }
/*      */ 
/*  552 */           Object valueObject = valueField.get(null);
/*      */           int value;
/*  553 */           if ((valueObject instanceof ProtocolMessageEnum)) {
/*  554 */             value = ((ProtocolMessageEnum)valueObject).getValue();
/*      */           }
/*      */           else
/*  557 */             value = ((Integer)valueObject).intValue();
/*      */         }
/*      */         catch (IllegalAccessException e)
/*      */         {
/*      */           int value;
/*  562 */           throw new IllegalStateException(e);
/*      */         }
/*      */         catch (NoSuchFieldException e) {
/*  565 */           throw new IllegalStateException(e);
/*      */         }
/*      */       } else {
/*  568 */         value = 0;
/*  569 */         error("Expected integer or long", new Object[0]);
/*      */       }
/*  571 */       if (tagInfo.getBaseType().isFixed())
/*  572 */         sink.putInt(value);
/*      */       else {
/*  574 */         sink.putVarInt(value);
/*      */       }
/*  576 */       break;
/*      */     case 3:
/*      */     case 4:
/*  582 */       if (!this.in.consume(PATTERN_INT)) {
/*  583 */         error("Expected integer or long", new Object[0]);
/*      */       }
/*  585 */       String match = this.in.getMatch();
/*      */       long value;
/*      */       long value;
/*  586 */       if ((match.startsWith("0x")) || (match.startsWith("0X")))
/*  587 */         value = UnsignedLong.parseLong(match.substring(2), 16);
/*      */       else {
/*  589 */         value = Long.parseLong(match, 10);
/*      */       }
/*  591 */       if (tagInfo.getBaseType().isFixed())
/*  592 */         sink.putLong(value);
/*      */       else {
/*  594 */         sink.putVarLong(value);
/*      */       }
/*  596 */       break;
/*      */     case 5:
/*  601 */       if (!this.in.consume(PATTERN_INT)) {
/*  602 */         error("Expected integer or long", new Object[0]);
/*      */       }
/*  604 */       String match = this.in.getMatch();
/*      */       long value;
/*      */       long value;
/*  605 */       if ((match.startsWith("0x")) || (match.startsWith("0X"))) {
/*  606 */         value = UnsignedLong.parseLong(match.substring(2), 16);
/*      */       }
/*      */       else
/*      */       {
/*      */         long value;
/*  607 */         if (match.startsWith("-"))
/*  608 */           value = Long.parseLong(match, 10);
/*      */         else
/*  610 */           value = UnsignedLong.parseLong(match, 10);
/*      */       }
/*  612 */       if (tagInfo.getBaseType().isFixed())
/*  613 */         sink.putLong(value);
/*      */       else {
/*  615 */         sink.putVarLong(value);
/*      */       }
/*  617 */       break;
/*      */     case 6:
/*  623 */       if (this.in.consume(PATTERN_ID))
/*      */       {
/*  625 */         String id = this.in.getMatch();
/*      */         boolean value;
/*      */         boolean value;
/*  626 */         if ((id.equalsIgnoreCase("t")) || (id.equalsIgnoreCase("true"))) {
/*  627 */           value = true;
/*      */         }
/*      */         else
/*      */         {
/*      */           boolean value;
/*  628 */           if ((id.equalsIgnoreCase("f")) || (id.equalsIgnoreCase("false"))) {
/*  629 */             value = false;
/*      */           } else {
/*  631 */             value = false;
/*  632 */             error("Bad value for boolean", new Object[0]);
/*      */           }
/*      */         }
/*  634 */         sink.putByte(value ? 1 : 0); } else {
/*  635 */         if (!this.in.consume(PATTERN_INT)) break;
/*  636 */         int value = Integer.parseInt(this.in.getMatch());
/*  637 */         if ((value != 0) && (value != 1)) {
/*  638 */           error("Bad value for boolean", new Object[0]);
/*      */         }
/*  640 */         sink.putByte((byte)value);
/*  641 */       }break;
/*      */     case 7:
/*  645 */       if (!this.in.consume(PATTERN_LBRACE)) {
/*  646 */         error("Missing left brace", new Object[0]);
/*      */       }
/*  648 */       Class subclass = tagInfo.getSubclass();
/*  649 */       parse(ProtocolSupport.newInstance(subclass).getProtocolType(), sink);
/*  650 */       if (!this.in.consume(PATTERN_RBRACE)) {
/*  651 */         error("Missing right brace", new Object[0]);
/*      */       }
/*  653 */       sink.putVarInt(tagInfo.getWireTag() + 1);
/*  654 */       break;
/*      */     case 8:
/*  658 */       GrowableProtocolSink newSink = parseForeign(tagInfo.getSubclass());
/*  659 */       sink.putVarInt(newSink.position());
/*  660 */       sink.putBytes(newSink.array(), 0, newSink.position());
/*  661 */       break;
/*      */     case 9:
/*  665 */       byte[] bytes = parseStringValue();
/*  666 */       sink.putVarInt(bytes.length);
/*  667 */       sink.putBytes(bytes);
/*  668 */       break;
/*      */     case 10:
/*  671 */       if (this.in.consume(PATTERN_FLOAT)) {
/*  672 */         String match = this.in.getMatch();
/*  673 */         sink.putDouble(Double.parseDouble(match));
/*  674 */       } else if (this.in.consume(PATTERN_INFINITY)) {
/*  675 */         String match = this.in.getMatch();
/*  676 */         sink.putDouble(match.charAt(0) == '-' ? (-1.0D / 0.0D) : (1.0D / 0.0D));
/*      */       }
/*  678 */       else if (this.in.consume(PATTERN_NAN)) {
/*  679 */         sink.putDouble((0.0D / 0.0D));
/*      */       } else {
/*  681 */         error("Expected double", new Object[0]);
/*      */       }
/*  683 */       break;
/*      */     case 11:
/*  686 */       if (this.in.consume(PATTERN_FLOAT)) {
/*  687 */         String match = this.in.getMatch();
/*  688 */         sink.putFloat(Float.parseFloat(match));
/*  689 */       } else if (this.in.consume(PATTERN_INFINITY)) {
/*  690 */         String match = this.in.getMatch();
/*  691 */         sink.putFloat(match.charAt(0) == '-' ? (1.0F / -1.0F) : (1.0F / 1.0F));
/*      */       }
/*  693 */       else if (this.in.consume(PATTERN_NAN)) {
/*  694 */         sink.putFloat((0.0F / 0.0F));
/*      */       } else {
/*  696 */         error("Expected float", new Object[0]);
/*      */       }
/*  698 */       break;
/*      */     default:
/*  702 */       error("Not yet handled", new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   private GrowableProtocolSink parseForeign(Class<? extends ProtocolMessage> clazz)
/*      */   {
/*  711 */     GrowableProtocolSink sink = new GrowableProtocolSink();
/*  712 */     if (this.in.consume(PATTERN_LANGLE_OR_LBRACE))
/*      */     {
/*  714 */       char starter = this.in.getMatch().charAt(0);
/*      */ 
/*  716 */       Pattern ender = starter == '<' ? PATTERN_RANGLE : PATTERN_RBRACE;
/*  717 */       parse(ProtocolSupport.newInstance(clazz).getProtocolType(), sink);
/*      */ 
/*  719 */       if (!this.in.consume(ender))
/*  720 */         error("Missing closing right brace or angle bracket", new Object[0]);
/*      */     }
/*  722 */     else if (clazz == RawMessage.class) {
/*  723 */       byte[] bytes = parseStringValue();
/*  724 */       sink.putBytes(bytes);
/*      */     } else {
/*  726 */       error("Missing left brace or left angle bracket", new Object[0]);
/*      */     }
/*  728 */     return sink;
/*      */   }
/*      */ 
/*      */   private byte[] parseStringValue()
/*      */   {
/*  733 */     List byteList = Lists.newArrayList();
/*      */ 
/*  737 */     this.in.disableSkip();
/*      */ 
/*  742 */     if (!this.in.consume(PATTERN_DQUOTE)) {
/*  743 */       addOneStringPieceToByteList(PATTERN_NEWLINE, PATTERN_NEWLINE_TERMINATED_SIMPLE_STRING, byteList);
/*      */     }
/*      */     else {
/*      */       do
/*      */       {
/*  748 */         addOneStringPieceToByteList(PATTERN_DQUOTE, PATTERN_SIMPLE_STRING, byteList);
/*      */ 
/*  753 */         this.in.enableSkip();
/*  754 */         this.in.disableSkip();
/*  755 */       }while (this.in.consume(PATTERN_DQUOTE));
/*      */     }
/*      */ 
/*  759 */     this.in.enableSkip();
/*      */ 
/*  761 */     byte[] byteArray = new byte[byteList.size()];
/*  762 */     int i = 0;
/*  763 */     for (Byte b : byteList) {
/*  764 */       byteArray[i] = b.byteValue();
/*  765 */       i++;
/*      */     }
/*  767 */     return byteArray;
/*      */   }
/*      */ 
/*      */   private void addOneStringPieceToByteList(Pattern endOfStringPattern, Pattern simpleStringPattern, List<Byte> byteList)
/*      */   {
/*  772 */     while (!this.in.consume(endOfStringPattern)) {
/*  773 */       if (this.in.consume(simpleStringPattern))
/*      */       {
/*  775 */         addToByteList(this.in.getMatch(), byteList); continue;
/*  776 */       }if (this.in.consume(PATTERN_SINGLE_CHAR_ESCAPE_SEQ))
/*      */       {
/*  778 */         addToByteList(parseEscapedChar(this.in.getMatch()), byteList); continue;
/*  779 */       }if (this.in.consume(PATTERN_SINGLE_BYTE_ESCAPE_SEQ))
/*      */       {
/*  781 */         if (this.interpretOctOrHexEscapeAsByte) {
/*  782 */           addToByteList(parseEscapedByte(this.in.getMatch()), byteList); continue;
/*      */         }
/*  784 */         addToByteList(parseEscapedChar(this.in.getMatch()), byteList); continue;
/*      */       }
/*      */ 
/*  787 */       error("error handling string", new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void addToByteList(String str, List<Byte> dest)
/*      */   {
/*  797 */     for (int i = 0; i < str.length(); i++)
/*  798 */       addToByteList(str.charAt(i), dest);
/*      */   }
/*      */ 
/*      */   private void addToByteList(char c, List<Byte> dest)
/*      */   {
/*  803 */     addToByteList(String.valueOf(c).getBytes(Charsets.UTF_8), dest);
/*      */   }
/*      */ 
/*      */   private void addToByteList(byte[] bytes, List<Byte> dest) {
/*  807 */     for (int i = 0; i < bytes.length; i++)
/*  808 */       addToByteList(bytes[i], dest);
/*      */   }
/*      */ 
/*      */   private void addToByteList(byte b, List<Byte> dest)
/*      */   {
/*  813 */     dest.add(Byte.valueOf(b));
/*      */   }
/*      */ 
/*      */   private char parseEscapedChar(String string)
/*      */   {
/*  818 */     assert (string.length() >= 2);
/*  819 */     assert (string.charAt(0) == '\\');
/*  820 */     switch (string.charAt(1)) { case 'b':
/*  821 */       return '\b';
/*      */     case 'f':
/*  822 */       return '\f';
/*      */     case 'n':
/*  823 */       return '\n';
/*      */     case 'r':
/*  824 */       return '\r';
/*      */     case 't':
/*  825 */       return '\t';
/*      */     case '"':
/*      */     case '\'':
/*      */     case '\\':
/*  827 */       return string.charAt(1);
/*      */     case '0':
/*      */     case '1':
/*      */     case '2':
/*      */     case '3':
/*      */     case '4':
/*      */     case '5':
/*      */     case '6':
/*      */     case '7':
/*  830 */       return (char)Integer.parseInt(string.substring(1), 8);
/*      */     case 'U':
/*      */     case 'X':
/*      */     case 'u':
/*      */     case 'x':
/*  834 */       return (char)Integer.parseInt(string.substring(2), 16);
/*      */     case '#':
/*      */     case '$':
/*      */     case '%':
/*      */     case '&':
/*      */     case '(':
/*      */     case ')':
/*      */     case '*':
/*      */     case '+':
/*      */     case ',':
/*      */     case '-':
/*      */     case '.':
/*      */     case '/':
/*      */     case '8':
/*      */     case '9':
/*      */     case ':':
/*      */     case ';':
/*      */     case '<':
/*      */     case '=':
/*      */     case '>':
/*      */     case '?':
/*      */     case '@':
/*      */     case 'A':
/*      */     case 'B':
/*      */     case 'C':
/*      */     case 'D':
/*      */     case 'E':
/*      */     case 'F':
/*      */     case 'G':
/*      */     case 'H':
/*      */     case 'I':
/*      */     case 'J':
/*      */     case 'K':
/*      */     case 'L':
/*      */     case 'M':
/*      */     case 'N':
/*      */     case 'O':
/*      */     case 'P':
/*      */     case 'Q':
/*      */     case 'R':
/*      */     case 'S':
/*      */     case 'T':
/*      */     case 'V':
/*      */     case 'W':
/*      */     case 'Y':
/*      */     case 'Z':
/*      */     case '[':
/*      */     case ']':
/*      */     case '^':
/*      */     case '_':
/*      */     case '`':
/*      */     case 'a':
/*      */     case 'c':
/*      */     case 'd':
/*      */     case 'e':
/*      */     case 'g':
/*      */     case 'h':
/*      */     case 'i':
/*      */     case 'j':
/*      */     case 'k':
/*      */     case 'l':
/*      */     case 'm':
/*      */     case 'o':
/*      */     case 'p':
/*      */     case 'q':
/*      */     case 's':
/*      */     case 'v':
/*  836 */     case 'w': } error("Should not reach here!", new Object[0]);
/*  837 */     return '\000';
/*      */   }
/*      */ 
/*      */   private byte parseEscapedByte(String string)
/*      */   {
/*  842 */     assert (string.length() >= 2);
/*  843 */     assert (string.charAt(0) == '\\');
/*  844 */     int value = 0;
/*  845 */     switch (string.charAt(1)) { case '0':
/*      */     case '1':
/*      */     case '2':
/*      */     case '3':
/*      */     case '4':
/*      */     case '5':
/*      */     case '6':
/*      */     case '7':
/*  848 */       value = Integer.parseInt(string.substring(1), 8);
/*  849 */       break;
/*      */     case 'X':
/*      */     case 'x':
/*  852 */       value = Integer.parseInt(string.substring(2), 16);
/*  853 */       break;
/*      */     default:
/*  855 */       error("Should not reach here!", new Object[0]);
/*  856 */       return 0;
/*      */     }
/*  858 */     if (value > 255) {
/*  859 */       logger.warning("The value of " + string + " exceeds 8 bits");
/*      */     }
/*  861 */     return (byte)value;
/*      */   }
/*      */ 
/*      */   private void error(Exception e, String format, Object[] args)
/*      */   {
/*  965 */     throw new RuntimeException(String.format("Line %d: ", new Object[] { Integer.valueOf(Scanner.access$300(this.in)) }) + String.format(format, args), e);
/*      */   }
/*      */ 
/*      */   private void error(String format, Object[] args)
/*      */   {
/*  971 */     error(null, format, args);
/*      */   }
/*      */ 
/*      */   private boolean skipValue()
/*      */   {
/*  979 */     if ((this.in.consume(PATTERN_FLOAT)) || (this.in.consume(PATTERN_INT)) || (this.in.consume(PATTERN_ID)))
/*      */     {
/*  982 */       return true;
/*      */     }
/*  984 */     if (this.in.lookingAt(PATTERN_DQUOTE)) {
/*  985 */       parseStringValue();
/*  986 */       return true;
/*      */     }
/*  988 */     if (this.in.consume(PATTERN_LBRACE)) {
/*  989 */       while (!this.in.lookingAt(PATTERN_RBRACE)) {
/*  990 */         skipName();
/*  991 */         this.in.consume(PATTERN_SEPARATOR);
/*  992 */         skipValue();
/*  993 */         this.in.consume(PATTERN_TERMINATOR);
/*      */       }
/*  995 */       return true;
/*      */     }
/*  997 */     if (this.in.consume(PATTERN_LANGLE_OR_LBRACE)) {
/*  998 */       while (!this.in.lookingAt(PATTERN_RANGLE)) {
/*  999 */         skipName();
/* 1000 */         this.in.consume(PATTERN_SEPARATOR);
/* 1001 */         skipValue();
/* 1002 */         this.in.consume(PATTERN_TERMINATOR);
/*      */       }
/* 1004 */       this.in.consume(PATTERN_RANGLE);
/* 1005 */       return true;
/*      */     }
/*      */ 
/* 1008 */     return false;
/*      */   }
/*      */ 
/*      */   private void skipName() {
/* 1012 */     if (this.in.consume(PATTERN_LSQUARE)) {
/* 1013 */       if (!this.in.consume(PATTERN_CLASS_NAME)) {
/* 1014 */         this.in.consume(PATTERN_OPTIONAL_INDEX);
/*      */       }
/* 1016 */       this.in.consume(PATTERN_RSQUARE);
/*      */     } else {
/* 1018 */       if (!this.in.consume(PATTERN_ID)) {
/* 1019 */         this.in.consume(PATTERN_TAG);
/*      */       }
/* 1021 */       while (this.in.lookingAt(PATTERN_DOT)) {
/* 1022 */         this.in.consume(PATTERN_DOT);
/* 1023 */         this.in.consume(PATTERN_ID);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   51 */     logger = Logger.getLogger(ProtocolTextParser.class.getName());
/*      */ 
/*   54 */     PATTERN_LBRACE = Pattern.compile("\\{");
/*   55 */     PATTERN_LSQUARE = Pattern.compile("\\[");
/*   56 */     PATTERN_LANGLE_OR_LBRACE = Pattern.compile("[\\<\\{]");
/*      */ 
/*   58 */     PATTERN_RBRACE = Pattern.compile("\\}");
/*   59 */     PATTERN_RSQUARE = Pattern.compile("\\]");
/*   60 */     PATTERN_RANGLE = Pattern.compile("\\>");
/*      */ 
/*   62 */     PATTERN_OPTIONAL_INDEX = Pattern.compile("\\([0-9]+\\)");
/*   63 */     PATTERN_SEPARATOR = Pattern.compile("[:=]");
/*      */ 
/*   65 */     PATTERN_ID = Pattern.compile("([a-zA-Z_]\\w*(\\.\\w+)*)");
/*      */ 
/*   67 */     PATTERN_CLASS_NAME = Pattern.compile("([a-zA-Z_][a-zA-Z0-9_.]*)");
/*      */ 
/*   70 */     PATTERN_INT = Pattern.compile("(-?([1-9][0-9]*|0([xX][0-9a-fA-Z]+|[0-7]*)?))");
/*      */ 
/*   72 */     PATTERN_FLOAT = Pattern.compile("(-?[0-9]+(\\.[0-9]*)?([eE](-|\\+)?[0-9]+)?)[fF]?");
/*      */ 
/*   74 */     PATTERN_INFINITY = Pattern.compile("[-+]?inf(inity)?f?", 2);
/*      */ 
/*   76 */     PATTERN_NAN = Pattern.compile("[-+]?nanf?", 2);
/*      */ 
/*   79 */     PATTERN_DQUOTE = Pattern.compile("\"");
/*      */ 
/*   81 */     PATTERN_SIMPLE_STRING = Pattern.compile("([^\"\\\\]+)");
/*      */ 
/*   83 */     PATTERN_NEWLINE_TERMINATED_SIMPLE_STRING = Pattern.compile("([^\"\r\n\\\\]+)");
/*      */ 
/*   86 */     PATTERN_SINGLE_CHAR_ESCAPE_SEQ = Pattern.compile("(\\\\[bfnrt\"'\\\\]|\\\\u[0-9a-fA-F]{4})");
/*      */ 
/*   91 */     PATTERN_SINGLE_BYTE_ESCAPE_SEQ = Pattern.compile("(\\\\[0-7]{1,3}|\\\\x[0-9a-fA-F]+)");
/*      */ 
/*   96 */     PATTERN_TERMINATOR = Pattern.compile("[;,]");
/*      */ 
/*   98 */     PATTERN_END = Pattern.compile("$");
/*      */ 
/*  100 */     PATTERN_COMMENTS = Pattern.compile("(\\s|#.*\n)+");
/*      */ 
/*  102 */     PATTERN_NEWLINE = Pattern.compile("[\r\n]");
/*      */ 
/*  104 */     PATTERN_DOT = Pattern.compile("\\.");
/*      */ 
/*  106 */     PATTERN_TAG = Pattern.compile("(tag)?([0-9]+)");
/*      */   }
/*      */ 
/*      */   static class Scanner
/*      */   {
/*      */     private final CharSequence sequence;
/*      */     private final int stringLength;
/*      */     private int currentPosition;
/*      */     private int lineNumber;
/*      */     private final Matcher normalMatcher;
/*      */     private final Matcher commentSkipper;
/*      */     private boolean skipComments;
/*      */ 
/*      */     Scanner(CharSequence string)
/*      */     {
/*  881 */       this.sequence = string;
/*  882 */       this.stringLength = string.length();
/*  883 */       this.currentPosition = 0;
/*  884 */       this.lineNumber = 1;
/*  885 */       this.normalMatcher = ProtocolTextParser.PATTERN_COMMENTS.matcher(string);
/*  886 */       this.commentSkipper = ProtocolTextParser.PATTERN_COMMENTS.matcher(string);
/*  887 */       this.skipComments = true;
/*      */     }
/*      */ 
/*      */     boolean lookingAt(Pattern pattern)
/*      */     {
/*  895 */       Matcher matcher = this.normalMatcher;
/*  896 */       matcher.usePattern(pattern);
/*  897 */       matcher.region(this.currentPosition, this.stringLength);
/*  898 */       return matcher.lookingAt();
/*      */     }
/*      */ 
/*      */     boolean consume(Pattern pattern)
/*      */     {
/*  907 */       Matcher matcher = this.normalMatcher;
/*  908 */       matcher.usePattern(pattern);
/*  909 */       matcher.region(this.currentPosition, this.stringLength);
/*  910 */       int formerPosition = this.currentPosition;
/*  911 */       boolean result = matcher.lookingAt();
/*  912 */       if (result) {
/*  913 */         this.currentPosition = matcher.end();
/*  914 */         if (this.skipComments) {
/*  915 */           this.commentSkipper.region(this.currentPosition, this.stringLength);
/*  916 */           if (this.commentSkipper.lookingAt()) {
/*  917 */             this.currentPosition = this.commentSkipper.end();
/*      */           }
/*      */         }
/*      */       }
/*  921 */       for (int i = formerPosition; i < this.currentPosition; i++) {
/*  922 */         if (this.sequence.charAt(i) == '\n') {
/*  923 */           this.lineNumber += 1;
/*      */         }
/*      */       }
/*  926 */       return result;
/*      */     }
/*      */ 
/*      */     String getMatch()
/*      */     {
/*  931 */       return this.normalMatcher.group();
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  936 */       int CONTEXT = 20;
/*  937 */       CharSequence prefix = this.currentPosition > CONTEXT ? "..." + this.sequence.subSequence(this.currentPosition - CONTEXT, this.currentPosition) : this.sequence.subSequence(0, this.currentPosition);
/*      */ 
/*  940 */       CharSequence suffix = this.currentPosition < this.stringLength - CONTEXT ? this.sequence.subSequence(this.currentPosition, this.currentPosition + CONTEXT) + "..." : this.sequence.subSequence(this.currentPosition, this.stringLength);
/*      */ 
/*  944 */       return prefix + " ### " + suffix;
/*      */     }
/*      */ 
/*      */     private void disableSkip() {
/*  948 */       this.skipComments = false;
/*      */     }
/*      */ 
/*      */     private void enableSkip() {
/*  952 */       this.skipComments = true;
/*  953 */       this.commentSkipper.region(this.currentPosition, this.stringLength);
/*  954 */       if (this.commentSkipper.lookingAt())
/*  955 */         this.currentPosition = this.commentSkipper.end();
/*      */     }
/*      */ 
/*      */     private int getLineNumber()
/*      */     {
/*  960 */       return this.lineNumber;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolTextParser
 * JD-Core Version:    0.6.0
 */