/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class ExtendableProtocolMessage<T extends ExtendableProtocolMessage<T>> extends ProtocolMessage<T>
/*     */ {
/*     */   protected ExtensionTags uninterpreted;
/*     */ 
/*     */   public final boolean hasExtension(Extensions.Extension<T, ?> extension)
/*     */   {
/*  22 */     if (this.uninterpreted == null) {
/*  23 */       return false;
/*     */     }
/*  25 */     return this.uninterpreted.containsKey(Integer.valueOf(extension.getWireTag()));
/*     */   }
/*     */ 
/*     */   public final boolean hasExtension(Extensions.RepeatedExtension<T, ?> extension)
/*     */   {
/*  31 */     if (this.uninterpreted == null) {
/*  32 */       return false;
/*     */     }
/*  34 */     return (this.uninterpreted.containsKey(Integer.valueOf(extension.getWireTag()))) && (!((List)this.uninterpreted.get(Integer.valueOf(extension.getWireTag())).read(extension)).isEmpty());
/*     */   }
/*     */ 
/*     */   public final <Ex> Ex getExtension(Extensions.Extension<T, Ex> extension)
/*     */   {
/*  41 */     if (this.uninterpreted == null)
/*     */     {
/*  43 */       return extension.defaultValue();
/*     */     }
/*  45 */     LazyParsingExtension ext = this.uninterpreted.get(Integer.valueOf(extension.getWireTag()));
/*  46 */     return ext == null ? extension.defaultValue() : extension.unmodifiable(ext.read(extension));
/*     */   }
/*     */ 
/*     */   public final <Ex extends ProtocolMessage<Ex>> Ex getMutableExtension(Extensions.Extension<T, Ex> extension)
/*     */   {
/*  57 */     return (ProtocolMessage)internalGetMutableExtension(extension);
/*     */   }
/*     */ 
/*     */   public final <Ex> List<Ex> getMutableExtension(Extensions.RepeatedExtension<T, Ex> extension)
/*     */   {
/*  65 */     return (List)internalGetMutableExtension(extension);
/*     */   }
/*     */ 
/*     */   private final <Ex> Ex internalGetMutableExtension(Extensions.Extension<T, Ex> extension) {
/*  69 */     getUninterpretedForWrite();
/*  70 */     LazyParsingExtension ext = this.uninterpreted.get(Integer.valueOf(extension.getWireTag()));
/*  71 */     if (ext == null) {
/*  72 */       ext = LazyParsingExtension.empty(extension);
/*  73 */       this.uninterpreted.putExtension(Integer.valueOf(extension.getWireTag()), ext);
/*     */     }
/*  75 */     return ext.read(extension);
/*     */   }
/*     */ 
/*     */   public final <Ex> Ex getExtension(Extensions.RepeatedExtension<T, Ex> extension, int index)
/*     */   {
/*  82 */     return ((List)getExtension(extension)).get(index);
/*     */   }
/*     */ 
/*     */   public final int extensionSize(Extensions.RepeatedExtension<T, ?> extension)
/*     */   {
/*  88 */     return ((List)getExtension(extension)).size();
/*     */   }
/*     */ 
/*     */   public final <Ex> T setExtension(Extensions.Extension<T, Ex> extension, Ex value)
/*     */   {
/*  95 */     getUninterpretedForWrite().putExtension(Integer.valueOf(extension.getWireTag()), LazyParsingExtension.parsed(extension, value));
/*     */ 
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   public final T setExtension(Extensions.Extension<T, Integer> extension, ProtocolMessageEnum enumValue)
/*     */   {
/* 103 */     return setExtension(extension, Integer.valueOf(enumValue.getValue()));
/*     */   }
/*     */ 
/*     */   public final T setExtension(Extensions.Extension<T, ProtoString> extension, String value)
/*     */   {
/* 109 */     return setExtension(extension, new ProtoString(value));
/*     */   }
/*     */ 
/*     */   public final T setExtension(Extensions.Extension<T, ProtoString> extension, byte[] value) {
/* 113 */     return setExtension(extension, new ProtoString(value));
/*     */   }
/*     */ 
/*     */   public final <Ex> T setExtension(Extensions.RepeatedExtension<T, Ex> extension, int index, Ex value)
/*     */   {
/* 120 */     getUninterpretedForWrite();
/* 121 */     LazyParsingExtension ext = this.uninterpreted.get(Integer.valueOf(extension.getWireTag()));
/* 122 */     if (ext == null) {
/* 123 */       ext = LazyParsingExtension.empty(extension);
/* 124 */       this.uninterpreted.putExtension(Integer.valueOf(extension.getWireTag()), ext);
/*     */     }
/* 126 */     ((List)ext.read(extension)).set(index, value);
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */   public final T setExtension(Extensions.RepeatedExtension<T, Integer> extension, int index, ProtocolMessageEnum enumValue)
/*     */   {
/* 133 */     return setExtension(extension, index, Integer.valueOf(enumValue.getValue()));
/*     */   }
/*     */ 
/*     */   public final T setExtension(Extensions.RepeatedExtension<T, ProtoString> extension, int index, String value)
/*     */   {
/* 139 */     return setExtension(extension, index, new ProtoString(value));
/*     */   }
/*     */ 
/*     */   public final T setExtension(Extensions.RepeatedExtension<T, ProtoString> extension, int index, byte[] value) {
/* 143 */     return setExtension(extension, index, new ProtoString(value));
/*     */   }
/*     */ 
/*     */   public final <Ex> T addExtension(Extensions.RepeatedExtension<T, Ex> extension, Ex value)
/*     */   {
/* 150 */     getUninterpretedForWrite();
/* 151 */     LazyParsingExtension ext = this.uninterpreted.get(Integer.valueOf(extension.getWireTag()));
/* 152 */     if (ext == null) {
/* 153 */       ext = LazyParsingExtension.empty(extension);
/* 154 */       this.uninterpreted.putExtension(Integer.valueOf(extension.getWireTag()), ext);
/*     */     }
/* 156 */     ((List)ext.read(extension)).add(value);
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   public final T addExtension(Extensions.RepeatedExtension<T, Integer> extension, ProtocolMessageEnum enumValue)
/*     */   {
/* 163 */     return addExtension(extension, Integer.valueOf(enumValue.getValue()));
/*     */   }
/*     */ 
/*     */   public final T addExtension(Extensions.RepeatedExtension<T, ProtoString> extension, String value)
/*     */   {
/* 169 */     return addExtension(extension, new ProtoString(value));
/*     */   }
/*     */ 
/*     */   public final T addExtension(Extensions.RepeatedExtension<T, ProtoString> extension, byte[] value) {
/* 173 */     return addExtension(extension, new ProtoString(value));
/*     */   }
/*     */ 
/*     */   public final <Ex extends ProtocolMessage<Ex>> Ex addExtension(Extensions.RepeatedExtension<T, Ex> extension)
/*     */   {
/* 180 */     ProtocolMessage result = ((ProtocolMessage)extension.unitDefaultValue()).newInstance();
/* 181 */     getUninterpretedForWrite();
/* 182 */     LazyParsingExtension ext = this.uninterpreted.get(Integer.valueOf(extension.getWireTag()));
/* 183 */     if (ext == null) {
/* 184 */       ext = LazyParsingExtension.empty(extension);
/* 185 */       this.uninterpreted.putExtension(Integer.valueOf(extension.getWireTag()), ext);
/*     */     }
/* 187 */     ((List)ext.read(extension)).add(result);
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */   public final <Ex> T clearExtension(Extensions.Extension<T, Ex> extension)
/*     */   {
/* 194 */     if (this.uninterpreted != null) {
/* 195 */       getUninterpretedForWrite().remove(Integer.valueOf(extension.getWireTag()));
/*     */     }
/* 197 */     return this;
/*     */   }
/*     */ 
/*     */   public final void makeReadAccessThreadSafe(Extensions.Extension<T, ?>[] extensions)
/*     */   {
/* 214 */     ExtensionTags tags = getUninterpretedForWrite();
/* 215 */     for (Extensions.Extension e : extensions) {
/* 216 */       LazyParsingExtension lpe = tags.get(Integer.valueOf(e.getWireTag()));
/* 217 */       if (lpe != null)
/* 218 */         lpe.read(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 235 */     throw new UnsupportedOperationException("hashCode unsupported for messages with extensions");
/*     */   }
/*     */ 
/*     */   protected abstract ExtensionTags getUninterpretedForWrite();
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ExtendableProtocolMessage
 * JD-Core Version:    0.6.0
 */