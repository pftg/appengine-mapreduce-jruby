/*      */ package com.google.appengine.api.memcache;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.protobuf.BlockingRpcChannel;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.BlockingService;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.Descriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumValueDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.MethodDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.ServiceDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.Builder;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Internal.EnumLiteMap;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcCallback;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcChannel;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcController;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.RpcUtil;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Service;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ServiceException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet.Builder;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class MemcacheServicePb
/*      */ {
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheServiceError_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheServiceError_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheGetRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheGetRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheGetResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheGetResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheGetResponse_Item_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheGetResponse_Item_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheSetRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheSetRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheSetRequest_Item_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheSetRequest_Item_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheSetResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheSetResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheDeleteRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheDeleteRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheDeleteRequest_Item_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheDeleteRequest_Item_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheDeleteResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheDeleteResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheIncrementRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheIncrementRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheIncrementResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheIncrementResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheBatchIncrementRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheBatchIncrementRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheBatchIncrementResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheBatchIncrementResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheFlushRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheFlushRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheFlushResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheFlushResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheStatsRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheStatsRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MergedNamespaceStats_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MergedNamespaceStats_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheStatsResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheStatsResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheGrabTailRequest_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheGrabTailRequest_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheGrabTailResponse_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheGrabTailResponse_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_MemcacheGrabTailResponse_Item_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_MemcacheGrabTailResponse_Item_fieldAccessorTable;
/*      */   private static Descriptors.FileDescriptor descriptor;
/*      */ 
/*      */   public static void registerAllExtensions(ExtensionRegistry registry)
/*      */   {
/*      */   }
/*      */ 
/*      */   public static Descriptors.FileDescriptor getDescriptor()
/*      */   {
/* 9671 */     return descriptor;
/*      */   }
/*      */   public static void internalForceInit() {
/*      */   }
/*      */   static {
/* 9676 */     String[] descriptorData = { "", "", "", "", "", "", "mcacheSetRequest\032\037.apphosting.MemcacheSetResponse\022O\n\006Delete\022!.apphosting.MemcacheDeleteRequest\032\".apphosting.MemcacheDeleteResponse\022X\n\tIncrement\022$.apphosting.MemcacheIncrementRequest\032%.apphosting.MemcacheIncrementResponse\022g\n\016BatchIncrement\022).apphosting.MemcacheBatchIncrementRequest\032*.apphosting.MemcacheBatchIncrementResponse\022O\n\bFlushAll\022 .apphosting.MemcacheFlushRequest\032!.apphosting.MemcacheFlushRe", "sponse\022L\n\005Stats\022 .apphosting.MemcacheStatsRequest\032!.apphosting.MemcacheStatsResponse\022U\n\bGrabTail\022#.apphosting.MemcacheGrabTailRequest\032$.apphosting.MemcacheGrabTailResponseB<\n!com.google.appengine.api.memcache\020\001 \001(\002B\021MemcacheServicePb" };
/*      */ 
/* 9754 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*      */     {
/*      */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*      */       {
/* 9758 */         MemcacheServicePb.access$19702(root);
/* 9759 */         MemcacheServicePb.access$002((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(0));
/*      */ 
/* 9761 */         MemcacheServicePb.access$102(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheServiceError_descriptor, new String[0], MemcacheServicePb.MemcacheServiceError.class, MemcacheServicePb.MemcacheServiceError.Builder.class));
/*      */ 
/* 9767 */         MemcacheServicePb.access$502((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(1));
/*      */ 
/* 9769 */         MemcacheServicePb.access$602(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheGetRequest_descriptor, new String[] { "Key", "NameSpace", "ForCas" }, MemcacheServicePb.MemcacheGetRequest.class, MemcacheServicePb.MemcacheGetRequest.Builder.class));
/*      */ 
/* 9775 */         MemcacheServicePb.access$1502((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(2));
/*      */ 
/* 9777 */         MemcacheServicePb.access$1602(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_descriptor, new String[] { "Item" }, MemcacheServicePb.MemcacheGetResponse.class, MemcacheServicePb.MemcacheGetResponse.Builder.class));
/*      */ 
/* 9783 */         MemcacheServicePb.access$1702((Descriptors.Descriptor)MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_descriptor.getNestedTypes().get(0));
/*      */ 
/* 9785 */         MemcacheServicePb.access$1802(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_Item_descriptor, new String[] { "Key", "Value", "Flags", "CasId", "ExpiresInSeconds" }, MemcacheServicePb.MemcacheGetResponse.Item.class, MemcacheServicePb.MemcacheGetResponse.Item.Builder.class));
/*      */ 
/* 9791 */         MemcacheServicePb.access$3602((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(3));
/*      */ 
/* 9793 */         MemcacheServicePb.access$3702(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_descriptor, new String[] { "Item", "NameSpace" }, MemcacheServicePb.MemcacheSetRequest.class, MemcacheServicePb.MemcacheSetRequest.Builder.class));
/*      */ 
/* 9799 */         MemcacheServicePb.access$3802((Descriptors.Descriptor)MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_descriptor.getNestedTypes().get(0));
/*      */ 
/* 9801 */         MemcacheServicePb.access$3902(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_Item_descriptor, new String[] { "Key", "Value", "Flags", "SetPolicy", "ExpirationTime", "CasId", "ForCas" }, MemcacheServicePb.MemcacheSetRequest.Item.class, MemcacheServicePb.MemcacheSetRequest.Item.Builder.class));
/*      */ 
/* 9807 */         MemcacheServicePb.access$6302((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(4));
/*      */ 
/* 9809 */         MemcacheServicePb.access$6402(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheSetResponse_descriptor, new String[] { "SetStatus" }, MemcacheServicePb.MemcacheSetResponse.class, MemcacheServicePb.MemcacheSetResponse.Builder.class));
/*      */ 
/* 9815 */         MemcacheServicePb.access$6902((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(5));
/*      */ 
/* 9817 */         MemcacheServicePb.access$7002(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_descriptor, new String[] { "Item", "NameSpace" }, MemcacheServicePb.MemcacheDeleteRequest.class, MemcacheServicePb.MemcacheDeleteRequest.Builder.class));
/*      */ 
/* 9823 */         MemcacheServicePb.access$7102((Descriptors.Descriptor)MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_descriptor.getNestedTypes().get(0));
/*      */ 
/* 9825 */         MemcacheServicePb.access$7202(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_Item_descriptor, new String[] { "Key", "DeleteTime" }, MemcacheServicePb.MemcacheDeleteRequest.Item.class, MemcacheServicePb.MemcacheDeleteRequest.Item.Builder.class));
/*      */ 
/* 9831 */         MemcacheServicePb.access$8602((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(6));
/*      */ 
/* 9833 */         MemcacheServicePb.access$8702(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheDeleteResponse_descriptor, new String[] { "DeleteStatus" }, MemcacheServicePb.MemcacheDeleteResponse.class, MemcacheServicePb.MemcacheDeleteResponse.Builder.class));
/*      */ 
/* 9839 */         MemcacheServicePb.access$9202((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(7));
/*      */ 
/* 9841 */         MemcacheServicePb.access$9302(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheIncrementRequest_descriptor, new String[] { "Key", "NameSpace", "Delta", "Direction", "InitialValue", "InitialFlags" }, MemcacheServicePb.MemcacheIncrementRequest.class, MemcacheServicePb.MemcacheIncrementRequest.Builder.class));
/*      */ 
/* 9847 */         MemcacheServicePb.access$10902((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(8));
/*      */ 
/* 9849 */         MemcacheServicePb.access$11002(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheIncrementResponse_descriptor, new String[] { "NewValue", "IncrementStatus" }, MemcacheServicePb.MemcacheIncrementResponse.class, MemcacheServicePb.MemcacheIncrementResponse.Builder.class));
/*      */ 
/* 9855 */         MemcacheServicePb.access$11802((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(9));
/*      */ 
/* 9857 */         MemcacheServicePb.access$11902(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementRequest_descriptor, new String[] { "NameSpace", "Item" }, MemcacheServicePb.MemcacheBatchIncrementRequest.class, MemcacheServicePb.MemcacheBatchIncrementRequest.Builder.class));
/*      */ 
/* 9863 */         MemcacheServicePb.access$12602((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(10));
/*      */ 
/* 9865 */         MemcacheServicePb.access$12702(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementResponse_descriptor, new String[] { "Item" }, MemcacheServicePb.MemcacheBatchIncrementResponse.class, MemcacheServicePb.MemcacheBatchIncrementResponse.Builder.class));
/*      */ 
/* 9871 */         MemcacheServicePb.access$13202((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(11));
/*      */ 
/* 9873 */         MemcacheServicePb.access$13302(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheFlushRequest_descriptor, new String[0], MemcacheServicePb.MemcacheFlushRequest.class, MemcacheServicePb.MemcacheFlushRequest.Builder.class));
/*      */ 
/* 9879 */         MemcacheServicePb.access$13702((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(12));
/*      */ 
/* 9881 */         MemcacheServicePb.access$13802(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheFlushResponse_descriptor, new String[0], MemcacheServicePb.MemcacheFlushResponse.class, MemcacheServicePb.MemcacheFlushResponse.Builder.class));
/*      */ 
/* 9887 */         MemcacheServicePb.access$14202((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(13));
/*      */ 
/* 9889 */         MemcacheServicePb.access$14302(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheStatsRequest_descriptor, new String[0], MemcacheServicePb.MemcacheStatsRequest.class, MemcacheServicePb.MemcacheStatsRequest.Builder.class));
/*      */ 
/* 9895 */         MemcacheServicePb.access$14702((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(14));
/*      */ 
/* 9897 */         MemcacheServicePb.access$14802(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MergedNamespaceStats_descriptor, new String[] { "Hits", "Misses", "ByteHits", "Items", "Bytes", "OldestItemAge" }, MemcacheServicePb.MergedNamespaceStats.class, MemcacheServicePb.MergedNamespaceStats.Builder.class));
/*      */ 
/* 9903 */         MemcacheServicePb.access$16402((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(15));
/*      */ 
/* 9905 */         MemcacheServicePb.access$16502(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheStatsResponse_descriptor, new String[] { "Stats" }, MemcacheServicePb.MemcacheStatsResponse.class, MemcacheServicePb.MemcacheStatsResponse.Builder.class));
/*      */ 
/* 9911 */         MemcacheServicePb.access$17102((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(16));
/*      */ 
/* 9913 */         MemcacheServicePb.access$17202(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailRequest_descriptor, new String[] { "ItemCount", "NameSpace" }, MemcacheServicePb.MemcacheGrabTailRequest.class, MemcacheServicePb.MemcacheGrabTailRequest.Builder.class));
/*      */ 
/* 9919 */         MemcacheServicePb.access$18002((Descriptors.Descriptor)MemcacheServicePb.getDescriptor().getMessageTypes().get(17));
/*      */ 
/* 9921 */         MemcacheServicePb.access$18102(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_descriptor, new String[] { "Item" }, MemcacheServicePb.MemcacheGrabTailResponse.class, MemcacheServicePb.MemcacheGrabTailResponse.Builder.class));
/*      */ 
/* 9927 */         MemcacheServicePb.access$18202((Descriptors.Descriptor)MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_descriptor.getNestedTypes().get(0));
/*      */ 
/* 9929 */         MemcacheServicePb.access$18302(new GeneratedMessage.FieldAccessorTable(MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_Item_descriptor, new String[] { "Value", "Flags" }, MemcacheServicePb.MemcacheGrabTailResponse.Item.class, MemcacheServicePb.MemcacheGrabTailResponse.Item.Builder.class));
/*      */ 
/* 9935 */         return null;
/*      */       }
/*      */     };
/* 9938 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/*      */   }
/*      */ 
/*      */   public static abstract class MemcacheService
/*      */     implements Service
/*      */   {
/*      */     public static Service newReflectiveService(Interface impl)
/*      */     {
/* 8931 */       return new MemcacheService(impl)
/*      */       {
/*      */         public void get(RpcController controller, MemcacheServicePb.MemcacheGetRequest request, RpcCallback<MemcacheServicePb.MemcacheGetResponse> done)
/*      */         {
/* 8937 */           this.val$impl.get(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void set(RpcController controller, MemcacheServicePb.MemcacheSetRequest request, RpcCallback<MemcacheServicePb.MemcacheSetResponse> done)
/*      */         {
/* 8945 */           this.val$impl.set(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void delete(RpcController controller, MemcacheServicePb.MemcacheDeleteRequest request, RpcCallback<MemcacheServicePb.MemcacheDeleteResponse> done)
/*      */         {
/* 8953 */           this.val$impl.delete(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void increment(RpcController controller, MemcacheServicePb.MemcacheIncrementRequest request, RpcCallback<MemcacheServicePb.MemcacheIncrementResponse> done)
/*      */         {
/* 8961 */           this.val$impl.increment(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void batchIncrement(RpcController controller, MemcacheServicePb.MemcacheBatchIncrementRequest request, RpcCallback<MemcacheServicePb.MemcacheBatchIncrementResponse> done)
/*      */         {
/* 8969 */           this.val$impl.batchIncrement(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void flushAll(RpcController controller, MemcacheServicePb.MemcacheFlushRequest request, RpcCallback<MemcacheServicePb.MemcacheFlushResponse> done)
/*      */         {
/* 8977 */           this.val$impl.flushAll(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void stats(RpcController controller, MemcacheServicePb.MemcacheStatsRequest request, RpcCallback<MemcacheServicePb.MemcacheStatsResponse> done)
/*      */         {
/* 8985 */           this.val$impl.stats(controller, request, done);
/*      */         }
/*      */ 
/*      */         public void grabTail(RpcController controller, MemcacheServicePb.MemcacheGrabTailRequest request, RpcCallback<MemcacheServicePb.MemcacheGrabTailResponse> done)
/*      */         {
/* 8993 */           this.val$impl.grabTail(controller, request, done);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static BlockingService newReflectiveBlockingService(BlockingInterface impl)
/*      */     {
/* 9001 */       return new BlockingService(impl)
/*      */       {
/*      */         public final Descriptors.ServiceDescriptor getDescriptorForType() {
/* 9004 */           return MemcacheServicePb.MemcacheService.getDescriptor();
/*      */         }
/*      */ 
/*      */         public final Message callBlockingMethod(Descriptors.MethodDescriptor method, RpcController controller, Message request)
/*      */           throws ServiceException
/*      */         {
/* 9012 */           if (method.getService() != MemcacheServicePb.MemcacheService.getDescriptor()) {
/* 9013 */             throw new IllegalArgumentException("Service.callBlockingMethod() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 9017 */           switch (method.getIndex()) {
/*      */           case 0:
/* 9019 */             return this.val$impl.get(controller, (MemcacheServicePb.MemcacheGetRequest)request);
/*      */           case 1:
/* 9021 */             return this.val$impl.set(controller, (MemcacheServicePb.MemcacheSetRequest)request);
/*      */           case 2:
/* 9023 */             return this.val$impl.delete(controller, (MemcacheServicePb.MemcacheDeleteRequest)request);
/*      */           case 3:
/* 9025 */             return this.val$impl.increment(controller, (MemcacheServicePb.MemcacheIncrementRequest)request);
/*      */           case 4:
/* 9027 */             return this.val$impl.batchIncrement(controller, (MemcacheServicePb.MemcacheBatchIncrementRequest)request);
/*      */           case 5:
/* 9029 */             return this.val$impl.flushAll(controller, (MemcacheServicePb.MemcacheFlushRequest)request);
/*      */           case 6:
/* 9031 */             return this.val$impl.stats(controller, (MemcacheServicePb.MemcacheStatsRequest)request);
/*      */           case 7:
/* 9033 */             return this.val$impl.grabTail(controller, (MemcacheServicePb.MemcacheGrabTailRequest)request);
/*      */           }
/* 9035 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */ 
/*      */         public final Message getRequestPrototype(Descriptors.MethodDescriptor method)
/*      */         {
/* 9042 */           if (method.getService() != MemcacheServicePb.MemcacheService.getDescriptor()) {
/* 9043 */             throw new IllegalArgumentException("Service.getRequestPrototype() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 9047 */           switch (method.getIndex()) {
/*      */           case 0:
/* 9049 */             return MemcacheServicePb.MemcacheGetRequest.getDefaultInstance();
/*      */           case 1:
/* 9051 */             return MemcacheServicePb.MemcacheSetRequest.getDefaultInstance();
/*      */           case 2:
/* 9053 */             return MemcacheServicePb.MemcacheDeleteRequest.getDefaultInstance();
/*      */           case 3:
/* 9055 */             return MemcacheServicePb.MemcacheIncrementRequest.getDefaultInstance();
/*      */           case 4:
/* 9057 */             return MemcacheServicePb.MemcacheBatchIncrementRequest.getDefaultInstance();
/*      */           case 5:
/* 9059 */             return MemcacheServicePb.MemcacheFlushRequest.getDefaultInstance();
/*      */           case 6:
/* 9061 */             return MemcacheServicePb.MemcacheStatsRequest.getDefaultInstance();
/*      */           case 7:
/* 9063 */             return MemcacheServicePb.MemcacheGrabTailRequest.getDefaultInstance();
/*      */           }
/* 9065 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */ 
/*      */         public final Message getResponsePrototype(Descriptors.MethodDescriptor method)
/*      */         {
/* 9072 */           if (method.getService() != MemcacheServicePb.MemcacheService.getDescriptor()) {
/* 9073 */             throw new IllegalArgumentException("Service.getResponsePrototype() given method descriptor for wrong service type.");
/*      */           }
/*      */ 
/* 9077 */           switch (method.getIndex()) {
/*      */           case 0:
/* 9079 */             return MemcacheServicePb.MemcacheGetResponse.getDefaultInstance();
/*      */           case 1:
/* 9081 */             return MemcacheServicePb.MemcacheSetResponse.getDefaultInstance();
/*      */           case 2:
/* 9083 */             return MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance();
/*      */           case 3:
/* 9085 */             return MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance();
/*      */           case 4:
/* 9087 */             return MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance();
/*      */           case 5:
/* 9089 */             return MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance();
/*      */           case 6:
/* 9091 */             return MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance();
/*      */           case 7:
/* 9093 */             return MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance();
/*      */           }
/* 9095 */           throw new AssertionError("Can't get here.");
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public abstract void get(RpcController paramRpcController, MemcacheServicePb.MemcacheGetRequest paramMemcacheGetRequest, RpcCallback<MemcacheServicePb.MemcacheGetResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void set(RpcController paramRpcController, MemcacheServicePb.MemcacheSetRequest paramMemcacheSetRequest, RpcCallback<MemcacheServicePb.MemcacheSetResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void delete(RpcController paramRpcController, MemcacheServicePb.MemcacheDeleteRequest paramMemcacheDeleteRequest, RpcCallback<MemcacheServicePb.MemcacheDeleteResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void increment(RpcController paramRpcController, MemcacheServicePb.MemcacheIncrementRequest paramMemcacheIncrementRequest, RpcCallback<MemcacheServicePb.MemcacheIncrementResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void batchIncrement(RpcController paramRpcController, MemcacheServicePb.MemcacheBatchIncrementRequest paramMemcacheBatchIncrementRequest, RpcCallback<MemcacheServicePb.MemcacheBatchIncrementResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void flushAll(RpcController paramRpcController, MemcacheServicePb.MemcacheFlushRequest paramMemcacheFlushRequest, RpcCallback<MemcacheServicePb.MemcacheFlushResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void stats(RpcController paramRpcController, MemcacheServicePb.MemcacheStatsRequest paramMemcacheStatsRequest, RpcCallback<MemcacheServicePb.MemcacheStatsResponse> paramRpcCallback);
/*      */ 
/*      */     public abstract void grabTail(RpcController paramRpcController, MemcacheServicePb.MemcacheGrabTailRequest paramMemcacheGrabTailRequest, RpcCallback<MemcacheServicePb.MemcacheGrabTailResponse> paramRpcCallback);
/*      */ 
/*      */     public static final Descriptors.ServiceDescriptor getDescriptor()
/*      */     {
/* 9145 */       return (Descriptors.ServiceDescriptor)MemcacheServicePb.getDescriptor().getServices().get(0);
/*      */     }
/*      */ 
/*      */     public final Descriptors.ServiceDescriptor getDescriptorForType() {
/* 9149 */       return getDescriptor();
/*      */     }
/*      */ 
/*      */     public final void callMethod(Descriptors.MethodDescriptor method, RpcController controller, Message request, RpcCallback<Message> done)
/*      */     {
/* 9158 */       if (method.getService() != getDescriptor()) {
/* 9159 */         throw new IllegalArgumentException("Service.callMethod() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 9163 */       switch (method.getIndex()) {
/*      */       case 0:
/* 9165 */         get(controller, (MemcacheServicePb.MemcacheGetRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9168 */         return;
/*      */       case 1:
/* 9170 */         set(controller, (MemcacheServicePb.MemcacheSetRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9173 */         return;
/*      */       case 2:
/* 9175 */         delete(controller, (MemcacheServicePb.MemcacheDeleteRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9178 */         return;
/*      */       case 3:
/* 9180 */         increment(controller, (MemcacheServicePb.MemcacheIncrementRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9183 */         return;
/*      */       case 4:
/* 9185 */         batchIncrement(controller, (MemcacheServicePb.MemcacheBatchIncrementRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9188 */         return;
/*      */       case 5:
/* 9190 */         flushAll(controller, (MemcacheServicePb.MemcacheFlushRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9193 */         return;
/*      */       case 6:
/* 9195 */         stats(controller, (MemcacheServicePb.MemcacheStatsRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9198 */         return;
/*      */       case 7:
/* 9200 */         grabTail(controller, (MemcacheServicePb.MemcacheGrabTailRequest)request, RpcUtil.specializeCallback(done));
/*      */ 
/* 9203 */         return;
/*      */       }
/* 9205 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public final Message getRequestPrototype(Descriptors.MethodDescriptor method)
/*      */     {
/* 9212 */       if (method.getService() != getDescriptor()) {
/* 9213 */         throw new IllegalArgumentException("Service.getRequestPrototype() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 9217 */       switch (method.getIndex()) {
/*      */       case 0:
/* 9219 */         return MemcacheServicePb.MemcacheGetRequest.getDefaultInstance();
/*      */       case 1:
/* 9221 */         return MemcacheServicePb.MemcacheSetRequest.getDefaultInstance();
/*      */       case 2:
/* 9223 */         return MemcacheServicePb.MemcacheDeleteRequest.getDefaultInstance();
/*      */       case 3:
/* 9225 */         return MemcacheServicePb.MemcacheIncrementRequest.getDefaultInstance();
/*      */       case 4:
/* 9227 */         return MemcacheServicePb.MemcacheBatchIncrementRequest.getDefaultInstance();
/*      */       case 5:
/* 9229 */         return MemcacheServicePb.MemcacheFlushRequest.getDefaultInstance();
/*      */       case 6:
/* 9231 */         return MemcacheServicePb.MemcacheStatsRequest.getDefaultInstance();
/*      */       case 7:
/* 9233 */         return MemcacheServicePb.MemcacheGrabTailRequest.getDefaultInstance();
/*      */       }
/* 9235 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public final Message getResponsePrototype(Descriptors.MethodDescriptor method)
/*      */     {
/* 9242 */       if (method.getService() != getDescriptor()) {
/* 9243 */         throw new IllegalArgumentException("Service.getResponsePrototype() given method descriptor for wrong service type.");
/*      */       }
/*      */ 
/* 9247 */       switch (method.getIndex()) {
/*      */       case 0:
/* 9249 */         return MemcacheServicePb.MemcacheGetResponse.getDefaultInstance();
/*      */       case 1:
/* 9251 */         return MemcacheServicePb.MemcacheSetResponse.getDefaultInstance();
/*      */       case 2:
/* 9253 */         return MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance();
/*      */       case 3:
/* 9255 */         return MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance();
/*      */       case 4:
/* 9257 */         return MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance();
/*      */       case 5:
/* 9259 */         return MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance();
/*      */       case 6:
/* 9261 */         return MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance();
/*      */       case 7:
/* 9263 */         return MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance();
/*      */       }
/* 9265 */       throw new AssertionError("Can't get here.");
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcChannel channel)
/*      */     {
/* 9271 */       return new Stub(channel, null);
/*      */     }
/*      */ 
/*      */     public static BlockingInterface newBlockingStub(BlockingRpcChannel channel)
/*      */     {
/* 9408 */       return new BlockingStub(channel, null);
/*      */     }
/*      */ 
/*      */     private static final class BlockingStub
/*      */       implements MemcacheServicePb.MemcacheService.BlockingInterface
/*      */     {
/*      */       private final BlockingRpcChannel channel;
/*      */ 
/*      */       private BlockingStub(BlockingRpcChannel channel)
/*      */       {
/* 9455 */         this.channel = channel;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetResponse get(RpcController controller, MemcacheServicePb.MemcacheGetRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9464 */         return (MemcacheServicePb.MemcacheGetResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(0), controller, request, MemcacheServicePb.MemcacheGetResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetResponse set(RpcController controller, MemcacheServicePb.MemcacheSetRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9476 */         return (MemcacheServicePb.MemcacheSetResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(1), controller, request, MemcacheServicePb.MemcacheSetResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteResponse delete(RpcController controller, MemcacheServicePb.MemcacheDeleteRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9488 */         return (MemcacheServicePb.MemcacheDeleteResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(2), controller, request, MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementResponse increment(RpcController controller, MemcacheServicePb.MemcacheIncrementRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9500 */         return (MemcacheServicePb.MemcacheIncrementResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(3), controller, request, MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementResponse batchIncrement(RpcController controller, MemcacheServicePb.MemcacheBatchIncrementRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9512 */         return (MemcacheServicePb.MemcacheBatchIncrementResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(4), controller, request, MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushResponse flushAll(RpcController controller, MemcacheServicePb.MemcacheFlushRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9524 */         return (MemcacheServicePb.MemcacheFlushResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(5), controller, request, MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsResponse stats(RpcController controller, MemcacheServicePb.MemcacheStatsRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9536 */         return (MemcacheServicePb.MemcacheStatsResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(6), controller, request, MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance());
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailResponse grabTail(RpcController controller, MemcacheServicePb.MemcacheGrabTailRequest request)
/*      */         throws ServiceException
/*      */       {
/* 9548 */         return (MemcacheServicePb.MemcacheGrabTailResponse)this.channel.callBlockingMethod((Descriptors.MethodDescriptor)MemcacheServicePb.MemcacheService.getDescriptor().getMethods().get(7), controller, request, MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance());
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface
/*      */     {
/*      */       public abstract MemcacheServicePb.MemcacheGetResponse get(RpcController paramRpcController, MemcacheServicePb.MemcacheGetRequest paramMemcacheGetRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheSetResponse set(RpcController paramRpcController, MemcacheServicePb.MemcacheSetRequest paramMemcacheSetRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheDeleteResponse delete(RpcController paramRpcController, MemcacheServicePb.MemcacheDeleteRequest paramMemcacheDeleteRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheIncrementResponse increment(RpcController paramRpcController, MemcacheServicePb.MemcacheIncrementRequest paramMemcacheIncrementRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheBatchIncrementResponse batchIncrement(RpcController paramRpcController, MemcacheServicePb.MemcacheBatchIncrementRequest paramMemcacheBatchIncrementRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheFlushResponse flushAll(RpcController paramRpcController, MemcacheServicePb.MemcacheFlushRequest paramMemcacheFlushRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheStatsResponse stats(RpcController paramRpcController, MemcacheServicePb.MemcacheStatsRequest paramMemcacheStatsRequest)
/*      */         throws ServiceException;
/*      */ 
/*      */       public abstract MemcacheServicePb.MemcacheGrabTailResponse grabTail(RpcController paramRpcController, MemcacheServicePb.MemcacheGrabTailRequest paramMemcacheGrabTailRequest)
/*      */         throws ServiceException;
/*      */     }
/*      */ 
/*      */     public static final class Stub extends MemcacheServicePb.MemcacheService
/*      */       implements MemcacheServicePb.MemcacheService.Interface
/*      */     {
/*      */       private final RpcChannel channel;
/*      */ 
/*      */       private Stub(RpcChannel channel)
/*      */       {
/* 9276 */         this.channel = channel;
/*      */       }
/*      */ 
/*      */       public RpcChannel getChannel()
/*      */       {
/* 9282 */         return this.channel;
/*      */       }
/*      */ 
/*      */       public void get(RpcController controller, MemcacheServicePb.MemcacheGetRequest request, RpcCallback<MemcacheServicePb.MemcacheGetResponse> done)
/*      */       {
/* 9289 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(0), controller, request, MemcacheServicePb.MemcacheGetResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheGetResponse.class, MemcacheServicePb.MemcacheGetResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void set(RpcController controller, MemcacheServicePb.MemcacheSetRequest request, RpcCallback<MemcacheServicePb.MemcacheSetResponse> done)
/*      */       {
/* 9304 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(1), controller, request, MemcacheServicePb.MemcacheSetResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheSetResponse.class, MemcacheServicePb.MemcacheSetResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void delete(RpcController controller, MemcacheServicePb.MemcacheDeleteRequest request, RpcCallback<MemcacheServicePb.MemcacheDeleteResponse> done)
/*      */       {
/* 9319 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(2), controller, request, MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheDeleteResponse.class, MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void increment(RpcController controller, MemcacheServicePb.MemcacheIncrementRequest request, RpcCallback<MemcacheServicePb.MemcacheIncrementResponse> done)
/*      */       {
/* 9334 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(3), controller, request, MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheIncrementResponse.class, MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void batchIncrement(RpcController controller, MemcacheServicePb.MemcacheBatchIncrementRequest request, RpcCallback<MemcacheServicePb.MemcacheBatchIncrementResponse> done)
/*      */       {
/* 9349 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(4), controller, request, MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheBatchIncrementResponse.class, MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void flushAll(RpcController controller, MemcacheServicePb.MemcacheFlushRequest request, RpcCallback<MemcacheServicePb.MemcacheFlushResponse> done)
/*      */       {
/* 9364 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(5), controller, request, MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheFlushResponse.class, MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void stats(RpcController controller, MemcacheServicePb.MemcacheStatsRequest request, RpcCallback<MemcacheServicePb.MemcacheStatsResponse> done)
/*      */       {
/* 9379 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(6), controller, request, MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheStatsResponse.class, MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance()));
/*      */       }
/*      */ 
/*      */       public void grabTail(RpcController controller, MemcacheServicePb.MemcacheGrabTailRequest request, RpcCallback<MemcacheServicePb.MemcacheGrabTailResponse> done)
/*      */       {
/* 9394 */         this.channel.callMethod((Descriptors.MethodDescriptor)getDescriptor().getMethods().get(7), controller, request, MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance(), RpcUtil.generalizeCallback(done, MemcacheServicePb.MemcacheGrabTailResponse.class, MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance()));
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface
/*      */     {
/*      */       public abstract void get(RpcController paramRpcController, MemcacheServicePb.MemcacheGetRequest paramMemcacheGetRequest, RpcCallback<MemcacheServicePb.MemcacheGetResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void set(RpcController paramRpcController, MemcacheServicePb.MemcacheSetRequest paramMemcacheSetRequest, RpcCallback<MemcacheServicePb.MemcacheSetResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void delete(RpcController paramRpcController, MemcacheServicePb.MemcacheDeleteRequest paramMemcacheDeleteRequest, RpcCallback<MemcacheServicePb.MemcacheDeleteResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void increment(RpcController paramRpcController, MemcacheServicePb.MemcacheIncrementRequest paramMemcacheIncrementRequest, RpcCallback<MemcacheServicePb.MemcacheIncrementResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void batchIncrement(RpcController paramRpcController, MemcacheServicePb.MemcacheBatchIncrementRequest paramMemcacheBatchIncrementRequest, RpcCallback<MemcacheServicePb.MemcacheBatchIncrementResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void flushAll(RpcController paramRpcController, MemcacheServicePb.MemcacheFlushRequest paramMemcacheFlushRequest, RpcCallback<MemcacheServicePb.MemcacheFlushResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void stats(RpcController paramRpcController, MemcacheServicePb.MemcacheStatsRequest paramMemcacheStatsRequest, RpcCallback<MemcacheServicePb.MemcacheStatsResponse> paramRpcCallback);
/*      */ 
/*      */       public abstract void grabTail(RpcController paramRpcController, MemcacheServicePb.MemcacheGrabTailRequest paramMemcacheGrabTailRequest, RpcCallback<MemcacheServicePb.MemcacheGrabTailResponse> paramRpcCallback);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheGrabTailResponse extends GeneratedMessage
/*      */   {
/* 8874 */     private static final MemcacheGrabTailResponse defaultInstance = new MemcacheGrabTailResponse(true);
/*      */     public static final int ITEM_FIELD_NUMBER = 1;
/*      */     private List<Item> item_;
/* 8585 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheGrabTailResponse(Builder builder)
/*      */     {
/* 8178 */       super();
/*      */     }
/*      */     private MemcacheGrabTailResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse getDefaultInstance() {
/* 8184 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheGrabTailResponse getDefaultInstanceForType() {
/* 8188 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 8193 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 8198 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<Item> getItemList()
/*      */     {
/* 8557 */       return this.item_;
/*      */     }
/*      */     public int getItemCount() {
/* 8560 */       return this.item_.size();
/*      */     }
/*      */     public Item getItem(int index) {
/* 8563 */       return (Item)this.item_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 8567 */       this.item_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 8570 */       for (Item element : getItemList()) {
/* 8571 */         if (!element.isInitialized()) return false;
/*      */       }
/* 8573 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 8578 */       getSerializedSize();
/* 8579 */       for (Item element : getItemList()) {
/* 8580 */         output.writeGroup(1, element);
/*      */       }
/* 8582 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 8587 */       int size = this.memoizedSerializedSize;
/* 8588 */       if (size != -1) return size;
/*      */ 
/* 8590 */       size = 0;
/* 8591 */       for (Item element : getItemList()) {
/* 8592 */         size += CodedOutputStream.computeGroupSize(1, element);
/*      */       }
/*      */ 
/* 8595 */       size += getUnknownFields().getSerializedSize();
/* 8596 */       this.memoizedSerializedSize = size;
/* 8597 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 8602 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 8608 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 8614 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 8619 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 8625 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 8630 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 8636 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 8641 */       Builder builder = newBuilder();
/* 8642 */       if (builder.mergeDelimitedFrom(input)) {
/* 8643 */         return builder.buildParsed();
/*      */       }
/* 8645 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 8652 */       Builder builder = newBuilder();
/* 8653 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 8654 */         return builder.buildParsed();
/*      */       }
/* 8656 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 8662 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 8668 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 8672 */       return Builder.access$19200(); } 
/* 8673 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheGrabTailResponse prototype) {
/* 8675 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 8677 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 8875 */       MemcacheServicePb.internalForceInit();
/* 8876 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 8811 */       private List<MemcacheServicePb.MemcacheGrabTailResponse.Item> item_ = Collections.emptyList();
/*      */       private boolean isItemMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 8683 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 8688 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 8696 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 8700 */         super.clear();
/* 8701 */         this.item_ = Collections.emptyList();
/* 8702 */         this.isItemMutable = false;
/* 8703 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 8707 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 8712 */         return MemcacheServicePb.MemcacheGrabTailResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailResponse getDefaultInstanceForType() {
/* 8716 */         return MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailResponse build() {
/* 8720 */         MemcacheServicePb.MemcacheGrabTailResponse result = buildPartial();
/* 8721 */         if (!result.isInitialized()) {
/* 8722 */           throw newUninitializedMessageException(result);
/*      */         }
/* 8724 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheGrabTailResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 8729 */         MemcacheServicePb.MemcacheGrabTailResponse result = buildPartial();
/* 8730 */         if (!result.isInitialized()) {
/* 8731 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 8734 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailResponse buildPartial() {
/* 8738 */         MemcacheServicePb.MemcacheGrabTailResponse result = new MemcacheServicePb.MemcacheGrabTailResponse(this, null);
/* 8739 */         if (this.isItemMutable) {
/* 8740 */           this.item_ = Collections.unmodifiableList(this.item_);
/* 8741 */           this.isItemMutable = false;
/*      */         }
/* 8743 */         MemcacheServicePb.MemcacheGrabTailResponse.access$19402(result, this.item_);
/* 8744 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 8748 */         if ((other instanceof MemcacheServicePb.MemcacheGrabTailResponse)) {
/* 8749 */           return mergeFrom((MemcacheServicePb.MemcacheGrabTailResponse)other);
/*      */         }
/* 8751 */         super.mergeFrom(other);
/* 8752 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheGrabTailResponse other)
/*      */       {
/* 8757 */         if (other == MemcacheServicePb.MemcacheGrabTailResponse.getDefaultInstance()) return this;
/* 8758 */         if (!other.item_.isEmpty()) {
/* 8759 */           if (this.item_.isEmpty()) {
/* 8760 */             this.item_ = other.item_;
/* 8761 */             this.isItemMutable = false;
/*      */           } else {
/* 8763 */             ensureItemIsMutable();
/* 8764 */             this.item_.addAll(other.item_);
/*      */           }
/*      */         }
/* 8767 */         mergeUnknownFields(other.getUnknownFields());
/* 8768 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 8772 */         for (MemcacheServicePb.MemcacheGrabTailResponse.Item element : getItemList()) {
/* 8773 */           if (!element.isInitialized()) return false;
/*      */         }
/* 8775 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 8782 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 8786 */           int tag = input.readTag();
/* 8787 */           switch (tag) {
/*      */           case 0:
/* 8789 */             setUnknownFields(unknownFields.build());
/* 8790 */             return this;
/*      */           default:
/* 8792 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 8794 */             setUnknownFields(unknownFields.build());
/* 8795 */             return this;
/*      */           case 11:
/* 8800 */             MemcacheServicePb.MemcacheGrabTailResponse.Item.Builder subBuilder = MemcacheServicePb.MemcacheGrabTailResponse.Item.newBuilder();
/* 8801 */             input.readGroup(1, subBuilder, extensionRegistry);
/* 8802 */             addItem(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureItemIsMutable()
/*      */       {
/* 8815 */         if (!this.isItemMutable) {
/* 8816 */           this.item_ = new ArrayList(this.item_);
/* 8817 */           this.isItemMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheGrabTailResponse.Item> getItemList() {
/* 8821 */         return Collections.unmodifiableList(this.item_);
/*      */       }
/*      */       public int getItemCount() {
/* 8824 */         return this.item_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheGrabTailResponse.Item getItem(int index) {
/* 8827 */         return (MemcacheServicePb.MemcacheGrabTailResponse.Item)this.item_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheGrabTailResponse.Item value) {
/* 8831 */         if (value == null) {
/* 8832 */           throw new NullPointerException();
/*      */         }
/* 8834 */         ensureItemIsMutable();
/* 8835 */         this.item_.set(index, value);
/* 8836 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheGrabTailResponse.Item.Builder builderForValue) {
/* 8840 */         ensureItemIsMutable();
/* 8841 */         this.item_.set(index, builderForValue.build());
/* 8842 */         return this;
/*      */       }
/*      */       public Builder addItem(MemcacheServicePb.MemcacheGrabTailResponse.Item value) {
/* 8845 */         if (value == null) {
/* 8846 */           throw new NullPointerException();
/*      */         }
/* 8848 */         ensureItemIsMutable();
/* 8849 */         this.item_.add(value);
/* 8850 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addItem(MemcacheServicePb.MemcacheGrabTailResponse.Item.Builder builderForValue) {
/* 8854 */         ensureItemIsMutable();
/* 8855 */         this.item_.add(builderForValue.build());
/* 8856 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllItem(Iterable<? extends MemcacheServicePb.MemcacheGrabTailResponse.Item> values) {
/* 8860 */         ensureItemIsMutable();
/* 8861 */         GeneratedMessage.Builder.addAll(values, this.item_);
/* 8862 */         return this;
/*      */       }
/*      */       public Builder clearItem() {
/* 8865 */         this.item_ = Collections.emptyList();
/* 8866 */         this.isItemMutable = false;
/* 8867 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static final class Item extends GeneratedMessage
/*      */     {
/* 8545 */       private static final Item defaultInstance = new Item(true);
/*      */       public static final int VALUE_FIELD_NUMBER = 2;
/*      */       private boolean hasValue;
/*      */       private ByteString value_;
/*      */       public static final int FLAGS_FIELD_NUMBER = 3;
/*      */       private boolean hasFlags;
/*      */       private int flags_;
/* 8271 */       private int memoizedSerializedSize = -1;
/*      */ 
/*      */       private Item(Builder builder)
/*      */       {
/* 8205 */         super();
/*      */       }
/*      */       private Item(boolean noInit) {
/*      */       }
/*      */ 
/*      */       public static Item getDefaultInstance() {
/* 8211 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public Item getDefaultInstanceForType() {
/* 8215 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 8220 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_Item_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 8225 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_Item_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       public boolean hasValue()
/*      */       {
/* 8233 */         return this.hasValue;
/*      */       }
/*      */       public ByteString getValue() {
/* 8236 */         return this.value_;
/*      */       }
/*      */ 
/*      */       public boolean hasFlags()
/*      */       {
/* 8244 */         return this.hasFlags;
/*      */       }
/*      */       public int getFlags() {
/* 8247 */         return this.flags_;
/*      */       }
/*      */ 
/*      */       private void initFields() {
/* 8251 */         this.value_ = ByteString.EMPTY;
/* 8252 */         this.flags_ = 0;
/*      */       }
/*      */       public final boolean isInitialized() {
/* 8255 */         return this.hasValue;
/*      */       }
/*      */ 
/*      */       public void writeTo(CodedOutputStream output)
/*      */         throws IOException
/*      */       {
/* 8261 */         getSerializedSize();
/* 8262 */         if (hasValue()) {
/* 8263 */           output.writeBytes(2, getValue());
/*      */         }
/* 8265 */         if (hasFlags()) {
/* 8266 */           output.writeFixed32(3, getFlags());
/*      */         }
/* 8268 */         getUnknownFields().writeTo(output);
/*      */       }
/*      */ 
/*      */       public int getSerializedSize()
/*      */       {
/* 8273 */         int size = this.memoizedSerializedSize;
/* 8274 */         if (size != -1) return size;
/*      */ 
/* 8276 */         size = 0;
/* 8277 */         if (hasValue()) {
/* 8278 */           size += CodedOutputStream.computeBytesSize(2, getValue());
/*      */         }
/*      */ 
/* 8281 */         if (hasFlags()) {
/* 8282 */           size += CodedOutputStream.computeFixed32Size(3, getFlags());
/*      */         }
/*      */ 
/* 8285 */         size += getUnknownFields().getSerializedSize();
/* 8286 */         this.memoizedSerializedSize = size;
/* 8287 */         return size;
/*      */       }
/*      */ 
/*      */       protected Object writeReplace() throws ObjectStreamException
/*      */       {
/* 8292 */         return super.writeReplace();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 8298 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 8304 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */       {
/* 8309 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 8315 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input) throws IOException
/*      */       {
/* 8320 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 8326 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input) throws IOException
/*      */       {
/* 8331 */         Builder builder = newBuilder();
/* 8332 */         if (builder.mergeDelimitedFrom(input)) {
/* 8333 */           return builder.buildParsed();
/*      */         }
/* 8335 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 8342 */         Builder builder = newBuilder();
/* 8343 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 8344 */           return builder.buildParsed();
/*      */         }
/* 8346 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input)
/*      */         throws IOException
/*      */       {
/* 8352 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 8358 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Builder newBuilder() {
/* 8362 */         return Builder.access$18500(); } 
/* 8363 */       public Builder newBuilderForType() { return newBuilder(); } 
/*      */       public static Builder newBuilder(Item prototype) {
/* 8365 */         return newBuilder().mergeFrom(prototype);
/*      */       }
/* 8367 */       public Builder toBuilder() { return newBuilder(this);
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 8546 */         MemcacheServicePb.internalForceInit();
/* 8547 */         defaultInstance.initFields();
/*      */       }
/*      */ 
/*      */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */       {
/*      */         private boolean hasValue;
/* 8500 */         private ByteString value_ = ByteString.EMPTY;
/*      */         private boolean hasFlags;
/*      */         private int flags_;
/*      */ 
/*      */         public static final Descriptors.Descriptor getDescriptor()
/*      */         {
/* 8373 */           return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_Item_descriptor;
/*      */         }
/*      */ 
/*      */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */         {
/* 8378 */           return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailResponse_Item_fieldAccessorTable;
/*      */         }
/*      */ 
/*      */         private static Builder create()
/*      */         {
/* 8386 */           return new Builder();
/*      */         }
/*      */ 
/*      */         public Builder clear() {
/* 8390 */           super.clear();
/* 8391 */           this.value_ = ByteString.EMPTY;
/* 8392 */           this.hasValue = false;
/* 8393 */           this.flags_ = 0;
/* 8394 */           this.hasFlags = false;
/* 8395 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder clone() {
/* 8399 */           return create().mergeFrom(buildPartial());
/*      */         }
/*      */ 
/*      */         public Descriptors.Descriptor getDescriptorForType()
/*      */         {
/* 8404 */           return MemcacheServicePb.MemcacheGrabTailResponse.Item.getDescriptor();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheGrabTailResponse.Item getDefaultInstanceForType() {
/* 8408 */           return MemcacheServicePb.MemcacheGrabTailResponse.Item.getDefaultInstance();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheGrabTailResponse.Item build() {
/* 8412 */           MemcacheServicePb.MemcacheGrabTailResponse.Item result = buildPartial();
/* 8413 */           if (!result.isInitialized()) {
/* 8414 */             throw newUninitializedMessageException(result);
/*      */           }
/* 8416 */           return result;
/*      */         }
/*      */ 
/*      */         private MemcacheServicePb.MemcacheGrabTailResponse.Item buildParsed() throws InvalidProtocolBufferException
/*      */         {
/* 8421 */           MemcacheServicePb.MemcacheGrabTailResponse.Item result = buildPartial();
/* 8422 */           if (!result.isInitialized()) {
/* 8423 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */           }
/*      */ 
/* 8426 */           return result;
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheGrabTailResponse.Item buildPartial() {
/* 8430 */           MemcacheServicePb.MemcacheGrabTailResponse.Item result = new MemcacheServicePb.MemcacheGrabTailResponse.Item(this, null);
/* 8431 */           MemcacheServicePb.MemcacheGrabTailResponse.Item.access$18702(result, this.hasValue);
/* 8432 */           MemcacheServicePb.MemcacheGrabTailResponse.Item.access$18802(result, this.value_);
/* 8433 */           MemcacheServicePb.MemcacheGrabTailResponse.Item.access$18902(result, this.hasFlags);
/* 8434 */           MemcacheServicePb.MemcacheGrabTailResponse.Item.access$19002(result, this.flags_);
/* 8435 */           return result;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(Message other) {
/* 8439 */           if ((other instanceof MemcacheServicePb.MemcacheGrabTailResponse.Item)) {
/* 8440 */             return mergeFrom((MemcacheServicePb.MemcacheGrabTailResponse.Item)other);
/*      */           }
/* 8442 */           super.mergeFrom(other);
/* 8443 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(MemcacheServicePb.MemcacheGrabTailResponse.Item other)
/*      */         {
/* 8448 */           if (other == MemcacheServicePb.MemcacheGrabTailResponse.Item.getDefaultInstance()) return this;
/* 8449 */           if (other.hasValue()) {
/* 8450 */             setValue(other.getValue());
/*      */           }
/* 8452 */           if (other.hasFlags()) {
/* 8453 */             setFlags(other.getFlags());
/*      */           }
/* 8455 */           mergeUnknownFields(other.getUnknownFields());
/* 8456 */           return this;
/*      */         }
/*      */ 
/*      */         public final boolean isInitialized() {
/* 8460 */           return this.hasValue;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */           throws IOException
/*      */         {
/* 8468 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */           while (true)
/*      */           {
/* 8472 */             int tag = input.readTag();
/* 8473 */             switch (tag) {
/*      */             case 0:
/* 8475 */               setUnknownFields(unknownFields.build());
/* 8476 */               return this;
/*      */             default:
/* 8478 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */                 break;
/* 8480 */               setUnknownFields(unknownFields.build());
/* 8481 */               return this;
/*      */             case 18:
/* 8486 */               setValue(input.readBytes());
/* 8487 */               break;
/*      */             case 29:
/* 8490 */               setFlags(input.readFixed32());
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         public boolean hasValue()
/*      */         {
/* 8502 */           return this.hasValue;
/*      */         }
/*      */         public ByteString getValue() {
/* 8505 */           return this.value_;
/*      */         }
/*      */         public Builder setValue(ByteString value) {
/* 8508 */           if (value == null) {
/* 8509 */             throw new NullPointerException();
/*      */           }
/* 8511 */           this.hasValue = true;
/* 8512 */           this.value_ = value;
/* 8513 */           return this;
/*      */         }
/*      */         public Builder clearValue() {
/* 8516 */           this.hasValue = false;
/* 8517 */           this.value_ = MemcacheServicePb.MemcacheGrabTailResponse.Item.getDefaultInstance().getValue();
/* 8518 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasFlags()
/*      */         {
/* 8525 */           return this.hasFlags;
/*      */         }
/*      */         public int getFlags() {
/* 8528 */           return this.flags_;
/*      */         }
/*      */         public Builder setFlags(int value) {
/* 8531 */           this.hasFlags = true;
/* 8532 */           this.flags_ = value;
/* 8533 */           return this;
/*      */         }
/*      */         public Builder clearFlags() {
/* 8536 */           this.hasFlags = false;
/* 8537 */           this.flags_ = 0;
/* 8538 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheGrabTailRequest extends GeneratedMessage
/*      */   {
/* 8166 */     private static final MemcacheGrabTailRequest defaultInstance = new MemcacheGrabTailRequest(true);
/*      */     public static final int ITEM_COUNT_FIELD_NUMBER = 1;
/*      */     private boolean hasItemCount;
/*      */     private int itemCount_;
/*      */     public static final int NAME_SPACE_FIELD_NUMBER = 2;
/*      */     private boolean hasNameSpace;
/*      */     private String nameSpace_;
/* 7892 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheGrabTailRequest(Builder builder)
/*      */     {
/* 7826 */       super();
/*      */     }
/*      */     private MemcacheGrabTailRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest getDefaultInstance() {
/* 7832 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheGrabTailRequest getDefaultInstanceForType() {
/* 7836 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 7841 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 7846 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasItemCount()
/*      */     {
/* 7854 */       return this.hasItemCount;
/*      */     }
/*      */     public int getItemCount() {
/* 7857 */       return this.itemCount_;
/*      */     }
/*      */ 
/*      */     public boolean hasNameSpace()
/*      */     {
/* 7865 */       return this.hasNameSpace;
/*      */     }
/*      */     public String getNameSpace() {
/* 7868 */       return this.nameSpace_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 7872 */       this.itemCount_ = 0;
/* 7873 */       this.nameSpace_ = "";
/*      */     }
/*      */     public final boolean isInitialized() {
/* 7876 */       return this.hasItemCount;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/* 7882 */       getSerializedSize();
/* 7883 */       if (hasItemCount()) {
/* 7884 */         output.writeInt32(1, getItemCount());
/*      */       }
/* 7886 */       if (hasNameSpace()) {
/* 7887 */         output.writeString(2, getNameSpace());
/*      */       }
/* 7889 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 7894 */       int size = this.memoizedSerializedSize;
/* 7895 */       if (size != -1) return size;
/*      */ 
/* 7897 */       size = 0;
/* 7898 */       if (hasItemCount()) {
/* 7899 */         size += CodedOutputStream.computeInt32Size(1, getItemCount());
/*      */       }
/*      */ 
/* 7902 */       if (hasNameSpace()) {
/* 7903 */         size += CodedOutputStream.computeStringSize(2, getNameSpace());
/*      */       }
/*      */ 
/* 7906 */       size += getUnknownFields().getSerializedSize();
/* 7907 */       this.memoizedSerializedSize = size;
/* 7908 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 7913 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7919 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7925 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 7930 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7936 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 7941 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7947 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 7952 */       Builder builder = newBuilder();
/* 7953 */       if (builder.mergeDelimitedFrom(input)) {
/* 7954 */         return builder.buildParsed();
/*      */       }
/* 7956 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7963 */       Builder builder = newBuilder();
/* 7964 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 7965 */         return builder.buildParsed();
/*      */       }
/* 7967 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 7973 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGrabTailRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7979 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 7983 */       return Builder.access$17400(); } 
/* 7984 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheGrabTailRequest prototype) {
/* 7986 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 7988 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 8167 */       MemcacheServicePb.internalForceInit();
/* 8168 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasItemCount;
/*      */       private int itemCount_;
/*      */       private boolean hasNameSpace;
/* 8141 */       private String nameSpace_ = "";
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 7994 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 7999 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGrabTailRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 8007 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 8011 */         super.clear();
/* 8012 */         this.itemCount_ = 0;
/* 8013 */         this.hasItemCount = false;
/* 8014 */         this.nameSpace_ = "";
/* 8015 */         this.hasNameSpace = false;
/* 8016 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 8020 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 8025 */         return MemcacheServicePb.MemcacheGrabTailRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailRequest getDefaultInstanceForType() {
/* 8029 */         return MemcacheServicePb.MemcacheGrabTailRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailRequest build() {
/* 8033 */         MemcacheServicePb.MemcacheGrabTailRequest result = buildPartial();
/* 8034 */         if (!result.isInitialized()) {
/* 8035 */           throw newUninitializedMessageException(result);
/*      */         }
/* 8037 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheGrabTailRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 8042 */         MemcacheServicePb.MemcacheGrabTailRequest result = buildPartial();
/* 8043 */         if (!result.isInitialized()) {
/* 8044 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 8047 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGrabTailRequest buildPartial() {
/* 8051 */         MemcacheServicePb.MemcacheGrabTailRequest result = new MemcacheServicePb.MemcacheGrabTailRequest(this, null);
/* 8052 */         MemcacheServicePb.MemcacheGrabTailRequest.access$17602(result, this.hasItemCount);
/* 8053 */         MemcacheServicePb.MemcacheGrabTailRequest.access$17702(result, this.itemCount_);
/* 8054 */         MemcacheServicePb.MemcacheGrabTailRequest.access$17802(result, this.hasNameSpace);
/* 8055 */         MemcacheServicePb.MemcacheGrabTailRequest.access$17902(result, this.nameSpace_);
/* 8056 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 8060 */         if ((other instanceof MemcacheServicePb.MemcacheGrabTailRequest)) {
/* 8061 */           return mergeFrom((MemcacheServicePb.MemcacheGrabTailRequest)other);
/*      */         }
/* 8063 */         super.mergeFrom(other);
/* 8064 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheGrabTailRequest other)
/*      */       {
/* 8069 */         if (other == MemcacheServicePb.MemcacheGrabTailRequest.getDefaultInstance()) return this;
/* 8070 */         if (other.hasItemCount()) {
/* 8071 */           setItemCount(other.getItemCount());
/*      */         }
/* 8073 */         if (other.hasNameSpace()) {
/* 8074 */           setNameSpace(other.getNameSpace());
/*      */         }
/* 8076 */         mergeUnknownFields(other.getUnknownFields());
/* 8077 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 8081 */         return this.hasItemCount;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 8089 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 8093 */           int tag = input.readTag();
/* 8094 */           switch (tag) {
/*      */           case 0:
/* 8096 */             setUnknownFields(unknownFields.build());
/* 8097 */             return this;
/*      */           default:
/* 8099 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 8101 */             setUnknownFields(unknownFields.build());
/* 8102 */             return this;
/*      */           case 8:
/* 8107 */             setItemCount(input.readInt32());
/* 8108 */             break;
/*      */           case 18:
/* 8111 */             setNameSpace(input.readString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasItemCount()
/*      */       {
/* 8123 */         return this.hasItemCount;
/*      */       }
/*      */       public int getItemCount() {
/* 8126 */         return this.itemCount_;
/*      */       }
/*      */       public Builder setItemCount(int value) {
/* 8129 */         this.hasItemCount = true;
/* 8130 */         this.itemCount_ = value;
/* 8131 */         return this;
/*      */       }
/*      */       public Builder clearItemCount() {
/* 8134 */         this.hasItemCount = false;
/* 8135 */         this.itemCount_ = 0;
/* 8136 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasNameSpace()
/*      */       {
/* 8143 */         return this.hasNameSpace;
/*      */       }
/*      */       public String getNameSpace() {
/* 8146 */         return this.nameSpace_;
/*      */       }
/*      */       public Builder setNameSpace(String value) {
/* 8149 */         if (value == null) {
/* 8150 */           throw new NullPointerException();
/*      */         }
/* 8152 */         this.hasNameSpace = true;
/* 8153 */         this.nameSpace_ = value;
/* 8154 */         return this;
/*      */       }
/*      */       public Builder clearNameSpace() {
/* 8157 */         this.hasNameSpace = false;
/* 8158 */         this.nameSpace_ = MemcacheServicePb.MemcacheGrabTailRequest.getDefaultInstance().getNameSpace();
/* 8159 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheStatsResponse extends GeneratedMessage
/*      */   {
/* 7814 */     private static final MemcacheStatsResponse defaultInstance = new MemcacheStatsResponse(true);
/*      */     public static final int STATS_FIELD_NUMBER = 1;
/*      */     private boolean hasStats;
/*      */     private MemcacheServicePb.MergedNamespaceStats stats_;
/* 7551 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheStatsResponse(Builder builder)
/*      */     {
/* 7498 */       super();
/*      */     }
/*      */     private MemcacheStatsResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse getDefaultInstance() {
/* 7504 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheStatsResponse getDefaultInstanceForType() {
/* 7508 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 7513 */       return MemcacheServicePb.internal_static_apphosting_MemcacheStatsResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 7518 */       return MemcacheServicePb.internal_static_apphosting_MemcacheStatsResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasStats()
/*      */     {
/* 7526 */       return this.hasStats;
/*      */     }
/*      */     public MemcacheServicePb.MergedNamespaceStats getStats() {
/* 7529 */       return this.stats_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 7533 */       this.stats_ = MemcacheServicePb.MergedNamespaceStats.getDefaultInstance();
/*      */     }
/*      */ 
/*      */     public final boolean isInitialized() {
/* 7537 */       return (!hasStats()) || 
/* 7537 */         (getStats().isInitialized());
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/* 7544 */       getSerializedSize();
/* 7545 */       if (hasStats()) {
/* 7546 */         output.writeMessage(1, getStats());
/*      */       }
/* 7548 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 7553 */       int size = this.memoizedSerializedSize;
/* 7554 */       if (size != -1) return size;
/*      */ 
/* 7556 */       size = 0;
/* 7557 */       if (hasStats()) {
/* 7558 */         size += CodedOutputStream.computeMessageSize(1, getStats());
/*      */       }
/*      */ 
/* 7561 */       size += getUnknownFields().getSerializedSize();
/* 7562 */       this.memoizedSerializedSize = size;
/* 7563 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 7568 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7574 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7580 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 7585 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7591 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 7596 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7602 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 7607 */       Builder builder = newBuilder();
/* 7608 */       if (builder.mergeDelimitedFrom(input)) {
/* 7609 */         return builder.buildParsed();
/*      */       }
/* 7611 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7618 */       Builder builder = newBuilder();
/* 7619 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 7620 */         return builder.buildParsed();
/*      */       }
/* 7622 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 7628 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7634 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 7638 */       return Builder.access$16700(); } 
/* 7639 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheStatsResponse prototype) {
/* 7641 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 7643 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 7815 */       MemcacheServicePb.internalForceInit();
/* 7816 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasStats;
/* 7772 */       private MemcacheServicePb.MergedNamespaceStats stats_ = MemcacheServicePb.MergedNamespaceStats.getDefaultInstance();
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 7649 */         return MemcacheServicePb.internal_static_apphosting_MemcacheStatsResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 7654 */         return MemcacheServicePb.internal_static_apphosting_MemcacheStatsResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 7662 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 7666 */         super.clear();
/* 7667 */         this.stats_ = MemcacheServicePb.MergedNamespaceStats.getDefaultInstance();
/* 7668 */         this.hasStats = false;
/* 7669 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 7673 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 7678 */         return MemcacheServicePb.MemcacheStatsResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsResponse getDefaultInstanceForType() {
/* 7682 */         return MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsResponse build() {
/* 7686 */         MemcacheServicePb.MemcacheStatsResponse result = buildPartial();
/* 7687 */         if (!result.isInitialized()) {
/* 7688 */           throw newUninitializedMessageException(result);
/*      */         }
/* 7690 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheStatsResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 7695 */         MemcacheServicePb.MemcacheStatsResponse result = buildPartial();
/* 7696 */         if (!result.isInitialized()) {
/* 7697 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 7700 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsResponse buildPartial() {
/* 7704 */         MemcacheServicePb.MemcacheStatsResponse result = new MemcacheServicePb.MemcacheStatsResponse(this, null);
/* 7705 */         MemcacheServicePb.MemcacheStatsResponse.access$16902(result, this.hasStats);
/* 7706 */         MemcacheServicePb.MemcacheStatsResponse.access$17002(result, this.stats_);
/* 7707 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 7711 */         if ((other instanceof MemcacheServicePb.MemcacheStatsResponse)) {
/* 7712 */           return mergeFrom((MemcacheServicePb.MemcacheStatsResponse)other);
/*      */         }
/* 7714 */         super.mergeFrom(other);
/* 7715 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheStatsResponse other)
/*      */       {
/* 7720 */         if (other == MemcacheServicePb.MemcacheStatsResponse.getDefaultInstance()) return this;
/* 7721 */         if (other.hasStats()) {
/* 7722 */           mergeStats(other.getStats());
/*      */         }
/* 7724 */         mergeUnknownFields(other.getUnknownFields());
/* 7725 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized()
/*      */       {
/* 7730 */         return (!hasStats()) || 
/* 7730 */           (getStats().isInitialized());
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 7739 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 7743 */           int tag = input.readTag();
/* 7744 */           switch (tag) {
/*      */           case 0:
/* 7746 */             setUnknownFields(unknownFields.build());
/* 7747 */             return this;
/*      */           default:
/* 7749 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 7751 */             setUnknownFields(unknownFields.build());
/* 7752 */             return this;
/*      */           case 10:
/* 7757 */             MemcacheServicePb.MergedNamespaceStats.Builder subBuilder = MemcacheServicePb.MergedNamespaceStats.newBuilder();
/* 7758 */             if (hasStats()) {
/* 7759 */               subBuilder.mergeFrom(getStats());
/*      */             }
/* 7761 */             input.readMessage(subBuilder, extensionRegistry);
/* 7762 */             setStats(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasStats()
/*      */       {
/* 7774 */         return this.hasStats;
/*      */       }
/*      */       public MemcacheServicePb.MergedNamespaceStats getStats() {
/* 7777 */         return this.stats_;
/*      */       }
/*      */       public Builder setStats(MemcacheServicePb.MergedNamespaceStats value) {
/* 7780 */         if (value == null) {
/* 7781 */           throw new NullPointerException();
/*      */         }
/* 7783 */         this.hasStats = true;
/* 7784 */         this.stats_ = value;
/* 7785 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setStats(MemcacheServicePb.MergedNamespaceStats.Builder builderForValue) {
/* 7789 */         this.hasStats = true;
/* 7790 */         this.stats_ = builderForValue.build();
/* 7791 */         return this;
/*      */       }
/*      */       public Builder mergeStats(MemcacheServicePb.MergedNamespaceStats value) {
/* 7794 */         if ((this.hasStats) && (this.stats_ != MemcacheServicePb.MergedNamespaceStats.getDefaultInstance()))
/*      */         {
/* 7796 */           this.stats_ = MemcacheServicePb.MergedNamespaceStats.newBuilder(this.stats_).mergeFrom(value).buildPartial();
/*      */         }
/*      */         else {
/* 7799 */           this.stats_ = value;
/*      */         }
/* 7801 */         this.hasStats = true;
/* 7802 */         return this;
/*      */       }
/*      */       public Builder clearStats() {
/* 7805 */         this.hasStats = false;
/* 7806 */         this.stats_ = MemcacheServicePb.MergedNamespaceStats.getDefaultInstance();
/* 7807 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MergedNamespaceStats extends GeneratedMessage
/*      */   {
/* 7486 */     private static final MergedNamespaceStats defaultInstance = new MergedNamespaceStats(true);
/*      */     public static final int HITS_FIELD_NUMBER = 1;
/*      */     private boolean hasHits;
/*      */     private long hits_;
/*      */     public static final int MISSES_FIELD_NUMBER = 2;
/*      */     private boolean hasMisses;
/*      */     private long misses_;
/*      */     public static final int BYTE_HITS_FIELD_NUMBER = 3;
/*      */     private boolean hasByteHits;
/*      */     private long byteHits_;
/*      */     public static final int ITEMS_FIELD_NUMBER = 4;
/*      */     private boolean hasItems;
/*      */     private long items_;
/*      */     public static final int BYTES_FIELD_NUMBER = 5;
/*      */     private boolean hasBytes;
/*      */     private long bytes_;
/*      */     public static final int OLDEST_ITEM_AGE_FIELD_NUMBER = 6;
/*      */     private boolean hasOldestItemAge;
/*      */     private int oldestItemAge_;
/* 7070 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MergedNamespaceStats(Builder builder)
/*      */     {
/* 6939 */       super();
/*      */     }
/*      */     private MergedNamespaceStats(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats getDefaultInstance() {
/* 6945 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MergedNamespaceStats getDefaultInstanceForType() {
/* 6949 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 6954 */       return MemcacheServicePb.internal_static_apphosting_MergedNamespaceStats_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 6959 */       return MemcacheServicePb.internal_static_apphosting_MergedNamespaceStats_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasHits()
/*      */     {
/* 6967 */       return this.hasHits;
/*      */     }
/*      */     public long getHits() {
/* 6970 */       return this.hits_;
/*      */     }
/*      */ 
/*      */     public boolean hasMisses()
/*      */     {
/* 6978 */       return this.hasMisses;
/*      */     }
/*      */     public long getMisses() {
/* 6981 */       return this.misses_;
/*      */     }
/*      */ 
/*      */     public boolean hasByteHits()
/*      */     {
/* 6989 */       return this.hasByteHits;
/*      */     }
/*      */     public long getByteHits() {
/* 6992 */       return this.byteHits_;
/*      */     }
/*      */ 
/*      */     public boolean hasItems()
/*      */     {
/* 7000 */       return this.hasItems;
/*      */     }
/*      */     public long getItems() {
/* 7003 */       return this.items_;
/*      */     }
/*      */ 
/*      */     public boolean hasBytes()
/*      */     {
/* 7011 */       return this.hasBytes;
/*      */     }
/*      */     public long getBytes() {
/* 7014 */       return this.bytes_;
/*      */     }
/*      */ 
/*      */     public boolean hasOldestItemAge()
/*      */     {
/* 7022 */       return this.hasOldestItemAge;
/*      */     }
/*      */     public int getOldestItemAge() {
/* 7025 */       return this.oldestItemAge_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 7029 */       this.hits_ = 0L;
/* 7030 */       this.misses_ = 0L;
/* 7031 */       this.byteHits_ = 0L;
/* 7032 */       this.items_ = 0L;
/* 7033 */       this.bytes_ = 0L;
/* 7034 */       this.oldestItemAge_ = 0;
/*      */     }
/*      */     public final boolean isInitialized() {
/* 7037 */       if (!this.hasHits) return false;
/* 7038 */       if (!this.hasMisses) return false;
/* 7039 */       if (!this.hasByteHits) return false;
/* 7040 */       if (!this.hasItems) return false;
/* 7041 */       if (!this.hasBytes) return false;
/* 7042 */       return this.hasOldestItemAge;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/* 7048 */       getSerializedSize();
/* 7049 */       if (hasHits()) {
/* 7050 */         output.writeUInt64(1, getHits());
/*      */       }
/* 7052 */       if (hasMisses()) {
/* 7053 */         output.writeUInt64(2, getMisses());
/*      */       }
/* 7055 */       if (hasByteHits()) {
/* 7056 */         output.writeUInt64(3, getByteHits());
/*      */       }
/* 7058 */       if (hasItems()) {
/* 7059 */         output.writeUInt64(4, getItems());
/*      */       }
/* 7061 */       if (hasBytes()) {
/* 7062 */         output.writeUInt64(5, getBytes());
/*      */       }
/* 7064 */       if (hasOldestItemAge()) {
/* 7065 */         output.writeFixed32(6, getOldestItemAge());
/*      */       }
/* 7067 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 7072 */       int size = this.memoizedSerializedSize;
/* 7073 */       if (size != -1) return size;
/*      */ 
/* 7075 */       size = 0;
/* 7076 */       if (hasHits()) {
/* 7077 */         size += CodedOutputStream.computeUInt64Size(1, getHits());
/*      */       }
/*      */ 
/* 7080 */       if (hasMisses()) {
/* 7081 */         size += CodedOutputStream.computeUInt64Size(2, getMisses());
/*      */       }
/*      */ 
/* 7084 */       if (hasByteHits()) {
/* 7085 */         size += CodedOutputStream.computeUInt64Size(3, getByteHits());
/*      */       }
/*      */ 
/* 7088 */       if (hasItems()) {
/* 7089 */         size += CodedOutputStream.computeUInt64Size(4, getItems());
/*      */       }
/*      */ 
/* 7092 */       if (hasBytes()) {
/* 7093 */         size += CodedOutputStream.computeUInt64Size(5, getBytes());
/*      */       }
/*      */ 
/* 7096 */       if (hasOldestItemAge()) {
/* 7097 */         size += CodedOutputStream.computeFixed32Size(6, getOldestItemAge());
/*      */       }
/*      */ 
/* 7100 */       size += getUnknownFields().getSerializedSize();
/* 7101 */       this.memoizedSerializedSize = size;
/* 7102 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 7107 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7113 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7119 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 7124 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 7130 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(InputStream input) throws IOException
/*      */     {
/* 7135 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7141 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 7146 */       Builder builder = newBuilder();
/* 7147 */       if (builder.mergeDelimitedFrom(input)) {
/* 7148 */         return builder.buildParsed();
/*      */       }
/* 7150 */       return null;
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7157 */       Builder builder = newBuilder();
/* 7158 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 7159 */         return builder.buildParsed();
/*      */       }
/* 7161 */       return null;
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 7167 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MergedNamespaceStats parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 7173 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 7177 */       return Builder.access$15000(); } 
/* 7178 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MergedNamespaceStats prototype) {
/* 7180 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 7182 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 7487 */       MemcacheServicePb.internalForceInit();
/* 7488 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasHits;
/*      */       private long hits_;
/*      */       private boolean hasMisses;
/*      */       private long misses_;
/*      */       private boolean hasByteHits;
/*      */       private long byteHits_;
/*      */       private boolean hasItems;
/*      */       private long items_;
/*      */       private boolean hasBytes;
/*      */       private long bytes_;
/*      */       private boolean hasOldestItemAge;
/*      */       private int oldestItemAge_;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 7188 */         return MemcacheServicePb.internal_static_apphosting_MergedNamespaceStats_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 7193 */         return MemcacheServicePb.internal_static_apphosting_MergedNamespaceStats_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 7201 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 7205 */         super.clear();
/* 7206 */         this.hits_ = 0L;
/* 7207 */         this.hasHits = false;
/* 7208 */         this.misses_ = 0L;
/* 7209 */         this.hasMisses = false;
/* 7210 */         this.byteHits_ = 0L;
/* 7211 */         this.hasByteHits = false;
/* 7212 */         this.items_ = 0L;
/* 7213 */         this.hasItems = false;
/* 7214 */         this.bytes_ = 0L;
/* 7215 */         this.hasBytes = false;
/* 7216 */         this.oldestItemAge_ = 0;
/* 7217 */         this.hasOldestItemAge = false;
/* 7218 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 7222 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 7227 */         return MemcacheServicePb.MergedNamespaceStats.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MergedNamespaceStats getDefaultInstanceForType() {
/* 7231 */         return MemcacheServicePb.MergedNamespaceStats.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MergedNamespaceStats build() {
/* 7235 */         MemcacheServicePb.MergedNamespaceStats result = buildPartial();
/* 7236 */         if (!result.isInitialized()) {
/* 7237 */           throw newUninitializedMessageException(result);
/*      */         }
/* 7239 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MergedNamespaceStats buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 7244 */         MemcacheServicePb.MergedNamespaceStats result = buildPartial();
/* 7245 */         if (!result.isInitialized()) {
/* 7246 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 7249 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MergedNamespaceStats buildPartial() {
/* 7253 */         MemcacheServicePb.MergedNamespaceStats result = new MemcacheServicePb.MergedNamespaceStats(this, null);
/* 7254 */         MemcacheServicePb.MergedNamespaceStats.access$15202(result, this.hasHits);
/* 7255 */         MemcacheServicePb.MergedNamespaceStats.access$15302(result, this.hits_);
/* 7256 */         MemcacheServicePb.MergedNamespaceStats.access$15402(result, this.hasMisses);
/* 7257 */         MemcacheServicePb.MergedNamespaceStats.access$15502(result, this.misses_);
/* 7258 */         MemcacheServicePb.MergedNamespaceStats.access$15602(result, this.hasByteHits);
/* 7259 */         MemcacheServicePb.MergedNamespaceStats.access$15702(result, this.byteHits_);
/* 7260 */         MemcacheServicePb.MergedNamespaceStats.access$15802(result, this.hasItems);
/* 7261 */         MemcacheServicePb.MergedNamespaceStats.access$15902(result, this.items_);
/* 7262 */         MemcacheServicePb.MergedNamespaceStats.access$16002(result, this.hasBytes);
/* 7263 */         MemcacheServicePb.MergedNamespaceStats.access$16102(result, this.bytes_);
/* 7264 */         MemcacheServicePb.MergedNamespaceStats.access$16202(result, this.hasOldestItemAge);
/* 7265 */         MemcacheServicePb.MergedNamespaceStats.access$16302(result, this.oldestItemAge_);
/* 7266 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 7270 */         if ((other instanceof MemcacheServicePb.MergedNamespaceStats)) {
/* 7271 */           return mergeFrom((MemcacheServicePb.MergedNamespaceStats)other);
/*      */         }
/* 7273 */         super.mergeFrom(other);
/* 7274 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MergedNamespaceStats other)
/*      */       {
/* 7279 */         if (other == MemcacheServicePb.MergedNamespaceStats.getDefaultInstance()) return this;
/* 7280 */         if (other.hasHits()) {
/* 7281 */           setHits(other.getHits());
/*      */         }
/* 7283 */         if (other.hasMisses()) {
/* 7284 */           setMisses(other.getMisses());
/*      */         }
/* 7286 */         if (other.hasByteHits()) {
/* 7287 */           setByteHits(other.getByteHits());
/*      */         }
/* 7289 */         if (other.hasItems()) {
/* 7290 */           setItems(other.getItems());
/*      */         }
/* 7292 */         if (other.hasBytes()) {
/* 7293 */           setBytes(other.getBytes());
/*      */         }
/* 7295 */         if (other.hasOldestItemAge()) {
/* 7296 */           setOldestItemAge(other.getOldestItemAge());
/*      */         }
/* 7298 */         mergeUnknownFields(other.getUnknownFields());
/* 7299 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 7303 */         if (!this.hasHits) return false;
/* 7304 */         if (!this.hasMisses) return false;
/* 7305 */         if (!this.hasByteHits) return false;
/* 7306 */         if (!this.hasItems) return false;
/* 7307 */         if (!this.hasBytes) return false;
/* 7308 */         return this.hasOldestItemAge;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 7316 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 7320 */           int tag = input.readTag();
/* 7321 */           switch (tag) {
/*      */           case 0:
/* 7323 */             setUnknownFields(unknownFields.build());
/* 7324 */             return this;
/*      */           default:
/* 7326 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 7328 */             setUnknownFields(unknownFields.build());
/* 7329 */             return this;
/*      */           case 8:
/* 7334 */             setHits(input.readUInt64());
/* 7335 */             break;
/*      */           case 16:
/* 7338 */             setMisses(input.readUInt64());
/* 7339 */             break;
/*      */           case 24:
/* 7342 */             setByteHits(input.readUInt64());
/* 7343 */             break;
/*      */           case 32:
/* 7346 */             setItems(input.readUInt64());
/* 7347 */             break;
/*      */           case 40:
/* 7350 */             setBytes(input.readUInt64());
/* 7351 */             break;
/*      */           case 53:
/* 7354 */             setOldestItemAge(input.readFixed32());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasHits()
/*      */       {
/* 7366 */         return this.hasHits;
/*      */       }
/*      */       public long getHits() {
/* 7369 */         return this.hits_;
/*      */       }
/*      */       public Builder setHits(long value) {
/* 7372 */         this.hasHits = true;
/* 7373 */         this.hits_ = value;
/* 7374 */         return this;
/*      */       }
/*      */       public Builder clearHits() {
/* 7377 */         this.hasHits = false;
/* 7378 */         this.hits_ = 0L;
/* 7379 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasMisses()
/*      */       {
/* 7386 */         return this.hasMisses;
/*      */       }
/*      */       public long getMisses() {
/* 7389 */         return this.misses_;
/*      */       }
/*      */       public Builder setMisses(long value) {
/* 7392 */         this.hasMisses = true;
/* 7393 */         this.misses_ = value;
/* 7394 */         return this;
/*      */       }
/*      */       public Builder clearMisses() {
/* 7397 */         this.hasMisses = false;
/* 7398 */         this.misses_ = 0L;
/* 7399 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasByteHits()
/*      */       {
/* 7406 */         return this.hasByteHits;
/*      */       }
/*      */       public long getByteHits() {
/* 7409 */         return this.byteHits_;
/*      */       }
/*      */       public Builder setByteHits(long value) {
/* 7412 */         this.hasByteHits = true;
/* 7413 */         this.byteHits_ = value;
/* 7414 */         return this;
/*      */       }
/*      */       public Builder clearByteHits() {
/* 7417 */         this.hasByteHits = false;
/* 7418 */         this.byteHits_ = 0L;
/* 7419 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasItems()
/*      */       {
/* 7426 */         return this.hasItems;
/*      */       }
/*      */       public long getItems() {
/* 7429 */         return this.items_;
/*      */       }
/*      */       public Builder setItems(long value) {
/* 7432 */         this.hasItems = true;
/* 7433 */         this.items_ = value;
/* 7434 */         return this;
/*      */       }
/*      */       public Builder clearItems() {
/* 7437 */         this.hasItems = false;
/* 7438 */         this.items_ = 0L;
/* 7439 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasBytes()
/*      */       {
/* 7446 */         return this.hasBytes;
/*      */       }
/*      */       public long getBytes() {
/* 7449 */         return this.bytes_;
/*      */       }
/*      */       public Builder setBytes(long value) {
/* 7452 */         this.hasBytes = true;
/* 7453 */         this.bytes_ = value;
/* 7454 */         return this;
/*      */       }
/*      */       public Builder clearBytes() {
/* 7457 */         this.hasBytes = false;
/* 7458 */         this.bytes_ = 0L;
/* 7459 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasOldestItemAge()
/*      */       {
/* 7466 */         return this.hasOldestItemAge;
/*      */       }
/*      */       public int getOldestItemAge() {
/* 7469 */         return this.oldestItemAge_;
/*      */       }
/*      */       public Builder setOldestItemAge(int value) {
/* 7472 */         this.hasOldestItemAge = true;
/* 7473 */         this.oldestItemAge_ = value;
/* 7474 */         return this;
/*      */       }
/*      */       public Builder clearOldestItemAge() {
/* 7477 */         this.hasOldestItemAge = false;
/* 7478 */         this.oldestItemAge_ = 0;
/* 7479 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheStatsRequest extends GeneratedMessage
/*      */   {
/* 6927 */     private static final MemcacheStatsRequest defaultInstance = new MemcacheStatsRequest(true);
/*      */ 
/* 6727 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheStatsRequest(Builder builder)
/*      */     {
/* 6692 */       super();
/*      */     }
/*      */     private MemcacheStatsRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest getDefaultInstance() {
/* 6698 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheStatsRequest getDefaultInstanceForType() {
/* 6702 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 6707 */       return MemcacheServicePb.internal_static_apphosting_MemcacheStatsRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 6712 */       return MemcacheServicePb.internal_static_apphosting_MemcacheStatsRequest_fieldAccessorTable;
/*      */     }
/*      */     private void initFields() {
/*      */     }
/*      */ 
/*      */     public final boolean isInitialized() {
/* 6718 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 6723 */       getSerializedSize();
/* 6724 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 6729 */       int size = this.memoizedSerializedSize;
/* 6730 */       if (size != -1) return size;
/*      */ 
/* 6732 */       size = 0;
/* 6733 */       size += getUnknownFields().getSerializedSize();
/* 6734 */       this.memoizedSerializedSize = size;
/* 6735 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 6740 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6746 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6752 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 6757 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6763 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 6768 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6774 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 6779 */       Builder builder = newBuilder();
/* 6780 */       if (builder.mergeDelimitedFrom(input)) {
/* 6781 */         return builder.buildParsed();
/*      */       }
/* 6783 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6790 */       Builder builder = newBuilder();
/* 6791 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 6792 */         return builder.buildParsed();
/*      */       }
/* 6794 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 6800 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheStatsRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6806 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 6810 */       return Builder.access$14500(); } 
/* 6811 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheStatsRequest prototype) {
/* 6813 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 6815 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6928 */       MemcacheServicePb.internalForceInit();
/* 6929 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 6821 */         return MemcacheServicePb.internal_static_apphosting_MemcacheStatsRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 6826 */         return MemcacheServicePb.internal_static_apphosting_MemcacheStatsRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 6834 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 6838 */         super.clear();
/* 6839 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 6843 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 6848 */         return MemcacheServicePb.MemcacheStatsRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsRequest getDefaultInstanceForType() {
/* 6852 */         return MemcacheServicePb.MemcacheStatsRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsRequest build() {
/* 6856 */         MemcacheServicePb.MemcacheStatsRequest result = buildPartial();
/* 6857 */         if (!result.isInitialized()) {
/* 6858 */           throw newUninitializedMessageException(result);
/*      */         }
/* 6860 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheStatsRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 6865 */         MemcacheServicePb.MemcacheStatsRequest result = buildPartial();
/* 6866 */         if (!result.isInitialized()) {
/* 6867 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 6870 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheStatsRequest buildPartial() {
/* 6874 */         MemcacheServicePb.MemcacheStatsRequest result = new MemcacheServicePb.MemcacheStatsRequest(this, null);
/* 6875 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 6879 */         if ((other instanceof MemcacheServicePb.MemcacheStatsRequest)) {
/* 6880 */           return mergeFrom((MemcacheServicePb.MemcacheStatsRequest)other);
/*      */         }
/* 6882 */         super.mergeFrom(other);
/* 6883 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheStatsRequest other)
/*      */       {
/* 6888 */         if (other == MemcacheServicePb.MemcacheStatsRequest.getDefaultInstance()) return this;
/* 6889 */         mergeUnknownFields(other.getUnknownFields());
/* 6890 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 6894 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 6901 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 6905 */           int tag = input.readTag();
/* 6906 */           switch (tag) {
/*      */           case 0:
/* 6908 */             setUnknownFields(unknownFields.build());
/* 6909 */             return this;
/*      */           }
/* 6911 */           if (!parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */           {
/* 6913 */             setUnknownFields(unknownFields.build());
/* 6914 */             return this;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheFlushResponse extends GeneratedMessage
/*      */   {
/* 6680 */     private static final MemcacheFlushResponse defaultInstance = new MemcacheFlushResponse(true);
/*      */ 
/* 6480 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheFlushResponse(Builder builder)
/*      */     {
/* 6445 */       super();
/*      */     }
/*      */     private MemcacheFlushResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse getDefaultInstance() {
/* 6451 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheFlushResponse getDefaultInstanceForType() {
/* 6455 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 6460 */       return MemcacheServicePb.internal_static_apphosting_MemcacheFlushResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 6465 */       return MemcacheServicePb.internal_static_apphosting_MemcacheFlushResponse_fieldAccessorTable;
/*      */     }
/*      */     private void initFields() {
/*      */     }
/*      */ 
/*      */     public final boolean isInitialized() {
/* 6471 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 6476 */       getSerializedSize();
/* 6477 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 6482 */       int size = this.memoizedSerializedSize;
/* 6483 */       if (size != -1) return size;
/*      */ 
/* 6485 */       size = 0;
/* 6486 */       size += getUnknownFields().getSerializedSize();
/* 6487 */       this.memoizedSerializedSize = size;
/* 6488 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 6493 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6499 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6505 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 6510 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6516 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 6521 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6527 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 6532 */       Builder builder = newBuilder();
/* 6533 */       if (builder.mergeDelimitedFrom(input)) {
/* 6534 */         return builder.buildParsed();
/*      */       }
/* 6536 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6543 */       Builder builder = newBuilder();
/* 6544 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 6545 */         return builder.buildParsed();
/*      */       }
/* 6547 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 6553 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6559 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 6563 */       return Builder.access$14000(); } 
/* 6564 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheFlushResponse prototype) {
/* 6566 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 6568 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6681 */       MemcacheServicePb.internalForceInit();
/* 6682 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 6574 */         return MemcacheServicePb.internal_static_apphosting_MemcacheFlushResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 6579 */         return MemcacheServicePb.internal_static_apphosting_MemcacheFlushResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 6587 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 6591 */         super.clear();
/* 6592 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 6596 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 6601 */         return MemcacheServicePb.MemcacheFlushResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushResponse getDefaultInstanceForType() {
/* 6605 */         return MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushResponse build() {
/* 6609 */         MemcacheServicePb.MemcacheFlushResponse result = buildPartial();
/* 6610 */         if (!result.isInitialized()) {
/* 6611 */           throw newUninitializedMessageException(result);
/*      */         }
/* 6613 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheFlushResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 6618 */         MemcacheServicePb.MemcacheFlushResponse result = buildPartial();
/* 6619 */         if (!result.isInitialized()) {
/* 6620 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 6623 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushResponse buildPartial() {
/* 6627 */         MemcacheServicePb.MemcacheFlushResponse result = new MemcacheServicePb.MemcacheFlushResponse(this, null);
/* 6628 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 6632 */         if ((other instanceof MemcacheServicePb.MemcacheFlushResponse)) {
/* 6633 */           return mergeFrom((MemcacheServicePb.MemcacheFlushResponse)other);
/*      */         }
/* 6635 */         super.mergeFrom(other);
/* 6636 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheFlushResponse other)
/*      */       {
/* 6641 */         if (other == MemcacheServicePb.MemcacheFlushResponse.getDefaultInstance()) return this;
/* 6642 */         mergeUnknownFields(other.getUnknownFields());
/* 6643 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 6647 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 6654 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 6658 */           int tag = input.readTag();
/* 6659 */           switch (tag) {
/*      */           case 0:
/* 6661 */             setUnknownFields(unknownFields.build());
/* 6662 */             return this;
/*      */           }
/* 6664 */           if (!parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */           {
/* 6666 */             setUnknownFields(unknownFields.build());
/* 6667 */             return this;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheFlushRequest extends GeneratedMessage
/*      */   {
/* 6433 */     private static final MemcacheFlushRequest defaultInstance = new MemcacheFlushRequest(true);
/*      */ 
/* 6233 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheFlushRequest(Builder builder)
/*      */     {
/* 6198 */       super();
/*      */     }
/*      */     private MemcacheFlushRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest getDefaultInstance() {
/* 6204 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheFlushRequest getDefaultInstanceForType() {
/* 6208 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 6213 */       return MemcacheServicePb.internal_static_apphosting_MemcacheFlushRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 6218 */       return MemcacheServicePb.internal_static_apphosting_MemcacheFlushRequest_fieldAccessorTable;
/*      */     }
/*      */     private void initFields() {
/*      */     }
/*      */ 
/*      */     public final boolean isInitialized() {
/* 6224 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 6229 */       getSerializedSize();
/* 6230 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 6235 */       int size = this.memoizedSerializedSize;
/* 6236 */       if (size != -1) return size;
/*      */ 
/* 6238 */       size = 0;
/* 6239 */       size += getUnknownFields().getSerializedSize();
/* 6240 */       this.memoizedSerializedSize = size;
/* 6241 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 6246 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6252 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6258 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 6263 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 6269 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 6274 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6280 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 6285 */       Builder builder = newBuilder();
/* 6286 */       if (builder.mergeDelimitedFrom(input)) {
/* 6287 */         return builder.buildParsed();
/*      */       }
/* 6289 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6296 */       Builder builder = newBuilder();
/* 6297 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 6298 */         return builder.buildParsed();
/*      */       }
/* 6300 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 6306 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheFlushRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 6312 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 6316 */       return Builder.access$13500(); } 
/* 6317 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheFlushRequest prototype) {
/* 6319 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 6321 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6434 */       MemcacheServicePb.internalForceInit();
/* 6435 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 6327 */         return MemcacheServicePb.internal_static_apphosting_MemcacheFlushRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 6332 */         return MemcacheServicePb.internal_static_apphosting_MemcacheFlushRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 6340 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 6344 */         super.clear();
/* 6345 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 6349 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 6354 */         return MemcacheServicePb.MemcacheFlushRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushRequest getDefaultInstanceForType() {
/* 6358 */         return MemcacheServicePb.MemcacheFlushRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushRequest build() {
/* 6362 */         MemcacheServicePb.MemcacheFlushRequest result = buildPartial();
/* 6363 */         if (!result.isInitialized()) {
/* 6364 */           throw newUninitializedMessageException(result);
/*      */         }
/* 6366 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheFlushRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 6371 */         MemcacheServicePb.MemcacheFlushRequest result = buildPartial();
/* 6372 */         if (!result.isInitialized()) {
/* 6373 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 6376 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheFlushRequest buildPartial() {
/* 6380 */         MemcacheServicePb.MemcacheFlushRequest result = new MemcacheServicePb.MemcacheFlushRequest(this, null);
/* 6381 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 6385 */         if ((other instanceof MemcacheServicePb.MemcacheFlushRequest)) {
/* 6386 */           return mergeFrom((MemcacheServicePb.MemcacheFlushRequest)other);
/*      */         }
/* 6388 */         super.mergeFrom(other);
/* 6389 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheFlushRequest other)
/*      */       {
/* 6394 */         if (other == MemcacheServicePb.MemcacheFlushRequest.getDefaultInstance()) return this;
/* 6395 */         mergeUnknownFields(other.getUnknownFields());
/* 6396 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 6400 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 6407 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 6411 */           int tag = input.readTag();
/* 6412 */           switch (tag) {
/*      */           case 0:
/* 6414 */             setUnknownFields(unknownFields.build());
/* 6415 */             return this;
/*      */           }
/* 6417 */           if (!parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */           {
/* 6419 */             setUnknownFields(unknownFields.build());
/* 6420 */             return this;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheBatchIncrementResponse extends GeneratedMessage
/*      */   {
/* 6186 */     private static final MemcacheBatchIncrementResponse defaultInstance = new MemcacheBatchIncrementResponse(true);
/*      */     public static final int ITEM_FIELD_NUMBER = 1;
/*      */     private List<MemcacheServicePb.MemcacheIncrementResponse> item_;
/* 5900 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheBatchIncrementResponse(Builder builder)
/*      */     {
/* 5848 */       super();
/*      */     }
/*      */     private MemcacheBatchIncrementResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse getDefaultInstance() {
/* 5854 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheBatchIncrementResponse getDefaultInstanceForType() {
/* 5858 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 5863 */       return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 5868 */       return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<MemcacheServicePb.MemcacheIncrementResponse> getItemList()
/*      */     {
/* 5875 */       return this.item_;
/*      */     }
/*      */     public int getItemCount() {
/* 5878 */       return this.item_.size();
/*      */     }
/*      */     public MemcacheServicePb.MemcacheIncrementResponse getItem(int index) {
/* 5881 */       return (MemcacheServicePb.MemcacheIncrementResponse)this.item_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 5885 */       this.item_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 5888 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 5893 */       getSerializedSize();
/* 5894 */       for (MemcacheServicePb.MemcacheIncrementResponse element : getItemList()) {
/* 5895 */         output.writeMessage(1, element);
/*      */       }
/* 5897 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 5902 */       int size = this.memoizedSerializedSize;
/* 5903 */       if (size != -1) return size;
/*      */ 
/* 5905 */       size = 0;
/* 5906 */       for (MemcacheServicePb.MemcacheIncrementResponse element : getItemList()) {
/* 5907 */         size += CodedOutputStream.computeMessageSize(1, element);
/*      */       }
/*      */ 
/* 5910 */       size += getUnknownFields().getSerializedSize();
/* 5911 */       this.memoizedSerializedSize = size;
/* 5912 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 5917 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5923 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5929 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 5934 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5940 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 5945 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5951 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 5956 */       Builder builder = newBuilder();
/* 5957 */       if (builder.mergeDelimitedFrom(input)) {
/* 5958 */         return builder.buildParsed();
/*      */       }
/* 5960 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5967 */       Builder builder = newBuilder();
/* 5968 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 5969 */         return builder.buildParsed();
/*      */       }
/* 5971 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 5977 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5983 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 5987 */       return Builder.access$12900(); } 
/* 5988 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheBatchIncrementResponse prototype) {
/* 5990 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 5992 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 6187 */       MemcacheServicePb.internalForceInit();
/* 6188 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 6123 */       private List<MemcacheServicePb.MemcacheIncrementResponse> item_ = Collections.emptyList();
/*      */       private boolean isItemMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 5998 */         return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 6003 */         return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 6011 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 6015 */         super.clear();
/* 6016 */         this.item_ = Collections.emptyList();
/* 6017 */         this.isItemMutable = false;
/* 6018 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 6022 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 6027 */         return MemcacheServicePb.MemcacheBatchIncrementResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementResponse getDefaultInstanceForType() {
/* 6031 */         return MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementResponse build() {
/* 6035 */         MemcacheServicePb.MemcacheBatchIncrementResponse result = buildPartial();
/* 6036 */         if (!result.isInitialized()) {
/* 6037 */           throw newUninitializedMessageException(result);
/*      */         }
/* 6039 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheBatchIncrementResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 6044 */         MemcacheServicePb.MemcacheBatchIncrementResponse result = buildPartial();
/* 6045 */         if (!result.isInitialized()) {
/* 6046 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 6049 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementResponse buildPartial() {
/* 6053 */         MemcacheServicePb.MemcacheBatchIncrementResponse result = new MemcacheServicePb.MemcacheBatchIncrementResponse(this, null);
/* 6054 */         if (this.isItemMutable) {
/* 6055 */           this.item_ = Collections.unmodifiableList(this.item_);
/* 6056 */           this.isItemMutable = false;
/*      */         }
/* 6058 */         MemcacheServicePb.MemcacheBatchIncrementResponse.access$13102(result, this.item_);
/* 6059 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 6063 */         if ((other instanceof MemcacheServicePb.MemcacheBatchIncrementResponse)) {
/* 6064 */           return mergeFrom((MemcacheServicePb.MemcacheBatchIncrementResponse)other);
/*      */         }
/* 6066 */         super.mergeFrom(other);
/* 6067 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheBatchIncrementResponse other)
/*      */       {
/* 6072 */         if (other == MemcacheServicePb.MemcacheBatchIncrementResponse.getDefaultInstance()) return this;
/* 6073 */         if (!other.item_.isEmpty()) {
/* 6074 */           if (this.item_.isEmpty()) {
/* 6075 */             this.item_ = other.item_;
/* 6076 */             this.isItemMutable = false;
/*      */           } else {
/* 6078 */             ensureItemIsMutable();
/* 6079 */             this.item_.addAll(other.item_);
/*      */           }
/*      */         }
/* 6082 */         mergeUnknownFields(other.getUnknownFields());
/* 6083 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 6087 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 6094 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 6098 */           int tag = input.readTag();
/* 6099 */           switch (tag) {
/*      */           case 0:
/* 6101 */             setUnknownFields(unknownFields.build());
/* 6102 */             return this;
/*      */           default:
/* 6104 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 6106 */             setUnknownFields(unknownFields.build());
/* 6107 */             return this;
/*      */           case 10:
/* 6112 */             MemcacheServicePb.MemcacheIncrementResponse.Builder subBuilder = MemcacheServicePb.MemcacheIncrementResponse.newBuilder();
/* 6113 */             input.readMessage(subBuilder, extensionRegistry);
/* 6114 */             addItem(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureItemIsMutable()
/*      */       {
/* 6127 */         if (!this.isItemMutable) {
/* 6128 */           this.item_ = new ArrayList(this.item_);
/* 6129 */           this.isItemMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheIncrementResponse> getItemList() {
/* 6133 */         return Collections.unmodifiableList(this.item_);
/*      */       }
/*      */       public int getItemCount() {
/* 6136 */         return this.item_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheIncrementResponse getItem(int index) {
/* 6139 */         return (MemcacheServicePb.MemcacheIncrementResponse)this.item_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheIncrementResponse value) {
/* 6143 */         if (value == null) {
/* 6144 */           throw new NullPointerException();
/*      */         }
/* 6146 */         ensureItemIsMutable();
/* 6147 */         this.item_.set(index, value);
/* 6148 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheIncrementResponse.Builder builderForValue) {
/* 6152 */         ensureItemIsMutable();
/* 6153 */         this.item_.set(index, builderForValue.build());
/* 6154 */         return this;
/*      */       }
/*      */       public Builder addItem(MemcacheServicePb.MemcacheIncrementResponse value) {
/* 6157 */         if (value == null) {
/* 6158 */           throw new NullPointerException();
/*      */         }
/* 6160 */         ensureItemIsMutable();
/* 6161 */         this.item_.add(value);
/* 6162 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addItem(MemcacheServicePb.MemcacheIncrementResponse.Builder builderForValue) {
/* 6166 */         ensureItemIsMutable();
/* 6167 */         this.item_.add(builderForValue.build());
/* 6168 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllItem(Iterable<? extends MemcacheServicePb.MemcacheIncrementResponse> values) {
/* 6172 */         ensureItemIsMutable();
/* 6173 */         GeneratedMessage.Builder.addAll(values, this.item_);
/* 6174 */         return this;
/*      */       }
/*      */       public Builder clearItem() {
/* 6177 */         this.item_ = Collections.emptyList();
/* 6178 */         this.isItemMutable = false;
/* 6179 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheBatchIncrementRequest extends GeneratedMessage
/*      */   {
/* 5836 */     private static final MemcacheBatchIncrementRequest defaultInstance = new MemcacheBatchIncrementRequest(true);
/*      */     public static final int NAME_SPACE_FIELD_NUMBER = 1;
/*      */     private boolean hasNameSpace;
/*      */     private String nameSpace_;
/*      */     public static final int ITEM_FIELD_NUMBER = 2;
/*      */     private List<MemcacheServicePb.MemcacheIncrementRequest> item_;
/* 5509 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheBatchIncrementRequest(Builder builder)
/*      */     {
/* 5439 */       super();
/*      */     }
/*      */     private MemcacheBatchIncrementRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest getDefaultInstance() {
/* 5445 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheBatchIncrementRequest getDefaultInstanceForType() {
/* 5449 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 5454 */       return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 5459 */       return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasNameSpace()
/*      */     {
/* 5467 */       return this.hasNameSpace;
/*      */     }
/*      */     public String getNameSpace() {
/* 5470 */       return this.nameSpace_;
/*      */     }
/*      */ 
/*      */     public List<MemcacheServicePb.MemcacheIncrementRequest> getItemList()
/*      */     {
/* 5477 */       return this.item_;
/*      */     }
/*      */     public int getItemCount() {
/* 5480 */       return this.item_.size();
/*      */     }
/*      */     public MemcacheServicePb.MemcacheIncrementRequest getItem(int index) {
/* 5483 */       return (MemcacheServicePb.MemcacheIncrementRequest)this.item_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 5487 */       this.nameSpace_ = "";
/* 5488 */       this.item_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 5491 */       for (MemcacheServicePb.MemcacheIncrementRequest element : getItemList()) {
/* 5492 */         if (!element.isInitialized()) return false;
/*      */       }
/* 5494 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 5499 */       getSerializedSize();
/* 5500 */       if (hasNameSpace()) {
/* 5501 */         output.writeString(1, getNameSpace());
/*      */       }
/* 5503 */       for (MemcacheServicePb.MemcacheIncrementRequest element : getItemList()) {
/* 5504 */         output.writeMessage(2, element);
/*      */       }
/* 5506 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 5511 */       int size = this.memoizedSerializedSize;
/* 5512 */       if (size != -1) return size;
/*      */ 
/* 5514 */       size = 0;
/* 5515 */       if (hasNameSpace()) {
/* 5516 */         size += CodedOutputStream.computeStringSize(1, getNameSpace());
/*      */       }
/*      */ 
/* 5519 */       for (MemcacheServicePb.MemcacheIncrementRequest element : getItemList()) {
/* 5520 */         size += CodedOutputStream.computeMessageSize(2, element);
/*      */       }
/*      */ 
/* 5523 */       size += getUnknownFields().getSerializedSize();
/* 5524 */       this.memoizedSerializedSize = size;
/* 5525 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 5530 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5536 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5542 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 5547 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5553 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 5558 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5564 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 5569 */       Builder builder = newBuilder();
/* 5570 */       if (builder.mergeDelimitedFrom(input)) {
/* 5571 */         return builder.buildParsed();
/*      */       }
/* 5573 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5580 */       Builder builder = newBuilder();
/* 5581 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 5582 */         return builder.buildParsed();
/*      */       }
/* 5584 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 5590 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheBatchIncrementRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5596 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 5600 */       return Builder.access$12100(); } 
/* 5601 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheBatchIncrementRequest prototype) {
/* 5603 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 5605 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 5837 */       MemcacheServicePb.internalForceInit();
/* 5838 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasNameSpace;
/* 5751 */       private String nameSpace_ = "";
/*      */ 
/* 5773 */       private List<MemcacheServicePb.MemcacheIncrementRequest> item_ = Collections.emptyList();
/*      */       private boolean isItemMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 5611 */         return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 5616 */         return MemcacheServicePb.internal_static_apphosting_MemcacheBatchIncrementRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 5624 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 5628 */         super.clear();
/* 5629 */         this.nameSpace_ = "";
/* 5630 */         this.hasNameSpace = false;
/* 5631 */         this.item_ = Collections.emptyList();
/* 5632 */         this.isItemMutable = false;
/* 5633 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 5637 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 5642 */         return MemcacheServicePb.MemcacheBatchIncrementRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementRequest getDefaultInstanceForType() {
/* 5646 */         return MemcacheServicePb.MemcacheBatchIncrementRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementRequest build() {
/* 5650 */         MemcacheServicePb.MemcacheBatchIncrementRequest result = buildPartial();
/* 5651 */         if (!result.isInitialized()) {
/* 5652 */           throw newUninitializedMessageException(result);
/*      */         }
/* 5654 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheBatchIncrementRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 5659 */         MemcacheServicePb.MemcacheBatchIncrementRequest result = buildPartial();
/* 5660 */         if (!result.isInitialized()) {
/* 5661 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 5664 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheBatchIncrementRequest buildPartial() {
/* 5668 */         MemcacheServicePb.MemcacheBatchIncrementRequest result = new MemcacheServicePb.MemcacheBatchIncrementRequest(this, null);
/* 5669 */         MemcacheServicePb.MemcacheBatchIncrementRequest.access$12302(result, this.hasNameSpace);
/* 5670 */         MemcacheServicePb.MemcacheBatchIncrementRequest.access$12402(result, this.nameSpace_);
/* 5671 */         if (this.isItemMutable) {
/* 5672 */           this.item_ = Collections.unmodifiableList(this.item_);
/* 5673 */           this.isItemMutable = false;
/*      */         }
/* 5675 */         MemcacheServicePb.MemcacheBatchIncrementRequest.access$12502(result, this.item_);
/* 5676 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 5680 */         if ((other instanceof MemcacheServicePb.MemcacheBatchIncrementRequest)) {
/* 5681 */           return mergeFrom((MemcacheServicePb.MemcacheBatchIncrementRequest)other);
/*      */         }
/* 5683 */         super.mergeFrom(other);
/* 5684 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheBatchIncrementRequest other)
/*      */       {
/* 5689 */         if (other == MemcacheServicePb.MemcacheBatchIncrementRequest.getDefaultInstance()) return this;
/* 5690 */         if (other.hasNameSpace()) {
/* 5691 */           setNameSpace(other.getNameSpace());
/*      */         }
/* 5693 */         if (!other.item_.isEmpty()) {
/* 5694 */           if (this.item_.isEmpty()) {
/* 5695 */             this.item_ = other.item_;
/* 5696 */             this.isItemMutable = false;
/*      */           } else {
/* 5698 */             ensureItemIsMutable();
/* 5699 */             this.item_.addAll(other.item_);
/*      */           }
/*      */         }
/* 5702 */         mergeUnknownFields(other.getUnknownFields());
/* 5703 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 5707 */         for (MemcacheServicePb.MemcacheIncrementRequest element : getItemList()) {
/* 5708 */           if (!element.isInitialized()) return false;
/*      */         }
/* 5710 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 5717 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 5721 */           int tag = input.readTag();
/* 5722 */           switch (tag) {
/*      */           case 0:
/* 5724 */             setUnknownFields(unknownFields.build());
/* 5725 */             return this;
/*      */           default:
/* 5727 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 5729 */             setUnknownFields(unknownFields.build());
/* 5730 */             return this;
/*      */           case 10:
/* 5735 */             setNameSpace(input.readString());
/* 5736 */             break;
/*      */           case 18:
/* 5739 */             MemcacheServicePb.MemcacheIncrementRequest.Builder subBuilder = MemcacheServicePb.MemcacheIncrementRequest.newBuilder();
/* 5740 */             input.readMessage(subBuilder, extensionRegistry);
/* 5741 */             addItem(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasNameSpace()
/*      */       {
/* 5753 */         return this.hasNameSpace;
/*      */       }
/*      */       public String getNameSpace() {
/* 5756 */         return this.nameSpace_;
/*      */       }
/*      */       public Builder setNameSpace(String value) {
/* 5759 */         if (value == null) {
/* 5760 */           throw new NullPointerException();
/*      */         }
/* 5762 */         this.hasNameSpace = true;
/* 5763 */         this.nameSpace_ = value;
/* 5764 */         return this;
/*      */       }
/*      */       public Builder clearNameSpace() {
/* 5767 */         this.hasNameSpace = false;
/* 5768 */         this.nameSpace_ = MemcacheServicePb.MemcacheBatchIncrementRequest.getDefaultInstance().getNameSpace();
/* 5769 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureItemIsMutable()
/*      */       {
/* 5777 */         if (!this.isItemMutable) {
/* 5778 */           this.item_ = new ArrayList(this.item_);
/* 5779 */           this.isItemMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheIncrementRequest> getItemList() {
/* 5783 */         return Collections.unmodifiableList(this.item_);
/*      */       }
/*      */       public int getItemCount() {
/* 5786 */         return this.item_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheIncrementRequest getItem(int index) {
/* 5789 */         return (MemcacheServicePb.MemcacheIncrementRequest)this.item_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheIncrementRequest value) {
/* 5793 */         if (value == null) {
/* 5794 */           throw new NullPointerException();
/*      */         }
/* 5796 */         ensureItemIsMutable();
/* 5797 */         this.item_.set(index, value);
/* 5798 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheIncrementRequest.Builder builderForValue) {
/* 5802 */         ensureItemIsMutable();
/* 5803 */         this.item_.set(index, builderForValue.build());
/* 5804 */         return this;
/*      */       }
/*      */       public Builder addItem(MemcacheServicePb.MemcacheIncrementRequest value) {
/* 5807 */         if (value == null) {
/* 5808 */           throw new NullPointerException();
/*      */         }
/* 5810 */         ensureItemIsMutable();
/* 5811 */         this.item_.add(value);
/* 5812 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addItem(MemcacheServicePb.MemcacheIncrementRequest.Builder builderForValue) {
/* 5816 */         ensureItemIsMutable();
/* 5817 */         this.item_.add(builderForValue.build());
/* 5818 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllItem(Iterable<? extends MemcacheServicePb.MemcacheIncrementRequest> values) {
/* 5822 */         ensureItemIsMutable();
/* 5823 */         GeneratedMessage.Builder.addAll(values, this.item_);
/* 5824 */         return this;
/*      */       }
/*      */       public Builder clearItem() {
/* 5827 */         this.item_ = Collections.emptyList();
/* 5828 */         this.isItemMutable = false;
/* 5829 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheIncrementResponse extends GeneratedMessage
/*      */   {
/* 5427 */     private static final MemcacheIncrementResponse defaultInstance = new MemcacheIncrementResponse(true);
/*      */     public static final int NEW_VALUE_FIELD_NUMBER = 1;
/*      */     private boolean hasNewValue;
/*      */     private long newValue_;
/*      */     public static final int INCREMENT_STATUS_FIELD_NUMBER = 2;
/*      */     private boolean hasIncrementStatus;
/*      */     private IncrementStatusCode incrementStatus_;
/* 5148 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheIncrementResponse(Builder builder)
/*      */     {
/* 5010 */       super();
/*      */     }
/*      */     private MemcacheIncrementResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse getDefaultInstance() {
/* 5016 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheIncrementResponse getDefaultInstanceForType() {
/* 5020 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 5025 */       return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 5030 */       return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasNewValue()
/*      */     {
/* 5111 */       return this.hasNewValue;
/*      */     }
/*      */     public long getNewValue() {
/* 5114 */       return this.newValue_;
/*      */     }
/*      */ 
/*      */     public boolean hasIncrementStatus()
/*      */     {
/* 5122 */       return this.hasIncrementStatus;
/*      */     }
/*      */     public IncrementStatusCode getIncrementStatus() {
/* 5125 */       return this.incrementStatus_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 5129 */       this.newValue_ = 0L;
/* 5130 */       this.incrementStatus_ = IncrementStatusCode.OK;
/*      */     }
/*      */     public final boolean isInitialized() {
/* 5133 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 5138 */       getSerializedSize();
/* 5139 */       if (hasNewValue()) {
/* 5140 */         output.writeUInt64(1, getNewValue());
/*      */       }
/* 5142 */       if (hasIncrementStatus()) {
/* 5143 */         output.writeEnum(2, getIncrementStatus().getNumber());
/*      */       }
/* 5145 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 5150 */       int size = this.memoizedSerializedSize;
/* 5151 */       if (size != -1) return size;
/*      */ 
/* 5153 */       size = 0;
/* 5154 */       if (hasNewValue()) {
/* 5155 */         size += CodedOutputStream.computeUInt64Size(1, getNewValue());
/*      */       }
/*      */ 
/* 5158 */       if (hasIncrementStatus()) {
/* 5159 */         size += CodedOutputStream.computeEnumSize(2, getIncrementStatus().getNumber());
/*      */       }
/*      */ 
/* 5162 */       size += getUnknownFields().getSerializedSize();
/* 5163 */       this.memoizedSerializedSize = size;
/* 5164 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 5169 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5175 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5181 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 5186 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 5192 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 5197 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5203 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 5208 */       Builder builder = newBuilder();
/* 5209 */       if (builder.mergeDelimitedFrom(input)) {
/* 5210 */         return builder.buildParsed();
/*      */       }
/* 5212 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5219 */       Builder builder = newBuilder();
/* 5220 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 5221 */         return builder.buildParsed();
/*      */       }
/* 5223 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 5229 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 5235 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 5239 */       return Builder.access$11200(); } 
/* 5240 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheIncrementResponse prototype) {
/* 5242 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 5244 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 5428 */       MemcacheServicePb.internalForceInit();
/* 5429 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasNewValue;
/*      */       private long newValue_;
/*      */       private boolean hasIncrementStatus;
/* 5402 */       private MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode incrementStatus_ = MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode.OK;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 5250 */         return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 5255 */         return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 5263 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 5267 */         super.clear();
/* 5268 */         this.newValue_ = 0L;
/* 5269 */         this.hasNewValue = false;
/* 5270 */         this.incrementStatus_ = MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode.OK;
/* 5271 */         this.hasIncrementStatus = false;
/* 5272 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 5276 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 5281 */         return MemcacheServicePb.MemcacheIncrementResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementResponse getDefaultInstanceForType() {
/* 5285 */         return MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementResponse build() {
/* 5289 */         MemcacheServicePb.MemcacheIncrementResponse result = buildPartial();
/* 5290 */         if (!result.isInitialized()) {
/* 5291 */           throw newUninitializedMessageException(result);
/*      */         }
/* 5293 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheIncrementResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 5298 */         MemcacheServicePb.MemcacheIncrementResponse result = buildPartial();
/* 5299 */         if (!result.isInitialized()) {
/* 5300 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 5303 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementResponse buildPartial() {
/* 5307 */         MemcacheServicePb.MemcacheIncrementResponse result = new MemcacheServicePb.MemcacheIncrementResponse(this, null);
/* 5308 */         MemcacheServicePb.MemcacheIncrementResponse.access$11402(result, this.hasNewValue);
/* 5309 */         MemcacheServicePb.MemcacheIncrementResponse.access$11502(result, this.newValue_);
/* 5310 */         MemcacheServicePb.MemcacheIncrementResponse.access$11602(result, this.hasIncrementStatus);
/* 5311 */         MemcacheServicePb.MemcacheIncrementResponse.access$11702(result, this.incrementStatus_);
/* 5312 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 5316 */         if ((other instanceof MemcacheServicePb.MemcacheIncrementResponse)) {
/* 5317 */           return mergeFrom((MemcacheServicePb.MemcacheIncrementResponse)other);
/*      */         }
/* 5319 */         super.mergeFrom(other);
/* 5320 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheIncrementResponse other)
/*      */       {
/* 5325 */         if (other == MemcacheServicePb.MemcacheIncrementResponse.getDefaultInstance()) return this;
/* 5326 */         if (other.hasNewValue()) {
/* 5327 */           setNewValue(other.getNewValue());
/*      */         }
/* 5329 */         if (other.hasIncrementStatus()) {
/* 5330 */           setIncrementStatus(other.getIncrementStatus());
/*      */         }
/* 5332 */         mergeUnknownFields(other.getUnknownFields());
/* 5333 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 5337 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 5344 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 5348 */           int tag = input.readTag();
/* 5349 */           switch (tag) {
/*      */           case 0:
/* 5351 */             setUnknownFields(unknownFields.build());
/* 5352 */             return this;
/*      */           default:
/* 5354 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 5356 */             setUnknownFields(unknownFields.build());
/* 5357 */             return this;
/*      */           case 8:
/* 5362 */             setNewValue(input.readUInt64());
/* 5363 */             break;
/*      */           case 16:
/* 5366 */             int rawValue = input.readEnum();
/* 5367 */             MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode value = MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode.valueOf(rawValue);
/* 5368 */             if (value == null)
/* 5369 */               unknownFields.mergeVarintField(2, rawValue);
/*      */             else
/* 5371 */               setIncrementStatus(value);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasNewValue()
/*      */       {
/* 5384 */         return this.hasNewValue;
/*      */       }
/*      */       public long getNewValue() {
/* 5387 */         return this.newValue_;
/*      */       }
/*      */       public Builder setNewValue(long value) {
/* 5390 */         this.hasNewValue = true;
/* 5391 */         this.newValue_ = value;
/* 5392 */         return this;
/*      */       }
/*      */       public Builder clearNewValue() {
/* 5395 */         this.hasNewValue = false;
/* 5396 */         this.newValue_ = 0L;
/* 5397 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasIncrementStatus()
/*      */       {
/* 5404 */         return this.hasIncrementStatus;
/*      */       }
/*      */       public MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode getIncrementStatus() {
/* 5407 */         return this.incrementStatus_;
/*      */       }
/*      */       public Builder setIncrementStatus(MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode value) {
/* 5410 */         if (value == null) {
/* 5411 */           throw new NullPointerException();
/*      */         }
/* 5413 */         this.hasIncrementStatus = true;
/* 5414 */         this.incrementStatus_ = value;
/* 5415 */         return this;
/*      */       }
/*      */       public Builder clearIncrementStatus() {
/* 5418 */         this.hasIncrementStatus = false;
/* 5419 */         this.incrementStatus_ = MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode.OK;
/* 5420 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum IncrementStatusCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 5035 */       OK(0, 1), 
/* 5036 */       NOT_CHANGED(1, 2), 
/* 5037 */       ERROR(2, 3);
/*      */ 
/*      */       public static final int OK_VALUE = 1;
/*      */       public static final int NOT_CHANGED_VALUE = 2;
/*      */       public static final int ERROR_VALUE = 3;
/*      */       private static Internal.EnumLiteMap<IncrementStatusCode> internalValueMap;
/*      */       private static final IncrementStatusCode[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/* 5045 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static IncrementStatusCode valueOf(int value) {
/* 5048 */         switch (value) { case 1:
/* 5049 */           return OK;
/*      */         case 2:
/* 5050 */           return NOT_CHANGED;
/*      */         case 3:
/* 5051 */           return ERROR; }
/* 5052 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<IncrementStatusCode> internalGetValueMap()
/*      */       {
/* 5058 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/* 5070 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/* 5074 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/* 5078 */         return (Descriptors.EnumDescriptor)MemcacheServicePb.MemcacheIncrementResponse.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static IncrementStatusCode valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/* 5086 */         if (desc.getType() != getDescriptor()) {
/* 5087 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/* 5090 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private IncrementStatusCode(int index, int value)
/*      */       {
/* 5095 */         this.index = index;
/* 5096 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 5061 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode findValueByNumber(int number) {
/* 5064 */             return MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode.valueOf(number);
/*      */           }
/*      */         };
/* 5081 */         VALUES = new IncrementStatusCode[] { OK, NOT_CHANGED, ERROR };
/*      */ 
/* 5100 */         MemcacheServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheIncrementRequest extends GeneratedMessage
/*      */   {
/* 4998 */     private static final MemcacheIncrementRequest defaultInstance = new MemcacheIncrementRequest(true);
/*      */     public static final int KEY_FIELD_NUMBER = 1;
/*      */     private boolean hasKey;
/*      */     private ByteString key_;
/*      */     public static final int NAME_SPACE_FIELD_NUMBER = 4;
/*      */     private boolean hasNameSpace;
/*      */     private String nameSpace_;
/*      */     public static final int DELTA_FIELD_NUMBER = 2;
/*      */     private boolean hasDelta;
/*      */     private long delta_;
/*      */     public static final int DIRECTION_FIELD_NUMBER = 3;
/*      */     private boolean hasDirection;
/*      */     private Direction direction_;
/*      */     public static final int INITIAL_VALUE_FIELD_NUMBER = 5;
/*      */     private boolean hasInitialValue;
/*      */     private long initialValue_;
/*      */     public static final int INITIAL_FLAGS_FIELD_NUMBER = 6;
/*      */     private boolean hasInitialFlags;
/*      */     private int initialFlags_;
/* 4572 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheIncrementRequest(Builder builder)
/*      */     {
/* 4376 */       super();
/*      */     }
/*      */     private MemcacheIncrementRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest getDefaultInstance() {
/* 4382 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheIncrementRequest getDefaultInstanceForType() {
/* 4386 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 4391 */       return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 4396 */       return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasKey()
/*      */     {
/* 4474 */       return this.hasKey;
/*      */     }
/*      */     public ByteString getKey() {
/* 4477 */       return this.key_;
/*      */     }
/*      */ 
/*      */     public boolean hasNameSpace()
/*      */     {
/* 4485 */       return this.hasNameSpace;
/*      */     }
/*      */     public String getNameSpace() {
/* 4488 */       return this.nameSpace_;
/*      */     }
/*      */ 
/*      */     public boolean hasDelta()
/*      */     {
/* 4496 */       return this.hasDelta;
/*      */     }
/*      */     public long getDelta() {
/* 4499 */       return this.delta_;
/*      */     }
/*      */ 
/*      */     public boolean hasDirection()
/*      */     {
/* 4507 */       return this.hasDirection;
/*      */     }
/*      */     public Direction getDirection() {
/* 4510 */       return this.direction_;
/*      */     }
/*      */ 
/*      */     public boolean hasInitialValue()
/*      */     {
/* 4518 */       return this.hasInitialValue;
/*      */     }
/*      */     public long getInitialValue() {
/* 4521 */       return this.initialValue_;
/*      */     }
/*      */ 
/*      */     public boolean hasInitialFlags()
/*      */     {
/* 4529 */       return this.hasInitialFlags;
/*      */     }
/*      */     public int getInitialFlags() {
/* 4532 */       return this.initialFlags_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 4536 */       this.key_ = ByteString.EMPTY;
/* 4537 */       this.nameSpace_ = "";
/* 4538 */       this.delta_ = 1L;
/* 4539 */       this.direction_ = Direction.INCREMENT;
/* 4540 */       this.initialValue_ = 0L;
/* 4541 */       this.initialFlags_ = 0;
/*      */     }
/*      */     public final boolean isInitialized() {
/* 4544 */       return this.hasKey;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/* 4550 */       getSerializedSize();
/* 4551 */       if (hasKey()) {
/* 4552 */         output.writeBytes(1, getKey());
/*      */       }
/* 4554 */       if (hasDelta()) {
/* 4555 */         output.writeUInt64(2, getDelta());
/*      */       }
/* 4557 */       if (hasDirection()) {
/* 4558 */         output.writeEnum(3, getDirection().getNumber());
/*      */       }
/* 4560 */       if (hasNameSpace()) {
/* 4561 */         output.writeString(4, getNameSpace());
/*      */       }
/* 4563 */       if (hasInitialValue()) {
/* 4564 */         output.writeUInt64(5, getInitialValue());
/*      */       }
/* 4566 */       if (hasInitialFlags()) {
/* 4567 */         output.writeFixed32(6, getInitialFlags());
/*      */       }
/* 4569 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 4574 */       int size = this.memoizedSerializedSize;
/* 4575 */       if (size != -1) return size;
/*      */ 
/* 4577 */       size = 0;
/* 4578 */       if (hasKey()) {
/* 4579 */         size += CodedOutputStream.computeBytesSize(1, getKey());
/*      */       }
/*      */ 
/* 4582 */       if (hasDelta()) {
/* 4583 */         size += CodedOutputStream.computeUInt64Size(2, getDelta());
/*      */       }
/*      */ 
/* 4586 */       if (hasDirection()) {
/* 4587 */         size += CodedOutputStream.computeEnumSize(3, getDirection().getNumber());
/*      */       }
/*      */ 
/* 4590 */       if (hasNameSpace()) {
/* 4591 */         size += CodedOutputStream.computeStringSize(4, getNameSpace());
/*      */       }
/*      */ 
/* 4594 */       if (hasInitialValue()) {
/* 4595 */         size += CodedOutputStream.computeUInt64Size(5, getInitialValue());
/*      */       }
/*      */ 
/* 4598 */       if (hasInitialFlags()) {
/* 4599 */         size += CodedOutputStream.computeFixed32Size(6, getInitialFlags());
/*      */       }
/*      */ 
/* 4602 */       size += getUnknownFields().getSerializedSize();
/* 4603 */       this.memoizedSerializedSize = size;
/* 4604 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 4609 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 4615 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 4621 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 4626 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 4632 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 4637 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 4643 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 4648 */       Builder builder = newBuilder();
/* 4649 */       if (builder.mergeDelimitedFrom(input)) {
/* 4650 */         return builder.buildParsed();
/*      */       }
/* 4652 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 4659 */       Builder builder = newBuilder();
/* 4660 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 4661 */         return builder.buildParsed();
/*      */       }
/* 4663 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 4669 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheIncrementRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 4675 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 4679 */       return Builder.access$9500(); } 
/* 4680 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheIncrementRequest prototype) {
/* 4682 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 4684 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4999 */       MemcacheServicePb.internalForceInit();
/* 5000 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasKey;
/* 4867 */       private ByteString key_ = ByteString.EMPTY;
/*      */       private boolean hasNameSpace;
/* 4890 */       private String nameSpace_ = "";
/*      */       private boolean hasDelta;
/* 4913 */       private long delta_ = 1L;
/*      */       private boolean hasDirection;
/* 4933 */       private MemcacheServicePb.MemcacheIncrementRequest.Direction direction_ = MemcacheServicePb.MemcacheIncrementRequest.Direction.INCREMENT;
/*      */       private boolean hasInitialValue;
/*      */       private long initialValue_;
/*      */       private boolean hasInitialFlags;
/*      */       private int initialFlags_;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 4690 */         return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 4695 */         return MemcacheServicePb.internal_static_apphosting_MemcacheIncrementRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 4703 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 4707 */         super.clear();
/* 4708 */         this.key_ = ByteString.EMPTY;
/* 4709 */         this.hasKey = false;
/* 4710 */         this.nameSpace_ = "";
/* 4711 */         this.hasNameSpace = false;
/* 4712 */         this.delta_ = 1L;
/* 4713 */         this.hasDelta = false;
/* 4714 */         this.direction_ = MemcacheServicePb.MemcacheIncrementRequest.Direction.INCREMENT;
/* 4715 */         this.hasDirection = false;
/* 4716 */         this.initialValue_ = 0L;
/* 4717 */         this.hasInitialValue = false;
/* 4718 */         this.initialFlags_ = 0;
/* 4719 */         this.hasInitialFlags = false;
/* 4720 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 4724 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 4729 */         return MemcacheServicePb.MemcacheIncrementRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementRequest getDefaultInstanceForType() {
/* 4733 */         return MemcacheServicePb.MemcacheIncrementRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementRequest build() {
/* 4737 */         MemcacheServicePb.MemcacheIncrementRequest result = buildPartial();
/* 4738 */         if (!result.isInitialized()) {
/* 4739 */           throw newUninitializedMessageException(result);
/*      */         }
/* 4741 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheIncrementRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 4746 */         MemcacheServicePb.MemcacheIncrementRequest result = buildPartial();
/* 4747 */         if (!result.isInitialized()) {
/* 4748 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 4751 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheIncrementRequest buildPartial() {
/* 4755 */         MemcacheServicePb.MemcacheIncrementRequest result = new MemcacheServicePb.MemcacheIncrementRequest(this, null);
/* 4756 */         MemcacheServicePb.MemcacheIncrementRequest.access$9702(result, this.hasKey);
/* 4757 */         MemcacheServicePb.MemcacheIncrementRequest.access$9802(result, this.key_);
/* 4758 */         MemcacheServicePb.MemcacheIncrementRequest.access$9902(result, this.hasNameSpace);
/* 4759 */         MemcacheServicePb.MemcacheIncrementRequest.access$10002(result, this.nameSpace_);
/* 4760 */         MemcacheServicePb.MemcacheIncrementRequest.access$10102(result, this.hasDelta);
/* 4761 */         MemcacheServicePb.MemcacheIncrementRequest.access$10202(result, this.delta_);
/* 4762 */         MemcacheServicePb.MemcacheIncrementRequest.access$10302(result, this.hasDirection);
/* 4763 */         MemcacheServicePb.MemcacheIncrementRequest.access$10402(result, this.direction_);
/* 4764 */         MemcacheServicePb.MemcacheIncrementRequest.access$10502(result, this.hasInitialValue);
/* 4765 */         MemcacheServicePb.MemcacheIncrementRequest.access$10602(result, this.initialValue_);
/* 4766 */         MemcacheServicePb.MemcacheIncrementRequest.access$10702(result, this.hasInitialFlags);
/* 4767 */         MemcacheServicePb.MemcacheIncrementRequest.access$10802(result, this.initialFlags_);
/* 4768 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 4772 */         if ((other instanceof MemcacheServicePb.MemcacheIncrementRequest)) {
/* 4773 */           return mergeFrom((MemcacheServicePb.MemcacheIncrementRequest)other);
/*      */         }
/* 4775 */         super.mergeFrom(other);
/* 4776 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheIncrementRequest other)
/*      */       {
/* 4781 */         if (other == MemcacheServicePb.MemcacheIncrementRequest.getDefaultInstance()) return this;
/* 4782 */         if (other.hasKey()) {
/* 4783 */           setKey(other.getKey());
/*      */         }
/* 4785 */         if (other.hasNameSpace()) {
/* 4786 */           setNameSpace(other.getNameSpace());
/*      */         }
/* 4788 */         if (other.hasDelta()) {
/* 4789 */           setDelta(other.getDelta());
/*      */         }
/* 4791 */         if (other.hasDirection()) {
/* 4792 */           setDirection(other.getDirection());
/*      */         }
/* 4794 */         if (other.hasInitialValue()) {
/* 4795 */           setInitialValue(other.getInitialValue());
/*      */         }
/* 4797 */         if (other.hasInitialFlags()) {
/* 4798 */           setInitialFlags(other.getInitialFlags());
/*      */         }
/* 4800 */         mergeUnknownFields(other.getUnknownFields());
/* 4801 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 4805 */         return this.hasKey;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 4813 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 4817 */           int tag = input.readTag();
/* 4818 */           switch (tag) {
/*      */           case 0:
/* 4820 */             setUnknownFields(unknownFields.build());
/* 4821 */             return this;
/*      */           default:
/* 4823 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 4825 */             setUnknownFields(unknownFields.build());
/* 4826 */             return this;
/*      */           case 10:
/* 4831 */             setKey(input.readBytes());
/* 4832 */             break;
/*      */           case 16:
/* 4835 */             setDelta(input.readUInt64());
/* 4836 */             break;
/*      */           case 24:
/* 4839 */             int rawValue = input.readEnum();
/* 4840 */             MemcacheServicePb.MemcacheIncrementRequest.Direction value = MemcacheServicePb.MemcacheIncrementRequest.Direction.valueOf(rawValue);
/* 4841 */             if (value == null)
/* 4842 */               unknownFields.mergeVarintField(3, rawValue);
/*      */             else {
/* 4844 */               setDirection(value);
/*      */             }
/* 4846 */             break;
/*      */           case 34:
/* 4849 */             setNameSpace(input.readString());
/* 4850 */             break;
/*      */           case 40:
/* 4853 */             setInitialValue(input.readUInt64());
/* 4854 */             break;
/*      */           case 53:
/* 4857 */             setInitialFlags(input.readFixed32());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/* 4869 */         return this.hasKey;
/*      */       }
/*      */       public ByteString getKey() {
/* 4872 */         return this.key_;
/*      */       }
/*      */       public Builder setKey(ByteString value) {
/* 4875 */         if (value == null) {
/* 4876 */           throw new NullPointerException();
/*      */         }
/* 4878 */         this.hasKey = true;
/* 4879 */         this.key_ = value;
/* 4880 */         return this;
/*      */       }
/*      */       public Builder clearKey() {
/* 4883 */         this.hasKey = false;
/* 4884 */         this.key_ = MemcacheServicePb.MemcacheIncrementRequest.getDefaultInstance().getKey();
/* 4885 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasNameSpace()
/*      */       {
/* 4892 */         return this.hasNameSpace;
/*      */       }
/*      */       public String getNameSpace() {
/* 4895 */         return this.nameSpace_;
/*      */       }
/*      */       public Builder setNameSpace(String value) {
/* 4898 */         if (value == null) {
/* 4899 */           throw new NullPointerException();
/*      */         }
/* 4901 */         this.hasNameSpace = true;
/* 4902 */         this.nameSpace_ = value;
/* 4903 */         return this;
/*      */       }
/*      */       public Builder clearNameSpace() {
/* 4906 */         this.hasNameSpace = false;
/* 4907 */         this.nameSpace_ = MemcacheServicePb.MemcacheIncrementRequest.getDefaultInstance().getNameSpace();
/* 4908 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasDelta()
/*      */       {
/* 4915 */         return this.hasDelta;
/*      */       }
/*      */       public long getDelta() {
/* 4918 */         return this.delta_;
/*      */       }
/*      */       public Builder setDelta(long value) {
/* 4921 */         this.hasDelta = true;
/* 4922 */         this.delta_ = value;
/* 4923 */         return this;
/*      */       }
/*      */       public Builder clearDelta() {
/* 4926 */         this.hasDelta = false;
/* 4927 */         this.delta_ = 1L;
/* 4928 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasDirection()
/*      */       {
/* 4935 */         return this.hasDirection;
/*      */       }
/*      */       public MemcacheServicePb.MemcacheIncrementRequest.Direction getDirection() {
/* 4938 */         return this.direction_;
/*      */       }
/*      */       public Builder setDirection(MemcacheServicePb.MemcacheIncrementRequest.Direction value) {
/* 4941 */         if (value == null) {
/* 4942 */           throw new NullPointerException();
/*      */         }
/* 4944 */         this.hasDirection = true;
/* 4945 */         this.direction_ = value;
/* 4946 */         return this;
/*      */       }
/*      */       public Builder clearDirection() {
/* 4949 */         this.hasDirection = false;
/* 4950 */         this.direction_ = MemcacheServicePb.MemcacheIncrementRequest.Direction.INCREMENT;
/* 4951 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasInitialValue()
/*      */       {
/* 4958 */         return this.hasInitialValue;
/*      */       }
/*      */       public long getInitialValue() {
/* 4961 */         return this.initialValue_;
/*      */       }
/*      */       public Builder setInitialValue(long value) {
/* 4964 */         this.hasInitialValue = true;
/* 4965 */         this.initialValue_ = value;
/* 4966 */         return this;
/*      */       }
/*      */       public Builder clearInitialValue() {
/* 4969 */         this.hasInitialValue = false;
/* 4970 */         this.initialValue_ = 0L;
/* 4971 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasInitialFlags()
/*      */       {
/* 4978 */         return this.hasInitialFlags;
/*      */       }
/*      */       public int getInitialFlags() {
/* 4981 */         return this.initialFlags_;
/*      */       }
/*      */       public Builder setInitialFlags(int value) {
/* 4984 */         this.hasInitialFlags = true;
/* 4985 */         this.initialFlags_ = value;
/* 4986 */         return this;
/*      */       }
/*      */       public Builder clearInitialFlags() {
/* 4989 */         this.hasInitialFlags = false;
/* 4990 */         this.initialFlags_ = 0;
/* 4991 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Direction
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 4401 */       INCREMENT(0, 1), 
/* 4402 */       DECREMENT(1, 2);
/*      */ 
/*      */       public static final int INCREMENT_VALUE = 1;
/*      */       public static final int DECREMENT_VALUE = 2;
/*      */       private static Internal.EnumLiteMap<Direction> internalValueMap;
/*      */       private static final Direction[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/* 4409 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static Direction valueOf(int value) {
/* 4412 */         switch (value) { case 1:
/* 4413 */           return INCREMENT;
/*      */         case 2:
/* 4414 */           return DECREMENT; }
/* 4415 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<Direction> internalGetValueMap()
/*      */       {
/* 4421 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/* 4433 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/* 4437 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/* 4441 */         return (Descriptors.EnumDescriptor)MemcacheServicePb.MemcacheIncrementRequest.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static Direction valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/* 4449 */         if (desc.getType() != getDescriptor()) {
/* 4450 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/* 4453 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private Direction(int index, int value)
/*      */       {
/* 4458 */         this.index = index;
/* 4459 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 4424 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public MemcacheServicePb.MemcacheIncrementRequest.Direction findValueByNumber(int number) {
/* 4427 */             return MemcacheServicePb.MemcacheIncrementRequest.Direction.valueOf(number);
/*      */           }
/*      */         };
/* 4444 */         VALUES = new Direction[] { INCREMENT, DECREMENT };
/*      */ 
/* 4463 */         MemcacheServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheDeleteResponse extends GeneratedMessage
/*      */   {
/* 4364 */     private static final MemcacheDeleteResponse defaultInstance = new MemcacheDeleteResponse(true);
/*      */     public static final int DELETE_STATUS_FIELD_NUMBER = 1;
/*      */     private List<DeleteStatusCode> deleteStatus_;
/* 4066 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheDeleteResponse(Builder builder)
/*      */     {
/* 3944 */       super();
/*      */     }
/*      */     private MemcacheDeleteResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse getDefaultInstance() {
/* 3950 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheDeleteResponse getDefaultInstanceForType() {
/* 3954 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 3959 */       return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 3964 */       return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<DeleteStatusCode> getDeleteStatusList()
/*      */     {
/* 4041 */       return this.deleteStatus_;
/*      */     }
/*      */     public int getDeleteStatusCount() {
/* 4044 */       return this.deleteStatus_.size();
/*      */     }
/*      */     public DeleteStatusCode getDeleteStatus(int index) {
/* 4047 */       return (DeleteStatusCode)this.deleteStatus_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 4051 */       this.deleteStatus_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 4054 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 4059 */       getSerializedSize();
/* 4060 */       for (DeleteStatusCode element : getDeleteStatusList()) {
/* 4061 */         output.writeEnum(1, element.getNumber());
/*      */       }
/* 4063 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 4068 */       int size = this.memoizedSerializedSize;
/* 4069 */       if (size != -1) return size;
/*      */ 
/* 4071 */       size = 0;
/*      */ 
/* 4073 */       int dataSize = 0;
/* 4074 */       for (DeleteStatusCode element : getDeleteStatusList()) {
/* 4075 */         dataSize += CodedOutputStream.computeEnumSizeNoTag(element.getNumber());
/*      */       }
/*      */ 
/* 4078 */       size += dataSize;
/* 4079 */       size += 1 * getDeleteStatusList().size();
/*      */ 
/* 4081 */       size += getUnknownFields().getSerializedSize();
/* 4082 */       this.memoizedSerializedSize = size;
/* 4083 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 4088 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 4094 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 4100 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 4105 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 4111 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 4116 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 4122 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 4127 */       Builder builder = newBuilder();
/* 4128 */       if (builder.mergeDelimitedFrom(input)) {
/* 4129 */         return builder.buildParsed();
/*      */       }
/* 4131 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 4138 */       Builder builder = newBuilder();
/* 4139 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 4140 */         return builder.buildParsed();
/*      */       }
/* 4142 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 4148 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 4154 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 4158 */       return Builder.access$8900(); } 
/* 4159 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheDeleteResponse prototype) {
/* 4161 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 4163 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 4365 */       MemcacheServicePb.internalForceInit();
/* 4366 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 4313 */       private List<MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode> deleteStatus_ = Collections.emptyList();
/*      */       private boolean isDeleteStatusMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 4169 */         return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 4174 */         return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 4182 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 4186 */         super.clear();
/* 4187 */         this.deleteStatus_ = Collections.emptyList();
/* 4188 */         this.isDeleteStatusMutable = false;
/* 4189 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 4193 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 4198 */         return MemcacheServicePb.MemcacheDeleteResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteResponse getDefaultInstanceForType() {
/* 4202 */         return MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteResponse build() {
/* 4206 */         MemcacheServicePb.MemcacheDeleteResponse result = buildPartial();
/* 4207 */         if (!result.isInitialized()) {
/* 4208 */           throw newUninitializedMessageException(result);
/*      */         }
/* 4210 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheDeleteResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 4215 */         MemcacheServicePb.MemcacheDeleteResponse result = buildPartial();
/* 4216 */         if (!result.isInitialized()) {
/* 4217 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 4220 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteResponse buildPartial() {
/* 4224 */         MemcacheServicePb.MemcacheDeleteResponse result = new MemcacheServicePb.MemcacheDeleteResponse(this, null);
/* 4225 */         if (this.isDeleteStatusMutable) {
/* 4226 */           this.deleteStatus_ = Collections.unmodifiableList(this.deleteStatus_);
/* 4227 */           this.isDeleteStatusMutable = false;
/*      */         }
/* 4229 */         MemcacheServicePb.MemcacheDeleteResponse.access$9102(result, this.deleteStatus_);
/* 4230 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 4234 */         if ((other instanceof MemcacheServicePb.MemcacheDeleteResponse)) {
/* 4235 */           return mergeFrom((MemcacheServicePb.MemcacheDeleteResponse)other);
/*      */         }
/* 4237 */         super.mergeFrom(other);
/* 4238 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheDeleteResponse other)
/*      */       {
/* 4243 */         if (other == MemcacheServicePb.MemcacheDeleteResponse.getDefaultInstance()) return this;
/* 4244 */         if (!other.deleteStatus_.isEmpty()) {
/* 4245 */           if (this.deleteStatus_.isEmpty()) {
/* 4246 */             this.deleteStatus_ = other.deleteStatus_;
/* 4247 */             this.isDeleteStatusMutable = false;
/*      */           } else {
/* 4249 */             ensureDeleteStatusIsMutable();
/* 4250 */             this.deleteStatus_.addAll(other.deleteStatus_);
/*      */           }
/*      */         }
/* 4253 */         mergeUnknownFields(other.getUnknownFields());
/* 4254 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 4258 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 4265 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 4269 */           int tag = input.readTag();
/* 4270 */           switch (tag) {
/*      */           case 0:
/* 4272 */             setUnknownFields(unknownFields.build());
/* 4273 */             return this;
/*      */           default:
/* 4275 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 4277 */             setUnknownFields(unknownFields.build());
/* 4278 */             return this;
/*      */           case 8:
/* 4283 */             int rawValue = input.readEnum();
/* 4284 */             MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode value = MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode.valueOf(rawValue);
/* 4285 */             if (value == null)
/* 4286 */               unknownFields.mergeVarintField(1, rawValue);
/*      */             else {
/* 4288 */               addDeleteStatus(value);
/*      */             }
/* 4290 */             break;
/*      */           case 10:
/* 4293 */             int length = input.readRawVarint32();
/* 4294 */             int oldLimit = input.pushLimit(length);
/* 4295 */             while (input.getBytesUntilLimit() > 0) {
/* 4296 */               int rawValue = input.readEnum();
/* 4297 */               MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode value = MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode.valueOf(rawValue);
/* 4298 */               if (value == null)
/* 4299 */                 unknownFields.mergeVarintField(1, rawValue);
/*      */               else {
/* 4301 */                 addDeleteStatus(value);
/*      */               }
/*      */             }
/* 4304 */             input.popLimit(oldLimit);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureDeleteStatusIsMutable()
/*      */       {
/* 4317 */         if (!this.isDeleteStatusMutable) {
/* 4318 */           this.deleteStatus_ = new ArrayList(this.deleteStatus_);
/* 4319 */           this.isDeleteStatusMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode> getDeleteStatusList() {
/* 4323 */         return Collections.unmodifiableList(this.deleteStatus_);
/*      */       }
/*      */       public int getDeleteStatusCount() {
/* 4326 */         return this.deleteStatus_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode getDeleteStatus(int index) {
/* 4329 */         return (MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode)this.deleteStatus_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setDeleteStatus(int index, MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode value) {
/* 4333 */         if (value == null) {
/* 4334 */           throw new NullPointerException();
/*      */         }
/* 4336 */         ensureDeleteStatusIsMutable();
/* 4337 */         this.deleteStatus_.set(index, value);
/* 4338 */         return this;
/*      */       }
/*      */       public Builder addDeleteStatus(MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode value) {
/* 4341 */         if (value == null) {
/* 4342 */           throw new NullPointerException();
/*      */         }
/* 4344 */         ensureDeleteStatusIsMutable();
/* 4345 */         this.deleteStatus_.add(value);
/* 4346 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllDeleteStatus(Iterable<? extends MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode> values) {
/* 4350 */         ensureDeleteStatusIsMutable();
/* 4351 */         GeneratedMessage.Builder.addAll(values, this.deleteStatus_);
/* 4352 */         return this;
/*      */       }
/*      */       public Builder clearDeleteStatus() {
/* 4355 */         this.deleteStatus_ = Collections.emptyList();
/* 4356 */         this.isDeleteStatusMutable = false;
/* 4357 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum DeleteStatusCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 3969 */       DELETED(0, 1), 
/* 3970 */       NOT_FOUND(1, 2);
/*      */ 
/*      */       public static final int DELETED_VALUE = 1;
/*      */       public static final int NOT_FOUND_VALUE = 2;
/*      */       private static Internal.EnumLiteMap<DeleteStatusCode> internalValueMap;
/*      */       private static final DeleteStatusCode[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/* 3977 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static DeleteStatusCode valueOf(int value) {
/* 3980 */         switch (value) { case 1:
/* 3981 */           return DELETED;
/*      */         case 2:
/* 3982 */           return NOT_FOUND; }
/* 3983 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<DeleteStatusCode> internalGetValueMap()
/*      */       {
/* 3989 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/* 4001 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/* 4005 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/* 4009 */         return (Descriptors.EnumDescriptor)MemcacheServicePb.MemcacheDeleteResponse.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static DeleteStatusCode valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/* 4017 */         if (desc.getType() != getDescriptor()) {
/* 4018 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/* 4021 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private DeleteStatusCode(int index, int value)
/*      */       {
/* 4026 */         this.index = index;
/* 4027 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 3992 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode findValueByNumber(int number) {
/* 3995 */             return MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode.valueOf(number);
/*      */           }
/*      */         };
/* 4012 */         VALUES = new DeleteStatusCode[] { DELETED, NOT_FOUND };
/*      */ 
/* 4031 */         MemcacheServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheDeleteRequest extends GeneratedMessage
/*      */   {
/* 3932 */     private static final MemcacheDeleteRequest defaultInstance = new MemcacheDeleteRequest(true);
/*      */     public static final int ITEM_FIELD_NUMBER = 1;
/*      */     private List<Item> item_;
/*      */     public static final int NAME_SPACE_FIELD_NUMBER = 4;
/*      */     private boolean hasNameSpace;
/*      */     private String nameSpace_;
/* 3605 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheDeleteRequest(Builder builder)
/*      */     {
/* 3183 */       super();
/*      */     }
/*      */     private MemcacheDeleteRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest getDefaultInstance() {
/* 3189 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheDeleteRequest getDefaultInstanceForType() {
/* 3193 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 3198 */       return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 3203 */       return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<Item> getItemList()
/*      */     {
/* 3562 */       return this.item_;
/*      */     }
/*      */     public int getItemCount() {
/* 3565 */       return this.item_.size();
/*      */     }
/*      */     public Item getItem(int index) {
/* 3568 */       return (Item)this.item_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasNameSpace()
/*      */     {
/* 3576 */       return this.hasNameSpace;
/*      */     }
/*      */     public String getNameSpace() {
/* 3579 */       return this.nameSpace_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 3583 */       this.item_ = Collections.emptyList();
/* 3584 */       this.nameSpace_ = "";
/*      */     }
/*      */     public final boolean isInitialized() {
/* 3587 */       for (Item element : getItemList()) {
/* 3588 */         if (!element.isInitialized()) return false;
/*      */       }
/* 3590 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 3595 */       getSerializedSize();
/* 3596 */       for (Item element : getItemList()) {
/* 3597 */         output.writeGroup(1, element);
/*      */       }
/* 3599 */       if (hasNameSpace()) {
/* 3600 */         output.writeString(4, getNameSpace());
/*      */       }
/* 3602 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 3607 */       int size = this.memoizedSerializedSize;
/* 3608 */       if (size != -1) return size;
/*      */ 
/* 3610 */       size = 0;
/* 3611 */       for (Item element : getItemList()) {
/* 3612 */         size += CodedOutputStream.computeGroupSize(1, element);
/*      */       }
/*      */ 
/* 3615 */       if (hasNameSpace()) {
/* 3616 */         size += CodedOutputStream.computeStringSize(4, getNameSpace());
/*      */       }
/*      */ 
/* 3619 */       size += getUnknownFields().getSerializedSize();
/* 3620 */       this.memoizedSerializedSize = size;
/* 3621 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 3626 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 3632 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 3638 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 3643 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 3649 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 3654 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 3660 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 3665 */       Builder builder = newBuilder();
/* 3666 */       if (builder.mergeDelimitedFrom(input)) {
/* 3667 */         return builder.buildParsed();
/*      */       }
/* 3669 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 3676 */       Builder builder = newBuilder();
/* 3677 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 3678 */         return builder.buildParsed();
/*      */       }
/* 3680 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 3686 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheDeleteRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 3692 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 3696 */       return Builder.access$8100(); } 
/* 3697 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheDeleteRequest prototype) {
/* 3699 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 3701 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3933 */       MemcacheServicePb.internalForceInit();
/* 3934 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 3846 */       private List<MemcacheServicePb.MemcacheDeleteRequest.Item> item_ = Collections.emptyList();
/*      */       private boolean isItemMutable;
/*      */       private boolean hasNameSpace;
/* 3907 */       private String nameSpace_ = "";
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 3707 */         return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 3712 */         return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 3720 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 3724 */         super.clear();
/* 3725 */         this.item_ = Collections.emptyList();
/* 3726 */         this.isItemMutable = false;
/* 3727 */         this.nameSpace_ = "";
/* 3728 */         this.hasNameSpace = false;
/* 3729 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 3733 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 3738 */         return MemcacheServicePb.MemcacheDeleteRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteRequest getDefaultInstanceForType() {
/* 3742 */         return MemcacheServicePb.MemcacheDeleteRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteRequest build() {
/* 3746 */         MemcacheServicePb.MemcacheDeleteRequest result = buildPartial();
/* 3747 */         if (!result.isInitialized()) {
/* 3748 */           throw newUninitializedMessageException(result);
/*      */         }
/* 3750 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheDeleteRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 3755 */         MemcacheServicePb.MemcacheDeleteRequest result = buildPartial();
/* 3756 */         if (!result.isInitialized()) {
/* 3757 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 3760 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheDeleteRequest buildPartial() {
/* 3764 */         MemcacheServicePb.MemcacheDeleteRequest result = new MemcacheServicePb.MemcacheDeleteRequest(this, null);
/* 3765 */         if (this.isItemMutable) {
/* 3766 */           this.item_ = Collections.unmodifiableList(this.item_);
/* 3767 */           this.isItemMutable = false;
/*      */         }
/* 3769 */         MemcacheServicePb.MemcacheDeleteRequest.access$8302(result, this.item_);
/* 3770 */         MemcacheServicePb.MemcacheDeleteRequest.access$8402(result, this.hasNameSpace);
/* 3771 */         MemcacheServicePb.MemcacheDeleteRequest.access$8502(result, this.nameSpace_);
/* 3772 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 3776 */         if ((other instanceof MemcacheServicePb.MemcacheDeleteRequest)) {
/* 3777 */           return mergeFrom((MemcacheServicePb.MemcacheDeleteRequest)other);
/*      */         }
/* 3779 */         super.mergeFrom(other);
/* 3780 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheDeleteRequest other)
/*      */       {
/* 3785 */         if (other == MemcacheServicePb.MemcacheDeleteRequest.getDefaultInstance()) return this;
/* 3786 */         if (!other.item_.isEmpty()) {
/* 3787 */           if (this.item_.isEmpty()) {
/* 3788 */             this.item_ = other.item_;
/* 3789 */             this.isItemMutable = false;
/*      */           } else {
/* 3791 */             ensureItemIsMutable();
/* 3792 */             this.item_.addAll(other.item_);
/*      */           }
/*      */         }
/* 3795 */         if (other.hasNameSpace()) {
/* 3796 */           setNameSpace(other.getNameSpace());
/*      */         }
/* 3798 */         mergeUnknownFields(other.getUnknownFields());
/* 3799 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 3803 */         for (MemcacheServicePb.MemcacheDeleteRequest.Item element : getItemList()) {
/* 3804 */           if (!element.isInitialized()) return false;
/*      */         }
/* 3806 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 3813 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 3817 */           int tag = input.readTag();
/* 3818 */           switch (tag) {
/*      */           case 0:
/* 3820 */             setUnknownFields(unknownFields.build());
/* 3821 */             return this;
/*      */           default:
/* 3823 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 3825 */             setUnknownFields(unknownFields.build());
/* 3826 */             return this;
/*      */           case 11:
/* 3831 */             MemcacheServicePb.MemcacheDeleteRequest.Item.Builder subBuilder = MemcacheServicePb.MemcacheDeleteRequest.Item.newBuilder();
/* 3832 */             input.readGroup(1, subBuilder, extensionRegistry);
/* 3833 */             addItem(subBuilder.buildPartial());
/* 3834 */             break;
/*      */           case 34:
/* 3837 */             setNameSpace(input.readString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureItemIsMutable()
/*      */       {
/* 3850 */         if (!this.isItemMutable) {
/* 3851 */           this.item_ = new ArrayList(this.item_);
/* 3852 */           this.isItemMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheDeleteRequest.Item> getItemList() {
/* 3856 */         return Collections.unmodifiableList(this.item_);
/*      */       }
/*      */       public int getItemCount() {
/* 3859 */         return this.item_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheDeleteRequest.Item getItem(int index) {
/* 3862 */         return (MemcacheServicePb.MemcacheDeleteRequest.Item)this.item_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheDeleteRequest.Item value) {
/* 3866 */         if (value == null) {
/* 3867 */           throw new NullPointerException();
/*      */         }
/* 3869 */         ensureItemIsMutable();
/* 3870 */         this.item_.set(index, value);
/* 3871 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheDeleteRequest.Item.Builder builderForValue) {
/* 3875 */         ensureItemIsMutable();
/* 3876 */         this.item_.set(index, builderForValue.build());
/* 3877 */         return this;
/*      */       }
/*      */       public Builder addItem(MemcacheServicePb.MemcacheDeleteRequest.Item value) {
/* 3880 */         if (value == null) {
/* 3881 */           throw new NullPointerException();
/*      */         }
/* 3883 */         ensureItemIsMutable();
/* 3884 */         this.item_.add(value);
/* 3885 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addItem(MemcacheServicePb.MemcacheDeleteRequest.Item.Builder builderForValue) {
/* 3889 */         ensureItemIsMutable();
/* 3890 */         this.item_.add(builderForValue.build());
/* 3891 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllItem(Iterable<? extends MemcacheServicePb.MemcacheDeleteRequest.Item> values) {
/* 3895 */         ensureItemIsMutable();
/* 3896 */         GeneratedMessage.Builder.addAll(values, this.item_);
/* 3897 */         return this;
/*      */       }
/*      */       public Builder clearItem() {
/* 3900 */         this.item_ = Collections.emptyList();
/* 3901 */         this.isItemMutable = false;
/* 3902 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasNameSpace()
/*      */       {
/* 3909 */         return this.hasNameSpace;
/*      */       }
/*      */       public String getNameSpace() {
/* 3912 */         return this.nameSpace_;
/*      */       }
/*      */       public Builder setNameSpace(String value) {
/* 3915 */         if (value == null) {
/* 3916 */           throw new NullPointerException();
/*      */         }
/* 3918 */         this.hasNameSpace = true;
/* 3919 */         this.nameSpace_ = value;
/* 3920 */         return this;
/*      */       }
/*      */       public Builder clearNameSpace() {
/* 3923 */         this.hasNameSpace = false;
/* 3924 */         this.nameSpace_ = MemcacheServicePb.MemcacheDeleteRequest.getDefaultInstance().getNameSpace();
/* 3925 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static final class Item extends GeneratedMessage
/*      */     {
/* 3550 */       private static final Item defaultInstance = new Item(true);
/*      */       public static final int KEY_FIELD_NUMBER = 2;
/*      */       private boolean hasKey;
/*      */       private ByteString key_;
/*      */       public static final int DELETE_TIME_FIELD_NUMBER = 3;
/*      */       private boolean hasDeleteTime;
/*      */       private int deleteTime_;
/* 3276 */       private int memoizedSerializedSize = -1;
/*      */ 
/*      */       private Item(Builder builder)
/*      */       {
/* 3210 */         super();
/*      */       }
/*      */       private Item(boolean noInit) {
/*      */       }
/*      */ 
/*      */       public static Item getDefaultInstance() {
/* 3216 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public Item getDefaultInstanceForType() {
/* 3220 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 3225 */         return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_Item_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 3230 */         return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_Item_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/* 3238 */         return this.hasKey;
/*      */       }
/*      */       public ByteString getKey() {
/* 3241 */         return this.key_;
/*      */       }
/*      */ 
/*      */       public boolean hasDeleteTime()
/*      */       {
/* 3249 */         return this.hasDeleteTime;
/*      */       }
/*      */       public int getDeleteTime() {
/* 3252 */         return this.deleteTime_;
/*      */       }
/*      */ 
/*      */       private void initFields() {
/* 3256 */         this.key_ = ByteString.EMPTY;
/* 3257 */         this.deleteTime_ = 0;
/*      */       }
/*      */       public final boolean isInitialized() {
/* 3260 */         return this.hasKey;
/*      */       }
/*      */ 
/*      */       public void writeTo(CodedOutputStream output)
/*      */         throws IOException
/*      */       {
/* 3266 */         getSerializedSize();
/* 3267 */         if (hasKey()) {
/* 3268 */           output.writeBytes(2, getKey());
/*      */         }
/* 3270 */         if (hasDeleteTime()) {
/* 3271 */           output.writeFixed32(3, getDeleteTime());
/*      */         }
/* 3273 */         getUnknownFields().writeTo(output);
/*      */       }
/*      */ 
/*      */       public int getSerializedSize()
/*      */       {
/* 3278 */         int size = this.memoizedSerializedSize;
/* 3279 */         if (size != -1) return size;
/*      */ 
/* 3281 */         size = 0;
/* 3282 */         if (hasKey()) {
/* 3283 */           size += CodedOutputStream.computeBytesSize(2, getKey());
/*      */         }
/*      */ 
/* 3286 */         if (hasDeleteTime()) {
/* 3287 */           size += CodedOutputStream.computeFixed32Size(3, getDeleteTime());
/*      */         }
/*      */ 
/* 3290 */         size += getUnknownFields().getSerializedSize();
/* 3291 */         this.memoizedSerializedSize = size;
/* 3292 */         return size;
/*      */       }
/*      */ 
/*      */       protected Object writeReplace() throws ObjectStreamException
/*      */       {
/* 3297 */         return super.writeReplace();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 3303 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 3309 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */       {
/* 3314 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 3320 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input) throws IOException
/*      */       {
/* 3325 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 3331 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input) throws IOException
/*      */       {
/* 3336 */         Builder builder = newBuilder();
/* 3337 */         if (builder.mergeDelimitedFrom(input)) {
/* 3338 */           return builder.buildParsed();
/*      */         }
/* 3340 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 3347 */         Builder builder = newBuilder();
/* 3348 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 3349 */           return builder.buildParsed();
/*      */         }
/* 3351 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input)
/*      */         throws IOException
/*      */       {
/* 3357 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 3363 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Builder newBuilder() {
/* 3367 */         return Builder.access$7400(); } 
/* 3368 */       public Builder newBuilderForType() { return newBuilder(); } 
/*      */       public static Builder newBuilder(Item prototype) {
/* 3370 */         return newBuilder().mergeFrom(prototype);
/*      */       }
/* 3372 */       public Builder toBuilder() { return newBuilder(this);
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 3551 */         MemcacheServicePb.internalForceInit();
/* 3552 */         defaultInstance.initFields();
/*      */       }
/*      */ 
/*      */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */       {
/*      */         private boolean hasKey;
/* 3505 */         private ByteString key_ = ByteString.EMPTY;
/*      */         private boolean hasDeleteTime;
/*      */         private int deleteTime_;
/*      */ 
/*      */         public static final Descriptors.Descriptor getDescriptor()
/*      */         {
/* 3378 */           return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_Item_descriptor;
/*      */         }
/*      */ 
/*      */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */         {
/* 3383 */           return MemcacheServicePb.internal_static_apphosting_MemcacheDeleteRequest_Item_fieldAccessorTable;
/*      */         }
/*      */ 
/*      */         private static Builder create()
/*      */         {
/* 3391 */           return new Builder();
/*      */         }
/*      */ 
/*      */         public Builder clear() {
/* 3395 */           super.clear();
/* 3396 */           this.key_ = ByteString.EMPTY;
/* 3397 */           this.hasKey = false;
/* 3398 */           this.deleteTime_ = 0;
/* 3399 */           this.hasDeleteTime = false;
/* 3400 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder clone() {
/* 3404 */           return create().mergeFrom(buildPartial());
/*      */         }
/*      */ 
/*      */         public Descriptors.Descriptor getDescriptorForType()
/*      */         {
/* 3409 */           return MemcacheServicePb.MemcacheDeleteRequest.Item.getDescriptor();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheDeleteRequest.Item getDefaultInstanceForType() {
/* 3413 */           return MemcacheServicePb.MemcacheDeleteRequest.Item.getDefaultInstance();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheDeleteRequest.Item build() {
/* 3417 */           MemcacheServicePb.MemcacheDeleteRequest.Item result = buildPartial();
/* 3418 */           if (!result.isInitialized()) {
/* 3419 */             throw newUninitializedMessageException(result);
/*      */           }
/* 3421 */           return result;
/*      */         }
/*      */ 
/*      */         private MemcacheServicePb.MemcacheDeleteRequest.Item buildParsed() throws InvalidProtocolBufferException
/*      */         {
/* 3426 */           MemcacheServicePb.MemcacheDeleteRequest.Item result = buildPartial();
/* 3427 */           if (!result.isInitialized()) {
/* 3428 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */           }
/*      */ 
/* 3431 */           return result;
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheDeleteRequest.Item buildPartial() {
/* 3435 */           MemcacheServicePb.MemcacheDeleteRequest.Item result = new MemcacheServicePb.MemcacheDeleteRequest.Item(this, null);
/* 3436 */           MemcacheServicePb.MemcacheDeleteRequest.Item.access$7602(result, this.hasKey);
/* 3437 */           MemcacheServicePb.MemcacheDeleteRequest.Item.access$7702(result, this.key_);
/* 3438 */           MemcacheServicePb.MemcacheDeleteRequest.Item.access$7802(result, this.hasDeleteTime);
/* 3439 */           MemcacheServicePb.MemcacheDeleteRequest.Item.access$7902(result, this.deleteTime_);
/* 3440 */           return result;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(Message other) {
/* 3444 */           if ((other instanceof MemcacheServicePb.MemcacheDeleteRequest.Item)) {
/* 3445 */             return mergeFrom((MemcacheServicePb.MemcacheDeleteRequest.Item)other);
/*      */           }
/* 3447 */           super.mergeFrom(other);
/* 3448 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(MemcacheServicePb.MemcacheDeleteRequest.Item other)
/*      */         {
/* 3453 */           if (other == MemcacheServicePb.MemcacheDeleteRequest.Item.getDefaultInstance()) return this;
/* 3454 */           if (other.hasKey()) {
/* 3455 */             setKey(other.getKey());
/*      */           }
/* 3457 */           if (other.hasDeleteTime()) {
/* 3458 */             setDeleteTime(other.getDeleteTime());
/*      */           }
/* 3460 */           mergeUnknownFields(other.getUnknownFields());
/* 3461 */           return this;
/*      */         }
/*      */ 
/*      */         public final boolean isInitialized() {
/* 3465 */           return this.hasKey;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */           throws IOException
/*      */         {
/* 3473 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */           while (true)
/*      */           {
/* 3477 */             int tag = input.readTag();
/* 3478 */             switch (tag) {
/*      */             case 0:
/* 3480 */               setUnknownFields(unknownFields.build());
/* 3481 */               return this;
/*      */             default:
/* 3483 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */                 break;
/* 3485 */               setUnknownFields(unknownFields.build());
/* 3486 */               return this;
/*      */             case 18:
/* 3491 */               setKey(input.readBytes());
/* 3492 */               break;
/*      */             case 29:
/* 3495 */               setDeleteTime(input.readFixed32());
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         public boolean hasKey()
/*      */         {
/* 3507 */           return this.hasKey;
/*      */         }
/*      */         public ByteString getKey() {
/* 3510 */           return this.key_;
/*      */         }
/*      */         public Builder setKey(ByteString value) {
/* 3513 */           if (value == null) {
/* 3514 */             throw new NullPointerException();
/*      */           }
/* 3516 */           this.hasKey = true;
/* 3517 */           this.key_ = value;
/* 3518 */           return this;
/*      */         }
/*      */         public Builder clearKey() {
/* 3521 */           this.hasKey = false;
/* 3522 */           this.key_ = MemcacheServicePb.MemcacheDeleteRequest.Item.getDefaultInstance().getKey();
/* 3523 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasDeleteTime()
/*      */         {
/* 3530 */           return this.hasDeleteTime;
/*      */         }
/*      */         public int getDeleteTime() {
/* 3533 */           return this.deleteTime_;
/*      */         }
/*      */         public Builder setDeleteTime(int value) {
/* 3536 */           this.hasDeleteTime = true;
/* 3537 */           this.deleteTime_ = value;
/* 3538 */           return this;
/*      */         }
/*      */         public Builder clearDeleteTime() {
/* 3541 */           this.hasDeleteTime = false;
/* 3542 */           this.deleteTime_ = 0;
/* 3543 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheSetResponse extends GeneratedMessage
/*      */   {
/* 3171 */     private static final MemcacheSetResponse defaultInstance = new MemcacheSetResponse(true);
/*      */     public static final int SET_STATUS_FIELD_NUMBER = 1;
/*      */     private List<SetStatusCode> setStatus_;
/* 2873 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheSetResponse(Builder builder)
/*      */     {
/* 2745 */       super();
/*      */     }
/*      */     private MemcacheSetResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse getDefaultInstance() {
/* 2751 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheSetResponse getDefaultInstanceForType() {
/* 2755 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 2760 */       return MemcacheServicePb.internal_static_apphosting_MemcacheSetResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 2765 */       return MemcacheServicePb.internal_static_apphosting_MemcacheSetResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<SetStatusCode> getSetStatusList()
/*      */     {
/* 2848 */       return this.setStatus_;
/*      */     }
/*      */     public int getSetStatusCount() {
/* 2851 */       return this.setStatus_.size();
/*      */     }
/*      */     public SetStatusCode getSetStatus(int index) {
/* 2854 */       return (SetStatusCode)this.setStatus_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 2858 */       this.setStatus_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 2861 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 2866 */       getSerializedSize();
/* 2867 */       for (SetStatusCode element : getSetStatusList()) {
/* 2868 */         output.writeEnum(1, element.getNumber());
/*      */       }
/* 2870 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 2875 */       int size = this.memoizedSerializedSize;
/* 2876 */       if (size != -1) return size;
/*      */ 
/* 2878 */       size = 0;
/*      */ 
/* 2880 */       int dataSize = 0;
/* 2881 */       for (SetStatusCode element : getSetStatusList()) {
/* 2882 */         dataSize += CodedOutputStream.computeEnumSizeNoTag(element.getNumber());
/*      */       }
/*      */ 
/* 2885 */       size += dataSize;
/* 2886 */       size += 1 * getSetStatusList().size();
/*      */ 
/* 2888 */       size += getUnknownFields().getSerializedSize();
/* 2889 */       this.memoizedSerializedSize = size;
/* 2890 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 2895 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2901 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2907 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 2912 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2918 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 2923 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2929 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 2934 */       Builder builder = newBuilder();
/* 2935 */       if (builder.mergeDelimitedFrom(input)) {
/* 2936 */         return builder.buildParsed();
/*      */       }
/* 2938 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2945 */       Builder builder = newBuilder();
/* 2946 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 2947 */         return builder.buildParsed();
/*      */       }
/* 2949 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 2955 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2961 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 2965 */       return Builder.access$6600(); } 
/* 2966 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheSetResponse prototype) {
/* 2968 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 2970 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3172 */       MemcacheServicePb.internalForceInit();
/* 3173 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 3120 */       private List<MemcacheServicePb.MemcacheSetResponse.SetStatusCode> setStatus_ = Collections.emptyList();
/*      */       private boolean isSetStatusMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 2976 */         return MemcacheServicePb.internal_static_apphosting_MemcacheSetResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 2981 */         return MemcacheServicePb.internal_static_apphosting_MemcacheSetResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 2989 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 2993 */         super.clear();
/* 2994 */         this.setStatus_ = Collections.emptyList();
/* 2995 */         this.isSetStatusMutable = false;
/* 2996 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 3000 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 3005 */         return MemcacheServicePb.MemcacheSetResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetResponse getDefaultInstanceForType() {
/* 3009 */         return MemcacheServicePb.MemcacheSetResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetResponse build() {
/* 3013 */         MemcacheServicePb.MemcacheSetResponse result = buildPartial();
/* 3014 */         if (!result.isInitialized()) {
/* 3015 */           throw newUninitializedMessageException(result);
/*      */         }
/* 3017 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheSetResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 3022 */         MemcacheServicePb.MemcacheSetResponse result = buildPartial();
/* 3023 */         if (!result.isInitialized()) {
/* 3024 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 3027 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetResponse buildPartial() {
/* 3031 */         MemcacheServicePb.MemcacheSetResponse result = new MemcacheServicePb.MemcacheSetResponse(this, null);
/* 3032 */         if (this.isSetStatusMutable) {
/* 3033 */           this.setStatus_ = Collections.unmodifiableList(this.setStatus_);
/* 3034 */           this.isSetStatusMutable = false;
/*      */         }
/* 3036 */         MemcacheServicePb.MemcacheSetResponse.access$6802(result, this.setStatus_);
/* 3037 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 3041 */         if ((other instanceof MemcacheServicePb.MemcacheSetResponse)) {
/* 3042 */           return mergeFrom((MemcacheServicePb.MemcacheSetResponse)other);
/*      */         }
/* 3044 */         super.mergeFrom(other);
/* 3045 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheSetResponse other)
/*      */       {
/* 3050 */         if (other == MemcacheServicePb.MemcacheSetResponse.getDefaultInstance()) return this;
/* 3051 */         if (!other.setStatus_.isEmpty()) {
/* 3052 */           if (this.setStatus_.isEmpty()) {
/* 3053 */             this.setStatus_ = other.setStatus_;
/* 3054 */             this.isSetStatusMutable = false;
/*      */           } else {
/* 3056 */             ensureSetStatusIsMutable();
/* 3057 */             this.setStatus_.addAll(other.setStatus_);
/*      */           }
/*      */         }
/* 3060 */         mergeUnknownFields(other.getUnknownFields());
/* 3061 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 3065 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 3072 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 3076 */           int tag = input.readTag();
/* 3077 */           switch (tag) {
/*      */           case 0:
/* 3079 */             setUnknownFields(unknownFields.build());
/* 3080 */             return this;
/*      */           default:
/* 3082 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 3084 */             setUnknownFields(unknownFields.build());
/* 3085 */             return this;
/*      */           case 8:
/* 3090 */             int rawValue = input.readEnum();
/* 3091 */             MemcacheServicePb.MemcacheSetResponse.SetStatusCode value = MemcacheServicePb.MemcacheSetResponse.SetStatusCode.valueOf(rawValue);
/* 3092 */             if (value == null)
/* 3093 */               unknownFields.mergeVarintField(1, rawValue);
/*      */             else {
/* 3095 */               addSetStatus(value);
/*      */             }
/* 3097 */             break;
/*      */           case 10:
/* 3100 */             int length = input.readRawVarint32();
/* 3101 */             int oldLimit = input.pushLimit(length);
/* 3102 */             while (input.getBytesUntilLimit() > 0) {
/* 3103 */               int rawValue = input.readEnum();
/* 3104 */               MemcacheServicePb.MemcacheSetResponse.SetStatusCode value = MemcacheServicePb.MemcacheSetResponse.SetStatusCode.valueOf(rawValue);
/* 3105 */               if (value == null)
/* 3106 */                 unknownFields.mergeVarintField(1, rawValue);
/*      */               else {
/* 3108 */                 addSetStatus(value);
/*      */               }
/*      */             }
/* 3111 */             input.popLimit(oldLimit);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureSetStatusIsMutable()
/*      */       {
/* 3124 */         if (!this.isSetStatusMutable) {
/* 3125 */           this.setStatus_ = new ArrayList(this.setStatus_);
/* 3126 */           this.isSetStatusMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheSetResponse.SetStatusCode> getSetStatusList() {
/* 3130 */         return Collections.unmodifiableList(this.setStatus_);
/*      */       }
/*      */       public int getSetStatusCount() {
/* 3133 */         return this.setStatus_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheSetResponse.SetStatusCode getSetStatus(int index) {
/* 3136 */         return (MemcacheServicePb.MemcacheSetResponse.SetStatusCode)this.setStatus_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setSetStatus(int index, MemcacheServicePb.MemcacheSetResponse.SetStatusCode value) {
/* 3140 */         if (value == null) {
/* 3141 */           throw new NullPointerException();
/*      */         }
/* 3143 */         ensureSetStatusIsMutable();
/* 3144 */         this.setStatus_.set(index, value);
/* 3145 */         return this;
/*      */       }
/*      */       public Builder addSetStatus(MemcacheServicePb.MemcacheSetResponse.SetStatusCode value) {
/* 3148 */         if (value == null) {
/* 3149 */           throw new NullPointerException();
/*      */         }
/* 3151 */         ensureSetStatusIsMutable();
/* 3152 */         this.setStatus_.add(value);
/* 3153 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllSetStatus(Iterable<? extends MemcacheServicePb.MemcacheSetResponse.SetStatusCode> values) {
/* 3157 */         ensureSetStatusIsMutable();
/* 3158 */         GeneratedMessage.Builder.addAll(values, this.setStatus_);
/* 3159 */         return this;
/*      */       }
/*      */       public Builder clearSetStatus() {
/* 3162 */         this.setStatus_ = Collections.emptyList();
/* 3163 */         this.isSetStatusMutable = false;
/* 3164 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum SetStatusCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 2770 */       STORED(0, 1), 
/* 2771 */       NOT_STORED(1, 2), 
/* 2772 */       ERROR(2, 3), 
/* 2773 */       EXISTS(3, 4);
/*      */ 
/*      */       public static final int STORED_VALUE = 1;
/*      */       public static final int NOT_STORED_VALUE = 2;
/*      */       public static final int ERROR_VALUE = 3;
/*      */       public static final int EXISTS_VALUE = 4;
/*      */       private static Internal.EnumLiteMap<SetStatusCode> internalValueMap;
/*      */       private static final SetStatusCode[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/* 2782 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static SetStatusCode valueOf(int value) {
/* 2785 */         switch (value) { case 1:
/* 2786 */           return STORED;
/*      */         case 2:
/* 2787 */           return NOT_STORED;
/*      */         case 3:
/* 2788 */           return ERROR;
/*      */         case 4:
/* 2789 */           return EXISTS; }
/* 2790 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<SetStatusCode> internalGetValueMap()
/*      */       {
/* 2796 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/* 2808 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/* 2812 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/* 2816 */         return (Descriptors.EnumDescriptor)MemcacheServicePb.MemcacheSetResponse.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static SetStatusCode valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/* 2824 */         if (desc.getType() != getDescriptor()) {
/* 2825 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/* 2828 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private SetStatusCode(int index, int value)
/*      */       {
/* 2833 */         this.index = index;
/* 2834 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 2799 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public MemcacheServicePb.MemcacheSetResponse.SetStatusCode findValueByNumber(int number) {
/* 2802 */             return MemcacheServicePb.MemcacheSetResponse.SetStatusCode.valueOf(number);
/*      */           }
/*      */         };
/* 2819 */         VALUES = new SetStatusCode[] { STORED, NOT_STORED, ERROR, EXISTS };
/*      */ 
/* 2838 */         MemcacheServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheSetRequest extends GeneratedMessage
/*      */   {
/* 2733 */     private static final MemcacheSetRequest defaultInstance = new MemcacheSetRequest(true);
/*      */     public static final int ITEM_FIELD_NUMBER = 1;
/*      */     private List<Item> item_;
/*      */     public static final int NAME_SPACE_FIELD_NUMBER = 7;
/*      */     private boolean hasNameSpace;
/*      */     private String nameSpace_;
/* 2406 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheSetRequest(Builder builder)
/*      */     {
/* 1644 */       super();
/*      */     }
/*      */     private MemcacheSetRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest getDefaultInstance() {
/* 1650 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheSetRequest getDefaultInstanceForType() {
/* 1654 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 1659 */       return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 1664 */       return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<Item> getItemList()
/*      */     {
/* 2363 */       return this.item_;
/*      */     }
/*      */     public int getItemCount() {
/* 2366 */       return this.item_.size();
/*      */     }
/*      */     public Item getItem(int index) {
/* 2369 */       return (Item)this.item_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasNameSpace()
/*      */     {
/* 2377 */       return this.hasNameSpace;
/*      */     }
/*      */     public String getNameSpace() {
/* 2380 */       return this.nameSpace_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 2384 */       this.item_ = Collections.emptyList();
/* 2385 */       this.nameSpace_ = "";
/*      */     }
/*      */     public final boolean isInitialized() {
/* 2388 */       for (Item element : getItemList()) {
/* 2389 */         if (!element.isInitialized()) return false;
/*      */       }
/* 2391 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 2396 */       getSerializedSize();
/* 2397 */       for (Item element : getItemList()) {
/* 2398 */         output.writeGroup(1, element);
/*      */       }
/* 2400 */       if (hasNameSpace()) {
/* 2401 */         output.writeString(7, getNameSpace());
/*      */       }
/* 2403 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 2408 */       int size = this.memoizedSerializedSize;
/* 2409 */       if (size != -1) return size;
/*      */ 
/* 2411 */       size = 0;
/* 2412 */       for (Item element : getItemList()) {
/* 2413 */         size += CodedOutputStream.computeGroupSize(1, element);
/*      */       }
/*      */ 
/* 2416 */       if (hasNameSpace()) {
/* 2417 */         size += CodedOutputStream.computeStringSize(7, getNameSpace());
/*      */       }
/*      */ 
/* 2420 */       size += getUnknownFields().getSerializedSize();
/* 2421 */       this.memoizedSerializedSize = size;
/* 2422 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 2427 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2433 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2439 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 2444 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2450 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(InputStream input) throws IOException
/*      */     {
/* 2455 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2461 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 2466 */       Builder builder = newBuilder();
/* 2467 */       if (builder.mergeDelimitedFrom(input)) {
/* 2468 */         return builder.buildParsed();
/*      */       }
/* 2470 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2477 */       Builder builder = newBuilder();
/* 2478 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 2479 */         return builder.buildParsed();
/*      */       }
/* 2481 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 2487 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheSetRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2493 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 2497 */       return Builder.access$5800(); } 
/* 2498 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheSetRequest prototype) {
/* 2500 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 2502 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2734 */       MemcacheServicePb.internalForceInit();
/* 2735 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 2647 */       private List<MemcacheServicePb.MemcacheSetRequest.Item> item_ = Collections.emptyList();
/*      */       private boolean isItemMutable;
/*      */       private boolean hasNameSpace;
/* 2708 */       private String nameSpace_ = "";
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 2508 */         return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 2513 */         return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 2521 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 2525 */         super.clear();
/* 2526 */         this.item_ = Collections.emptyList();
/* 2527 */         this.isItemMutable = false;
/* 2528 */         this.nameSpace_ = "";
/* 2529 */         this.hasNameSpace = false;
/* 2530 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 2534 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 2539 */         return MemcacheServicePb.MemcacheSetRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetRequest getDefaultInstanceForType() {
/* 2543 */         return MemcacheServicePb.MemcacheSetRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetRequest build() {
/* 2547 */         MemcacheServicePb.MemcacheSetRequest result = buildPartial();
/* 2548 */         if (!result.isInitialized()) {
/* 2549 */           throw newUninitializedMessageException(result);
/*      */         }
/* 2551 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheSetRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 2556 */         MemcacheServicePb.MemcacheSetRequest result = buildPartial();
/* 2557 */         if (!result.isInitialized()) {
/* 2558 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 2561 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheSetRequest buildPartial() {
/* 2565 */         MemcacheServicePb.MemcacheSetRequest result = new MemcacheServicePb.MemcacheSetRequest(this, null);
/* 2566 */         if (this.isItemMutable) {
/* 2567 */           this.item_ = Collections.unmodifiableList(this.item_);
/* 2568 */           this.isItemMutable = false;
/*      */         }
/* 2570 */         MemcacheServicePb.MemcacheSetRequest.access$6002(result, this.item_);
/* 2571 */         MemcacheServicePb.MemcacheSetRequest.access$6102(result, this.hasNameSpace);
/* 2572 */         MemcacheServicePb.MemcacheSetRequest.access$6202(result, this.nameSpace_);
/* 2573 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 2577 */         if ((other instanceof MemcacheServicePb.MemcacheSetRequest)) {
/* 2578 */           return mergeFrom((MemcacheServicePb.MemcacheSetRequest)other);
/*      */         }
/* 2580 */         super.mergeFrom(other);
/* 2581 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheSetRequest other)
/*      */       {
/* 2586 */         if (other == MemcacheServicePb.MemcacheSetRequest.getDefaultInstance()) return this;
/* 2587 */         if (!other.item_.isEmpty()) {
/* 2588 */           if (this.item_.isEmpty()) {
/* 2589 */             this.item_ = other.item_;
/* 2590 */             this.isItemMutable = false;
/*      */           } else {
/* 2592 */             ensureItemIsMutable();
/* 2593 */             this.item_.addAll(other.item_);
/*      */           }
/*      */         }
/* 2596 */         if (other.hasNameSpace()) {
/* 2597 */           setNameSpace(other.getNameSpace());
/*      */         }
/* 2599 */         mergeUnknownFields(other.getUnknownFields());
/* 2600 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 2604 */         for (MemcacheServicePb.MemcacheSetRequest.Item element : getItemList()) {
/* 2605 */           if (!element.isInitialized()) return false;
/*      */         }
/* 2607 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 2614 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 2618 */           int tag = input.readTag();
/* 2619 */           switch (tag) {
/*      */           case 0:
/* 2621 */             setUnknownFields(unknownFields.build());
/* 2622 */             return this;
/*      */           default:
/* 2624 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 2626 */             setUnknownFields(unknownFields.build());
/* 2627 */             return this;
/*      */           case 11:
/* 2632 */             MemcacheServicePb.MemcacheSetRequest.Item.Builder subBuilder = MemcacheServicePb.MemcacheSetRequest.Item.newBuilder();
/* 2633 */             input.readGroup(1, subBuilder, extensionRegistry);
/* 2634 */             addItem(subBuilder.buildPartial());
/* 2635 */             break;
/*      */           case 58:
/* 2638 */             setNameSpace(input.readString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureItemIsMutable()
/*      */       {
/* 2651 */         if (!this.isItemMutable) {
/* 2652 */           this.item_ = new ArrayList(this.item_);
/* 2653 */           this.isItemMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheSetRequest.Item> getItemList() {
/* 2657 */         return Collections.unmodifiableList(this.item_);
/*      */       }
/*      */       public int getItemCount() {
/* 2660 */         return this.item_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheSetRequest.Item getItem(int index) {
/* 2663 */         return (MemcacheServicePb.MemcacheSetRequest.Item)this.item_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheSetRequest.Item value) {
/* 2667 */         if (value == null) {
/* 2668 */           throw new NullPointerException();
/*      */         }
/* 2670 */         ensureItemIsMutable();
/* 2671 */         this.item_.set(index, value);
/* 2672 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheSetRequest.Item.Builder builderForValue) {
/* 2676 */         ensureItemIsMutable();
/* 2677 */         this.item_.set(index, builderForValue.build());
/* 2678 */         return this;
/*      */       }
/*      */       public Builder addItem(MemcacheServicePb.MemcacheSetRequest.Item value) {
/* 2681 */         if (value == null) {
/* 2682 */           throw new NullPointerException();
/*      */         }
/* 2684 */         ensureItemIsMutable();
/* 2685 */         this.item_.add(value);
/* 2686 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addItem(MemcacheServicePb.MemcacheSetRequest.Item.Builder builderForValue) {
/* 2690 */         ensureItemIsMutable();
/* 2691 */         this.item_.add(builderForValue.build());
/* 2692 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllItem(Iterable<? extends MemcacheServicePb.MemcacheSetRequest.Item> values) {
/* 2696 */         ensureItemIsMutable();
/* 2697 */         GeneratedMessage.Builder.addAll(values, this.item_);
/* 2698 */         return this;
/*      */       }
/*      */       public Builder clearItem() {
/* 2701 */         this.item_ = Collections.emptyList();
/* 2702 */         this.isItemMutable = false;
/* 2703 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasNameSpace()
/*      */       {
/* 2710 */         return this.hasNameSpace;
/*      */       }
/*      */       public String getNameSpace() {
/* 2713 */         return this.nameSpace_;
/*      */       }
/*      */       public Builder setNameSpace(String value) {
/* 2716 */         if (value == null) {
/* 2717 */           throw new NullPointerException();
/*      */         }
/* 2719 */         this.hasNameSpace = true;
/* 2720 */         this.nameSpace_ = value;
/* 2721 */         return this;
/*      */       }
/*      */       public Builder clearNameSpace() {
/* 2724 */         this.hasNameSpace = false;
/* 2725 */         this.nameSpace_ = MemcacheServicePb.MemcacheSetRequest.getDefaultInstance().getNameSpace();
/* 2726 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static final class Item extends GeneratedMessage
/*      */     {
/* 2351 */       private static final Item defaultInstance = new Item(true);
/*      */       public static final int KEY_FIELD_NUMBER = 2;
/*      */       private boolean hasKey;
/*      */       private ByteString key_;
/*      */       public static final int VALUE_FIELD_NUMBER = 3;
/*      */       private boolean hasValue;
/*      */       private ByteString value_;
/*      */       public static final int FLAGS_FIELD_NUMBER = 4;
/*      */       private boolean hasFlags;
/*      */       private int flags_;
/*      */       public static final int SET_POLICY_FIELD_NUMBER = 5;
/*      */       private boolean hasSetPolicy;
/*      */       private MemcacheServicePb.MemcacheSetRequest.SetPolicy setPolicy_;
/*      */       public static final int EXPIRATION_TIME_FIELD_NUMBER = 6;
/*      */       private boolean hasExpirationTime;
/*      */       private int expirationTime_;
/*      */       public static final int CAS_ID_FIELD_NUMBER = 8;
/*      */       private boolean hasCasId;
/*      */       private long casId_;
/*      */       public static final int FOR_CAS_FIELD_NUMBER = 9;
/*      */       private boolean hasForCas;
/*      */       private boolean forCas_;
/* 1889 */       private int memoizedSerializedSize = -1;
/*      */ 
/*      */       private Item(Builder builder)
/*      */       {
/* 1747 */         super();
/*      */       }
/*      */       private Item(boolean noInit) {
/*      */       }
/*      */ 
/*      */       public static Item getDefaultInstance() {
/* 1753 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public Item getDefaultInstanceForType() {
/* 1757 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 1762 */         return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_Item_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 1767 */         return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_Item_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/* 1775 */         return this.hasKey;
/*      */       }
/*      */       public ByteString getKey() {
/* 1778 */         return this.key_;
/*      */       }
/*      */ 
/*      */       public boolean hasValue()
/*      */       {
/* 1786 */         return this.hasValue;
/*      */       }
/*      */       public ByteString getValue() {
/* 1789 */         return this.value_;
/*      */       }
/*      */ 
/*      */       public boolean hasFlags()
/*      */       {
/* 1797 */         return this.hasFlags;
/*      */       }
/*      */       public int getFlags() {
/* 1800 */         return this.flags_;
/*      */       }
/*      */ 
/*      */       public boolean hasSetPolicy()
/*      */       {
/* 1808 */         return this.hasSetPolicy;
/*      */       }
/*      */       public MemcacheServicePb.MemcacheSetRequest.SetPolicy getSetPolicy() {
/* 1811 */         return this.setPolicy_;
/*      */       }
/*      */ 
/*      */       public boolean hasExpirationTime()
/*      */       {
/* 1819 */         return this.hasExpirationTime;
/*      */       }
/*      */       public int getExpirationTime() {
/* 1822 */         return this.expirationTime_;
/*      */       }
/*      */ 
/*      */       public boolean hasCasId()
/*      */       {
/* 1830 */         return this.hasCasId;
/*      */       }
/*      */       public long getCasId() {
/* 1833 */         return this.casId_;
/*      */       }
/*      */ 
/*      */       public boolean hasForCas()
/*      */       {
/* 1841 */         return this.hasForCas;
/*      */       }
/*      */       public boolean getForCas() {
/* 1844 */         return this.forCas_;
/*      */       }
/*      */ 
/*      */       private void initFields() {
/* 1848 */         this.key_ = ByteString.EMPTY;
/* 1849 */         this.value_ = ByteString.EMPTY;
/* 1850 */         this.flags_ = 0;
/* 1851 */         this.setPolicy_ = MemcacheServicePb.MemcacheSetRequest.SetPolicy.SET;
/* 1852 */         this.expirationTime_ = 0;
/* 1853 */         this.casId_ = 0L;
/* 1854 */         this.forCas_ = false;
/*      */       }
/*      */       public final boolean isInitialized() {
/* 1857 */         if (!this.hasKey) return false;
/* 1858 */         return this.hasValue;
/*      */       }
/*      */ 
/*      */       public void writeTo(CodedOutputStream output)
/*      */         throws IOException
/*      */       {
/* 1864 */         getSerializedSize();
/* 1865 */         if (hasKey()) {
/* 1866 */           output.writeBytes(2, getKey());
/*      */         }
/* 1868 */         if (hasValue()) {
/* 1869 */           output.writeBytes(3, getValue());
/*      */         }
/* 1871 */         if (hasFlags()) {
/* 1872 */           output.writeFixed32(4, getFlags());
/*      */         }
/* 1874 */         if (hasSetPolicy()) {
/* 1875 */           output.writeEnum(5, getSetPolicy().getNumber());
/*      */         }
/* 1877 */         if (hasExpirationTime()) {
/* 1878 */           output.writeFixed32(6, getExpirationTime());
/*      */         }
/* 1880 */         if (hasCasId()) {
/* 1881 */           output.writeFixed64(8, getCasId());
/*      */         }
/* 1883 */         if (hasForCas()) {
/* 1884 */           output.writeBool(9, getForCas());
/*      */         }
/* 1886 */         getUnknownFields().writeTo(output);
/*      */       }
/*      */ 
/*      */       public int getSerializedSize()
/*      */       {
/* 1891 */         int size = this.memoizedSerializedSize;
/* 1892 */         if (size != -1) return size;
/*      */ 
/* 1894 */         size = 0;
/* 1895 */         if (hasKey()) {
/* 1896 */           size += CodedOutputStream.computeBytesSize(2, getKey());
/*      */         }
/*      */ 
/* 1899 */         if (hasValue()) {
/* 1900 */           size += CodedOutputStream.computeBytesSize(3, getValue());
/*      */         }
/*      */ 
/* 1903 */         if (hasFlags()) {
/* 1904 */           size += CodedOutputStream.computeFixed32Size(4, getFlags());
/*      */         }
/*      */ 
/* 1907 */         if (hasSetPolicy()) {
/* 1908 */           size += CodedOutputStream.computeEnumSize(5, getSetPolicy().getNumber());
/*      */         }
/*      */ 
/* 1911 */         if (hasExpirationTime()) {
/* 1912 */           size += CodedOutputStream.computeFixed32Size(6, getExpirationTime());
/*      */         }
/*      */ 
/* 1915 */         if (hasCasId()) {
/* 1916 */           size += CodedOutputStream.computeFixed64Size(8, getCasId());
/*      */         }
/*      */ 
/* 1919 */         if (hasForCas()) {
/* 1920 */           size += CodedOutputStream.computeBoolSize(9, getForCas());
/*      */         }
/*      */ 
/* 1923 */         size += getUnknownFields().getSerializedSize();
/* 1924 */         this.memoizedSerializedSize = size;
/* 1925 */         return size;
/*      */       }
/*      */ 
/*      */       protected Object writeReplace() throws ObjectStreamException
/*      */       {
/* 1930 */         return super.writeReplace();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 1936 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 1942 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */       {
/* 1947 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/* 1953 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input) throws IOException
/*      */       {
/* 1958 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1964 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input) throws IOException
/*      */       {
/* 1969 */         Builder builder = newBuilder();
/* 1970 */         if (builder.mergeDelimitedFrom(input)) {
/* 1971 */           return builder.buildParsed();
/*      */         }
/* 1973 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1980 */         Builder builder = newBuilder();
/* 1981 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 1982 */           return builder.buildParsed();
/*      */         }
/* 1984 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input)
/*      */         throws IOException
/*      */       {
/* 1990 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1996 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Builder newBuilder() {
/* 2000 */         return Builder.access$4100(); } 
/* 2001 */       public Builder newBuilderForType() { return newBuilder(); } 
/*      */       public static Builder newBuilder(Item prototype) {
/* 2003 */         return newBuilder().mergeFrom(prototype);
/*      */       }
/* 2005 */       public Builder toBuilder() { return newBuilder(this);
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 2352 */         MemcacheServicePb.internalForceInit();
/* 2353 */         defaultInstance.initFields();
/*      */       }
/*      */ 
/*      */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */       {
/*      */         private boolean hasKey;
/* 2200 */         private ByteString key_ = ByteString.EMPTY;
/*      */         private boolean hasValue;
/* 2223 */         private ByteString value_ = ByteString.EMPTY;
/*      */         private boolean hasFlags;
/*      */         private int flags_;
/*      */         private boolean hasSetPolicy;
/* 2266 */         private MemcacheServicePb.MemcacheSetRequest.SetPolicy setPolicy_ = MemcacheServicePb.MemcacheSetRequest.SetPolicy.SET;
/*      */         private boolean hasExpirationTime;
/*      */         private int expirationTime_;
/*      */         private boolean hasCasId;
/*      */         private long casId_;
/*      */         private boolean hasForCas;
/*      */         private boolean forCas_;
/*      */ 
/*      */         public static final Descriptors.Descriptor getDescriptor()
/*      */         {
/* 2011 */           return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_Item_descriptor;
/*      */         }
/*      */ 
/*      */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */         {
/* 2016 */           return MemcacheServicePb.internal_static_apphosting_MemcacheSetRequest_Item_fieldAccessorTable;
/*      */         }
/*      */ 
/*      */         private static Builder create()
/*      */         {
/* 2024 */           return new Builder();
/*      */         }
/*      */ 
/*      */         public Builder clear() {
/* 2028 */           super.clear();
/* 2029 */           this.key_ = ByteString.EMPTY;
/* 2030 */           this.hasKey = false;
/* 2031 */           this.value_ = ByteString.EMPTY;
/* 2032 */           this.hasValue = false;
/* 2033 */           this.flags_ = 0;
/* 2034 */           this.hasFlags = false;
/* 2035 */           this.setPolicy_ = MemcacheServicePb.MemcacheSetRequest.SetPolicy.SET;
/* 2036 */           this.hasSetPolicy = false;
/* 2037 */           this.expirationTime_ = 0;
/* 2038 */           this.hasExpirationTime = false;
/* 2039 */           this.casId_ = 0L;
/* 2040 */           this.hasCasId = false;
/* 2041 */           this.forCas_ = false;
/* 2042 */           this.hasForCas = false;
/* 2043 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder clone() {
/* 2047 */           return create().mergeFrom(buildPartial());
/*      */         }
/*      */ 
/*      */         public Descriptors.Descriptor getDescriptorForType()
/*      */         {
/* 2052 */           return MemcacheServicePb.MemcacheSetRequest.Item.getDescriptor();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheSetRequest.Item getDefaultInstanceForType() {
/* 2056 */           return MemcacheServicePb.MemcacheSetRequest.Item.getDefaultInstance();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheSetRequest.Item build() {
/* 2060 */           MemcacheServicePb.MemcacheSetRequest.Item result = buildPartial();
/* 2061 */           if (!result.isInitialized()) {
/* 2062 */             throw newUninitializedMessageException(result);
/*      */           }
/* 2064 */           return result;
/*      */         }
/*      */ 
/*      */         private MemcacheServicePb.MemcacheSetRequest.Item buildParsed() throws InvalidProtocolBufferException
/*      */         {
/* 2069 */           MemcacheServicePb.MemcacheSetRequest.Item result = buildPartial();
/* 2070 */           if (!result.isInitialized()) {
/* 2071 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */           }
/*      */ 
/* 2074 */           return result;
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheSetRequest.Item buildPartial() {
/* 2078 */           MemcacheServicePb.MemcacheSetRequest.Item result = new MemcacheServicePb.MemcacheSetRequest.Item(this, null);
/* 2079 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4302(result, this.hasKey);
/* 2080 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4402(result, this.key_);
/* 2081 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4502(result, this.hasValue);
/* 2082 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4602(result, this.value_);
/* 2083 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4702(result, this.hasFlags);
/* 2084 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4802(result, this.flags_);
/* 2085 */           MemcacheServicePb.MemcacheSetRequest.Item.access$4902(result, this.hasSetPolicy);
/* 2086 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5002(result, this.setPolicy_);
/* 2087 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5102(result, this.hasExpirationTime);
/* 2088 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5202(result, this.expirationTime_);
/* 2089 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5302(result, this.hasCasId);
/* 2090 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5402(result, this.casId_);
/* 2091 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5502(result, this.hasForCas);
/* 2092 */           MemcacheServicePb.MemcacheSetRequest.Item.access$5602(result, this.forCas_);
/* 2093 */           return result;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(Message other) {
/* 2097 */           if ((other instanceof MemcacheServicePb.MemcacheSetRequest.Item)) {
/* 2098 */             return mergeFrom((MemcacheServicePb.MemcacheSetRequest.Item)other);
/*      */           }
/* 2100 */           super.mergeFrom(other);
/* 2101 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(MemcacheServicePb.MemcacheSetRequest.Item other)
/*      */         {
/* 2106 */           if (other == MemcacheServicePb.MemcacheSetRequest.Item.getDefaultInstance()) return this;
/* 2107 */           if (other.hasKey()) {
/* 2108 */             setKey(other.getKey());
/*      */           }
/* 2110 */           if (other.hasValue()) {
/* 2111 */             setValue(other.getValue());
/*      */           }
/* 2113 */           if (other.hasFlags()) {
/* 2114 */             setFlags(other.getFlags());
/*      */           }
/* 2116 */           if (other.hasSetPolicy()) {
/* 2117 */             setSetPolicy(other.getSetPolicy());
/*      */           }
/* 2119 */           if (other.hasExpirationTime()) {
/* 2120 */             setExpirationTime(other.getExpirationTime());
/*      */           }
/* 2122 */           if (other.hasCasId()) {
/* 2123 */             setCasId(other.getCasId());
/*      */           }
/* 2125 */           if (other.hasForCas()) {
/* 2126 */             setForCas(other.getForCas());
/*      */           }
/* 2128 */           mergeUnknownFields(other.getUnknownFields());
/* 2129 */           return this;
/*      */         }
/*      */ 
/*      */         public final boolean isInitialized() {
/* 2133 */           if (!this.hasKey) return false;
/* 2134 */           return this.hasValue;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */           throws IOException
/*      */         {
/* 2142 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */           while (true)
/*      */           {
/* 2146 */             int tag = input.readTag();
/* 2147 */             switch (tag) {
/*      */             case 0:
/* 2149 */               setUnknownFields(unknownFields.build());
/* 2150 */               return this;
/*      */             default:
/* 2152 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */                 break;
/* 2154 */               setUnknownFields(unknownFields.build());
/* 2155 */               return this;
/*      */             case 18:
/* 2160 */               setKey(input.readBytes());
/* 2161 */               break;
/*      */             case 26:
/* 2164 */               setValue(input.readBytes());
/* 2165 */               break;
/*      */             case 37:
/* 2168 */               setFlags(input.readFixed32());
/* 2169 */               break;
/*      */             case 40:
/* 2172 */               int rawValue = input.readEnum();
/* 2173 */               MemcacheServicePb.MemcacheSetRequest.SetPolicy value = MemcacheServicePb.MemcacheSetRequest.SetPolicy.valueOf(rawValue);
/* 2174 */               if (value == null)
/* 2175 */                 unknownFields.mergeVarintField(5, rawValue);
/*      */               else {
/* 2177 */                 setSetPolicy(value);
/*      */               }
/* 2179 */               break;
/*      */             case 53:
/* 2182 */               setExpirationTime(input.readFixed32());
/* 2183 */               break;
/*      */             case 65:
/* 2186 */               setCasId(input.readFixed64());
/* 2187 */               break;
/*      */             case 72:
/* 2190 */               setForCas(input.readBool());
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         public boolean hasKey()
/*      */         {
/* 2202 */           return this.hasKey;
/*      */         }
/*      */         public ByteString getKey() {
/* 2205 */           return this.key_;
/*      */         }
/*      */         public Builder setKey(ByteString value) {
/* 2208 */           if (value == null) {
/* 2209 */             throw new NullPointerException();
/*      */           }
/* 2211 */           this.hasKey = true;
/* 2212 */           this.key_ = value;
/* 2213 */           return this;
/*      */         }
/*      */         public Builder clearKey() {
/* 2216 */           this.hasKey = false;
/* 2217 */           this.key_ = MemcacheServicePb.MemcacheSetRequest.Item.getDefaultInstance().getKey();
/* 2218 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasValue()
/*      */         {
/* 2225 */           return this.hasValue;
/*      */         }
/*      */         public ByteString getValue() {
/* 2228 */           return this.value_;
/*      */         }
/*      */         public Builder setValue(ByteString value) {
/* 2231 */           if (value == null) {
/* 2232 */             throw new NullPointerException();
/*      */           }
/* 2234 */           this.hasValue = true;
/* 2235 */           this.value_ = value;
/* 2236 */           return this;
/*      */         }
/*      */         public Builder clearValue() {
/* 2239 */           this.hasValue = false;
/* 2240 */           this.value_ = MemcacheServicePb.MemcacheSetRequest.Item.getDefaultInstance().getValue();
/* 2241 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasFlags()
/*      */         {
/* 2248 */           return this.hasFlags;
/*      */         }
/*      */         public int getFlags() {
/* 2251 */           return this.flags_;
/*      */         }
/*      */         public Builder setFlags(int value) {
/* 2254 */           this.hasFlags = true;
/* 2255 */           this.flags_ = value;
/* 2256 */           return this;
/*      */         }
/*      */         public Builder clearFlags() {
/* 2259 */           this.hasFlags = false;
/* 2260 */           this.flags_ = 0;
/* 2261 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasSetPolicy()
/*      */         {
/* 2268 */           return this.hasSetPolicy;
/*      */         }
/*      */         public MemcacheServicePb.MemcacheSetRequest.SetPolicy getSetPolicy() {
/* 2271 */           return this.setPolicy_;
/*      */         }
/*      */         public Builder setSetPolicy(MemcacheServicePb.MemcacheSetRequest.SetPolicy value) {
/* 2274 */           if (value == null) {
/* 2275 */             throw new NullPointerException();
/*      */           }
/* 2277 */           this.hasSetPolicy = true;
/* 2278 */           this.setPolicy_ = value;
/* 2279 */           return this;
/*      */         }
/*      */         public Builder clearSetPolicy() {
/* 2282 */           this.hasSetPolicy = false;
/* 2283 */           this.setPolicy_ = MemcacheServicePb.MemcacheSetRequest.SetPolicy.SET;
/* 2284 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasExpirationTime()
/*      */         {
/* 2291 */           return this.hasExpirationTime;
/*      */         }
/*      */         public int getExpirationTime() {
/* 2294 */           return this.expirationTime_;
/*      */         }
/*      */         public Builder setExpirationTime(int value) {
/* 2297 */           this.hasExpirationTime = true;
/* 2298 */           this.expirationTime_ = value;
/* 2299 */           return this;
/*      */         }
/*      */         public Builder clearExpirationTime() {
/* 2302 */           this.hasExpirationTime = false;
/* 2303 */           this.expirationTime_ = 0;
/* 2304 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasCasId()
/*      */         {
/* 2311 */           return this.hasCasId;
/*      */         }
/*      */         public long getCasId() {
/* 2314 */           return this.casId_;
/*      */         }
/*      */         public Builder setCasId(long value) {
/* 2317 */           this.hasCasId = true;
/* 2318 */           this.casId_ = value;
/* 2319 */           return this;
/*      */         }
/*      */         public Builder clearCasId() {
/* 2322 */           this.hasCasId = false;
/* 2323 */           this.casId_ = 0L;
/* 2324 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasForCas()
/*      */         {
/* 2331 */           return this.hasForCas;
/*      */         }
/*      */         public boolean getForCas() {
/* 2334 */           return this.forCas_;
/*      */         }
/*      */         public Builder setForCas(boolean value) {
/* 2337 */           this.hasForCas = true;
/* 2338 */           this.forCas_ = value;
/* 2339 */           return this;
/*      */         }
/*      */         public Builder clearForCas() {
/* 2342 */           this.hasForCas = false;
/* 2343 */           this.forCas_ = false;
/* 2344 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum SetPolicy
/*      */       implements ProtocolMessageEnum
/*      */     {
/* 1669 */       SET(0, 1), 
/* 1670 */       ADD(1, 2), 
/* 1671 */       REPLACE(2, 3), 
/* 1672 */       CAS(3, 4);
/*      */ 
/*      */       public static final int SET_VALUE = 1;
/*      */       public static final int ADD_VALUE = 2;
/*      */       public static final int REPLACE_VALUE = 3;
/*      */       public static final int CAS_VALUE = 4;
/*      */       private static Internal.EnumLiteMap<SetPolicy> internalValueMap;
/*      */       private static final SetPolicy[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/* 1681 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static SetPolicy valueOf(int value) {
/* 1684 */         switch (value) { case 1:
/* 1685 */           return SET;
/*      */         case 2:
/* 1686 */           return ADD;
/*      */         case 3:
/* 1687 */           return REPLACE;
/*      */         case 4:
/* 1688 */           return CAS; }
/* 1689 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<SetPolicy> internalGetValueMap()
/*      */       {
/* 1695 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/* 1707 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/* 1711 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/* 1715 */         return (Descriptors.EnumDescriptor)MemcacheServicePb.MemcacheSetRequest.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static SetPolicy valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/* 1723 */         if (desc.getType() != getDescriptor()) {
/* 1724 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/* 1727 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private SetPolicy(int index, int value)
/*      */       {
/* 1732 */         this.index = index;
/* 1733 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1698 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public MemcacheServicePb.MemcacheSetRequest.SetPolicy findValueByNumber(int number) {
/* 1701 */             return MemcacheServicePb.MemcacheSetRequest.SetPolicy.valueOf(number);
/*      */           }
/*      */         };
/* 1718 */         VALUES = new SetPolicy[] { SET, ADD, REPLACE, CAS };
/*      */ 
/* 1737 */         MemcacheServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheGetResponse extends GeneratedMessage
/*      */   {
/* 1632 */     private static final MemcacheGetResponse defaultInstance = new MemcacheGetResponse(true);
/*      */     public static final int ITEM_FIELD_NUMBER = 1;
/*      */     private List<Item> item_;
/* 1343 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheGetResponse(Builder builder)
/*      */     {
/*  781 */       super();
/*      */     }
/*      */     private MemcacheGetResponse(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse getDefaultInstance() {
/*  787 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheGetResponse getDefaultInstanceForType() {
/*  791 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  796 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  801 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<Item> getItemList()
/*      */     {
/* 1315 */       return this.item_;
/*      */     }
/*      */     public int getItemCount() {
/* 1318 */       return this.item_.size();
/*      */     }
/*      */     public Item getItem(int index) {
/* 1321 */       return (Item)this.item_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 1325 */       this.item_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 1328 */       for (Item element : getItemList()) {
/* 1329 */         if (!element.isInitialized()) return false;
/*      */       }
/* 1331 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 1336 */       getSerializedSize();
/* 1337 */       for (Item element : getItemList()) {
/* 1338 */         output.writeGroup(1, element);
/*      */       }
/* 1340 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 1345 */       int size = this.memoizedSerializedSize;
/* 1346 */       if (size != -1) return size;
/*      */ 
/* 1348 */       size = 0;
/* 1349 */       for (Item element : getItemList()) {
/* 1350 */         size += CodedOutputStream.computeGroupSize(1, element);
/*      */       }
/*      */ 
/* 1353 */       size += getUnknownFields().getSerializedSize();
/* 1354 */       this.memoizedSerializedSize = size;
/* 1355 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 1360 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 1366 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 1372 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 1377 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 1383 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(InputStream input) throws IOException
/*      */     {
/* 1388 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1394 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 1399 */       Builder builder = newBuilder();
/* 1400 */       if (builder.mergeDelimitedFrom(input)) {
/* 1401 */         return builder.buildParsed();
/*      */       }
/* 1403 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1410 */       Builder builder = newBuilder();
/* 1411 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 1412 */         return builder.buildParsed();
/*      */       }
/* 1414 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 1420 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetResponse parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1426 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 1430 */       return Builder.access$3300(); } 
/* 1431 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheGetResponse prototype) {
/* 1433 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 1435 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1633 */       MemcacheServicePb.internalForceInit();
/* 1634 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/* 1569 */       private List<MemcacheServicePb.MemcacheGetResponse.Item> item_ = Collections.emptyList();
/*      */       private boolean isItemMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 1441 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 1446 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 1454 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 1458 */         super.clear();
/* 1459 */         this.item_ = Collections.emptyList();
/* 1460 */         this.isItemMutable = false;
/* 1461 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 1465 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 1470 */         return MemcacheServicePb.MemcacheGetResponse.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetResponse getDefaultInstanceForType() {
/* 1474 */         return MemcacheServicePb.MemcacheGetResponse.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetResponse build() {
/* 1478 */         MemcacheServicePb.MemcacheGetResponse result = buildPartial();
/* 1479 */         if (!result.isInitialized()) {
/* 1480 */           throw newUninitializedMessageException(result);
/*      */         }
/* 1482 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheGetResponse buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 1487 */         MemcacheServicePb.MemcacheGetResponse result = buildPartial();
/* 1488 */         if (!result.isInitialized()) {
/* 1489 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 1492 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetResponse buildPartial() {
/* 1496 */         MemcacheServicePb.MemcacheGetResponse result = new MemcacheServicePb.MemcacheGetResponse(this, null);
/* 1497 */         if (this.isItemMutable) {
/* 1498 */           this.item_ = Collections.unmodifiableList(this.item_);
/* 1499 */           this.isItemMutable = false;
/*      */         }
/* 1501 */         MemcacheServicePb.MemcacheGetResponse.access$3502(result, this.item_);
/* 1502 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 1506 */         if ((other instanceof MemcacheServicePb.MemcacheGetResponse)) {
/* 1507 */           return mergeFrom((MemcacheServicePb.MemcacheGetResponse)other);
/*      */         }
/* 1509 */         super.mergeFrom(other);
/* 1510 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheGetResponse other)
/*      */       {
/* 1515 */         if (other == MemcacheServicePb.MemcacheGetResponse.getDefaultInstance()) return this;
/* 1516 */         if (!other.item_.isEmpty()) {
/* 1517 */           if (this.item_.isEmpty()) {
/* 1518 */             this.item_ = other.item_;
/* 1519 */             this.isItemMutable = false;
/*      */           } else {
/* 1521 */             ensureItemIsMutable();
/* 1522 */             this.item_.addAll(other.item_);
/*      */           }
/*      */         }
/* 1525 */         mergeUnknownFields(other.getUnknownFields());
/* 1526 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 1530 */         for (MemcacheServicePb.MemcacheGetResponse.Item element : getItemList()) {
/* 1531 */           if (!element.isInitialized()) return false;
/*      */         }
/* 1533 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1540 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 1544 */           int tag = input.readTag();
/* 1545 */           switch (tag) {
/*      */           case 0:
/* 1547 */             setUnknownFields(unknownFields.build());
/* 1548 */             return this;
/*      */           default:
/* 1550 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 1552 */             setUnknownFields(unknownFields.build());
/* 1553 */             return this;
/*      */           case 11:
/* 1558 */             MemcacheServicePb.MemcacheGetResponse.Item.Builder subBuilder = MemcacheServicePb.MemcacheGetResponse.Item.newBuilder();
/* 1559 */             input.readGroup(1, subBuilder, extensionRegistry);
/* 1560 */             addItem(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureItemIsMutable()
/*      */       {
/* 1573 */         if (!this.isItemMutable) {
/* 1574 */           this.item_ = new ArrayList(this.item_);
/* 1575 */           this.isItemMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<MemcacheServicePb.MemcacheGetResponse.Item> getItemList() {
/* 1579 */         return Collections.unmodifiableList(this.item_);
/*      */       }
/*      */       public int getItemCount() {
/* 1582 */         return this.item_.size();
/*      */       }
/*      */       public MemcacheServicePb.MemcacheGetResponse.Item getItem(int index) {
/* 1585 */         return (MemcacheServicePb.MemcacheGetResponse.Item)this.item_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheGetResponse.Item value) {
/* 1589 */         if (value == null) {
/* 1590 */           throw new NullPointerException();
/*      */         }
/* 1592 */         ensureItemIsMutable();
/* 1593 */         this.item_.set(index, value);
/* 1594 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setItem(int index, MemcacheServicePb.MemcacheGetResponse.Item.Builder builderForValue) {
/* 1598 */         ensureItemIsMutable();
/* 1599 */         this.item_.set(index, builderForValue.build());
/* 1600 */         return this;
/*      */       }
/*      */       public Builder addItem(MemcacheServicePb.MemcacheGetResponse.Item value) {
/* 1603 */         if (value == null) {
/* 1604 */           throw new NullPointerException();
/*      */         }
/* 1606 */         ensureItemIsMutable();
/* 1607 */         this.item_.add(value);
/* 1608 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addItem(MemcacheServicePb.MemcacheGetResponse.Item.Builder builderForValue) {
/* 1612 */         ensureItemIsMutable();
/* 1613 */         this.item_.add(builderForValue.build());
/* 1614 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllItem(Iterable<? extends MemcacheServicePb.MemcacheGetResponse.Item> values) {
/* 1618 */         ensureItemIsMutable();
/* 1619 */         GeneratedMessage.Builder.addAll(values, this.item_);
/* 1620 */         return this;
/*      */       }
/*      */       public Builder clearItem() {
/* 1623 */         this.item_ = Collections.emptyList();
/* 1624 */         this.isItemMutable = false;
/* 1625 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static final class Item extends GeneratedMessage
/*      */     {
/* 1303 */       private static final Item defaultInstance = new Item(true);
/*      */       public static final int KEY_FIELD_NUMBER = 2;
/*      */       private boolean hasKey;
/*      */       private ByteString key_;
/*      */       public static final int VALUE_FIELD_NUMBER = 3;
/*      */       private boolean hasValue;
/*      */       private ByteString value_;
/*      */       public static final int FLAGS_FIELD_NUMBER = 4;
/*      */       private boolean hasFlags;
/*      */       private int flags_;
/*      */       public static final int CAS_ID_FIELD_NUMBER = 5;
/*      */       private boolean hasCasId;
/*      */       private long casId_;
/*      */       public static final int EXPIRES_IN_SECONDS_FIELD_NUMBER = 6;
/*      */       private boolean hasExpiresInSeconds;
/*      */       private int expiresInSeconds_;
/*  920 */       private int memoizedSerializedSize = -1;
/*      */ 
/*      */       private Item(Builder builder)
/*      */       {
/*  808 */         super();
/*      */       }
/*      */       private Item(boolean noInit) {
/*      */       }
/*      */ 
/*      */       public static Item getDefaultInstance() {
/*  814 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public Item getDefaultInstanceForType() {
/*  818 */         return defaultInstance;
/*      */       }
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  823 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_Item_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  828 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_Item_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/*  836 */         return this.hasKey;
/*      */       }
/*      */       public ByteString getKey() {
/*  839 */         return this.key_;
/*      */       }
/*      */ 
/*      */       public boolean hasValue()
/*      */       {
/*  847 */         return this.hasValue;
/*      */       }
/*      */       public ByteString getValue() {
/*  850 */         return this.value_;
/*      */       }
/*      */ 
/*      */       public boolean hasFlags()
/*      */       {
/*  858 */         return this.hasFlags;
/*      */       }
/*      */       public int getFlags() {
/*  861 */         return this.flags_;
/*      */       }
/*      */ 
/*      */       public boolean hasCasId()
/*      */       {
/*  869 */         return this.hasCasId;
/*      */       }
/*      */       public long getCasId() {
/*  872 */         return this.casId_;
/*      */       }
/*      */ 
/*      */       public boolean hasExpiresInSeconds()
/*      */       {
/*  880 */         return this.hasExpiresInSeconds;
/*      */       }
/*      */       public int getExpiresInSeconds() {
/*  883 */         return this.expiresInSeconds_;
/*      */       }
/*      */ 
/*      */       private void initFields() {
/*  887 */         this.key_ = ByteString.EMPTY;
/*  888 */         this.value_ = ByteString.EMPTY;
/*  889 */         this.flags_ = 0;
/*  890 */         this.casId_ = 0L;
/*  891 */         this.expiresInSeconds_ = 0;
/*      */       }
/*      */       public final boolean isInitialized() {
/*  894 */         if (!this.hasKey) return false;
/*  895 */         return this.hasValue;
/*      */       }
/*      */ 
/*      */       public void writeTo(CodedOutputStream output)
/*      */         throws IOException
/*      */       {
/*  901 */         getSerializedSize();
/*  902 */         if (hasKey()) {
/*  903 */           output.writeBytes(2, getKey());
/*      */         }
/*  905 */         if (hasValue()) {
/*  906 */           output.writeBytes(3, getValue());
/*      */         }
/*  908 */         if (hasFlags()) {
/*  909 */           output.writeFixed32(4, getFlags());
/*      */         }
/*  911 */         if (hasCasId()) {
/*  912 */           output.writeFixed64(5, getCasId());
/*      */         }
/*  914 */         if (hasExpiresInSeconds()) {
/*  915 */           output.writeInt32(6, getExpiresInSeconds());
/*      */         }
/*  917 */         getUnknownFields().writeTo(output);
/*      */       }
/*      */ 
/*      */       public int getSerializedSize()
/*      */       {
/*  922 */         int size = this.memoizedSerializedSize;
/*  923 */         if (size != -1) return size;
/*      */ 
/*  925 */         size = 0;
/*  926 */         if (hasKey()) {
/*  927 */           size += CodedOutputStream.computeBytesSize(2, getKey());
/*      */         }
/*      */ 
/*  930 */         if (hasValue()) {
/*  931 */           size += CodedOutputStream.computeBytesSize(3, getValue());
/*      */         }
/*      */ 
/*  934 */         if (hasFlags()) {
/*  935 */           size += CodedOutputStream.computeFixed32Size(4, getFlags());
/*      */         }
/*      */ 
/*  938 */         if (hasCasId()) {
/*  939 */           size += CodedOutputStream.computeFixed64Size(5, getCasId());
/*      */         }
/*      */ 
/*  942 */         if (hasExpiresInSeconds()) {
/*  943 */           size += CodedOutputStream.computeInt32Size(6, getExpiresInSeconds());
/*      */         }
/*      */ 
/*  946 */         size += getUnknownFields().getSerializedSize();
/*  947 */         this.memoizedSerializedSize = size;
/*  948 */         return size;
/*      */       }
/*      */ 
/*      */       protected Object writeReplace() throws ObjectStreamException
/*      */       {
/*  953 */         return super.writeReplace();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/*  959 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/*  965 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */       {
/*  970 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */         throws InvalidProtocolBufferException
/*      */       {
/*  976 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input) throws IOException
/*      */       {
/*  981 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  987 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input) throws IOException
/*      */       {
/*  992 */         Builder builder = newBuilder();
/*  993 */         if (builder.mergeDelimitedFrom(input)) {
/*  994 */           return builder.buildParsed();
/*      */         }
/*  996 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1003 */         Builder builder = newBuilder();
/* 1004 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 1005 */           return builder.buildParsed();
/*      */         }
/* 1007 */         return null;
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input)
/*      */         throws IOException
/*      */       {
/* 1013 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Item parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1019 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */       }
/*      */ 
/*      */       public static Builder newBuilder() {
/* 1023 */         return Builder.access$2000(); } 
/* 1024 */       public Builder newBuilderForType() { return newBuilder(); } 
/*      */       public static Builder newBuilder(Item prototype) {
/* 1026 */         return newBuilder().mergeFrom(prototype);
/*      */       }
/* 1028 */       public Builder toBuilder() { return newBuilder(this);
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/* 1304 */         MemcacheServicePb.internalForceInit();
/* 1305 */         defaultInstance.initFields();
/*      */       }
/*      */ 
/*      */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */       {
/*      */         private boolean hasKey;
/* 1195 */         private ByteString key_ = ByteString.EMPTY;
/*      */         private boolean hasValue;
/* 1218 */         private ByteString value_ = ByteString.EMPTY;
/*      */         private boolean hasFlags;
/*      */         private int flags_;
/*      */         private boolean hasCasId;
/*      */         private long casId_;
/*      */         private boolean hasExpiresInSeconds;
/*      */         private int expiresInSeconds_;
/*      */ 
/*      */         public static final Descriptors.Descriptor getDescriptor()
/*      */         {
/* 1034 */           return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_Item_descriptor;
/*      */         }
/*      */ 
/*      */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */         {
/* 1039 */           return MemcacheServicePb.internal_static_apphosting_MemcacheGetResponse_Item_fieldAccessorTable;
/*      */         }
/*      */ 
/*      */         private static Builder create()
/*      */         {
/* 1047 */           return new Builder();
/*      */         }
/*      */ 
/*      */         public Builder clear() {
/* 1051 */           super.clear();
/* 1052 */           this.key_ = ByteString.EMPTY;
/* 1053 */           this.hasKey = false;
/* 1054 */           this.value_ = ByteString.EMPTY;
/* 1055 */           this.hasValue = false;
/* 1056 */           this.flags_ = 0;
/* 1057 */           this.hasFlags = false;
/* 1058 */           this.casId_ = 0L;
/* 1059 */           this.hasCasId = false;
/* 1060 */           this.expiresInSeconds_ = 0;
/* 1061 */           this.hasExpiresInSeconds = false;
/* 1062 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder clone() {
/* 1066 */           return create().mergeFrom(buildPartial());
/*      */         }
/*      */ 
/*      */         public Descriptors.Descriptor getDescriptorForType()
/*      */         {
/* 1071 */           return MemcacheServicePb.MemcacheGetResponse.Item.getDescriptor();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheGetResponse.Item getDefaultInstanceForType() {
/* 1075 */           return MemcacheServicePb.MemcacheGetResponse.Item.getDefaultInstance();
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheGetResponse.Item build() {
/* 1079 */           MemcacheServicePb.MemcacheGetResponse.Item result = buildPartial();
/* 1080 */           if (!result.isInitialized()) {
/* 1081 */             throw newUninitializedMessageException(result);
/*      */           }
/* 1083 */           return result;
/*      */         }
/*      */ 
/*      */         private MemcacheServicePb.MemcacheGetResponse.Item buildParsed() throws InvalidProtocolBufferException
/*      */         {
/* 1088 */           MemcacheServicePb.MemcacheGetResponse.Item result = buildPartial();
/* 1089 */           if (!result.isInitialized()) {
/* 1090 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */           }
/*      */ 
/* 1093 */           return result;
/*      */         }
/*      */ 
/*      */         public MemcacheServicePb.MemcacheGetResponse.Item buildPartial() {
/* 1097 */           MemcacheServicePb.MemcacheGetResponse.Item result = new MemcacheServicePb.MemcacheGetResponse.Item(this, null);
/* 1098 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2202(result, this.hasKey);
/* 1099 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2302(result, this.key_);
/* 1100 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2402(result, this.hasValue);
/* 1101 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2502(result, this.value_);
/* 1102 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2602(result, this.hasFlags);
/* 1103 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2702(result, this.flags_);
/* 1104 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2802(result, this.hasCasId);
/* 1105 */           MemcacheServicePb.MemcacheGetResponse.Item.access$2902(result, this.casId_);
/* 1106 */           MemcacheServicePb.MemcacheGetResponse.Item.access$3002(result, this.hasExpiresInSeconds);
/* 1107 */           MemcacheServicePb.MemcacheGetResponse.Item.access$3102(result, this.expiresInSeconds_);
/* 1108 */           return result;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(Message other) {
/* 1112 */           if ((other instanceof MemcacheServicePb.MemcacheGetResponse.Item)) {
/* 1113 */             return mergeFrom((MemcacheServicePb.MemcacheGetResponse.Item)other);
/*      */           }
/* 1115 */           super.mergeFrom(other);
/* 1116 */           return this;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(MemcacheServicePb.MemcacheGetResponse.Item other)
/*      */         {
/* 1121 */           if (other == MemcacheServicePb.MemcacheGetResponse.Item.getDefaultInstance()) return this;
/* 1122 */           if (other.hasKey()) {
/* 1123 */             setKey(other.getKey());
/*      */           }
/* 1125 */           if (other.hasValue()) {
/* 1126 */             setValue(other.getValue());
/*      */           }
/* 1128 */           if (other.hasFlags()) {
/* 1129 */             setFlags(other.getFlags());
/*      */           }
/* 1131 */           if (other.hasCasId()) {
/* 1132 */             setCasId(other.getCasId());
/*      */           }
/* 1134 */           if (other.hasExpiresInSeconds()) {
/* 1135 */             setExpiresInSeconds(other.getExpiresInSeconds());
/*      */           }
/* 1137 */           mergeUnknownFields(other.getUnknownFields());
/* 1138 */           return this;
/*      */         }
/*      */ 
/*      */         public final boolean isInitialized() {
/* 1142 */           if (!this.hasKey) return false;
/* 1143 */           return this.hasValue;
/*      */         }
/*      */ 
/*      */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */           throws IOException
/*      */         {
/* 1151 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */           while (true)
/*      */           {
/* 1155 */             int tag = input.readTag();
/* 1156 */             switch (tag) {
/*      */             case 0:
/* 1158 */               setUnknownFields(unknownFields.build());
/* 1159 */               return this;
/*      */             default:
/* 1161 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */                 break;
/* 1163 */               setUnknownFields(unknownFields.build());
/* 1164 */               return this;
/*      */             case 18:
/* 1169 */               setKey(input.readBytes());
/* 1170 */               break;
/*      */             case 26:
/* 1173 */               setValue(input.readBytes());
/* 1174 */               break;
/*      */             case 37:
/* 1177 */               setFlags(input.readFixed32());
/* 1178 */               break;
/*      */             case 41:
/* 1181 */               setCasId(input.readFixed64());
/* 1182 */               break;
/*      */             case 48:
/* 1185 */               setExpiresInSeconds(input.readInt32());
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         public boolean hasKey()
/*      */         {
/* 1197 */           return this.hasKey;
/*      */         }
/*      */         public ByteString getKey() {
/* 1200 */           return this.key_;
/*      */         }
/*      */         public Builder setKey(ByteString value) {
/* 1203 */           if (value == null) {
/* 1204 */             throw new NullPointerException();
/*      */           }
/* 1206 */           this.hasKey = true;
/* 1207 */           this.key_ = value;
/* 1208 */           return this;
/*      */         }
/*      */         public Builder clearKey() {
/* 1211 */           this.hasKey = false;
/* 1212 */           this.key_ = MemcacheServicePb.MemcacheGetResponse.Item.getDefaultInstance().getKey();
/* 1213 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasValue()
/*      */         {
/* 1220 */           return this.hasValue;
/*      */         }
/*      */         public ByteString getValue() {
/* 1223 */           return this.value_;
/*      */         }
/*      */         public Builder setValue(ByteString value) {
/* 1226 */           if (value == null) {
/* 1227 */             throw new NullPointerException();
/*      */           }
/* 1229 */           this.hasValue = true;
/* 1230 */           this.value_ = value;
/* 1231 */           return this;
/*      */         }
/*      */         public Builder clearValue() {
/* 1234 */           this.hasValue = false;
/* 1235 */           this.value_ = MemcacheServicePb.MemcacheGetResponse.Item.getDefaultInstance().getValue();
/* 1236 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasFlags()
/*      */         {
/* 1243 */           return this.hasFlags;
/*      */         }
/*      */         public int getFlags() {
/* 1246 */           return this.flags_;
/*      */         }
/*      */         public Builder setFlags(int value) {
/* 1249 */           this.hasFlags = true;
/* 1250 */           this.flags_ = value;
/* 1251 */           return this;
/*      */         }
/*      */         public Builder clearFlags() {
/* 1254 */           this.hasFlags = false;
/* 1255 */           this.flags_ = 0;
/* 1256 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasCasId()
/*      */         {
/* 1263 */           return this.hasCasId;
/*      */         }
/*      */         public long getCasId() {
/* 1266 */           return this.casId_;
/*      */         }
/*      */         public Builder setCasId(long value) {
/* 1269 */           this.hasCasId = true;
/* 1270 */           this.casId_ = value;
/* 1271 */           return this;
/*      */         }
/*      */         public Builder clearCasId() {
/* 1274 */           this.hasCasId = false;
/* 1275 */           this.casId_ = 0L;
/* 1276 */           return this;
/*      */         }
/*      */ 
/*      */         public boolean hasExpiresInSeconds()
/*      */         {
/* 1283 */           return this.hasExpiresInSeconds;
/*      */         }
/*      */         public int getExpiresInSeconds() {
/* 1286 */           return this.expiresInSeconds_;
/*      */         }
/*      */         public Builder setExpiresInSeconds(int value) {
/* 1289 */           this.hasExpiresInSeconds = true;
/* 1290 */           this.expiresInSeconds_ = value;
/* 1291 */           return this;
/*      */         }
/*      */         public Builder clearExpiresInSeconds() {
/* 1294 */           this.hasExpiresInSeconds = false;
/* 1295 */           this.expiresInSeconds_ = 0;
/* 1296 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheGetRequest extends GeneratedMessage
/*      */   {
/*  769 */     private static final MemcacheGetRequest defaultInstance = new MemcacheGetRequest(true);
/*      */     public static final int KEY_FIELD_NUMBER = 1;
/*      */     private List<ByteString> key_;
/*      */     public static final int NAME_SPACE_FIELD_NUMBER = 2;
/*      */     private boolean hasNameSpace;
/*      */     private String nameSpace_;
/*      */     public static final int FOR_CAS_FIELD_NUMBER = 4;
/*      */     private boolean hasForCas;
/*      */     private boolean forCas_;
/*  418 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheGetRequest(Builder builder)
/*      */     {
/*  335 */       super();
/*      */     }
/*      */     private MemcacheGetRequest(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest getDefaultInstance() {
/*  341 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheGetRequest getDefaultInstanceForType() {
/*  345 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  350 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGetRequest_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  355 */       return MemcacheServicePb.internal_static_apphosting_MemcacheGetRequest_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<ByteString> getKeyList()
/*      */     {
/*  363 */       return this.key_;
/*      */     }
/*      */     public int getKeyCount() {
/*  366 */       return this.key_.size();
/*      */     }
/*      */     public ByteString getKey(int index) {
/*  369 */       return (ByteString)this.key_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasNameSpace()
/*      */     {
/*  377 */       return this.hasNameSpace;
/*      */     }
/*      */     public String getNameSpace() {
/*  380 */       return this.nameSpace_;
/*      */     }
/*      */ 
/*      */     public boolean hasForCas()
/*      */     {
/*  388 */       return this.hasForCas;
/*      */     }
/*      */     public boolean getForCas() {
/*  391 */       return this.forCas_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*  395 */       this.key_ = Collections.emptyList();
/*  396 */       this.nameSpace_ = "";
/*  397 */       this.forCas_ = false;
/*      */     }
/*      */     public final boolean isInitialized() {
/*  400 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/*  405 */       getSerializedSize();
/*  406 */       for (ByteString element : getKeyList()) {
/*  407 */         output.writeBytes(1, element);
/*      */       }
/*  409 */       if (hasNameSpace()) {
/*  410 */         output.writeString(2, getNameSpace());
/*      */       }
/*  412 */       if (hasForCas()) {
/*  413 */         output.writeBool(4, getForCas());
/*      */       }
/*  415 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  420 */       int size = this.memoizedSerializedSize;
/*  421 */       if (size != -1) return size;
/*      */ 
/*  423 */       size = 0;
/*      */ 
/*  425 */       int dataSize = 0;
/*  426 */       for (ByteString element : getKeyList()) {
/*  427 */         dataSize += CodedOutputStream.computeBytesSizeNoTag(element);
/*      */       }
/*      */ 
/*  430 */       size += dataSize;
/*  431 */       size += 1 * getKeyList().size();
/*      */ 
/*  433 */       if (hasNameSpace()) {
/*  434 */         size += CodedOutputStream.computeStringSize(2, getNameSpace());
/*      */       }
/*      */ 
/*  437 */       if (hasForCas()) {
/*  438 */         size += CodedOutputStream.computeBoolSize(4, getForCas());
/*      */       }
/*      */ 
/*  441 */       size += getUnknownFields().getSerializedSize();
/*  442 */       this.memoizedSerializedSize = size;
/*  443 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  448 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  454 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  460 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  465 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  471 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(InputStream input) throws IOException
/*      */     {
/*  476 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  482 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  487 */       Builder builder = newBuilder();
/*  488 */       if (builder.mergeDelimitedFrom(input)) {
/*  489 */         return builder.buildParsed();
/*      */       }
/*  491 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  498 */       Builder builder = newBuilder();
/*  499 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  500 */         return builder.buildParsed();
/*      */       }
/*  502 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  508 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheGetRequest parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  514 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  518 */       return Builder.access$800(); } 
/*  519 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheGetRequest prototype) {
/*  521 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  523 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  770 */       MemcacheServicePb.internalForceInit();
/*  771 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*  674 */       private List<ByteString> key_ = Collections.emptyList();
/*      */       private boolean isKeyMutable;
/*      */       private boolean hasNameSpace;
/*  724 */       private String nameSpace_ = "";
/*      */       private boolean hasForCas;
/*      */       private boolean forCas_;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  529 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGetRequest_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  534 */         return MemcacheServicePb.internal_static_apphosting_MemcacheGetRequest_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  542 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  546 */         super.clear();
/*  547 */         this.key_ = Collections.emptyList();
/*  548 */         this.isKeyMutable = false;
/*  549 */         this.nameSpace_ = "";
/*  550 */         this.hasNameSpace = false;
/*  551 */         this.forCas_ = false;
/*  552 */         this.hasForCas = false;
/*  553 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  557 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  562 */         return MemcacheServicePb.MemcacheGetRequest.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetRequest getDefaultInstanceForType() {
/*  566 */         return MemcacheServicePb.MemcacheGetRequest.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetRequest build() {
/*  570 */         MemcacheServicePb.MemcacheGetRequest result = buildPartial();
/*  571 */         if (!result.isInitialized()) {
/*  572 */           throw newUninitializedMessageException(result);
/*      */         }
/*  574 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheGetRequest buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  579 */         MemcacheServicePb.MemcacheGetRequest result = buildPartial();
/*  580 */         if (!result.isInitialized()) {
/*  581 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  584 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheGetRequest buildPartial() {
/*  588 */         MemcacheServicePb.MemcacheGetRequest result = new MemcacheServicePb.MemcacheGetRequest(this, null);
/*  589 */         if (this.isKeyMutable) {
/*  590 */           this.key_ = Collections.unmodifiableList(this.key_);
/*  591 */           this.isKeyMutable = false;
/*      */         }
/*  593 */         MemcacheServicePb.MemcacheGetRequest.access$1002(result, this.key_);
/*  594 */         MemcacheServicePb.MemcacheGetRequest.access$1102(result, this.hasNameSpace);
/*  595 */         MemcacheServicePb.MemcacheGetRequest.access$1202(result, this.nameSpace_);
/*  596 */         MemcacheServicePb.MemcacheGetRequest.access$1302(result, this.hasForCas);
/*  597 */         MemcacheServicePb.MemcacheGetRequest.access$1402(result, this.forCas_);
/*  598 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  602 */         if ((other instanceof MemcacheServicePb.MemcacheGetRequest)) {
/*  603 */           return mergeFrom((MemcacheServicePb.MemcacheGetRequest)other);
/*      */         }
/*  605 */         super.mergeFrom(other);
/*  606 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheGetRequest other)
/*      */       {
/*  611 */         if (other == MemcacheServicePb.MemcacheGetRequest.getDefaultInstance()) return this;
/*  612 */         if (!other.key_.isEmpty()) {
/*  613 */           if (this.key_.isEmpty()) {
/*  614 */             this.key_ = other.key_;
/*  615 */             this.isKeyMutable = false;
/*      */           } else {
/*  617 */             ensureKeyIsMutable();
/*  618 */             this.key_.addAll(other.key_);
/*      */           }
/*      */         }
/*  621 */         if (other.hasNameSpace()) {
/*  622 */           setNameSpace(other.getNameSpace());
/*      */         }
/*  624 */         if (other.hasForCas()) {
/*  625 */           setForCas(other.getForCas());
/*      */         }
/*  627 */         mergeUnknownFields(other.getUnknownFields());
/*  628 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  632 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  639 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  643 */           int tag = input.readTag();
/*  644 */           switch (tag) {
/*      */           case 0:
/*  646 */             setUnknownFields(unknownFields.build());
/*  647 */             return this;
/*      */           default:
/*  649 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  651 */             setUnknownFields(unknownFields.build());
/*  652 */             return this;
/*      */           case 10:
/*  657 */             addKey(input.readBytes());
/*  658 */             break;
/*      */           case 18:
/*  661 */             setNameSpace(input.readString());
/*  662 */             break;
/*      */           case 32:
/*  665 */             setForCas(input.readBool());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureKeyIsMutable()
/*      */       {
/*  678 */         if (!this.isKeyMutable) {
/*  679 */           this.key_ = new ArrayList(this.key_);
/*  680 */           this.isKeyMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<ByteString> getKeyList() {
/*  685 */         return Collections.unmodifiableList(this.key_);
/*      */       }
/*      */       public int getKeyCount() {
/*  688 */         return this.key_.size();
/*      */       }
/*      */       public ByteString getKey(int index) {
/*  691 */         return (ByteString)this.key_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setKey(int index, ByteString value) {
/*  695 */         if (value == null) {
/*  696 */           throw new NullPointerException();
/*      */         }
/*  698 */         ensureKeyIsMutable();
/*  699 */         this.key_.set(index, value);
/*  700 */         return this;
/*      */       }
/*      */       public Builder addKey(ByteString value) {
/*  703 */         if (value == null) {
/*  704 */           throw new NullPointerException();
/*      */         }
/*  706 */         ensureKeyIsMutable();
/*  707 */         this.key_.add(value);
/*  708 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllKey(Iterable<? extends ByteString> values) {
/*  712 */         ensureKeyIsMutable();
/*  713 */         GeneratedMessage.Builder.addAll(values, this.key_);
/*  714 */         return this;
/*      */       }
/*      */       public Builder clearKey() {
/*  717 */         this.key_ = Collections.emptyList();
/*  718 */         this.isKeyMutable = false;
/*  719 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasNameSpace()
/*      */       {
/*  726 */         return this.hasNameSpace;
/*      */       }
/*      */       public String getNameSpace() {
/*  729 */         return this.nameSpace_;
/*      */       }
/*      */       public Builder setNameSpace(String value) {
/*  732 */         if (value == null) {
/*  733 */           throw new NullPointerException();
/*      */         }
/*  735 */         this.hasNameSpace = true;
/*  736 */         this.nameSpace_ = value;
/*  737 */         return this;
/*      */       }
/*      */       public Builder clearNameSpace() {
/*  740 */         this.hasNameSpace = false;
/*  741 */         this.nameSpace_ = MemcacheServicePb.MemcacheGetRequest.getDefaultInstance().getNameSpace();
/*  742 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasForCas()
/*      */       {
/*  749 */         return this.hasForCas;
/*      */       }
/*      */       public boolean getForCas() {
/*  752 */         return this.forCas_;
/*      */       }
/*      */       public Builder setForCas(boolean value) {
/*  755 */         this.hasForCas = true;
/*  756 */         this.forCas_ = value;
/*  757 */         return this;
/*      */       }
/*      */       public Builder clearForCas() {
/*  760 */         this.hasForCas = false;
/*  761 */         this.forCas_ = false;
/*  762 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class MemcacheServiceError extends GeneratedMessage
/*      */   {
/*  323 */     private static final MemcacheServiceError defaultInstance = new MemcacheServiceError(true);
/*      */ 
/*  123 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private MemcacheServiceError(Builder builder)
/*      */     {
/*   15 */       super();
/*      */     }
/*      */     private MemcacheServiceError(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError getDefaultInstance() {
/*   21 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public MemcacheServiceError getDefaultInstanceForType() {
/*   25 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*   30 */       return MemcacheServicePb.internal_static_apphosting_MemcacheServiceError_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*   35 */       return MemcacheServicePb.internal_static_apphosting_MemcacheServiceError_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     private void initFields()
/*      */     {
/*      */     }
/*      */ 
/*      */     public final boolean isInitialized()
/*      */     {
/*  114 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/*  119 */       getSerializedSize();
/*  120 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  125 */       int size = this.memoizedSerializedSize;
/*  126 */       if (size != -1) return size;
/*      */ 
/*  128 */       size = 0;
/*  129 */       size += getUnknownFields().getSerializedSize();
/*  130 */       this.memoizedSerializedSize = size;
/*  131 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  136 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  142 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  148 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  153 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  159 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(InputStream input) throws IOException
/*      */     {
/*  164 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  170 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  175 */       Builder builder = newBuilder();
/*  176 */       if (builder.mergeDelimitedFrom(input)) {
/*  177 */         return builder.buildParsed();
/*      */       }
/*  179 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  186 */       Builder builder = newBuilder();
/*  187 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  188 */         return builder.buildParsed();
/*      */       }
/*  190 */       return null;
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  196 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static MemcacheServiceError parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  202 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  206 */       return Builder.access$300(); } 
/*  207 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(MemcacheServiceError prototype) {
/*  209 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  211 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  324 */       MemcacheServicePb.internalForceInit();
/*  325 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  217 */         return MemcacheServicePb.internal_static_apphosting_MemcacheServiceError_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  222 */         return MemcacheServicePb.internal_static_apphosting_MemcacheServiceError_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  230 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  234 */         super.clear();
/*  235 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  239 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  244 */         return MemcacheServicePb.MemcacheServiceError.getDescriptor();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheServiceError getDefaultInstanceForType() {
/*  248 */         return MemcacheServicePb.MemcacheServiceError.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheServiceError build() {
/*  252 */         MemcacheServicePb.MemcacheServiceError result = buildPartial();
/*  253 */         if (!result.isInitialized()) {
/*  254 */           throw newUninitializedMessageException(result);
/*      */         }
/*  256 */         return result;
/*      */       }
/*      */ 
/*      */       private MemcacheServicePb.MemcacheServiceError buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  261 */         MemcacheServicePb.MemcacheServiceError result = buildPartial();
/*  262 */         if (!result.isInitialized()) {
/*  263 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  266 */         return result;
/*      */       }
/*      */ 
/*      */       public MemcacheServicePb.MemcacheServiceError buildPartial() {
/*  270 */         MemcacheServicePb.MemcacheServiceError result = new MemcacheServicePb.MemcacheServiceError(this, null);
/*  271 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  275 */         if ((other instanceof MemcacheServicePb.MemcacheServiceError)) {
/*  276 */           return mergeFrom((MemcacheServicePb.MemcacheServiceError)other);
/*      */         }
/*  278 */         super.mergeFrom(other);
/*  279 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(MemcacheServicePb.MemcacheServiceError other)
/*      */       {
/*  284 */         if (other == MemcacheServicePb.MemcacheServiceError.getDefaultInstance()) return this;
/*  285 */         mergeUnknownFields(other.getUnknownFields());
/*  286 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  290 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  297 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  301 */           int tag = input.readTag();
/*  302 */           switch (tag) {
/*      */           case 0:
/*  304 */             setUnknownFields(unknownFields.build());
/*  305 */             return this;
/*      */           }
/*  307 */           if (!parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */           {
/*  309 */             setUnknownFields(unknownFields.build());
/*  310 */             return this;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   40 */       OK(0, 0), 
/*   41 */       UNSPECIFIED_ERROR(1, 1), 
/*   42 */       NAMESPACE_NOT_SET(2, 2);
/*      */ 
/*      */       public static final int OK_VALUE = 0;
/*      */       public static final int UNSPECIFIED_ERROR_VALUE = 1;
/*      */       public static final int NAMESPACE_NOT_SET_VALUE = 2;
/*      */       private static Internal.EnumLiteMap<ErrorCode> internalValueMap;
/*      */       private static final ErrorCode[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/*   50 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   53 */         switch (value) { case 0:
/*   54 */           return OK;
/*      */         case 1:
/*   55 */           return UNSPECIFIED_ERROR;
/*      */         case 2:
/*   56 */           return NAMESPACE_NOT_SET; }
/*   57 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<ErrorCode> internalGetValueMap()
/*      */       {
/*   63 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/*   75 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*   79 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*   83 */         return (Descriptors.EnumDescriptor)MemcacheServicePb.MemcacheServiceError.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static ErrorCode valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/*   91 */         if (desc.getType() != getDescriptor()) {
/*   92 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/*   95 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private ErrorCode(int index, int value)
/*      */       {
/*  100 */         this.index = index;
/*  101 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   66 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public MemcacheServicePb.MemcacheServiceError.ErrorCode findValueByNumber(int number) {
/*   69 */             return MemcacheServicePb.MemcacheServiceError.ErrorCode.valueOf(number);
/*      */           }
/*      */         };
/*   86 */         VALUES = new ErrorCode[] { OK, UNSPECIFIED_ERROR, NAMESPACE_NOT_SET };
/*      */ 
/*  105 */         MemcacheServicePb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.MemcacheServicePb
 * JD-Core Version:    0.6.0
 */