/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class ExtensionRegistry extends ExtensionRegistryLite
/*     */ {
/*     */   private final Map<String, ExtensionInfo> extensionsByName;
/*     */   private final Map<DescriptorIntPair, ExtensionInfo> extensionsByNumber;
/* 188 */   private static final ExtensionRegistry EMPTY = new ExtensionRegistry(true);
/*     */ 
/*     */   public static ExtensionRegistry newInstance()
/*     */   {
/*  68 */     return new ExtensionRegistry();
/*     */   }
/*     */ 
/*     */   public static ExtensionRegistry getEmptyRegistry()
/*     */   {
/*  73 */     return EMPTY;
/*     */   }
/*     */ 
/*     */   public ExtensionRegistry getUnmodifiable()
/*     */   {
/*  79 */     return new ExtensionRegistry(this);
/*     */   }
/*     */ 
/*     */   public ExtensionInfo findExtensionByName(String fullName)
/*     */   {
/* 113 */     return (ExtensionInfo)this.extensionsByName.get(fullName);
/*     */   }
/*     */ 
/*     */   public ExtensionInfo findExtensionByNumber(Descriptors.Descriptor containingType, int fieldNumber)
/*     */   {
/* 124 */     return (ExtensionInfo)this.extensionsByNumber.get(new DescriptorIntPair(containingType, fieldNumber));
/*     */   }
/*     */ 
/*     */   public void add(GeneratedMessage.GeneratedExtension<?, ?> extension)
/*     */   {
/* 130 */     if (extension.getDescriptor().getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/*     */     {
/* 132 */       if (extension.getMessageDefaultInstance() == null) {
/* 133 */         throw new IllegalStateException("Registered message-type extension had null default instance: " + extension.getDescriptor().getFullName());
/*     */       }
/*     */ 
/* 137 */       add(new ExtensionInfo(extension.getDescriptor(), extension.getMessageDefaultInstance(), null));
/*     */     }
/*     */     else {
/* 140 */       add(new ExtensionInfo(extension.getDescriptor(), null, null));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(Descriptors.FieldDescriptor type)
/*     */   {
/* 146 */     if (type.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 147 */       throw new IllegalArgumentException("ExtensionRegistry.add() must be provided a default instance when adding an embedded message extension.");
/*     */     }
/*     */ 
/* 151 */     add(new ExtensionInfo(type, null, null));
/*     */   }
/*     */ 
/*     */   public void add(Descriptors.FieldDescriptor type, Message defaultInstance)
/*     */   {
/* 156 */     if (type.getJavaType() != Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 157 */       throw new IllegalArgumentException("ExtensionRegistry.add() provided a default instance for a non-message extension.");
/*     */     }
/*     */ 
/* 161 */     add(new ExtensionInfo(type, defaultInstance, null));
/*     */   }
/*     */ 
/*     */   private ExtensionRegistry()
/*     */   {
/* 168 */     this.extensionsByName = new HashMap();
/* 169 */     this.extensionsByNumber = new HashMap();
/*     */   }
/*     */ 
/*     */   private ExtensionRegistry(ExtensionRegistry other) {
/* 173 */     super(other);
/* 174 */     this.extensionsByName = Collections.unmodifiableMap(other.extensionsByName);
/* 175 */     this.extensionsByNumber = Collections.unmodifiableMap(other.extensionsByNumber);
/*     */   }
/*     */ 
/*     */   private ExtensionRegistry(boolean empty)
/*     */   {
/* 183 */     super(ExtensionRegistryLite.getEmptyRegistry());
/* 184 */     this.extensionsByName = Collections.emptyMap();
/* 185 */     this.extensionsByNumber = Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   private void add(ExtensionInfo extension)
/*     */   {
/* 191 */     if (!extension.descriptor.isExtension()) {
/* 192 */       throw new IllegalArgumentException("ExtensionRegistry.add() was given a FieldDescriptor for a regular (non-extension) field.");
/*     */     }
/*     */ 
/* 197 */     this.extensionsByName.put(extension.descriptor.getFullName(), extension);
/* 198 */     this.extensionsByNumber.put(new DescriptorIntPair(extension.descriptor.getContainingType(), extension.descriptor.getNumber()), extension);
/*     */ 
/* 203 */     Descriptors.FieldDescriptor field = extension.descriptor;
/* 204 */     if ((field.getContainingType().getOptions().getMessageSetWireFormat()) && (field.getType() == Descriptors.FieldDescriptor.Type.MESSAGE) && (field.isOptional()) && (field.getExtensionScope() == field.getMessageType()))
/*     */     {
/* 211 */       this.extensionsByName.put(field.getMessageType().getFullName(), extension);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class DescriptorIntPair {
/*     */     private final Descriptors.Descriptor descriptor;
/*     */     private final int number;
/*     */ 
/*     */     DescriptorIntPair(Descriptors.Descriptor descriptor, int number) {
/* 221 */       this.descriptor = descriptor;
/* 222 */       this.number = number;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 227 */       return this.descriptor.hashCode() * 65535 + this.number;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 231 */       if (!(obj instanceof DescriptorIntPair)) {
/* 232 */         return false;
/*     */       }
/* 234 */       DescriptorIntPair other = (DescriptorIntPair)obj;
/* 235 */       return (this.descriptor == other.descriptor) && (this.number == other.number);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class ExtensionInfo
/*     */   {
/*     */     public final Descriptors.FieldDescriptor descriptor;
/*     */     public final Message defaultInstance;
/*     */ 
/*     */     private ExtensionInfo(Descriptors.FieldDescriptor descriptor)
/*     */     {
/*  94 */       this.descriptor = descriptor;
/*  95 */       this.defaultInstance = null;
/*     */     }
/*     */ 
/*     */     private ExtensionInfo(Descriptors.FieldDescriptor descriptor, Message defaultInstance) {
/*  99 */       this.descriptor = descriptor;
/* 100 */       this.defaultInstance = defaultInstance;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry
 * JD-Core Version:    0.6.0
 */