/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.InterruptedIOException;
/*     */ 
/*     */ @GoogleInternal
/*     */ public class InterruptedRuntimeException extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public InterruptedRuntimeException()
/*     */   {
/*  53 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ 
/*     */   public InterruptedRuntimeException(String message)
/*     */   {
/*  63 */     super(message);
/*  64 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ 
/*     */   public InterruptedRuntimeException(InterruptedException cause)
/*     */   {
/*  73 */     super(cause);
/*  74 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ 
/*     */   public InterruptedRuntimeException(InterruptedIOException cause)
/*     */   {
/*  83 */     super(cause);
/*  84 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ 
/*     */   public InterruptedRuntimeException(String message, InterruptedException cause)
/*     */   {
/*  94 */     super(message, cause);
/*  95 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ 
/*     */   public InterruptedRuntimeException(String message, InterruptedIOException cause)
/*     */   {
/* 105 */     super(message, cause);
/* 106 */     Thread.currentThread().interrupt();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.InterruptedRuntimeException
 * JD-Core Version:    0.6.0
 */