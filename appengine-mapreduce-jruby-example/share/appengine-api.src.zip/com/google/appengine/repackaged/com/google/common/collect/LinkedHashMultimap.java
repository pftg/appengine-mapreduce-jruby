/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public final class LinkedHashMultimap<K, V> extends AbstractSetMultimap<K, V>
/*     */ {
/*     */   private static final int DEFAULT_VALUES_PER_KEY = 8;
/*     */ 
/*     */   @VisibleForTesting
/*  74 */   transient int expectedValuesPerKey = 8;
/*     */   transient Collection<Map.Entry<K, V>> linkedEntries;
/*     */ 
/*     */   @GwtIncompatible("java serialization not supported")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> LinkedHashMultimap<K, V> create()
/*     */   {
/*  89 */     return new LinkedHashMultimap();
/*     */   }
/*     */ 
/*     */   public static <K, V> LinkedHashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*     */   {
/* 103 */     return new LinkedHashMultimap(expectedKeys, expectedValuesPerKey);
/*     */   }
/*     */ 
/*     */   public static <K, V> LinkedHashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*     */   {
/* 117 */     return new LinkedHashMultimap(multimap);
/*     */   }
/*     */ 
/*     */   private LinkedHashMultimap() {
/* 121 */     super(new LinkedHashMap());
/* 122 */     this.linkedEntries = Sets.newLinkedHashSet();
/*     */   }
/*     */ 
/*     */   private LinkedHashMultimap(int expectedKeys, int expectedValuesPerKey) {
/* 126 */     super(new LinkedHashMap(expectedKeys));
/* 127 */     Preconditions.checkArgument(expectedValuesPerKey >= 0);
/* 128 */     this.expectedValuesPerKey = expectedValuesPerKey;
/* 129 */     this.linkedEntries = new LinkedHashSet(expectedKeys * expectedValuesPerKey);
/*     */   }
/*     */ 
/*     */   private LinkedHashMultimap(Multimap<? extends K, ? extends V> multimap)
/*     */   {
/* 134 */     super(new LinkedHashMap(Maps.capacity(multimap.keySet().size())));
/*     */ 
/* 136 */     this.linkedEntries = new LinkedHashSet(Maps.capacity(multimap.size()));
/*     */ 
/* 138 */     putAll(multimap);
/*     */   }
/*     */ 
/*     */   Set<V> createCollection()
/*     */   {
/* 151 */     return new LinkedHashSet(Maps.capacity(this.expectedValuesPerKey));
/*     */   }
/*     */ 
/*     */   Collection<V> createCollection(@Nullable K key)
/*     */   {
/* 165 */     return new SetDecorator(key, createCollection());
/*     */   }
/*     */ 
/*     */   Iterator<Map.Entry<K, V>> createEntryIterator()
/*     */   {
/* 283 */     Iterator delegateIterator = this.linkedEntries.iterator();
/*     */ 
/* 285 */     return new Iterator(delegateIterator) {
/*     */       Map.Entry<K, V> entry;
/*     */ 
/* 289 */       public boolean hasNext() { return this.val$delegateIterator.hasNext(); }
/*     */ 
/*     */       public Map.Entry<K, V> next()
/*     */       {
/* 293 */         this.entry = ((Map.Entry)this.val$delegateIterator.next());
/* 294 */         return this.entry;
/*     */       }
/*     */ 
/*     */       public void remove()
/*     */       {
/* 299 */         this.val$delegateIterator.remove();
/* 300 */         LinkedHashMultimap.this.remove(this.entry.getKey(), this.entry.getValue());
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Set<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/*     */   {
/* 315 */     return super.replaceValues(key, values);
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entries()
/*     */   {
/* 331 */     return super.entries();
/*     */   }
/*     */ 
/*     */   public Collection<V> values()
/*     */   {
/* 342 */     return super.values();
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 355 */     stream.defaultWriteObject();
/* 356 */     stream.writeInt(this.expectedValuesPerKey);
/* 357 */     Serialization.writeMultimap(this, stream);
/* 358 */     for (Map.Entry entry : this.linkedEntries) {
/* 359 */       stream.writeObject(entry.getKey());
/* 360 */       stream.writeObject(entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 367 */     stream.defaultReadObject();
/* 368 */     this.expectedValuesPerKey = stream.readInt();
/* 369 */     int distinctKeys = Serialization.readCount(stream);
/* 370 */     setMap(new LinkedHashMap(Maps.capacity(distinctKeys)));
/* 371 */     this.linkedEntries = new LinkedHashSet(distinctKeys * this.expectedValuesPerKey);
/*     */ 
/* 373 */     Serialization.populateMultimap(this, stream, distinctKeys);
/* 374 */     this.linkedEntries.clear();
/* 375 */     for (int i = 0; i < size(); i++)
/*     */     {
/* 377 */       Object key = stream.readObject();
/*     */ 
/* 379 */       Object value = stream.readObject();
/* 380 */       this.linkedEntries.add(Maps.immutableEntry(key, value));
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SetDecorator extends ForwardingSet<V>
/*     */   {
/*     */     final Set<V> delegate;
/*     */     final K key;
/*     */ 
/*     */     SetDecorator(Set<V> key)
/*     */     {
/* 173 */       this.delegate = delegate;
/* 174 */       this.key = key;
/*     */     }
/*     */ 
/*     */     protected Set<V> delegate() {
/* 178 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     <E> Map.Entry<K, E> createEntry(@Nullable E value) {
/* 182 */       return Maps.immutableEntry(this.key, value);
/*     */     }
/*     */ 
/*     */     <E> Collection<Map.Entry<K, E>> createEntries(Collection<E> values)
/*     */     {
/* 187 */       Collection entries = Lists.newArrayListWithExpectedSize(values.size());
/*     */ 
/* 189 */       for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 190 */         entries.add(createEntry(value));
/*     */       }
/* 192 */       return entries;
/*     */     }
/*     */ 
/*     */     public boolean add(@Nullable V value) {
/* 196 */       boolean changed = this.delegate.add(value);
/* 197 */       if (changed) {
/* 198 */         LinkedHashMultimap.this.linkedEntries.add(createEntry(value));
/*     */       }
/* 200 */       return changed;
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection<? extends V> values) {
/* 204 */       boolean changed = this.delegate.addAll(values);
/* 205 */       if (changed) {
/* 206 */         LinkedHashMultimap.this.linkedEntries.addAll(createEntries(delegate()));
/*     */       }
/* 208 */       return changed;
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 212 */       LinkedHashMultimap.this.linkedEntries.removeAll(createEntries(delegate()));
/* 213 */       this.delegate.clear();
/*     */     }
/*     */ 
/*     */     public Iterator<V> iterator() {
/* 217 */       Iterator delegateIterator = this.delegate.iterator();
/* 218 */       return new Iterator(delegateIterator) {
/*     */         V value;
/*     */ 
/* 222 */         public boolean hasNext() { return this.val$delegateIterator.hasNext(); }
/*     */ 
/*     */         public V next() {
/* 225 */           this.value = this.val$delegateIterator.next();
/* 226 */           return this.value;
/*     */         }
/*     */         public void remove() {
/* 229 */           this.val$delegateIterator.remove();
/* 230 */           LinkedHashMultimap.this.linkedEntries.remove(LinkedHashMultimap.SetDecorator.this.createEntry(this.value));
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public boolean remove(@Nullable Object value) {
/* 236 */       boolean changed = this.delegate.remove(value);
/* 237 */       if (changed)
/*     */       {
/* 242 */         LinkedHashMultimap.this.linkedEntries.remove(createEntry(value));
/*     */       }
/* 244 */       return changed;
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> values) {
/* 248 */       boolean changed = this.delegate.removeAll(values);
/* 249 */       if (changed) {
/* 250 */         LinkedHashMultimap.this.linkedEntries.removeAll(createEntries(values));
/*     */       }
/* 252 */       return changed;
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> values)
/*     */     {
/* 260 */       boolean changed = false;
/* 261 */       Iterator iterator = this.delegate.iterator();
/* 262 */       while (iterator.hasNext()) {
/* 263 */         Object value = iterator.next();
/* 264 */         if (!values.contains(value)) {
/* 265 */           iterator.remove();
/* 266 */           LinkedHashMultimap.this.linkedEntries.remove(Maps.immutableEntry(this.key, value));
/* 267 */           changed = true;
/*     */         }
/*     */       }
/* 270 */       return changed;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.LinkedHashMultimap
 * JD-Core Version:    0.6.0
 */