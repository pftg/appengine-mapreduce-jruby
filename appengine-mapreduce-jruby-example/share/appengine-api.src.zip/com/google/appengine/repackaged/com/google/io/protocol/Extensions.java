/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Lists;
/*     */ import java.io.Serializable;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class Extensions
/*     */ {
/*     */   public static class LazyParsingException extends RuntimeException
/*     */   {
/*     */     public LazyParsingException(String s)
/*     */     {
/* 499 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class RepeatedExtension<E extends ExtendableProtocolMessage<E>, T> extends Extensions.Extension<E, List<T>>
/*     */   {
/*     */     private final Extensions.Extension<E, T> unitExtension;
/*     */ 
/*     */     protected RepeatedExtension(Extensions.Extension<E, T> unitExtension)
/*     */     {
/* 432 */       this.unitExtension = unitExtension;
/*     */     }
/*     */ 
/*     */     protected int getWireTag()
/*     */     {
/* 437 */       return this.unitExtension.getWireTag();
/*     */     }
/*     */ 
/*     */     protected final T unitDefaultValue() {
/* 441 */       return this.unitExtension.newValue();
/*     */     }
/*     */ 
/*     */     protected final List<T> defaultValue()
/*     */     {
/* 446 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     protected final List<T> newValue()
/*     */     {
/* 451 */       return Lists.newArrayList();
/*     */     }
/*     */ 
/*     */     protected final List<T> readFromRepeatedTags(List<ByteBuffer> allSourceData)
/*     */     {
/* 456 */       List result = Lists.newArrayList();
/* 457 */       for (ByteBuffer b : allSourceData) {
/* 458 */         result.add(this.unitExtension.readOne(b.asReadOnlyBuffer()));
/*     */       }
/* 460 */       return result;
/*     */     }
/*     */ 
/*     */     protected List<T> unmodifiable(List<T> data)
/*     */     {
/* 465 */       return ProtocolSupport.unmodifiableList(data);
/*     */     }
/*     */ 
/*     */     protected final List<T> merge(List<T> mergeInto, List<T> mergeFrom)
/*     */     {
/* 470 */       mergeInto.addAll(mergeFrom);
/* 471 */       return mergeInto;
/*     */     }
/*     */ 
/*     */     protected final List<T> readOne(ByteBuffer arg0)
/*     */     {
/* 476 */       throw new UnsupportedOperationException("readOne not supported for repeated extensions");
/*     */     }
/*     */ 
/*     */     protected final void write(List<T> allData, ProtocolSink sink)
/*     */     {
/* 481 */       for (Iterator i$ = allData.iterator(); i$.hasNext(); ) { Object data = i$.next();
/* 482 */         this.unitExtension.write(data, sink);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(List<T> data)
/*     */     {
/* 488 */       int size = 0;
/* 489 */       for (Iterator i$ = data.iterator(); i$.hasNext(); ) { Object t = i$.next();
/*     */ 
/* 491 */         size += this.unitExtension.encodingSize(t);
/*     */       }
/* 493 */       return size;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class MessageExtension<E extends ExtendableProtocolMessage<E>, P extends ProtocolMessage<P>> extends Extensions.Extension<E, P>
/*     */   {
/*     */     private final int wireTag;
/*     */     private final P defaultInstance;
/*     */ 
/*     */     public MessageExtension(int wireTag, P defaultInstance)
/*     */     {
/* 354 */       this.wireTag = wireTag;
/* 355 */       this.defaultInstance = defaultInstance;
/*     */     }
/*     */ 
/*     */     protected int getWireTag()
/*     */     {
/* 360 */       return this.wireTag;
/*     */     }
/*     */ 
/*     */     protected final P defaultValue()
/*     */     {
/* 366 */       return this.defaultInstance.getDefaultInstanceForType();
/*     */     }
/*     */ 
/*     */     protected final P newValue()
/*     */     {
/* 371 */       return this.defaultInstance.newInstance();
/*     */     }
/*     */ 
/*     */     protected final P readFromRepeatedTags(List<ByteBuffer> allSourceData)
/*     */       throws Extensions.LazyParsingException
/*     */     {
/* 377 */       ProtocolMessage result = null;
/* 378 */       for (ByteBuffer extData : allSourceData) {
/* 379 */         if (result == null) {
/* 380 */           result = newValue();
/*     */         }
/* 382 */         mergeSerialized(result, extData.asReadOnlyBuffer());
/*     */       }
/* 384 */       return result;
/*     */     }
/*     */ 
/*     */     protected P unmodifiable(P data)
/*     */     {
/* 389 */       return data;
/*     */     }
/*     */ 
/*     */     protected final P merge(P mergeInto, P mergeFrom)
/*     */     {
/* 394 */       mergeInto.mergeFrom(mergeFrom);
/* 395 */       return mergeInto;
/*     */     }
/*     */ 
/*     */     protected final P readOne(ByteBuffer source) throws Extensions.LazyParsingException
/*     */     {
/* 400 */       ProtocolMessage result = newValue();
/* 401 */       mergeSerialized(result, source);
/* 402 */       return result;
/*     */     }
/*     */ 
/*     */     protected final void write(P data, ProtocolSink sink)
/*     */     {
/* 407 */       sink.putVarInt(this.wireTag);
/* 408 */       sink.putForeign(data);
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(P data)
/*     */     {
/* 413 */       int encodingSize = data.encodingSize();
/* 414 */       return Protocol.varIntSize(this.wireTag) + Protocol.varIntSize(encodingSize) + encodingSize;
/*     */     }
/*     */ 
/*     */     private final void mergeSerialized(P mergeInto, ByteBuffer source) throws Extensions.LazyParsingException {
/* 418 */       ProtocolSource protoSource = new ProtocolSource(source);
/* 419 */       protoSource.push(protoSource.getVarInt());
/* 420 */       if (!mergeInto.mergeFrom(protoSource))
/* 421 */         throw new Extensions.LazyParsingException("Unable to parse " + mergeInto.getClass() + " proto from " + source);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class StringExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, ProtoString>
/*     */   {
/*     */     public StringExtension(int wireTag, ProtoString defaultValue)
/*     */     {
/* 326 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final ProtoString readOne(ByteBuffer source)
/*     */     {
/* 331 */       return new ProtoString(Protocol.getPrefixedData(source));
/*     */     }
/*     */ 
/*     */     protected final void write(ProtoString data, ProtocolSink sink)
/*     */     {
/* 336 */       sink.putVarInt(this.wireTag);
/* 337 */       sink.putPrefixedData(data.getAsBytes());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(ProtoString dataString)
/*     */     {
/* 342 */       byte[] data = dataString.getAsBytes();
/* 343 */       return Protocol.varIntSize(this.wireTag) + Protocol.varIntSize(data.length) + data.length;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class DoubleExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Double>
/*     */   {
/*     */     public DoubleExtension(int wireTag, Double defaultValue)
/*     */     {
/* 303 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Double readOne(ByteBuffer source)
/*     */     {
/* 308 */       return Double.valueOf(new ProtocolSource(source).getDouble());
/*     */     }
/*     */ 
/*     */     protected final void write(Double data, ProtocolSink sink)
/*     */     {
/* 313 */       sink.putVarInt(this.wireTag);
/* 314 */       sink.putDouble(data.doubleValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Double data)
/*     */     {
/* 319 */       return Protocol.varIntSize(this.wireTag) + 8;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class FloatExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Float>
/*     */   {
/*     */     public FloatExtension(int wireTag, Float defaultValue)
/*     */     {
/* 280 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Float readOne(ByteBuffer source)
/*     */     {
/* 285 */       return Float.valueOf(new ProtocolSource(source).getFloat());
/*     */     }
/*     */ 
/*     */     protected final void write(Float data, ProtocolSink sink)
/*     */     {
/* 290 */       sink.putVarInt(this.wireTag);
/* 291 */       sink.putFloat(data.floatValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Float data)
/*     */     {
/* 296 */       return Protocol.varIntSize(this.wireTag) + 4;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class FixedLongExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Long>
/*     */   {
/*     */     public FixedLongExtension(int wireTag, Long defaultValue)
/*     */     {
/* 257 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Long readOne(ByteBuffer source)
/*     */     {
/* 262 */       return Long.valueOf(new ProtocolSource(source).getLong());
/*     */     }
/*     */ 
/*     */     protected final void write(Long data, ProtocolSink sink)
/*     */     {
/* 267 */       sink.putVarInt(this.wireTag);
/* 268 */       sink.putLong(data.longValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Long data)
/*     */     {
/* 273 */       return Protocol.varIntSize(this.wireTag) + 8;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class LongExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Long>
/*     */   {
/*     */     public LongExtension(int wireTag, Long defaultValue)
/*     */     {
/* 234 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Long readOne(ByteBuffer source)
/*     */     {
/* 239 */       return Long.valueOf(Protocol.getVarLong(source));
/*     */     }
/*     */ 
/*     */     protected final void write(Long data, ProtocolSink sink)
/*     */     {
/* 244 */       sink.putVarInt(this.wireTag);
/* 245 */       sink.putVarLong(data.longValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Long data)
/*     */     {
/* 250 */       return Protocol.varIntSize(this.wireTag) + Protocol.varLongSize(data.longValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class FixedIntegerExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Integer>
/*     */   {
/*     */     public FixedIntegerExtension(int wireTag, Integer defaultValue)
/*     */     {
/* 211 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Integer readOne(ByteBuffer source)
/*     */     {
/* 216 */       return Integer.valueOf(new ProtocolSource(source).getInt());
/*     */     }
/*     */ 
/*     */     protected final void write(Integer data, ProtocolSink sink)
/*     */     {
/* 221 */       sink.putVarInt(this.wireTag);
/* 222 */       sink.putInt(data.intValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Integer data)
/*     */     {
/* 227 */       return Protocol.varIntSize(this.wireTag) + 4;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class IntegerExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Integer>
/*     */   {
/*     */     public IntegerExtension(int wireTag, Integer defaultValue)
/*     */     {
/* 188 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Integer readOne(ByteBuffer source)
/*     */     {
/* 193 */       return Integer.valueOf(Protocol.getVarInt(source));
/*     */     }
/*     */ 
/*     */     protected final void write(Integer data, ProtocolSink sink)
/*     */     {
/* 198 */       sink.putVarInt(this.wireTag);
/* 199 */       sink.putVarInt(data.intValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Integer data)
/*     */     {
/* 204 */       return Protocol.varIntSize(this.wireTag) + Protocol.varLongSize(data.intValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class BooleanExtension<E extends ExtendableProtocolMessage<E>> extends Extensions.PrimitiveExtension<E, Boolean>
/*     */   {
/*     */     public BooleanExtension(int wireTag, Boolean defaultValue)
/*     */     {
/* 165 */       super(defaultValue, null);
/*     */     }
/*     */ 
/*     */     protected final Boolean readOne(ByteBuffer source)
/*     */     {
/* 170 */       return Boolean.valueOf(new ProtocolSource(source).getBoolean());
/*     */     }
/*     */ 
/*     */     protected final void write(Boolean data, ProtocolSink sink)
/*     */     {
/* 175 */       sink.putVarInt(this.wireTag);
/* 176 */       sink.putBoolean(data.booleanValue());
/*     */     }
/*     */ 
/*     */     protected final int encodingSize(Boolean data)
/*     */     {
/* 181 */       return Protocol.varIntSize(this.wireTag) + 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class PrimitiveExtension<E extends ExtendableProtocolMessage<E>, T> extends Extensions.Extension<E, T>
/*     */   {
/*     */     protected final int wireTag;
/*     */     private final T defaultValue;
/*     */ 
/*     */     private PrimitiveExtension(int wireTag, T defaultValue)
/*     */     {
/*  93 */       this.wireTag = wireTag;
/*  94 */       this.defaultValue = defaultValue;
/*     */     }
/*     */ 
/*     */     protected int getWireTag()
/*     */     {
/*  99 */       return this.wireTag;
/*     */     }
/*     */ 
/*     */     protected T defaultValue()
/*     */     {
/* 107 */       return this.defaultValue;
/*     */     }
/*     */ 
/*     */     protected T newValue()
/*     */     {
/* 115 */       return this.defaultValue;
/*     */     }
/*     */ 
/*     */     protected T readFromRepeatedTags(List<ByteBuffer> allSourceData)
/*     */     {
/* 124 */       return readOne(((ByteBuffer)allSourceData.get(allSourceData.size() - 1)).asReadOnlyBuffer());
/*     */     }
/*     */ 
/*     */     protected T merge(T mergeInto, T mergeFrom)
/*     */     {
/* 132 */       return mergeFrom;
/*     */     }
/*     */ 
/*     */     protected abstract T readOne(ByteBuffer paramByteBuffer);
/*     */ 
/*     */     protected T unmodifiable(T data)
/*     */     {
/* 145 */       return data;
/*     */     }
/*     */ 
/*     */     protected abstract void write(T paramT, ProtocolSink paramProtocolSink);
/*     */ 
/*     */     protected abstract int encodingSize(T paramT);
/*     */   }
/*     */ 
/*     */   public static abstract class Extension<E extends ExtendableProtocolMessage<E>, T>
/*     */     implements Serializable
/*     */   {
/*     */     public final Extensions.RepeatedExtension<E, T> asRepeated()
/*     */     {
/*  36 */       return new Extensions.RepeatedExtension(this);
/*     */     }
/*     */ 
/*     */     protected abstract int getWireTag();
/*     */ 
/*     */     protected abstract T defaultValue();
/*     */ 
/*     */     protected abstract T newValue();
/*     */ 
/*     */     protected abstract T readFromRepeatedTags(List<ByteBuffer> paramList);
/*     */ 
/*     */     protected abstract T merge(T paramT1, T paramT2);
/*     */ 
/*     */     protected abstract T readOne(ByteBuffer paramByteBuffer);
/*     */ 
/*     */     protected abstract T unmodifiable(T paramT);
/*     */ 
/*     */     protected abstract void write(T paramT, ProtocolSink paramProtocolSink);
/*     */ 
/*     */     protected abstract int encodingSize(T paramT);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.Extensions
 * JD-Core Version:    0.6.0
 */