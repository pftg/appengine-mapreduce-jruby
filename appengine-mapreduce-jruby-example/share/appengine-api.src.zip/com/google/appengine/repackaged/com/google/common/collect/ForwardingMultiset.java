/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Set;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingMultiset<E> extends ForwardingCollection<E>
/*    */   implements Multiset<E>
/*    */ {
/*    */   protected abstract Multiset<E> delegate();
/*    */ 
/*    */   public int count(Object element)
/*    */   {
/* 44 */     return delegate().count(element);
/*    */   }
/*    */ 
/*    */   public int add(E element, int occurrences) {
/* 48 */     return delegate().add(element, occurrences);
/*    */   }
/*    */ 
/*    */   public int remove(Object element, int occurrences) {
/* 52 */     return delegate().remove(element, occurrences);
/*    */   }
/*    */ 
/*    */   public Set<E> elementSet() {
/* 56 */     return delegate().elementSet();
/*    */   }
/*    */ 
/*    */   public Set<Multiset.Entry<E>> entrySet() {
/* 60 */     return delegate().entrySet();
/*    */   }
/*    */ 
/*    */   public boolean equals(@Nullable Object object) {
/* 64 */     return (object == this) || (delegate().equals(object));
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 68 */     return delegate().hashCode();
/*    */   }
/*    */ 
/*    */   public int setCount(E element, int count) {
/* 72 */     return delegate().setCount(element, count);
/*    */   }
/*    */ 
/*    */   public boolean setCount(E element, int oldCount, int newCount) {
/* 76 */     return delegate().setCount(element, oldCount, newCount);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingMultiset
 * JD-Core Version:    0.6.0
 */