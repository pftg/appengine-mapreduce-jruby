/*      */ package com.google.appengine.repackaged.com.google.protobuf;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.math.BigInteger;
/*      */ import java.nio.CharBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ public final class TextFormat
/*      */ {
/*   30 */   private static final Printer DEFAULT_PRINTER = new Printer(false, null);
/*   31 */   private static final Printer SINGLE_LINE_PRINTER = new Printer(true, null);
/*      */   private static final int BUFFER_SIZE = 4096;
/*      */ 
/*      */   public static void print(Message message, Appendable output)
/*      */     throws IOException
/*      */   {
/*   40 */     DEFAULT_PRINTER.print(message, new TextGenerator(output, null));
/*      */   }
/*      */ 
/*      */   public static void print(UnknownFieldSet fields, Appendable output)
/*      */     throws IOException
/*      */   {
/*   47 */     DEFAULT_PRINTER.printUnknownFields(fields, new TextGenerator(output, null));
/*      */   }
/*      */ 
/*      */   public static String shortDebugString(Message message)
/*      */   {
/*      */     try
/*      */     {
/*   56 */       StringBuilder sb = new StringBuilder();
/*   57 */       SINGLE_LINE_PRINTER.print(message, new TextGenerator(sb, null));
/*      */ 
/*   59 */       return sb.toString().trim(); } catch (IOException e) {
/*      */     }
/*   61 */     throw new IllegalStateException(e);
/*      */   }
/*      */ 
/*      */   public static String shortDebugString(UnknownFieldSet fields)
/*      */   {
/*      */     try
/*      */     {
/*   71 */       StringBuilder sb = new StringBuilder();
/*   72 */       SINGLE_LINE_PRINTER.printUnknownFields(fields, new TextGenerator(sb, null));
/*      */ 
/*   74 */       return sb.toString().trim(); } catch (IOException e) {
/*      */     }
/*   76 */     throw new IllegalStateException(e);
/*      */   }
/*      */ 
/*      */   public static String printToString(Message message)
/*      */   {
/*      */     try
/*      */     {
/*   86 */       StringBuilder text = new StringBuilder();
/*   87 */       print(message, text);
/*   88 */       return text.toString(); } catch (IOException e) {
/*      */     }
/*   90 */     throw new IllegalStateException(e);
/*      */   }
/*      */ 
/*      */   public static String printToString(UnknownFieldSet fields)
/*      */   {
/*      */     try
/*      */     {
/*  100 */       StringBuilder text = new StringBuilder();
/*  101 */       print(fields, text);
/*  102 */       return text.toString(); } catch (IOException e) {
/*      */     }
/*  104 */     throw new IllegalStateException(e);
/*      */   }
/*      */ 
/*      */   public static void printField(Descriptors.FieldDescriptor field, Object value, Appendable output)
/*      */     throws IOException
/*      */   {
/*  112 */     DEFAULT_PRINTER.printField(field, value, new TextGenerator(output, null));
/*      */   }
/*      */ 
/*      */   public static String printFieldToString(Descriptors.FieldDescriptor field, Object value)
/*      */   {
/*      */     try {
/*  118 */       StringBuilder text = new StringBuilder();
/*  119 */       printField(field, value, text);
/*  120 */       return text.toString(); } catch (IOException e) {
/*      */     }
/*  122 */     throw new IllegalStateException(e);
/*      */   }
/*      */ 
/*      */   public static void printFieldValue(Descriptors.FieldDescriptor field, Object value, Appendable output)
/*      */     throws IOException
/*      */   {
/*  140 */     DEFAULT_PRINTER.printFieldValue(field, value, new TextGenerator(output, null));
/*      */   }
/*      */ 
/*      */   public static void printUnknownFieldValue(int tag, Object value, Appendable output)
/*      */     throws IOException
/*      */   {
/*  157 */     printUnknownFieldValue(tag, value, new TextGenerator(output, null));
/*      */   }
/*      */ 
/*      */   private static void printUnknownFieldValue(int tag, Object value, TextGenerator generator)
/*      */     throws IOException
/*      */   {
/*  164 */     switch (WireFormat.getTagWireType(tag)) {
/*      */     case 0:
/*  166 */       generator.print(unsignedToString(((Long)value).longValue()));
/*  167 */       break;
/*      */     case 5:
/*  169 */       generator.print(String.format((Locale)null, "0x%08x", new Object[] { (Integer)value }));
/*      */ 
/*  171 */       break;
/*      */     case 1:
/*  173 */       generator.print(String.format((Locale)null, "0x%016x", new Object[] { (Long)value }));
/*  174 */       break;
/*      */     case 2:
/*  176 */       generator.print("\"");
/*  177 */       generator.print(escapeBytes((ByteString)value));
/*  178 */       generator.print("\"");
/*  179 */       break;
/*      */     case 3:
/*  181 */       DEFAULT_PRINTER.printUnknownFields((UnknownFieldSet)value, generator);
/*  182 */       break;
/*      */     case 4:
/*      */     default:
/*  184 */       throw new IllegalArgumentException("Bad tag: " + tag);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String unsignedToString(int value)
/*      */   {
/*  385 */     if (value >= 0) {
/*  386 */       return Integer.toString(value);
/*      */     }
/*  388 */     return Long.toString(value & 0xFFFFFFFF);
/*      */   }
/*      */ 
/*      */   private static String unsignedToString(long value)
/*      */   {
/*  394 */     if (value >= 0L) {
/*  395 */       return Long.toString(value);
/*      */     }
/*      */ 
/*  399 */     return BigInteger.valueOf(value & 0xFFFFFFFF).setBit(63).toString();
/*      */   }
/*      */ 
/*      */   public static void merge(Readable input, Message.Builder builder)
/*      */     throws IOException
/*      */   {
/*  887 */     merge(input, ExtensionRegistry.getEmptyRegistry(), builder);
/*      */   }
/*      */ 
/*      */   public static void merge(CharSequence input, Message.Builder builder)
/*      */     throws TextFormat.ParseException
/*      */   {
/*  897 */     merge(input, ExtensionRegistry.getEmptyRegistry(), builder);
/*      */   }
/*      */ 
/*      */   public static void merge(Readable input, ExtensionRegistry extensionRegistry, Message.Builder builder)
/*      */     throws IOException
/*      */   {
/*  917 */     merge(toStringBuilder(input), extensionRegistry, builder);
/*      */   }
/*      */ 
/*      */   private static StringBuilder toStringBuilder(Readable input)
/*      */     throws IOException
/*      */   {
/*  926 */     StringBuilder text = new StringBuilder();
/*  927 */     CharBuffer buffer = CharBuffer.allocate(4096);
/*      */     while (true) {
/*  929 */       int n = input.read(buffer);
/*  930 */       if (n == -1) {
/*      */         break;
/*      */       }
/*  933 */       buffer.flip();
/*  934 */       text.append(buffer, 0, n);
/*      */     }
/*  936 */     return text;
/*      */   }
/*      */ 
/*      */   public static void merge(CharSequence input, ExtensionRegistry extensionRegistry, Message.Builder builder)
/*      */     throws TextFormat.ParseException
/*      */   {
/*  948 */     Tokenizer tokenizer = new Tokenizer(input, null);
/*      */ 
/*  950 */     while (!tokenizer.atEnd())
/*  951 */       mergeField(tokenizer, extensionRegistry, builder);
/*      */   }
/*      */ 
/*      */   private static void mergeField(Tokenizer tokenizer, ExtensionRegistry extensionRegistry, Message.Builder builder)
/*      */     throws TextFormat.ParseException
/*      */   {
/*  964 */     Descriptors.Descriptor type = builder.getDescriptorForType();
/*  965 */     ExtensionRegistry.ExtensionInfo extension = null;
/*      */     Descriptors.FieldDescriptor field;
/*      */     Descriptors.FieldDescriptor field;
/*  967 */     if (tokenizer.tryConsume("["))
/*      */     {
/*  969 */       StringBuilder name = new StringBuilder(tokenizer.consumeIdentifier());
/*      */ 
/*  971 */       while (tokenizer.tryConsume(".")) {
/*  972 */         name.append('.');
/*  973 */         name.append(tokenizer.consumeIdentifier());
/*      */       }
/*      */ 
/*  976 */       extension = extensionRegistry.findExtensionByName(name.toString());
/*      */ 
/*  978 */       if (extension == null) {
/*  979 */         throw tokenizer.parseExceptionPreviousToken("Extension \"" + name + "\" not found in the ExtensionRegistry.");
/*      */       }
/*  981 */       if (extension.descriptor.getContainingType() != type) {
/*  982 */         throw tokenizer.parseExceptionPreviousToken("Extension \"" + name + "\" does not extend message type \"" + type.getFullName() + "\".");
/*      */       }
/*      */ 
/*  987 */       tokenizer.consume("]");
/*      */ 
/*  989 */       field = extension.descriptor;
/*      */     } else {
/*  991 */       String name = tokenizer.consumeIdentifier();
/*  992 */       field = type.findFieldByName(name);
/*      */ 
/*  997 */       if (field == null)
/*      */       {
/* 1000 */         String lowerName = name.toLowerCase(Locale.US);
/* 1001 */         field = type.findFieldByName(lowerName);
/*      */ 
/* 1003 */         if ((field != null) && (field.getType() != Descriptors.FieldDescriptor.Type.GROUP)) {
/* 1004 */           field = null;
/*      */         }
/*      */       }
/*      */ 
/* 1008 */       if ((field != null) && (field.getType() == Descriptors.FieldDescriptor.Type.GROUP) && (!field.getMessageType().getName().equals(name)))
/*      */       {
/* 1010 */         field = null;
/*      */       }
/*      */ 
/* 1013 */       if (field == null) {
/* 1014 */         throw tokenizer.parseExceptionPreviousToken("Message type \"" + type.getFullName() + "\" has no field named \"" + name + "\".");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1020 */     Object value = null;
/*      */ 
/* 1022 */     if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 1023 */       tokenizer.tryConsume(":");
/*      */       String endToken;
/*      */       String endToken;
/* 1026 */       if (tokenizer.tryConsume("<")) {
/* 1027 */         endToken = ">";
/*      */       } else {
/* 1029 */         tokenizer.consume("{");
/* 1030 */         endToken = "}";
/*      */       }
/*      */       Message.Builder subBuilder;
/*      */       Message.Builder subBuilder;
/* 1034 */       if (extension == null)
/* 1035 */         subBuilder = builder.newBuilderForField(field);
/*      */       else {
/* 1037 */         subBuilder = extension.defaultInstance.newBuilderForType();
/*      */       }
/*      */ 
/* 1040 */       while (!tokenizer.tryConsume(endToken)) {
/* 1041 */         if (tokenizer.atEnd()) {
/* 1042 */           throw tokenizer.parseException("Expected \"" + endToken + "\".");
/*      */         }
/*      */ 
/* 1045 */         mergeField(tokenizer, extensionRegistry, subBuilder);
/*      */       }
/*      */ 
/* 1048 */       value = subBuilder.build();
/*      */     }
/*      */     else {
/* 1051 */       tokenizer.consume(":");
/*      */ 
/* 1053 */       switch (1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$Type[field.getType().ordinal()]) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/* 1057 */         value = Integer.valueOf(tokenizer.consumeInt32());
/* 1058 */         break;
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/* 1063 */         value = Long.valueOf(tokenizer.consumeInt64());
/* 1064 */         break;
/*      */       case 10:
/*      */       case 11:
/* 1068 */         value = Integer.valueOf(tokenizer.consumeUInt32());
/* 1069 */         break;
/*      */       case 12:
/*      */       case 13:
/* 1073 */         value = Long.valueOf(tokenizer.consumeUInt64());
/* 1074 */         break;
/*      */       case 8:
/* 1077 */         value = Float.valueOf(tokenizer.consumeFloat());
/* 1078 */         break;
/*      */       case 9:
/* 1081 */         value = Double.valueOf(tokenizer.consumeDouble());
/* 1082 */         break;
/*      */       case 7:
/* 1085 */         value = Boolean.valueOf(tokenizer.consumeBoolean());
/* 1086 */         break;
/*      */       case 14:
/* 1089 */         value = tokenizer.consumeString();
/* 1090 */         break;
/*      */       case 15:
/* 1093 */         value = tokenizer.consumeByteString();
/* 1094 */         break;
/*      */       case 16:
/* 1097 */         Descriptors.EnumDescriptor enumType = field.getEnumType();
/*      */ 
/* 1099 */         if (tokenizer.lookingAtInteger()) {
/* 1100 */           int number = tokenizer.consumeInt32();
/* 1101 */           value = enumType.findValueByNumber(number);
/* 1102 */           if (value == null) {
/* 1103 */             throw tokenizer.parseExceptionPreviousToken("Enum type \"" + enumType.getFullName() + "\" has no value with number " + number + '.');
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1108 */           String id = tokenizer.consumeIdentifier();
/* 1109 */           value = enumType.findValueByName(id);
/* 1110 */           if (value == null) {
/* 1111 */             throw tokenizer.parseExceptionPreviousToken("Enum type \"" + enumType.getFullName() + "\" has no value named \"" + id + "\".");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1117 */         break;
/*      */       case 17:
/*      */       case 18:
/* 1121 */         throw new RuntimeException("Can't get here.");
/*      */       }
/*      */     }
/*      */ 
/* 1125 */     if (field.isRepeated())
/* 1126 */       builder.addRepeatedField(field, value);
/*      */     else
/* 1128 */       builder.setField(field, value);
/*      */   }
/*      */ 
/*      */   static String escapeBytes(ByteString input)
/*      */   {
/* 1147 */     StringBuilder builder = new StringBuilder(input.size());
/* 1148 */     for (int i = 0; i < input.size(); i++) {
/* 1149 */       byte b = input.byteAt(i);
/* 1150 */       switch (b) {
/*      */       case 7:
/* 1152 */         builder.append("\\a"); break;
/*      */       case 8:
/* 1153 */         builder.append("\\b"); break;
/*      */       case 12:
/* 1154 */         builder.append("\\f"); break;
/*      */       case 10:
/* 1155 */         builder.append("\\n"); break;
/*      */       case 13:
/* 1156 */         builder.append("\\r"); break;
/*      */       case 9:
/* 1157 */         builder.append("\\t"); break;
/*      */       case 11:
/* 1158 */         builder.append("\\v"); break;
/*      */       case 92:
/* 1159 */         builder.append("\\\\"); break;
/*      */       case 39:
/* 1160 */         builder.append("\\'"); break;
/*      */       case 34:
/* 1161 */         builder.append("\\\""); break;
/*      */       default:
/* 1166 */         if (b >= 32) {
/* 1167 */           builder.append((char)b);
/*      */         } else {
/* 1169 */           builder.append('\\');
/* 1170 */           builder.append((char)(48 + (b >>> 6 & 0x3)));
/* 1171 */           builder.append((char)(48 + (b >>> 3 & 0x7)));
/* 1172 */           builder.append((char)(48 + (b & 0x7)));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1177 */     return builder.toString();
/*      */   }
/*      */ 
/*      */   static ByteString unescapeBytes(CharSequence input)
/*      */     throws TextFormat.InvalidEscapeSequenceException
/*      */   {
/* 1187 */     byte[] result = new byte[input.length()];
/* 1188 */     int pos = 0;
/* 1189 */     for (int i = 0; i < input.length(); i++) {
/* 1190 */       char c = input.charAt(i);
/* 1191 */       if (c == '\\') {
/* 1192 */         if (i + 1 < input.length()) {
/* 1193 */           i++;
/* 1194 */           c = input.charAt(i);
/* 1195 */           if (isOctal(c))
/*      */           {
/* 1197 */             int code = digitValue(c);
/* 1198 */             if ((i + 1 < input.length()) && (isOctal(input.charAt(i + 1)))) {
/* 1199 */               i++;
/* 1200 */               code = code * 8 + digitValue(input.charAt(i));
/*      */             }
/* 1202 */             if ((i + 1 < input.length()) && (isOctal(input.charAt(i + 1)))) {
/* 1203 */               i++;
/* 1204 */               code = code * 8 + digitValue(input.charAt(i));
/*      */             }
/* 1206 */             result[(pos++)] = (byte)code;
/*      */           } else {
/* 1208 */             switch (c) { case 'a':
/* 1209 */               result[(pos++)] = 7; break;
/*      */             case 'b':
/* 1210 */               result[(pos++)] = 8; break;
/*      */             case 'f':
/* 1211 */               result[(pos++)] = 12; break;
/*      */             case 'n':
/* 1212 */               result[(pos++)] = 10; break;
/*      */             case 'r':
/* 1213 */               result[(pos++)] = 13; break;
/*      */             case 't':
/* 1214 */               result[(pos++)] = 9; break;
/*      */             case 'v':
/* 1215 */               result[(pos++)] = 11; break;
/*      */             case '\\':
/* 1216 */               result[(pos++)] = 92; break;
/*      */             case '\'':
/* 1217 */               result[(pos++)] = 39; break;
/*      */             case '"':
/* 1218 */               result[(pos++)] = 34; break;
/*      */             case 'x':
/* 1222 */               int code = 0;
/* 1223 */               if ((i + 1 < input.length()) && (isHex(input.charAt(i + 1)))) {
/* 1224 */                 i++;
/* 1225 */                 code = digitValue(input.charAt(i));
/*      */               } else {
/* 1227 */                 throw new InvalidEscapeSequenceException("Invalid escape sequence: '\\x' with no digits");
/*      */               }
/*      */ 
/* 1230 */               if ((i + 1 < input.length()) && (isHex(input.charAt(i + 1)))) {
/* 1231 */                 i++;
/* 1232 */                 code = code * 16 + digitValue(input.charAt(i));
/*      */               }
/* 1234 */               result[(pos++)] = (byte)code;
/* 1235 */               break;
/*      */             default:
/* 1238 */               throw new InvalidEscapeSequenceException("Invalid escape sequence: '\\" + c + '\''); }
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1243 */           throw new InvalidEscapeSequenceException("Invalid escape sequence: '\\' at end of string.");
/*      */         }
/*      */       }
/*      */       else {
/* 1247 */         result[(pos++)] = (byte)c;
/*      */       }
/*      */     }
/*      */ 
/* 1251 */     return ByteString.copyFrom(result, 0, pos);
/*      */   }
/*      */ 
/*      */   static String escapeText(String input)
/*      */   {
/* 1272 */     return escapeBytes(ByteString.copyFromUtf8(input));
/*      */   }
/*      */ 
/*      */   static String unescapeText(String input)
/*      */     throws TextFormat.InvalidEscapeSequenceException
/*      */   {
/* 1281 */     return unescapeBytes(input).toStringUtf8();
/*      */   }
/*      */ 
/*      */   private static boolean isOctal(char c)
/*      */   {
/* 1286 */     return ('0' <= c) && (c <= '7');
/*      */   }
/*      */ 
/*      */   private static boolean isHex(char c)
/*      */   {
/* 1291 */     return (('0' <= c) && (c <= '9')) || (('a' <= c) && (c <= 'f')) || (('A' <= c) && (c <= 'F'));
/*      */   }
/*      */ 
/*      */   private static int digitValue(char c)
/*      */   {
/* 1302 */     if (('0' <= c) && (c <= '9'))
/* 1303 */       return c - '0';
/* 1304 */     if (('a' <= c) && (c <= 'z')) {
/* 1305 */       return c - 'a' + 10;
/*      */     }
/* 1307 */     return c - 'A' + 10;
/*      */   }
/*      */ 
/*      */   static int parseInt32(String text)
/*      */     throws NumberFormatException
/*      */   {
/* 1317 */     return (int)parseInteger(text, true, false);
/*      */   }
/*      */ 
/*      */   static int parseUInt32(String text)
/*      */     throws NumberFormatException
/*      */   {
/* 1328 */     return (int)parseInteger(text, false, false);
/*      */   }
/*      */ 
/*      */   static long parseInt64(String text)
/*      */     throws NumberFormatException
/*      */   {
/* 1337 */     return parseInteger(text, true, true);
/*      */   }
/*      */ 
/*      */   static long parseUInt64(String text)
/*      */     throws NumberFormatException
/*      */   {
/* 1348 */     return parseInteger(text, false, true);
/*      */   }
/*      */ 
/*      */   private static long parseInteger(String text, boolean isSigned, boolean isLong)
/*      */     throws NumberFormatException
/*      */   {
/* 1355 */     int pos = 0;
/*      */ 
/* 1357 */     boolean negative = false;
/* 1358 */     if (text.startsWith("-", pos)) {
/* 1359 */       if (!isSigned) {
/* 1360 */         throw new NumberFormatException("Number must be positive: " + text);
/*      */       }
/* 1362 */       pos++;
/* 1363 */       negative = true;
/*      */     }
/*      */ 
/* 1366 */     int radix = 10;
/* 1367 */     if (text.startsWith("0x", pos)) {
/* 1368 */       pos += 2;
/* 1369 */       radix = 16;
/* 1370 */     } else if (text.startsWith("0", pos)) {
/* 1371 */       radix = 8;
/*      */     }
/*      */ 
/* 1374 */     String numberText = text.substring(pos);
/*      */ 
/* 1376 */     long result = 0L;
/* 1377 */     if (numberText.length() < 16)
/*      */     {
/* 1379 */       result = Long.parseLong(numberText, radix);
/* 1380 */       if (negative) {
/* 1381 */         result = -result;
/*      */       }
/*      */ 
/* 1387 */       if (!isLong) {
/* 1388 */         if (isSigned) {
/* 1389 */           if ((result > 2147483647L) || (result < -2147483648L)) {
/* 1390 */             throw new NumberFormatException("Number out of range for 32-bit signed integer: " + text);
/*      */           }
/*      */ 
/*      */         }
/* 1394 */         else if ((result >= 4294967296L) || (result < 0L)) {
/* 1395 */           throw new NumberFormatException("Number out of range for 32-bit unsigned integer: " + text);
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1401 */       BigInteger bigValue = new BigInteger(numberText, radix);
/* 1402 */       if (negative) {
/* 1403 */         bigValue = bigValue.negate();
/*      */       }
/*      */ 
/* 1407 */       if (!isLong) {
/* 1408 */         if (isSigned) {
/* 1409 */           if (bigValue.bitLength() > 31) {
/* 1410 */             throw new NumberFormatException("Number out of range for 32-bit signed integer: " + text);
/*      */           }
/*      */ 
/*      */         }
/* 1414 */         else if (bigValue.bitLength() > 32) {
/* 1415 */           throw new NumberFormatException("Number out of range for 32-bit unsigned integer: " + text);
/*      */         }
/*      */ 
/*      */       }
/* 1420 */       else if (isSigned) {
/* 1421 */         if (bigValue.bitLength() > 63) {
/* 1422 */           throw new NumberFormatException("Number out of range for 64-bit signed integer: " + text);
/*      */         }
/*      */ 
/*      */       }
/* 1426 */       else if (bigValue.bitLength() > 64) {
/* 1427 */         throw new NumberFormatException("Number out of range for 64-bit unsigned integer: " + text);
/*      */       }
/*      */ 
/* 1433 */       result = bigValue.longValue();
/*      */     }
/*      */ 
/* 1436 */     return result;
/*      */   }
/*      */ 
/*      */   static class InvalidEscapeSequenceException extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = -8164033650142593304L;
/*      */ 
/*      */     InvalidEscapeSequenceException(String description)
/*      */     {
/* 1262 */       super();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ParseException extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = 3196188060225107702L;
/*      */ 
/*      */     public ParseException(String message)
/*      */     {
/*  876 */       super();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Tokenizer
/*      */   {
/*      */     private final CharSequence text;
/*      */     private final Matcher matcher;
/*      */     private String currentToken;
/*  505 */     private int pos = 0;
/*      */ 
/*  508 */     private int line = 0;
/*  509 */     private int column = 0;
/*      */ 
/*  513 */     private int previousLine = 0;
/*  514 */     private int previousColumn = 0;
/*      */ 
/*  518 */     private static final Pattern WHITESPACE = Pattern.compile("(\\s|(#.*$))++", 8);
/*      */ 
/*  520 */     private static final Pattern TOKEN = Pattern.compile("[a-zA-Z_][0-9a-zA-Z_+-]*+|[.]?[0-9+-][0-9a-zA-Z_.+-]*+|\"([^\"\n\\\\]|\\\\.)*+(\"|\\\\?$)|'([^'\n\\\\]|\\\\.)*+('|\\\\?$)", 8);
/*      */ 
/*  527 */     private static final Pattern DOUBLE_INFINITY = Pattern.compile("-?inf(inity)?", 2);
/*      */ 
/*  530 */     private static final Pattern FLOAT_INFINITY = Pattern.compile("-?inf(inity)?f?", 2);
/*      */ 
/*  533 */     private static final Pattern FLOAT_NAN = Pattern.compile("nanf?", 2);
/*      */ 
/*      */     private Tokenizer(CharSequence text)
/*      */     {
/*  539 */       this.text = text;
/*  540 */       this.matcher = WHITESPACE.matcher(text);
/*  541 */       skipWhitespace();
/*  542 */       nextToken();
/*      */     }
/*      */ 
/*      */     public boolean atEnd()
/*      */     {
/*  547 */       return this.currentToken.length() == 0;
/*      */     }
/*      */ 
/*      */     public void nextToken()
/*      */     {
/*  552 */       this.previousLine = this.line;
/*  553 */       this.previousColumn = this.column;
/*      */ 
/*  556 */       while (this.pos < this.matcher.regionStart()) {
/*  557 */         if (this.text.charAt(this.pos) == '\n') {
/*  558 */           this.line += 1;
/*  559 */           this.column = 0;
/*      */         } else {
/*  561 */           this.column += 1;
/*      */         }
/*  563 */         this.pos += 1;
/*      */       }
/*      */ 
/*  567 */       if (this.matcher.regionStart() == this.matcher.regionEnd())
/*      */       {
/*  569 */         this.currentToken = "";
/*      */       } else {
/*  571 */         this.matcher.usePattern(TOKEN);
/*  572 */         if (this.matcher.lookingAt()) {
/*  573 */           this.currentToken = this.matcher.group();
/*  574 */           this.matcher.region(this.matcher.end(), this.matcher.regionEnd());
/*      */         }
/*      */         else {
/*  577 */           this.currentToken = String.valueOf(this.text.charAt(this.pos));
/*  578 */           this.matcher.region(this.pos + 1, this.matcher.regionEnd());
/*      */         }
/*      */ 
/*  581 */         skipWhitespace();
/*      */       }
/*      */     }
/*      */ 
/*      */     private void skipWhitespace()
/*      */     {
/*  590 */       this.matcher.usePattern(WHITESPACE);
/*  591 */       if (this.matcher.lookingAt())
/*  592 */         this.matcher.region(this.matcher.end(), this.matcher.regionEnd());
/*      */     }
/*      */ 
/*      */     public boolean tryConsume(String token)
/*      */     {
/*  601 */       if (this.currentToken.equals(token)) {
/*  602 */         nextToken();
/*  603 */         return true;
/*      */       }
/*  605 */       return false;
/*      */     }
/*      */ 
/*      */     public void consume(String token)
/*      */       throws TextFormat.ParseException
/*      */     {
/*  614 */       if (!tryConsume(token))
/*  615 */         throw parseException("Expected \"" + token + "\".");
/*      */     }
/*      */ 
/*      */     public boolean lookingAtInteger()
/*      */     {
/*  624 */       if (this.currentToken.length() == 0) {
/*  625 */         return false;
/*      */       }
/*      */ 
/*  628 */       char c = this.currentToken.charAt(0);
/*  629 */       return (('0' <= c) && (c <= '9')) || (c == '-') || (c == '+');
/*      */     }
/*      */ 
/*      */     public String consumeIdentifier()
/*      */       throws TextFormat.ParseException
/*      */     {
/*  638 */       for (int i = 0; i < this.currentToken.length(); i++) {
/*  639 */         char c = this.currentToken.charAt(i);
/*  640 */         if ((('a' <= c) && (c <= 'z')) || (('A' <= c) && (c <= 'Z')) || (('0' <= c) && (c <= '9')) || (c == '_') || (c == '.'))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/*  646 */         throw parseException("Expected identifier.");
/*      */       }
/*      */ 
/*  650 */       String result = this.currentToken;
/*  651 */       nextToken();
/*  652 */       return result;
/*      */     }
/*      */ 
/*      */     public int consumeInt32()
/*      */       throws TextFormat.ParseException
/*      */     {
/*      */       try
/*      */       {
/*  661 */         int result = TextFormat.parseInt32(this.currentToken);
/*  662 */         nextToken();
/*  663 */         return result; } catch (NumberFormatException e) {
/*      */       }
/*  665 */       throw integerParseException(e);
/*      */     }
/*      */ 
/*      */     public int consumeUInt32()
/*      */       throws TextFormat.ParseException
/*      */     {
/*      */       try
/*      */       {
/*  675 */         int result = TextFormat.parseUInt32(this.currentToken);
/*  676 */         nextToken();
/*  677 */         return result; } catch (NumberFormatException e) {
/*      */       }
/*  679 */       throw integerParseException(e);
/*      */     }
/*      */ 
/*      */     public long consumeInt64()
/*      */       throws TextFormat.ParseException
/*      */     {
/*      */       try
/*      */       {
/*  689 */         long result = TextFormat.parseInt64(this.currentToken);
/*  690 */         nextToken();
/*  691 */         return result; } catch (NumberFormatException e) {
/*      */       }
/*  693 */       throw integerParseException(e);
/*      */     }
/*      */ 
/*      */     public long consumeUInt64()
/*      */       throws TextFormat.ParseException
/*      */     {
/*      */       try
/*      */       {
/*  703 */         long result = TextFormat.parseUInt64(this.currentToken);
/*  704 */         nextToken();
/*  705 */         return result; } catch (NumberFormatException e) {
/*      */       }
/*  707 */       throw integerParseException(e);
/*      */     }
/*      */ 
/*      */     public double consumeDouble()
/*      */       throws TextFormat.ParseException
/*      */     {
/*  718 */       if (DOUBLE_INFINITY.matcher(this.currentToken).matches()) {
/*  719 */         boolean negative = this.currentToken.startsWith("-");
/*  720 */         nextToken();
/*  721 */         return negative ? (-1.0D / 0.0D) : (1.0D / 0.0D);
/*      */       }
/*  723 */       if (this.currentToken.equalsIgnoreCase("nan")) {
/*  724 */         nextToken();
/*  725 */         return (0.0D / 0.0D);
/*      */       }
/*      */       try {
/*  728 */         double result = Double.parseDouble(this.currentToken);
/*  729 */         nextToken();
/*  730 */         return result; } catch (NumberFormatException e) {
/*      */       }
/*  732 */       throw floatParseException(e);
/*      */     }
/*      */ 
/*      */     public float consumeFloat()
/*      */       throws TextFormat.ParseException
/*      */     {
/*  743 */       if (FLOAT_INFINITY.matcher(this.currentToken).matches()) {
/*  744 */         boolean negative = this.currentToken.startsWith("-");
/*  745 */         nextToken();
/*  746 */         return negative ? (1.0F / -1.0F) : (1.0F / 1.0F);
/*      */       }
/*  748 */       if (FLOAT_NAN.matcher(this.currentToken).matches()) {
/*  749 */         nextToken();
/*  750 */         return (0.0F / 0.0F);
/*      */       }
/*      */       try {
/*  753 */         float result = Float.parseFloat(this.currentToken);
/*  754 */         nextToken();
/*  755 */         return result; } catch (NumberFormatException e) {
/*      */       }
/*  757 */       throw floatParseException(e);
/*      */     }
/*      */ 
/*      */     public boolean consumeBoolean()
/*      */       throws TextFormat.ParseException
/*      */     {
/*  766 */       if ((this.currentToken.equals("true")) || (this.currentToken.equals("t")) || (this.currentToken.equals("1")))
/*      */       {
/*  769 */         nextToken();
/*  770 */         return true;
/*  771 */       }if ((this.currentToken.equals("false")) || (this.currentToken.equals("f")) || (this.currentToken.equals("0")))
/*      */       {
/*  774 */         nextToken();
/*  775 */         return false;
/*      */       }
/*  777 */       throw parseException("Expected \"true\" or \"false\".");
/*      */     }
/*      */ 
/*      */     public String consumeString()
/*      */       throws TextFormat.ParseException
/*      */     {
/*  786 */       return consumeByteString().toStringUtf8();
/*      */     }
/*      */ 
/*      */     public ByteString consumeByteString()
/*      */       throws TextFormat.ParseException
/*      */     {
/*  795 */       List list = new ArrayList();
/*  796 */       consumeByteString(list);
/*  797 */       while ((this.currentToken.startsWith("'")) || (this.currentToken.startsWith("\""))) {
/*  798 */         consumeByteString(list);
/*      */       }
/*  800 */       return ByteString.copyFrom(list);
/*      */     }
/*      */ 
/*      */     private void consumeByteString(List<ByteString> list)
/*      */       throws TextFormat.ParseException
/*      */     {
/*  810 */       char quote = this.currentToken.length() > 0 ? this.currentToken.charAt(0) : '\000';
/*      */ 
/*  812 */       if ((quote != '"') && (quote != '\'')) {
/*  813 */         throw parseException("Expected string.");
/*      */       }
/*      */ 
/*  816 */       if ((this.currentToken.length() < 2) || (this.currentToken.charAt(this.currentToken.length() - 1) != quote))
/*      */       {
/*  818 */         throw parseException("String missing ending quote.");
/*      */       }
/*      */       try
/*      */       {
/*  822 */         String escaped = this.currentToken.substring(1, this.currentToken.length() - 1);
/*      */ 
/*  824 */         ByteString result = TextFormat.unescapeBytes(escaped);
/*  825 */         nextToken();
/*  826 */         list.add(result);
/*      */       } catch (TextFormat.InvalidEscapeSequenceException e) {
/*  828 */         throw parseException(e.getMessage());
/*      */       }
/*      */     }
/*      */ 
/*      */     public TextFormat.ParseException parseException(String description)
/*      */     {
/*  838 */       return new TextFormat.ParseException(this.line + 1 + ":" + (this.column + 1) + ": " + description);
/*      */     }
/*      */ 
/*      */     public TextFormat.ParseException parseExceptionPreviousToken(String description)
/*      */     {
/*  849 */       return new TextFormat.ParseException(this.previousLine + 1 + ":" + (this.previousColumn + 1) + ": " + description);
/*      */     }
/*      */ 
/*      */     private TextFormat.ParseException integerParseException(NumberFormatException e)
/*      */     {
/*  859 */       return parseException("Couldn't parse integer: " + e.getMessage());
/*      */     }
/*      */ 
/*      */     private TextFormat.ParseException floatParseException(NumberFormatException e)
/*      */     {
/*  867 */       return parseException("Couldn't parse number: " + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class TextGenerator
/*      */   {
/*      */     private final Appendable output;
/*  409 */     private final StringBuilder indent = new StringBuilder();
/*  410 */     private boolean atStartOfLine = true;
/*      */ 
/*      */     private TextGenerator(Appendable output) {
/*  413 */       this.output = output;
/*      */     }
/*      */ 
/*      */     public void indent()
/*      */     {
/*  422 */       this.indent.append("  ");
/*      */     }
/*      */ 
/*      */     public void outdent()
/*      */     {
/*  430 */       int length = this.indent.length();
/*  431 */       if (length == 0) {
/*  432 */         throw new IllegalArgumentException(" Outdent() without matching Indent().");
/*      */       }
/*      */ 
/*  435 */       this.indent.delete(length - 2, length);
/*      */     }
/*      */ 
/*      */     public void print(CharSequence text)
/*      */       throws IOException
/*      */     {
/*  442 */       int size = text.length();
/*  443 */       int pos = 0;
/*      */ 
/*  445 */       for (int i = 0; i < size; i++) {
/*  446 */         if (text.charAt(i) == '\n') {
/*  447 */           write(text.subSequence(pos, size), i - pos + 1);
/*  448 */           pos = i + 1;
/*  449 */           this.atStartOfLine = true;
/*      */         }
/*      */       }
/*  452 */       write(text.subSequence(pos, size), size - pos);
/*      */     }
/*      */ 
/*      */     private void write(CharSequence data, int size) throws IOException
/*      */     {
/*  457 */       if (size == 0) {
/*  458 */         return;
/*      */       }
/*  460 */       if (this.atStartOfLine) {
/*  461 */         this.atStartOfLine = false;
/*  462 */         this.output.append(this.indent);
/*      */       }
/*  464 */       this.output.append(data);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Printer
/*      */   {
/*      */     final boolean singleLineMode;
/*      */ 
/*      */     private Printer(boolean singleLineMode)
/*      */     {
/*  194 */       this.singleLineMode = singleLineMode;
/*      */     }
/*      */ 
/*      */     private void print(Message message, TextFormat.TextGenerator generator)
/*      */       throws IOException
/*      */     {
/*  200 */       for (Map.Entry field : message.getAllFields().entrySet()) {
/*  201 */         printField((Descriptors.FieldDescriptor)field.getKey(), field.getValue(), generator);
/*      */       }
/*  203 */       printUnknownFields(message.getUnknownFields(), generator);
/*      */     }
/*      */ 
/*      */     private void printField(Descriptors.FieldDescriptor field, Object value, TextFormat.TextGenerator generator)
/*      */       throws IOException
/*      */     {
/*      */       Iterator i$;
/*  208 */       if (field.isRepeated())
/*      */       {
/*  210 */         for (i$ = ((List)value).iterator(); i$.hasNext(); ) { Object element = i$.next();
/*  211 */           printSingleField(field, element, generator); }
/*      */       }
/*      */       else
/*  214 */         printSingleField(field, value, generator);
/*      */     }
/*      */ 
/*      */     private void printSingleField(Descriptors.FieldDescriptor field, Object value, TextFormat.TextGenerator generator)
/*      */       throws IOException
/*      */     {
/*  222 */       if (field.isExtension()) {
/*  223 */         generator.print("[");
/*      */ 
/*  225 */         if ((field.getContainingType().getOptions().getMessageSetWireFormat()) && (field.getType() == Descriptors.FieldDescriptor.Type.MESSAGE) && (field.isOptional()) && (field.getExtensionScope() == field.getMessageType()))
/*      */         {
/*  230 */           generator.print(field.getMessageType().getFullName());
/*      */         }
/*  232 */         else generator.print(field.getFullName());
/*      */ 
/*  234 */         generator.print("]");
/*      */       }
/*  236 */       else if (field.getType() == Descriptors.FieldDescriptor.Type.GROUP)
/*      */       {
/*  238 */         generator.print(field.getMessageType().getName());
/*      */       } else {
/*  240 */         generator.print(field.getName());
/*      */       }
/*      */ 
/*  244 */       if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/*  245 */         if (this.singleLineMode) {
/*  246 */           generator.print(" { ");
/*      */         } else {
/*  248 */           generator.print(" {\n");
/*  249 */           generator.indent();
/*      */         }
/*      */       }
/*  252 */       else generator.print(": ");
/*      */ 
/*  255 */       printFieldValue(field, value, generator);
/*      */ 
/*  257 */       if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/*  258 */         if (this.singleLineMode) {
/*  259 */           generator.print("} ");
/*      */         } else {
/*  261 */           generator.outdent();
/*  262 */           generator.print("}\n");
/*      */         }
/*      */       }
/*  265 */       else if (this.singleLineMode)
/*  266 */         generator.print(" ");
/*      */       else
/*  268 */         generator.print("\n");
/*      */     }
/*      */ 
/*      */     private void printFieldValue(Descriptors.FieldDescriptor field, Object value, TextFormat.TextGenerator generator)
/*      */       throws IOException
/*      */     {
/*  277 */       switch (TextFormat.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$Type[field.getType().ordinal()]) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*  281 */         generator.print(((Integer)value).toString());
/*  282 */         break;
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*  287 */         generator.print(((Long)value).toString());
/*  288 */         break;
/*      */       case 7:
/*  291 */         generator.print(((Boolean)value).toString());
/*  292 */         break;
/*      */       case 8:
/*  295 */         generator.print(((Float)value).toString());
/*  296 */         break;
/*      */       case 9:
/*  299 */         generator.print(((Double)value).toString());
/*  300 */         break;
/*      */       case 10:
/*      */       case 11:
/*  304 */         generator.print(TextFormat.access$600(((Integer)value).intValue()));
/*  305 */         break;
/*      */       case 12:
/*      */       case 13:
/*  309 */         generator.print(TextFormat.access$700(((Long)value).longValue()));
/*  310 */         break;
/*      */       case 14:
/*  313 */         generator.print("\"");
/*  314 */         generator.print(TextFormat.escapeText((String)value));
/*  315 */         generator.print("\"");
/*  316 */         break;
/*      */       case 15:
/*  319 */         generator.print("\"");
/*  320 */         generator.print(TextFormat.escapeBytes((ByteString)value));
/*  321 */         generator.print("\"");
/*  322 */         break;
/*      */       case 16:
/*  325 */         generator.print(((Descriptors.EnumValueDescriptor)value).getName());
/*  326 */         break;
/*      */       case 17:
/*      */       case 18:
/*  330 */         print((Message)value, generator);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void printUnknownFields(UnknownFieldSet unknownFields, TextFormat.TextGenerator generator)
/*      */       throws IOException
/*      */     {
/*  339 */       for (Iterator i$ = unknownFields.asMap().entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
/*  340 */         int number = ((Integer)entry.getKey()).intValue();
/*  341 */         UnknownFieldSet.Field field = (UnknownFieldSet.Field)entry.getValue();
/*  342 */         printUnknownField(number, 0, field.getVarintList(), generator);
/*      */ 
/*  344 */         printUnknownField(number, 5, field.getFixed32List(), generator);
/*      */ 
/*  346 */         printUnknownField(number, 1, field.getFixed64List(), generator);
/*      */ 
/*  348 */         printUnknownField(number, 2, field.getLengthDelimitedList(), generator);
/*      */ 
/*  350 */         for (UnknownFieldSet value : field.getGroupList()) {
/*  351 */           generator.print(((Integer)entry.getKey()).toString());
/*  352 */           if (this.singleLineMode) {
/*  353 */             generator.print(" { ");
/*      */           } else {
/*  355 */             generator.print(" {\n");
/*  356 */             generator.indent();
/*      */           }
/*  358 */           printUnknownFields(value, generator);
/*  359 */           if (this.singleLineMode) {
/*  360 */             generator.print("} ");
/*      */           } else {
/*  362 */             generator.outdent();
/*  363 */             generator.print("}\n");
/*      */           }
/*      */         }
/*      */       }
/*      */       Map.Entry entry;
/*      */     }
/*      */ 
/*      */     private void printUnknownField(int number, int wireType, List<?> values, TextFormat.TextGenerator generator)
/*      */       throws IOException
/*      */     {
/*  374 */       for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/*  375 */         generator.print(String.valueOf(number));
/*  376 */         generator.print(": ");
/*  377 */         TextFormat.access$800(wireType, value, generator);
/*  378 */         generator.print(this.singleLineMode ? " " : "\n");
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.TextFormat
 * JD-Core Version:    0.6.0
 */