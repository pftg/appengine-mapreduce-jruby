/*     */ package com.google.appengine.api.users;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public final class User
/*     */   implements Serializable, Comparable<User>
/*     */ {
/*     */   static final long serialVersionUID = 8691571286358652288L;
/*     */   private String email;
/*     */   private String authDomain;
/*     */   private String userId;
/*     */   private String federatedIdentity;
/*     */ 
/*     */   private User()
/*     */   {
/*     */   }
/*     */ 
/*     */   public User(String email, String authDomain)
/*     */   {
/*  57 */     this(email, authDomain, null);
/*     */   }
/*     */ 
/*     */   public User(String email, String authDomain, String userId)
/*     */   {
/*  70 */     if (email == null) {
/*  71 */       throw new NullPointerException("email must be specified");
/*     */     }
/*  73 */     if (authDomain == null) {
/*  74 */       throw new NullPointerException("authDomain must be specified");
/*     */     }
/*  76 */     this.email = email;
/*  77 */     this.authDomain = authDomain;
/*  78 */     this.userId = userId;
/*     */   }
/*     */ 
/*     */   public User(String email, String authDomain, String userId, String federatedIdentity)
/*     */   {
/*  90 */     if (federatedIdentity == null) {
/*  91 */       throw new NullPointerException("Identity must be specified");
/*     */     }
/*  93 */     if (authDomain == null)
/*  94 */       this.authDomain = "";
/*     */     else {
/*  96 */       this.authDomain = authDomain;
/*     */     }
/*  98 */     if (userId == null)
/*  99 */       this.userId = "";
/*     */     else {
/* 101 */       this.userId = userId;
/*     */     }
/* 103 */     this.email = email;
/* 104 */     this.federatedIdentity = federatedIdentity;
/*     */   }
/*     */ 
/*     */   public String getNickname()
/*     */   {
/* 114 */     int indexOfDomain = this.email.indexOf("@" + this.authDomain);
/* 115 */     if (indexOfDomain == -1) {
/* 116 */       return this.email;
/*     */     }
/* 118 */     return this.email.substring(0, indexOfDomain);
/*     */   }
/*     */ 
/*     */   public String getAuthDomain() {
/* 122 */     return this.authDomain;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 126 */     return this.email;
/*     */   }
/*     */ 
/*     */   public String getUserId()
/*     */   {
/* 137 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public String getFederatedIdentity() {
/* 141 */     return this.federatedIdentity;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 145 */     return this.email;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 152 */     if (!(object instanceof User)) {
/* 153 */       return false;
/*     */     }
/*     */ 
/* 156 */     User user = (User)object;
/* 157 */     if ((this.federatedIdentity != null) && (!this.federatedIdentity.equals(""))) {
/* 158 */       return user.federatedIdentity.equals(this.federatedIdentity);
/*     */     }
/* 160 */     return (user.email.equals(this.email)) && (user.authDomain.equals(this.authDomain));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 167 */     return 17 * this.email.hashCode() + this.authDomain.hashCode();
/*     */   }
/*     */ 
/*     */   public int compareTo(User user) {
/* 171 */     return this.email.compareTo(user.email);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.users.User
 * JD-Core Version:    0.6.0
 */