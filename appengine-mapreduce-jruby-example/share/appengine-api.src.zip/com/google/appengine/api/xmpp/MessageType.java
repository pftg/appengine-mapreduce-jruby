/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ public enum MessageType
/*    */ {
/* 11 */   CHAT, 
/* 12 */   ERROR, 
/* 13 */   GROUPCHAT, 
/* 14 */   HEADLINE, 
/* 15 */   NORMAL;
/*    */ 
/*    */   String getInternalName() {
/* 18 */     return name().toLowerCase();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.MessageType
 * JD-Core Version:    0.6.0
 */