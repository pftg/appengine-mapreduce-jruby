package javax.mail;

public abstract interface MessageAware
{
  public abstract MessageContext getMessageContext();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.MessageAware
 * JD-Core Version:    0.6.0
 */