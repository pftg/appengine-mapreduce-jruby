/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class Fingerprinting
/*     */ {
/*     */   public static long fingerprintWord(String word)
/*     */   {
/*  30 */     return Hash.hash64(word);
/*     */   }
/*     */ 
/*     */   public static void fingerprintWords(String[] words, long[] wordFps)
/*     */     throws IllegalArgumentException
/*     */   {
/*  42 */     Preconditions.checkArgument(wordFps.length >= words.length);
/*  43 */     for (int i = 0; i < words.length; i++)
/*  44 */       wordFps[i] = fingerprintWord(words[i]);
/*     */   }
/*     */ 
/*     */   public static long combineUnordered(long x, long y)
/*     */   {
/*  57 */     return x + y;
/*     */   }
/*     */ 
/*     */   public static long uncombineUnordered(long combinedFp, long fp)
/*     */   {
/*  72 */     return combinedFp - fp;
/*     */   }
/*     */ 
/*     */   public static long addToOrdered(long sequenceFp, long wordFp)
/*     */   {
/*  85 */     return wordFp + (sequenceFp << 1) + (sequenceFp < 0L ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public static long unorderedFingerprint(long[] wordFps)
/*     */   {
/*  96 */     long fp = 0L;
/*  97 */     for (long wordFp : wordFps) {
/*  98 */       fp = combineUnordered(fp, wordFp);
/*     */     }
/* 100 */     return fp;
/*     */   }
/*     */ 
/*     */   public static long orderedFingerprint(long[] wordFps)
/*     */   {
/* 120 */     long fp = 3141592653589793238L;
/* 121 */     for (long wordFp : wordFps) {
/* 122 */       fp = addToOrdered(fp, wordFp);
/*     */     }
/* 124 */     return fp;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Fingerprinting
 * JD-Core Version:    0.6.0
 */