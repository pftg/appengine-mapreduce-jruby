/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*    */ 
/*    */ final class ImmutableSortedAsList<E> extends RegularImmutableList<E>
/*    */ {
/*    */   private final transient ImmutableSortedSet<E> set;
/*    */ 
/*    */   ImmutableSortedAsList(Object[] array, int offset, int size, ImmutableSortedSet<E> set)
/*    */   {
/* 33 */     super(array, offset, size);
/* 34 */     this.set = set;
/*    */   }
/*    */ 
/*    */   public boolean contains(Object target)
/*    */   {
/* 41 */     return this.set.indexOf(target) >= 0;
/*    */   }
/*    */ 
/*    */   public int indexOf(Object target) {
/* 45 */     return this.set.indexOf(target);
/*    */   }
/*    */ 
/*    */   public int lastIndexOf(Object target) {
/* 49 */     return this.set.indexOf(target);
/*    */   }
/*    */ 
/*    */   public ImmutableList<E> subList(int fromIndex, int toIndex)
/*    */   {
/* 55 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/* 56 */     return fromIndex == toIndex ? ImmutableList.of() : new RegularImmutableSortedSet(array(), this.set.comparator(), offset() + fromIndex, offset() + toIndex).asList();
/*    */   }
/*    */ 
/*    */   Object writeReplace()
/*    */   {
/* 65 */     return new ImmutableAsList.SerializedForm(this.set);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableSortedAsList
 * JD-Core Version:    0.6.0
 */