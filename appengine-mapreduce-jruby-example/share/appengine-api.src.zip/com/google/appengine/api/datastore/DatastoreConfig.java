/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract interface DatastoreConfig
/*    */ {
/*    */ 
/*    */   @Deprecated
/* 28 */   public static final DatastoreConfig DEFAULT = new DatastoreConfig() {
/*    */     public ImplicitTransactionManagementPolicy getImplicitTransactionManagementPolicy() {
/* 30 */       return ImplicitTransactionManagementPolicy.NONE;
/*    */     }
/* 28 */   };
/*    */ 
/*    */   @Deprecated
/*    */   public abstract ImplicitTransactionManagementPolicy getImplicitTransactionManagementPolicy();
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreConfig
 * JD-Core Version:    0.6.0
 */