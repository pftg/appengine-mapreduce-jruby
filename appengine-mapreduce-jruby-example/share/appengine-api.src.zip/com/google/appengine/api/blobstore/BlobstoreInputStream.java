/*     */ package com.google.appengine.api.blobstore;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public final class BlobstoreInputStream extends InputStream
/*     */ {
/*     */   private final BlobKey blobKey;
/*     */   private final BlobInfo blobInfo;
/*     */   private long blobOffset;
/*     */   private byte[] buffer;
/*     */   private int bufferOffset;
/*  61 */   private boolean markSet = false;
/*     */   private long markOffset;
/*     */   private final BlobstoreService blobstoreService;
/*     */ 
/*     */   public BlobstoreInputStream(BlobKey blobKey, long offset)
/*     */     throws IOException
/*     */   {
/*  80 */     this(blobKey, offset, new BlobInfoFactory(), BlobstoreServiceFactory.getBlobstoreService());
/*     */   }
/*     */ 
/*     */   public BlobstoreInputStream(BlobKey blobKey)
/*     */     throws IOException
/*     */   {
/*  92 */     this(blobKey, 0L);
/*     */   }
/*     */ 
/*     */   BlobstoreInputStream(BlobKey blobKey, long offset, BlobInfoFactory blobInfoFactory, BlobstoreService blobstoreService)
/*     */     throws IOException
/*     */   {
/* 100 */     if (offset < 0L) {
/* 101 */       throw new IllegalArgumentException("Offset " + offset + " is less than 0");
/*     */     }
/*     */ 
/* 104 */     this.blobKey = blobKey;
/* 105 */     this.blobOffset = offset;
/* 106 */     this.blobstoreService = blobstoreService;
/* 107 */     this.blobInfo = blobInfoFactory.loadBlobInfo(blobKey);
/* 108 */     if (this.blobInfo == null)
/* 109 */       throw new BlobstoreIOException("BlobstoreInputStream received an invalid blob key: " + blobKey.getKeyString());
/*     */   }
/*     */ 
/*     */   private boolean atEndOfBuffer()
/*     */   {
/* 121 */     Preconditions.checkState((this.buffer == null) || (this.bufferOffset <= this.buffer.length), "Buffer offset is past the end of the buffer. This should never happen.");
/*     */ 
/* 123 */     return (this.buffer == null) || (this.bufferOffset == this.buffer.length);
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/* 128 */     if (!ensureDataInBuffer()) {
/* 129 */       return -1;
/*     */     }
/*     */ 
/* 132 */     return this.buffer[(this.bufferOffset++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 138 */     Preconditions.checkNotNull(b);
/* 139 */     Preconditions.checkElementIndex(off, b.length);
/* 140 */     Preconditions.checkPositionIndex(off + len, b.length);
/* 141 */     if (len == 0) {
/* 142 */       return 0;
/*     */     }
/*     */ 
/* 145 */     if (!ensureDataInBuffer()) {
/* 146 */       return -1;
/*     */     }
/*     */ 
/* 150 */     int amountToCopy = Math.min(this.buffer.length - this.bufferOffset, len);
/* 151 */     System.arraycopy(this.buffer, this.bufferOffset, b, off, amountToCopy);
/* 152 */     this.bufferOffset += amountToCopy;
/* 153 */     return amountToCopy;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */   public void mark(int readlimit)
/*     */   {
/* 163 */     this.markSet = true;
/* 164 */     this.markOffset = this.blobOffset;
/*     */ 
/* 166 */     if (this.buffer != null)
/* 167 */       this.markOffset += this.bufferOffset - this.buffer.length;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 173 */     if (!this.markSet) {
/* 174 */       throw new IOException("Attempted to reset on un-mark()ed BlobstoreInputStream");
/*     */     }
/* 176 */     this.blobOffset = this.markOffset;
/* 177 */     this.buffer = null;
/* 178 */     this.bufferOffset = 0;
/* 179 */     this.markSet = false;
/*     */   }
/*     */ 
/*     */   private boolean ensureDataInBuffer()
/*     */     throws IOException
/*     */   {
/* 191 */     if (!atEndOfBuffer()) {
/* 192 */       return true;
/*     */     }
/*     */ 
/* 195 */     long fetchSize = Math.min(this.blobInfo.getSize() - this.blobOffset, 1015808L);
/*     */ 
/* 198 */     if (fetchSize <= 0L) {
/* 199 */       this.buffer = null;
/* 200 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 204 */       this.buffer = this.blobstoreService.fetchData(this.blobKey, this.blobOffset, this.blobOffset + fetchSize - 1L);
/* 205 */       this.blobOffset += this.buffer.length;
/* 206 */       this.bufferOffset = 0;
/* 207 */       return true; } catch (BlobstoreFailureException bfe) {
/*     */     }
/* 209 */     throw new BlobstoreIOException("Error reading data from Blobstore", bfe);
/*     */   }
/*     */ 
/*     */   public static final class BlobstoreIOException extends IOException
/*     */   {
/*     */     public BlobstoreIOException(String message)
/*     */     {
/*  31 */       super();
/*     */     }
/*     */ 
/*     */     public BlobstoreIOException(String message, Throwable cause)
/*     */     {
/*  39 */       super();
/*  40 */       initCause(cause);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobstoreInputStream
 * JD-Core Version:    0.6.0
 */