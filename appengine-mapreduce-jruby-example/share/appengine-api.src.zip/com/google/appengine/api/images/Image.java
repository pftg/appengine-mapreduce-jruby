/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ import com.google.appengine.api.blobstore.BlobKey;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public abstract interface Image extends Serializable
/*    */ {
/*    */   public abstract int getWidth();
/*    */ 
/*    */   public abstract int getHeight();
/*    */ 
/*    */   public abstract Format getFormat();
/*    */ 
/*    */   public abstract byte[] getImageData();
/*    */ 
/*    */   public abstract void setImageData(byte[] paramArrayOfByte);
/*    */ 
/*    */   public abstract BlobKey getBlobKey();
/*    */ 
/*    */   public static enum Format
/*    */   {
/* 20 */     PNG, JPEG, GIF, TIFF, BMP, ICO;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.Image
 * JD-Core Version:    0.6.0
 */