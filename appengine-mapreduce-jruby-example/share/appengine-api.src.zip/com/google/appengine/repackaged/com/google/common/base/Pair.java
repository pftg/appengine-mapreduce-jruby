/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible(serializable=true)
/*     */ public class Pair<A, B>
/*     */   implements Serializable
/*     */ {
/*     */   public final A first;
/*     */   public final B second;
/*     */   private static final long serialVersionUID = 747826592375603043L;
/*     */ 
/*     */   public static <A, B> Pair<A, B> of(@Nullable A first, @Nullable B second)
/*     */   {
/*  59 */     return new Pair(first, second);
/*     */   }
/*     */ 
/*     */   public Pair(@Nullable A first, @Nullable B second)
/*     */   {
/*  76 */     this.first = first;
/*  77 */     this.second = second;
/*     */   }
/*     */ 
/*     */   public A getFirst()
/*     */   {
/*  84 */     return this.first;
/*     */   }
/*     */ 
/*     */   public B getSecond()
/*     */   {
/*  91 */     return this.second;
/*     */   }
/*     */ 
/*     */   public static <A, B> Function<Pair<A, B>, A> firstFunction()
/*     */   {
/* 100 */     return PairFunction.FIRST_FUNCTION;
/*     */   }
/*     */ 
/*     */   public static <A, B> Function<Pair<A, B>, B> secondFunction()
/*     */   {
/* 109 */     return PairFunction.SECOND_FUNCTION;
/*     */   }
/*     */ 
/*     */   public static <A extends Comparable, B> Comparator<Pair<A, B>> compareByFirst()
/*     */   {
/* 132 */     return FirstComparator.FIRST_COMPARATOR;
/*     */   }
/*     */ 
/*     */   public static <A, B extends Comparable> Comparator<Pair<A, B>> compareBySecond()
/*     */   {
/* 142 */     return SecondComparator.SECOND_COMPARATOR;
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object)
/*     */   {
/* 171 */     if ((object instanceof Pair)) {
/* 172 */       Pair that = (Pair)object;
/* 173 */       return (Objects.equal(this.first, that.first)) && (Objects.equal(this.second, that.second));
/*     */     }
/*     */ 
/* 176 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 180 */     return Objects.hashCode(new Object[] { this.first, this.second });
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 194 */     return "(" + this.first + ", " + this.second + ")";
/*     */   }
/*     */ 
/*     */   private static enum SecondComparator
/*     */     implements Comparator<Pair<Object, Comparable>>
/*     */   {
/* 159 */     SECOND_COMPARATOR;
/*     */ 
/*     */     public int compare(Pair<Object, Comparable> pair1, Pair<Object, Comparable> pair2)
/*     */     {
/* 163 */       return ((Comparable)pair1.getSecond()).compareTo(pair2.getSecond());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum FirstComparator
/*     */     implements Comparator<Pair<Comparable, Object>>
/*     */   {
/* 148 */     FIRST_COMPARATOR;
/*     */ 
/*     */     public int compare(Pair<Comparable, Object> pair1, Pair<Comparable, Object> pair2)
/*     */     {
/* 152 */       return ((Comparable)pair1.getFirst()).compareTo(pair2.getFirst());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract enum PairFunction
/*     */     implements Function<Pair<Object, Object>, Object>
/*     */   {
/* 113 */     FIRST_FUNCTION, 
/*     */ 
/* 118 */     SECOND_FUNCTION;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Pair
 * JD-Core Version:    0.6.0
 */