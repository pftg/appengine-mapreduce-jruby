/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public class StandardRowSortedTable<R, C, V> extends StandardTable<R, C, V>
/*     */ {
/*     */   private transient SortedSet<R> rowKeySet;
/*     */   private transient StandardRowSortedTable<R, C, V>.RowSortedMap rowMap;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <R, C, V> StandardTable<R, C, V> create(Comparator<? super R> comparator, Supplier<? extends Map<C, V>> factory)
/*     */   {
/*  74 */     Preconditions.checkNotNull(comparator);
/*  75 */     Preconditions.checkNotNull(factory);
/*  76 */     return new StandardRowSortedTable(new TreeMap(comparator), factory);
/*     */   }
/*     */ 
/*     */   StandardRowSortedTable(SortedMap<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/*     */   {
/*  82 */     super(backingMap, factory);
/*     */   }
/*     */ 
/*     */   private SortedMap<R, Map<C, V>> sortedBackingMap() {
/*  86 */     return (SortedMap)this.backingMap;
/*     */   }
/*     */ 
/*     */   public SortedSet<R> rowKeySet()
/*     */   {
/*  98 */     SortedSet result = this.rowKeySet;
/*  99 */     return result == null ? (this.rowKeySet = new RowKeySortedSet(null)) : result;
/*     */   }
/*     */ 
/*     */   public SortedMap<R, Map<C, V>> rowMap()
/*     */   {
/* 145 */     RowSortedMap result = this.rowMap;
/* 146 */     return result == null ? (this.rowMap = new RowSortedMap(null)) : result;
/*     */   }
/*     */   private class RowSortedMap extends StandardTable<R, C, V>.RowMap implements SortedMap<R, Map<C, V>> {
/* 149 */     private RowSortedMap() { super(); }
/*     */ 
/*     */     public Comparator<? super R> comparator() {
/* 152 */       return StandardRowSortedTable.this.sortedBackingMap().comparator();
/*     */     }
/*     */ 
/*     */     public R firstKey() {
/* 156 */       return StandardRowSortedTable.this.sortedBackingMap().firstKey();
/*     */     }
/*     */ 
/*     */     public R lastKey() {
/* 160 */       return StandardRowSortedTable.this.sortedBackingMap().lastKey();
/*     */     }
/*     */ 
/*     */     public SortedMap<R, Map<C, V>> headMap(R toKey) {
/* 164 */       Preconditions.checkNotNull(toKey);
/* 165 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().headMap(toKey), StandardRowSortedTable.this.factory).rowMap();
/*     */     }
/*     */ 
/*     */     public SortedMap<R, Map<C, V>> subMap(R fromKey, R toKey)
/*     */     {
/* 170 */       Preconditions.checkNotNull(fromKey);
/* 171 */       Preconditions.checkNotNull(toKey);
/* 172 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().subMap(fromKey, toKey), StandardRowSortedTable.this.factory).rowMap();
/*     */     }
/*     */ 
/*     */     public SortedMap<R, Map<C, V>> tailMap(R fromKey)
/*     */     {
/* 177 */       Preconditions.checkNotNull(fromKey);
/* 178 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().tailMap(fromKey), StandardRowSortedTable.this.factory).rowMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class RowKeySortedSet extends StandardTable<R, C, V>.RowKeySet
/*     */     implements SortedSet<R>
/*     */   {
/*     */     private RowKeySortedSet()
/*     */     {
/* 102 */       super();
/*     */     }
/* 104 */     public Comparator<? super R> comparator() { return StandardRowSortedTable.this.sortedBackingMap().comparator(); }
/*     */ 
/*     */     public R first()
/*     */     {
/* 108 */       return StandardRowSortedTable.this.sortedBackingMap().firstKey();
/*     */     }
/*     */ 
/*     */     public R last() {
/* 112 */       return StandardRowSortedTable.this.sortedBackingMap().lastKey();
/*     */     }
/*     */ 
/*     */     public SortedSet<R> headSet(R toElement) {
/* 116 */       Preconditions.checkNotNull(toElement);
/* 117 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().headMap(toElement), StandardRowSortedTable.this.factory).rowKeySet();
/*     */     }
/*     */ 
/*     */     public SortedSet<R> subSet(R fromElement, R toElement)
/*     */     {
/* 122 */       Preconditions.checkNotNull(fromElement);
/* 123 */       Preconditions.checkNotNull(toElement);
/* 124 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().subMap(fromElement, toElement), StandardRowSortedTable.this.factory).rowKeySet();
/*     */     }
/*     */ 
/*     */     public SortedSet<R> tailSet(R fromElement)
/*     */     {
/* 130 */       Preconditions.checkNotNull(fromElement);
/* 131 */       return new StandardRowSortedTable(StandardRowSortedTable.this.sortedBackingMap().tailMap(fromElement), StandardRowSortedTable.this.factory).rowKeySet();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.StandardRowSortedTable
 * JD-Core Version:    0.6.0
 */