package javax.mail;

class Version
{
  public static final String version = "1.4.2";
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Version
 * JD-Core Version:    0.6.0
 */