/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class ByteString
/*     */ {
/*     */   private final byte[] bytes;
/*  55 */   public static final ByteString EMPTY = new ByteString(new byte[0]);
/*     */ 
/* 237 */   private volatile int hash = 0;
/*     */ 
/*     */   private ByteString(byte[] bytes)
/*     */   {
/*  23 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */   public byte byteAt(int index)
/*     */   {
/*  32 */     return this.bytes[index];
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  39 */     return this.bytes.length;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  46 */     return this.bytes.length == 0;
/*     */   }
/*     */ 
/*     */   public static ByteString copyFrom(byte[] bytes, int offset, int size)
/*     */   {
/*  62 */     byte[] copy = new byte[size];
/*  63 */     System.arraycopy(bytes, offset, copy, 0, size);
/*  64 */     return new ByteString(copy);
/*     */   }
/*     */ 
/*     */   public static ByteString copyFrom(byte[] bytes)
/*     */   {
/*  71 */     return copyFrom(bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   public static ByteString copyFrom(ByteBuffer bytes, int size)
/*     */   {
/*  79 */     byte[] copy = new byte[size];
/*  80 */     bytes.get(copy);
/*  81 */     return new ByteString(copy);
/*     */   }
/*     */ 
/*     */   public static ByteString copyFrom(ByteBuffer bytes)
/*     */   {
/*  89 */     return copyFrom(bytes, bytes.remaining());
/*     */   }
/*     */ 
/*     */   public static ByteString copyFrom(String text, String charsetName)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  98 */     return new ByteString(text.getBytes(charsetName));
/*     */   }
/*     */ 
/*     */   public static ByteString copyFromUtf8(String text)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       return new ByteString(text.getBytes("UTF-8")); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 109 */     throw new RuntimeException("UTF-8 not supported?", e);
/*     */   }
/*     */ 
/*     */   public static ByteString copyFrom(List<ByteString> list)
/*     */   {
/* 122 */     if (list.size() == 0)
/* 123 */       return EMPTY;
/* 124 */     if (list.size() == 1) {
/* 125 */       return (ByteString)list.get(0);
/*     */     }
/*     */ 
/* 128 */     int size = 0;
/* 129 */     for (ByteString str : list) {
/* 130 */       size += str.size();
/*     */     }
/* 132 */     byte[] bytes = new byte[size];
/* 133 */     int pos = 0;
/* 134 */     for (ByteString str : list) {
/* 135 */       System.arraycopy(str.bytes, 0, bytes, pos, str.size());
/* 136 */       pos += str.size();
/*     */     }
/* 138 */     return new ByteString(bytes);
/*     */   }
/*     */ 
/*     */   public void copyTo(byte[] target, int offset)
/*     */   {
/* 151 */     System.arraycopy(this.bytes, 0, target, offset, this.bytes.length);
/*     */   }
/*     */ 
/*     */   public void copyTo(byte[] target, int sourceOffset, int targetOffset, int size)
/*     */   {
/* 165 */     System.arraycopy(this.bytes, sourceOffset, target, targetOffset, size);
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray()
/*     */   {
/* 172 */     int size = this.bytes.length;
/* 173 */     byte[] copy = new byte[size];
/* 174 */     System.arraycopy(this.bytes, 0, copy, 0, size);
/* 175 */     return copy;
/*     */   }
/*     */ 
/*     */   public ByteBuffer asReadOnlyByteBuffer()
/*     */   {
/* 183 */     ByteBuffer byteBuffer = ByteBuffer.wrap(this.bytes);
/* 184 */     return byteBuffer.asReadOnlyBuffer();
/*     */   }
/*     */ 
/*     */   public String toString(String charsetName)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 193 */     return new String(this.bytes, charsetName);
/*     */   }
/*     */ 
/*     */   public String toStringUtf8()
/*     */   {
/*     */     try
/*     */     {
/* 201 */       return new String(this.bytes, "UTF-8"); } catch (UnsupportedEncodingException e) {
/*     */     }
/* 203 */     throw new RuntimeException("UTF-8 not supported?", e);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 212 */     if (o == this) {
/* 213 */       return true;
/*     */     }
/*     */ 
/* 216 */     if (!(o instanceof ByteString)) {
/* 217 */       return false;
/*     */     }
/*     */ 
/* 220 */     ByteString other = (ByteString)o;
/* 221 */     int size = this.bytes.length;
/* 222 */     if (size != other.bytes.length) {
/* 223 */       return false;
/*     */     }
/*     */ 
/* 226 */     byte[] thisBytes = this.bytes;
/* 227 */     byte[] otherBytes = other.bytes;
/* 228 */     for (int i = 0; i < size; i++) {
/* 229 */       if (thisBytes[i] != otherBytes[i]) {
/* 230 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 234 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 241 */     int h = this.hash;
/*     */ 
/* 243 */     if (h == 0) {
/* 244 */       byte[] thisBytes = this.bytes;
/* 245 */       int size = this.bytes.length;
/*     */ 
/* 247 */       h = size;
/* 248 */       for (int i = 0; i < size; i++) {
/* 249 */         h = h * 31 + thisBytes[i];
/*     */       }
/* 251 */       if (h == 0) {
/* 252 */         h = 1;
/*     */       }
/*     */ 
/* 255 */       this.hash = h;
/*     */     }
/*     */ 
/* 258 */     return h;
/*     */   }
/*     */ 
/*     */   public InputStream newInput()
/*     */   {
/* 268 */     return new ByteArrayInputStream(this.bytes);
/*     */   }
/*     */ 
/*     */   public CodedInputStream newCodedInput()
/*     */   {
/* 279 */     return CodedInputStream.newInstance(this.bytes);
/*     */   }
/*     */ 
/*     */   public static Output newOutput(int initialCapacity)
/*     */   {
/* 289 */     return new Output(new ByteArrayOutputStream(initialCapacity), null);
/*     */   }
/*     */ 
/*     */   public static Output newOutput()
/*     */   {
/* 296 */     return newOutput(32);
/*     */   }
/*     */ 
/*     */   static CodedBuilder newCodedBuilder(int size)
/*     */   {
/* 337 */     return new CodedBuilder(size, null);
/*     */   }
/*     */   static final class CodedBuilder {
/*     */     private final CodedOutputStream output;
/*     */     private final byte[] buffer;
/*     */ 
/*     */     private CodedBuilder(int size) {
/* 346 */       this.buffer = new byte[size];
/* 347 */       this.output = CodedOutputStream.newInstance(this.buffer);
/*     */     }
/*     */ 
/*     */     public ByteString build() {
/* 351 */       this.output.checkNoSpaceLeft();
/*     */ 
/* 356 */       return new ByteString(this.buffer, null);
/*     */     }
/*     */ 
/*     */     public CodedOutputStream getCodedOutput() {
/* 360 */       return this.output;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Output extends FilterOutputStream
/*     */   {
/*     */     private final ByteArrayOutputStream bout;
/*     */ 
/*     */     private Output(ByteArrayOutputStream bout)
/*     */     {
/* 310 */       super();
/* 311 */       this.bout = bout;
/*     */     }
/*     */ 
/*     */     public ByteString toByteString()
/*     */     {
/* 318 */       byte[] byteArray = this.bout.toByteArray();
/* 319 */       return new ByteString(byteArray, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.ByteString
 * JD-Core Version:    0.6.0
 */