/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicate;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicates;
/*      */ import com.google.appengine.repackaged.com.google.common.base.ReferenceType;
/*      */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*      */ import com.google.common.annotations.Beta;
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import com.google.common.annotations.GwtIncompatible;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashSet;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GwtCompatible(emulated=true)
/*      */ public final class Sets
/*      */ {
/*      */   @GwtCompatible(serializable=true)
/*      */   public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(E anElement, E[] otherElements)
/*      */   {
/*   86 */     return new ImmutableEnumSet(EnumSet.of(anElement, otherElements));
/*      */   }
/*      */ 
/*      */   @GwtCompatible(serializable=true)
/*      */   public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(Iterable<E> elements)
/*      */   {
/*  104 */     Iterator iterator = elements.iterator();
/*  105 */     if (!iterator.hasNext()) {
/*  106 */       return ImmutableSet.of();
/*      */     }
/*  108 */     if ((elements instanceof EnumSet)) {
/*  109 */       EnumSet enumSetClone = EnumSet.copyOf((EnumSet)elements);
/*  110 */       return new ImmutableEnumSet(enumSetClone);
/*      */     }
/*  112 */     Enum first = (Enum)iterator.next();
/*  113 */     EnumSet set = EnumSet.of(first);
/*  114 */     while (iterator.hasNext()) {
/*  115 */       set.add(iterator.next());
/*      */     }
/*  117 */     return new ImmutableEnumSet(set);
/*      */   }
/*      */ 
/*      */   public static <E extends Enum<E>> EnumSet<E> newEnumSet(Iterable<E> iterable, Class<E> elementType)
/*      */   {
/*  141 */     Preconditions.checkNotNull(iterable);
/*  142 */     EnumSet set = EnumSet.noneOf(elementType);
/*  143 */     Iterables.addAll(set, iterable);
/*  144 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E> HashSet<E> newHashSet()
/*      */   {
/*  161 */     return new HashSet();
/*      */   }
/*      */ 
/*      */   public static <E> HashSet<E> newHashSet(E[] elements)
/*      */   {
/*  179 */     int capacity = Maps.capacity(elements.length);
/*  180 */     HashSet set = new HashSet(capacity);
/*  181 */     Collections.addAll(set, elements);
/*  182 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E> HashSet<E> newHashSetWithExpectedSize(int expectedSize)
/*      */   {
/*  195 */     return new HashSet(Maps.capacity(expectedSize));
/*      */   }
/*      */ 
/*      */   public static <E> HashSet<E> newHashSet(Iterable<? extends E> elements)
/*      */   {
/*  212 */     if ((elements instanceof Collection))
/*      */     {
/*  214 */       Collection collection = (Collection)elements;
/*  215 */       return new HashSet(collection);
/*      */     }
/*  217 */     return newHashSet(elements.iterator());
/*      */   }
/*      */ 
/*      */   public static <E> HashSet<E> newHashSet(Iterator<? extends E> elements)
/*      */   {
/*  235 */     HashSet set = newHashSet();
/*  236 */     while (elements.hasNext()) {
/*  237 */       set.add(elements.next());
/*      */     }
/*  239 */     return set;
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> Set<E> newConcurrentHashSet()
/*      */   {
/*  254 */     return newSetFromMap(new ConcurrentHashMap());
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> Set<E> newConcurrentHashSet(E[] elements)
/*      */   {
/*  271 */     int capacity = Maps.capacity(elements.length);
/*  272 */     Set set = newSetFromMap(new ConcurrentHashMap(capacity));
/*  273 */     Collections.addAll(set, elements);
/*  274 */     return set;
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> Set<E> newConcurrentHashSet(Iterable<? extends E> elements)
/*      */   {
/*  293 */     Iterator iterator = elements.iterator();
/*  294 */     Set set = newConcurrentHashSet();
/*  295 */     while (iterator.hasNext()) {
/*  296 */       set.add(iterator.next());
/*      */     }
/*  298 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E> LinkedHashSet<E> newLinkedHashSet()
/*      */   {
/*  312 */     return new LinkedHashSet();
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> LinkedHashSet<E> newLinkedHashSet(E[] elements)
/*      */   {
/*  328 */     LinkedHashSet set = new LinkedHashSet(Maps.capacity(elements.length));
/*  329 */     Collections.addAll(set, elements);
/*  330 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E> LinkedHashSet<E> newLinkedHashSet(Iterable<? extends E> elements)
/*      */   {
/*  346 */     if ((elements instanceof Collection))
/*      */     {
/*  348 */       Collection collection = (Collection)elements;
/*  349 */       return new LinkedHashSet(collection);
/*      */     }
/*  351 */     LinkedHashSet set = newLinkedHashSet();
/*  352 */     for (Iterator i$ = elements.iterator(); i$.hasNext(); ) { Object element = i$.next();
/*  353 */       set.add(element);
/*      */     }
/*  355 */     return set;
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> LinkedHashSet<E> newLinkedHashSet(Iterator<? extends E> elements)
/*      */   {
/*  368 */     LinkedHashSet set = newLinkedHashSet();
/*  369 */     while (elements.hasNext()) {
/*  370 */       set.add(elements.next());
/*      */     }
/*  372 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E extends Comparable> TreeSet<E> newTreeSet()
/*      */   {
/*  388 */     return new TreeSet();
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E extends Comparable> TreeSet<E> newTreeSet(E[] elements)
/*      */   {
/*  405 */     TreeSet set = newTreeSet();
/*  406 */     Collections.addAll(set, elements);
/*  407 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E extends Comparable> TreeSet<E> newTreeSet(Iterable<? extends E> elements)
/*      */   {
/*  428 */     TreeSet set = newTreeSet();
/*  429 */     for (Comparable element : elements) {
/*  430 */       set.add(element);
/*      */     }
/*  432 */     return set;
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E extends Comparable> TreeSet<E> newTreeSet(Iterator<? extends E> elements)
/*      */   {
/*  449 */     TreeSet set = newTreeSet();
/*  450 */     while (elements.hasNext()) {
/*  451 */       set.add(elements.next());
/*      */     }
/*  453 */     return set;
/*      */   }
/*      */ 
/*      */   public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator)
/*      */   {
/*  468 */     return new TreeSet((Comparator)Preconditions.checkNotNull(comparator));
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator, E[] elements)
/*      */   {
/*  487 */     TreeSet set = newTreeSet(comparator);
/*  488 */     Collections.addAll(set, elements);
/*  489 */     return set;
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator, Iterable<? extends E> elements)
/*      */   {
/*  508 */     return newTreeSet(comparator, elements.iterator());
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator, Iterator<? extends E> elements)
/*      */   {
/*  527 */     TreeSet set = newTreeSet(comparator);
/*  528 */     while (elements.hasNext()) {
/*  529 */       set.add(elements.next());
/*      */     }
/*  531 */     return set;
/*      */   }
/*      */ 
/*      */   @GwtIncompatible("java.lang.ref.SoftReference, java.lang.ref.WeakReference")
/*      */   @GoogleInternal
/*      */   public static <E> Set<E> newIdentityHashSet(ReferenceType referenceType)
/*      */   {
/*      */     Map map;
/*  556 */     switch (4.$SwitchMap$com$google$common$base$ReferenceType[referenceType.ordinal()]) {
/*      */     case 1:
/*  558 */       map = new IdentityHashMap();
/*  559 */       break;
/*      */     case 2:
/*  561 */       map = new MapMaker().softKeys().makeMap();
/*  562 */       break;
/*      */     case 3:
/*  564 */       map = new MapMaker().weakKeys().makeMap();
/*  565 */       break;
/*      */     case 4:
/*  567 */       throw new IllegalArgumentException("Phantom references are not supported.");
/*      */     default:
/*  570 */       throw new AssertionError();
/*      */     }
/*  572 */     return newSetFromMap(map);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <E extends Comparable> SortedArraySet<E> newSortedArraySet()
/*      */   {
/*  587 */     return new SortedArraySet();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <E> SortedArraySet<E> newSortedArraySet(Comparator<? super E> comparator)
/*      */   {
/*  600 */     return new SortedArraySet(comparator);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <E extends Comparable> SortedArraySet<E> newSortedArraySet(Iterable<? extends E> elements)
/*      */   {
/*  621 */     Preconditions.checkContentsNotNull(elements);
/*  622 */     return newSortedArraySet(elements, Ordering.natural());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <E> SortedArraySet<E> newSortedArraySet(Iterable<? extends E> elements, Comparator<? super E> comparator)
/*      */   {
/*  643 */     SortedArraySet set = new SortedArraySet(comparator, (elements instanceof Collection) ? ((Collection)elements).size() : 10);
/*      */ 
/*  646 */     for (Iterator i$ = elements.iterator(); i$.hasNext(); ) { Object element = i$.next();
/*  647 */       set.add(element);
/*      */     }
/*  649 */     return set;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <E> SortedArraySet<E> newSortedArraySet(Comparator<? super E> comparator, E[] elements)
/*      */   {
/*  672 */     SortedArraySet set = new SortedArraySet(comparator, elements.length);
/*  673 */     Collections.addAll(set, elements);
/*  674 */     return set;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <E extends Comparable> SortedArraySet<E> newSortedArraySet(E[] elements)
/*      */   {
/*  694 */     for (Comparable element : elements) {
/*  695 */       Preconditions.checkNotNull(element);
/*      */     }
/*  697 */     return newSortedArraySet(Ordering.natural(), elements);
/*      */   }
/*      */ 
/*      */   public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection)
/*      */   {
/*  717 */     if ((collection instanceof EnumSet)) {
/*  718 */       return EnumSet.complementOf((EnumSet)collection);
/*      */     }
/*  720 */     Preconditions.checkArgument(!collection.isEmpty(), "collection is empty; use the other version of this method");
/*      */ 
/*  722 */     Class type = ((Enum)collection.iterator().next()).getDeclaringClass();
/*  723 */     return makeComplementByHand(collection, type);
/*      */   }
/*      */ 
/*      */   public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection, Class<E> type)
/*      */   {
/*  740 */     Preconditions.checkNotNull(collection);
/*  741 */     return (collection instanceof EnumSet) ? EnumSet.complementOf((EnumSet)collection) : makeComplementByHand(collection, type);
/*      */   }
/*      */ 
/*      */   private static <E extends Enum<E>> EnumSet<E> makeComplementByHand(Collection<E> collection, Class<E> type)
/*      */   {
/*  748 */     EnumSet result = EnumSet.allOf(type);
/*  749 */     result.removeAll(collection);
/*  750 */     return result;
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static SortedSet<Integer> asIntegerSet(int min, int max)
/*      */   {
/*  760 */     return max < min ? ImmutableSortedSet.of() : ((DiscreteRange)Ranges.integers().closed(Integer.valueOf(min), Integer.valueOf(max))).asSet();
/*      */   }
/*      */ 
/*      */   public static <E> Set<E> newSetFromMap(Map<E, Boolean> map)
/*      */   {
/*  805 */     return new SetFromMap(map);
/*      */   }
/*      */ 
/*      */   public static <E> SetView<E> union(Set<? extends E> set1, Set<? extends E> set2)
/*      */   {
/*  933 */     Preconditions.checkNotNull(set1, "set1");
/*  934 */     Preconditions.checkNotNull(set2, "set2");
/*      */ 
/*  939 */     Set set2minus1 = difference(set2, set1);
/*      */ 
/*  941 */     return new SetView(set1, set2minus1, set2) {
/*      */       public int size() {
/*  943 */         return this.val$set1.size() + this.val$set2minus1.size();
/*      */       }
/*      */       public boolean isEmpty() {
/*  946 */         return (this.val$set1.isEmpty()) && (this.val$set2.isEmpty());
/*      */       }
/*      */       public Iterator<E> iterator() {
/*  949 */         return Iterators.unmodifiableIterator(Iterators.concat(this.val$set1.iterator(), this.val$set2minus1.iterator()));
/*      */       }
/*      */ 
/*      */       public boolean contains(Object object) {
/*  953 */         return (this.val$set1.contains(object)) || (this.val$set2.contains(object));
/*      */       }
/*      */       public <S extends Set<E>> S copyInto(S set) {
/*  956 */         set.addAll(this.val$set1);
/*  957 */         set.addAll(this.val$set2);
/*  958 */         return set;
/*      */       }
/*      */       public ImmutableSet<E> immutableCopy() {
/*  961 */         return new ImmutableSet.Builder().addAll(this.val$set1).addAll(this.val$set2).build();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <E> SetView<E> intersection(Set<E> set1, Set<?> set2)
/*      */   {
/*  995 */     Preconditions.checkNotNull(set1, "set1");
/*  996 */     Preconditions.checkNotNull(set2, "set2");
/*      */ 
/* 1001 */     Predicate inSet2 = Predicates.in(set2);
/* 1002 */     return new SetView(set1, inSet2, set2) {
/*      */       public Iterator<E> iterator() {
/* 1004 */         return Iterators.filter(this.val$set1.iterator(), this.val$inSet2);
/*      */       }
/*      */       public int size() {
/* 1007 */         return Iterators.size(iterator());
/*      */       }
/*      */       public boolean isEmpty() {
/* 1010 */         return !iterator().hasNext();
/*      */       }
/*      */       public boolean contains(Object object) {
/* 1013 */         return (this.val$set1.contains(object)) && (this.val$set2.contains(object));
/*      */       }
/*      */       public boolean containsAll(Collection<?> collection) {
/* 1016 */         return (this.val$set1.containsAll(collection)) && (this.val$set2.containsAll(collection));
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <E> SetView<E> difference(Set<E> set1, Set<?> set2)
/*      */   {
/* 1035 */     Preconditions.checkNotNull(set1, "set1");
/* 1036 */     Preconditions.checkNotNull(set2, "set2");
/*      */ 
/* 1041 */     Predicate notInSet2 = Predicates.not(Predicates.in(set2));
/* 1042 */     return new SetView(set1, notInSet2, set2) {
/*      */       public Iterator<E> iterator() {
/* 1044 */         return Iterators.filter(this.val$set1.iterator(), this.val$notInSet2);
/*      */       }
/*      */       public int size() {
/* 1047 */         return Iterators.size(iterator());
/*      */       }
/*      */       public boolean isEmpty() {
/* 1050 */         return this.val$set2.containsAll(this.val$set1);
/*      */       }
/*      */       public boolean contains(Object element) {
/* 1053 */         return (this.val$set1.contains(element)) && (!this.val$set2.contains(element));
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   @Beta
/*      */   public static <E> SetView<E> symmetricDifference(Set<? extends E> set1, Set<? extends E> set2)
/*      */   {
/* 1073 */     Preconditions.checkNotNull(set1, "set1");
/* 1074 */     Preconditions.checkNotNull(set2, "set2");
/*      */ 
/* 1077 */     return difference(union(set1, set2), intersection(set1, set2));
/*      */   }
/*      */ 
/*      */   public static <E> Set<E> filter(Set<E> unfiltered, Predicate<? super E> predicate)
/*      */   {
/* 1103 */     if ((unfiltered instanceof FilteredSet))
/*      */     {
/* 1106 */       FilteredSet filtered = (FilteredSet)unfiltered;
/* 1107 */       Predicate combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*      */ 
/* 1109 */       return new FilteredSet((Set)filtered.unfiltered, combinedPredicate);
/*      */     }
/*      */ 
/* 1113 */     return new FilteredSet((Set)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*      */   }
/*      */ 
/*      */   public static <B> Set<List<B>> cartesianProduct(List<? extends Set<? extends B>> sets)
/*      */   {
/* 1179 */     CartesianSet cartesianSet = new CartesianSet(sets);
/* 1180 */     return cartesianSet.isEmpty() ? ImmutableSet.of() : cartesianSet;
/*      */   }
/*      */ 
/*      */   public static <B> Set<List<B>> cartesianProduct(Set<? extends B>[] sets)
/*      */   {
/* 1230 */     return cartesianProduct(Arrays.asList(sets));
/*      */   }
/*      */ 
/*      */   @GwtCompatible(serializable=false)
/*      */   public static <E> Set<Set<E>> powerSet(Set<E> set)
/*      */   {
/* 1392 */     ImmutableSet input = ImmutableSet.copyOf(set);
/* 1393 */     Preconditions.checkArgument(input.size() <= 30, "Too many elements to create power set: %s > 30", new Object[] { Integer.valueOf(input.size()) });
/*      */ 
/* 1395 */     return new PowerSet(input);
/*      */   }
/*      */ 
/*      */   static int hashCodeImpl(Set<?> s)
/*      */   {
/* 1492 */     int hashCode = 0;
/* 1493 */     for (Iterator i$ = s.iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 1494 */       hashCode += (o != null ? o.hashCode() : 0);
/*      */     }
/* 1496 */     return hashCode;
/*      */   }
/*      */ 
/*      */   private static final class PowerSet<E> extends AbstractSet<Set<E>>
/*      */   {
/*      */     final ImmutableSet<E> inputSet;
/*      */     final ImmutableList<E> inputList;
/*      */     final int powerSetSize;
/*      */ 
/*      */     PowerSet(ImmutableSet<E> input)
/*      */     {
/* 1404 */       this.inputSet = input;
/* 1405 */       this.inputList = input.asList();
/* 1406 */       this.powerSetSize = (1 << input.size());
/*      */     }
/*      */ 
/*      */     public int size() {
/* 1410 */       return this.powerSetSize;
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/* 1414 */       return false;
/*      */     }
/*      */ 
/*      */     public Iterator<Set<E>> iterator() {
/* 1418 */       return new AbstractIndexedIterator(this.powerSetSize) {
/*      */         protected Set<E> get(int setBits) {
/* 1420 */           return new AbstractSet(setBits) {
/*      */             public int size() {
/* 1422 */               return Integer.bitCount(this.val$setBits);
/*      */             }
/*      */             public Iterator<E> iterator() {
/* 1425 */               return new Sets.PowerSet.BitFilteredSetIterator(Sets.PowerSet.this.inputList, this.val$setBits);
/*      */             }
/*      */           };
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public boolean contains(@Nullable Object obj)
/*      */     {
/* 1459 */       if ((obj instanceof Set)) {
/* 1460 */         Set set = (Set)obj;
/* 1461 */         return this.inputSet.containsAll(set);
/*      */       }
/* 1463 */       return false;
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object obj) {
/* 1467 */       if ((obj instanceof PowerSet)) {
/* 1468 */         PowerSet that = (PowerSet)obj;
/* 1469 */         return this.inputSet.equals(that.inputSet);
/*      */       }
/* 1471 */       return super.equals(obj);
/*      */     }
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1480 */       return this.inputSet.hashCode() << this.inputSet.size() - 1;
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1484 */       return "powerSet(" + this.inputSet + ")";
/*      */     }
/*      */ 
/*      */     private static final class BitFilteredSetIterator<E> extends UnmodifiableIterator<E>
/*      */     {
/*      */       final ImmutableList<E> input;
/*      */       int remainingSetBits;
/*      */ 
/*      */       BitFilteredSetIterator(ImmutableList<E> input, int allSetBits)
/*      */       {
/* 1438 */         this.input = input;
/* 1439 */         this.remainingSetBits = allSetBits;
/*      */       }
/*      */ 
/*      */       public boolean hasNext() {
/* 1443 */         return this.remainingSetBits != 0;
/*      */       }
/*      */ 
/*      */       public E next() {
/* 1447 */         int index = Integer.numberOfTrailingZeros(this.remainingSetBits);
/* 1448 */         if (index == 32) {
/* 1449 */           throw new NoSuchElementException();
/*      */         }
/*      */ 
/* 1452 */         int currentElementMask = 1 << index;
/* 1453 */         this.remainingSetBits &= (currentElementMask ^ 0xFFFFFFFF);
/* 1454 */         return this.input.get(index);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CartesianSet<B> extends AbstractSet<List<B>>
/*      */   {
/*      */     final ImmutableList<CartesianSet<B>.Axis> axes;
/*      */     final int size;
/*      */ 
/*      */     CartesianSet(List<? extends Set<? extends B>> sets)
/*      */     {
/* 1238 */       long dividend = 1L;
/* 1239 */       ImmutableList.Builder builder = ImmutableList.builder();
/* 1240 */       for (Set set : sets) {
/* 1241 */         Axis axis = new Axis(set, (int)dividend);
/* 1242 */         builder.add(axis);
/* 1243 */         dividend *= axis.size();
/*      */       }
/* 1245 */       this.axes = builder.build();
/* 1246 */       this.size = Ints.checkedCast(dividend);
/*      */     }
/*      */ 
/*      */     public int size() {
/* 1250 */       return this.size;
/*      */     }
/*      */ 
/*      */     public UnmodifiableIterator<List<B>> iterator() {
/* 1254 */       return new UnmodifiableIterator() {
/*      */         int index;
/*      */ 
/* 1258 */         public boolean hasNext() { return this.index < Sets.CartesianSet.this.size; }
/*      */ 
/*      */         public List<B> next()
/*      */         {
/* 1262 */           if (!hasNext()) {
/* 1263 */             throw new NoSuchElementException();
/*      */           }
/*      */ 
/* 1266 */           Object[] tuple = new Object[Sets.CartesianSet.this.axes.size()];
/* 1267 */           for (int i = 0; i < tuple.length; i++) {
/* 1268 */             tuple[i] = ((Sets.CartesianSet.Axis)Sets.CartesianSet.this.axes.get(i)).getForIndex(this.index);
/*      */           }
/* 1270 */           this.index += 1;
/*      */ 
/* 1273 */           List result = ImmutableList.copyOf(tuple);
/* 1274 */           return result;
/*      */         } } ;
/*      */     }
/*      */ 
/*      */     public boolean contains(Object element) {
/* 1280 */       if (!(element instanceof List)) {
/* 1281 */         return false;
/*      */       }
/* 1283 */       List tuple = (List)element;
/* 1284 */       int dimensions = this.axes.size();
/* 1285 */       if (tuple.size() != dimensions) {
/* 1286 */         return false;
/*      */       }
/* 1288 */       for (int i = 0; i < dimensions; i++) {
/* 1289 */         if (!((Axis)this.axes.get(i)).contains(tuple.get(i))) {
/* 1290 */           return false;
/*      */         }
/*      */       }
/* 1293 */       return true;
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object)
/*      */     {
/* 1299 */       if ((object instanceof CartesianSet)) {
/* 1300 */         CartesianSet that = (CartesianSet)object;
/* 1301 */         return this.axes.equals(that.axes);
/*      */       }
/* 1303 */       return super.equals(object);
/*      */     }
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1311 */       int adjust = this.size - 1;
/* 1312 */       for (int i = 0; i < this.axes.size(); i++) {
/* 1313 */         adjust *= 31;
/*      */       }
/* 1315 */       return this.axes.hashCode() + adjust;
/*      */     }
/*      */     private class Axis { final ImmutableSet<? extends B> choices;
/*      */       final ImmutableList<? extends B> choicesList;
/*      */       final int dividend;
/*      */ 
/* 1324 */       Axis(int set) { this.choices = ImmutableSet.copyOf(set);
/* 1325 */         this.choicesList = this.choices.asList();
/* 1326 */         this.dividend = dividend; }
/*      */ 
/*      */       int size()
/*      */       {
/* 1330 */         return this.choices.size();
/*      */       }
/*      */ 
/*      */       B getForIndex(int index) {
/* 1334 */         return this.choicesList.get(index / this.dividend % size());
/*      */       }
/*      */ 
/*      */       boolean contains(Object target) {
/* 1338 */         return this.choices.contains(target);
/*      */       }
/*      */ 
/*      */       public boolean equals(Object obj)
/*      */       {
/* 1343 */         if ((obj instanceof Axis)) {
/* 1344 */           Axis that = (Axis)obj;
/* 1345 */           return this.choices.equals(that.choices);
/*      */         }
/*      */ 
/* 1348 */         return false;
/*      */       }
/*      */ 
/*      */       public int hashCode()
/*      */       {
/* 1355 */         return Sets.CartesianSet.this.size / this.choices.size() * this.choices.hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class FilteredSet<E> extends Collections2.FilteredCollection<E>
/*      */     implements Set<E>
/*      */   {
/*      */     FilteredSet(Set<E> unfiltered, Predicate<? super E> predicate)
/*      */     {
/* 1120 */       super(predicate);
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object) {
/* 1124 */       return Collections2.setEquals(this, object);
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1128 */       return Sets.hashCodeImpl(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class SetView<E> extends AbstractSet<E>
/*      */   {
/*      */     public ImmutableSet<E> immutableCopy()
/*      */     {
/*  898 */       return ImmutableSet.copyOf(this);
/*      */     }
/*      */ 
/*      */     public <S extends Set<E>> S copyInto(S set)
/*      */     {
/*  911 */       set.addAll(this);
/*  912 */       return set;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SetFromMap<E> extends AbstractSet<E>
/*      */     implements Set<E>, Serializable
/*      */   {
/*      */     private final Map<E, Boolean> m;
/*      */     private transient Set<E> s;
/*      */ 
/*      */     @GwtIncompatible("not needed in emulated source")
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SetFromMap(Map<E, Boolean> map)
/*      */     {
/*  814 */       Preconditions.checkArgument(map.isEmpty(), "Map is non-empty");
/*  815 */       this.m = map;
/*  816 */       this.s = map.keySet();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  820 */       this.m.clear();
/*      */     }
/*      */     public int size() {
/*  823 */       return this.m.size();
/*      */     }
/*      */     public boolean isEmpty() {
/*  826 */       return this.m.isEmpty();
/*      */     }
/*      */     public boolean contains(Object o) {
/*  829 */       return this.m.containsKey(o);
/*      */     }
/*      */     public boolean remove(Object o) {
/*  832 */       return this.m.remove(o) != null;
/*      */     }
/*      */     public boolean add(E e) {
/*  835 */       return this.m.put(e, Boolean.TRUE) == null;
/*      */     }
/*      */     public Iterator<E> iterator() {
/*  838 */       return this.s.iterator();
/*      */     }
/*      */     public Object[] toArray() {
/*  841 */       return this.s.toArray();
/*      */     }
/*      */     public <T> T[] toArray(T[] a) {
/*  844 */       return this.s.toArray(a);
/*      */     }
/*      */     public String toString() {
/*  847 */       return this.s.toString();
/*      */     }
/*      */     public int hashCode() {
/*  850 */       return this.s.hashCode();
/*      */     }
/*      */     public boolean equals(@Nullable Object object) {
/*  853 */       return (this == object) || (this.s.equals(object));
/*      */     }
/*      */     public boolean containsAll(Collection<?> c) {
/*  856 */       return this.s.containsAll(c);
/*      */     }
/*      */     public boolean removeAll(Collection<?> c) {
/*  859 */       return this.s.removeAll(c);
/*      */     }
/*      */     public boolean retainAll(Collection<?> c) {
/*  862 */       return this.s.retainAll(c);
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectInputStream")
/*      */     private void readObject(ObjectInputStream stream)
/*      */       throws IOException, ClassNotFoundException
/*      */     {
/*  872 */       stream.defaultReadObject();
/*  873 */       this.s = this.m.keySet();
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Sets
 * JD-Core Version:    0.6.0
 */