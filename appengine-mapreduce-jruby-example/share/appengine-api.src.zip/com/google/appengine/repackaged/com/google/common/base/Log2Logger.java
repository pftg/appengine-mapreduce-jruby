/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.text.DateFormat;
/*     */ import java.util.logging.ConsoleHandler;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.LogRecord;
/*     */ 
/*     */ @Deprecated
/*     */ @GoogleInternal
/*     */ public final class Log2Logger
/*     */   implements Logger
/*     */ {
/*     */   private int threshold;
/* 277 */   private static final java.util.logging.Logger LOG = java.util.logging.Logger.getLogger("com.google.appengine.repackaged.com.google.common.base.Log2");
/*     */ 
/* 279 */   private static boolean selfInstalledHandler = false;
/* 280 */   private static boolean useRootHandler = false;
/*     */ 
/*     */   Log2Logger()
/*     */   {
/*  47 */     Handler[] handlers = LOG.getHandlers();
/*  48 */     if ((handlers.length == 0) && (!useRootHandler)) {
/*  49 */       ConsoleHandler ch = new ConsoleHandler();
/*  50 */       ch.setFormatter(new Log2Formatter());
/*  51 */       addHandler(ch);
/*  52 */       setThreshold(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   Log2Logger(String filePath, String linkName, String extension, DateFormat recordTsFormat, DateFormat fileNameTsFormat, long rotateSize)
/*     */   {
/*  67 */     Handler[] handlers = LOG.getHandlers();
/*     */ 
/*  72 */     if (((handlers.length == 0) || (selfInstalledHandler)) && (!useRootHandler)) {
/*  73 */       if (selfInstalledHandler) {
/*  74 */         LOG.removeHandler(handlers[0]);
/*     */       }
/*  76 */       Handler h = new Log2FileHandler(filePath, linkName, extension, recordTsFormat, fileNameTsFormat, rotateSize);
/*     */ 
/*  82 */       addHandler(h);
/*  83 */       setThreshold(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void useRootHandler()
/*     */   {
/*  91 */     if (!useRootHandler) {
/*  92 */       Handler[] handlers = LOG.getHandlers();
/*  93 */       for (int i = 0; i < handlers.length; i++) {
/*  94 */         LOG.removeHandler(handlers[i]);
/*     */       }
/*  96 */       LOG.setUseParentHandlers(true);
/*  97 */       useRootHandler = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setThreshold(int level)
/*     */   {
/*     */     Level javaLevel;
/* 110 */     if (level == 2) {
/* 111 */       javaLevel = Level.WARNING;
/*     */     }
/*     */     else
/*     */     {
/*     */       Level javaLevel;
/* 112 */       if (level == 1) {
/* 113 */         javaLevel = Level.INFO;
/*     */       }
/*     */       else
/*     */       {
/*     */         Level javaLevel;
/* 114 */         if (level == 0)
/* 115 */           javaLevel = Level.FINEST;
/*     */         else
/* 117 */           throw new RuntimeException("Invalid level passed to Log2Logger.setThreshold ");
/*     */       }
/*     */     }
/*     */     Level javaLevel;
/* 125 */     LOG.setLevel(javaLevel);
/* 126 */     if (selfInstalledHandler) {
/* 127 */       Handler[] handlers = LOG.getHandlers();
/* 128 */       handlers[0].setLevel(javaLevel);
/*     */     }
/* 130 */     this.threshold = level;
/*     */   }
/*     */ 
/*     */   public int getThreshold()
/*     */   {
/* 139 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public void logDebug(String msg) {
/* 143 */     if (LOG.isLoggable(Level.FINE))
/* 144 */       logAfterSettingCaller(Level.FINE, msg);
/*     */   }
/*     */ 
/*     */   public void logEvent(String msg)
/*     */   {
/* 149 */     if (LOG.isLoggable(Level.INFO)) {
/* 150 */       LogRecord lr = new LogRecord(Level.INFO, msg);
/* 151 */       doCallerInference(lr);
/* 152 */       LOG.log(lr);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void logTimedEvent(String msg, long start, long end)
/*     */   {
/* 160 */     LOG.info(end - start + " ms.: " + msg);
/*     */   }
/*     */ 
/*     */   public void setErrorEmail(String emailAddr)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void logException(Throwable t)
/*     */   {
/* 171 */     logException(t, "");
/*     */   }
/*     */ 
/*     */   public void logException(Throwable t, String msg) {
/* 175 */     if (LOG.isLoggable(Level.WARNING))
/* 176 */       logAfterSettingCaller(Level.WARNING, msg, t);
/*     */   }
/*     */ 
/*     */   public void logSevereException(Throwable t)
/*     */   {
/* 181 */     logSevereException(t, "");
/*     */   }
/*     */ 
/*     */   public void logSevereException(Throwable t, String msg) {
/* 185 */     if (LOG.isLoggable(Level.SEVERE))
/* 186 */       logAfterSettingCaller(Level.SEVERE, msg, t);
/*     */   }
/*     */ 
/*     */   public void logError(String msg)
/*     */   {
/* 201 */     logAfterSettingCaller(Level.WARNING, msg + "\n" + Log2.getExceptionTrace(new LoggedError(null)));
/*     */   }
/*     */ 
/*     */   public String getThreadTag() {
/* 205 */     return LogContext.getThreadTag();
/*     */   }
/*     */ 
/*     */   public void setThreadTag(String s) {
/* 209 */     LogContext.setThreadTag(s);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 216 */     Handler[] handlers = LOG.getHandlers();
/* 217 */     for (int i = 0; i < handlers.length; i++)
/* 218 */       handlers[i].close();
/*     */   }
/*     */ 
/*     */   private void addHandler(Handler handler)
/*     */   {
/* 223 */     LOG.addHandler(handler);
/*     */ 
/* 225 */     boolean useParentHandlers = false;
/* 226 */     String val = LogManager.getLogManager().getProperty(LOG.getName() + ".useParentHandlers");
/*     */ 
/* 228 */     val = val == null ? "" : val.toLowerCase();
/* 229 */     if ((val.equals("true")) || (val.equals("1"))) {
/* 230 */       useParentHandlers = true;
/*     */     }
/*     */ 
/* 233 */     LOG.setUseParentHandlers(useParentHandlers);
/* 234 */     selfInstalledHandler = true;
/*     */   }
/*     */ 
/*     */   private void doCallerInference(LogRecord record)
/*     */   {
/* 242 */     String loggerClassName = Log2.class.getName();
/* 243 */     StackTraceElement[] callStack = new Throwable().getStackTrace();
/* 244 */     int lastLoggerCallIndex = 2147483647;
/*     */ 
/* 246 */     for (int i = 0; i < callStack.length; i++) {
/* 247 */       String className = callStack[i].getClassName();
/* 248 */       if (className.equals(loggerClassName)) {
/* 249 */         lastLoggerCallIndex = i;
/* 250 */       } else if (lastLoggerCallIndex != 2147483647) {
/* 251 */         record.setSourceClassName(callStack[i].getClassName());
/* 252 */         record.setSourceMethodName(callStack[i].getMethodName());
/* 253 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void logAfterSettingCaller(Level level, String msg, Throwable t)
/*     */   {
/* 263 */     LogRecord lr = new LogRecord(level, msg);
/* 264 */     if (t != null) {
/* 265 */       lr.setThrown(t);
/*     */     }
/*     */ 
/* 268 */     doCallerInference(lr);
/* 269 */     LOG.log(lr);
/*     */   }
/*     */ 
/*     */   private void logAfterSettingCaller(Level level, String msg) {
/* 273 */     logAfterSettingCaller(level, msg, null);
/*     */   }
/*     */ 
/*     */   private static class LoggedError extends Throwable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Log2Logger
 * JD-Core Version:    0.6.0
 */