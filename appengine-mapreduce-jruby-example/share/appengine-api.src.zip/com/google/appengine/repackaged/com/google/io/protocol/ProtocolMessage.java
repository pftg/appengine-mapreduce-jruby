/*      */ package com.google.appengine.repackaged.com.google.io.protocol;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.CharEscaper;
/*      */ import com.google.appengine.repackaged.com.google.common.base.CharEscapers;
/*      */ import com.google.appengine.repackaged.com.google.common.io.ByteStreams;
/*      */ import com.google.appengine.repackaged.com.google.common.io.InputSupplier;
/*      */ import com.google.appengine.repackaged.com.google.io.base.IORuntimeException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.MessageLite;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.MessageLite.Builder;
/*      */ import java.awt.Image;
/*      */ import java.beans.BeanDescriptor;
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.EventSetDescriptor;
/*      */ import java.beans.MethodDescriptor;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.BufferOverflowException;
/*      */ import java.nio.BufferUnderflowException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Set;
/*      */ 
/*      */ public abstract class ProtocolMessage<T extends ProtocolMessage<T>>
/*      */   implements MessageLite, Serializable, BeanInfo
/*      */ {
/*   53 */   private static final String[] formattedHex = new String[256];
/*      */   private static final EnumSet<PrintFlag> FLAGS_DEFAULT;
/*      */   private static final EnumSet<PrintFlag> FLAGS_WITH_INDEX;
/*      */ 
/*      */   public String findInitializationError()
/*      */   {
/*  117 */     if (isInitialized()) {
/*  118 */       return null;
/*      */     }
/*  120 */     MissingFieldVisitor visitor = new MissingFieldVisitor();
/*  121 */     ProtocolType.visit(this, visitor);
/*  122 */     return "missing field: " + visitor.getMissingFieldName();
/*      */   }
/*      */ 
/*      */   public abstract boolean isInitialized();
/*      */ 
/*      */   public abstract int encodingSize();
/*      */ 
/*      */   public abstract int maxEncodingSize();
/*      */ 
/*      */   public abstract void clear();
/*      */ 
/*      */   public abstract T newInstance();
/*      */ 
/*      */   public T freeze()
/*      */   {
/*  161 */     return this;
/*      */   }
/*      */ 
/*      */   public T unfreeze()
/*      */   {
/*  171 */     return this;
/*      */   }
/*      */ 
/*      */   public boolean isFrozen()
/*      */   {
/*  184 */     return false;
/*      */   }
/*      */ 
/*      */   public abstract T mergeFrom(T paramT);
/*      */ 
/*      */   public T copyFrom(T that)
/*      */   {
/*  206 */     if (that == this) return that;
/*  207 */     clear();
/*  208 */     return mergeFrom(that);
/*      */   }
/*      */ 
/*      */   public T clone()
/*      */   {
/*  219 */     ProtocolMessage copy = newInstance();
/*  220 */     copy.mergeFrom(this);
/*  221 */     return copy;
/*      */   }
/*      */ 
/*      */   public abstract boolean equals(Object paramObject);
/*      */ 
/*      */   public abstract int hashCode();
/*      */ 
/*      */   public abstract boolean equals(T paramT);
/*      */ 
/*      */   public abstract boolean equalsIgnoreUninterpreted(T paramT);
/*      */ 
/*      */   public abstract boolean equals(T paramT, boolean paramBoolean);
/*      */ 
/*      */   public abstract void outputTo(ProtocolSink paramProtocolSink);
/*      */ 
/*      */   public final ProtocolSink toProtocolSink()
/*      */   {
/*  279 */     ProtocolSink sink = new ProtocolSink(maxEncodingSize());
/*  280 */     outputTo(sink);
/*  281 */     return sink;
/*      */   }
/*      */ 
/*      */   public final void outputTo(byte[] buf, int offset)
/*      */   {
/*  295 */     outputTo(new ProtocolSink(buf, offset));
/*      */   }
/*      */ 
/*      */   public final byte[] toByteArray()
/*      */   {
/*  306 */     return toProtocolSink().toArray();
/*      */   }
/*      */ 
/*      */   public final void outputTo(ByteBuffer buffer)
/*      */   {
/*  324 */     if (buffer.hasArray()) {
/*  325 */       int offset = buffer.arrayOffset();
/*  326 */       ProtocolSink sink = new ProtocolSink(buffer.array(), offset + buffer.position());
/*      */ 
/*  328 */       outputTo(sink);
/*  329 */       if (sink.position() - offset > buffer.limit()) {
/*  330 */         throw new BufferOverflowException();
/*      */       }
/*  332 */       buffer.position(sink.position() - offset);
/*      */     } else {
/*  334 */       ProtocolSink sink = toProtocolSink();
/*  335 */       buffer.put(sink.array(), 0, sink.position());
/*      */     }
/*      */   }
/*      */ 
/*      */   public final ByteBuffer toByteBuffer()
/*      */   {
/*  344 */     ProtocolSink sink = toProtocolSink();
/*  345 */     return ByteBuffer.wrap(sink.array(), 0, sink.position()).order(ByteOrder.LITTLE_ENDIAN);
/*      */   }
/*      */ 
/*      */   public final void outputTo(OutputStream stream)
/*      */   {
/*      */     try
/*      */     {
/*  362 */       ProtocolSink sink = toProtocolSink();
/*  363 */       stream.write(sink.array(), 0, sink.position());
/*      */     } catch (IOException ioe) {
/*  365 */       throw new IORuntimeException(ioe);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected abstract boolean merge(ProtocolSource paramProtocolSource);
/*      */ 
/*      */   public final boolean mergeFrom(ProtocolSource source)
/*      */   {
/*      */     try
/*      */     {
/*  402 */       return merge(source);
/*      */     } catch (IndexOutOfBoundsException e) {
/*  404 */       return false; } catch (IllegalArgumentException e) {
/*      */     }
/*  406 */     return false;
/*      */   }
/*      */ 
/*      */   public final boolean mergeFrom(byte[] buf)
/*      */   {
/*  419 */     return mergeFrom(new ProtocolSource(buf));
/*      */   }
/*      */ 
/*      */   public final boolean mergeFrom(byte[] buf, int offset, int length)
/*      */   {
/*  433 */     return mergeFrom(new ProtocolSource(buf, offset, length));
/*      */   }
/*      */ 
/*      */   public final boolean mergeFrom(ByteBuffer buffer)
/*      */   {
/*      */     try
/*      */     {
/*  449 */       ProtocolSource source = new ProtocolSource(buffer);
/*  450 */       bool = mergeFrom(source);
/*      */       return bool;
/*      */     }
/*      */     catch (BufferUnderflowException e)
/*      */     {
/*  452 */       boolean bool = false;
/*      */       return bool; } finally { buffer.position(buffer.limit()); } throw localObject;
/*      */   }
/*      */ 
/*      */   public final boolean mergeFrom(InputStream in)
/*      */   {
/*      */     try
/*      */     {
/*  478 */       return mergeFrom(ByteStreams.toByteArray(in)); } catch (IOException e) {
/*      */     }
/*  480 */     return false;
/*      */   }
/*      */ 
/*      */   public final boolean mergeFrom(InputSupplier<? extends InputStream> supplier)
/*      */   {
/*      */     try
/*      */     {
/*  500 */       InputStream in = (InputStream)supplier.getInput();
/*      */       try {
/*  502 */         boolean bool = mergeFrom(ByteStreams.toByteArray(in));
/*      */         return bool; } finally { in.close(); }
/*      */     } catch (IOException e) {
/*      */     }
/*  507 */     return false;
/*      */   }
/*      */ 
/*      */   public final boolean parseFrom(ProtocolSource source)
/*      */   {
/*  518 */     clear();
/*  519 */     return mergeFrom(source);
/*      */   }
/*      */ 
/*      */   public final boolean parseFrom(byte[] buf)
/*      */   {
/*  530 */     clear();
/*  531 */     return mergeFrom(buf);
/*      */   }
/*      */ 
/*      */   public final boolean parseFrom(byte[] buf, int offset, int length)
/*      */   {
/*  544 */     clear();
/*  545 */     return mergeFrom(buf, offset, length);
/*      */   }
/*      */ 
/*      */   public final boolean parseFrom(ByteBuffer buf)
/*      */   {
/*  556 */     clear();
/*  557 */     return mergeFrom(buf);
/*      */   }
/*      */ 
/*      */   public final boolean parseFrom(InputStream in)
/*      */   {
/*  567 */     clear();
/*  568 */     return mergeFrom(in);
/*      */   }
/*      */ 
/*      */   public final boolean parseFrom(InputSupplier<? extends InputStream> supplier)
/*      */   {
/*  579 */     clear();
/*  580 */     return mergeFrom(supplier);
/*      */   }
/*      */ 
/*      */   public MessageAppender getMessageAppender()
/*      */   {
/*  598 */     return null;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  607 */     return toString("", false);
/*      */   }
/*      */ 
/*      */   public String toString(PrintFlag[] flags)
/*      */   {
/*  612 */     Set flagSet = toEnumSet(flags);
/*  613 */     return toString("", flagSet);
/*      */   }
/*      */ 
/*      */   public String toString(Set<PrintFlag> flags)
/*      */   {
/*  618 */     return toString("", flags);
/*      */   }
/*      */ 
/*      */   public String toString(boolean printIndex)
/*      */   {
/*  623 */     return toString("", printIndex);
/*      */   }
/*      */ 
/*      */   public String toString(String prefix, boolean printIndex)
/*      */   {
/*  642 */     return toString(prefix, printIndex ? FLAGS_WITH_INDEX : FLAGS_DEFAULT);
/*      */   }
/*      */ 
/*      */   public String toString(String prefix, Set<PrintFlag> flags)
/*      */   {
/*  654 */     StringBuilder sb = new StringBuilder();
/*  655 */     outputText(sb, prefix, flags);
/*  656 */     if ((sb.length() > 0) && (!flags.contains(PrintFlag.FLATTEN))) {
/*  657 */       sb.append("\n");
/*      */     }
/*  659 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public String toString(int maxChars, PrintFlag[] flags)
/*      */   {
/*  670 */     if (maxChars < 3) {
/*  671 */       return "...";
/*      */     }
/*  673 */     Set flagSet = toEnumSet(flags);
/*  674 */     StringBuilder sb = new StringBuilder();
/*      */ 
/*  676 */     AbstractVisitor visitor = new BoundedAsciiVisitor(sb, "", flagSet, maxChars);
/*  677 */     visitor.visit(this);
/*      */ 
/*  679 */     if ((!visitor.canAccept()) && (sb.length() > 0)) {
/*  680 */       boolean endedWithQuote = sb.charAt(sb.length() - 1) == '"';
/*  681 */       sb.delete(maxChars - 4, sb.length()).append("...");
/*  682 */       if (endedWithQuote) {
/*  683 */         sb.append('"');
/*      */       }
/*      */     }
/*  686 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public String toFlatString(int maxChars)
/*      */   {
/*  700 */     return toString(maxChars, new PrintFlag[] { PrintFlag.FLATTEN });
/*      */   }
/*      */ 
/*      */   public String toFlatString()
/*      */   {
/*  710 */     return toFlatString(false);
/*      */   }
/*      */ 
/*      */   public String toFlatString(boolean printIndex)
/*      */   {
/*  730 */     Set flags = EnumSet.of(PrintFlag.FLATTEN);
/*  731 */     if (printIndex) {
/*  732 */       flags.add(PrintFlag.SHOW_ELEMENT_NUMBERS);
/*      */     }
/*      */ 
/*  735 */     return outputText(new StringBuilder(), null, flags).toString();
/*      */   }
/*      */ 
/*      */   private static Set<PrintFlag> toEnumSet(PrintFlag[] flags) {
/*  739 */     Set flagSet = EnumSet.noneOf(PrintFlag.class);
/*  740 */     for (PrintFlag flag : flags) {
/*  741 */       flagSet.add(flag);
/*      */     }
/*  743 */     return flagSet;
/*      */   }
/*      */ 
/*      */   public ProtocolMessage getDefaultInstanceForType()
/*      */   {
/*  753 */     return null;
/*      */   }
/*      */ 
/*      */   public final void writeTo(CodedOutputStream output)
/*      */     throws IOException
/*      */   {
/*  764 */     ProtocolSink sink = toProtocolSink();
/*  765 */     output.writeRawBytes(sink.array(), 0, sink.position());
/*      */   }
/*      */ 
/*      */   public final int getSerializedSize()
/*      */   {
/*  770 */     return encodingSize();
/*      */   }
/*      */ 
/*      */   public final ByteString toByteString()
/*      */   {
/*  775 */     ByteBuffer byteBuffer = toByteBuffer();
/*  776 */     return ByteString.copyFrom(byteBuffer);
/*      */   }
/*      */ 
/*      */   public final void writeTo(OutputStream output) throws IOException
/*      */   {
/*  781 */     outputTo(output);
/*      */   }
/*      */ 
/*      */   public final void writeDelimitedTo(OutputStream output) throws IOException
/*      */   {
/*  786 */     int serializedSize = getSerializedSize();
/*  787 */     int varIntSize = CodedOutputStream.computeRawVarint32Size(serializedSize);
/*  788 */     ProtocolSink sink = new ProtocolSink(varIntSize + serializedSize);
/*  789 */     sink.putVarInt(serializedSize);
/*  790 */     outputTo(sink);
/*  791 */     output.write(sink.array(), 0, sink.position());
/*      */   }
/*      */ 
/*      */   public final MessageLite.Builder newBuilderForType()
/*      */   {
/*  803 */     return new Proto2BuilderAdapter(newInstance());
/*      */   }
/*      */ 
/*      */   public final MessageLite.Builder toBuilder()
/*      */   {
/*  815 */     ProtocolMessage copy = newInstance();
/*  816 */     copy.mergeFrom(this);
/*  817 */     return new Proto2BuilderAdapter(copy);
/*      */   }
/*      */ 
/*      */   private StringBuilder outputText(StringBuilder sb, String prefix, Set<PrintFlag> flags)
/*      */   {
/* 1404 */     new AsciiVisitor(sb, prefix, flags).visit(this);
/* 1405 */     return sb;
/*      */   }
/*      */ 
/*      */   public String toXmlString()
/*      */   {
/* 1412 */     StringBuilder sb = new StringBuilder("<?xml version=\"1.0\"?>\n<toplevel>\n");
/* 1413 */     new XmlVisitor(sb, "  ").visit(this);
/* 1414 */     return "\n</toplevel>\n";
/*      */   }
/*      */ 
/*      */   public abstract ProtocolType getProtocolType();
/*      */ 
/*      */   public BeanDescriptor getBeanDescriptor()
/*      */   {
/* 1438 */     return null;
/*      */   }
/*      */ 
/*      */   public PropertyDescriptor[] getPropertyDescriptors()
/*      */   {
/* 1449 */     if (getClass() != ProtocolMessage.class) {
/* 1450 */       return getProtocolType().getPropertyDescriptors();
/*      */     }
/* 1452 */     return null;
/*      */   }
/*      */ 
/*      */   public int getDefaultPropertyIndex()
/*      */   {
/* 1459 */     return -1;
/*      */   }
/*      */ 
/*      */   public EventSetDescriptor[] getEventSetDescriptors()
/*      */   {
/* 1466 */     return null;
/*      */   }
/*      */ 
/*      */   public int getDefaultEventIndex()
/*      */   {
/* 1473 */     return -1;
/*      */   }
/*      */ 
/*      */   public MethodDescriptor[] getMethodDescriptors()
/*      */   {
/* 1480 */     return null;
/*      */   }
/*      */ 
/*      */   public BeanInfo[] getAdditionalBeanInfo()
/*      */   {
/* 1487 */     return null;
/*      */   }
/*      */ 
/*      */   public Image getIcon(int iconKind)
/*      */   {
/* 1494 */     return null;
/*      */   }
/*      */ 
/*      */   public CategoryInformation<T> messageCategoryInformation()
/*      */   {
/* 1506 */     return null;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   56 */     for (int i = 0; i < 256; i++) {
/*   57 */       formattedHex[i] = String.format("0x%02x ", new Object[] { Integer.valueOf(i) });
/*      */     }
/*      */ 
/*  627 */     FLAGS_DEFAULT = EnumSet.of(PrintFlag.ALLOW_NULL);
/*      */ 
/*  631 */     FLAGS_WITH_INDEX = EnumSet.of(PrintFlag.SHOW_ELEMENT_NUMBERS);
/*      */   }
/*      */ 
/*      */   public static class XmlVisitor extends ProtocolMessage.AbstractVisitor
/*      */   {
/*      */     protected XmlVisitor(StringBuilder sb, String prefix)
/*      */     {
/* 1266 */       super(prefix, EnumSet.noneOf(ProtocolMessage.PrintFlag.class));
/*      */     }
/*      */ 
/*      */     public void visitBoolean(ProtocolType.FieldType ti, int index, boolean value)
/*      */     {
/* 1277 */       header(ti, index);
/* 1278 */       append(new Object[] { " bool=\"", Boolean.valueOf(value), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitInteger(ProtocolType.FieldType ti, int index, int value)
/*      */     {
/* 1289 */       header(ti, index);
/* 1290 */       append(new Object[] { " int=\"", Integer.valueOf(value), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitLong(ProtocolType.FieldType ti, int index, long value)
/*      */     {
/* 1301 */       header(ti, index);
/* 1302 */       append(new Object[] { " long=\"", Long.valueOf(value), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitByteArray(ProtocolType.FieldType ti, int index, byte[] value)
/*      */     {
/* 1313 */       header(ti, index);
/* 1314 */       append(new Object[] { " data=\"", CharEscapers.xmlEscaper().escape(Protocol.toStringUtf8(value)), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitString(ProtocolType.FieldType ti, int index, String value)
/*      */     {
/* 1326 */       header(ti, index);
/* 1327 */       append(new Object[] { " data=\"", CharEscapers.xmlEscaper().escape(value), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitFloat(ProtocolType.FieldType ti, int index, float value)
/*      */     {
/* 1338 */       header(ti, index);
/* 1339 */       append(new Object[] { " float=\"", Float.valueOf(value), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitDouble(ProtocolType.FieldType ti, int index, double value)
/*      */     {
/* 1350 */       header(ti, index);
/* 1351 */       append(new Object[] { " double=\"", Double.valueOf(value), "\"/>" });
/*      */     }
/*      */ 
/*      */     public void visitGroup(ProtocolType.FieldType ti, int index, ProtocolMessage value)
/*      */     {
/* 1362 */       visitCollection(ti, index, value, ">", "</" + CharEscapers.xmlEscaper().escape(ti.getName()) + ">");
/*      */     }
/*      */ 
/*      */     public void visitForeign(ProtocolType.FieldType ti, int index, ProtocolMessage value)
/*      */     {
/* 1374 */       visitGroup(ti, index, value);
/*      */     }
/*      */ 
/*      */     protected void header(ProtocolType.FieldType ti, int index)
/*      */     {
/* 1384 */       separator();
/* 1385 */       prefix();
/* 1386 */       append(new Object[] { "<", CharEscapers.xmlEscaper().escape(ti.getName()) });
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BoundedAsciiVisitor extends ProtocolMessage.AsciiVisitor
/*      */   {
/* 1206 */     int maxChars = 0;
/*      */ 
/*      */     BoundedAsciiVisitor(StringBuilder sb, String prefix, Set<ProtocolMessage.PrintFlag> flags, int maxChars)
/*      */     {
/* 1215 */       super(prefix, flags);
/* 1216 */       this.maxChars = maxChars;
/*      */     }
/*      */ 
/*      */     private int availableSpace()
/*      */     {
/* 1223 */       return this.maxChars - this.sb.length();
/*      */     }
/*      */ 
/*      */     public boolean canAccept()
/*      */     {
/* 1231 */       return availableSpace() > 0;
/*      */     }
/*      */ 
/*      */     public void visitByteArray(ProtocolType.FieldType ti, int index, byte[] value)
/*      */     {
/* 1242 */       header(ti, index);
/* 1243 */       byte[] bytesToStore = this.binaryString ? ti.getRawByteArray(this.node, index) : value;
/* 1244 */       int nBytes = Math.max(0, Math.min(bytesToStore.length, availableSpace() - 4));
/*      */ 
/* 1246 */       String stringValue = this.binaryString ? new String(ti.getRawByteArray(this.node, index), 0, 0, nBytes) : ProtocolSupport.toStringUtf8(value, 0, nBytes);
/*      */ 
/* 1249 */       appendString(stringValue);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class AsciiVisitor extends ProtocolMessage.AbstractVisitor
/*      */   {
/*      */     AsciiVisitor(StringBuilder sb, String prefix, Set<ProtocolMessage.PrintFlag> flags)
/*      */     {
/* 1018 */       super(prefix, flags);
/*      */     }
/*      */ 
/*      */     public void visitBoolean(ProtocolType.FieldType ti, int index, boolean value)
/*      */     {
/* 1028 */       header(ti, index);
/* 1029 */       append(new Object[] { ": ", Boolean.valueOf(value) });
/*      */     }
/*      */ 
/*      */     public void visitInteger(ProtocolType.FieldType ti, int index, int value)
/*      */     {
/* 1042 */       header(ti, index);
/* 1043 */       append(new Object[] { ": " });
/* 1044 */       ProtocolType.FieldBaseType type = ti.getBaseType();
/* 1045 */       Class enumType = ti.getEnumType();
/*      */ 
/* 1047 */       if ((enumType != null) && (this.flags.contains(ProtocolMessage.PrintFlag.PRINT_ENUMS)))
/*      */       {
/*      */         try
/*      */         {
/* 1052 */           Method method = enumType.getMethod("valueOf", new Class[] { Integer.TYPE });
/* 1053 */           Enum e = (Enum)method.invoke(null, new Object[] { Integer.valueOf(value) });
/* 1054 */           if (e != null) {
/* 1055 */             append(new Object[] { e });
/* 1056 */             return;
/*      */           }
/*      */         } catch (NoSuchMethodException e) {
/* 1059 */           throw new RuntimeException(e);
/*      */         } catch (IllegalAccessException e) {
/* 1061 */           throw new RuntimeException(e);
/*      */         } catch (InvocationTargetException e) {
/* 1063 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */ 
/* 1067 */       if ((!this.numberAlwaysDecimal) && ((value >= 2000000000) || (value <= -2000000000) || (type.isFixed())))
/*      */       {
/* 1070 */         append(new Object[] { "0x", Integer.toHexString(value) });
/*      */       }
/* 1072 */       else append(new Object[] { Integer.valueOf(value) });
/*      */     }
/*      */ 
/*      */     public void visitLong(ProtocolType.FieldType ti, int index, long value)
/*      */     {
/* 1083 */       header(ti, index);
/* 1084 */       append(new Object[] { ": " });
/* 1085 */       ProtocolType.FieldBaseType type = ti.getBaseType();
/* 1086 */       if ((!this.numberAlwaysDecimal) && ((value >= 2000000000L) || (value <= -2000000000L) || (type.isFixed())))
/*      */       {
/* 1089 */         append(new Object[] { "0x", Long.toHexString(value) });
/*      */       }
/* 1091 */       else append(new Object[] { Long.valueOf(value) });
/*      */     }
/*      */ 
/*      */     public void visitString(ProtocolType.FieldType ti, int index, String value)
/*      */     {
/* 1103 */       header(ti, index);
/*      */ 
/* 1105 */       appendString(this.binaryString ? new String(ti.getRawByteArray(this.node, index), 0) : value);
/*      */     }
/*      */ 
/*      */     public void visitFloat(ProtocolType.FieldType ti, int index, float value)
/*      */     {
/* 1116 */       header(ti, index);
/* 1117 */       append(new Object[] { ": ", Float.valueOf(value), "f" });
/*      */     }
/*      */ 
/*      */     public void visitDouble(ProtocolType.FieldType ti, int index, double value)
/*      */     {
/* 1128 */       header(ti, index);
/* 1129 */       append(new Object[] { ": ", Double.valueOf(value) });
/*      */     }
/*      */ 
/*      */     public void visitByteArray(ProtocolType.FieldType ti, int index, byte[] value)
/*      */     {
/* 1140 */       header(ti, index);
/*      */ 
/* 1142 */       String stringValue = this.binaryString ? new String(ti.getRawByteArray(this.node, index), 0) : ProtocolSupport.toStringUtf8(value);
/*      */ 
/* 1145 */       appendString(stringValue);
/*      */     }
/*      */ 
/*      */     public void visitGroup(ProtocolType.FieldType ti, int index, ProtocolMessage value)
/*      */     {
/* 1156 */       visitCollection(ti, index, value, " {", "}");
/*      */     }
/*      */ 
/*      */     public void visitForeign(ProtocolType.FieldType ti, int index, ProtocolMessage value)
/*      */     {
/* 1167 */       visitCollection(ti, index, value, " <", ">");
/*      */     }
/*      */ 
/*      */     public void visitNull()
/*      */     {
/* 1175 */       separator();
/* 1176 */       prefix();
/* 1177 */       append(new Object[] { "ILLEGAL_NULL_VALUE" });
/*      */     }
/*      */ 
/*      */     protected void header(ProtocolType.FieldType ti, int index)
/*      */     {
/* 1187 */       separator();
/* 1188 */       prefix();
/* 1189 */       if ((ti instanceof MessageSet.FieldType))
/* 1190 */         append(new Object[] { "[", ti.getName(), "]" });
/*      */       else {
/* 1192 */         append(new Object[] { ti.getName() });
/*      */       }
/* 1194 */       if ((this.flags.contains(ProtocolMessage.PrintFlag.SHOW_ELEMENT_NUMBERS)) && (index >= 0) && (ti.getPresence() == ProtocolType.Presence.REPEATED))
/*      */       {
/* 1196 */         append(new Object[] { "(", Integer.valueOf(index), ")" });
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class AbstractVisitor
/*      */     implements MessageVisitor
/*      */   {
/*      */     protected final StringBuilder sb;
/*      */     protected final Set<ProtocolMessage.PrintFlag> flags;
/*      */     protected final char separator;
/*      */     protected final String newline;
/*      */     protected final boolean numberAlwaysDecimal;
/*      */     protected final boolean escapeString;
/*      */     protected final boolean binaryString;
/*      */     protected final String prefix;
/*  830 */     private final String alignment = "  ";
/*  831 */     private int depth = -1;
/*  832 */     private boolean needSeparator = false;
/*      */     protected ProtocolMessage node;
/*      */ 
/*      */     protected AbstractVisitor(StringBuilder sb, String prefix, Set<ProtocolMessage.PrintFlag> flags)
/*      */     {
/*  842 */       this.sb = sb;
/*  843 */       this.flags = flags;
/*  844 */       this.separator = (flags.contains(ProtocolMessage.PrintFlag.FLATTEN) ? ',' : '\n');
/*  845 */       this.newline = (flags.contains(ProtocolMessage.PrintFlag.FLATTEN) ? "" : "\n");
/*  846 */       this.numberAlwaysDecimal = flags.contains(ProtocolMessage.PrintFlag.NUMBERS_ALWAYS_DECIMAL);
/*  847 */       this.escapeString = (!flags.contains(ProtocolMessage.PrintFlag.NO_ESCAPE_STRINGS));
/*  848 */       this.binaryString = flags.contains(ProtocolMessage.PrintFlag.BINARY_STRINGS);
/*  849 */       this.prefix = prefix;
/*      */     }
/*      */ 
/*      */     public void visit(ProtocolMessage protocolMessage)
/*      */     {
/*  858 */       boolean neededSeparator = this.needSeparator;
/*  859 */       this.needSeparator = false;
/*      */ 
/*  861 */       ProtocolMessage previousNode = this.node;
/*  862 */       this.node = protocolMessage;
/*  863 */       this.depth += 1;
/*  864 */       newline();
/*      */ 
/*  866 */       if (protocolMessage != null) {
/*  867 */         ProtocolType.visit(protocolMessage, this);
/*  868 */         newline();
/*      */       } else {
/*  870 */         visitNull();
/*      */       }
/*  872 */       this.depth -= 1;
/*  873 */       this.needSeparator = neededSeparator;
/*  874 */       this.node = previousNode;
/*      */     }
/*      */ 
/*      */     protected void visitCollection(ProtocolType.FieldType ti, int index, ProtocolMessage collection, String opener, String closer)
/*      */     {
/*  888 */       header(ti, index);
/*      */ 
/*  890 */       if (collection == null) {
/*  891 */         visit(collection);
/*      */       } else {
/*  893 */         append(new Object[] { opener });
/*  894 */         visit(collection);
/*  895 */         prefix();
/*  896 */         append(new Object[] { closer });
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean canAccept()
/*      */     {
/*  902 */       return true;
/*      */     }
/*      */ 
/*      */     public boolean shouldVisitField(ProtocolType.FieldType ti, int count)
/*      */     {
/*  909 */       return canAccept();
/*      */     }
/*      */ 
/*      */     public abstract void visitForeign(ProtocolType.FieldType paramFieldType, int paramInt, ProtocolMessage paramProtocolMessage);
/*      */ 
/*      */     public void visitRawMessage(ByteBuffer value)
/*      */     {
/*  922 */       while ((value.remaining() > 0) && (canAccept())) {
/*  923 */         separator();
/*  924 */         prefix();
/*  925 */         for (int j = 0; (j < 16) && (value.remaining() > 0) && (canAccept()); j++)
/*  926 */           append(new Object[] { ProtocolMessage.access$000()[(value.get() & 0xFF)] });
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void visitNull()
/*      */     {
/*  936 */       throw new NullPointerException();
/*      */     }
/*      */ 
/*      */     protected void prefix()
/*      */     {
/*  944 */       if (this.prefix != null) {
/*  945 */         append(new Object[] { this.prefix });
/*  946 */         for (int i = 0; i < this.depth; i++)
/*  947 */           append(new Object[] { "  " });
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void separator()
/*      */     {
/*  957 */       if (this.needSeparator) {
/*  958 */         append(new Object[] { Character.valueOf(this.separator) });
/*      */       }
/*  960 */       this.needSeparator = true;
/*      */     }
/*      */ 
/*      */     private void newline()
/*      */     {
/*  968 */       if (this.depth > 0)
/*  969 */         append(new Object[] { this.newline });
/*      */     }
/*      */ 
/*      */     protected void append(Object[] parts)
/*      */     {
/*  979 */       for (Object part : parts)
/*  980 */         this.sb.append(part.toString());
/*      */     }
/*      */ 
/*      */     protected void appendString(String s)
/*      */     {
/*  989 */       append(new Object[] { ": \"", this.escapeString ? CharEscapers.javaStringEscaper().escape(s) : s, "\"" });
/*      */     }
/*      */ 
/*      */     protected abstract void header(ProtocolType.FieldType paramFieldType, int paramInt);
/*      */ 
/*      */     public void visit(ByteBuffer message)
/*      */     {
/* 1001 */       visitRawMessage(message);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum PrintFlag
/*      */   {
/*   70 */     SHOW_ELEMENT_NUMBERS, 
/*      */ 
/*   72 */     PRINT_ENUMS, 
/*      */ 
/*   74 */     FLATTEN, 
/*      */ 
/*   80 */     NUMBERS_ALWAYS_DECIMAL, 
/*      */ 
/*   92 */     NO_ESCAPE_STRINGS, 
/*      */ 
/*   99 */     BINARY_STRINGS, 
/*      */ 
/*  105 */     ALLOW_NULL;
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage
 * JD-Core Version:    0.6.0
 */