/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.ListIterator;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingList<E> extends ForwardingCollection<E>
/*    */   implements List<E>
/*    */ {
/*    */   protected abstract List<E> delegate();
/*    */ 
/*    */   public void add(int index, E element)
/*    */   {
/* 50 */     delegate().add(index, element);
/*    */   }
/*    */ 
/*    */   public boolean addAll(int index, Collection<? extends E> elements) {
/* 54 */     return delegate().addAll(index, elements);
/*    */   }
/*    */ 
/*    */   public E get(int index) {
/* 58 */     return delegate().get(index);
/*    */   }
/*    */ 
/*    */   public int indexOf(Object element) {
/* 62 */     return delegate().indexOf(element);
/*    */   }
/*    */ 
/*    */   public int lastIndexOf(Object element) {
/* 66 */     return delegate().lastIndexOf(element);
/*    */   }
/*    */ 
/*    */   public ListIterator<E> listIterator() {
/* 70 */     return delegate().listIterator();
/*    */   }
/*    */ 
/*    */   public ListIterator<E> listIterator(int index) {
/* 74 */     return delegate().listIterator(index);
/*    */   }
/*    */ 
/*    */   public E remove(int index) {
/* 78 */     return delegate().remove(index);
/*    */   }
/*    */ 
/*    */   public E set(int index, E element) {
/* 82 */     return delegate().set(index, element);
/*    */   }
/*    */ 
/*    */   public List<E> subList(int fromIndex, int toIndex) {
/* 86 */     return delegate().subList(fromIndex, toIndex);
/*    */   }
/*    */ 
/*    */   public boolean equals(@Nullable Object object) {
/* 90 */     return (object == this) || (delegate().equals(object));
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 94 */     return delegate().hashCode();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingList
 * JD-Core Version:    0.6.0
 */