/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingMap<K, V> extends ForwardingObject
/*    */   implements Map<K, V>
/*    */ {
/*    */   protected abstract Map<K, V> delegate();
/*    */ 
/*    */   public int size()
/*    */   {
/* 47 */     return delegate().size();
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 51 */     return delegate().isEmpty();
/*    */   }
/*    */ 
/*    */   public V remove(Object object) {
/* 55 */     return delegate().remove(object);
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 59 */     delegate().clear();
/*    */   }
/*    */ 
/*    */   public boolean containsKey(Object key) {
/* 63 */     return delegate().containsKey(key);
/*    */   }
/*    */ 
/*    */   public boolean containsValue(Object value) {
/* 67 */     return delegate().containsValue(value);
/*    */   }
/*    */ 
/*    */   public V get(Object key) {
/* 71 */     return delegate().get(key);
/*    */   }
/*    */ 
/*    */   public V put(K key, V value) {
/* 75 */     return delegate().put(key, value);
/*    */   }
/*    */ 
/*    */   public void putAll(Map<? extends K, ? extends V> map) {
/* 79 */     delegate().putAll(map);
/*    */   }
/*    */ 
/*    */   public Set<K> keySet() {
/* 83 */     return delegate().keySet();
/*    */   }
/*    */ 
/*    */   public Collection<V> values() {
/* 87 */     return delegate().values();
/*    */   }
/*    */ 
/*    */   public Set<Map.Entry<K, V>> entrySet() {
/* 91 */     return delegate().entrySet();
/*    */   }
/*    */ 
/*    */   public boolean equals(@Nullable Object object) {
/* 95 */     return (object == this) || (delegate().equals(object));
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 99 */     return delegate().hashCode();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingMap
 * JD-Core Version:    0.6.0
 */