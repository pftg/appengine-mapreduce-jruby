/*     */ package com.google.appengine.api.memcache;
/*     */ 
/*     */ import com.google.appengine.api.NamespaceManager;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.Message.Builder;
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApiProxyException;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ class MemcacheServiceImpl
/*     */   implements MemcacheService
/*     */ {
/*     */   static final String PACKAGE = "memcache";
/*     */   private static final Logger logger;
/*  60 */   private ErrorHandler handler = new LogAndContinueErrorHandler(Level.INFO);
/*     */   private String namespace;
/*     */ 
/*     */   MemcacheServiceImpl(String namespace)
/*     */   {
/* 162 */     if (namespace != null) {
/* 163 */       NamespaceManager.validateNamespace(namespace);
/*     */     }
/* 165 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   private boolean makeSyncCall(String methodName, Message request, Message.Builder response, String errorText)
/*     */   {
/*     */     try
/*     */     {
/* 179 */       byte[] responseBytes = ApiProxy.makeSyncCall("memcache", methodName, request.toByteArray());
/* 180 */       response.mergeFrom(responseBytes);
/* 181 */       return true;
/*     */     } catch (InvalidProtocolBufferException ex) {
/* 183 */       this.handler.handleServiceError(new MemcacheServiceException("Could not decode response:", ex));
/*     */     }
/*     */     catch (ApiProxy.ApplicationException ae)
/*     */     {
/* 189 */       logger.info(errorText + ": " + ae.getErrorDetail());
/* 190 */       this.handler.handleServiceError(new MemcacheServiceException(errorText));
/*     */     } catch (ApiProxy.ApiProxyException ex) {
/* 192 */       this.handler.handleServiceError(new MemcacheServiceException(errorText, ex));
/*     */     }
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 207 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setNamespace(String newNamespace)
/*     */   {
/* 219 */     this.namespace = newNamespace;
/*     */   }
/*     */ 
/*     */   private String getEffectiveNamespace()
/*     */   {
/* 229 */     if (this.namespace != null) {
/* 230 */       return this.namespace;
/*     */     }
/* 232 */     String namespace1 = NamespaceManager.get();
/* 233 */     return namespace1 == null ? "" : namespace1;
/*     */   }
/*     */ 
/*     */   public boolean contains(Object key) {
/* 241 */     MemcacheServicePb.MemcacheGetResponse.Builder response = MemcacheServicePb.MemcacheGetResponse.newBuilder();
/*     */     MemcacheServicePb.MemcacheGetRequest request;
/*     */     try {
/* 245 */       request = MemcacheServicePb.MemcacheGetRequest.newBuilder().setNameSpace(getEffectiveNamespace()).addKey(ByteString.copyFrom(MemcacheSerialization.makePbKey(key))).build();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 250 */       throw new IllegalArgumentException("Cannot use as key: '" + key + "'", ex);
/*     */     }
/* 252 */     if (!makeSyncCall("Get", request, response, "Memcache contains: exception testing contains (" + key + ")"))
/*     */     {
/* 254 */       return false;
/*     */     }
/* 256 */     return response.getItemCount() == 1;
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/* 266 */     MemcacheServicePb.MemcacheGetResponse.Builder response = MemcacheServicePb.MemcacheGetResponse.newBuilder();
/*     */     MemcacheServicePb.MemcacheGetRequest request;
/*     */     try {
/* 270 */       request = MemcacheServicePb.MemcacheGetRequest.newBuilder().setNameSpace(getEffectiveNamespace()).addKey(ByteString.copyFrom(MemcacheSerialization.makePbKey(key))).build();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 275 */       throw new IllegalArgumentException("Cannot use as a key: '" + key + "'", ex);
/*     */     }
/* 277 */     if (!makeSyncCall("Get", request, response, "Memcache get: exception getting 1 key (" + key + ")"))
/*     */     {
/* 279 */       return null;
/*     */     }
/* 281 */     if (response.getItemCount() == 0) {
/* 282 */       return null;
/*     */     }
/* 284 */     MemcacheServicePb.MemcacheGetResponse.Item item = response.getItem(0);
/*     */     try
/*     */     {
/* 287 */       return MemcacheSerialization.deserialize(item.getValue().toByteArray(), item.getFlags());
/*     */     } catch (ClassNotFoundException ex) {
/* 289 */       this.handler.handleDeserializationError(new InvalidValueException("Can't find class for value of key '" + key + "'", ex));
/*     */ 
/* 291 */       return null; } catch (IOException ex) {
/*     */     }
/* 293 */     throw new InvalidValueException("IO exception parsing value of '" + key + "'", ex);
/*     */   }
/*     */ 
/*     */   public <T> Map<T, Object> getAll(Collection<T> keys)
/*     */   {
/* 301 */     MemcacheServicePb.MemcacheGetResponse.Builder response = MemcacheServicePb.MemcacheGetResponse.newBuilder();
/*     */ 
/* 303 */     MemcacheServicePb.MemcacheGetRequest.Builder requestBuilder = MemcacheServicePb.MemcacheGetRequest.newBuilder();
/* 304 */     requestBuilder.setNameSpace(getEffectiveNamespace());
/*     */ 
/* 306 */     Map cacheKeyToObjectKey = new HashMap();
/* 307 */     for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
/*     */       try {
/* 309 */         byte[] keybytes = MemcacheSerialization.makePbKey(key);
/* 310 */         cacheKeyToObjectKey.put(new CacheKey(keybytes), key);
/* 311 */         requestBuilder.addKey(ByteString.copyFrom(keybytes));
/*     */       } catch (IOException ex) {
/* 313 */         throw new IllegalArgumentException("Cannot use as key: '" + key + "'", ex);
/*     */       }
/*     */     }
/* 316 */     if (!makeSyncCall("Get", requestBuilder.build(), response, "Memcache get: exception getting multiple keys"))
/*     */     {
/* 318 */       return Collections.emptyMap();
/*     */     }
/*     */ 
/* 321 */     Map result = new HashMap();
/* 322 */     for (MemcacheServicePb.MemcacheGetResponse.Item item : response.getItemList()) {
/* 323 */       Object key = null;
/*     */       try {
/* 325 */         key = cacheKeyToObjectKey.get(new CacheKey(item.getKey().toByteArray()));
/* 326 */         Object obj = MemcacheSerialization.deserialize(item.getValue().toByteArray(), item.getFlags());
/*     */ 
/* 328 */         result.put(key, obj);
/*     */       } catch (ClassNotFoundException ex) {
/* 330 */         this.handler.handleDeserializationError(new InvalidValueException("Can't find class for value of key '" + key + "'", ex));
/*     */ 
/* 332 */         return null;
/*     */       } catch (IOException ex) {
/* 334 */         throw new InvalidValueException("IO exception parsing value of '" + key + "'", ex);
/*     */       }
/*     */     }
/* 337 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean put(Object key, Object value, Expiration expires, MemcacheService.SetPolicy policy)
/*     */   {
/* 351 */     MemcacheServicePb.MemcacheSetResponse.Builder response = MemcacheServicePb.MemcacheSetResponse.newBuilder();
/*     */ 
/* 353 */     MemcacheServicePb.MemcacheSetRequest.Builder requestBuilder = MemcacheServicePb.MemcacheSetRequest.newBuilder();
/* 354 */     requestBuilder.setNameSpace(getEffectiveNamespace());
/*     */ 
/* 356 */     MemcacheServicePb.MemcacheSetRequest.Item.Builder itemBuilder = MemcacheServicePb.MemcacheSetRequest.Item.newBuilder();
/*     */     try {
/* 358 */       MemcacheSerialization.ValueAndFlags vaf = MemcacheSerialization.serialize(value);
/* 359 */       itemBuilder.setValue(ByteString.copyFrom(vaf.value));
/* 360 */       itemBuilder.setFlags(vaf.flags.ordinal());
/*     */     } catch (IOException ex) {
/* 362 */       throw new IllegalArgumentException("Cannot use as value: '" + value + "'", ex);
/*     */     }
/*     */     try {
/* 365 */       itemBuilder.setKey(ByteString.copyFrom(MemcacheSerialization.makePbKey(key)));
/*     */     } catch (IOException ex) {
/* 367 */       throw new IllegalArgumentException("Cannot use as key: '" + key + "'", ex);
/*     */     }
/* 369 */     itemBuilder.setExpirationTime(expires == null ? 0 : expires.getSecondsValue());
/* 370 */     itemBuilder.setSetPolicy(convertSetPolicyToPb(policy));
/* 371 */     requestBuilder.addItem(itemBuilder);
/*     */ 
/* 373 */     if (!makeSyncCall("Set", requestBuilder.build(), response, "Memcache put: exception setting 1 key (" + key + ") to '" + value + "'"))
/*     */     {
/* 375 */       return false;
/*     */     }
/* 377 */     if (response.getSetStatusCount() != 1) {
/* 378 */       throw new MemcacheServiceException("Memcache put: Set one item, got " + response.getSetStatusCount() + " response statuses");
/*     */     }
/*     */ 
/* 381 */     MemcacheServicePb.MemcacheSetResponse.SetStatusCode status = response.getSetStatus(0);
/* 382 */     if (status == MemcacheServicePb.MemcacheSetResponse.SetStatusCode.ERROR) {
/* 383 */       throw new MemcacheServiceException("Memcache put: Error setting single item (" + key + ")");
/*     */     }
/* 385 */     return status == MemcacheServicePb.MemcacheSetResponse.SetStatusCode.STORED;
/*     */   }
/*     */ 
/*     */   private MemcacheServicePb.MemcacheSetRequest.SetPolicy convertSetPolicyToPb(MemcacheService.SetPolicy policy) {
/* 389 */     switch (1.$SwitchMap$com$google$appengine$api$memcache$MemcacheService$SetPolicy[policy.ordinal()]) {
/*     */     case 1:
/* 391 */       return MemcacheServicePb.MemcacheSetRequest.SetPolicy.SET;
/*     */     case 2:
/* 393 */       return MemcacheServicePb.MemcacheSetRequest.SetPolicy.ADD;
/*     */     case 3:
/* 395 */       return MemcacheServicePb.MemcacheSetRequest.SetPolicy.REPLACE;
/*     */     }
/* 397 */     throw new IllegalArgumentException("Unknown policy: " + policy);
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value, Expiration expires)
/*     */   {
/* 404 */     put(key, value, expires, MemcacheService.SetPolicy.SET_ALWAYS);
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value)
/*     */   {
/* 412 */     put(key, value, null, MemcacheService.SetPolicy.SET_ALWAYS);
/*     */   }
/*     */ 
/*     */   public <T> Set<T> putAll(Map<T, ?> values, Expiration expires, MemcacheService.SetPolicy policy)
/*     */   {
/* 426 */     MemcacheServicePb.MemcacheSetResponse.Builder response = MemcacheServicePb.MemcacheSetResponse.newBuilder();
/*     */ 
/* 428 */     MemcacheServicePb.MemcacheSetRequest.Builder requestBuilder = MemcacheServicePb.MemcacheSetRequest.newBuilder();
/* 429 */     requestBuilder.setNameSpace(getEffectiveNamespace());
/*     */ 
/* 431 */     Map cacheKeyToObjectKey = new HashMap();
/*     */ 
/* 433 */     for (Map.Entry entry : values.entrySet()) {
/* 434 */       MemcacheServicePb.MemcacheSetRequest.Item.Builder itemBuilder = MemcacheServicePb.MemcacheSetRequest.Item.newBuilder();
/*     */       try {
/* 436 */         byte[] sha1 = MemcacheSerialization.makePbKey(entry.getKey());
/* 437 */         cacheKeyToObjectKey.put(new CacheKey(sha1), entry.getKey());
/* 438 */         itemBuilder.setKey(ByteString.copyFrom(sha1));
/*     */       } catch (IOException ex) {
/* 440 */         throw new IllegalArgumentException("Cannot use as key: '" + entry.getKey() + "'", ex);
/*     */       }
/*     */       try
/*     */       {
/* 444 */         MemcacheSerialization.ValueAndFlags vaf = MemcacheSerialization.serialize(entry.getValue());
/* 445 */         itemBuilder.setValue(ByteString.copyFrom(vaf.value));
/* 446 */         itemBuilder.setFlags(vaf.flags.ordinal());
/*     */       } catch (IOException ex) {
/* 448 */         throw new IllegalArgumentException("Cannot use as value: '" + entry.getValue() + "'", ex);
/*     */       }
/*     */ 
/* 451 */       itemBuilder.setExpirationTime(expires == null ? 0 : expires.getSecondsValue());
/* 452 */       itemBuilder.setSetPolicy(convertSetPolicyToPb(policy));
/* 453 */       requestBuilder.addItem(itemBuilder);
/*     */     }
/* 455 */     MemcacheServicePb.MemcacheSetRequest request = requestBuilder.build();
/* 456 */     if (!makeSyncCall("Set", request, response, "Memcache put: Unknown exception setting " + values.size() + " keys"))
/*     */     {
/* 458 */       return new HashSet();
/*     */     }
/* 460 */     HashSet result = new HashSet();
/* 461 */     HashSet errors = new HashSet();
/*     */ 
/* 463 */     if (response.getSetStatusCount() != values.size()) {
/* 464 */       throw new MemcacheServiceException("Memcache put: Set " + values.size() + " items, got " + response.getSetStatusCount() + " response statuses");
/*     */     }
/*     */ 
/* 468 */     for (int i = 0; i < values.size(); i++) {
/* 469 */       MemcacheServicePb.MemcacheSetResponse.SetStatusCode status = response.getSetStatus(i);
/* 470 */       byte[] key = request.getItem(i).getKey().toByteArray();
/* 471 */       if (status == MemcacheServicePb.MemcacheSetResponse.SetStatusCode.ERROR)
/* 472 */         errors.add(key);
/* 473 */       else if (status == MemcacheServicePb.MemcacheSetResponse.SetStatusCode.STORED) {
/* 474 */         result.add(cacheKeyToObjectKey.get(new CacheKey(key)));
/*     */       }
/*     */     }
/* 477 */     if (errors.size() != 0) {
/* 478 */       StringBuilder builder = new StringBuilder();
/* 479 */       for (Iterator i$ = errors.iterator(); i$.hasNext(); ) { Object err = i$.next();
/* 480 */         if (builder.length() > 0) {
/* 481 */           builder.append(", ");
/*     */         }
/* 483 */         builder.append(err);
/*     */       }
/* 485 */       throw new MemcacheServiceException("Memcache put: Set failed to set " + errors.size() + " keys: " + builder.toString());
/*     */     }
/*     */ 
/* 488 */     return result;
/*     */   }
/*     */ 
/*     */   public void putAll(Map<?, ?> values, Expiration expires)
/*     */   {
/* 495 */     putAll(values, expires, MemcacheService.SetPolicy.SET_ALWAYS);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<?, ?> values)
/*     */   {
/* 503 */     putAll(values, null, MemcacheService.SetPolicy.SET_ALWAYS);
/*     */   }
/*     */ 
/*     */   public boolean delete(Object key)
/*     */   {
/* 512 */     return delete(key, 0L);
/*     */   }
/*     */ 
/*     */   public boolean delete(Object key, long millisNoReAdd) {
/* 524 */     MemcacheServicePb.MemcacheDeleteResponse.Builder response = MemcacheServicePb.MemcacheDeleteResponse.newBuilder();
/*     */     MemcacheServicePb.MemcacheDeleteRequest request;
/*     */     try {
/* 528 */       MemcacheServicePb.MemcacheDeleteRequest.Item.Builder item = MemcacheServicePb.MemcacheDeleteRequest.Item.newBuilder().setKey(ByteString.copyFrom(MemcacheSerialization.makePbKey(key))).setDeleteTime((int)(millisNoReAdd / 1000L));
/*     */ 
/* 532 */       request = MemcacheServicePb.MemcacheDeleteRequest.newBuilder().setNameSpace(getEffectiveNamespace()).addItem(item).build();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 537 */       throw new IllegalArgumentException("Cannot use as key: '" + key + "'", ex);
/*     */     }
/* 539 */     if (!makeSyncCall("Delete", request, response, "Memcache delete: Unknown exception deleting key: " + key))
/*     */     {
/* 541 */       return false;
/*     */     }
/* 543 */     return response.getDeleteStatus(0) == MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode.DELETED;
/*     */   }
/*     */ 
/*     */   public <T> Set<T> deleteAll(Collection<T> keys)
/*     */   {
/* 552 */     return deleteAll(keys, 0L);
/*     */   }
/*     */ 
/*     */   public <T> Set<T> deleteAll(Collection<T> keys, long millisNoReAdd)
/*     */   {
/* 564 */     Map cacheKeyToObjectKey = new HashMap();
/*     */ 
/* 566 */     MemcacheServicePb.MemcacheDeleteRequest.Builder requestBuilder = MemcacheServicePb.MemcacheDeleteRequest.newBuilder().setNameSpace(getEffectiveNamespace());
/*     */ 
/* 569 */     for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
/*     */       try {
/* 571 */         byte[] sha1 = MemcacheSerialization.makePbKey(key);
/* 572 */         cacheKeyToObjectKey.put(new CacheKey(sha1), key);
/*     */ 
/* 574 */         requestBuilder.addItem(MemcacheServicePb.MemcacheDeleteRequest.Item.newBuilder().setDeleteTime((int)(millisNoReAdd / 1000L)).setKey(ByteString.copyFrom(sha1)));
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 578 */         throw new IllegalArgumentException("Cannot use as key: '" + key + "'", ex);
/*     */       }
/*     */     }
/*     */ 
/* 582 */     MemcacheServicePb.MemcacheDeleteRequest request = requestBuilder.build();
/* 583 */     MemcacheServicePb.MemcacheDeleteResponse.Builder response = MemcacheServicePb.MemcacheDeleteResponse.newBuilder();
/* 584 */     if (!makeSyncCall("Delete", request, response, "Memcache delete: Unknown exception deleting multiple keys"))
/*     */     {
/* 586 */       return new HashSet();
/*     */     }
/* 588 */     Set retval = new HashSet();
/* 589 */     for (int i = 0; i < response.getDeleteStatusCount(); i++) {
/* 590 */       if (response.getDeleteStatus(i) == MemcacheServicePb.MemcacheDeleteResponse.DeleteStatusCode.DELETED) {
/* 591 */         retval.add(cacheKeyToObjectKey.get(new CacheKey(request.getItem(i).getKey().toByteArray())));
/*     */       }
/*     */     }
/*     */ 
/* 595 */     return retval;
/*     */   }
/*     */ 
/*     */   private MemcacheServicePb.MemcacheIncrementRequest internalBuildIncrementRequest(Object key, long delta, Long initialValue, MemcacheServicePb.MemcacheIncrementRequest.Builder requestBuilder)
/*     */   {
/*     */     try
/*     */     {
/* 604 */       requestBuilder.setKey(ByteString.copyFrom(MemcacheSerialization.makePbKey(key)));
/*     */     }
/*     */     catch (IOException ex) {
/* 607 */       throw new IllegalArgumentException("Cannot use as key: '" + key + "'", ex);
/*     */     }
/* 609 */     if (delta > 0L) {
/* 610 */       requestBuilder.setDirection(MemcacheServicePb.MemcacheIncrementRequest.Direction.INCREMENT);
/* 611 */       requestBuilder.setDelta(delta);
/*     */     } else {
/* 613 */       requestBuilder.setDirection(MemcacheServicePb.MemcacheIncrementRequest.Direction.DECREMENT);
/* 614 */       requestBuilder.setDelta(-delta);
/*     */     }
/* 616 */     if (initialValue != null) {
/* 617 */       requestBuilder.setInitialValue(initialValue.longValue());
/* 618 */       requestBuilder.setInitialFlags(MemcacheSerialization.Flag.LONG.ordinal());
/*     */     }
/* 620 */     return requestBuilder.build();
/*     */   }
/*     */ 
/*     */   public Long increment(Object key, long delta)
/*     */   {
/* 631 */     return increment(key, delta, null);
/*     */   }
/*     */ 
/*     */   public Long increment(Object key, long delta, Long initialValue)
/*     */   {
/* 644 */     MemcacheServicePb.MemcacheIncrementResponse.Builder response = MemcacheServicePb.MemcacheIncrementResponse.newBuilder();
/* 645 */     MemcacheServicePb.MemcacheIncrementRequest.Builder requestBuilder = MemcacheServicePb.MemcacheIncrementRequest.newBuilder();
/* 646 */     MemcacheServicePb.MemcacheIncrementRequest request = internalBuildIncrementRequest(key, delta, initialValue, requestBuilder.setNameSpace(getEffectiveNamespace()));
/*     */     try
/*     */     {
/* 659 */       byte[] responseBytes = ApiProxy.makeSyncCall("memcache", "Increment", request.toByteArray());
/* 660 */       response.mergeFrom(responseBytes);
/*     */     } catch (InvalidProtocolBufferException ex) {
/* 662 */       this.handler.handleServiceError(new MemcacheServiceException("Could not decode response:", ex));
/*     */     } catch (ApiProxy.ApplicationException ex) {
/* 664 */       logger.info(ex.getErrorDetail());
/* 665 */       throw new InvalidValueException("Non-incrementable value for key '" + key + "'");
/*     */     } catch (ApiProxy.ApiProxyException ex) {
/* 667 */       this.handler.handleServiceError(new MemcacheServiceException("Memcache increment of key '" + key + "': exception", ex));
/*     */     }
/*     */ 
/* 670 */     if (!response.hasNewValue()) {
/* 671 */       return null;
/*     */     }
/*     */ 
/* 674 */     return Long.valueOf(response.getNewValue());
/*     */   }
/*     */ 
/*     */   public <T> Map<T, Long> incrementAll(Collection<T> keys, long delta) {
/* 678 */     return incrementAll(keys, delta, null);
/*     */   }
/*     */ 
/*     */   public <T> Map<T, Long> incrementAll(Collection<T> keys, long delta, Long initialValue) {
/* 682 */     Map offsets = new LinkedHashMap();
/* 683 */     Long deltaLong = Long.valueOf(delta);
/* 684 */     for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
/* 685 */       offsets.put(key, Long.valueOf(delta));
/*     */     }
/* 687 */     return incrementAll(offsets, initialValue);
/*     */   }
/*     */ 
/*     */   public <T> Map<T, Long> incrementAll(Map<T, Long> offsets) {
/* 691 */     return incrementAll(offsets, null);
/*     */   }
/*     */ 
/*     */   public <T> Map<T, Long> incrementAll(Map<T, Long> offsets, Long initialValue) {
/* 695 */     MemcacheServicePb.MemcacheBatchIncrementRequest.Builder requestBuilder = MemcacheServicePb.MemcacheBatchIncrementRequest.newBuilder().setNameSpace(getEffectiveNamespace());
/*     */ 
/* 697 */     MemcacheServicePb.MemcacheBatchIncrementResponse.Builder response = MemcacheServicePb.MemcacheBatchIncrementResponse.newBuilder();
/*     */ 
/* 700 */     for (Map.Entry entry : offsets.entrySet()) {
/* 701 */       requestBuilder.addItem(internalBuildIncrementRequest(entry.getKey(), ((Long)entry.getValue()).longValue(), initialValue, MemcacheServicePb.MemcacheIncrementRequest.newBuilder()));
/*     */     }
/*     */ 
/* 706 */     MemcacheServicePb.MemcacheBatchIncrementRequest request = requestBuilder.build();
/*     */     try {
/* 708 */       byte[] responseBytes = ApiProxy.makeSyncCall("memcache", "BatchIncrement", request.toByteArray());
/*     */ 
/* 710 */       response.mergeFrom(responseBytes);
/*     */     } catch (InvalidProtocolBufferException ex) {
/* 712 */       this.handler.handleServiceError(new MemcacheServiceException("Could not decode response:", ex));
/*     */     } catch (ApiProxy.ApiProxyException ex) {
/* 714 */       this.handler.handleServiceError(new MemcacheServiceException("Memcache batch increment exception", ex));
/*     */     }
/*     */ 
/* 718 */     assert (response.getItemCount() == request.getItemCount());
/*     */ 
/* 720 */     Map result = new HashMap();
/* 721 */     int index = 0;
/* 722 */     for (Map.Entry entry : offsets.entrySet()) {
/* 723 */       MemcacheServicePb.MemcacheIncrementResponse responseItem = response.getItem(index++);
/* 724 */       if ((responseItem.getIncrementStatus().equals(MemcacheServicePb.MemcacheIncrementResponse.IncrementStatusCode.OK)) && (responseItem.hasNewValue()))
/*     */       {
/* 726 */         result.put(entry.getKey(), Long.valueOf(responseItem.getNewValue()));
/*     */       }
/* 728 */       else result.put(entry.getKey(), null);
/*     */ 
/*     */     }
/*     */ 
/* 732 */     return result;
/*     */   }
/*     */ 
/*     */   public void clearAll() {
/* 736 */     MemcacheServicePb.MemcacheFlushRequest request = MemcacheServicePb.MemcacheFlushRequest.newBuilder().build();
/* 737 */     MemcacheServicePb.MemcacheFlushResponse.Builder response = MemcacheServicePb.MemcacheFlushResponse.newBuilder();
/*     */ 
/* 739 */     makeSyncCall("FlushAll", request, response, "Memcache flush: exception");
/*     */   }
/*     */ 
/*     */   public Stats getStatistics() {
/* 743 */     MemcacheServicePb.MemcacheStatsRequest request = MemcacheServicePb.MemcacheStatsRequest.newBuilder().build();
/* 744 */     MemcacheServicePb.MemcacheStatsResponse.Builder response = MemcacheServicePb.MemcacheStatsResponse.newBuilder();
/*     */ 
/* 746 */     if (!makeSyncCall("Stats", request, response, "Memcache getStatistics: exception"))
/*     */     {
/* 748 */       return null;
/*     */     }
/* 750 */     MemcacheServicePb.MergedNamespaceStats stats = response.getStats();
/* 751 */     if (stats == null)
/*     */     {
/* 754 */       return new StatsImpl(0L, 0L, 0L, 0L, 0L, 0, null);
/*     */     }
/* 756 */     return new StatsImpl(stats.getHits(), stats.getMisses(), stats.getByteHits(), stats.getItems(), stats.getBytes(), stats.getOldestItemAge(), null);
/*     */   }
/*     */ 
/*     */   public ErrorHandler getErrorHandler()
/*     */   {
/* 762 */     return this.handler;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler newHandler) {
/* 766 */     this.handler = newHandler;
/*     */   }
/*     */ 
/*     */   public List<Object> grabTail(int itemCount) {
/* 770 */     if (getEffectiveNamespace().length() == 0) {
/* 771 */       throw new IllegalStateException("Namespace should be non-empty.");
/*     */     }
/*     */ 
/* 774 */     MemcacheServicePb.MemcacheGrabTailResponse.Builder response = MemcacheServicePb.MemcacheGrabTailResponse.newBuilder();
/*     */ 
/* 776 */     MemcacheServicePb.MemcacheGrabTailRequest.Builder requestBuilder = MemcacheServicePb.MemcacheGrabTailRequest.newBuilder();
/* 777 */     requestBuilder.setNameSpace(getEffectiveNamespace());
/* 778 */     requestBuilder.setItemCount(itemCount);
/*     */ 
/* 780 */     if (!makeSyncCall("GrabTail", requestBuilder.build(), response, "Memcache get: exception getting multiple keys"))
/*     */     {
/* 782 */       return Collections.emptyList();
/*     */     }
/*     */ 
/* 785 */     List result = new ArrayList();
/* 786 */     for (MemcacheServicePb.MemcacheGrabTailResponse.Item item : response.getItemList()) {
/*     */       try {
/* 788 */         Object obj = MemcacheSerialization.deserialize(item.getValue().toByteArray(), item.getFlags());
/*     */ 
/* 790 */         result.add(obj);
/*     */       } catch (ClassNotFoundException ex) {
/* 792 */         this.handler.handleDeserializationError(new InvalidValueException("Can't find class", ex));
/*     */ 
/* 794 */         return null;
/*     */       } catch (IOException ex) {
/* 796 */         throw new InvalidValueException("IO exception parsing value", ex);
/*     */       }
/*     */     }
/* 799 */     return result;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     logger = Logger.getLogger(MemcacheServiceImpl.class.getName());
/*     */   }
/*     */ 
/*     */   private class StatsImpl
/*     */     implements Stats
/*     */   {
/*     */     private long hits;
/*     */     private long misses;
/*     */     private long bytesFetched;
/*     */     private long items;
/*     */     private long bytesStored;
/*     */     private int maxCachedTime;
/*     */ 
/*     */     private StatsImpl(long hits, long misses, long bytesFetched, long items, long bytesStored, int maxCachedTime)
/*     */     {
/* 110 */       this.hits = hits;
/* 111 */       this.misses = misses;
/* 112 */       this.bytesFetched = bytesFetched;
/* 113 */       this.items = items;
/* 114 */       this.bytesStored = bytesStored;
/* 115 */       this.maxCachedTime = maxCachedTime;
/*     */     }
/*     */ 
/*     */     public long getHitCount()
/*     */     {
/* 120 */       return this.hits;
/*     */     }
/*     */ 
/*     */     public long getMissCount()
/*     */     {
/* 125 */       return this.misses;
/*     */     }
/*     */ 
/*     */     public long getBytesReturnedForHits()
/*     */     {
/* 130 */       return this.bytesFetched;
/*     */     }
/*     */ 
/*     */     public long getItemCount()
/*     */     {
/* 135 */       return this.items;
/*     */     }
/*     */ 
/*     */     public long getTotalItemBytes()
/*     */     {
/* 140 */       return this.bytesStored;
/*     */     }
/*     */ 
/*     */     public int getMaxTimeWithoutAccess()
/*     */     {
/* 145 */       return this.maxCachedTime;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 150 */       StringBuilder builder = new StringBuilder();
/* 151 */       builder.append("Hits: " + this.hits + "\n");
/* 152 */       builder.append("Misses: " + this.misses + "\n");
/* 153 */       builder.append("Bytes Fetched: " + this.bytesFetched + "\n");
/* 154 */       builder.append("Bytes Stored: " + this.bytesStored + "\n");
/* 155 */       builder.append("Items: " + this.items + "\n");
/* 156 */       builder.append("Max Cached Time: " + this.maxCachedTime + "\n");
/* 157 */       return builder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class CacheKey
/*     */   {
/*     */     private byte[] keyval;
/*     */     private int hashcode;
/*     */ 
/*     */     public CacheKey(byte[] bytes)
/*     */     {
/*  81 */       this.keyval = bytes;
/*  82 */       this.hashcode = Arrays.hashCode(this.keyval);
/*     */     }
/*     */ 
/*     */     public byte[] getBytes() {
/*  86 */       return this.keyval;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/*  91 */       if ((other instanceof CacheKey)) {
/*  92 */         return Arrays.equals(this.keyval, ((CacheKey)other).keyval);
/*     */       }
/*  94 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 100 */       return this.hashcode;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.MemcacheServiceImpl
 * JD-Core Version:    0.6.0
 */