package com.google.appengine.api.users;

import java.util.Set;

public abstract interface UserService
{
  public abstract String createLoginURL(String paramString);

  public abstract String createLoginURL(String paramString1, String paramString2);

  public abstract String createLoginURL(String paramString1, String paramString2, String paramString3, Set<String> paramSet);

  public abstract String createLogoutURL(String paramString);

  public abstract String createLogoutURL(String paramString1, String paramString2);

  public abstract boolean isUserLoggedIn();

  public abstract boolean isUserAdmin();

  public abstract User getCurrentUser();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.users.UserService
 * JD-Core Version:    0.6.0
 */