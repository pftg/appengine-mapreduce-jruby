/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class DynamicMessage extends AbstractMessage
/*     */ {
/*     */   private final Descriptors.Descriptor type;
/*     */   private final FieldSet<Descriptors.FieldDescriptor> fields;
/*     */   private final UnknownFieldSet unknownFields;
/*  22 */   private int memoizedSize = -1;
/*     */ 
/*     */   private DynamicMessage(Descriptors.Descriptor type, FieldSet<Descriptors.FieldDescriptor> fields, UnknownFieldSet unknownFields)
/*     */   {
/*  29 */     this.type = type;
/*  30 */     this.fields = fields;
/*  31 */     this.unknownFields = unknownFields;
/*     */   }
/*     */ 
/*     */   public static DynamicMessage getDefaultInstance(Descriptors.Descriptor type)
/*     */   {
/*  39 */     return new DynamicMessage(type, FieldSet.emptySet(), UnknownFieldSet.getDefaultInstance());
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, CodedInputStream input)
/*     */     throws IOException
/*     */   {
/*  47 */     return ((Builder)newBuilder(type).mergeFrom(input)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, CodedInputStream input, ExtensionRegistry extensionRegistry)
/*     */     throws IOException
/*     */   {
/*  56 */     return ((Builder)newBuilder(type).mergeFrom(input, extensionRegistry)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, ByteString data)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/*  62 */     return ((Builder)newBuilder(type).mergeFrom(data)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, ByteString data, ExtensionRegistry extensionRegistry)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/*  69 */     return ((Builder)newBuilder(type).mergeFrom(data, extensionRegistry)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, byte[] data)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/*  75 */     return ((Builder)newBuilder(type).mergeFrom(data)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, byte[] data, ExtensionRegistry extensionRegistry)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/*  82 */     return ((Builder)newBuilder(type).mergeFrom(data, extensionRegistry)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, InputStream input)
/*     */     throws IOException
/*     */   {
/*  88 */     return ((Builder)newBuilder(type).mergeFrom(input)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static DynamicMessage parseFrom(Descriptors.Descriptor type, InputStream input, ExtensionRegistry extensionRegistry)
/*     */     throws IOException
/*     */   {
/*  95 */     return ((Builder)newBuilder(type).mergeFrom(input, extensionRegistry)).buildParsed();
/*     */   }
/*     */ 
/*     */   public static Builder newBuilder(Descriptors.Descriptor type)
/*     */   {
/* 100 */     return new Builder(type, null);
/*     */   }
/*     */ 
/*     */   public static Builder newBuilder(Message prototype)
/*     */   {
/* 108 */     return new Builder(prototype.getDescriptorForType(), null).mergeFrom(prototype);
/*     */   }
/*     */ 
/*     */   public Descriptors.Descriptor getDescriptorForType()
/*     */   {
/* 115 */     return this.type;
/*     */   }
/*     */ 
/*     */   public DynamicMessage getDefaultInstanceForType() {
/* 119 */     return getDefaultInstance(this.type);
/*     */   }
/*     */ 
/*     */   public Map<Descriptors.FieldDescriptor, Object> getAllFields() {
/* 123 */     return this.fields.getAllFields();
/*     */   }
/*     */ 
/*     */   public boolean hasField(Descriptors.FieldDescriptor field) {
/* 127 */     verifyContainingType(field);
/* 128 */     return this.fields.hasField(field);
/*     */   }
/*     */ 
/*     */   public Object getField(Descriptors.FieldDescriptor field) {
/* 132 */     verifyContainingType(field);
/* 133 */     Object result = this.fields.getField(field);
/* 134 */     if (result == null) {
/* 135 */       if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/* 136 */         result = getDefaultInstance(field.getMessageType());
/*     */       else {
/* 138 */         result = field.getDefaultValue();
/*     */       }
/*     */     }
/* 141 */     return result;
/*     */   }
/*     */ 
/*     */   public int getRepeatedFieldCount(Descriptors.FieldDescriptor field) {
/* 145 */     verifyContainingType(field);
/* 146 */     return this.fields.getRepeatedFieldCount(field);
/*     */   }
/*     */ 
/*     */   public Object getRepeatedField(Descriptors.FieldDescriptor field, int index) {
/* 150 */     verifyContainingType(field);
/* 151 */     return this.fields.getRepeatedField(field, index);
/*     */   }
/*     */ 
/*     */   public UnknownFieldSet getUnknownFields() {
/* 155 */     return this.unknownFields;
/*     */   }
/*     */ 
/*     */   private static boolean isInitialized(Descriptors.Descriptor type, FieldSet<Descriptors.FieldDescriptor> fields)
/*     */   {
/* 161 */     for (Descriptors.FieldDescriptor field : type.getFields()) {
/* 162 */       if ((field.isRequired()) && 
/* 163 */         (!fields.hasField(field))) {
/* 164 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 170 */     return fields.isInitialized();
/*     */   }
/*     */ 
/*     */   public boolean isInitialized() {
/* 174 */     return isInitialized(this.type, this.fields);
/*     */   }
/*     */ 
/*     */   public void writeTo(CodedOutputStream output) throws IOException {
/* 178 */     if (this.type.getOptions().getMessageSetWireFormat()) {
/* 179 */       this.fields.writeMessageSetTo(output);
/* 180 */       this.unknownFields.writeAsMessageSetTo(output);
/*     */     } else {
/* 182 */       this.fields.writeTo(output);
/* 183 */       this.unknownFields.writeTo(output);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getSerializedSize() {
/* 188 */     int size = this.memoizedSize;
/* 189 */     if (size != -1) return size;
/*     */ 
/* 191 */     if (this.type.getOptions().getMessageSetWireFormat()) {
/* 192 */       size = this.fields.getMessageSetSerializedSize();
/* 193 */       size += this.unknownFields.getSerializedSizeAsMessageSet();
/*     */     } else {
/* 195 */       size = this.fields.getSerializedSize();
/* 196 */       size += this.unknownFields.getSerializedSize();
/*     */     }
/*     */ 
/* 199 */     this.memoizedSize = size;
/* 200 */     return size;
/*     */   }
/*     */ 
/*     */   public Builder newBuilderForType() {
/* 204 */     return new Builder(this.type, null);
/*     */   }
/*     */ 
/*     */   public Builder toBuilder() {
/* 208 */     return newBuilderForType().mergeFrom(this);
/*     */   }
/*     */ 
/*     */   private void verifyContainingType(Descriptors.FieldDescriptor field)
/*     */   {
/* 213 */     if (field.getContainingType() != this.type)
/* 214 */       throw new IllegalArgumentException("FieldDescriptor does not match message type.");
/*     */   }
/*     */ 
/*     */   public static final class Builder extends AbstractMessage.Builder<Builder>
/*     */   {
/*     */     private final Descriptors.Descriptor type;
/*     */     private FieldSet<Descriptors.FieldDescriptor> fields;
/*     */     private UnknownFieldSet unknownFields;
/*     */ 
/*     */     private Builder(Descriptors.Descriptor type)
/*     */     {
/* 231 */       this.type = type;
/* 232 */       this.fields = FieldSet.newFieldSet();
/* 233 */       this.unknownFields = UnknownFieldSet.getDefaultInstance();
/*     */     }
/*     */ 
/*     */     public Builder clear()
/*     */     {
/* 240 */       if (this.fields == null) {
/* 241 */         throw new IllegalStateException("Cannot call clear() after build().");
/*     */       }
/* 243 */       this.fields.clear();
/* 244 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(Message other) {
/* 248 */       if ((other instanceof DynamicMessage))
/*     */       {
/* 250 */         DynamicMessage otherDynamicMessage = (DynamicMessage)other;
/* 251 */         if (otherDynamicMessage.type != this.type) {
/* 252 */           throw new IllegalArgumentException("mergeFrom(Message) can only merge messages of the same type.");
/*     */         }
/*     */ 
/* 255 */         this.fields.mergeFrom(otherDynamicMessage.fields);
/* 256 */         mergeUnknownFields(otherDynamicMessage.unknownFields);
/* 257 */         return this;
/*     */       }
/* 259 */       return (Builder)super.mergeFrom(other);
/*     */     }
/*     */ 
/*     */     public DynamicMessage build()
/*     */     {
/* 265 */       if ((this.fields != null) && (!isInitialized())) {
/* 266 */         throw newUninitializedMessageException(new DynamicMessage(this.type, this.fields, this.unknownFields, null));
/*     */       }
/*     */ 
/* 269 */       return buildPartial();
/*     */     }
/*     */ 
/*     */     private DynamicMessage buildParsed()
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 278 */       if (!isInitialized()) {
/* 279 */         throw newUninitializedMessageException(new DynamicMessage(this.type, this.fields, this.unknownFields, null)).asInvalidProtocolBufferException();
/*     */       }
/*     */ 
/* 283 */       return buildPartial();
/*     */     }
/*     */ 
/*     */     public DynamicMessage buildPartial() {
/* 287 */       if (this.fields == null) {
/* 288 */         throw new IllegalStateException("build() has already been called on this Builder.");
/*     */       }
/*     */ 
/* 291 */       this.fields.makeImmutable();
/* 292 */       DynamicMessage result = new DynamicMessage(this.type, this.fields, this.unknownFields, null);
/*     */ 
/* 294 */       this.fields = null;
/* 295 */       this.unknownFields = null;
/* 296 */       return result;
/*     */     }
/*     */ 
/*     */     public Builder clone() {
/* 300 */       Builder result = new Builder(this.type);
/* 301 */       result.fields.mergeFrom(this.fields);
/* 302 */       return result;
/*     */     }
/*     */ 
/*     */     public boolean isInitialized() {
/* 306 */       return DynamicMessage.access$600(this.type, this.fields);
/*     */     }
/*     */ 
/*     */     public Descriptors.Descriptor getDescriptorForType() {
/* 310 */       return this.type;
/*     */     }
/*     */ 
/*     */     public DynamicMessage getDefaultInstanceForType() {
/* 314 */       return DynamicMessage.getDefaultInstance(this.type);
/*     */     }
/*     */ 
/*     */     public Map<Descriptors.FieldDescriptor, Object> getAllFields() {
/* 318 */       return this.fields.getAllFields();
/*     */     }
/*     */ 
/*     */     public Builder newBuilderForField(Descriptors.FieldDescriptor field) {
/* 322 */       verifyContainingType(field);
/*     */ 
/* 324 */       if (field.getJavaType() != Descriptors.FieldDescriptor.JavaType.MESSAGE) {
/* 325 */         throw new IllegalArgumentException("newBuilderForField is only valid for fields with message type.");
/*     */       }
/*     */ 
/* 329 */       return new Builder(field.getMessageType());
/*     */     }
/*     */ 
/*     */     public boolean hasField(Descriptors.FieldDescriptor field) {
/* 333 */       verifyContainingType(field);
/* 334 */       return this.fields.hasField(field);
/*     */     }
/*     */ 
/*     */     public Object getField(Descriptors.FieldDescriptor field) {
/* 338 */       verifyContainingType(field);
/* 339 */       Object result = this.fields.getField(field);
/* 340 */       if (result == null) {
/* 341 */         if (field.getJavaType() == Descriptors.FieldDescriptor.JavaType.MESSAGE)
/* 342 */           result = DynamicMessage.getDefaultInstance(field.getMessageType());
/*     */         else {
/* 344 */           result = field.getDefaultValue();
/*     */         }
/*     */       }
/* 347 */       return result;
/*     */     }
/*     */ 
/*     */     public Builder setField(Descriptors.FieldDescriptor field, Object value) {
/* 351 */       verifyContainingType(field);
/* 352 */       this.fields.setField(field, value);
/* 353 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder clearField(Descriptors.FieldDescriptor field) {
/* 357 */       verifyContainingType(field);
/* 358 */       this.fields.clearField(field);
/* 359 */       return this;
/*     */     }
/*     */ 
/*     */     public int getRepeatedFieldCount(Descriptors.FieldDescriptor field) {
/* 363 */       verifyContainingType(field);
/* 364 */       return this.fields.getRepeatedFieldCount(field);
/*     */     }
/*     */ 
/*     */     public Object getRepeatedField(Descriptors.FieldDescriptor field, int index) {
/* 368 */       verifyContainingType(field);
/* 369 */       return this.fields.getRepeatedField(field, index);
/*     */     }
/*     */ 
/*     */     public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
/*     */     {
/* 374 */       verifyContainingType(field);
/* 375 */       this.fields.setRepeatedField(field, index, value);
/* 376 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value) {
/* 380 */       verifyContainingType(field);
/* 381 */       this.fields.addRepeatedField(field, value);
/* 382 */       return this;
/*     */     }
/*     */ 
/*     */     public UnknownFieldSet getUnknownFields() {
/* 386 */       return this.unknownFields;
/*     */     }
/*     */ 
/*     */     public Builder setUnknownFields(UnknownFieldSet unknownFields) {
/* 390 */       this.unknownFields = unknownFields;
/* 391 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder mergeUnknownFields(UnknownFieldSet unknownFields) {
/* 395 */       this.unknownFields = UnknownFieldSet.newBuilder(this.unknownFields).mergeFrom(unknownFields).build();
/*     */ 
/* 399 */       return this;
/*     */     }
/*     */ 
/*     */     private void verifyContainingType(Descriptors.FieldDescriptor field)
/*     */     {
/* 404 */       if (field.getContainingType() != this.type)
/* 405 */         throw new IllegalArgumentException("FieldDescriptor does not match message type.");
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.DynamicMessage
 * JD-Core Version:    0.6.0
 */