/*      */ package com.google.appengine.api.blobstore;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import com.google.apphosting.api.ApiBasePb.VoidProto;
/*      */ import com.google.net.rpc.DefaultStubCreationFilter;
/*      */ import com.google.net.rpc.RPC;
/*      */ import com.google.net.rpc.RpcCallback;
/*      */ import com.google.net.rpc.RpcCancelCallback;
/*      */ import com.google.net.rpc.RpcException;
/*      */ import com.google.net.rpc.RpcInterface;
/*      */ import com.google.net.rpc.RpcServerParameters;
/*      */ import com.google.net.rpc.RpcService;
/*      */ import com.google.net.rpc.RpcStub;
/*      */ import com.google.net.rpc.RpcStubFactory;
/*      */ import com.google.net.rpc.RpcStubParameters;
/*      */ import com.google.net.rpc.StubCreationFilter;
/*      */ import com.google.net.rpc.impl.ApplicationHandler;
/*      */ import com.google.net.rpc.impl.BlockingApplicationHandler;
/*      */ import com.google.net.rpc.impl.RpcHandlerRegistry;
/*      */ import com.google.net.rpc.impl.RpcServerConfig;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1CompatibilityStub;
/*      */ import com.google.net.rpc3.impl.compatibility.Rpc1HandlerRegistry;
/*      */ import com.google.net.rpc3.server.RpcServer.Builder;
/*      */ import com.google.net.ssl.SslSecurityLevel;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ public class BlobstoreServicePb
/*      */ {
/*      */   public static final class BlobstoreService
/*      */   {
/* 2561 */     private static volatile StubCreationFilter stubCreationFilter_ = new DefaultStubCreationFilter();
/*      */ 
/* 2567 */     private static final RpcStubFactory stubFactory_ = new RpcStubFactory() {
/*      */       public RpcStub newRpcStub(RpcStubParameters params) {
/* 2569 */         return new BlobstoreServicePb.BlobstoreService.SimpleStub(BlobstoreServicePb.BlobstoreService.stubCreationFilter_.filterStubParameters("BlobstoreService", params));
/*      */       }
/* 2567 */     };
/*      */ 
/*      */     public static void setStubCreationFilter(StubCreationFilter filter)
/*      */     {
/* 2564 */       stubCreationFilter_ = filter == null ? new DefaultStubCreationFilter() : filter;
/*      */     }
/*      */ 
/*      */     public static RpcStubFactory stubFactory()
/*      */     {
/* 2573 */       return stubFactory_;
/*      */     }
/*      */ 
/*      */     public static BlockingStub newBlockingStub(RpcStubParameters params)
/*      */     {
/* 2636 */       return new BlockingStub(stubCreationFilter_.filterStubParameters("BlobstoreService", params));
/*      */     }
/*      */ 
/*      */     public static Stub newStub(RpcStubParameters params)
/*      */     {
/* 2669 */       return new Stub(stubCreationFilter_.filterStubParameters("BlobstoreService", params));
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcHandlerRegistry registry)
/*      */     {
/* 2746 */       ServerConfig config = new ServerConfig();
/* 2747 */       exportServiceUsingConfig(service, registry, config);
/* 2748 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 2754 */       registry.registerHandler(config.serviceName(), "CreateUploadURL", new BlobstoreServicePb.CreateUploadURLRequest(), new BlobstoreServicePb.CreateUploadURLResponse(), null, config.CreateUploadURL_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 2758 */           this.val$service.createUploadURL(rpc, (BlobstoreServicePb.CreateUploadURLRequest)rpc.internalRequest(), (BlobstoreServicePb.CreateUploadURLResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 2762 */       registry.registerHandler(config.serviceName(), "DeleteBlob", new BlobstoreServicePb.DeleteBlobRequest(), new ApiBasePb.VoidProto(), null, config.DeleteBlob_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 2766 */           this.val$service.deleteBlob(rpc, (BlobstoreServicePb.DeleteBlobRequest)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 2770 */       registry.registerHandler(config.serviceName(), "FetchData", new BlobstoreServicePb.FetchDataRequest(), new BlobstoreServicePb.FetchDataResponse(), null, config.FetchData_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 2774 */           this.val$service.fetchData(rpc, (BlobstoreServicePb.FetchDataRequest)rpc.internalRequest(), (BlobstoreServicePb.FetchDataResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/* 2778 */       registry.registerHandler(config.serviceName(), "DecodeBlobKey", new BlobstoreServicePb.DecodeBlobKeyRequest(), new BlobstoreServicePb.DecodeBlobKeyResponse(), null, config.DecodeBlobKey_parameters_, new ApplicationHandler(service)
/*      */       {
/*      */         public void handleRequest(RPC rpc)
/*      */         {
/* 2782 */           this.val$service.decodeBlobKey(rpc, (BlobstoreServicePb.DecodeBlobKeyRequest)rpc.internalRequest(), (BlobstoreServicePb.DecodeBlobKeyResponse)rpc.internalResponse(), rpc.internalCallback());
/*      */         }
/*      */       });
/*      */     }
/*      */ 
/*      */     public static RpcService newService(Interface impl) {
/* 2789 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 2791 */           return BlobstoreServicePb.BlobstoreService.exportService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportService(Interface service, RpcServer.Builder builder) {
/* 2798 */       ServerConfig config = new ServerConfig();
/* 2799 */       exportServiceUsingConfig(service, builder, config);
/* 2800 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportServiceUsingConfig(Interface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 2806 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 2807 */       exportServiceUsingConfig(service, registry, config);
/* 2808 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcHandlerRegistry registry)
/*      */     {
/* 2813 */       ServerConfig config = new ServerConfig();
/* 2814 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 2815 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcHandlerRegistry registry, ServerConfig config)
/*      */     {
/* 2821 */       registry.registerHandler(config.serviceName(), "CreateUploadURL", new BlobstoreServicePb.CreateUploadURLRequest(), new BlobstoreServicePb.CreateUploadURLResponse(), null, config.CreateUploadURL_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public BlobstoreServicePb.CreateUploadURLResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 2825 */           return this.val$service.createUploadURL(rpc, (BlobstoreServicePb.CreateUploadURLRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 2828 */       registry.registerHandler(config.serviceName(), "DeleteBlob", new BlobstoreServicePb.DeleteBlobRequest(), new ApiBasePb.VoidProto(), null, config.DeleteBlob_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 2832 */           return this.val$service.deleteBlob(rpc, (BlobstoreServicePb.DeleteBlobRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 2835 */       registry.registerHandler(config.serviceName(), "FetchData", new BlobstoreServicePb.FetchDataRequest(), new BlobstoreServicePb.FetchDataResponse(), null, config.FetchData_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public BlobstoreServicePb.FetchDataResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 2839 */           return this.val$service.fetchData(rpc, (BlobstoreServicePb.FetchDataRequest)rpc.internalRequest());
/*      */         }
/*      */       });
/* 2842 */       registry.registerHandler(config.serviceName(), "DecodeBlobKey", new BlobstoreServicePb.DecodeBlobKeyRequest(), new BlobstoreServicePb.DecodeBlobKeyResponse(), null, config.DecodeBlobKey_parameters_, new BlockingApplicationHandler(service)
/*      */       {
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse handleBlockingRequest(RPC rpc) throws RpcException
/*      */         {
/* 2846 */           return this.val$service.decodeBlobKey(rpc, (BlobstoreServicePb.DecodeBlobKeyRequest)rpc.internalRequest());
/*      */         } } );
/*      */     }
/*      */ 
/*      */     public static RpcService newBlockingService(BlockingInterface impl) {
/* 2852 */       return new RpcService(impl) {
/*      */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 2854 */           return BlobstoreServicePb.BlobstoreService.exportBlockingService(this.val$impl, registry);
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcServer.Builder builder) {
/* 2861 */       ServerConfig config = new ServerConfig();
/* 2862 */       exportBlockingServiceUsingConfig(service, builder, config);
/* 2863 */       return config;
/*      */     }
/*      */ 
/*      */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcServer.Builder builder, ServerConfig config)
/*      */     {
/* 2869 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 2870 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 2871 */       builder.addService(registry);
/*      */     }
/*      */ 
/*      */     public static void unexport(RpcHandlerRegistry registry) {
/* 2875 */       registry.unregisterService("BlobstoreService");
/*      */     }
/*      */ 
/*      */     public static class ServerConfig extends RpcServerConfig
/*      */     {
/* 2673 */       final RpcServerParameters CreateUploadURL_parameters_ = new RpcServerParameters();
/* 2674 */       final RpcServerParameters DeleteBlob_parameters_ = new RpcServerParameters();
/* 2675 */       final RpcServerParameters FetchData_parameters_ = new RpcServerParameters();
/* 2676 */       final RpcServerParameters DecodeBlobKey_parameters_ = new RpcServerParameters();
/*      */ 
/*      */       public ServerConfig() {
/* 2679 */         this("BlobstoreService");
/*      */       }
/*      */       public ServerConfig(String serviceName) {
/* 2682 */         super();
/*      */       }
/*      */       public void setRpcRunner(Executor t) {
/* 2685 */         setRpcRunner_CreateUploadURL(t);
/* 2686 */         setRpcRunner_DeleteBlob(t);
/* 2687 */         setRpcRunner_FetchData(t);
/* 2688 */         setRpcRunner_DecodeBlobKey(t);
/*      */       }
/*      */ 
/*      */       public void setRpcRunner_CreateUploadURL(Executor t) {
/* 2692 */         this.CreateUploadURL_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_DeleteBlob(Executor t) {
/* 2695 */         this.DeleteBlob_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_FetchData(Executor t) {
/* 2698 */         this.FetchData_parameters_.setRpcRunner(t);
/*      */       }
/*      */       public void setRpcRunner_DecodeBlobKey(Executor t) {
/* 2701 */         this.DecodeBlobKey_parameters_.setRpcRunner(t);
/*      */       }
/*      */ 
/*      */       public void setServerLogging_CreateUploadURL(int t) {
/* 2705 */         this.CreateUploadURL_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_DeleteBlob(int t) {
/* 2708 */         this.DeleteBlob_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_FetchData(int t) {
/* 2711 */         this.FetchData_parameters_.setServerLogging(t);
/*      */       }
/*      */       public void setServerLogging_DecodeBlobKey(int t) {
/* 2714 */         this.DecodeBlobKey_parameters_.setServerLogging(t);
/*      */       }
/*      */ 
/*      */       public void setSecurityLevel_CreateUploadURL(SslSecurityLevel t) {
/* 2718 */         this.CreateUploadURL_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_DeleteBlob(SslSecurityLevel t) {
/* 2721 */         this.DeleteBlob_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_FetchData(SslSecurityLevel t) {
/* 2724 */         this.FetchData_parameters_.setSecurityLevel(t);
/*      */       }
/*      */       public void setSecurityLevel_DecodeBlobKey(SslSecurityLevel t) {
/* 2727 */         this.DecodeBlobKey_parameters_.setSecurityLevel(t);
/*      */       }
/*      */ 
/*      */       public void setRpcCancelCallback_CreateUploadURL(RpcCancelCallback t) {
/* 2731 */         this.CreateUploadURL_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_DeleteBlob(RpcCancelCallback t) {
/* 2734 */         this.DeleteBlob_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_FetchData(RpcCancelCallback t) {
/* 2737 */         this.FetchData_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */       public void setRpcCancelCallback_DecodeBlobKey(RpcCancelCallback t) {
/* 2740 */         this.DecodeBlobKey_parameters_.setRpcCancelCallback(t);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static class Stub extends BlobstoreServicePb.BlobstoreService.BlockingStub
/*      */       implements BlobstoreServicePb.BlobstoreService.Interface
/*      */     {
/*      */       Stub(RpcStubParameters params)
/*      */       {
/* 2648 */         super();
/*      */       }
/*      */       public void createUploadURL(RPC rpc, BlobstoreServicePb.CreateUploadURLRequest req, BlobstoreServicePb.CreateUploadURLResponse reply, RpcCallback cb) {
/* 2651 */         startNonBlockingRpc(rpc, this.CreateUploadURL_method_, "CreateUploadURL", req, reply, cb, this.CreateUploadURL_parameters_);
/*      */       }
/*      */ 
/*      */       public void deleteBlob(RPC rpc, BlobstoreServicePb.DeleteBlobRequest req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 2655 */         startNonBlockingRpc(rpc, this.DeleteBlob_method_, "DeleteBlob", req, reply, cb, this.DeleteBlob_parameters_);
/*      */       }
/*      */ 
/*      */       public void fetchData(RPC rpc, BlobstoreServicePb.FetchDataRequest req, BlobstoreServicePb.FetchDataResponse reply, RpcCallback cb) {
/* 2659 */         startNonBlockingRpc(rpc, this.FetchData_method_, "FetchData", req, reply, cb, this.FetchData_parameters_);
/*      */       }
/*      */ 
/*      */       public void decodeBlobKey(RPC rpc, BlobstoreServicePb.DecodeBlobKeyRequest req, BlobstoreServicePb.DecodeBlobKeyResponse reply, RpcCallback cb) {
/* 2663 */         startNonBlockingRpc(rpc, this.DecodeBlobKey_method_, "DecodeBlobKey", req, reply, cb, this.DecodeBlobKey_parameters_);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface Interface extends RpcInterface
/*      */     {
/*      */       public abstract void createUploadURL(RPC paramRPC, BlobstoreServicePb.CreateUploadURLRequest paramCreateUploadURLRequest, BlobstoreServicePb.CreateUploadURLResponse paramCreateUploadURLResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void deleteBlob(RPC paramRPC, BlobstoreServicePb.DeleteBlobRequest paramDeleteBlobRequest, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void fetchData(RPC paramRPC, BlobstoreServicePb.FetchDataRequest paramFetchDataRequest, BlobstoreServicePb.FetchDataResponse paramFetchDataResponse, RpcCallback paramRpcCallback);
/*      */ 
/*      */       public abstract void decodeBlobKey(RPC paramRPC, BlobstoreServicePb.DecodeBlobKeyRequest paramDecodeBlobKeyRequest, BlobstoreServicePb.DecodeBlobKeyResponse paramDecodeBlobKeyResponse, RpcCallback paramRpcCallback);
/*      */     }
/*      */ 
/*      */     public static class BlockingStub extends BlobstoreServicePb.BlobstoreService.BaseStub
/*      */       implements BlobstoreServicePb.BlobstoreService.BlockingInterface
/*      */     {
/*      */       BlockingStub(RpcStubParameters params)
/*      */       {
/* 2607 */         super();
/*      */       }
/*      */       public BlobstoreServicePb.CreateUploadURLResponse createUploadURL(RPC rpc, BlobstoreServicePb.CreateUploadURLRequest req) throws RpcException {
/* 2610 */         BlobstoreServicePb.CreateUploadURLResponse reply = new BlobstoreServicePb.CreateUploadURLResponse();
/* 2611 */         startBlockingRpc(rpc, this.CreateUploadURL_method_, "CreateUploadURL", req, reply, this.CreateUploadURL_parameters_);
/*      */ 
/* 2613 */         return reply;
/*      */       }
/*      */       public ApiBasePb.VoidProto deleteBlob(RPC rpc, BlobstoreServicePb.DeleteBlobRequest req) throws RpcException {
/* 2616 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 2617 */         startBlockingRpc(rpc, this.DeleteBlob_method_, "DeleteBlob", req, reply, this.DeleteBlob_parameters_);
/*      */ 
/* 2619 */         return reply;
/*      */       }
/*      */       public BlobstoreServicePb.FetchDataResponse fetchData(RPC rpc, BlobstoreServicePb.FetchDataRequest req) throws RpcException {
/* 2622 */         BlobstoreServicePb.FetchDataResponse reply = new BlobstoreServicePb.FetchDataResponse();
/* 2623 */         startBlockingRpc(rpc, this.FetchData_method_, "FetchData", req, reply, this.FetchData_parameters_);
/*      */ 
/* 2625 */         return reply;
/*      */       }
/*      */       public BlobstoreServicePb.DecodeBlobKeyResponse decodeBlobKey(RPC rpc, BlobstoreServicePb.DecodeBlobKeyRequest req) throws RpcException {
/* 2628 */         BlobstoreServicePb.DecodeBlobKeyResponse reply = new BlobstoreServicePb.DecodeBlobKeyResponse();
/* 2629 */         startBlockingRpc(rpc, this.DecodeBlobKey_method_, "DecodeBlobKey", req, reply, this.DecodeBlobKey_parameters_);
/*      */ 
/* 2631 */         return reply;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static abstract interface BlockingInterface extends RpcInterface
/*      */     {
/*      */       public abstract BlobstoreServicePb.CreateUploadURLResponse createUploadURL(RPC paramRPC, BlobstoreServicePb.CreateUploadURLRequest paramCreateUploadURLRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract ApiBasePb.VoidProto deleteBlob(RPC paramRPC, BlobstoreServicePb.DeleteBlobRequest paramDeleteBlobRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract BlobstoreServicePb.FetchDataResponse fetchData(RPC paramRPC, BlobstoreServicePb.FetchDataRequest paramFetchDataRequest)
/*      */         throws RpcException;
/*      */ 
/*      */       public abstract BlobstoreServicePb.DecodeBlobKeyResponse decodeBlobKey(RPC paramRPC, BlobstoreServicePb.DecodeBlobKeyRequest paramDecodeBlobKeyRequest)
/*      */         throws RpcException;
/*      */     }
/*      */ 
/*      */     private static class BaseStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       protected final String CreateUploadURL_method_;
/* 2589 */       protected final RPC CreateUploadURL_parameters_ = newRpcPrototype(BlobstoreServicePb.BlobstoreService.Method.CreateUploadURL);
/*      */       protected final String DeleteBlob_method_;
/* 2591 */       protected final RPC DeleteBlob_parameters_ = newRpcPrototype(BlobstoreServicePb.BlobstoreService.Method.DeleteBlob);
/*      */       protected final String FetchData_method_;
/* 2593 */       protected final RPC FetchData_parameters_ = newRpcPrototype(BlobstoreServicePb.BlobstoreService.Method.FetchData);
/*      */       protected final String DecodeBlobKey_method_;
/* 2595 */       protected final RPC DecodeBlobKey_parameters_ = newRpcPrototype(BlobstoreServicePb.BlobstoreService.Method.DecodeBlobKey);
/*      */ 
/*      */       protected BaseStub(RpcStubParameters params)
/*      */       {
/* 2581 */         super(params, BlobstoreServicePb.BlobstoreService.Method.class);
/* 2582 */         this.CreateUploadURL_method_ = makeFullMethodName("CreateUploadURL");
/* 2583 */         this.DeleteBlob_method_ = makeFullMethodName("DeleteBlob");
/* 2584 */         this.FetchData_method_ = makeFullMethodName("FetchData");
/* 2585 */         this.DecodeBlobKey_method_ = makeFullMethodName("DecodeBlobKey");
/*      */       }
/*      */     }
/*      */ 
/*      */     private static class SimpleStub extends Rpc1CompatibilityStub
/*      */     {
/*      */       public SimpleStub(RpcStubParameters params)
/*      */       {
/* 2576 */         super(params, BlobstoreServicePb.BlobstoreService.Method.class);
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Method
/*      */     {
/* 2555 */       CreateUploadURL, 
/* 2556 */       DeleteBlob, 
/* 2557 */       FetchData, 
/* 2558 */       DecodeBlobKey;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DecodeBlobKeyResponse extends ProtocolMessage<DecodeBlobKeyResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 2206 */     private List<byte[]> decoded_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final DecodeBlobKeyResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kdecoded = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int decodedSize()
/*      */     {
/* 2211 */       return this.decoded_ != null ? this.decoded_.size() : 0;
/*      */     }
/*      */     public final byte[] getDecodedAsBytes(int i) {
/* 2214 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.decoded_ != null ? this.decoded_.size() : 0)); } else throw new AssertionError();
/* 2215 */       return (byte[])this.decoded_.get(i);
/*      */     }
/*      */     public DecodeBlobKeyResponse clearDecoded() {
/* 2218 */       if (this.decoded_ != null) this.decoded_.clear();
/* 2219 */       return this;
/*      */     }
/*      */     public final String getDecoded(int i) {
/* 2222 */       return ProtocolSupport.toStringUtf8((byte[])this.decoded_.get(i));
/*      */     }
/*      */     public DecodeBlobKeyResponse setDecodedAsBytes(int i, byte[] v) {
/* 2225 */       this.decoded_.set(i, v);
/* 2226 */       return this;
/*      */     }
/*      */     public DecodeBlobKeyResponse setDecoded(int i, String v) {
/* 2229 */       if (v == null) throw new NullPointerException();
/* 2230 */       this.decoded_.set(i, ProtocolSupport.toBytesUtf8(v));
/* 2231 */       return this;
/*      */     }
/*      */     public DecodeBlobKeyResponse addDecodedAsBytes(byte[] v) {
/* 2234 */       if (this.decoded_ == null) this.decoded_ = new ArrayList(4);
/* 2235 */       this.decoded_.add(v);
/* 2236 */       return this;
/*      */     }
/*      */     public DecodeBlobKeyResponse addDecoded(String v) {
/* 2239 */       if (v == null) throw new NullPointerException();
/* 2240 */       if (this.decoded_ == null) this.decoded_ = new ArrayList(4);
/* 2241 */       this.decoded_.add(ProtocolSupport.toBytesUtf8(v));
/* 2242 */       return this;
/*      */     }
/*      */     public final Iterator<String> decodedIterator() {
/* 2245 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.decoded_);
/*      */     }
/*      */     public final List<String> decodeds() {
/* 2248 */       return ProtocolSupport.byteArrayToUnicodeList(this.decoded_);
/*      */     }
/*      */     public final Iterator<byte[]> decodedAsBytesIterator() {
/* 2251 */       return this.decoded_ == null ? ProtocolSupport.emptyIterator() : this.decoded_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> decodedsAsBytes()
/*      */     {
/* 2256 */       return ProtocolSupport.unmodifiableList(this.decoded_);
/*      */     }
/*      */     public final List<byte[]> mutableDecodedsAsBytes() {
/* 2259 */       if (this.decoded_ == null) this.decoded_ = new ArrayList(4);
/* 2260 */       return this.decoded_;
/*      */     }
/*      */     public final String getDecoded(int i, Charset cs) {
/* 2263 */       return ProtocolSupport.toString((byte[])this.decoded_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse setDecoded(int i, String v, Charset cs) {
/* 2267 */       if (v == null) throw new NullPointerException();
/* 2268 */       this.decoded_.set(i, ProtocolSupport.toBytes(v, cs));
/* 2269 */       return this;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse addDecoded(String v, Charset cs) {
/* 2273 */       if (v == null) throw new NullPointerException();
/* 2274 */       if (this.decoded_ == null) this.decoded_ = new ArrayList(4);
/* 2275 */       this.decoded_.add(ProtocolSupport.toBytes(v, cs));
/* 2276 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> decodedIterator(Charset cs) {
/* 2280 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.decoded_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> decodeds(Charset cs) {
/* 2284 */       return ProtocolSupport.byteArrayToUnicodeList(this.decoded_, cs);
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse mergeFrom(DecodeBlobKeyResponse that)
/*      */     {
/* 2291 */       assert (that != this);
/*      */ 
/* 2293 */       if ((that.decoded_ != null) && (that.decoded_.size() > 0)) {
/* 2294 */         if (this.decoded_ == null)
/* 2295 */           this.decoded_ = new ArrayList(that.decoded_);
/*      */         else {
/* 2297 */           this.decoded_.addAll(that.decoded_);
/*      */         }
/*      */       }
/*      */ 
/* 2301 */       if (that.uninterpreted != null) {
/* 2302 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 2304 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(DecodeBlobKeyResponse that) {
/* 2308 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(DecodeBlobKeyResponse that) {
/* 2312 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(DecodeBlobKeyResponse that, boolean ignoreUninterpreted) {
/* 2316 */       if (that == null) return false;
/* 2317 */       if (that == this) return true;
/* 2320 */       int n;
/* 2320 */       if ((n = this.decoded_ != null ? this.decoded_.size() : 0) != (that.decoded_ != null ? that.decoded_.size() : 0)) return false;
/* 2321 */       for (int i = 0; i < n; i++) {
/* 2322 */         if (!Arrays.equals((byte[])this.decoded_.get(i), (byte[])that.decoded_.get(i))) return false;
/*      */       }
/*      */ 
/* 2325 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 2330 */       return ((that instanceof DecodeBlobKeyResponse)) && (equals((DecodeBlobKeyResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 2334 */       int hash = 1458060640;
/*      */ 
/* 2336 */       hash *= 31;
/* 2337 */       int i = 0; for (int n = this.decoded_ != null ? this.decoded_.size() : 0; i < n; i++) {
/* 2338 */         hash = hash * 31 + Arrays.hashCode((byte[])this.decoded_.get(i));
/*      */       }
/* 2340 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 2341 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 2343 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 2347 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 2351 */       int n = 0;
/*      */       int m;
/* 2354 */       n += (m = this.decoded_ != null ? this.decoded_.size() : 0);
/* 2355 */       for (int i = 0; i < m; i++) {
/* 2356 */         n += Protocol.stringSize(((byte[])this.decoded_.get(i)).length);
/*      */       }
/*      */ 
/* 2359 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2364 */       int n = 0;
/*      */       int m;
/* 2367 */       n += 6 * (m = this.decoded_ != null ? this.decoded_.size() : 0);
/* 2368 */       for (int i = 0; i < m; i++) {
/* 2369 */         n += ((byte[])this.decoded_.get(i)).length;
/*      */       }
/*      */ 
/* 2372 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2377 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2381 */       if (this.decoded_ != null) this.decoded_.clear();
/* 2382 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse newInstance() {
/* 2386 */       return new DecodeBlobKeyResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2390 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2409 */       int i = 0; for (int m = this.decoded_ != null ? this.decoded_.size() : 0; i < m; i++) {
/* 2410 */         byte[] v = (byte[])this.decoded_.get(i);
/* 2411 */         sink.putByte(10);
/* 2412 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 2415 */       if (this.uninterpreted != null)
/* 2416 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2421 */       boolean result = true;
/*      */ 
/* 2423 */       while (source.hasRemaining()) {
/* 2424 */         int tt = source.getVarInt();
/* 2425 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2429 */           result = false;
/* 2430 */           break;
/*      */         case 10:
/* 2433 */           addDecodedAsBytes(source.getPrefixedData());
/* 2434 */           break;
/*      */         default:
/* 2436 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2441 */       return result;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse getDefaultInstanceForType()
/*      */     {
/* 2446 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final DecodeBlobKeyResponse getDefaultInstance() {
/* 2450 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse freeze()
/*      */     {
/* 2512 */       this.decoded_ = ProtocolSupport.freezeStrings(this.decoded_);
/* 2513 */       return this;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyResponse unfreeze() {
/* 2517 */       this.decoded_ = ProtocolSupport.unfreezeStrings(this.decoded_);
/* 2518 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 2522 */       return ProtocolSupport.isFrozenStrings(this.decoded_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 2525 */       if (this.uninterpreted == null) {
/* 2526 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2528 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2454 */       IMMUTABLE_DEFAULT_INSTANCE = new DecodeBlobKeyResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse clearDecoded()
/*      */         {
/* 2462 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse setDecodedAsBytes(int i, byte[] v) {
/* 2465 */           ProtocolSupport.unsupportedOperation();
/* 2466 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse setDecoded(int i, String v) {
/* 2469 */           ProtocolSupport.unsupportedOperation();
/* 2470 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse addDecodedAsBytes(byte[] v) {
/* 2473 */           ProtocolSupport.unsupportedOperation();
/* 2474 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse addDecoded(String v) {
/* 2477 */           ProtocolSupport.unsupportedOperation();
/* 2478 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse setDecoded(int i, String v, Charset cs) {
/* 2482 */           ProtocolSupport.unsupportedOperation();
/* 2483 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse addDecoded(String v, Charset cs) {
/* 2487 */           ProtocolSupport.unsupportedOperation();
/* 2488 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse mergeFrom(BlobstoreServicePb.DecodeBlobKeyResponse that) {
/* 2492 */           ProtocolSupport.unsupportedOperation();
/* 2493 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2496 */           ProtocolSupport.unsupportedOperation();
/* 2497 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse freeze() {
/* 2500 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyResponse unfreeze() {
/* 2503 */           ProtocolSupport.unsupportedOperation();
/* 2504 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2507 */           return true;
/*      */         }
/*      */       };
/* 2533 */       text = new String[2];
/*      */ 
/* 2535 */       text[0] = "ErrorCode";
/* 2536 */       text[1] = "decoded";
/*      */ 
/* 2539 */       types = new int[2];
/*      */ 
/* 2541 */       Arrays.fill(types, 6);
/* 2542 */       types[0] = 0;
/* 2543 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2394 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.DecodeBlobKeyResponse.class, "Z0apphosting/api/blobstore/blobstore_service.proto\n apphosting.DecodeBlobKeyResponse\023\032\007decoded \001(\0020\t8\003\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("decoded", "decoded", 1, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DecodeBlobKeyRequest extends ProtocolMessage<DecodeBlobKeyRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1857 */     private List<byte[]> blob_key_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final DecodeBlobKeyRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kblob_key = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int blobKeySize()
/*      */     {
/* 1862 */       return this.blob_key_ != null ? this.blob_key_.size() : 0;
/*      */     }
/*      */     public final byte[] getBlobKeyAsBytes(int i) {
/* 1865 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.blob_key_ != null ? this.blob_key_.size() : 0)); } else throw new AssertionError();
/* 1866 */       return (byte[])this.blob_key_.get(i);
/*      */     }
/*      */     public DecodeBlobKeyRequest clearBlobKey() {
/* 1869 */       if (this.blob_key_ != null) this.blob_key_.clear();
/* 1870 */       return this;
/*      */     }
/*      */     public final String getBlobKey(int i) {
/* 1873 */       return ProtocolSupport.toStringUtf8((byte[])this.blob_key_.get(i));
/*      */     }
/*      */     public DecodeBlobKeyRequest setBlobKeyAsBytes(int i, byte[] v) {
/* 1876 */       this.blob_key_.set(i, v);
/* 1877 */       return this;
/*      */     }
/*      */     public DecodeBlobKeyRequest setBlobKey(int i, String v) {
/* 1880 */       if (v == null) throw new NullPointerException();
/* 1881 */       this.blob_key_.set(i, ProtocolSupport.toBytesUtf8(v));
/* 1882 */       return this;
/*      */     }
/*      */     public DecodeBlobKeyRequest addBlobKeyAsBytes(byte[] v) {
/* 1885 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/* 1886 */       this.blob_key_.add(v);
/* 1887 */       return this;
/*      */     }
/*      */     public DecodeBlobKeyRequest addBlobKey(String v) {
/* 1890 */       if (v == null) throw new NullPointerException();
/* 1891 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/* 1892 */       this.blob_key_.add(ProtocolSupport.toBytesUtf8(v));
/* 1893 */       return this;
/*      */     }
/*      */     public final Iterator<String> blobKeyIterator() {
/* 1896 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.blob_key_);
/*      */     }
/*      */     public final List<String> blobKeys() {
/* 1899 */       return ProtocolSupport.byteArrayToUnicodeList(this.blob_key_);
/*      */     }
/*      */     public final Iterator<byte[]> blobKeyAsBytesIterator() {
/* 1902 */       return this.blob_key_ == null ? ProtocolSupport.emptyIterator() : this.blob_key_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> blobKeysAsBytes()
/*      */     {
/* 1907 */       return ProtocolSupport.unmodifiableList(this.blob_key_);
/*      */     }
/*      */     public final List<byte[]> mutableBlobKeysAsBytes() {
/* 1910 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/* 1911 */       return this.blob_key_;
/*      */     }
/*      */     public final String getBlobKey(int i, Charset cs) {
/* 1914 */       return ProtocolSupport.toString((byte[])this.blob_key_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest setBlobKey(int i, String v, Charset cs) {
/* 1918 */       if (v == null) throw new NullPointerException();
/* 1919 */       this.blob_key_.set(i, ProtocolSupport.toBytes(v, cs));
/* 1920 */       return this;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest addBlobKey(String v, Charset cs) {
/* 1924 */       if (v == null) throw new NullPointerException();
/* 1925 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/* 1926 */       this.blob_key_.add(ProtocolSupport.toBytes(v, cs));
/* 1927 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> blobKeyIterator(Charset cs) {
/* 1931 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.blob_key_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> blobKeys(Charset cs) {
/* 1935 */       return ProtocolSupport.byteArrayToUnicodeList(this.blob_key_, cs);
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest mergeFrom(DecodeBlobKeyRequest that)
/*      */     {
/* 1942 */       assert (that != this);
/*      */ 
/* 1944 */       if ((that.blob_key_ != null) && (that.blob_key_.size() > 0)) {
/* 1945 */         if (this.blob_key_ == null)
/* 1946 */           this.blob_key_ = new ArrayList(that.blob_key_);
/*      */         else {
/* 1948 */           this.blob_key_.addAll(that.blob_key_);
/*      */         }
/*      */       }
/*      */ 
/* 1952 */       if (that.uninterpreted != null) {
/* 1953 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1955 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(DecodeBlobKeyRequest that) {
/* 1959 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(DecodeBlobKeyRequest that) {
/* 1963 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(DecodeBlobKeyRequest that, boolean ignoreUninterpreted) {
/* 1967 */       if (that == null) return false;
/* 1968 */       if (that == this) return true;
/* 1971 */       int n;
/* 1971 */       if ((n = this.blob_key_ != null ? this.blob_key_.size() : 0) != (that.blob_key_ != null ? that.blob_key_.size() : 0)) return false;
/* 1972 */       for (int i = 0; i < n; i++) {
/* 1973 */         if (!Arrays.equals((byte[])this.blob_key_.get(i), (byte[])that.blob_key_.get(i))) return false;
/*      */       }
/*      */ 
/* 1976 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1981 */       return ((that instanceof DecodeBlobKeyRequest)) && (equals((DecodeBlobKeyRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1985 */       int hash = 1684786824;
/*      */ 
/* 1987 */       hash *= 31;
/* 1988 */       int i = 0; for (int n = this.blob_key_ != null ? this.blob_key_.size() : 0; i < n; i++) {
/* 1989 */         hash = hash * 31 + Arrays.hashCode((byte[])this.blob_key_.get(i));
/*      */       }
/* 1991 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1992 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1994 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1998 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 2002 */       int n = 0;
/*      */       int m;
/* 2005 */       n += (m = this.blob_key_ != null ? this.blob_key_.size() : 0);
/* 2006 */       for (int i = 0; i < m; i++) {
/* 2007 */         n += Protocol.stringSize(((byte[])this.blob_key_.get(i)).length);
/*      */       }
/*      */ 
/* 2010 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 2015 */       int n = 0;
/*      */       int m;
/* 2018 */       n += 6 * (m = this.blob_key_ != null ? this.blob_key_.size() : 0);
/* 2019 */       for (int i = 0; i < m; i++) {
/* 2020 */         n += ((byte[])this.blob_key_.get(i)).length;
/*      */       }
/*      */ 
/* 2023 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 2028 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 2032 */       if (this.blob_key_ != null) this.blob_key_.clear();
/* 2033 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest newInstance() {
/* 2037 */       return new DecodeBlobKeyRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 2041 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 2060 */       int i = 0; for (int m = this.blob_key_ != null ? this.blob_key_.size() : 0; i < m; i++) {
/* 2061 */         byte[] v = (byte[])this.blob_key_.get(i);
/* 2062 */         sink.putByte(10);
/* 2063 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 2066 */       if (this.uninterpreted != null)
/* 2067 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 2072 */       boolean result = true;
/*      */ 
/* 2074 */       while (source.hasRemaining()) {
/* 2075 */         int tt = source.getVarInt();
/* 2076 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 2080 */           result = false;
/* 2081 */           break;
/*      */         case 10:
/* 2084 */           addBlobKeyAsBytes(source.getPrefixedData());
/* 2085 */           break;
/*      */         default:
/* 2087 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2092 */       return result;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest getDefaultInstanceForType()
/*      */     {
/* 2097 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final DecodeBlobKeyRequest getDefaultInstance() {
/* 2101 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest freeze()
/*      */     {
/* 2163 */       this.blob_key_ = ProtocolSupport.freezeStrings(this.blob_key_);
/* 2164 */       return this;
/*      */     }
/*      */ 
/*      */     public DecodeBlobKeyRequest unfreeze() {
/* 2168 */       this.blob_key_ = ProtocolSupport.unfreezeStrings(this.blob_key_);
/* 2169 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 2173 */       return ProtocolSupport.isFrozenStrings(this.blob_key_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 2176 */       if (this.uninterpreted == null) {
/* 2177 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 2179 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2105 */       IMMUTABLE_DEFAULT_INSTANCE = new DecodeBlobKeyRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest clearBlobKey()
/*      */         {
/* 2113 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest setBlobKeyAsBytes(int i, byte[] v) {
/* 2116 */           ProtocolSupport.unsupportedOperation();
/* 2117 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest setBlobKey(int i, String v) {
/* 2120 */           ProtocolSupport.unsupportedOperation();
/* 2121 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest addBlobKeyAsBytes(byte[] v) {
/* 2124 */           ProtocolSupport.unsupportedOperation();
/* 2125 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest addBlobKey(String v) {
/* 2128 */           ProtocolSupport.unsupportedOperation();
/* 2129 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest setBlobKey(int i, String v, Charset cs) {
/* 2133 */           ProtocolSupport.unsupportedOperation();
/* 2134 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest addBlobKey(String v, Charset cs) {
/* 2138 */           ProtocolSupport.unsupportedOperation();
/* 2139 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest mergeFrom(BlobstoreServicePb.DecodeBlobKeyRequest that) {
/* 2143 */           ProtocolSupport.unsupportedOperation();
/* 2144 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 2147 */           ProtocolSupport.unsupportedOperation();
/* 2148 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest freeze() {
/* 2151 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DecodeBlobKeyRequest unfreeze() {
/* 2154 */           ProtocolSupport.unsupportedOperation();
/* 2155 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 2158 */           return true;
/*      */         }
/*      */       };
/* 2184 */       text = new String[2];
/*      */ 
/* 2186 */       text[0] = "ErrorCode";
/* 2187 */       text[1] = "blob_key";
/*      */ 
/* 2190 */       types = new int[2];
/*      */ 
/* 2192 */       Arrays.fill(types, 6);
/* 2193 */       types[0] = 0;
/* 2194 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 2045 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.DecodeBlobKeyRequest.class, "Z0apphosting/api/blobstore/blobstore_service.proto\n\037apphosting.DecodeBlobKeyRequest\023\032\bblob_key \001(\0020\t8\003\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("blob_key", "blob_key", 1, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FetchDataResponse extends ProtocolMessage<FetchDataResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1576 */     private byte[] data_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final FetchDataResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kdata = 1000;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getDataAsBytes()
/*      */     {
/* 1582 */       return this.data_;
/*      */     }
/*      */     public final boolean hasData() {
/* 1585 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public FetchDataResponse clearData() {
/* 1588 */       this.optional_0_ &= -2;
/* 1589 */       this.data_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1590 */       return this;
/*      */     }
/*      */     public FetchDataResponse setDataAsBytes(byte[] x) {
/* 1593 */       this.optional_0_ |= 1;
/* 1594 */       this.data_ = x;
/* 1595 */       return this;
/*      */     }
/*      */     public final String getData() {
/* 1598 */       return ProtocolSupport.toStringUtf8(this.data_);
/*      */     }
/*      */     public FetchDataResponse setData(String v) {
/* 1601 */       if (v == null) throw new NullPointerException();
/* 1602 */       this.optional_0_ |= 1;
/* 1603 */       this.data_ = ProtocolSupport.toBytesUtf8(v);
/* 1604 */       return this;
/*      */     }
/*      */     public final String getData(Charset cs) {
/* 1607 */       return ProtocolSupport.toString(this.data_, cs);
/*      */     }
/*      */     public FetchDataResponse setData(String v, Charset cs) {
/* 1610 */       if (v == null) throw new NullPointerException();
/* 1611 */       this.optional_0_ |= 1;
/* 1612 */       this.data_ = ProtocolSupport.toBytes(v, cs);
/* 1613 */       return this;
/*      */     }
/*      */ 
/*      */     public FetchDataResponse mergeFrom(FetchDataResponse that)
/*      */     {
/* 1620 */       assert (that != this);
/* 1621 */       int this_t0 = this.optional_0_;
/* 1622 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1624 */       if ((that_t0 & 0x1) != 0) {
/* 1625 */         this_t0 |= 1;
/* 1626 */         this.data_ = that.data_;
/*      */       }
/*      */ 
/* 1629 */       if (that.uninterpreted != null) {
/* 1630 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1632 */       this.optional_0_ = this_t0;
/* 1633 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(FetchDataResponse that) {
/* 1637 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(FetchDataResponse that) {
/* 1641 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(FetchDataResponse that, boolean ignoreUninterpreted) {
/* 1645 */       if (that == null) return false;
/* 1646 */       if (that == this) return true;
/* 1647 */       int this_t0 = this.optional_0_;
/* 1648 */       int that_t0 = that.optional_0_;
/* 1649 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1651 */       if (((this_t0 & 0x1) != 0) && 
/* 1652 */         (!Arrays.equals(this.data_, that.data_))) return false;
/*      */ 
/* 1655 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1660 */       return ((that instanceof FetchDataResponse)) && (equals((FetchDataResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1664 */       int hash = 1155250177;
/*      */ 
/* 1666 */       int this_t0 = this.optional_0_;
/* 1667 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.data_) : -113);
/* 1668 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1669 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1671 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1675 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1677 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1684 */       int n = 2 + Protocol.stringSize(this.data_.length);
/*      */ 
/* 1686 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1692 */       int n = 7 + this.data_.length;
/*      */ 
/* 1694 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1699 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1703 */       this.optional_0_ = 0;
/* 1704 */       this.data_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1705 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public FetchDataResponse newInstance() {
/* 1709 */       return new FetchDataResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1713 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1733 */       sink.putByte(-62);
/* 1734 */       sink.putByte(62);
/* 1735 */       sink.putPrefixedData(this.data_);
/*      */ 
/* 1737 */       if (this.uninterpreted != null)
/* 1738 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1743 */       boolean result = true;
/* 1744 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1746 */       while (source.hasRemaining()) {
/* 1747 */         int tt = source.getVarInt();
/* 1748 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1752 */           result = false;
/* 1753 */           break;
/*      */         case 8002:
/* 1756 */           this.data_ = source.getPrefixedData();
/* 1757 */           this_t0 |= 1;
/* 1758 */           break;
/*      */         default:
/* 1760 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1765 */       this.optional_0_ = this_t0;
/* 1766 */       return result;
/*      */     }
/*      */ 
/*      */     public FetchDataResponse getDefaultInstanceForType()
/*      */     {
/* 1771 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final FetchDataResponse getDefaultInstance() {
/* 1775 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public FetchDataResponse freeze()
/*      */     {
/* 1823 */       this.data_ = ProtocolSupport.freezeString(this.data_);
/* 1824 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1827 */       if (this.uninterpreted == null) {
/* 1828 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1830 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1779 */       IMMUTABLE_DEFAULT_INSTANCE = new FetchDataResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.FetchDataResponse clearData()
/*      */         {
/* 1787 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataResponse setDataAsBytes(byte[] x) {
/* 1790 */           ProtocolSupport.unsupportedOperation();
/* 1791 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataResponse setData(String v) {
/* 1794 */           ProtocolSupport.unsupportedOperation();
/* 1795 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataResponse setData(String v, Charset cs) {
/* 1798 */           ProtocolSupport.unsupportedOperation();
/* 1799 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.FetchDataResponse mergeFrom(BlobstoreServicePb.FetchDataResponse that) {
/* 1803 */           ProtocolSupport.unsupportedOperation();
/* 1804 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1807 */           ProtocolSupport.unsupportedOperation();
/* 1808 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataResponse freeze() {
/* 1811 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataResponse unfreeze() {
/* 1814 */           ProtocolSupport.unsupportedOperation();
/* 1815 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1818 */           return true;
/*      */         }
/*      */       };
/* 1835 */       text = new String[1001];
/*      */ 
/* 1837 */       text[0] = "ErrorCode";
/* 1838 */       text[1000] = "data";
/*      */ 
/* 1841 */       types = new int[1001];
/*      */ 
/* 1843 */       Arrays.fill(types, 6);
/* 1844 */       types[0] = 0;
/* 1845 */       types[1000] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1717 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.FetchDataResponse.class, "Z0apphosting/api/blobstore/blobstore_service.proto\n\034apphosting.FetchDataResponse\023\032\004data è\007(\0020\t8\002£\001ª\001\005ctype²\001\004Cord¤\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("data", "data", 1000, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class FetchDataRequest extends ProtocolMessage<FetchDataRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1176 */     private byte[] blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1177 */     private long start_index_ = 0L;
/* 1178 */     private long end_index_ = 0L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final FetchDataRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kblob_key = 1;
/*      */     public static final int kstart_index = 2;
/*      */     public static final int kend_index = 3;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getBlobKeyAsBytes()
/*      */     {
/* 1184 */       return this.blob_key_;
/*      */     }
/*      */     public final boolean hasBlobKey() {
/* 1187 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public FetchDataRequest clearBlobKey() {
/* 1190 */       this.optional_0_ &= -2;
/* 1191 */       this.blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1192 */       return this;
/*      */     }
/*      */     public FetchDataRequest setBlobKeyAsBytes(byte[] x) {
/* 1195 */       this.optional_0_ |= 1;
/* 1196 */       this.blob_key_ = x;
/* 1197 */       return this;
/*      */     }
/*      */     public final String getBlobKey() {
/* 1200 */       return ProtocolSupport.toStringUtf8(this.blob_key_);
/*      */     }
/*      */     public FetchDataRequest setBlobKey(String v) {
/* 1203 */       if (v == null) throw new NullPointerException();
/* 1204 */       this.optional_0_ |= 1;
/* 1205 */       this.blob_key_ = ProtocolSupport.toBytesUtf8(v);
/* 1206 */       return this;
/*      */     }
/*      */     public final String getBlobKey(Charset cs) {
/* 1209 */       return ProtocolSupport.toString(this.blob_key_, cs);
/*      */     }
/*      */     public FetchDataRequest setBlobKey(String v, Charset cs) {
/* 1212 */       if (v == null) throw new NullPointerException();
/* 1213 */       this.optional_0_ |= 1;
/* 1214 */       this.blob_key_ = ProtocolSupport.toBytes(v, cs);
/* 1215 */       return this;
/*      */     }
/*      */ 
/*      */     public final long getStartIndex()
/*      */     {
/* 1220 */       return this.start_index_;
/*      */     }
/*      */     public final boolean hasStartIndex() {
/* 1223 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public FetchDataRequest clearStartIndex() {
/* 1226 */       this.optional_0_ &= -3;
/* 1227 */       this.start_index_ = 0L;
/* 1228 */       return this;
/*      */     }
/*      */     public FetchDataRequest setStartIndex(long x) {
/* 1231 */       this.optional_0_ |= 2;
/* 1232 */       this.start_index_ = x;
/* 1233 */       return this;
/*      */     }
/*      */ 
/*      */     public final long getEndIndex()
/*      */     {
/* 1238 */       return this.end_index_;
/*      */     }
/*      */     public final boolean hasEndIndex() {
/* 1241 */       return (this.optional_0_ & 0x4) != 0;
/*      */     }
/*      */     public FetchDataRequest clearEndIndex() {
/* 1244 */       this.optional_0_ &= -5;
/* 1245 */       this.end_index_ = 0L;
/* 1246 */       return this;
/*      */     }
/*      */     public FetchDataRequest setEndIndex(long x) {
/* 1249 */       this.optional_0_ |= 4;
/* 1250 */       this.end_index_ = x;
/* 1251 */       return this;
/*      */     }
/*      */ 
/*      */     public FetchDataRequest mergeFrom(FetchDataRequest that)
/*      */     {
/* 1258 */       assert (that != this);
/* 1259 */       int this_t0 = this.optional_0_;
/* 1260 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1262 */       if ((that_t0 & 0x1) != 0) {
/* 1263 */         this_t0 |= 1;
/* 1264 */         this.blob_key_ = that.blob_key_;
/*      */       }
/*      */ 
/* 1267 */       if ((that_t0 & 0x2) != 0) {
/* 1268 */         this_t0 |= 2;
/* 1269 */         this.start_index_ = that.start_index_;
/*      */       }
/*      */ 
/* 1272 */       if ((that_t0 & 0x4) != 0) {
/* 1273 */         this_t0 |= 4;
/* 1274 */         this.end_index_ = that.end_index_;
/*      */       }
/*      */ 
/* 1277 */       if (that.uninterpreted != null) {
/* 1278 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1280 */       this.optional_0_ = this_t0;
/* 1281 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(FetchDataRequest that) {
/* 1285 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(FetchDataRequest that) {
/* 1289 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(FetchDataRequest that, boolean ignoreUninterpreted) {
/* 1293 */       if (that == null) return false;
/* 1294 */       if (that == this) return true;
/* 1295 */       int this_t0 = this.optional_0_;
/* 1296 */       int that_t0 = that.optional_0_;
/* 1297 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1299 */       if (((this_t0 & 0x1) != 0) && 
/* 1300 */         (!Arrays.equals(this.blob_key_, that.blob_key_))) return false;
/*      */ 
/* 1303 */       if (((this_t0 & 0x2) != 0) && 
/* 1304 */         (this.start_index_ != that.start_index_)) return false;
/*      */ 
/* 1307 */       if (((this_t0 & 0x4) != 0) && 
/* 1308 */         (this.end_index_ != that.end_index_)) return false;
/*      */ 
/* 1311 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1316 */       return ((that instanceof FetchDataRequest)) && (equals((FetchDataRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1320 */       int hash = -1195462424;
/*      */ 
/* 1322 */       int this_t0 = this.optional_0_;
/* 1323 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.blob_key_) : -113);
/*      */ 
/* 1325 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.start_index_) : -113);
/*      */ 
/* 1327 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? ProtocolSupport.hashCode(this.end_index_) : -113);
/* 1328 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1329 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1331 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1335 */       int this_t0 = this.optional_0_;
/* 1336 */       if ((this_t0 & 0x7) != 7) {
/* 1337 */         if ((this_t0 & 0x1) == 0) {
/* 1338 */           return false;
/*      */         }
/*      */ 
/* 1341 */         return (this_t0 & 0x2) != 0;
/*      */       }
/*      */ 
/* 1345 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1352 */       int n = 3 + Protocol.stringSize(this.blob_key_.length) + Protocol.varLongSize(this.start_index_) + Protocol.varLongSize(this.end_index_);
/*      */ 
/* 1356 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1364 */       int n = 28 + this.blob_key_.length;
/*      */ 
/* 1366 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1371 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1375 */       this.optional_0_ = 0;
/* 1376 */       this.blob_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1377 */       this.start_index_ = 0L;
/* 1378 */       this.end_index_ = 0L;
/* 1379 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public FetchDataRequest newInstance() {
/* 1383 */       return new FetchDataRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1387 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1413 */       sink.putByte(10);
/* 1414 */       sink.putPrefixedData(this.blob_key_);
/*      */ 
/* 1416 */       sink.putByte(16);
/* 1417 */       sink.putVarLong(this.start_index_);
/*      */ 
/* 1419 */       sink.putByte(24);
/* 1420 */       sink.putVarLong(this.end_index_);
/*      */ 
/* 1422 */       if (this.uninterpreted != null)
/* 1423 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1428 */       boolean result = true;
/* 1429 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1431 */       while (source.hasRemaining()) {
/* 1432 */         int tt = source.getVarInt();
/* 1433 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1437 */           result = false;
/* 1438 */           break;
/*      */         case 10:
/* 1441 */           this.blob_key_ = source.getPrefixedData();
/* 1442 */           this_t0 |= 1;
/* 1443 */           break;
/*      */         case 16:
/* 1446 */           this.start_index_ = source.getVarLong();
/* 1447 */           this_t0 |= 2;
/* 1448 */           break;
/*      */         case 24:
/* 1451 */           this.end_index_ = source.getVarLong();
/* 1452 */           this_t0 |= 4;
/* 1453 */           break;
/*      */         default:
/* 1455 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1460 */       this.optional_0_ = this_t0;
/* 1461 */       return result;
/*      */     }
/*      */ 
/*      */     public FetchDataRequest getDefaultInstanceForType()
/*      */     {
/* 1466 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final FetchDataRequest getDefaultInstance() {
/* 1470 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public FetchDataRequest freeze()
/*      */     {
/* 1536 */       this.blob_key_ = ProtocolSupport.freezeString(this.blob_key_);
/* 1537 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1540 */       if (this.uninterpreted == null) {
/* 1541 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1543 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1474 */       IMMUTABLE_DEFAULT_INSTANCE = new FetchDataRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.FetchDataRequest clearBlobKey()
/*      */         {
/* 1482 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest setBlobKeyAsBytes(byte[] x) {
/* 1485 */           ProtocolSupport.unsupportedOperation();
/* 1486 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest setBlobKey(String v) {
/* 1489 */           ProtocolSupport.unsupportedOperation();
/* 1490 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest setBlobKey(String v, Charset cs) {
/* 1493 */           ProtocolSupport.unsupportedOperation();
/* 1494 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.FetchDataRequest clearStartIndex()
/*      */         {
/* 1499 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest setStartIndex(long x) {
/* 1502 */           ProtocolSupport.unsupportedOperation();
/* 1503 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.FetchDataRequest clearEndIndex()
/*      */         {
/* 1508 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest setEndIndex(long x) {
/* 1511 */           ProtocolSupport.unsupportedOperation();
/* 1512 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.FetchDataRequest mergeFrom(BlobstoreServicePb.FetchDataRequest that) {
/* 1516 */           ProtocolSupport.unsupportedOperation();
/* 1517 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1520 */           ProtocolSupport.unsupportedOperation();
/* 1521 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest freeze() {
/* 1524 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.FetchDataRequest unfreeze() {
/* 1527 */           ProtocolSupport.unsupportedOperation();
/* 1528 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1531 */           return true;
/*      */         }
/*      */       };
/* 1550 */       text = new String[4];
/*      */ 
/* 1552 */       text[0] = "ErrorCode";
/* 1553 */       text[1] = "blob_key";
/* 1554 */       text[2] = "start_index";
/* 1555 */       text[3] = "end_index";
/*      */ 
/* 1558 */       types = new int[4];
/*      */ 
/* 1560 */       Arrays.fill(types, 6);
/* 1561 */       types[0] = 0;
/* 1562 */       types[1] = 2;
/* 1563 */       types[2] = 0;
/* 1564 */       types[3] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1391 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.FetchDataRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("blob_key", "blob_key", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("start_index", "start_index", 2, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("end_index", "end_index", 3, 2, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DeleteBlobRequest extends ProtocolMessage<DeleteBlobRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  827 */     private List<byte[]> blob_key_ = null;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final DeleteBlobRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kblob_key = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int blobKeySize()
/*      */     {
/*  832 */       return this.blob_key_ != null ? this.blob_key_.size() : 0;
/*      */     }
/*      */     public final byte[] getBlobKeyAsBytes(int i) {
/*  835 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.blob_key_ != null ? this.blob_key_.size() : 0)); } else throw new AssertionError();
/*  836 */       return (byte[])this.blob_key_.get(i);
/*      */     }
/*      */     public DeleteBlobRequest clearBlobKey() {
/*  839 */       if (this.blob_key_ != null) this.blob_key_.clear();
/*  840 */       return this;
/*      */     }
/*      */     public final String getBlobKey(int i) {
/*  843 */       return ProtocolSupport.toStringUtf8((byte[])this.blob_key_.get(i));
/*      */     }
/*      */     public DeleteBlobRequest setBlobKeyAsBytes(int i, byte[] v) {
/*  846 */       this.blob_key_.set(i, v);
/*  847 */       return this;
/*      */     }
/*      */     public DeleteBlobRequest setBlobKey(int i, String v) {
/*  850 */       if (v == null) throw new NullPointerException();
/*  851 */       this.blob_key_.set(i, ProtocolSupport.toBytesUtf8(v));
/*  852 */       return this;
/*      */     }
/*      */     public DeleteBlobRequest addBlobKeyAsBytes(byte[] v) {
/*  855 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/*  856 */       this.blob_key_.add(v);
/*  857 */       return this;
/*      */     }
/*      */     public DeleteBlobRequest addBlobKey(String v) {
/*  860 */       if (v == null) throw new NullPointerException();
/*  861 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/*  862 */       this.blob_key_.add(ProtocolSupport.toBytesUtf8(v));
/*  863 */       return this;
/*      */     }
/*      */     public final Iterator<String> blobKeyIterator() {
/*  866 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.blob_key_);
/*      */     }
/*      */     public final List<String> blobKeys() {
/*  869 */       return ProtocolSupport.byteArrayToUnicodeList(this.blob_key_);
/*      */     }
/*      */     public final Iterator<byte[]> blobKeyAsBytesIterator() {
/*  872 */       return this.blob_key_ == null ? ProtocolSupport.emptyIterator() : this.blob_key_.iterator();
/*      */     }
/*      */ 
/*      */     public final List<byte[]> blobKeysAsBytes()
/*      */     {
/*  877 */       return ProtocolSupport.unmodifiableList(this.blob_key_);
/*      */     }
/*      */     public final List<byte[]> mutableBlobKeysAsBytes() {
/*  880 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/*  881 */       return this.blob_key_;
/*      */     }
/*      */     public final String getBlobKey(int i, Charset cs) {
/*  884 */       return ProtocolSupport.toString((byte[])this.blob_key_.get(i), cs);
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest setBlobKey(int i, String v, Charset cs) {
/*  888 */       if (v == null) throw new NullPointerException();
/*  889 */       this.blob_key_.set(i, ProtocolSupport.toBytes(v, cs));
/*  890 */       return this;
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest addBlobKey(String v, Charset cs) {
/*  894 */       if (v == null) throw new NullPointerException();
/*  895 */       if (this.blob_key_ == null) this.blob_key_ = new ArrayList(4);
/*  896 */       this.blob_key_.add(ProtocolSupport.toBytes(v, cs));
/*  897 */       return this;
/*      */     }
/*      */ 
/*      */     public final Iterator<String> blobKeyIterator(Charset cs) {
/*  901 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.blob_key_, cs);
/*      */     }
/*      */ 
/*      */     public final List<String> blobKeys(Charset cs) {
/*  905 */       return ProtocolSupport.byteArrayToUnicodeList(this.blob_key_, cs);
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest mergeFrom(DeleteBlobRequest that)
/*      */     {
/*  912 */       assert (that != this);
/*      */ 
/*  914 */       if ((that.blob_key_ != null) && (that.blob_key_.size() > 0)) {
/*  915 */         if (this.blob_key_ == null)
/*  916 */           this.blob_key_ = new ArrayList(that.blob_key_);
/*      */         else {
/*  918 */           this.blob_key_.addAll(that.blob_key_);
/*      */         }
/*      */       }
/*      */ 
/*  922 */       if (that.uninterpreted != null) {
/*  923 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  925 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(DeleteBlobRequest that) {
/*  929 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(DeleteBlobRequest that) {
/*  933 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(DeleteBlobRequest that, boolean ignoreUninterpreted) {
/*  937 */       if (that == null) return false;
/*  938 */       if (that == this) return true;
/*  941 */       int n;
/*  941 */       if ((n = this.blob_key_ != null ? this.blob_key_.size() : 0) != (that.blob_key_ != null ? that.blob_key_.size() : 0)) return false;
/*  942 */       for (int i = 0; i < n; i++) {
/*  943 */         if (!Arrays.equals((byte[])this.blob_key_.get(i), (byte[])that.blob_key_.get(i))) return false;
/*      */       }
/*      */ 
/*  946 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  951 */       return ((that instanceof DeleteBlobRequest)) && (equals((DeleteBlobRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  955 */       int hash = -1446063869;
/*      */ 
/*  957 */       hash *= 31;
/*  958 */       int i = 0; for (int n = this.blob_key_ != null ? this.blob_key_.size() : 0; i < n; i++) {
/*  959 */         hash = hash * 31 + Arrays.hashCode((byte[])this.blob_key_.get(i));
/*      */       }
/*  961 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  962 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  964 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  968 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  972 */       int n = 0;
/*      */       int m;
/*  975 */       n += (m = this.blob_key_ != null ? this.blob_key_.size() : 0);
/*  976 */       for (int i = 0; i < m; i++) {
/*  977 */         n += Protocol.stringSize(((byte[])this.blob_key_.get(i)).length);
/*      */       }
/*      */ 
/*  980 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  985 */       int n = 0;
/*      */       int m;
/*  988 */       n += 6 * (m = this.blob_key_ != null ? this.blob_key_.size() : 0);
/*  989 */       for (int i = 0; i < m; i++) {
/*  990 */         n += ((byte[])this.blob_key_.get(i)).length;
/*      */       }
/*      */ 
/*  993 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  998 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1002 */       if (this.blob_key_ != null) this.blob_key_.clear();
/* 1003 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest newInstance() {
/* 1007 */       return new DeleteBlobRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1011 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1030 */       int i = 0; for (int m = this.blob_key_ != null ? this.blob_key_.size() : 0; i < m; i++) {
/* 1031 */         byte[] v = (byte[])this.blob_key_.get(i);
/* 1032 */         sink.putByte(10);
/* 1033 */         sink.putPrefixedData(v);
/*      */       }
/*      */ 
/* 1036 */       if (this.uninterpreted != null)
/* 1037 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1042 */       boolean result = true;
/*      */ 
/* 1044 */       while (source.hasRemaining()) {
/* 1045 */         int tt = source.getVarInt();
/* 1046 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1050 */           result = false;
/* 1051 */           break;
/*      */         case 10:
/* 1054 */           addBlobKeyAsBytes(source.getPrefixedData());
/* 1055 */           break;
/*      */         default:
/* 1057 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1062 */       return result;
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest getDefaultInstanceForType()
/*      */     {
/* 1067 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final DeleteBlobRequest getDefaultInstance() {
/* 1071 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest freeze()
/*      */     {
/* 1133 */       this.blob_key_ = ProtocolSupport.freezeStrings(this.blob_key_);
/* 1134 */       return this;
/*      */     }
/*      */ 
/*      */     public DeleteBlobRequest unfreeze() {
/* 1138 */       this.blob_key_ = ProtocolSupport.unfreezeStrings(this.blob_key_);
/* 1139 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean isFrozen() {
/* 1143 */       return ProtocolSupport.isFrozenStrings(this.blob_key_);
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1146 */       if (this.uninterpreted == null) {
/* 1147 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1149 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1075 */       IMMUTABLE_DEFAULT_INSTANCE = new DeleteBlobRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.DeleteBlobRequest clearBlobKey()
/*      */         {
/* 1083 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DeleteBlobRequest setBlobKeyAsBytes(int i, byte[] v) {
/* 1086 */           ProtocolSupport.unsupportedOperation();
/* 1087 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DeleteBlobRequest setBlobKey(int i, String v) {
/* 1090 */           ProtocolSupport.unsupportedOperation();
/* 1091 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DeleteBlobRequest addBlobKeyAsBytes(byte[] v) {
/* 1094 */           ProtocolSupport.unsupportedOperation();
/* 1095 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DeleteBlobRequest addBlobKey(String v) {
/* 1098 */           ProtocolSupport.unsupportedOperation();
/* 1099 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DeleteBlobRequest setBlobKey(int i, String v, Charset cs) {
/* 1103 */           ProtocolSupport.unsupportedOperation();
/* 1104 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DeleteBlobRequest addBlobKey(String v, Charset cs) {
/* 1108 */           ProtocolSupport.unsupportedOperation();
/* 1109 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.DeleteBlobRequest mergeFrom(BlobstoreServicePb.DeleteBlobRequest that) {
/* 1113 */           ProtocolSupport.unsupportedOperation();
/* 1114 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1117 */           ProtocolSupport.unsupportedOperation();
/* 1118 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.DeleteBlobRequest freeze() {
/* 1121 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.DeleteBlobRequest unfreeze() {
/* 1124 */           ProtocolSupport.unsupportedOperation();
/* 1125 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1128 */           return true;
/*      */         }
/*      */       };
/* 1154 */       text = new String[2];
/*      */ 
/* 1156 */       text[0] = "ErrorCode";
/* 1157 */       text[1] = "blob_key";
/*      */ 
/* 1160 */       types = new int[2];
/*      */ 
/* 1162 */       Arrays.fill(types, 6);
/* 1163 */       types[0] = 0;
/* 1164 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1015 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.DeleteBlobRequest.class, "Z0apphosting/api/blobstore/blobstore_service.proto\n\034apphosting.DeleteBlobRequest\023\032\bblob_key \001(\0020\t8\003\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("blob_key", "blob_key", 1, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateUploadURLResponse extends ProtocolMessage<CreateUploadURLResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  548 */     private byte[] url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateUploadURLResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kurl = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getUrlAsBytes()
/*      */     {
/*  554 */       return this.url_;
/*      */     }
/*      */     public final boolean hasUrl() {
/*  557 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateUploadURLResponse clearUrl() {
/*  560 */       this.optional_0_ &= -2;
/*  561 */       this.url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  562 */       return this;
/*      */     }
/*      */     public CreateUploadURLResponse setUrlAsBytes(byte[] x) {
/*  565 */       this.optional_0_ |= 1;
/*  566 */       this.url_ = x;
/*  567 */       return this;
/*      */     }
/*      */     public final String getUrl() {
/*  570 */       return ProtocolSupport.toStringUtf8(this.url_);
/*      */     }
/*      */     public CreateUploadURLResponse setUrl(String v) {
/*  573 */       if (v == null) throw new NullPointerException();
/*  574 */       this.optional_0_ |= 1;
/*  575 */       this.url_ = ProtocolSupport.toBytesUtf8(v);
/*  576 */       return this;
/*      */     }
/*      */     public final String getUrl(Charset cs) {
/*  579 */       return ProtocolSupport.toString(this.url_, cs);
/*      */     }
/*      */     public CreateUploadURLResponse setUrl(String v, Charset cs) {
/*  582 */       if (v == null) throw new NullPointerException();
/*  583 */       this.optional_0_ |= 1;
/*  584 */       this.url_ = ProtocolSupport.toBytes(v, cs);
/*  585 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLResponse mergeFrom(CreateUploadURLResponse that)
/*      */     {
/*  592 */       assert (that != this);
/*  593 */       int this_t0 = this.optional_0_;
/*  594 */       int that_t0 = that.optional_0_;
/*      */ 
/*  596 */       if ((that_t0 & 0x1) != 0) {
/*  597 */         this_t0 |= 1;
/*  598 */         this.url_ = that.url_;
/*      */       }
/*      */ 
/*  601 */       if (that.uninterpreted != null) {
/*  602 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  604 */       this.optional_0_ = this_t0;
/*  605 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateUploadURLResponse that) {
/*  609 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateUploadURLResponse that) {
/*  613 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateUploadURLResponse that, boolean ignoreUninterpreted) {
/*  617 */       if (that == null) return false;
/*  618 */       if (that == this) return true;
/*  619 */       int this_t0 = this.optional_0_;
/*  620 */       int that_t0 = that.optional_0_;
/*  621 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  623 */       if (((this_t0 & 0x1) != 0) && 
/*  624 */         (!Arrays.equals(this.url_, that.url_))) return false;
/*      */ 
/*  627 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  632 */       return ((that instanceof CreateUploadURLResponse)) && (equals((CreateUploadURLResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  636 */       int hash = -1494753975;
/*      */ 
/*  638 */       int this_t0 = this.optional_0_;
/*  639 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.url_) : -113);
/*  640 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  641 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  643 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  647 */       int this_t0 = this.optional_0_;
/*      */ 
/*  649 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  656 */       int n = 1 + Protocol.stringSize(this.url_.length);
/*      */ 
/*  658 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  664 */       int n = 6 + this.url_.length;
/*      */ 
/*  666 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  671 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  675 */       this.optional_0_ = 0;
/*  676 */       this.url_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  677 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLResponse newInstance() {
/*  681 */       return new CreateUploadURLResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  685 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  704 */       sink.putByte(10);
/*  705 */       sink.putPrefixedData(this.url_);
/*      */ 
/*  707 */       if (this.uninterpreted != null)
/*  708 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  713 */       boolean result = true;
/*  714 */       int this_t0 = this.optional_0_;
/*      */ 
/*  716 */       while (source.hasRemaining()) {
/*  717 */         int tt = source.getVarInt();
/*  718 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  722 */           result = false;
/*  723 */           break;
/*      */         case 10:
/*  726 */           this.url_ = source.getPrefixedData();
/*  727 */           this_t0 |= 1;
/*  728 */           break;
/*      */         default:
/*  730 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  735 */       this.optional_0_ = this_t0;
/*  736 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLResponse getDefaultInstanceForType()
/*      */     {
/*  741 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateUploadURLResponse getDefaultInstance() {
/*  745 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLResponse freeze()
/*      */     {
/*  793 */       this.url_ = ProtocolSupport.freezeString(this.url_);
/*  794 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  797 */       if (this.uninterpreted == null) {
/*  798 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  800 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  749 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateUploadURLResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.CreateUploadURLResponse clearUrl()
/*      */         {
/*  757 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLResponse setUrlAsBytes(byte[] x) {
/*  760 */           ProtocolSupport.unsupportedOperation();
/*  761 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLResponse setUrl(String v) {
/*  764 */           ProtocolSupport.unsupportedOperation();
/*  765 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLResponse setUrl(String v, Charset cs) {
/*  768 */           ProtocolSupport.unsupportedOperation();
/*  769 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.CreateUploadURLResponse mergeFrom(BlobstoreServicePb.CreateUploadURLResponse that) {
/*  773 */           ProtocolSupport.unsupportedOperation();
/*  774 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  777 */           ProtocolSupport.unsupportedOperation();
/*  778 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLResponse freeze() {
/*  781 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLResponse unfreeze() {
/*  784 */           ProtocolSupport.unsupportedOperation();
/*  785 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  788 */           return true;
/*      */         }
/*      */       };
/*  805 */       text = new String[2];
/*      */ 
/*  807 */       text[0] = "ErrorCode";
/*  808 */       text[1] = "url";
/*      */ 
/*  811 */       types = new int[2];
/*      */ 
/*  813 */       Arrays.fill(types, 6);
/*  814 */       types[0] = 0;
/*  815 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  689 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.CreateUploadURLResponse.class, "Z0apphosting/api/blobstore/blobstore_service.proto\n\"apphosting.CreateUploadURLResponse\023\032\003url \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("url", "url", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateUploadURLRequest extends ProtocolMessage<CreateUploadURLRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  268 */     private byte[] success_path_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateUploadURLRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int ksuccess_path = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getSuccessPathAsBytes()
/*      */     {
/*  274 */       return this.success_path_;
/*      */     }
/*      */     public final boolean hasSuccessPath() {
/*  277 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateUploadURLRequest clearSuccessPath() {
/*  280 */       this.optional_0_ &= -2;
/*  281 */       this.success_path_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  282 */       return this;
/*      */     }
/*      */     public CreateUploadURLRequest setSuccessPathAsBytes(byte[] x) {
/*  285 */       this.optional_0_ |= 1;
/*  286 */       this.success_path_ = x;
/*  287 */       return this;
/*      */     }
/*      */     public final String getSuccessPath() {
/*  290 */       return ProtocolSupport.toStringUtf8(this.success_path_);
/*      */     }
/*      */     public CreateUploadURLRequest setSuccessPath(String v) {
/*  293 */       if (v == null) throw new NullPointerException();
/*  294 */       this.optional_0_ |= 1;
/*  295 */       this.success_path_ = ProtocolSupport.toBytesUtf8(v);
/*  296 */       return this;
/*      */     }
/*      */     public final String getSuccessPath(Charset cs) {
/*  299 */       return ProtocolSupport.toString(this.success_path_, cs);
/*      */     }
/*      */     public CreateUploadURLRequest setSuccessPath(String v, Charset cs) {
/*  302 */       if (v == null) throw new NullPointerException();
/*  303 */       this.optional_0_ |= 1;
/*  304 */       this.success_path_ = ProtocolSupport.toBytes(v, cs);
/*  305 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLRequest mergeFrom(CreateUploadURLRequest that)
/*      */     {
/*  312 */       assert (that != this);
/*  313 */       int this_t0 = this.optional_0_;
/*  314 */       int that_t0 = that.optional_0_;
/*      */ 
/*  316 */       if ((that_t0 & 0x1) != 0) {
/*  317 */         this_t0 |= 1;
/*  318 */         this.success_path_ = that.success_path_;
/*      */       }
/*      */ 
/*  321 */       if (that.uninterpreted != null) {
/*  322 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  324 */       this.optional_0_ = this_t0;
/*  325 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateUploadURLRequest that) {
/*  329 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateUploadURLRequest that) {
/*  333 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateUploadURLRequest that, boolean ignoreUninterpreted) {
/*  337 */       if (that == null) return false;
/*  338 */       if (that == this) return true;
/*  339 */       int this_t0 = this.optional_0_;
/*  340 */       int that_t0 = that.optional_0_;
/*  341 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  343 */       if (((this_t0 & 0x1) != 0) && 
/*  344 */         (!Arrays.equals(this.success_path_, that.success_path_))) return false;
/*      */ 
/*  347 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  352 */       return ((that instanceof CreateUploadURLRequest)) && (equals((CreateUploadURLRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  356 */       int hash = -1914397838;
/*      */ 
/*  358 */       int this_t0 = this.optional_0_;
/*  359 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.success_path_) : -113);
/*  360 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  361 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  363 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  367 */       int this_t0 = this.optional_0_;
/*      */ 
/*  369 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  376 */       int n = 1 + Protocol.stringSize(this.success_path_.length);
/*      */ 
/*  378 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  384 */       int n = 6 + this.success_path_.length;
/*      */ 
/*  386 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  391 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  395 */       this.optional_0_ = 0;
/*  396 */       this.success_path_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  397 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLRequest newInstance() {
/*  401 */       return new CreateUploadURLRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  405 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  425 */       sink.putByte(10);
/*  426 */       sink.putPrefixedData(this.success_path_);
/*      */ 
/*  428 */       if (this.uninterpreted != null)
/*  429 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  434 */       boolean result = true;
/*  435 */       int this_t0 = this.optional_0_;
/*      */ 
/*  437 */       while (source.hasRemaining()) {
/*  438 */         int tt = source.getVarInt();
/*  439 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  443 */           result = false;
/*  444 */           break;
/*      */         case 10:
/*  447 */           this.success_path_ = source.getPrefixedData();
/*  448 */           this_t0 |= 1;
/*  449 */           break;
/*      */         default:
/*  451 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  456 */       this.optional_0_ = this_t0;
/*  457 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLRequest getDefaultInstanceForType()
/*      */     {
/*  462 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateUploadURLRequest getDefaultInstance() {
/*  466 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateUploadURLRequest freeze()
/*      */     {
/*  514 */       this.success_path_ = ProtocolSupport.freezeString(this.success_path_);
/*  515 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  518 */       if (this.uninterpreted == null) {
/*  519 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  521 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  470 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateUploadURLRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.CreateUploadURLRequest clearSuccessPath()
/*      */         {
/*  478 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLRequest setSuccessPathAsBytes(byte[] x) {
/*  481 */           ProtocolSupport.unsupportedOperation();
/*  482 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLRequest setSuccessPath(String v) {
/*  485 */           ProtocolSupport.unsupportedOperation();
/*  486 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLRequest setSuccessPath(String v, Charset cs) {
/*  489 */           ProtocolSupport.unsupportedOperation();
/*  490 */           return this;
/*      */         }
/*      */ 
/*      */         public BlobstoreServicePb.CreateUploadURLRequest mergeFrom(BlobstoreServicePb.CreateUploadURLRequest that) {
/*  494 */           ProtocolSupport.unsupportedOperation();
/*  495 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  498 */           ProtocolSupport.unsupportedOperation();
/*  499 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLRequest freeze() {
/*  502 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.CreateUploadURLRequest unfreeze() {
/*  505 */           ProtocolSupport.unsupportedOperation();
/*  506 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  509 */           return true;
/*      */         }
/*      */       };
/*  526 */       text = new String[2];
/*      */ 
/*  528 */       text[0] = "ErrorCode";
/*  529 */       text[1] = "success_path";
/*      */ 
/*  532 */       types = new int[2];
/*      */ 
/*  534 */       Arrays.fill(types, 6);
/*  535 */       types[0] = 0;
/*  536 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  409 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.CreateUploadURLRequest.class, "Z0apphosting/api/blobstore/blobstore_service.proto\n!apphosting.CreateUploadURLRequest\023\032\fsuccess_path \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("success_path", "success_path", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class BlobstoreServiceError extends ProtocolMessage<BlobstoreServiceError>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final BlobstoreServiceError IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public BlobstoreServiceError mergeFrom(BlobstoreServiceError that)
/*      */     {
/*   84 */       assert (that != this);
/*      */ 
/*   86 */       if (that.uninterpreted != null) {
/*   87 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   89 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(BlobstoreServiceError that) {
/*   93 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(BlobstoreServiceError that) {
/*   97 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(BlobstoreServiceError that, boolean ignoreUninterpreted) {
/*  101 */       if (that == null) return false;
/*  102 */       if (that == this) return true;
/*      */ 
/*  104 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  109 */       return ((that instanceof BlobstoreServiceError)) && (equals((BlobstoreServiceError)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  113 */       int hash = -562054251;
/*  114 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  115 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  117 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  121 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  125 */       int n = 0;
/*      */ 
/*  127 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  132 */       int n = 0;
/*      */ 
/*  134 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  139 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  143 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public BlobstoreServiceError newInstance() {
/*  147 */       return new BlobstoreServiceError();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  151 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  180 */       if (this.uninterpreted != null)
/*  181 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  186 */       boolean result = true;
/*      */ 
/*  188 */       while (source.hasRemaining()) {
/*  189 */         int tt = source.getVarInt();
/*  190 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  194 */           result = false;
/*  195 */           break;
/*      */         default:
/*  197 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  202 */       return result;
/*      */     }
/*      */ 
/*      */     public BlobstoreServiceError getDefaultInstanceForType()
/*      */     {
/*  207 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final BlobstoreServiceError getDefaultInstance() {
/*  211 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  241 */       if (this.uninterpreted == null) {
/*  242 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  244 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  215 */       IMMUTABLE_DEFAULT_INSTANCE = new BlobstoreServiceError()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public BlobstoreServicePb.BlobstoreServiceError mergeFrom(BlobstoreServicePb.BlobstoreServiceError that)
/*      */         {
/*  222 */           ProtocolSupport.unsupportedOperation();
/*  223 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  226 */           ProtocolSupport.unsupportedOperation();
/*  227 */           return false;
/*      */         }
/*      */         public BlobstoreServicePb.BlobstoreServiceError freeze() {
/*  230 */           return this;
/*      */         }
/*      */         public BlobstoreServicePb.BlobstoreServiceError unfreeze() {
/*  233 */           ProtocolSupport.unsupportedOperation();
/*  234 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  237 */           return true;
/*      */         }
/*      */       };
/*  248 */       text = new String[1];
/*      */ 
/*  250 */       text[0] = "ErrorCode";
/*      */ 
/*  253 */       types = new int[1];
/*      */ 
/*  255 */       Arrays.fill(types, 6);
/*  256 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  155 */       private static final ProtocolType protocolType = new ProtocolType(BlobstoreServicePb.BlobstoreServiceError.class, "", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   50 */       OK(0), 
/*   51 */       INTERNAL_ERROR(1), 
/*   52 */       URL_TOO_LONG(2), 
/*   53 */       PERMISSION_DENIED(3), 
/*   54 */       BLOB_NOT_FOUND(4), 
/*   55 */       DATA_INDEX_OUT_OF_RANGE(5), 
/*   56 */       BLOB_FETCH_SIZE_TOO_LARGE(6);
/*      */ 
/*      */       public static final ErrorCode ErrorCode_MIN;
/*      */       public static final ErrorCode ErrorCode_MAX;
/*      */       private final int value;
/*      */ 
/*   61 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   64 */         switch (value) { case 0:
/*   65 */           return OK;
/*      */         case 1:
/*   66 */           return INTERNAL_ERROR;
/*      */         case 2:
/*   67 */           return URL_TOO_LONG;
/*      */         case 3:
/*   68 */           return PERMISSION_DENIED;
/*      */         case 4:
/*   69 */           return BLOB_NOT_FOUND;
/*      */         case 5:
/*   70 */           return DATA_INDEX_OUT_OF_RANGE;
/*      */         case 6:
/*   71 */           return BLOB_FETCH_SIZE_TOO_LARGE;
/*      */         }
/*   73 */         return null;
/*      */       }
/*      */ 
/*      */       private ErrorCode(int v) {
/*   77 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   58 */         ErrorCode_MIN = OK;
/*   59 */         ErrorCode_MAX = BLOB_FETCH_SIZE_TOO_LARGE;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobstoreServicePb
 * JD-Core Version:    0.6.0
 */