/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ public class Message
/*    */ {
/*    */   private final MessageType messageType;
/*    */   private final boolean asXml;
/*    */   private final String body;
/*    */   private final String stanza;
/*    */   private final JID fromJid;
/*    */   private final JID[] recipientJids;
/*    */ 
/*    */   Message(MessageType messageType, boolean asXml, String body, String stanza, JID fromJid, JID[] recipientJids)
/*    */   {
/* 35 */     this.messageType = messageType;
/* 36 */     this.asXml = asXml;
/* 37 */     this.body = body;
/* 38 */     this.stanza = stanza;
/* 39 */     this.fromJid = fromJid;
/* 40 */     this.recipientJids = recipientJids;
/*    */   }
/*    */ 
/*    */   public MessageType getMessageType() {
/* 44 */     return this.messageType;
/*    */   }
/*    */ 
/*    */   public boolean isXml() {
/* 48 */     return this.asXml;
/*    */   }
/*    */ 
/*    */   public String getBody() {
/* 52 */     return this.body;
/*    */   }
/*    */ 
/*    */   public JID getFromJid() {
/* 56 */     return this.fromJid;
/*    */   }
/*    */ 
/*    */   public JID[] getRecipientJids() {
/* 60 */     return this.recipientJids;
/*    */   }
/*    */ 
/*    */   public String getStanza()
/*    */   {
/* 68 */     return this.stanza;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.Message
 * JD-Core Version:    0.6.0
 */