/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Comparator;
/*    */ import java.util.SortedSet;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingSortedSet<E> extends ForwardingSet<E>
/*    */   implements SortedSet<E>
/*    */ {
/*    */   protected abstract SortedSet<E> delegate();
/*    */ 
/*    */   public Comparator<? super E> comparator()
/*    */   {
/* 43 */     return delegate().comparator();
/*    */   }
/*    */ 
/*    */   public E first() {
/* 47 */     return delegate().first();
/*    */   }
/*    */ 
/*    */   public SortedSet<E> headSet(E toElement) {
/* 51 */     return delegate().headSet(toElement);
/*    */   }
/*    */ 
/*    */   public E last() {
/* 55 */     return delegate().last();
/*    */   }
/*    */ 
/*    */   public SortedSet<E> subSet(E fromElement, E toElement) {
/* 59 */     return delegate().subSet(fromElement, toElement);
/*    */   }
/*    */ 
/*    */   public SortedSet<E> tailSet(E fromElement) {
/* 63 */     return delegate().tailSet(fromElement);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingSortedSet
 * JD-Core Version:    0.6.0
 */