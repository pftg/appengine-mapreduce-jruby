/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.flags.InvalidFlagValueException;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ 
/*     */ @Deprecated
/*     */ @GoogleInternal
/*     */ public abstract class Flag
/*     */ {
/*  84 */   private State state = State.UNUSED;
/*     */   private final String helpString;
/*     */ 
/*     */   static boolean setStateCheckingDisabled(boolean newValue)
/*     */   {
/* 475 */     String DISABLE_CHECKING = "com.google.appengine.repackaged.com.google.common.flags.disableStateChecking";
/* 476 */     boolean oldValue = Boolean.getBoolean("com.google.appengine.repackaged.com.google.common.flags.disableStateChecking");
/* 477 */     System.getProperties().setProperty("com.google.appengine.repackaged.com.google.common.flags.disableStateChecking", Boolean.toString(newValue));
/* 478 */     return oldValue;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 485 */     return "" + newFlag().get();
/*     */   }
/*     */ 
/*     */   private Flag(String helpString)
/*     */   {
/* 497 */     setState(State.UNUSED);
/* 498 */     this.helpString = Strings.nullToEmpty(helpString);
/*     */   }
/*     */ 
/*     */   private void setState(State newState) {
/* 502 */     this.state = newState;
/*     */   }
/*     */ 
/*     */   String getHelpString()
/*     */   {
/* 509 */     return this.helpString;
/*     */   }
/*     */ 
/*     */   String getTypeLabel()
/*     */   {
/* 516 */     return "unknown";
/*     */   }
/*     */ 
/*     */   abstract Class<?> getType();
/*     */ 
/*     */   boolean isBoolean()
/*     */   {
/* 526 */     return false;
/*     */   }
/*     */ 
/*     */   void setValueFromString(String value)
/*     */   {
/* 533 */     setFromString(value);
/*     */   }
/*     */ 
/*     */   String getCurrentValue()
/*     */   {
/* 541 */     return String.valueOf(newFlag().get());
/*     */   }
/*     */ 
/*     */   void checkAccessible() {
/* 545 */     if (this.state == State.REGISTERED) {
/* 546 */       String DISABLE_CHECKING = "com.google.appengine.repackaged.com.google.common.flags.disableStateChecking";
/* 547 */       if (!Boolean.getBoolean("com.google.appengine.repackaged.com.google.common.flags.disableStateChecking")) {
/* 548 */         throw new IllegalStateException("Flag is registered but not parsed");
/*     */       }
/*     */     }
/*     */ 
/* 552 */     setState(State.ACCESSED);
/*     */   }
/*     */ 
/*     */   void setRegistered()
/*     */   {
/* 564 */     switch (1.$SwitchMap$com$google$common$base$Flag$State[this.state.ordinal()]) {
/*     */     case 1:
/* 566 */       String DISABLE_CHECKING = "com.google.appengine.repackaged.com.google.common.flags.disableStateChecking";
/* 567 */       if (Boolean.getBoolean("com.google.appengine.repackaged.com.google.common.flags.disableStateChecking")) break;
/* 568 */       throw new IllegalStateException("Flag has already been registered (" + getHelpString() + ")");
/*     */     case 2:
/*     */     default:
/* 575 */       setState(State.REGISTERED);
/*     */     }
/*     */   }
/*     */ 
/*     */   void setParsed()
/*     */   {
/* 583 */     String DISABLE_CHECKING = "com.google.appengine.repackaged.com.google.common.flags.disableStateChecking";
/* 584 */     if ((this.state != State.REGISTERED) && (!Boolean.getBoolean("com.google.appengine.repackaged.com.google.common.flags.disableStateChecking"))) {
/* 585 */       throw new IllegalStateException();
/*     */     }
/* 587 */     setState(State.PARSED);
/*     */   }
/*     */ 
/*     */   public void resetState()
/*     */   {
/* 595 */     setStateCheckingDisabled(true);
/* 596 */     setState(State.UNUSED);
/*     */   }
/*     */ 
/*     */   void setFromString(String value) {
/*     */     try {
/* 601 */       newFlag().setFromString(value);
/*     */     } catch (InvalidFlagValueException ex) {
/* 603 */       throw new IllegalArgumentException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   abstract com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag();
/*     */ 
/*     */   public static final class Date extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Date> newFlag;
/*     */ 
/*     */     public Date(Date defaultValue, DateFormat dateFormat, String helpString)
/*     */     {
/* 440 */       super(null);
/* 441 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue, dateFormat);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 445 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     Class<Date> getType() {
/* 449 */       return Date.class;
/*     */     }
/*     */ 
/*     */     void setValueFromString(String value) {
/* 453 */       setFromString(value);
/*     */     }
/*     */ 
/*     */     public Date getValue() {
/* 457 */       return get();
/*     */     }
/*     */ 
/*     */     public Date get() {
/* 461 */       checkAccessible();
/* 462 */       return (Date)this.newFlag.get();
/*     */     }
/*     */ 
/*     */     protected boolean isBoolean() {
/* 466 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Class extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Class<?>> newFlag;
/*     */ 
/*     */     public Class(Class<?> defaultValue, String helpString)
/*     */     {
/* 393 */       super(null);
/* 394 */       if (defaultValue == null) {
/* 395 */         throw new NullPointerException();
/*     */       }
/* 397 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     public Class(Class defaultValue, Class assignableTo, String helpString)
/*     */     {
/* 403 */       super(null);
/* 404 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue, assignableTo);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 408 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     Class<?> getType() {
/* 412 */       return Class.class;
/*     */     }
/*     */ 
/*     */     public Class<?> get() {
/* 416 */       checkAccessible();
/* 417 */       return (Class)this.newFlag.get();
/*     */     }
/*     */ 
/*     */     public void set(Class<?> clazz) {
/* 421 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 423 */         this.newFlag.setFromString(clazz == null ? null : clazz.getName());
/*     */       } catch (InvalidFlagValueException ex) {
/* 425 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 427 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void setValueFromString(String value) {
/* 432 */       setFromString(value.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Enum<E extends Enum<E>> extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<E> newFlag;
/*     */ 
/*     */     public Enum(E defaultValue, String helpString)
/*     */     {
/* 324 */       super(null);
/* 325 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     Class<E> getType() {
/* 329 */       return ((Enum)this.newFlag.get()).getDeclaringClass();
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 333 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public E get() {
/* 337 */       checkAccessible();
/* 338 */       return (Enum)this.newFlag.get();
/*     */     }
/*     */ 
/*     */     public void set(E value) {
/* 342 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 344 */         this.newFlag.setFromString(value == null ? null : value.name());
/*     */       } catch (InvalidFlagValueException ex) {
/* 346 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 348 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void setValueFromString(String value) {
/* 353 */       setFromString(value.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Boolean extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Boolean> newFlag;
/*     */ 
/*     */     public Boolean(boolean defaultValue, String helpString)
/*     */     {
/* 275 */       super(null);
/* 276 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 280 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public boolean get() {
/* 284 */       checkAccessible();
/* 285 */       return ((Boolean)this.newFlag.get()).booleanValue();
/*     */     }
/*     */ 
/*     */     public String getTypeLabel() {
/* 289 */       return "boolean";
/*     */     }
/*     */ 
/*     */     Class<Boolean> getType() {
/* 293 */       return Boolean.TYPE;
/*     */     }
/*     */ 
/*     */     public void set(boolean value) {
/* 297 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 299 */         this.newFlag.setFromString("" + value);
/*     */       } catch (InvalidFlagValueException ex) {
/* 301 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 303 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected boolean isBoolean() {
/* 308 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class String extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<String> newFlag;
/*     */ 
/*     */     public String(String defaultValue, String helpString)
/*     */     {
/* 238 */       super(null);
/* 239 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 243 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public String get() {
/* 247 */       checkAccessible();
/* 248 */       return (String)this.newFlag.get();
/*     */     }
/*     */ 
/*     */     public String getTypeLabel() {
/* 252 */       return "string";
/*     */     }
/*     */ 
/*     */     Class<String> getType() {
/* 256 */       return String.class;
/*     */     }
/*     */ 
/*     */     public void set(String value) {
/* 260 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 262 */         this.newFlag.setFromString(value);
/*     */       } catch (InvalidFlagValueException ex) {
/* 264 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 266 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Double extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Double> newFlag;
/*     */ 
/*     */     public Double(double defaultValue, String helpString)
/*     */     {
/* 201 */       super(null);
/* 202 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 206 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public double get() {
/* 210 */       checkAccessible();
/* 211 */       return ((Double)this.newFlag.get()).doubleValue();
/*     */     }
/*     */ 
/*     */     public String getTypeLabel() {
/* 215 */       return "double";
/*     */     }
/*     */ 
/*     */     Class<Double> getType() {
/* 219 */       return Double.TYPE;
/*     */     }
/*     */ 
/*     */     public void set(double value) {
/* 223 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 225 */         this.newFlag.setFromString("" + value);
/*     */       } catch (InvalidFlagValueException ex) {
/* 227 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 229 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Float extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Float> newFlag;
/*     */ 
/*     */     public Float(float defaultValue, String helpString)
/*     */     {
/* 164 */       super(null);
/* 165 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 169 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public float get() {
/* 173 */       checkAccessible();
/* 174 */       return ((Float)this.newFlag.get()).floatValue();
/*     */     }
/*     */ 
/*     */     public String getTypeLabel() {
/* 178 */       return "float";
/*     */     }
/*     */ 
/*     */     Class<Float> getType() {
/* 182 */       return Float.TYPE;
/*     */     }
/*     */ 
/*     */     public void set(float value) {
/* 186 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 188 */         this.newFlag.setFromString("" + value);
/*     */       } catch (InvalidFlagValueException ex) {
/* 190 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 192 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Long extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Long> newFlag;
/*     */ 
/*     */     public Long(long defaultValue, String helpString)
/*     */     {
/* 127 */       super(null);
/* 128 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/* 132 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public long get() {
/* 136 */       checkAccessible();
/* 137 */       return ((Long)this.newFlag.get()).longValue();
/*     */     }
/*     */ 
/*     */     public String getTypeLabel() {
/* 141 */       return "long";
/*     */     }
/*     */ 
/*     */     Class<Long> getType() {
/* 145 */       return Long.TYPE;
/*     */     }
/*     */ 
/*     */     public void set(long value) {
/* 149 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 151 */         this.newFlag.setFromString("" + value);
/*     */       } catch (InvalidFlagValueException ex) {
/* 153 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 155 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Integer extends Flag
/*     */   {
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<Integer> newFlag;
/*     */ 
/*     */     public Integer(int defaultValue, String helpString)
/*     */     {
/*  90 */       super(null);
/*  91 */       this.newFlag = com.google.appengine.repackaged.com.google.common.flags.Flag.value(defaultValue);
/*     */     }
/*     */ 
/*     */     com.google.appengine.repackaged.com.google.common.flags.Flag<?> newFlag() {
/*  95 */       return this.newFlag;
/*     */     }
/*     */ 
/*     */     public int get() {
/*  99 */       checkAccessible();
/* 100 */       return ((Integer)this.newFlag.get()).intValue();
/*     */     }
/*     */ 
/*     */     public String getTypeLabel() {
/* 104 */       return "int";
/*     */     }
/*     */ 
/*     */     Class<Integer> getType() {
/* 108 */       return Integer.TYPE;
/*     */     }
/*     */ 
/*     */     public void set(int value) {
/* 112 */       boolean oldChecking = setStateCheckingDisabled(true);
/*     */       try {
/* 114 */         this.newFlag.setFromString("" + value);
/*     */       } catch (InvalidFlagValueException ex) {
/* 116 */         throw new IllegalArgumentException(ex);
/*     */       } finally {
/* 118 */         setStateCheckingDisabled(oldChecking);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum State
/*     */   {
/*  81 */     UNUSED, REGISTERED, PARSED, ACCESSED;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Flag
 * JD-Core Version:    0.6.0
 */