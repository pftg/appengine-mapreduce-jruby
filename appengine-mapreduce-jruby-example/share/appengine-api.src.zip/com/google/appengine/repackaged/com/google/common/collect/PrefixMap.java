package com.google.appengine.repackaged.com.google.common.collect;

import com.google.common.annotations.GoogleInternal;

@GoogleInternal
public abstract interface PrefixMap<T>
{
  public abstract T put(CharSequence paramCharSequence, T paramT);

  public abstract T get(CharSequence paramCharSequence);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.PrefixMap
 * JD-Core Version:    0.6.0
 */