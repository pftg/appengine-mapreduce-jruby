/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import java.io.IOException;
/*    */ import java.text.DateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ 
/*    */ @GoogleInternal
/*    */ public class RotatingDateLogStream extends RotatingLogStream
/*    */ {
/*    */   private Calendar lastDate_;
/*    */   private Calendar currentDate_;
/*    */ 
/*    */   public RotatingDateLogStream(String basename, String linkname, DateFormat dateFormat)
/*    */     throws IOException
/*    */   {
/* 34 */     super(basename, linkname, dateFormat);
/*    */   }
/*    */ 
/*    */   protected String getNextFilename()
/*    */   {
/* 41 */     setLastDate(new Date());
/*    */ 
/* 43 */     return super.getNextFilename();
/*    */   }
/*    */ 
/*    */   protected void checkRotate(int lenToWrite)
/*    */     throws IOException
/*    */   {
/* 62 */     setCurrentDate(new Date());
/*    */ 
/* 64 */     int curDate = this.currentDate_.get(5);
/* 65 */     int lastDate = this.lastDate_.get(5);
/*    */ 
/* 67 */     if (curDate != lastDate) {
/* 68 */       updateCombinedLogSizeForRotate(lenToWrite);
/* 69 */       rotate();
/*    */     }
/*    */ 
/* 75 */     super.checkRotate(lenToWrite);
/*    */   }
/*    */ 
/*    */   protected void setLastDate(Date date)
/*    */   {
/* 85 */     if (this.lastDate_ == null) {
/* 86 */       this.lastDate_ = Calendar.getInstance();
/*    */     }
/* 88 */     this.lastDate_.setTime(date);
/*    */   }
/*    */ 
/*    */   private void setCurrentDate(Date date)
/*    */   {
/* 96 */     if (this.currentDate_ == null) {
/* 97 */       this.currentDate_ = Calendar.getInstance();
/*    */     }
/* 99 */     this.currentDate_.setTime(date);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.RotatingDateLogStream
 * JD-Core Version:    0.6.0
 */