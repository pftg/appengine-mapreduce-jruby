/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ public final class Key
/*     */   implements Serializable, Comparable<Key>
/*     */ {
/*     */   static final long serialVersionUID = -448150158203091507L;
/*     */   static final long NOT_ASSIGNED = 0L;
/*     */   private Key parentKey;
/*     */   private String kind;
/*     */   private String appId;
/*     */   private long id;
/*     */   private String name;
/*     */   private transient AppIdNamespace appIdNamespace;
/*     */ 
/*     */   private Key()
/*     */   {
/*  68 */     this.parentKey = null;
/*  69 */     this.kind = null;
/*  70 */     this.appIdNamespace = null;
/*  71 */     this.id = 0L;
/*  72 */     this.name = null;
/*     */   }
/*     */ 
/*     */   Key(String kind) {
/*  76 */     this(kind, null, 0L);
/*     */   }
/*     */ 
/*     */   Key(String kind, String name) {
/*  80 */     this(kind, null, name);
/*     */   }
/*     */ 
/*     */   Key(String kind, Key parentKey) {
/*  84 */     this(kind, parentKey, 0L);
/*     */   }
/*     */ 
/*     */   Key(String kind, Key parentKey, long id) {
/*  88 */     this(kind, parentKey, id, null, (AppIdNamespace)null);
/*     */   }
/*     */ 
/*     */   Key(String kind, Key parentKey, String name) {
/*  92 */     this(kind, parentKey, 0L, name, (AppIdNamespace)null);
/*     */   }
/*     */ 
/*     */   Key(String kind, Key parentKey, long id, String name, AppIdNamespace appIdNamespace) {
/*  96 */     if ((kind == null) || (kind.length() == 0)) {
/*  97 */       throw new IllegalArgumentException("No kind specified.");
/*     */     }
/*     */ 
/* 102 */     if (appIdNamespace == null) {
/* 103 */       if (parentKey == null)
/* 104 */         appIdNamespace = DatastoreApiHelper.getCurrentAppIdNamespace();
/*     */       else {
/* 106 */         appIdNamespace = parentKey.getAppIdNamespace();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 113 */     validateAppIdNamespace(parentKey, appIdNamespace);
/*     */ 
/* 115 */     if (name != null) {
/* 116 */       if (name.length() == 0)
/* 117 */         throw new IllegalArgumentException("Name may not be empty.");
/* 118 */       if (id != 0L) {
/* 119 */         throw new IllegalArgumentException("Id and name may not both be specified at once.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 124 */     this.name = name;
/* 125 */     this.id = id;
/*     */ 
/* 127 */     this.parentKey = parentKey;
/*     */ 
/* 140 */     this.kind = kind.intern();
/* 141 */     this.appIdNamespace = appIdNamespace;
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 145 */     if (this.appIdNamespace != null) {
/* 146 */       this.appId = this.appIdNamespace.toEncodedString();
/*     */     }
/* 148 */     out.defaultWriteObject();
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 152 */     in.defaultReadObject();
/* 153 */     if (this.appId != null) {
/* 154 */       this.appIdNamespace = AppIdNamespace.parseEncodedAppIdNamespace(this.appId);
/* 155 */       this.appId = null;
/*     */     }
/*     */     else
/*     */     {
/* 159 */       this.appIdNamespace = new AppIdNamespace(DatastoreApiHelper.getCurrentAppId(), "");
/*     */     }
/* 161 */     validateAppIdNamespace(this.parentKey, this.appIdNamespace);
/*     */   }
/*     */ 
/*     */   private static void validateAppIdNamespace(Key parentKey, AppIdNamespace appIdNamespace) {
/* 165 */     if ((parentKey != null) && (appIdNamespace != null) && (parentKey.getAppIdNamespace() != null) && (!parentKey.getAppIdNamespace().equals(appIdNamespace)))
/*     */     {
/* 167 */       throw new IllegalArgumentException("Parent key must have same app id and namespace as child.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getKind()
/*     */   {
/* 177 */     return this.kind;
/*     */   }
/*     */ 
/*     */   public Key getParent()
/*     */   {
/* 185 */     return this.parentKey;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 190 */     int prime = 31;
/* 191 */     int result = 1;
/* 192 */     result = 31 * result + (this.appIdNamespace == null ? 0 : this.appIdNamespace.hashCode());
/* 193 */     result = 31 * result + (int)(this.id ^ this.id >>> 32);
/* 194 */     result = 31 * result + (this.kind == null ? 0 : this.kind.hashCode());
/* 195 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 196 */     result = 31 * result + (this.parentKey == null ? 0 : this.parentKey.hashCode());
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 202 */     StringBuffer buffer = new StringBuffer();
/* 203 */     appendToString(buffer);
/* 204 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   private void appendToString(StringBuffer buffer) {
/* 208 */     if (this.parentKey != null) {
/* 209 */       this.parentKey.appendToString(buffer);
/* 210 */       buffer.append("/");
/*     */     }
/* 214 */     else if (this.appIdNamespace != null) {
/* 215 */       String namespace = this.appIdNamespace.getNamespace();
/* 216 */       if (namespace.length() > 0) {
/* 217 */         buffer.append("!");
/* 218 */         buffer.append(namespace);
/* 219 */         buffer.append(":");
/*     */       }
/*     */     }
/*     */ 
/* 223 */     buffer.append(this.kind);
/* 224 */     buffer.append("(");
/* 225 */     if (this.name != null)
/* 226 */       buffer.append("\"" + this.name + "\"");
/* 227 */     else if (this.id == 0L)
/* 228 */       buffer.append("no-id-yet");
/*     */     else {
/* 230 */       buffer.append(String.valueOf(this.id));
/*     */     }
/* 232 */     buffer.append(")");
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 244 */     if ((object instanceof Key)) {
/* 245 */       Key key = (Key)object;
/* 246 */       if (this == key) {
/* 247 */         return true;
/*     */       }
/* 249 */       if (!this.appIdNamespace.equals(key.appIdNamespace)) {
/* 250 */         return false;
/*     */       }
/* 252 */       if ((this.name == null) && (this.id == 0L) && (key.id == 0L)) {
/* 253 */         return false;
/*     */       }
/* 255 */       if ((this.id != key.id) || (!this.kind.equals(key.kind)) || ((this.name != null) && (!this.name.equals(key.name))))
/*     */       {
/* 258 */         return false;
/*     */       }
/*     */ 
/* 262 */       return (this.parentKey == key.parentKey) || ((this.parentKey != null) && (this.parentKey.equals(key.parentKey)));
/*     */     }
/*     */ 
/* 266 */     return false;
/*     */   }
/*     */ 
/*     */   AppIdNamespace getAppIdNamespace()
/*     */   {
/* 274 */     return this.appIdNamespace;
/*     */   }
/*     */ 
/*     */   String getAppId()
/*     */   {
/* 281 */     return this.appIdNamespace.getAppId();
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 288 */     return this.appIdNamespace.getNamespace();
/*     */   }
/*     */ 
/*     */   public long getId()
/*     */   {
/* 295 */     return this.id;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 299 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Key getChild(String kind, long id)
/*     */   {
/* 311 */     if (!isComplete()) {
/* 312 */       throw new IllegalStateException("Cannot get a child of an incomplete key.");
/*     */     }
/* 314 */     return new Key(kind, this, id);
/*     */   }
/*     */ 
/*     */   public Key getChild(String kind, String name)
/*     */   {
/* 326 */     if (!isComplete()) {
/* 327 */       throw new IllegalStateException("Cannot get a child of an incomplete key.");
/*     */     }
/* 329 */     return new Key(kind, this, name);
/*     */   }
/*     */ 
/*     */   public boolean isComplete()
/*     */   {
/* 336 */     return (this.id != 0L) || (this.name != null);
/*     */   }
/*     */ 
/*     */   void setId(long id) {
/* 340 */     if (this.name != null) {
/* 341 */       throw new IllegalArgumentException("Cannot set id; key already has a name.");
/*     */     }
/* 343 */     this.id = id;
/*     */   }
/*     */ 
/*     */   void simulatePutForTesting(long testId) {
/* 347 */     this.id = testId;
/*     */   }
/*     */ 
/*     */   private static Iterator<Key> getPathIterator(Key key)
/*     */   {
/* 357 */     LinkedList stack = new LinkedList();
/*     */     do {
/* 359 */       stack.addFirst(key);
/* 360 */       key = key.getParent();
/* 361 */     }while (key != null);
/* 362 */     return stack.iterator();
/*     */   }
/*     */ 
/*     */   public int compareTo(Key other)
/*     */   {
/* 396 */     if (this == other) {
/* 397 */       return 0;
/*     */     }
/*     */ 
/* 404 */     Iterator thisPath = getPathIterator(this);
/* 405 */     Iterator otherPath = getPathIterator(other);
/*     */ 
/* 407 */     while (thisPath.hasNext()) {
/* 408 */       Key thisKey = (Key)thisPath.next();
/* 409 */       if (otherPath.hasNext()) {
/* 410 */         Key otherKey = (Key)otherPath.next();
/* 411 */         int result = compareToInternal(thisKey, otherKey);
/* 412 */         if (result != 0) {
/* 413 */           return result;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 418 */         return 1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 424 */     return otherPath.hasNext() ? -1 : 0;
/*     */   }
/*     */ 
/*     */   private static int compareToInternal(Key thisKey, Key otherKey)
/*     */   {
/* 439 */     if (thisKey == otherKey) {
/* 440 */       return 0;
/*     */     }
/*     */ 
/* 444 */     int result = thisKey.getAppIdNamespace().compareTo(otherKey.getAppIdNamespace());
/* 445 */     if (result != 0)
/*     */     {
/* 447 */       return result;
/*     */     }
/*     */ 
/* 451 */     result = thisKey.getKind().compareTo(otherKey.getKind());
/* 452 */     if (result != 0)
/*     */     {
/* 454 */       return result;
/*     */     }
/*     */ 
/* 457 */     if ((!thisKey.isComplete()) && (!otherKey.isComplete()))
/*     */     {
/* 462 */       return compareToWithIdentityHash(thisKey, otherKey);
/*     */     }
/*     */ 
/* 466 */     if (thisKey.getId() != 0L)
/*     */     {
/* 468 */       if (otherKey.getId() == 0L)
/*     */       {
/* 471 */         return -1;
/*     */       }
/*     */ 
/* 474 */       return Long.valueOf(thisKey.getId()).compareTo(Long.valueOf(otherKey.getId()));
/*     */     }
/*     */ 
/* 478 */     if (otherKey.getId() != 0L)
/*     */     {
/* 481 */       return 1;
/*     */     }
/*     */ 
/* 485 */     return thisKey.getName().compareTo(otherKey.getName());
/*     */   }
/*     */ 
/*     */   static int compareToWithIdentityHash(Key k1, Key k2)
/*     */   {
/* 493 */     return Integer.valueOf(System.identityHashCode(k1)).compareTo(Integer.valueOf(System.identityHashCode(k2)));
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Key
 * JD-Core Version:    0.6.0
 */