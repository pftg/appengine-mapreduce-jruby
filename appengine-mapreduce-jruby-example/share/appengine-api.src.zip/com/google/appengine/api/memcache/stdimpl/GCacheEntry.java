/*     */ package com.google.appengine.api.memcache.stdimpl;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import javax.cache.Cache;
/*     */ import javax.cache.CacheEntry;
/*     */ 
/*     */ public class GCacheEntry
/*     */   implements CacheEntry
/*     */ {
/*     */   private Object key;
/*     */   private Object value;
/*     */   private Cache cache;
/*     */ 
/*     */   GCacheEntry(Cache cache, Object key, Object value)
/*     */   {
/*  29 */     this.cache = cache;
/*  30 */     this.key = key;
/*  31 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public long getCost()
/*     */   {
/*  38 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long getCreationTime()
/*     */   {
/*  45 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long getExpirationTime()
/*     */   {
/*  52 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long getHits()
/*     */   {
/*  59 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long getLastAccessTime()
/*     */   {
/*  66 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long getLastUpdateTime()
/*     */   {
/*  73 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long getVersion()
/*     */   {
/*  80 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/*  84 */     if ((obj instanceof CacheEntry)) {
/*  85 */       CacheEntry other = (CacheEntry)obj;
/*  86 */       return (Objects.equal(this.key, other.getKey())) && (Objects.equal(this.value, other.getValue()));
/*     */     }
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/*  92 */     return Objects.hashCode(new Object[] { this.key, this.value });
/*     */   }
/*     */ 
/*     */   public boolean isValid() {
/*  96 */     return Objects.equal(this, this.cache.getCacheEntry(this.key));
/*     */   }
/*     */ 
/*     */   public Object getKey() {
/* 100 */     return this.key;
/*     */   }
/*     */ 
/*     */   public Object getValue() {
/* 104 */     return this.value;
/*     */   }
/*     */ 
/*     */   public Object setValue(Object newValue)
/*     */   {
/* 109 */     this.value = newValue;
/* 110 */     return this.cache.put(this.key, this.value);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.stdimpl.GCacheEntry
 * JD-Core Version:    0.6.0
 */