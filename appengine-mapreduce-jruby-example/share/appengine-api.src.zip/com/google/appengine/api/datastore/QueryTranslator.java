/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.DatastorePb.Query;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter.Operator;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order.Direction;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ final class QueryTranslator
/*     */ {
/*     */   public static DatastorePb.Query convertToPb(Query query, FetchOptions fetchOptions)
/*     */   {
/*  24 */     Key ancestor = query.getAncestor();
/*  25 */     List filterPredicates = query.getFilterPredicates();
/*  26 */     List sortPredicates = query.getSortPredicates();
/*     */ 
/*  28 */     DatastorePb.Query proto = new DatastorePb.Query();
/*     */ 
/*  30 */     if (query.getKind() != null) {
/*  31 */       proto.setKind(query.getKind());
/*     */     }
/*     */ 
/*  34 */     proto.setApp(query.getAppIdNamespace().getAppId());
/*  35 */     String nameSpace = query.getAppIdNamespace().getNamespace();
/*  36 */     if (nameSpace.length() != 0) {
/*  37 */       proto.setNameSpace(nameSpace);
/*     */     }
/*     */ 
/*  40 */     if (fetchOptions.getOffset() != null) {
/*  41 */       proto.setOffset(fetchOptions.getOffset().intValue());
/*     */     }
/*     */ 
/*  44 */     if (fetchOptions.getLimit() != null) {
/*  45 */       proto.setLimit(fetchOptions.getLimit().intValue());
/*     */     }
/*     */ 
/*  48 */     if (fetchOptions.getPrefetchSize() != null) {
/*  49 */       proto.setCount(fetchOptions.getPrefetchSize().intValue());
/*     */     }
/*     */ 
/*  52 */     if (fetchOptions.getStartCursor() != null) {
/*  53 */       proto.setCompiledCursor(fetchOptions.getStartCursor().convertToPb());
/*     */     }
/*     */ 
/*  56 */     if (fetchOptions.getEndCursor() != null) {
/*  57 */       proto.setEndCompiledCursor(fetchOptions.getEndCursor().convertToPb());
/*     */     }
/*     */ 
/*  60 */     if (fetchOptions.getCompile() != null) {
/*  61 */       proto.setCompile(fetchOptions.getCompile().booleanValue());
/*     */     }
/*     */ 
/*  64 */     if (ancestor != null) {
/*  65 */       OnestoreEntity.Reference ref = KeyTranslator.convertToPb(ancestor);
/*  66 */       if (!ref.getApp().equals(proto.getApp())) {
/*  67 */         throw new IllegalArgumentException("Query and ancestor appid/namespace mismatch");
/*     */       }
/*  69 */       proto.setAncestor(ref);
/*     */     }
/*     */ 
/*  72 */     proto.setKeysOnly(query.isKeysOnly());
/*     */ 
/*  74 */     for (Query.FilterPredicate filterPredicate : filterPredicates) {
/*  75 */       DatastorePb.Query.Filter filter = proto.addFilter();
/*  76 */       filter.copyFrom(convertFilterPredicateToPb(filterPredicate));
/*     */     }
/*     */ 
/*  79 */     for (Query.SortPredicate sortPredicate : sortPredicates) {
/*  80 */       DatastorePb.Query.Order order = proto.addOrder();
/*  81 */       order.copyFrom(convertSortPredicateToPb(sortPredicate));
/*     */     }
/*     */ 
/*  84 */     if (query.getFullTextSearch() != null) {
/*  85 */       proto.setSearchQuery(query.getFullTextSearch());
/*     */     }
/*     */ 
/*  88 */     return proto;
/*     */   }
/*     */ 
/*     */   static DatastorePb.Query.Order convertSortPredicateToPb(Query.SortPredicate predicate) {
/*  92 */     DatastorePb.Query.Order order = new DatastorePb.Query.Order();
/*  93 */     order.setProperty(predicate.getPropertyName());
/*  94 */     order.setDirection(getSortOp(predicate.getDirection()));
/*  95 */     return order;
/*     */   }
/*     */ 
/*     */   private static DatastorePb.Query.Order.Direction getSortOp(Query.SortDirection direction) {
/*  99 */     switch (direction) {
/*     */     case ASCENDING:
/* 101 */       return DatastorePb.Query.Order.Direction.ASCENDING;
/*     */     case DESCENDING:
/* 103 */       return DatastorePb.Query.Order.Direction.DESCENDING;
/*     */     }
/* 105 */     throw new UnsupportedOperationException("direction: " + direction);
/*     */   }
/*     */ 
/*     */   private static DatastorePb.Query.Filter convertFilterPredicateToPb(Query.FilterPredicate predicate)
/*     */   {
/* 111 */     DatastorePb.Query.Filter filter = new DatastorePb.Query.Filter();
/* 112 */     filter.setOp(getFilterOp(predicate.getOperator()));
/*     */     Iterator i$;
/* 114 */     if ((predicate.getValue() instanceof Iterable)) {
/* 115 */       if (predicate.getOperator() != Query.FilterOperator.IN) {
/* 116 */         throw new IllegalArgumentException("Only the IN operator supports multiple values");
/*     */       }
/* 118 */       for (i$ = ((Iterable)predicate.getValue()).iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 119 */         filter.addProperty(DataTypeTranslator.toProperty(predicate.getPropertyName(), value)); }
/*     */     }
/*     */     else {
/* 122 */       filter.addProperty(DataTypeTranslator.toProperty(predicate.getPropertyName(), predicate.getValue()));
/*     */     }
/*     */ 
/* 126 */     return filter;
/*     */   }
/*     */ 
/*     */   private static DatastorePb.Query.Filter.Operator getFilterOp(Query.FilterOperator operator) {
/* 130 */     switch (1.$SwitchMap$com$google$appengine$api$datastore$Query$FilterOperator[operator.ordinal()]) {
/*     */     case 1:
/* 132 */       return DatastorePb.Query.Filter.Operator.LESS_THAN;
/*     */     case 2:
/* 134 */       return DatastorePb.Query.Filter.Operator.LESS_THAN_OR_EQUAL;
/*     */     case 3:
/* 136 */       return DatastorePb.Query.Filter.Operator.GREATER_THAN;
/*     */     case 4:
/* 138 */       return DatastorePb.Query.Filter.Operator.GREATER_THAN_OR_EQUAL;
/*     */     case 5:
/* 140 */       return DatastorePb.Query.Filter.Operator.EQUAL;
/*     */     case 6:
/* 142 */       return DatastorePb.Query.Filter.Operator.IN;
/*     */     }
/* 144 */     throw new UnsupportedOperationException("operator: " + operator);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryTranslator
 * JD-Core Version:    0.6.0
 */