/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class Link
/*    */   implements Serializable, Comparable<Link>
/*    */ {
/*    */   public static final long serialVersionUID = 731239796613544443L;
/*    */   private String value;
/*    */ 
/*    */   private Link()
/*    */   {
/* 42 */     this.value = null;
/*    */   }
/*    */ 
/*    */   public Link(String value)
/*    */   {
/* 51 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 58 */     return this.value;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 63 */     return this.value.hashCode();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 72 */     if ((object instanceof Link)) {
/* 73 */       Link key = (Link)object;
/* 74 */       return this.value.equals(key.value);
/*    */     }
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 84 */     return this.value;
/*    */   }
/*    */ 
/*    */   public int compareTo(Link l) {
/* 88 */     return this.value.compareTo(l.value);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Link
 * JD-Core Version:    0.6.0
 */