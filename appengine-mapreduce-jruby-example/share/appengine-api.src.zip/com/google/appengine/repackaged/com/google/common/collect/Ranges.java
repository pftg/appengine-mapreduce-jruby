/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public final class Ranges
/*     */ {
/*  46 */   private static final RangeFactory<Comparable<?>, Range<Comparable<?>>> DEFAULT_FACTORY = new RangeFactory()
/*     */   {
/*     */     protected Range<Comparable<?>> create(Cut<Comparable<?>> lowerBound, Cut<Comparable<?>> upperBound)
/*     */     {
/*  50 */       return new Range(lowerBound, upperBound);
/*     */     }
/*  46 */   };
/*     */ 
/*  62 */   private static final DiscreteType<Integer> INTEGER_DESCRIPTOR = new DiscreteType()
/*     */   {
/*     */     public Integer next(Integer value) {
/*  65 */       int i = value.intValue();
/*  66 */       return i == 2147483647 ? null : Integer.valueOf(i + 1);
/*     */     }
/*     */ 
/*     */     public Integer previous(Integer value) {
/*  70 */       int i = value.intValue();
/*  71 */       return i == -2147483648 ? null : Integer.valueOf(i - 1);
/*     */     }
/*     */ 
/*     */     public long distance(Integer start, Integer end) {
/*  75 */       return end.intValue() - start.intValue();
/*     */     }
/*     */ 
/*     */     public Integer minValue() {
/*  79 */       return Integer.valueOf(-2147483648);
/*     */     }
/*     */ 
/*     */     public Integer maxValue() {
/*  83 */       return Integer.valueOf(2147483647);
/*     */     }
/*  62 */   };
/*     */ 
/*  88 */   private static final RangeFactory<Integer, DiscreteRange<Integer>> INTEGER_FACTORY = discreteRangeFactory(INTEGER_DESCRIPTOR);
/*     */ 
/*  98 */   private static final DiscreteType<Long> LONG_DESCRIPTOR = new DiscreteType()
/*     */   {
/*     */     public Long next(Long value) {
/* 101 */       long l = value.longValue();
/* 102 */       return l == 9223372036854775807L ? null : Long.valueOf(l + 1L);
/*     */     }
/*     */ 
/*     */     public Long previous(Long value) {
/* 106 */       long l = value.longValue();
/* 107 */       return l == -9223372036854775808L ? null : Long.valueOf(l - 1L);
/*     */     }
/*     */ 
/*     */     public long distance(Long start, Long end) {
/* 111 */       long result = end.longValue() - start.longValue();
/* 112 */       if ((end.longValue() > start.longValue()) && (result < 0L)) {
/* 113 */         return 9223372036854775807L;
/*     */       }
/* 115 */       if ((end.longValue() < start.longValue()) && (result > 0L)) {
/* 116 */         return -9223372036854775808L;
/*     */       }
/* 118 */       return result;
/*     */     }
/*     */ 
/*     */     public Long minValue() {
/* 122 */       return Long.valueOf(-9223372036854775808L);
/*     */     }
/*     */ 
/*     */     public Long maxValue() {
/* 126 */       return Long.valueOf(9223372036854775807L);
/*     */     }
/*  98 */   };
/*     */ 
/* 131 */   private static final RangeFactory<Long, DiscreteRange<Long>> LONG_FACTORY = discreteRangeFactory(LONG_DESCRIPTOR);
/*     */ 
/*     */   public static <C extends Comparable<?>> RangeFactory<C, Range<C>> factory()
/*     */   {
/*  42 */     return DEFAULT_FACTORY;
/*     */   }
/*     */ 
/*     */   public static RangeFactory<Integer, DiscreteRange<Integer>> integers()
/*     */   {
/*  59 */     return INTEGER_FACTORY;
/*     */   }
/*     */ 
/*     */   public static RangeFactory<Long, DiscreteRange<Long>> longs()
/*     */   {
/*  95 */     return LONG_FACTORY;
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   static <C extends Comparable<?>> RangeFactory<C, DiscreteRange<C>> discreteRangeFactory(DiscreteType<C> typeDescriptor)
/*     */   {
/* 136 */     return new RangeFactory(typeDescriptor)
/*     */     {
/*     */       protected DiscreteRange<C> create(Cut<C> lowerBound, Cut<C> upperBound) {
/* 139 */         return new DiscreteRange(lowerBound, upperBound, this.val$typeDescriptor);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> open(C lower, C upper)
/*     */   {
/* 155 */     RangeFactory factory = factory();
/* 156 */     return factory.open(lower, upper);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> closed(C lower, C upper)
/*     */   {
/* 168 */     RangeFactory factory = factory();
/* 169 */     return factory.closed(lower, upper);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> closedOpen(C lower, C upper)
/*     */   {
/* 182 */     RangeFactory factory = factory();
/* 183 */     return factory.closedOpen(lower, upper);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> openClosed(C lower, C upper)
/*     */   {
/* 196 */     RangeFactory factory = factory();
/* 197 */     return factory.openClosed(lower, upper);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> range(C lower, Range.BoundType lowerType, C upper, Range.BoundType upperType)
/*     */   {
/* 210 */     RangeFactory factory = factory();
/* 211 */     return factory.range(lower, lowerType, upper, upperType);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> lessThan(C endpoint)
/*     */   {
/* 219 */     RangeFactory factory = factory();
/* 220 */     return factory.lessThan(endpoint);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> greaterThan(C endpoint)
/*     */   {
/* 228 */     RangeFactory factory = factory();
/* 229 */     return factory.greaterThan(endpoint);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> atLeast(C endpoint)
/*     */   {
/* 237 */     RangeFactory factory = factory();
/* 238 */     return factory.atLeast(endpoint);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> atMost(C endpoint)
/*     */   {
/* 246 */     RangeFactory factory = factory();
/* 247 */     return factory.atMost(endpoint);
/*     */   }
/*     */ 
/*     */   public static <C extends Comparable<?>> Range<C> all()
/*     */   {
/* 255 */     RangeFactory factory = factory();
/* 256 */     return factory.all();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Ranges
 * JD-Core Version:    0.6.0
 */