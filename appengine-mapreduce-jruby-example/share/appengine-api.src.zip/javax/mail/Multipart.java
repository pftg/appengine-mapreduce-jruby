/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public abstract class Multipart
/*     */ {
/*  35 */   protected Vector parts = new Vector();
/*     */ 
/*  40 */   protected String contentType = "multipart/mixed";
/*     */   protected Part parent;
/*     */ 
/*     */   protected void setMultipartDataSource(MultipartDataSource mds)
/*     */     throws MessagingException
/*     */   {
/*  58 */     this.parts.clear();
/*  59 */     this.contentType = mds.getContentType();
/*  60 */     int size = mds.getCount();
/*  61 */     for (int i = 0; i < size; i++)
/*  62 */       this.parts.add(mds.getBodyPart(i));
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  72 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public int getCount()
/*     */     throws MessagingException
/*     */   {
/*  82 */     return this.parts.size();
/*     */   }
/*     */ 
/*     */   public BodyPart getBodyPart(int index)
/*     */     throws MessagingException
/*     */   {
/*  93 */     return (BodyPart)this.parts.get(index);
/*     */   }
/*     */ 
/*     */   public boolean removeBodyPart(BodyPart part)
/*     */     throws MessagingException
/*     */   {
/* 104 */     return this.parts.remove(part);
/*     */   }
/*     */ 
/*     */   public void removeBodyPart(int index)
/*     */     throws MessagingException
/*     */   {
/* 114 */     this.parts.remove(index);
/*     */   }
/*     */ 
/*     */   public void addBodyPart(BodyPart part)
/*     */     throws MessagingException
/*     */   {
/* 124 */     this.parts.add(part);
/*     */   }
/*     */ 
/*     */   public void addBodyPart(BodyPart part, int pos)
/*     */     throws MessagingException
/*     */   {
/* 135 */     this.parts.add(pos, part);
/*     */   }
/*     */ 
/*     */   public abstract void writeTo(OutputStream paramOutputStream)
/*     */     throws IOException, MessagingException;
/*     */ 
/*     */   public Part getParent()
/*     */   {
/* 154 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public void setParent(Part part)
/*     */   {
/* 163 */     this.parent = part;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Multipart
 * JD-Core Version:    0.6.0
 */