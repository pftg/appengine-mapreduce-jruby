/*    */ package com.google.appengine.api.urlfetch;
/*    */ 
/*    */ public enum HTTPMethod
/*    */ {
/* 12 */   GET, 
/* 13 */   POST, 
/* 14 */   HEAD, 
/* 15 */   PUT, 
/* 16 */   DELETE;
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.HTTPMethod
 * JD-Core Version:    0.6.0
 */