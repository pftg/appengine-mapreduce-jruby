/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ @Deprecated
/*     */ @GoogleInternal
/*     */ public class LogWriter
/*     */   implements Logger
/*     */ {
/*  38 */   private static final char[] LEVEL_ID = { 'D', 'I', 'X' };
/*     */   static final int defaultThreshold = 0;
/*     */   private int threshold;
/*  46 */   SimpleDateFormat dateFormatter = null;
/*     */ 
/*  48 */   Writer writer = null;
/*     */ 
/*  50 */   private Logger javaLogger = null;
/*     */ 
/* 233 */   ThreadLocal<String> threadTagMap = new ThreadLocal();
/*     */ 
/*     */   LogWriter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LogWriter(Writer writer)
/*     */   {
/*  62 */     this.writer = writer;
/*  63 */     this.dateFormatter = new SimpleDateFormat("yyMMdd HH:mm:ss.SSS");
/*  64 */     this.threshold = 0;
/*     */   }
/*     */ 
/*     */   public void setThreshold(int level)
/*     */   {
/*  73 */     if ((level < 0) || (level > 3)) {
/*  74 */       throw new RuntimeException("RotatingLog#setThreshold(int) : invalid threshold value: " + level);
/*     */     }
/*     */ 
/*  77 */     this.threshold = level;
/*  78 */     if (this.javaLogger != null)
/*  79 */       this.javaLogger.setThreshold(level);
/*     */   }
/*     */ 
/*     */   public int getThreshold()
/*     */   {
/*  88 */     return this.threshold;
/*     */   }
/*     */ 
/*     */   public void logDebug(String msg)
/*     */   {
/*  95 */     if (this.javaLogger != null)
/*  96 */       this.javaLogger.logDebug(msg);
/*     */     else
/*  98 */       write(0, msg);
/*     */   }
/*     */ 
/*     */   public void logEvent(String msg)
/*     */   {
/* 106 */     if (this.javaLogger != null)
/* 107 */       this.javaLogger.logEvent(msg);
/*     */     else
/* 109 */       write(1, msg);
/*     */   }
/*     */ 
/*     */   public void logTimedEvent(String msg, long start, long end)
/*     */   {
/* 119 */     if (this.javaLogger != null)
/* 120 */       this.javaLogger.logTimedEvent(msg, start, end);
/*     */     else
/* 122 */       write(1, end - start + " ms.: " + msg);
/*     */   }
/*     */ 
/*     */   public void setErrorEmail(String emailAddr)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void logException(Throwable t)
/*     */   {
/* 133 */     logException(t, "");
/*     */   }
/*     */ 
/*     */   public void logException(Throwable t, String msg) {
/* 137 */     if (this.javaLogger != null) {
/* 138 */       this.javaLogger.logException(t, msg);
/*     */     } else {
/* 140 */       String errorMessage = t.getMessage();
/* 141 */       if (errorMessage != null) {
/* 142 */         msg = msg + ": " + errorMessage;
/*     */       }
/* 144 */       write(2, msg + "\n" + Log2.getExceptionTrace(t));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void logSevereException(Throwable t) {
/* 149 */     logSevereException(t, "");
/*     */   }
/*     */ 
/*     */   public void logSevereException(Throwable t, String msg) {
/* 153 */     if (this.javaLogger != null) {
/* 154 */       this.javaLogger.logSevereException(t, msg);
/*     */     } else {
/* 156 */       String errorMessage = t.getMessage();
/* 157 */       if (errorMessage != null) {
/* 158 */         msg = msg + ": " + errorMessage;
/*     */       }
/* 160 */       write(2, msg + "\n" + Log2.getExceptionTrace(t));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void logError(String msg)
/*     */   {
/* 170 */     if (this.javaLogger != null) {
/* 171 */       this.javaLogger.logError(msg);
/*     */     }
/*     */     else
/* 174 */       write(2, msg + "\n" + Log2.getExceptionTrace(new LoggedError()));
/*     */   }
/*     */ 
/*     */   protected synchronized void write(int level, String msg)
/*     */   {
/* 194 */     if (level < this.threshold) return;
/*     */ 
/* 196 */     String threadTag = getThreadTag();
/* 197 */     if (threadTag == null)
/* 198 */       threadTag = "";
/*     */     else {
/* 200 */       threadTag = threadTag + " ";
/*     */     }
/*     */ 
/* 206 */     char charPrefix = LEVEL_ID[level];
/* 207 */     StringTokenizer tokenizer = new StringTokenizer(msg, "\n");
/* 208 */     StringBuffer sb = new StringBuffer(1000);
/* 209 */     while (tokenizer.hasMoreTokens()) {
/* 210 */       if (this.dateFormatter != null) {
/* 211 */         sb.append(this.dateFormatter.format(new Date()));
/* 212 */         sb.append(':');
/*     */       }
/* 214 */       sb.append(charPrefix);
/* 215 */       sb.append(' ');
/* 216 */       sb.append(threadTag);
/* 217 */       sb.append(tokenizer.nextToken());
/* 218 */       sb.append("\n");
/* 219 */       charPrefix = ' ';
/*     */     }
/*     */     try
/*     */     {
/* 223 */       this.writer.write(sb.toString());
/* 224 */       this.writer.flush();
/*     */     } catch (IOException ioE) {
/* 226 */       System.err.println("LogWriter#write(int, String) : error in writing to log!\n Exception thrown: " + ioE.getMessage() + "\nlog entry: " + msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getThreadTag()
/*     */   {
/* 236 */     if (this.javaLogger != null) {
/* 237 */       return this.javaLogger.getThreadTag();
/*     */     }
/* 239 */     return (String)this.threadTagMap.get();
/*     */   }
/*     */ 
/*     */   public void setThreadTag(String s) {
/* 243 */     if (this.javaLogger != null)
/* 244 */       this.javaLogger.setThreadTag(s);
/*     */     else
/* 246 */       this.threadTagMap.set(s);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 257 */     if (this.javaLogger != null) {
/* 258 */       this.javaLogger.close();
/* 259 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 263 */       this.writer.flush();
/* 264 */       this.writer.close();
/*     */     }
/*     */     catch (Exception ignored)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void createAndSetJavaLogger(String fileName, String linkName, String extension, DateFormat recordTsFormat, DateFormat fileNameTsFormat, long rotationSize)
/*     */   {
/* 279 */     this.javaLogger = new Log2Logger(fileName, linkName, extension, recordTsFormat, fileNameTsFormat, rotationSize);
/*     */ 
/* 281 */     this.javaLogger.setThreshold(0);
/*     */   }
/*     */ 
/*     */   static class LoggedError extends Throwable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.LogWriter
 * JD-Core Version:    0.6.0
 */