package com.google.appengine.api.datastore;

import java.util.Iterator;
import java.util.List;

public abstract interface PreparedQuery
{
  public abstract List<Entity> asList(FetchOptions paramFetchOptions);

  public abstract QueryResultList<Entity> asQueryResultList(FetchOptions paramFetchOptions);

  public abstract Iterable<Entity> asIterable(FetchOptions paramFetchOptions);

  public abstract QueryResultIterable<Entity> asQueryResultIterable(FetchOptions paramFetchOptions);

  public abstract Iterable<Entity> asIterable();

  public abstract QueryResultIterable<Entity> asQueryResultIterable();

  public abstract Iterator<Entity> asIterator(FetchOptions paramFetchOptions);

  public abstract Iterator<Entity> asIterator();

  public abstract QueryResultIterator<Entity> asQueryResultIterator(FetchOptions paramFetchOptions);

  public abstract QueryResultIterator<Entity> asQueryResultIterator();

  public abstract Entity asSingleEntity()
    throws PreparedQuery.TooManyResultsException;

  public abstract int countEntities();

  public static class TooManyResultsException extends RuntimeException
  {
  }
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.PreparedQuery
 * JD-Core Version:    0.6.0
 */