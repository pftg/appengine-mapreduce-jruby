/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.TransportEvent;
/*     */ import javax.mail.event.TransportListener;
/*     */ 
/*     */ public abstract class Transport extends Service
/*     */ {
/* 193 */   private Vector transportListeners = new Vector();
/*     */ 
/*     */   public static void send(Message message)
/*     */     throws MessagingException
/*     */   {
/*  48 */     send(message, message.getAllRecipients());
/*     */   }
/*     */ 
/*     */   public static void send(Message message, Address[] addresses)
/*     */     throws MessagingException
/*     */   {
/*  63 */     Session session = message.session;
/*  64 */     Map msgsByTransport = new HashMap();
/*  65 */     for (int i = 0; i < addresses.length; i++) {
/*  66 */       Address address = addresses[i];
/*  67 */       Transport transport = session.getTransport(address);
/*  68 */       List addrs = (List)msgsByTransport.get(transport);
/*  69 */       if (addrs == null) {
/*  70 */         addrs = new ArrayList();
/*  71 */         msgsByTransport.put(transport, addrs);
/*     */       }
/*  73 */       addrs.add(address);
/*     */     }
/*     */ 
/*  76 */     message.saveChanges();
/*     */ 
/*  82 */     MessagingException chainedException = null;
/*  83 */     ArrayList sentAddresses = new ArrayList();
/*  84 */     ArrayList unsentAddresses = new ArrayList();
/*  85 */     ArrayList invalidAddresses = new ArrayList();
/*     */ 
/*  88 */     for (Iterator i = msgsByTransport.entrySet().iterator(); i.hasNext(); ) {
/*  89 */       Map.Entry entry = (Map.Entry)i.next();
/*  90 */       Transport transport = (Transport)entry.getKey();
/*  91 */       List addrs = (List)entry.getValue();
/*     */       try
/*     */       {
/*  94 */         transport.connect();
/*  95 */         transport.sendMessage(message, (Address[])(Address[])addrs.toArray(new Address[addrs.size()]));
/*     */ 
/*  98 */         sentAddresses.addAll(addrs);
/*     */       }
/*     */       catch (SendFailedException e)
/*     */       {
/* 105 */         if (chainedException == null) {
/* 106 */           chainedException = e;
/*     */         }
/*     */         else {
/* 109 */           chainedException.setNextException(e);
/*     */         }
/*     */ 
/* 113 */         Address[] exAddrs = e.getValidSentAddresses();
/* 114 */         if (exAddrs != null) {
/* 115 */           for (int j = 0; j < exAddrs.length; j++) {
/* 116 */             sentAddresses.add(exAddrs[j]);
/*     */           }
/*     */         }
/*     */ 
/* 120 */         exAddrs = e.getValidUnsentAddresses();
/* 121 */         if (exAddrs != null) {
/* 122 */           for (int j = 0; j < exAddrs.length; j++) {
/* 123 */             unsentAddresses.add(exAddrs[j]);
/*     */           }
/*     */         }
/*     */ 
/* 127 */         exAddrs = e.getInvalidAddresses();
/* 128 */         if (exAddrs != null) {
/* 129 */           for (int j = 0; j < exAddrs.length; j++) {
/* 130 */             invalidAddresses.add(exAddrs[j]);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (MessagingException e)
/*     */       {
/* 136 */         if (chainedException == null) {
/* 137 */           chainedException = e;
/*     */         }
/*     */         else
/* 140 */           chainedException.setNextException(e);
/*     */       }
/*     */       finally
/*     */       {
/* 144 */         transport.close();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 150 */     if (chainedException != null)
/*     */     {
/* 154 */       if ((msgsByTransport.size() == 1) && ((chainedException instanceof SendFailedException))) {
/* 155 */         throw chainedException;
/*     */       }
/*     */ 
/* 159 */       Address[] sent = (Address[])(Address[])sentAddresses.toArray(new Address[0]);
/* 160 */       Address[] unsent = (Address[])(Address[])unsentAddresses.toArray(new Address[0]);
/* 161 */       Address[] invalid = (Address[])(Address[])invalidAddresses.toArray(new Address[0]);
/*     */ 
/* 163 */       throw new SendFailedException("Send failure", chainedException, sent, unsent, invalid);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Transport(Session session, URLName name)
/*     */   {
/* 174 */     super(session, name);
/*     */   }
/*     */ 
/*     */   public abstract void sendMessage(Message paramMessage, Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void addTransportListener(TransportListener listener)
/*     */   {
/* 196 */     this.transportListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeTransportListener(TransportListener listener) {
/* 200 */     this.transportListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyTransportListeners(int type, Address[] validSent, Address[] validUnsent, Address[] invalid, Message message) {
/* 204 */     queueEvent(new TransportEvent(this, type, validSent, validUnsent, invalid, message), this.transportListeners);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Transport
 * JD-Core Version:    0.6.0
 */