/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ public abstract class FinalizableWeakReference<T> extends WeakReference<T>
/*    */   implements FinalizableReference
/*    */ {
/*    */   protected FinalizableWeakReference(T referent, FinalizableReferenceQueue queue)
/*    */   {
/* 37 */     super(referent, queue.queue);
/* 38 */     queue.cleanUp();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.FinalizableWeakReference
 * JD-Core Version:    0.6.0
 */