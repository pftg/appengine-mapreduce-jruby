/*    */ package com.google.appengine.repackaged.com.google.protobuf;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ public class Internal
/*    */ {
/*    */   public static String stringDefaultValue(String bytes)
/*    */   {
/*    */     try
/*    */     {
/* 46 */       return new String(bytes.getBytes("ISO-8859-1"), "UTF-8");
/*    */     }
/*    */     catch (UnsupportedEncodingException e) {
/*    */     }
/* 50 */     throw new IllegalStateException("Java VM does not support a standard character set.", e);
/*    */   }
/*    */ 
/*    */   public static ByteString bytesDefaultValue(String bytes)
/*    */   {
/*    */     try
/*    */     {
/* 65 */       return ByteString.copyFrom(bytes.getBytes("ISO-8859-1"));
/*    */     }
/*    */     catch (UnsupportedEncodingException e) {
/*    */     }
/* 69 */     throw new IllegalStateException("Java VM does not support a standard character set.", e);
/*    */   }
/*    */ 
/*    */   public static abstract interface EnumLiteMap<T extends Internal.EnumLite>
/*    */   {
/*    */     public abstract T findValueByNumber(int paramInt);
/*    */   }
/*    */ 
/*    */   public static abstract interface EnumLite
/*    */   {
/*    */     public abstract int getNumber();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.Internal
 * JD-Core Version:    0.6.0
 */