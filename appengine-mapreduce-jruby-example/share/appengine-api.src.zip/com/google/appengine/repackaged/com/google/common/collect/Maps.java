/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Joiner;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Joiner.MapJoiner;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicate;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicates;
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.EnumMap;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GwtCompatible
/*      */ public final class Maps
/*      */ {
/* 1465 */   static final Joiner.MapJoiner standardJoiner = Collections2.standardJoiner.withKeyValueSeparator("=");
/*      */ 
/*      */   public static <K, V> HashMap<K, V> newHashMap()
/*      */   {
/*   78 */     return new HashMap();
/*      */   }
/*      */ 
/*      */   public static <K, V> HashMap<K, V> newHashMapWithExpectedSize(int expectedSize)
/*      */   {
/*   97 */     return new HashMap(capacity(expectedSize));
/*      */   }
/*      */ 
/*      */   static int capacity(int expectedSize)
/*      */   {
/*  109 */     Preconditions.checkArgument(expectedSize >= 0);
/*  110 */     return Math.max(expectedSize * 2, 16);
/*      */   }
/*      */ 
/*      */   public static <K, V> HashMap<K, V> newHashMap(Map<? extends K, ? extends V> map)
/*      */   {
/*  129 */     return new HashMap(map);
/*      */   }
/*      */ 
/*      */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMap()
/*      */   {
/*  142 */     return new LinkedHashMap();
/*      */   }
/*      */ 
/*      */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMap(Map<? extends K, ? extends V> map)
/*      */   {
/*  158 */     return new LinkedHashMap(map);
/*      */   }
/*      */ 
/*      */   public static <K, V> ConcurrentMap<K, V> newConcurrentMap()
/*      */   {
/*  177 */     return new MapMaker().makeMap();
/*      */   }
/*      */ 
/*      */   public static <K extends Comparable, V> TreeMap<K, V> newTreeMap()
/*      */   {
/*  191 */     return new TreeMap();
/*      */   }
/*      */ 
/*      */   public static <K, V> TreeMap<K, V> newTreeMap(SortedMap<K, ? extends V> map)
/*      */   {
/*  207 */     return new TreeMap(map);
/*      */   }
/*      */ 
/*      */   public static <C, K extends C, V> TreeMap<K, V> newTreeMap(@Nullable Comparator<C> comparator)
/*      */   {
/*  227 */     return new TreeMap(comparator);
/*      */   }
/*      */ 
/*      */   public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Class<K> type)
/*      */   {
/*  237 */     return new EnumMap((Class)Preconditions.checkNotNull(type));
/*      */   }
/*      */ 
/*      */   public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Map<K, ? extends V> map)
/*      */   {
/*  251 */     return new EnumMap(map);
/*      */   }
/*      */ 
/*      */   public static <K, V> IdentityHashMap<K, V> newIdentityHashMap()
/*      */   {
/*  260 */     return new IdentityHashMap();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <K, V> Map<K, V> immutableMap(@Nullable K k1, @Nullable V v1)
/*      */   {
/*  274 */     return Collections.singletonMap(k1, v1);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <K, V> Map<K, V> immutableMap(@Nullable K k1, @Nullable V v1, @Nullable K k2, @Nullable V v2)
/*      */   {
/*  292 */     return new ImmutableMapBuilder().put(k1, v1).put(k2, v2).getMap();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <K, V> Map<K, V> immutableMap(@Nullable K k1, @Nullable V v1, @Nullable K k2, @Nullable V v2, @Nullable K k3, @Nullable V v3)
/*      */   {
/*  311 */     return new ImmutableMapBuilder().put(k1, v1).put(k2, v2).put(k3, v3).getMap();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <K, V> Map<K, V> immutableMap(@Nullable K k1, @Nullable V v1, @Nullable K k2, @Nullable V v2, @Nullable K k3, @Nullable V v3, @Nullable K k4, @Nullable V v4)
/*      */   {
/*  335 */     return new ImmutableMapBuilder().put(k1, v1).put(k2, v2).put(k3, v3).put(k4, v4).getMap();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   @GoogleInternal
/*      */   public static <K, V> Map<K, V> immutableMap(@Nullable K k1, @Nullable V v1, @Nullable K k2, @Nullable V v2, @Nullable K k3, @Nullable V v3, @Nullable K k4, @Nullable V v4, @Nullable K k5, @Nullable V v5)
/*      */   {
/*  361 */     return new ImmutableMapBuilder().put(k1, v1).put(k2, v2).put(k3, v3).put(k4, v4).put(k5, v5).getMap();
/*      */   }
/*      */ 
/*      */   public static <K, V> BiMap<K, V> synchronizedBiMap(BiMap<K, V> bimap)
/*      */   {
/*  399 */     return Synchronized.biMap(bimap, null);
/*      */   }
/*      */ 
/*      */   public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right)
/*      */   {
/*  420 */     Map onlyOnLeft = newHashMap();
/*  421 */     Map onlyOnRight = new HashMap(right);
/*  422 */     Map onBoth = newHashMap();
/*  423 */     Map differences = newHashMap();
/*  424 */     boolean eq = true;
/*      */ 
/*  426 */     for (Map.Entry entry : left.entrySet()) {
/*  427 */       Object leftKey = entry.getKey();
/*  428 */       Object leftValue = entry.getValue();
/*  429 */       if (right.containsKey(leftKey)) {
/*  430 */         Object rightValue = onlyOnRight.remove(leftKey);
/*  431 */         if (Objects.equal(leftValue, rightValue)) {
/*  432 */           onBoth.put(leftKey, leftValue);
/*      */         } else {
/*  434 */           eq = false;
/*  435 */           differences.put(leftKey, new ValueDifferenceImpl(leftValue, rightValue));
/*      */         }
/*      */       }
/*      */       else {
/*  439 */         eq = false;
/*  440 */         onlyOnLeft.put(leftKey, leftValue);
/*      */       }
/*      */     }
/*      */ 
/*  444 */     boolean areEqual = (eq) && (onlyOnRight.isEmpty());
/*  445 */     return new MapDifferenceImpl(areEqual, onlyOnLeft, onlyOnRight, onBoth, differences);
/*      */   }
/*      */ 
/*      */   public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterable<V> values, Function<? super V, K> keyFunction)
/*      */   {
/*  579 */     Preconditions.checkNotNull(keyFunction);
/*  580 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/*  581 */     for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/*  582 */       builder.put(keyFunction.apply(value), value);
/*      */     }
/*  584 */     return builder.build();
/*      */   }
/*      */ 
/*      */   public static ImmutableMap<String, String> fromProperties(Properties properties)
/*      */   {
/*  602 */     ImmutableMap.Builder builder = ImmutableMap.builder();
/*      */ 
/*  604 */     for (Enumeration e = properties.propertyNames(); e.hasMoreElements(); ) {
/*  605 */       String key = (String)e.nextElement();
/*  606 */       builder.put(key, properties.getProperty(key));
/*      */     }
/*      */ 
/*  609 */     return builder.build();
/*      */   }
/*      */ 
/*      */   public static <K, V> Map.Entry<K, V> immutableEntry(@Nullable K key, @Nullable V value)
/*      */   {
/*  623 */     return new ImmutableEntry(key, value);
/*      */   }
/*      */ 
/*      */   static <K, V> Set<Map.Entry<K, V>> unmodifiableEntrySet(Set<Map.Entry<K, V>> entrySet)
/*      */   {
/*  636 */     return new UnmodifiableEntrySet(Collections.unmodifiableSet(entrySet));
/*      */   }
/*      */ 
/*      */   private static <K, V> Map.Entry<K, V> unmodifiableEntry(Map.Entry<K, V> entry)
/*      */   {
/*  650 */     Preconditions.checkNotNull(entry);
/*  651 */     return new AbstractMapEntry(entry) {
/*      */       public K getKey() {
/*  653 */         return this.val$entry.getKey();
/*      */       }
/*      */ 
/*      */       public V getValue() {
/*  657 */         return this.val$entry.getValue();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <K, V> BiMap<K, V> unmodifiableBiMap(BiMap<? extends K, ? extends V> bimap)
/*      */   {
/*  740 */     return new UnmodifiableBiMap(bimap, null);
/*      */   }
/*      */ 
/*      */   static <K, V> boolean containsEntryImpl(Collection<Map.Entry<K, V>> c, Object o)
/*      */   {
/*  797 */     if (!(o instanceof Map.Entry)) {
/*  798 */       return false;
/*      */     }
/*  800 */     return c.contains(unmodifiableEntry((Map.Entry)o));
/*      */   }
/*      */ 
/*      */   static <K, V> boolean removeEntryImpl(Collection<Map.Entry<K, V>> c, Object o)
/*      */   {
/*  817 */     if (!(o instanceof Map.Entry)) {
/*  818 */       return false;
/*      */     }
/*  820 */     return c.remove(unmodifiableEntry((Map.Entry)o));
/*      */   }
/*      */ 
/*      */   public static <K, V1, V2> Map<K, V2> transformValues(Map<K, V1> fromMap, Function<? super V1, V2> function)
/*      */   {
/*  861 */     return new TransformedValuesMap(fromMap, function);
/*      */   }
/*      */ 
/*      */   public static <K, V> Map<K, V> filterKeys(Map<K, V> unfiltered, Predicate<? super K> keyPredicate)
/*      */   {
/*  999 */     Preconditions.checkNotNull(keyPredicate);
/* 1000 */     Predicate entryPredicate = new Predicate(keyPredicate)
/*      */     {
/*      */       public boolean apply(Map.Entry<K, V> input) {
/* 1003 */         return this.val$keyPredicate.apply(input.getKey());
/*      */       }
/*      */     };
/* 1006 */     return (unfiltered instanceof AbstractFilteredMap) ? filterFiltered((AbstractFilteredMap)unfiltered, entryPredicate) : new FilteredKeyMap((Map)Preconditions.checkNotNull(unfiltered), keyPredicate, entryPredicate);
/*      */   }
/*      */ 
/*      */   public static <K, V> Map<K, V> filterValues(Map<K, V> unfiltered, Predicate<? super V> valuePredicate)
/*      */   {
/* 1038 */     Preconditions.checkNotNull(valuePredicate);
/* 1039 */     Predicate entryPredicate = new Predicate(valuePredicate)
/*      */     {
/*      */       public boolean apply(Map.Entry<K, V> input) {
/* 1042 */         return this.val$valuePredicate.apply(input.getValue());
/*      */       }
/*      */     };
/* 1045 */     return filterEntries(unfiltered, entryPredicate);
/*      */   }
/*      */ 
/*      */   public static <K, V> Map<K, V> filterEntries(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/*      */   {
/* 1076 */     Preconditions.checkNotNull(entryPredicate);
/* 1077 */     return (unfiltered instanceof AbstractFilteredMap) ? filterFiltered((AbstractFilteredMap)unfiltered, entryPredicate) : new FilteredEntryMap((Map)Preconditions.checkNotNull(unfiltered), entryPredicate);
/*      */   }
/*      */ 
/*      */   private static <K, V> Map<K, V> filterFiltered(AbstractFilteredMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/*      */   {
/* 1088 */     Predicate predicate = Predicates.and(map.predicate, entryPredicate);
/*      */ 
/* 1090 */     return new FilteredEntryMap(map.unfiltered, predicate);
/*      */   }
/*      */ 
/*      */   static <V> V safeGet(Map<?, V> map, Object key)
/*      */   {
/*      */     try
/*      */     {
/* 1474 */       return map.get(key); } catch (ClassCastException e) {
/*      */     }
/* 1476 */     return null;
/*      */   }
/*      */ 
/*      */   static boolean safeContainsKey(Map<?, ?> map, Object key)
/*      */   {
/*      */     try
/*      */     {
/* 1486 */       return map.containsKey(key); } catch (ClassCastException e) {
/*      */     }
/* 1488 */     return false;
/*      */   }
/*      */ 
/*      */   @GwtCompatible
/*      */   static abstract class ImprovedAbstractMap<K, V> extends AbstractMap<K, V>
/*      */   {
/*      */     private Set<Map.Entry<K, V>> entrySet;
/*      */     private Set<K> keySet;
/*      */     private Collection<V> values;
/*      */ 
/*      */     protected abstract Set<Map.Entry<K, V>> createEntrySet();
/*      */ 
/*      */     public Set<Map.Entry<K, V>> entrySet()
/*      */     {
/* 1406 */       Set result = this.entrySet;
/* 1407 */       if (result == null) {
/* 1408 */         this.entrySet = (result = createEntrySet());
/*      */       }
/* 1410 */       return result;
/*      */     }
/*      */ 
/*      */     public Set<K> keySet()
/*      */     {
/* 1416 */       Set result = this.keySet;
/* 1417 */       if (result == null) {
/* 1418 */         Set delegate = super.keySet();
/* 1419 */         this.keySet = (result = new ForwardingSet(delegate)
/*      */         {
/*      */           protected Set<K> delegate() {
/* 1422 */             return this.val$delegate;
/*      */           }
/*      */ 
/*      */           public boolean isEmpty() {
/* 1426 */             return Maps.ImprovedAbstractMap.this.isEmpty();
/*      */           } } );
/*      */       }
/* 1430 */       return result;
/*      */     }
/*      */ 
/*      */     public Collection<V> values()
/*      */     {
/* 1436 */       Collection result = this.values;
/* 1437 */       if (result == null) {
/* 1438 */         Collection delegate = super.values();
/* 1439 */         this.values = (result = new ForwardingCollection(delegate)
/*      */         {
/*      */           protected Collection<V> delegate() {
/* 1442 */             return this.val$delegate;
/*      */           }
/*      */ 
/*      */           public boolean isEmpty() {
/* 1446 */             return Maps.ImprovedAbstractMap.this.isEmpty();
/*      */           } } );
/*      */       }
/* 1450 */       return result;
/*      */     }
/*      */ 
/*      */     public boolean isEmpty()
/*      */     {
/* 1461 */       return entrySet().isEmpty();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class FilteredEntryMap<K, V> extends Maps.AbstractFilteredMap<K, V>
/*      */   {
/*      */     final Set<Map.Entry<K, V>> filteredEntrySet;
/*      */     Set<Map.Entry<K, V>> entrySet;
/*      */     Set<K> keySet;
/*      */ 
/*      */     FilteredEntryMap(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/*      */     {
/* 1272 */       super(entryPredicate);
/* 1273 */       this.filteredEntrySet = Sets.filter(unfiltered.entrySet(), this.predicate);
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, V>> entrySet()
/*      */     {
/* 1279 */       Set result = this.entrySet;
/* 1280 */       return result == null ? (this.entrySet = new EntrySet(null)) : result;
/*      */     }
/*      */ 
/*      */     public Set<K> keySet()
/*      */     {
/* 1315 */       Set result = this.keySet;
/* 1316 */       return result == null ? (this.keySet = new KeySet(null)) : result;
/*      */     }
/*      */     private class KeySet extends AbstractSet<K> {
/*      */       private KeySet() {
/*      */       }
/* 1321 */       public Iterator<K> iterator() { Iterator iterator = Maps.FilteredEntryMap.this.filteredEntrySet.iterator();
/* 1322 */         return new UnmodifiableIterator(iterator) {
/*      */           public boolean hasNext() {
/* 1324 */             return this.val$iterator.hasNext();
/*      */           }
/*      */ 
/*      */           public K next() {
/* 1328 */             return ((Map.Entry)this.val$iterator.next()).getKey();
/*      */           }
/*      */         }; }
/*      */ 
/*      */       public int size() {
/* 1334 */         return Maps.FilteredEntryMap.this.filteredEntrySet.size();
/*      */       }
/*      */ 
/*      */       public void clear() {
/* 1338 */         Maps.FilteredEntryMap.this.filteredEntrySet.clear();
/*      */       }
/*      */ 
/*      */       public boolean contains(Object o) {
/* 1342 */         return Maps.FilteredEntryMap.this.containsKey(o);
/*      */       }
/*      */ 
/*      */       public boolean remove(Object o) {
/* 1346 */         if (Maps.FilteredEntryMap.this.containsKey(o)) {
/* 1347 */           Maps.FilteredEntryMap.this.unfiltered.remove(o);
/* 1348 */           return true;
/*      */         }
/* 1350 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> collection) {
/* 1354 */         Preconditions.checkNotNull(collection);
/* 1355 */         boolean changed = false;
/* 1356 */         for (Iterator i$ = collection.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 1357 */           changed |= remove(obj);
/*      */         }
/* 1359 */         return changed;
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> collection) {
/* 1363 */         Preconditions.checkNotNull(collection);
/* 1364 */         boolean changed = false;
/* 1365 */         Iterator iterator = Maps.FilteredEntryMap.this.unfiltered.entrySet().iterator();
/* 1366 */         while (iterator.hasNext()) {
/* 1367 */           Map.Entry entry = (Map.Entry)iterator.next();
/* 1368 */           if ((!collection.contains(entry.getKey())) && (Maps.FilteredEntryMap.this.predicate.apply(entry))) {
/* 1369 */             iterator.remove();
/* 1370 */             changed = true;
/*      */           }
/*      */         }
/* 1373 */         return changed;
/*      */       }
/*      */ 
/*      */       public Object[] toArray()
/*      */       {
/* 1378 */         return Lists.newArrayList(iterator()).toArray();
/*      */       }
/*      */ 
/*      */       public <T> T[] toArray(T[] array) {
/* 1382 */         return Lists.newArrayList(iterator()).toArray(array);
/*      */       }
/*      */     }
/*      */ 
/*      */     private class EntrySet extends ForwardingSet<Map.Entry<K, V>>
/*      */     {
/*      */       private EntrySet()
/*      */       {
/*      */       }
/*      */ 
/*      */       protected Set<Map.Entry<K, V>> delegate()
/*      */       {
/* 1285 */         return Maps.FilteredEntryMap.this.filteredEntrySet;
/*      */       }
/*      */ 
/*      */       public Iterator<Map.Entry<K, V>> iterator() {
/* 1289 */         Iterator iterator = Maps.FilteredEntryMap.this.filteredEntrySet.iterator();
/* 1290 */         return new UnmodifiableIterator(iterator) {
/*      */           public boolean hasNext() {
/* 1292 */             return this.val$iterator.hasNext();
/*      */           }
/*      */ 
/*      */           public Map.Entry<K, V> next() {
/* 1296 */             Map.Entry entry = (Map.Entry)this.val$iterator.next();
/* 1297 */             return new ForwardingMapEntry(entry) {
/*      */               protected Map.Entry<K, V> delegate() {
/* 1299 */                 return this.val$entry;
/*      */               }
/*      */ 
/*      */               public V setValue(V value) {
/* 1303 */                 Preconditions.checkArgument(Maps.FilteredEntryMap.this.apply(this.val$entry.getKey(), value));
/* 1304 */                 return super.setValue(value);
/*      */               }
/*      */             };
/*      */           }
/*      */         };
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class FilteredKeyMap<K, V> extends Maps.AbstractFilteredMap<K, V>
/*      */   {
/*      */     Predicate<? super K> keyPredicate;
/*      */     Set<Map.Entry<K, V>> entrySet;
/*      */     Set<K> keySet;
/*      */ 
/*      */     FilteredKeyMap(Map<K, V> unfiltered, Predicate<? super K> keyPredicate, Predicate<Map.Entry<K, V>> entryPredicate)
/*      */     {
/* 1231 */       super(entryPredicate);
/* 1232 */       this.keyPredicate = keyPredicate;
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, V>> entrySet()
/*      */     {
/* 1238 */       Set result = this.entrySet;
/* 1239 */       return result == null ? (this.entrySet = Sets.filter(this.unfiltered.entrySet(), this.predicate)) : result;
/*      */     }
/*      */ 
/*      */     public Set<K> keySet()
/*      */     {
/* 1247 */       Set result = this.keySet;
/* 1248 */       return result == null ? (this.keySet = Sets.filter(this.unfiltered.keySet(), this.keyPredicate)) : result;
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key)
/*      */     {
/* 1258 */       return (this.unfiltered.containsKey(key)) && (this.keyPredicate.apply(key));
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract class AbstractFilteredMap<K, V> extends AbstractMap<K, V>
/*      */   {
/*      */     final Map<K, V> unfiltered;
/*      */     final Predicate<? super Map.Entry<K, V>> predicate;
/*      */     Collection<V> values;
/*      */ 
/*      */     AbstractFilteredMap(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/*      */     {
/* 1100 */       this.unfiltered = unfiltered;
/* 1101 */       this.predicate = predicate;
/*      */     }
/*      */ 
/*      */     boolean apply(Object key, V value)
/*      */     {
/* 1108 */       Object k = key;
/* 1109 */       return this.predicate.apply(Maps.immutableEntry(k, value));
/*      */     }
/*      */ 
/*      */     public V put(K key, V value) {
/* 1113 */       Preconditions.checkArgument(apply(key, value));
/* 1114 */       return this.unfiltered.put(key, value);
/*      */     }
/*      */ 
/*      */     public void putAll(Map<? extends K, ? extends V> map) {
/* 1118 */       for (Map.Entry entry : map.entrySet()) {
/* 1119 */         Preconditions.checkArgument(apply(entry.getKey(), entry.getValue()));
/*      */       }
/* 1121 */       this.unfiltered.putAll(map);
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/* 1125 */       return (this.unfiltered.containsKey(key)) && (apply(key, this.unfiltered.get(key)));
/*      */     }
/*      */ 
/*      */     public V get(Object key) {
/* 1129 */       Object value = this.unfiltered.get(key);
/* 1130 */       return (value != null) && (apply(key, value)) ? value : null;
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/* 1134 */       return entrySet().isEmpty();
/*      */     }
/*      */ 
/*      */     public V remove(Object key) {
/* 1138 */       return containsKey(key) ? this.unfiltered.remove(key) : null;
/*      */     }
/*      */ 
/*      */     public Collection<V> values()
/*      */     {
/* 1144 */       Collection result = this.values;
/* 1145 */       return result == null ? (this.values = new Values()) : result;
/*      */     }
/*      */     class Values extends AbstractCollection<V> {
/*      */       Values() {
/*      */       }
/* 1150 */       public Iterator<V> iterator() { Iterator entryIterator = Maps.AbstractFilteredMap.this.entrySet().iterator();
/* 1151 */         return new UnmodifiableIterator(entryIterator) {
/*      */           public boolean hasNext() {
/* 1153 */             return this.val$entryIterator.hasNext();
/*      */           }
/*      */ 
/*      */           public V next() {
/* 1157 */             return ((Map.Entry)this.val$entryIterator.next()).getValue();
/*      */           }
/*      */         }; }
/*      */ 
/*      */       public int size() {
/* 1163 */         return Maps.AbstractFilteredMap.this.entrySet().size();
/*      */       }
/*      */ 
/*      */       public void clear() {
/* 1167 */         Maps.AbstractFilteredMap.this.entrySet().clear();
/*      */       }
/*      */ 
/*      */       public boolean isEmpty() {
/* 1171 */         return Maps.AbstractFilteredMap.this.entrySet().isEmpty();
/*      */       }
/*      */ 
/*      */       public boolean remove(Object o) {
/* 1175 */         Iterator iterator = Maps.AbstractFilteredMap.this.unfiltered.entrySet().iterator();
/* 1176 */         while (iterator.hasNext()) {
/* 1177 */           Map.Entry entry = (Map.Entry)iterator.next();
/* 1178 */           if ((Objects.equal(o, entry.getValue())) && (Maps.AbstractFilteredMap.this.predicate.apply(entry))) {
/* 1179 */             iterator.remove();
/* 1180 */             return true;
/*      */           }
/*      */         }
/* 1183 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> collection) {
/* 1187 */         Preconditions.checkNotNull(collection);
/* 1188 */         boolean changed = false;
/* 1189 */         Iterator iterator = Maps.AbstractFilteredMap.this.unfiltered.entrySet().iterator();
/* 1190 */         while (iterator.hasNext()) {
/* 1191 */           Map.Entry entry = (Map.Entry)iterator.next();
/* 1192 */           if ((collection.contains(entry.getValue())) && (Maps.AbstractFilteredMap.this.predicate.apply(entry))) {
/* 1193 */             iterator.remove();
/* 1194 */             changed = true;
/*      */           }
/*      */         }
/* 1197 */         return changed;
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> collection) {
/* 1201 */         Preconditions.checkNotNull(collection);
/* 1202 */         boolean changed = false;
/* 1203 */         Iterator iterator = Maps.AbstractFilteredMap.this.unfiltered.entrySet().iterator();
/* 1204 */         while (iterator.hasNext()) {
/* 1205 */           Map.Entry entry = (Map.Entry)iterator.next();
/* 1206 */           if ((!collection.contains(entry.getValue())) && (Maps.AbstractFilteredMap.this.predicate.apply(entry)))
/*      */           {
/* 1208 */             iterator.remove();
/* 1209 */             changed = true;
/*      */           }
/*      */         }
/* 1212 */         return changed;
/*      */       }
/*      */ 
/*      */       public Object[] toArray()
/*      */       {
/* 1217 */         return Lists.newArrayList(iterator()).toArray();
/*      */       }
/*      */ 
/*      */       public <T> T[] toArray(T[] array) {
/* 1221 */         return Lists.newArrayList(iterator()).toArray(array);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class TransformedValuesMap<K, V1, V2> extends AbstractMap<K, V2>
/*      */   {
/*      */     final Map<K, V1> fromMap;
/*      */     final Function<? super V1, V2> function;
/*      */     TransformedValuesMap<K, V1, V2>.EntrySet entrySet;
/*      */ 
/*      */     TransformedValuesMap(Map<K, V1> fromMap, Function<? super V1, V2> function)
/*      */     {
/*  871 */       this.fromMap = ((Map)Preconditions.checkNotNull(fromMap));
/*  872 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*      */     }
/*      */ 
/*      */     public int size() {
/*  876 */       return this.fromMap.size();
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  880 */       return this.fromMap.containsKey(key);
/*      */     }
/*      */ 
/*      */     public V2 get(Object key) {
/*  884 */       Object value = this.fromMap.get(key);
/*  885 */       return (value != null) || (this.fromMap.containsKey(key)) ? this.function.apply(value) : null;
/*      */     }
/*      */ 
/*      */     public V2 remove(Object key)
/*      */     {
/*  891 */       return this.fromMap.containsKey(key) ? this.function.apply(this.fromMap.remove(key)) : null;
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */     {
/*  897 */       this.fromMap.clear();
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, V2>> entrySet()
/*      */     {
/*  903 */       EntrySet result = this.entrySet;
/*  904 */       if (result == null) {
/*  905 */         this.entrySet = (result = new EntrySet());
/*      */       }
/*  907 */       return result;
/*      */     }
/*      */     class EntrySet extends AbstractSet<Map.Entry<K, V2>> {
/*      */       EntrySet() {
/*      */       }
/*  912 */       public int size() { return Maps.TransformedValuesMap.this.size(); }
/*      */ 
/*      */       public Iterator<Map.Entry<K, V2>> iterator()
/*      */       {
/*  916 */         Iterator mapIterator = Maps.TransformedValuesMap.this.fromMap.entrySet().iterator();
/*      */ 
/*  919 */         return new Iterator(mapIterator) {
/*      */           public boolean hasNext() {
/*  921 */             return this.val$mapIterator.hasNext();
/*      */           }
/*      */ 
/*      */           public Map.Entry<K, V2> next() {
/*  925 */             Map.Entry entry = (Map.Entry)this.val$mapIterator.next();
/*  926 */             return new AbstractMapEntry(entry) {
/*      */               public K getKey() {
/*  928 */                 return this.val$entry.getKey();
/*      */               }
/*      */ 
/*      */               public V2 getValue() {
/*  932 */                 return Maps.TransformedValuesMap.this.function.apply(this.val$entry.getValue());
/*      */               } } ;
/*      */           }
/*      */ 
/*      */           public void remove() {
/*  938 */             this.val$mapIterator.remove();
/*      */           } } ;
/*      */       }
/*      */ 
/*      */       public void clear() {
/*  944 */         Maps.TransformedValuesMap.this.fromMap.clear();
/*      */       }
/*      */ 
/*      */       public boolean contains(Object o) {
/*  948 */         if (!(o instanceof Map.Entry)) {
/*  949 */           return false;
/*      */         }
/*  951 */         Map.Entry entry = (Map.Entry)o;
/*  952 */         Object entryKey = entry.getKey();
/*  953 */         Object entryValue = entry.getValue();
/*  954 */         Object mapValue = Maps.TransformedValuesMap.this.get(entryKey);
/*  955 */         if (mapValue != null) {
/*  956 */           return mapValue.equals(entryValue);
/*      */         }
/*  958 */         return (entryValue == null) && (Maps.TransformedValuesMap.this.containsKey(entryKey));
/*      */       }
/*      */ 
/*      */       public boolean remove(Object o) {
/*  962 */         if (contains(o)) {
/*  963 */           Map.Entry entry = (Map.Entry)o;
/*  964 */           Object key = entry.getKey();
/*  965 */           Maps.TransformedValuesMap.this.fromMap.remove(key);
/*  966 */           return true;
/*      */         }
/*  968 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnmodifiableBiMap<K, V> extends ForwardingMap<K, V>
/*      */     implements BiMap<K, V>, Serializable
/*      */   {
/*      */     final Map<K, V> unmodifiableMap;
/*      */     final BiMap<? extends K, ? extends V> delegate;
/*      */     transient BiMap<V, K> inverse;
/*      */     transient Set<V> values;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     UnmodifiableBiMap(BiMap<? extends K, ? extends V> delegate, @Nullable BiMap<V, K> inverse)
/*      */     {
/*  753 */       this.unmodifiableMap = Collections.unmodifiableMap(delegate);
/*  754 */       this.delegate = delegate;
/*  755 */       this.inverse = inverse;
/*      */     }
/*      */ 
/*      */     protected Map<K, V> delegate() {
/*  759 */       return this.unmodifiableMap;
/*      */     }
/*      */ 
/*      */     public V forcePut(K key, V value) {
/*  763 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public BiMap<V, K> inverse() {
/*  767 */       BiMap result = this.inverse;
/*  768 */       return result == null ? (this.inverse = new UnmodifiableBiMap(this.delegate.inverse(), this)) : result;
/*      */     }
/*      */ 
/*      */     public Set<V> values()
/*      */     {
/*  774 */       Set result = this.values;
/*  775 */       return result == null ? (this.values = Collections.unmodifiableSet(this.delegate.values())) : result;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class UnmodifiableEntrySet<K, V> extends Maps.UnmodifiableEntries<K, V>
/*      */     implements Set<Map.Entry<K, V>>
/*      */   {
/*      */     UnmodifiableEntrySet(Set<Map.Entry<K, V>> entries)
/*      */     {
/*  711 */       super();
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object)
/*      */     {
/*  717 */       return Collections2.setEquals(this, object);
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  721 */       return Sets.hashCodeImpl(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class UnmodifiableEntries<K, V> extends ForwardingCollection<Map.Entry<K, V>>
/*      */   {
/*      */     private final Collection<Map.Entry<K, V>> entries;
/*      */ 
/*      */     UnmodifiableEntries(Collection<Map.Entry<K, V>> entries)
/*      */     {
/*  668 */       this.entries = entries;
/*      */     }
/*      */ 
/*      */     protected Collection<Map.Entry<K, V>> delegate() {
/*  672 */       return this.entries;
/*      */     }
/*      */ 
/*      */     public Iterator<Map.Entry<K, V>> iterator() {
/*  676 */       Iterator delegate = super.iterator();
/*  677 */       return new ForwardingIterator(delegate) {
/*      */         public Map.Entry<K, V> next() {
/*  679 */           return Maps.access$000((Map.Entry)super.next());
/*      */         }
/*      */ 
/*      */         protected Iterator<Map.Entry<K, V>> delegate() {
/*  683 */           return this.val$delegate;
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public Object[] toArray()
/*      */     {
/*  691 */       return ObjectArrays.toArrayImpl(this);
/*      */     }
/*      */ 
/*      */     public <T> T[] toArray(T[] array) {
/*  695 */       return ObjectArrays.toArrayImpl(this, array);
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/*  699 */       return Maps.containsEntryImpl(delegate(), o);
/*      */     }
/*      */ 
/*      */     public boolean containsAll(Collection<?> c) {
/*  703 */       return Collections2.containsAll(this, c);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ValueDifferenceImpl<V>
/*      */     implements MapDifference.ValueDifference<V>
/*      */   {
/*      */     private final V left;
/*      */     private final V right;
/*      */ 
/*      */     ValueDifferenceImpl(@Nullable V left, @Nullable V right)
/*      */     {
/*  530 */       this.left = left;
/*  531 */       this.right = right;
/*      */     }
/*      */ 
/*      */     public V leftValue() {
/*  535 */       return this.left;
/*      */     }
/*      */ 
/*      */     public V rightValue() {
/*  539 */       return this.right;
/*      */     }
/*      */ 
/*      */     public boolean equals(@Nullable Object object) {
/*  543 */       if ((object instanceof MapDifference.ValueDifference)) {
/*  544 */         MapDifference.ValueDifference that = (MapDifference.ValueDifference)object;
/*      */ 
/*  546 */         return (Objects.equal(this.left, that.leftValue())) && (Objects.equal(this.right, that.rightValue()));
/*      */       }
/*      */ 
/*  549 */       return false;
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  553 */       return Objects.hashCode(new Object[] { this.left, this.right });
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  557 */       return "(" + this.left + ", " + this.right + ")";
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class MapDifferenceImpl<K, V>
/*      */     implements MapDifference<K, V>
/*      */   {
/*      */     final boolean areEqual;
/*      */     final Map<K, V> onlyOnLeft;
/*      */     final Map<K, V> onlyOnRight;
/*      */     final Map<K, V> onBoth;
/*      */     final Map<K, MapDifference.ValueDifference<V>> differences;
/*      */ 
/*      */     MapDifferenceImpl(boolean areEqual, Map<K, V> onlyOnLeft, Map<K, V> onlyOnRight, Map<K, V> onBoth, Map<K, MapDifference.ValueDifference<V>> differences)
/*      */     {
/*  459 */       this.areEqual = areEqual;
/*  460 */       this.onlyOnLeft = Collections.unmodifiableMap(onlyOnLeft);
/*  461 */       this.onlyOnRight = Collections.unmodifiableMap(onlyOnRight);
/*  462 */       this.onBoth = Collections.unmodifiableMap(onBoth);
/*  463 */       this.differences = Collections.unmodifiableMap(differences);
/*      */     }
/*      */ 
/*      */     public boolean areEqual() {
/*  467 */       return this.areEqual;
/*      */     }
/*      */ 
/*      */     public Map<K, V> entriesOnlyOnLeft() {
/*  471 */       return this.onlyOnLeft;
/*      */     }
/*      */ 
/*      */     public Map<K, V> entriesOnlyOnRight() {
/*  475 */       return this.onlyOnRight;
/*      */     }
/*      */ 
/*      */     public Map<K, V> entriesInCommon() {
/*  479 */       return this.onBoth;
/*      */     }
/*      */ 
/*      */     public Map<K, MapDifference.ValueDifference<V>> entriesDiffering() {
/*  483 */       return this.differences;
/*      */     }
/*      */ 
/*      */     public boolean equals(Object object) {
/*  487 */       if (object == this) {
/*  488 */         return true;
/*      */       }
/*  490 */       if ((object instanceof MapDifference)) {
/*  491 */         MapDifference other = (MapDifference)object;
/*  492 */         return (entriesOnlyOnLeft().equals(other.entriesOnlyOnLeft())) && (entriesOnlyOnRight().equals(other.entriesOnlyOnRight())) && (entriesInCommon().equals(other.entriesInCommon())) && (entriesDiffering().equals(other.entriesDiffering()));
/*      */       }
/*      */ 
/*  497 */       return false;
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  501 */       return Objects.hashCode(new Object[] { entriesOnlyOnLeft(), entriesOnlyOnRight(), entriesInCommon(), entriesDiffering() });
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  506 */       if (this.areEqual) {
/*  507 */         return "equal";
/*      */       }
/*      */ 
/*  510 */       StringBuilder result = new StringBuilder("not equal");
/*  511 */       if (!this.onlyOnLeft.isEmpty()) {
/*  512 */         result.append(": only on left=").append(this.onlyOnLeft);
/*      */       }
/*  514 */       if (!this.onlyOnRight.isEmpty()) {
/*  515 */         result.append(": only on right=").append(this.onlyOnRight);
/*      */       }
/*  517 */       if (!this.differences.isEmpty()) {
/*  518 */         result.append(": value differences=").append(this.differences);
/*      */       }
/*  520 */       return result.toString();
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Maps
 * JD-Core Version:    0.6.0
 */