package com.google.appengine.api.datastore;

import java.util.List;

public abstract interface QueryResultList<T> extends List<T>
{
  public abstract Cursor getCursor();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryResultList
 * JD-Core Version:    0.6.0
 */