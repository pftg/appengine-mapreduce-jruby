package javax.mail;

import javax.activation.DataSource;

public abstract interface MultipartDataSource extends DataSource
{
  public abstract BodyPart getBodyPart(int paramInt)
    throws MessagingException;

  public abstract int getCount();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.MultipartDataSource
 * JD-Core Version:    0.6.0
 */