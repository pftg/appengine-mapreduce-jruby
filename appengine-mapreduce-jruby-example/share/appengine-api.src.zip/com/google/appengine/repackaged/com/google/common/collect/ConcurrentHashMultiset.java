/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.primitives.Ints;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ public final class ConcurrentHashMultiset<E> extends AbstractMultiset<E>
/*     */   implements Serializable
/*     */ {
/*     */   private final transient ConcurrentMap<E, Integer> countMap;
/*     */   private transient ConcurrentHashMultiset<E>.EntrySet entrySet;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <E> ConcurrentHashMultiset<E> create()
/*     */   {
/*  76 */     return new ConcurrentHashMultiset(new ConcurrentHashMap());
/*     */   }
/*     */ 
/*     */   public static <E> ConcurrentHashMultiset<E> create(Iterable<? extends E> elements)
/*     */   {
/*  88 */     ConcurrentHashMultiset multiset = create();
/*  89 */     Iterables.addAll(multiset, elements);
/*  90 */     return multiset;
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   ConcurrentHashMultiset(ConcurrentMap<E, Integer> countMap)
/*     */   {
/* 106 */     Preconditions.checkArgument(countMap.isEmpty());
/* 107 */     this.countMap = countMap;
/*     */   }
/*     */ 
/*     */   public int count(@Nullable Object element)
/*     */   {
/*     */     try
/*     */     {
/* 120 */       return unbox((Integer)this.countMap.get(element));
/*     */     } catch (NullPointerException e) {
/* 122 */       return 0; } catch (ClassCastException e) {
/*     */     }
/* 124 */     return 0;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 136 */     long sum = 0L;
/* 137 */     for (Integer value : this.countMap.values()) {
/* 138 */       sum += value.intValue();
/*     */     }
/* 140 */     return Ints.saturatedCast(sum);
/*     */   }
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 149 */     return snapshot().toArray();
/*     */   }
/*     */ 
/*     */   public <T> T[] toArray(T[] array) {
/* 153 */     return snapshot().toArray(array);
/*     */   }
/*     */ 
/*     */   private List<E> snapshot()
/*     */   {
/* 161 */     List list = Lists.newArrayListWithExpectedSize(size());
/* 162 */     for (Multiset.Entry entry : entrySet()) {
/* 163 */       Object element = entry.getElement();
/* 164 */       for (int i = entry.getCount(); i > 0; i--) {
/* 165 */         list.add(element);
/*     */       }
/*     */     }
/* 168 */     return list;
/*     */   }
/*     */ 
/*     */   public int add(E element, int occurrences)
/*     */   {
/* 184 */     if (occurrences == 0) {
/* 185 */       return count(element);
/*     */     }
/* 187 */     Preconditions.checkArgument(occurrences > 0, "Invalid occurrences: %s", new Object[] { Integer.valueOf(occurrences) });
/*     */     while (true)
/*     */     {
/* 190 */       int current = count(element);
/* 191 */       if (current == 0) {
/* 192 */         if (this.countMap.putIfAbsent(element, Integer.valueOf(occurrences)) == null)
/* 193 */           return 0;
/*     */       }
/*     */       else {
/* 196 */         Preconditions.checkArgument(occurrences <= 2147483647 - current, "Overflow adding %s occurrences to a count of %s", new Object[] { Integer.valueOf(occurrences), Integer.valueOf(current) });
/*     */ 
/* 199 */         int next = current + occurrences;
/* 200 */         if (this.countMap.replace(element, Integer.valueOf(current), Integer.valueOf(next)))
/* 201 */           return current;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int remove(@Nullable Object element, int occurrences)
/*     */   {
/* 219 */     if (occurrences == 0) {
/* 220 */       return count(element);
/*     */     }
/* 222 */     Preconditions.checkArgument(occurrences > 0, "Invalid occurrences: %s", new Object[] { Integer.valueOf(occurrences) });
/*     */     while (true)
/*     */     {
/* 225 */       int current = count(element);
/* 226 */       if (current == 0) {
/* 227 */         return 0;
/*     */       }
/* 229 */       if (occurrences >= current) {
/* 230 */         if (this.countMap.remove(element, Integer.valueOf(current))) {
/* 231 */           return current;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 236 */         Object casted = element;
/*     */ 
/* 238 */         if (this.countMap.replace(casted, Integer.valueOf(current), Integer.valueOf(current - occurrences)))
/* 239 */           return current;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private int removeAllOccurrences(@Nullable Object element)
/*     */   {
/*     */     try
/*     */     {
/* 256 */       return unbox((Integer)this.countMap.remove(element));
/*     */     } catch (NullPointerException e) {
/* 258 */       return 0; } catch (ClassCastException e) {
/*     */     }
/* 260 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean removeExactly(@Nullable Object element, int occurrences)
/*     */   {
/* 277 */     if (occurrences == 0) {
/* 278 */       return true;
/*     */     }
/* 280 */     Preconditions.checkArgument(occurrences > 0, "Invalid occurrences: %s", new Object[] { Integer.valueOf(occurrences) });
/*     */     while (true)
/*     */     {
/* 283 */       int current = count(element);
/* 284 */       if (occurrences > current) {
/* 285 */         return false;
/*     */       }
/* 287 */       if (occurrences == current) {
/* 288 */         if (this.countMap.remove(element, Integer.valueOf(occurrences)))
/* 289 */           return true;
/*     */       }
/*     */       else
/*     */       {
/* 293 */         Object casted = element;
/* 294 */         if (this.countMap.replace(casted, Integer.valueOf(current), Integer.valueOf(current - occurrences)))
/* 295 */           return true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int setCount(E element, int count)
/*     */   {
/* 310 */     Multisets.checkNonnegative(count, "count");
/* 311 */     return count == 0 ? removeAllOccurrences(element) : unbox((Integer)this.countMap.put(element, Integer.valueOf(count)));
/*     */   }
/*     */ 
/*     */   public boolean setCount(E element, int oldCount, int newCount)
/*     */   {
/* 330 */     Multisets.checkNonnegative(oldCount, "oldCount");
/* 331 */     Multisets.checkNonnegative(newCount, "newCount");
/* 332 */     if (newCount == 0) {
/* 333 */       if (oldCount == 0)
/*     */       {
/* 335 */         return !this.countMap.containsKey(element);
/*     */       }
/* 337 */       return this.countMap.remove(element, Integer.valueOf(oldCount));
/*     */     }
/*     */ 
/* 340 */     if (oldCount == 0) {
/* 341 */       return this.countMap.putIfAbsent(element, Integer.valueOf(newCount)) == null;
/*     */     }
/* 343 */     return this.countMap.replace(element, Integer.valueOf(oldCount), Integer.valueOf(newCount));
/*     */   }
/*     */ 
/*     */   Set<E> createElementSet()
/*     */   {
/* 349 */     Set delegate = this.countMap.keySet();
/* 350 */     return new ForwardingSet(delegate) {
/*     */       protected Set<E> delegate() {
/* 352 */         return this.val$delegate;
/*     */       }
/*     */       public boolean remove(Object object) {
/*     */         try {
/* 356 */           return this.val$delegate.remove(object);
/*     */         } catch (NullPointerException e) {
/* 358 */           return false; } catch (ClassCastException e) {
/*     */         }
/* 360 */         return false;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Set<Multiset.Entry<E>> entrySet()
/*     */   {
/* 369 */     EntrySet result = this.entrySet;
/* 370 */     if (result == null) {
/* 371 */       this.entrySet = (result = new EntrySet(null));
/*     */     }
/* 373 */     return result;
/*     */   }
/*     */ 
/*     */   private static int unbox(Integer i)
/*     */   {
/* 466 */     return i == null ? 0 : i.intValue();
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 474 */     stream.defaultWriteObject();
/*     */ 
/* 476 */     Serialization.writeMultiset(HashMultiset.create(this), stream);
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*     */   {
/* 481 */     stream.defaultReadObject();
/* 482 */     FieldSettersHolder.COUNT_MAP_FIELD_SETTER.set(this, new ConcurrentHashMap());
/*     */ 
/* 484 */     Serialization.populateMultiset(this, stream);
/*     */   }
/*     */ 
/*     */   private class EntrySet extends AbstractSet<Multiset.Entry<E>>
/*     */   {
/*     */     private EntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 378 */       return ConcurrentHashMultiset.this.countMap.size();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 382 */       return ConcurrentHashMultiset.this.countMap.isEmpty();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object object) {
/* 386 */       if ((object instanceof Multiset.Entry)) {
/* 387 */         Multiset.Entry entry = (Multiset.Entry)object;
/* 388 */         Object element = entry.getElement();
/* 389 */         int entryCount = entry.getCount();
/* 390 */         return (entryCount > 0) && (ConcurrentHashMultiset.this.count(element) == entryCount);
/*     */       }
/* 392 */       return false;
/*     */     }
/*     */ 
/*     */     public Iterator<Multiset.Entry<E>> iterator() {
/* 396 */       Iterator backingIterator = ConcurrentHashMultiset.this.countMap.entrySet().iterator();
/*     */ 
/* 398 */       return new Iterator(backingIterator) {
/*     */         public boolean hasNext() {
/* 400 */           return this.val$backingIterator.hasNext();
/*     */         }
/*     */ 
/*     */         public Multiset.Entry<E> next() {
/* 404 */           Map.Entry backingEntry = (Map.Entry)this.val$backingIterator.next();
/* 405 */           return Multisets.immutableEntry(backingEntry.getKey(), ((Integer)backingEntry.getValue()).intValue());
/*     */         }
/*     */ 
/*     */         public void remove()
/*     */         {
/* 410 */           this.val$backingIterator.remove();
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 421 */       return snapshot().toArray();
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 425 */       return snapshot().toArray(array);
/*     */     }
/*     */ 
/*     */     private List<Multiset.Entry<E>> snapshot()
/*     */     {
/* 433 */       List list = Lists.newArrayListWithExpectedSize(size());
/* 434 */       for (Multiset.Entry entry : this) {
/* 435 */         list.add(entry);
/*     */       }
/* 437 */       return list;
/*     */     }
/*     */ 
/*     */     public boolean remove(Object object) {
/* 441 */       if ((object instanceof Multiset.Entry)) {
/* 442 */         Multiset.Entry entry = (Multiset.Entry)object;
/* 443 */         Object element = entry.getElement();
/* 444 */         int entryCount = entry.getCount();
/* 445 */         return ConcurrentHashMultiset.this.countMap.remove(element, Integer.valueOf(entryCount));
/*     */       }
/* 447 */       return false;
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 451 */       ConcurrentHashMultiset.this.countMap.clear();
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 458 */       return ConcurrentHashMultiset.this.countMap.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FieldSettersHolder
/*     */   {
/*  66 */     static final Serialization.FieldSetter<ConcurrentHashMultiset> COUNT_MAP_FIELD_SETTER = Serialization.getFieldSetter(ConcurrentHashMultiset.class, "countMap");
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ConcurrentHashMultiset
 * JD-Core Version:    0.6.0
 */