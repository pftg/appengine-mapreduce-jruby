/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ @GoogleInternal
/*    */ public final class LogContext
/*    */ {
/* 46 */   private static ThreadLocal<String> threadTagMap = new ThreadLocal();
/*    */ 
/*    */   public static void setThreadTag(@Nullable String tag)
/*    */   {
/* 35 */     threadTagMap.set(tag);
/*    */   }
/*    */ 
/*    */   @Nullable
/*    */   public static String getThreadTag()
/*    */   {
/* 43 */     return (String)threadTagMap.get();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.LogContext
 * JD-Core Version:    0.6.0
 */