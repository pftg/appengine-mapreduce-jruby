/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class Protocol
/*     */ {
/*     */   public static final int NUMERIC = 0;
/*     */   public static final int DOUBLE = 1;
/*     */   public static final int STRING = 2;
/*     */   public static final int STARTGROUP = 3;
/*     */   public static final int ENDGROUP = 4;
/*     */   public static final int FLOAT = 5;
/*     */   public static final int MAX_TYPE = 6;
/*     */   public static final int MAX_VARINT_SIZE = 5;
/*     */   public static final int MAX_VARLONG_SIZE = 10;
/*     */   public static final byte[] EMPTY_BYTE_ARRAY;
/*     */ 
/*     */   public static int getTagFormat(int tag_word)
/*     */   {
/*  36 */     return tag_word & 0x7;
/*     */   }
/*     */ 
/*     */   public static int getTag(int tag_word)
/*     */   {
/*  43 */     return tag_word >>> 3;
/*     */   }
/*     */ 
/*     */   public static int makeTagWord(int tag, int tag_format)
/*     */   {
/*  50 */     assert ((tag_format & 0x7) == tag_format);
/*  51 */     return tag << 3 | tag_format;
/*     */   }
/*     */ 
/*     */   public static int endTag(int tag)
/*     */   {
/*  58 */     return makeTagWord(tag, 4);
/*     */   }
/*     */ 
/*     */   public static boolean getBoolean(ByteBuffer source)
/*     */   {
/*  73 */     return getVarInt(source) != 0;
/*     */   }
/*     */ 
/*     */   public static void putBoolean(boolean v, ByteBuffer sink)
/*     */   {
/*  80 */     sink.put((byte)(v ? 1 : 0));
/*     */   }
/*     */ 
/*     */   public static int varIntSize(int v)
/*     */   {
/*  88 */     int result = 0;
/*     */     do {
/*  90 */       result++;
/*  91 */       v >>>= 7;
/*  92 */     }while (v != 0);
/*  93 */     return result;
/*     */   }
/*     */ 
/*     */   public static int getVarInt(ByteBuffer source)
/*     */   {
/*     */     int tmp;
/* 103 */     if ((tmp = source.get()) >= 0) {
/* 104 */       return tmp;
/*     */     }
/* 106 */     int result = tmp & 0x7F;
/* 107 */     if ((tmp = source.get()) >= 0) {
/* 108 */       result |= tmp << 7;
/*     */     } else {
/* 110 */       result |= (tmp & 0x7F) << 7;
/* 111 */       if ((tmp = source.get()) >= 0) {
/* 112 */         result |= tmp << 14;
/*     */       } else {
/* 114 */         result |= (tmp & 0x7F) << 14;
/* 115 */         if ((tmp = source.get()) >= 0) {
/* 116 */           result |= tmp << 21;
/*     */         } else {
/* 118 */           result |= (tmp & 0x7F) << 21;
/* 119 */           result |= (tmp = source.get()) << 28;
/* 120 */           while (tmp < 0)
/*     */           {
/* 124 */             tmp = source.get();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 129 */     return result;
/*     */   }
/*     */ 
/*     */   public static void putVarInt(int v, ByteBuffer sink)
/*     */   {
/*     */     while (true)
/*     */     {
/* 138 */       int bits = v & 0x7F;
/* 139 */       v >>>= 7;
/* 140 */       if (v == 0) {
/* 141 */         sink.put((byte)bits);
/* 142 */         return;
/*     */       }
/* 144 */       sink.put((byte)(bits | 0x80));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int varLongSize(long v)
/*     */   {
/* 153 */     int result = 0;
/*     */     do {
/* 155 */       result++;
/* 156 */       v >>>= 7;
/* 157 */     }while (v != 0L);
/* 158 */     return result;
/*     */   }
/*     */ 
/*     */   public static long getVarLong(ByteBuffer source)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static void putVarLong(long v, ByteBuffer sink)
/*     */   {
/*     */     while (true)
/*     */     {
/* 222 */       int bits = (int)v & 0x7F;
/* 223 */       v >>>= 7;
/* 224 */       if (v == 0L) {
/* 225 */         sink.put((byte)bits);
/* 226 */         return;
/*     */       }
/* 228 */       sink.put((byte)(bits | 0x80));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int stringSize(int len)
/*     */   {
/* 238 */     return varIntSize(len) + len;
/*     */   }
/*     */ 
/*     */   public static byte[] getPrefixedData(ByteBuffer source)
/*     */   {
/* 246 */     int len = getVarInt(source);
/* 247 */     byte[] b = new byte[len];
/* 248 */     source.get(b, 0, len);
/* 249 */     return b;
/*     */   }
/*     */ 
/*     */   public static void putPrefixedData(byte[] v, ByteBuffer sink)
/*     */   {
/* 258 */     putVarInt(v.length, sink);
/* 259 */     sink.put(v, 0, v.length);
/*     */   }
/*     */ 
/*     */   public static void skipData(ByteBuffer source, int tagWord)
/*     */   {
/*     */     int endWord;
/* 268 */     switch (getTagFormat(tagWord)) {
/*     */     case 0:
/* 270 */       getVarLong(source);
/* 271 */       break;
/*     */     case 5:
/* 273 */       source.getFloat();
/* 274 */       break;
/*     */     case 1:
/* 276 */       source.getDouble();
/* 277 */       break;
/*     */     case 2:
/* 279 */       int len = getVarInt(source);
/* 280 */       source.position(source.position() + len);
/* 281 */       break;
/*     */     case 3:
/* 284 */       endWord = endTag(getTag(tagWord));
/*     */     case 4:
/*     */     default:
/*     */       int nextTagWord;
/* 285 */       while ((nextTagWord = getVarInt(source)) != endWord) {
/* 286 */         skipData(source, nextTagWord); continue;
/*     */ 
/* 290 */         throw new IllegalArgumentException("unexpected ENDGROUP " + tagWord);
/*     */ 
/* 292 */         throw new IllegalArgumentException("unexpected type code in " + tagWord);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void putString(String v, ByteBuffer sink)
/*     */   {
/*     */     try
/*     */     {
/* 305 */       byte[] utf8Bytes = v.getBytes("UTF-8");
/* 306 */       sink.put(utf8Bytes, 0, utf8Bytes.length);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 309 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <T> T unsupportedOperation()
/*     */   {
/* 324 */     throw new UnsupportedOperationException("Modifying immutable object");
/*     */   }
/*     */ 
/*     */   public static int hashCode(boolean b)
/*     */   {
/* 329 */     return ProtocolSupport.hashCode(b);
/*     */   }
/*     */ 
/*     */   public static int hashCode(int i)
/*     */   {
/* 334 */     return ProtocolSupport.hashCode(i);
/*     */   }
/*     */ 
/*     */   public static int hashCode(long l)
/*     */   {
/* 339 */     return ProtocolSupport.hashCode(l);
/*     */   }
/*     */ 
/*     */   public static int hashCode(float f)
/*     */   {
/* 344 */     return ProtocolSupport.hashCode(f);
/*     */   }
/*     */ 
/*     */   public static int hashCode(double d)
/*     */   {
/* 349 */     return ProtocolSupport.hashCode(d);
/*     */   }
/*     */ 
/*     */   public static <T> T[] growArray(T[] array)
/*     */   {
/* 354 */     return ProtocolSupport.growArray(array);
/*     */   }
/*     */ 
/*     */   public static boolean[] growArray(boolean[] array)
/*     */   {
/* 359 */     return ProtocolSupport.growArray(array);
/*     */   }
/*     */ 
/*     */   public static int[] growArray(int[] array)
/*     */   {
/* 364 */     return ProtocolSupport.growArray(array);
/*     */   }
/*     */ 
/*     */   public static long[] growArray(long[] array)
/*     */   {
/* 369 */     return ProtocolSupport.growArray(array);
/*     */   }
/*     */ 
/*     */   public static float[] growArray(float[] array)
/*     */   {
/* 374 */     return ProtocolSupport.growArray(array);
/*     */   }
/*     */ 
/*     */   public static double[] growArray(double[] array)
/*     */   {
/* 379 */     return ProtocolSupport.growArray(array);
/*     */   }
/*     */ 
/*     */   public static boolean[] ensureCapacity(boolean[] array, int size)
/*     */   {
/* 386 */     return ProtocolSupport.ensureCapacity(array, size);
/*     */   }
/*     */ 
/*     */   public static int[] ensureCapacity(int[] array, int size)
/*     */   {
/* 391 */     return ProtocolSupport.ensureCapacity(array, size);
/*     */   }
/*     */ 
/*     */   public static long[] ensureCapacity(long[] array, int size)
/*     */   {
/* 396 */     return ProtocolSupport.ensureCapacity(array, size);
/*     */   }
/*     */ 
/*     */   public static float[] ensureCapacity(float[] array, int size)
/*     */   {
/* 401 */     return ProtocolSupport.ensureCapacity(array, size);
/*     */   }
/*     */ 
/*     */   public static double[] ensureCapacity(double[] array, int size)
/*     */   {
/* 406 */     return ProtocolSupport.ensureCapacity(array, size);
/*     */   }
/*     */ 
/*     */   public static List<Integer> asList(int[] array, int start, int end)
/*     */   {
/* 411 */     return ProtocolSupport.asList(array, start, end);
/*     */   }
/*     */ 
/*     */   public static List<Long> asList(long[] array, int start, int end)
/*     */   {
/* 416 */     return ProtocolSupport.asList(array, start, end);
/*     */   }
/*     */ 
/*     */   public static List<Float> asList(float[] array, int start, int end)
/*     */   {
/* 421 */     return ProtocolSupport.asList(array, start, end);
/*     */   }
/*     */ 
/*     */   public static List<Double> asList(double[] array, int start, int end)
/*     */   {
/* 426 */     return ProtocolSupport.asList(array, start, end);
/*     */   }
/*     */ 
/*     */   public static List<Boolean> asList(boolean[] array, int start, int end)
/*     */   {
/* 431 */     return ProtocolSupport.asList(array, start, end);
/*     */   }
/*     */ 
/*     */   public static Iterator<String> byteArrayToUnicodeIterator(List<byte[]> data)
/*     */   {
/* 439 */     return ProtocolSupport.byteArrayToUnicodeIterator(data);
/*     */   }
/*     */ 
/*     */   public static Iterator<String> byteArrayToUnicodeIterator(List<byte[]> data, Charset cs)
/*     */   {
/* 448 */     return ProtocolSupport.byteArrayToUnicodeIterator(data, cs);
/*     */   }
/*     */ 
/*     */   public static List<String> byteArrayToUnicodeList(List<byte[]> data)
/*     */   {
/* 456 */     return ProtocolSupport.byteArrayToUnicodeList(data);
/*     */   }
/*     */ 
/*     */   public static List<String> byteArrayToUnicodeList(List<byte[]> data, Charset cs)
/*     */   {
/* 465 */     return ProtocolSupport.byteArrayToUnicodeList(data, cs);
/*     */   }
/*     */ 
/*     */   public static byte[] toBytes(String str, Charset charset)
/*     */   {
/* 470 */     return ProtocolSupport.toBytes(str, charset);
/*     */   }
/*     */ 
/*     */   public static byte[] toBytesUtf8(String str)
/*     */   {
/* 475 */     return ProtocolSupport.toBytesUtf8(str);
/*     */   }
/*     */ 
/*     */   public static String toString(byte[] data, Charset charset)
/*     */   {
/* 480 */     return ProtocolSupport.toString(data, charset);
/*     */   }
/*     */ 
/*     */   public static String toStringUtf8(byte[] data)
/*     */   {
/* 485 */     return ProtocolSupport.toStringUtf8(data);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 319 */     EMPTY_BYTE_ARRAY = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.Protocol
 * JD-Core Version:    0.6.0
 */