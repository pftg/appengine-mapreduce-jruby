/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.Beta;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Predicates
/*     */ {
/* 353 */   private static final Joiner commaJoiner = Joiner.on(",");
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Predicate<T> alwaysTrue()
/*     */   {
/*  57 */     return AlwaysTruePredicate.INSTANCE;
/*     */   }
/*     */ 
/*     */   @GwtCompatible(serializable=true)
/*     */   public static <T> Predicate<T> alwaysFalse()
/*     */   {
/*  66 */     return AlwaysFalsePredicate.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> isNull()
/*     */   {
/*  75 */     return IsNullPredicate.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> notNull()
/*     */   {
/*  84 */     return NotNullPredicate.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> not(Predicate<T> predicate)
/*     */   {
/*  92 */     return new NotPredicate(predicate);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> and(Iterable<? extends Predicate<? super T>> components)
/*     */   {
/* 106 */     return new AndPredicate(defensiveCopy(components), null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> and(Predicate<? super T>[] components)
/*     */   {
/* 119 */     return new AndPredicate(defensiveCopy(components), null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> and(Predicate<? super T> first, Predicate<? super T> second)
/*     */   {
/* 130 */     return new AndPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> or(Iterable<? extends Predicate<? super T>> components)
/*     */   {
/* 145 */     return new OrPredicate(defensiveCopy(components), null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> or(Predicate<? super T>[] components)
/*     */   {
/* 158 */     return new OrPredicate(defensiveCopy(components), null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> or(Predicate<? super T> first, Predicate<? super T> second)
/*     */   {
/* 169 */     return new OrPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> equalTo(@Nullable T target)
/*     */   {
/* 178 */     return target == null ? isNull() : new IsEqualToPredicate(target, null);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("Class.isInstance")
/*     */   public static Predicate<Object> instanceOf(Class<?> clazz)
/*     */   {
/* 194 */     return new InstanceOfPredicate(clazz, null);
/*     */   }
/*     */ 
/*     */   public static <T> Predicate<T> in(Collection<? extends T> target)
/*     */   {
/* 210 */     return new InPredicate(target, null);
/*     */   }
/*     */ 
/*     */   public static <A, B> Predicate<A> compose(Predicate<B> predicate, Function<A, ? extends B> function)
/*     */   {
/* 221 */     return new CompositionPredicate(predicate, function, null);
/*     */   }
/*     */ 
/*     */   @Beta
/*     */   @GwtIncompatible("java.util.regex.Pattern")
/*     */   public static Predicate<CharSequence> containsPattern(String pattern)
/*     */   {
/* 236 */     return new ContainsPatternPredicate(pattern);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.util.regex.Pattern")
/*     */   public static Predicate<CharSequence> contains(Pattern pattern)
/*     */   {
/* 249 */     return new ContainsPatternPredicate(pattern);
/*     */   }
/*     */ 
/*     */   private static boolean iterableElementsEqual(Iterable<?> iterable1, Iterable<?> iterable2)
/*     */   {
/* 600 */     Iterator iterator1 = iterable1.iterator();
/* 601 */     Iterator iterator2 = iterable2.iterator();
/* 602 */     while (iterator1.hasNext()) {
/* 603 */       if (!iterator2.hasNext()) {
/* 604 */         return false;
/*     */       }
/* 606 */       if (!iterator1.next().equals(iterator2.next())) {
/* 607 */         return false;
/*     */       }
/*     */     }
/* 610 */     return !iterator2.hasNext();
/*     */   }
/*     */ 
/*     */   private static <T> List<Predicate<? super T>> asList(Predicate<? super T> first, Predicate<? super T> second)
/*     */   {
/* 616 */     return Arrays.asList(new Predicate[] { first, second });
/*     */   }
/*     */ 
/*     */   private static <T> List<T> defensiveCopy(T[] array) {
/* 620 */     return defensiveCopy(Arrays.asList(array));
/*     */   }
/*     */ 
/*     */   static <T> List<T> defensiveCopy(Iterable<T> iterable) {
/* 624 */     ArrayList list = new ArrayList();
/* 625 */     for (Iterator i$ = iterable.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 626 */       list.add(Preconditions.checkNotNull(element));
/*     */     }
/* 628 */     return list;
/*     */   }
/*     */ 
/*     */   private static class CompositionPredicate<A, B>
/*     */     implements Predicate<A>, Serializable
/*     */   {
/*     */     final Predicate<B> p;
/*     */     final Function<A, ? extends B> f;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private CompositionPredicate(Predicate<B> p, Function<A, ? extends B> f)
/*     */     {
/* 548 */       this.p = ((Predicate)Preconditions.checkNotNull(p));
/* 549 */       this.f = ((Function)Preconditions.checkNotNull(f));
/*     */     }
/*     */ 
/*     */     public boolean apply(A a) {
/* 553 */       return this.p.apply(this.f.apply(a));
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 557 */       if ((obj instanceof CompositionPredicate)) {
/* 558 */         CompositionPredicate that = (CompositionPredicate)obj;
/* 559 */         return (this.f.equals(that.f)) && (this.p.equals(that.p));
/*     */       }
/* 561 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 578 */       return this.f.hashCode() ^ this.p.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 582 */       return this.p.toString() + "(" + this.f.toString() + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InPredicate<T>
/*     */     implements Predicate<T>, Serializable
/*     */   {
/*     */     private final Collection<?> target;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private InPredicate(Collection<?> target)
/*     */     {
/* 510 */       this.target = ((Collection)Preconditions.checkNotNull(target));
/*     */     }
/*     */ 
/*     */     public boolean apply(T t) {
/*     */       try {
/* 515 */         return this.target.contains(t);
/*     */       } catch (NullPointerException e) {
/* 517 */         return false; } catch (ClassCastException e) {
/*     */       }
/* 519 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj)
/*     */     {
/* 524 */       if ((obj instanceof InPredicate)) {
/* 525 */         InPredicate that = (InPredicate)obj;
/* 526 */         return this.target.equals(that.target);
/*     */       }
/* 528 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 532 */       return this.target.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 536 */       return "In(" + this.target + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum NotNullPredicate
/*     */     implements Predicate<Object>
/*     */   {
/* 495 */     INSTANCE;
/*     */ 
/*     */     public boolean apply(@Nullable Object o) {
/* 498 */       return o != null;
/*     */     }
/*     */     public String toString() {
/* 501 */       return "NotNull";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum IsNullPredicate
/*     */     implements Predicate<Object>
/*     */   {
/* 482 */     INSTANCE;
/*     */ 
/*     */     public boolean apply(@Nullable Object o) {
/* 485 */       return o == null;
/*     */     }
/*     */     public String toString() {
/* 488 */       return "IsNull";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InstanceOfPredicate
/*     */     implements Predicate<Object>, Serializable
/*     */   {
/*     */     private final Class<?> clazz;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private InstanceOfPredicate(Class<?> clazz)
/*     */     {
/* 458 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/*     */     }
/*     */     public boolean apply(@Nullable Object o) {
/* 461 */       return Platform.isInstance(this.clazz, o);
/*     */     }
/*     */     public int hashCode() {
/* 464 */       return this.clazz.hashCode();
/*     */     }
/*     */     public boolean equals(@Nullable Object obj) {
/* 467 */       if ((obj instanceof InstanceOfPredicate)) {
/* 468 */         InstanceOfPredicate that = (InstanceOfPredicate)obj;
/* 469 */         return this.clazz == that.clazz;
/*     */       }
/* 471 */       return false;
/*     */     }
/*     */     public String toString() {
/* 474 */       return "IsInstanceOf(" + this.clazz.getName() + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class IsEqualToPredicate<T>
/*     */     implements Predicate<T>, Serializable
/*     */   {
/*     */     private final T target;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private IsEqualToPredicate(T target)
/*     */     {
/* 431 */       this.target = target;
/*     */     }
/*     */     public boolean apply(T t) {
/* 434 */       return this.target.equals(t);
/*     */     }
/*     */     public int hashCode() {
/* 437 */       return this.target.hashCode();
/*     */     }
/*     */     public boolean equals(@Nullable Object obj) {
/* 440 */       if ((obj instanceof IsEqualToPredicate)) {
/* 441 */         IsEqualToPredicate that = (IsEqualToPredicate)obj;
/* 442 */         return this.target.equals(that.target);
/*     */       }
/* 444 */       return false;
/*     */     }
/*     */     public String toString() {
/* 447 */       return "IsEqualTo(" + this.target + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class OrPredicate<T>
/*     */     implements Predicate<T>, Serializable
/*     */   {
/*     */     private final Iterable<? extends Predicate<? super T>> components;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private OrPredicate(Iterable<? extends Predicate<? super T>> components)
/*     */     {
/* 395 */       this.components = components;
/*     */     }
/*     */     public boolean apply(T t) {
/* 398 */       for (Predicate predicate : this.components) {
/* 399 */         if (predicate.apply(t)) {
/* 400 */           return true;
/*     */         }
/*     */       }
/* 403 */       return false;
/*     */     }
/*     */     public int hashCode() {
/* 406 */       int result = 0;
/* 407 */       for (Predicate predicate : this.components) {
/* 408 */         result |= predicate.hashCode();
/*     */       }
/* 410 */       return result;
/*     */     }
/*     */     public boolean equals(@Nullable Object obj) {
/* 413 */       if ((obj instanceof OrPredicate)) {
/* 414 */         OrPredicate that = (OrPredicate)obj;
/* 415 */         return Predicates.access$600(this.components, that.components);
/*     */       }
/* 417 */       return false;
/*     */     }
/*     */     public String toString() {
/* 420 */       return "Or(" + Predicates.commaJoiner.join(this.components) + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AndPredicate<T>
/*     */     implements Predicate<T>, Serializable
/*     */   {
/*     */     private final Iterable<? extends Predicate<? super T>> components;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private AndPredicate(Iterable<? extends Predicate<? super T>> components)
/*     */     {
/* 360 */       this.components = components;
/*     */     }
/*     */     public boolean apply(T t) {
/* 363 */       for (Predicate predicate : this.components) {
/* 364 */         if (!predicate.apply(t)) {
/* 365 */           return false;
/*     */         }
/*     */       }
/* 368 */       return true;
/*     */     }
/*     */     public int hashCode() {
/* 371 */       int result = -1;
/* 372 */       for (Predicate predicate : this.components) {
/* 373 */         result &= predicate.hashCode();
/*     */       }
/* 375 */       return result;
/*     */     }
/*     */     public boolean equals(@Nullable Object obj) {
/* 378 */       if ((obj instanceof AndPredicate)) {
/* 379 */         AndPredicate that = (AndPredicate)obj;
/* 380 */         return Predicates.access$600(this.components, that.components);
/*     */       }
/* 382 */       return false;
/*     */     }
/*     */     public String toString() {
/* 385 */       return "And(" + Predicates.commaJoiner.join(this.components) + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class NotPredicate<T>
/*     */     implements Predicate<T>, Serializable
/*     */   {
/*     */     final Predicate<T> predicate;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     NotPredicate(Predicate<T> predicate)
/*     */     {
/* 332 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*     */     }
/*     */     public boolean apply(T t) {
/* 335 */       return !this.predicate.apply(t);
/*     */     }
/*     */     public int hashCode() {
/* 338 */       return this.predicate.hashCode() ^ 0xFFFFFFFF;
/*     */     }
/*     */     public boolean equals(@Nullable Object obj) {
/* 341 */       if ((obj instanceof NotPredicate)) {
/* 342 */         NotPredicate that = (NotPredicate)obj;
/* 343 */         return this.predicate.equals(that.predicate);
/*     */       }
/* 345 */       return false;
/*     */     }
/*     */     public String toString() {
/* 348 */       return "Not(" + this.predicate.toString() + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum AlwaysFalsePredicate
/*     */     implements Predicate<Object>
/*     */   {
/* 317 */     INSTANCE;
/*     */ 
/*     */     public boolean apply(@Nullable Object o) {
/* 320 */       return false;
/*     */     }
/*     */     public String toString() {
/* 323 */       return "AlwaysFalse";
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum AlwaysTruePredicate
/*     */     implements Predicate<Object>
/*     */   {
/* 304 */     INSTANCE;
/*     */ 
/*     */     public boolean apply(@Nullable Object o) {
/* 307 */       return true;
/*     */     }
/*     */     public String toString() {
/* 310 */       return "AlwaysTrue";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ContainsPatternPredicate
/*     */     implements Predicate<CharSequence>, Serializable
/*     */   {
/*     */     final Pattern pattern;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     ContainsPatternPredicate(Pattern pattern)
/*     */     {
/* 261 */       this.pattern = ((Pattern)Preconditions.checkNotNull(pattern));
/*     */     }
/*     */ 
/*     */     ContainsPatternPredicate(String patternStr) {
/* 265 */       this(Pattern.compile(patternStr));
/*     */     }
/*     */ 
/*     */     public boolean apply(CharSequence t) {
/* 269 */       return this.pattern.matcher(t).find();
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 276 */       return Objects.hashCode(new Object[] { this.pattern.pattern(), Integer.valueOf(this.pattern.flags()) });
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 280 */       if ((obj instanceof ContainsPatternPredicate)) {
/* 281 */         ContainsPatternPredicate that = (ContainsPatternPredicate)obj;
/*     */ 
/* 285 */         return (Objects.equal(this.pattern.pattern(), that.pattern.pattern())) && (Objects.equal(Integer.valueOf(this.pattern.flags()), Integer.valueOf(that.pattern.flags())));
/*     */       }
/*     */ 
/* 288 */       return false;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 292 */       return Objects.toStringHelper(this).add("pattern", this.pattern).add("pattern.flags", Integer.toHexString(this.pattern.flags())).toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Predicates
 * JD-Core Version:    0.6.0
 */