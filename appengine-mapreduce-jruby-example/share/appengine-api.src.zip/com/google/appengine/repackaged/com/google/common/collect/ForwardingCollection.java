/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingCollection<E> extends ForwardingObject
/*    */   implements Collection<E>
/*    */ {
/*    */   protected abstract Collection<E> delegate();
/*    */ 
/*    */   public Iterator<E> iterator()
/*    */   {
/* 43 */     return delegate().iterator();
/*    */   }
/*    */ 
/*    */   public int size() {
/* 47 */     return delegate().size();
/*    */   }
/*    */ 
/*    */   public boolean removeAll(Collection<?> collection) {
/* 51 */     return delegate().removeAll(collection);
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 55 */     return delegate().isEmpty();
/*    */   }
/*    */ 
/*    */   public boolean contains(Object object) {
/* 59 */     return delegate().contains(object);
/*    */   }
/*    */ 
/*    */   public Object[] toArray() {
/* 63 */     return delegate().toArray();
/*    */   }
/*    */ 
/*    */   public <T> T[] toArray(T[] array) {
/* 67 */     return delegate().toArray(array);
/*    */   }
/*    */ 
/*    */   public boolean add(E element) {
/* 71 */     return delegate().add(element);
/*    */   }
/*    */ 
/*    */   public boolean remove(Object object) {
/* 75 */     return delegate().remove(object);
/*    */   }
/*    */ 
/*    */   public boolean containsAll(Collection<?> collection) {
/* 79 */     return delegate().containsAll(collection);
/*    */   }
/*    */ 
/*    */   public boolean addAll(Collection<? extends E> collection) {
/* 83 */     return delegate().addAll(collection);
/*    */   }
/*    */ 
/*    */   public boolean retainAll(Collection<?> collection) {
/* 87 */     return delegate().retainAll(collection);
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 91 */     delegate().clear();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingCollection
 * JD-Core Version:    0.6.0
 */