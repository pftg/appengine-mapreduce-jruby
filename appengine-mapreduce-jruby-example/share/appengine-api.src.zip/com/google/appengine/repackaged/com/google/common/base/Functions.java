/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Functions
/*     */ {
/*     */   public static Function<Object, String> toStringFunction()
/*     */   {
/*  46 */     return ToStringFunction.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <E> Function<E, E> identity()
/*     */   {
/*  68 */     return IdentityFunction.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <K, V> Function<K, V> forMap(Map<K, V> map)
/*     */   {
/*  89 */     return new FunctionForMapNoDefault(map);
/*     */   }
/*     */ 
/*     */   public static <K, V> Function<K, V> forMap(Map<K, ? extends V> map, @Nullable V defaultValue)
/*     */   {
/* 135 */     return new ForMapWithDefault(map, defaultValue);
/*     */   }
/*     */ 
/*     */   public static <A, B, C> Function<A, C> compose(Function<B, C> g, Function<A, ? extends B> f)
/*     */   {
/* 180 */     return new FunctionComposition(g, f);
/*     */   }
/*     */ 
/*     */   public static <T> Function<T, Boolean> forPredicate(Predicate<T> predicate)
/*     */   {
/* 219 */     return new PredicateFunction(predicate, null);
/*     */   }
/*     */ 
/*     */   public static <E> Function<Object, E> constant(@Nullable E value)
/*     */   {
/* 260 */     return new ConstantFunction(value);
/*     */   }
/*     */   private static class ConstantFunction<E> implements Function<Object, E>, Serializable { private final E value;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/* 267 */     public ConstantFunction(@Nullable E value) { this.value = value; }
/*     */ 
/*     */     public E apply(@Nullable Object from)
/*     */     {
/* 271 */       return this.value;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 275 */       if ((obj instanceof ConstantFunction)) {
/* 276 */         ConstantFunction that = (ConstantFunction)obj;
/* 277 */         return Objects.equal(this.value, that.value);
/*     */       }
/* 279 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 283 */       return this.value == null ? 0 : this.value.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 287 */       return "constant(" + this.value + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PredicateFunction<T>
/*     */     implements Function<T, Boolean>, Serializable
/*     */   {
/*     */     private final Predicate<T> predicate;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     private PredicateFunction(Predicate<T> predicate)
/*     */     {
/* 227 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*     */     }
/*     */ 
/*     */     public Boolean apply(T t) {
/* 231 */       return Boolean.valueOf(this.predicate.apply(t));
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 235 */       if ((obj instanceof PredicateFunction)) {
/* 236 */         PredicateFunction that = (PredicateFunction)obj;
/* 237 */         return this.predicate.equals(that.predicate);
/*     */       }
/* 239 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 243 */       return this.predicate.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 247 */       return "forPredicate(" + this.predicate + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FunctionComposition<A, B, C>
/*     */     implements Function<A, C>, Serializable
/*     */   {
/*     */     private final Function<B, C> g;
/*     */     private final Function<A, ? extends B> f;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     public FunctionComposition(Function<B, C> g, Function<A, ? extends B> f)
/*     */     {
/* 188 */       this.g = ((Function)Preconditions.checkNotNull(g));
/* 189 */       this.f = ((Function)Preconditions.checkNotNull(f));
/*     */     }
/*     */ 
/*     */     public C apply(A a) {
/* 193 */       return this.g.apply(this.f.apply(a));
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 197 */       if ((obj instanceof FunctionComposition)) {
/* 198 */         FunctionComposition that = (FunctionComposition)obj;
/* 199 */         return (this.f.equals(that.f)) && (this.g.equals(that.g));
/*     */       }
/* 201 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 205 */       return this.f.hashCode() ^ this.g.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 209 */       return this.g.toString() + "(" + this.f.toString() + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ForMapWithDefault<K, V>
/*     */     implements Function<K, V>, Serializable
/*     */   {
/*     */     final Map<K, ? extends V> map;
/*     */     final V defaultValue;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     ForMapWithDefault(Map<K, ? extends V> map, V defaultValue)
/*     */     {
/* 143 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 144 */       this.defaultValue = defaultValue;
/*     */     }
/*     */ 
/*     */     public V apply(K key) {
/* 148 */       return this.map.containsKey(key) ? this.map.get(key) : this.defaultValue;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object o) {
/* 152 */       if ((o instanceof ForMapWithDefault)) {
/* 153 */         ForMapWithDefault that = (ForMapWithDefault)o;
/* 154 */         return (this.map.equals(that.map)) && (Objects.equal(this.defaultValue, that.defaultValue));
/*     */       }
/* 156 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 160 */       return Objects.hashCode(new Object[] { this.map, this.defaultValue });
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 164 */       return "forMap(" + this.map + ", defaultValue=" + this.defaultValue + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FunctionForMapNoDefault<K, V>
/*     */     implements Function<K, V>, Serializable
/*     */   {
/*     */     final Map<K, V> map;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     FunctionForMapNoDefault(Map<K, V> map)
/*     */     {
/*  96 */       this.map = ((Map)Preconditions.checkNotNull(map));
/*     */     }
/*     */ 
/*     */     public V apply(K key) {
/* 100 */       Object result = this.map.get(key);
/* 101 */       Preconditions.checkArgument((result != null) || (this.map.containsKey(key)), "Key '%s' not present in map", new Object[] { key });
/* 102 */       return result;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object o) {
/* 106 */       if ((o instanceof FunctionForMapNoDefault)) {
/* 107 */         FunctionForMapNoDefault that = (FunctionForMapNoDefault)o;
/* 108 */         return this.map.equals(that.map);
/*     */       }
/* 110 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 114 */       return this.map.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 118 */       return "forMap(" + this.map + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum IdentityFunction
/*     */     implements Function<Object, Object>
/*     */   {
/*  73 */     INSTANCE;
/*     */ 
/*     */     public Object apply(Object o) {
/*  76 */       return o;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  80 */       return "identity";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum ToStringFunction
/*     */     implements Function<Object, String>
/*     */   {
/*  51 */     INSTANCE;
/*     */ 
/*     */     public String apply(Object o) {
/*  54 */       Preconditions.checkNotNull(o);
/*  55 */       return o.toString();
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  59 */       return "toString";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Functions
 * JD-Core Version:    0.6.0
 */