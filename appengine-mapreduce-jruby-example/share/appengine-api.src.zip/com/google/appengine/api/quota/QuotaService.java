/*    */ package com.google.appengine.api.quota;
/*    */ 
/*    */ public abstract interface QuotaService
/*    */ {
/*    */   public abstract boolean supports(DataType paramDataType);
/*    */ 
/*    */   public abstract long getApiTimeInMegaCycles();
/*    */ 
/*    */   public abstract long getCpuTimeInMegaCycles();
/*    */ 
/*    */   public abstract double convertMegacyclesToCpuSeconds(long paramLong);
/*    */ 
/*    */   public abstract long convertCpuSecondsToMegacycles(double paramDouble);
/*    */ 
/*    */   public static enum DataType
/*    */   {
/* 17 */     API_TIME_IN_MEGACYCLES, 
/* 18 */     CPU_TIME_IN_MEGACYCLES;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.quota.QuotaService
 * JD-Core Version:    0.6.0
 */