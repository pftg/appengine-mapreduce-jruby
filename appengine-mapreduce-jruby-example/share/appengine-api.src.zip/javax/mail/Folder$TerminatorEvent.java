/*      */ package javax.mail;
/*      */ 
/*      */ import javax.mail.event.MailEvent;
/*      */ 
/*      */ class Folder$TerminatorEvent extends MailEvent
/*      */ {
/*      */   private static final long serialVersionUID = 3765761925441296565L;
/*      */ 
/*      */   Folder$TerminatorEvent()
/*      */   {
/* 1619 */     super(new Object());
/*      */   }
/*      */ 
/*      */   public void dispatch(Object listener)
/*      */   {
/* 1624 */     Thread.currentThread().interrupt();
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Folder.TerminatorEvent
 * JD-Core Version:    0.6.0
 */