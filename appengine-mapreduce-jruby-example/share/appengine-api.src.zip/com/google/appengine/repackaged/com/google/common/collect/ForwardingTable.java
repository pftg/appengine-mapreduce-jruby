/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public abstract class ForwardingTable<R, C, V> extends ForwardingObject
/*     */   implements Table<R, C, V>
/*     */ {
/*     */   protected abstract Table<R, C, V> delegate();
/*     */ 
/*     */   public Set<Table.Cell<R, C, V>> cellSet()
/*     */   {
/*  45 */     return delegate().cellSet();
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  49 */     delegate().clear();
/*     */   }
/*     */ 
/*     */   public Map<R, V> column(C columnKey) {
/*  53 */     return delegate().column(columnKey);
/*     */   }
/*     */ 
/*     */   public Set<C> columnKeySet() {
/*  57 */     return delegate().columnKeySet();
/*     */   }
/*     */ 
/*     */   public Map<C, Map<R, V>> columnMap() {
/*  61 */     return delegate().columnMap();
/*     */   }
/*     */ 
/*     */   public boolean contains(Object rowKey, Object columnKey) {
/*  65 */     return delegate().contains(rowKey, columnKey);
/*     */   }
/*     */ 
/*     */   public boolean containsColumn(Object columnKey) {
/*  69 */     return delegate().containsColumn(columnKey);
/*     */   }
/*     */ 
/*     */   public boolean containsRow(Object rowKey) {
/*  73 */     return delegate().containsRow(rowKey);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/*  77 */     return delegate().containsValue(value);
/*     */   }
/*     */ 
/*     */   public V get(Object rowKey, Object columnKey) {
/*  81 */     return delegate().get(rowKey, columnKey);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  85 */     return delegate().isEmpty();
/*     */   }
/*     */ 
/*     */   public V put(R rowKey, C columnKey, V value) {
/*  89 */     return delegate().put(rowKey, columnKey, value);
/*     */   }
/*     */ 
/*     */   public void putAll(Table<? extends R, ? extends C, ? extends V> table) {
/*  93 */     delegate().putAll(table);
/*     */   }
/*     */ 
/*     */   public V remove(Object rowKey, Object columnKey) {
/*  97 */     return delegate().remove(rowKey, columnKey);
/*     */   }
/*     */ 
/*     */   public Map<C, V> row(R rowKey) {
/* 101 */     return delegate().row(rowKey);
/*     */   }
/*     */ 
/*     */   public Set<R> rowKeySet() {
/* 105 */     return delegate().rowKeySet();
/*     */   }
/*     */ 
/*     */   public Map<R, Map<C, V>> rowMap() {
/* 109 */     return delegate().rowMap();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 113 */     return delegate().size();
/*     */   }
/*     */ 
/*     */   public Collection<V> values() {
/* 117 */     return delegate().values();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 121 */     return (obj == this) || (delegate().equals(obj));
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 125 */     return delegate().hashCode();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingTable
 * JD-Core Version:    0.6.0
 */