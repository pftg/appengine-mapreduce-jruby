/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Formatter;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class Log2Formatter extends Formatter
/*     */ {
/*     */   private DateFormat dateFormatter;
/*     */ 
/*     */   public Log2Formatter()
/*     */   {
/*  37 */     this.dateFormatter = new SimpleDateFormat("yyMMdd HH:mm:ss.SSS");
/*     */   }
/*     */ 
/*     */   public Log2Formatter(DateFormat val)
/*     */   {
/*  44 */     this.dateFormatter = val;
/*     */   }
/*     */ 
/*     */   public String format(LogRecord rec)
/*     */   {
/*  55 */     String threadTag = LogContext.getThreadTag();
/*  56 */     if (threadTag == null)
/*  57 */       threadTag = "";
/*     */     else {
/*  59 */       threadTag = threadTag + " ";
/*     */     }
/*     */ 
/*  67 */     StringBuilder sb = new StringBuilder();
/*  68 */     String timestamp = this.dateFormatter.format(new Date(rec.getMillis()));
/*  69 */     char levelPrefix = getLevelPrefix(rec.getLevel().intValue());
/*  70 */     StringTokenizer tokenizer = new StringTokenizer(formatMessage(rec), "\n");
/*     */ 
/*  72 */     while (tokenizer.hasMoreTokens()) {
/*  73 */       sb.append(timestamp);
/*  74 */       sb.append(':');
/*  75 */       sb.append(levelPrefix);
/*  76 */       sb.append(' ');
/*  77 */       sb.append(threadTag);
/*  78 */       sb.append(tokenizer.nextToken());
/*  79 */       sb.append("\n");
/*  80 */       levelPrefix = ' ';
/*     */     }
/*     */ 
/*  86 */     Throwable thrown = rec.getThrown();
/*  87 */     if (thrown != null) {
/*  88 */       StringWriter sw = new StringWriter();
/*  89 */       PrintWriter pw = new PrintWriter(sw);
/*  90 */       thrown.printStackTrace(pw);
/*  91 */       pw.flush();
/*  92 */       sb.append(sw.toString());
/*     */     }
/*  94 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private char getLevelPrefix(int recLevel)
/*     */   {
/* 103 */     if (recLevel >= Level.WARNING.intValue())
/* 104 */       return 'X';
/* 105 */     if (recLevel <= Level.FINE.intValue()) {
/* 106 */       return 'D';
/*     */     }
/* 108 */     return 'I';
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Log2Formatter
 * JD-Core Version:    0.6.0
 */