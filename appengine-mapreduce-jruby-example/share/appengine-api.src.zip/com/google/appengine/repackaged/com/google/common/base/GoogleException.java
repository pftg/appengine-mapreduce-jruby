/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ 
/*     */ @GoogleInternal
/*     */ public class GoogleException extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String internalMessage;
/*  19 */   private String externalMessage = "A system error has occurred";
/*     */ 
/*     */   public GoogleException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GoogleException(Throwable t)
/*     */   {
/*  30 */     super(t);
/*  31 */     setInternalMessage(Throwables.getStackTraceAsString(t));
/*     */   }
/*     */ 
/*     */   public GoogleException(Throwable t, String externalMessage)
/*     */   {
/*  42 */     super(externalMessage, t);
/*  43 */     setInternalMessage(Throwables.getStackTraceAsString(t));
/*  44 */     setExternalMessage(externalMessage);
/*     */   }
/*     */ 
/*     */   public GoogleException(String internalMessage)
/*     */   {
/*  52 */     super(internalMessage);
/*  53 */     setInternalMessage(internalMessage);
/*     */   }
/*     */ 
/*     */   public GoogleException(String internalMessage, String externalMessage)
/*     */   {
/*  63 */     super(internalMessage);
/*  64 */     setInternalMessage(internalMessage);
/*  65 */     setExternalMessage(externalMessage);
/*     */   }
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/*  74 */     return -999;
/*     */   }
/*     */ 
/*     */   public String getInternalMessage()
/*     */   {
/*  83 */     return this.internalMessage;
/*     */   }
/*     */ 
/*     */   public void setInternalMessage(String s) {
/*  87 */     this.internalMessage = s;
/*     */   }
/*     */ 
/*     */   public String getExternalMessage()
/*     */   {
/*  95 */     return this.externalMessage;
/*     */   }
/*     */ 
/*     */   public void setExternalMessage(String s) {
/*  99 */     this.externalMessage = s;
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 106 */     return getInternalMessage();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.GoogleException
 * JD-Core Version:    0.6.0
 */