/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*     */ import com.google.apphosting.api.ApiBasePb.VoidProto;
/*     */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*     */ import com.google.apphosting.api.DatastorePb.CommitResponse;
/*     */ import com.google.apphosting.api.DatastorePb.Transaction;
/*     */ 
/*     */ class TransactionImpl
/*     */   implements Transaction
/*     */ {
/*     */   private final ApiProxy.ApiConfig apiConfig;
/*     */   private final String app;
/*     */   private final long handle;
/*     */   private final TransactionStack txnStack;
/*  31 */   TransactionState state = TransactionState.BEGUN;
/*     */ 
/*     */   TransactionImpl(ApiProxy.ApiConfig apiConfig, String app, long handle, TransactionStack txnStack) {
/*  34 */     this.apiConfig = apiConfig;
/*  35 */     this.app = app;
/*  36 */     this.handle = handle;
/*  37 */     this.txnStack = txnStack;
/*     */   }
/*     */ 
/*     */   void makeSyncCall(String methodName, ProtocolMessage<?> request, ProtocolMessage<?> response)
/*     */   {
/*  42 */     DatastoreApiHelper.makeSyncCall(this.apiConfig, methodName, request, response);
/*     */   }
/*     */ 
/*     */   private void makeSyncCall(String methodName, ProtocolMessage<?> response) {
/*  46 */     if (this.state != TransactionState.BEGUN) {
/*  47 */       throw new IllegalStateException("Transaction is in state " + this.state + ".  There is no legal " + "transition out of this state.");
/*     */     }
/*     */ 
/*  51 */     DatastorePb.Transaction txn = new DatastorePb.Transaction();
/*  52 */     txn.setApp(this.app);
/*  53 */     txn.setHandle(this.handle);
/*     */     try
/*     */     {
/*  56 */       makeSyncCall(methodName, txn, response);
/*     */     }
/*     */     catch (RuntimeException rte) {
/*  59 */       this.state = TransactionState.ERROR;
/*  60 */       throw rte;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void commit() {
/*     */     try {
/*  66 */       makeSyncCall("Commit", new DatastorePb.CommitResponse());
/*  67 */       this.state = TransactionState.COMMITTED;
/*     */     }
/*     */     finally
/*     */     {
/*  71 */       this.txnStack.remove(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void rollback() {
/*     */     try {
/*  77 */       makeSyncCall("Rollback", new ApiBasePb.VoidProto());
/*  78 */       this.state = TransactionState.ROLLED_BACK;
/*     */     }
/*     */     finally
/*     */     {
/*  82 */       this.txnStack.remove(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getApp() {
/*  87 */     return this.app;
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/*  93 */     return Long.toString(this.handle);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  98 */     if (this == o) {
/*  99 */       return true;
/*     */     }
/* 101 */     if ((o == null) || (getClass() != o.getClass())) {
/* 102 */       return false;
/*     */     }
/*     */ 
/* 105 */     TransactionImpl that = (TransactionImpl)o;
/*     */ 
/* 107 */     return this.handle == that.handle;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 112 */     return (int)(this.handle ^ this.handle >>> 32);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 117 */     return "Txn [" + this.app + "." + this.handle + ", " + this.state + "]";
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/* 121 */     return this.state == TransactionState.BEGUN;
/*     */   }
/*     */ 
/*     */   static void ensureTxnActive(Transaction txn)
/*     */   {
/* 129 */     if ((txn != null) && (!txn.isActive()))
/* 130 */       throw new IllegalStateException("Transaction with which this operation is associated is not active.");
/*     */   }
/*     */ 
/*     */   static enum TransactionState
/*     */   {
/*  20 */     BEGUN, COMMITTED, ROLLED_BACK, ERROR;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.TransactionImpl
 * JD-Core Version:    0.6.0
 */