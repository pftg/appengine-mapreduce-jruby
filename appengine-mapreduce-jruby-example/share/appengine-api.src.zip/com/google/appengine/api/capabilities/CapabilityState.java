/*    */ package com.google.appengine.api.capabilities;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class CapabilityState
/*    */ {
/*    */   private final Capability capability;
/*    */   private final CapabilityStatus status;
/*    */   private final Date scheduledDate;
/*    */ 
/*    */   CapabilityState(Capability capability, CapabilityStatus status, long timeUntilScheduled)
/*    */   {
/* 26 */     this.capability = capability;
/* 27 */     this.status = status;
/* 28 */     if (timeUntilScheduled >= 0L)
/* 29 */       this.scheduledDate = new Date(System.currentTimeMillis() + 1000L * timeUntilScheduled);
/*    */     else
/* 31 */       this.scheduledDate = null;
/*    */   }
/*    */ 
/*    */   public Capability getCapability()
/*    */   {
/* 41 */     return this.capability;
/*    */   }
/*    */ 
/*    */   public CapabilityStatus getStatus()
/*    */   {
/* 50 */     return this.status;
/*    */   }
/*    */ 
/*    */   public Date getScheduledDate()
/*    */   {
/* 63 */     return this.scheduledDate;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.CapabilityState
 * JD-Core Version:    0.6.0
 */