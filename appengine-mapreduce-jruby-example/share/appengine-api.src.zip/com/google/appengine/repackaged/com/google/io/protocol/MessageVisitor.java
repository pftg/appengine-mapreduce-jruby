package com.google.appengine.repackaged.com.google.io.protocol;

import java.nio.ByteBuffer;

public abstract interface MessageVisitor extends ProtocolType.Visitor
{
  public abstract boolean shouldVisitField(ProtocolType.FieldType paramFieldType, int paramInt);

  public abstract void visitBoolean(ProtocolType.FieldType paramFieldType, int paramInt, boolean paramBoolean);

  public abstract void visitInteger(ProtocolType.FieldType paramFieldType, int paramInt1, int paramInt2);

  public abstract void visitLong(ProtocolType.FieldType paramFieldType, int paramInt, long paramLong);

  public abstract void visitByteArray(ProtocolType.FieldType paramFieldType, int paramInt, byte[] paramArrayOfByte);

  public abstract void visitString(ProtocolType.FieldType paramFieldType, int paramInt, String paramString);

  public abstract void visitFloat(ProtocolType.FieldType paramFieldType, int paramInt, float paramFloat);

  public abstract void visitDouble(ProtocolType.FieldType paramFieldType, int paramInt, double paramDouble);

  public abstract void visitGroup(ProtocolType.FieldType paramFieldType, int paramInt, ProtocolMessage paramProtocolMessage);

  public abstract void visitForeign(ProtocolType.FieldType paramFieldType, int paramInt, ProtocolMessage paramProtocolMessage);

  public abstract void visitRawMessage(ByteBuffer paramByteBuffer);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.MessageVisitor
 * JD-Core Version:    0.6.0
 */