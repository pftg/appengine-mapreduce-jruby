/*   */ package com.google.appengine.api.urlfetch;
/*   */ 
/*   */ public class URLFetchServiceFactory
/*   */ {
/*   */   public static URLFetchService getURLFetchService()
/*   */   {
/* 7 */     return new URLFetchServiceImpl();
/*   */   }
/*   */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.URLFetchServiceFactory
 * JD-Core Version:    0.6.0
 */