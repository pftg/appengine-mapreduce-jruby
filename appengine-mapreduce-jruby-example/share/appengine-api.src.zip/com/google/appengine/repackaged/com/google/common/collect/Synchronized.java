/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import com.google.common.annotations.GwtIncompatible;
/*      */ import com.google.common.annotations.VisibleForTesting;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.RandomAccess;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GwtCompatible(emulated=true)
/*      */ final class Synchronized
/*      */ {
/*      */   private static <E> Collection<E> collection(Collection<E> collection, @Nullable Object mutex)
/*      */   {
/*   96 */     return new SynchronizedCollection(collection, mutex, null);
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static <E> Set<E> set(Set<E> set, @Nullable Object mutex)
/*      */   {
/*  191 */     return new SynchronizedSet(set, mutex, null);
/*      */   }
/*      */ 
/*      */   private static <E> SortedSet<E> sortedSet(SortedSet<E> set, @Nullable Object mutex)
/*      */   {
/*  224 */     return new SynchronizedSortedSet(set, mutex);
/*      */   }
/*      */ 
/*      */   private static <E> List<E> list(List<E> list, @Nullable Object mutex)
/*      */   {
/*  277 */     return (list instanceof RandomAccess) ? new SynchronizedRandomAccessList(list, mutex) : new SynchronizedList(list, mutex);
/*      */   }
/*      */ 
/*      */   static <E> Multiset<E> multiset(Multiset<E> multiset, @Nullable Object mutex)
/*      */   {
/*  376 */     return new SynchronizedMultiset(multiset, mutex);
/*      */   }
/*      */ 
/*      */   static <K, V> Multimap<K, V> multimap(Multimap<K, V> multimap, @Nullable Object mutex)
/*      */   {
/*  460 */     return new SynchronizedMultimap(multimap, mutex);
/*      */   }
/*      */ 
/*      */   static <K, V> ListMultimap<K, V> listMultimap(ListMultimap<K, V> multimap, @Nullable Object mutex)
/*      */   {
/*  623 */     return new SynchronizedListMultimap(multimap, mutex);
/*      */   }
/*      */ 
/*      */   static <K, V> SetMultimap<K, V> setMultimap(SetMultimap<K, V> multimap, @Nullable Object mutex)
/*      */   {
/*  656 */     return new SynchronizedSetMultimap(multimap, mutex);
/*      */   }
/*      */ 
/*      */   static <K, V> SortedSetMultimap<K, V> sortedSetMultimap(SortedSetMultimap<K, V> multimap, @Nullable Object mutex)
/*      */   {
/*  699 */     return new SynchronizedSortedSetMultimap(multimap, mutex);
/*      */   }
/*      */ 
/*      */   private static <E> Collection<E> typePreservingCollection(Collection<E> collection, @Nullable Object mutex)
/*      */   {
/*  737 */     if ((collection instanceof SortedSet)) {
/*  738 */       return sortedSet((SortedSet)collection, mutex);
/*      */     }
/*  740 */     if ((collection instanceof Set)) {
/*  741 */       return set((Set)collection, mutex);
/*      */     }
/*  743 */     if ((collection instanceof List)) {
/*  744 */       return list((List)collection, mutex);
/*      */     }
/*  746 */     return collection(collection, mutex);
/*      */   }
/*      */ 
/*      */   private static <E> Set<E> typePreservingSet(Set<E> set, @Nullable Object mutex)
/*      */   {
/*  751 */     if ((set instanceof SortedSet)) {
/*  752 */       return sortedSet((SortedSet)set, mutex);
/*      */     }
/*  754 */     return set(set, mutex);
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static <K, V> Map<K, V> map(Map<K, V> map, @Nullable Object mutex)
/*      */   {
/*  838 */     return new SynchronizedMap(map, mutex, null);
/*      */   }
/*      */ 
/*      */   static <K, V> BiMap<K, V> biMap(BiMap<K, V> bimap, @Nullable Object mutex)
/*      */   {
/*  956 */     return new SynchronizedBiMap(bimap, mutex, null, null);
/*      */   }
/*      */ 
/*      */   private static class SynchronizedAsMapValues<V> extends Synchronized.SynchronizedCollection<Collection<V>>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedAsMapValues(Collection<Collection<V>> delegate, @Nullable Object mutex)
/*      */     {
/* 1051 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     public Iterator<Collection<V>> iterator()
/*      */     {
/* 1056 */       Iterator iterator = super.iterator();
/* 1057 */       return new ForwardingIterator(iterator) {
/*      */         protected Iterator<Collection<V>> delegate() {
/* 1059 */           return this.val$iterator;
/*      */         }
/*      */         public Collection<V> next() {
/* 1062 */           return Synchronized.access$500((Collection)this.val$iterator.next(), Synchronized.SynchronizedAsMapValues.this.mutex);
/*      */         }
/*      */       };
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedAsMap<K, V> extends Synchronized.SynchronizedMap<K, Collection<V>>
/*      */   {
/*      */     transient Set<Map.Entry<K, Collection<V>>> asMapEntrySet;
/*      */     transient Collection<Collection<V>> asMapValues;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedAsMap(Map<K, Collection<V>> delegate, @Nullable Object mutex)
/*      */     {
/* 1008 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     public Collection<V> get(Object key) {
/* 1012 */       synchronized (this.mutex) {
/* 1013 */         Collection collection = (Collection)super.get(key);
/* 1014 */         return collection == null ? null : Synchronized.access$500(collection, this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, Collection<V>>> entrySet()
/*      */     {
/* 1020 */       synchronized (this.mutex) {
/* 1021 */         if (this.asMapEntrySet == null) {
/* 1022 */           this.asMapEntrySet = new Synchronized.SynchronizedAsMapEntries(delegate().entrySet(), this.mutex);
/*      */         }
/*      */ 
/* 1025 */         return this.asMapEntrySet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<Collection<V>> values() {
/* 1030 */       synchronized (this.mutex) {
/* 1031 */         if (this.asMapValues == null) {
/* 1032 */           this.asMapValues = new Synchronized.SynchronizedAsMapValues(delegate().values(), this.mutex);
/*      */         }
/*      */ 
/* 1035 */         return this.asMapValues;
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsValue(Object o)
/*      */     {
/* 1041 */       return values().contains(o);
/*      */     }
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static class SynchronizedBiMap<K, V> extends Synchronized.SynchronizedMap<K, V>
/*      */     implements BiMap<K, V>, Serializable
/*      */   {
/*      */     private transient Set<V> valueSet;
/*      */     private transient BiMap<V, K> inverse;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     private SynchronizedBiMap(BiMap<K, V> delegate, @Nullable Object mutex, @Nullable BiMap<V, K> inverse)
/*      */     {
/*  966 */       super(mutex, null);
/*  967 */       this.inverse = inverse;
/*      */     }
/*      */ 
/*      */     BiMap<K, V> delegate() {
/*  971 */       return (BiMap)super.delegate();
/*      */     }
/*      */ 
/*      */     public Set<V> values() {
/*  975 */       synchronized (this.mutex) {
/*  976 */         if (this.valueSet == null) {
/*  977 */           this.valueSet = Synchronized.set(delegate().values(), this.mutex);
/*      */         }
/*  979 */         return this.valueSet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public V forcePut(K key, V value) {
/*  984 */       synchronized (this.mutex) {
/*  985 */         return delegate().forcePut(key, value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public BiMap<V, K> inverse() {
/*  990 */       synchronized (this.mutex) {
/*  991 */         if (this.inverse == null) {
/*  992 */           this.inverse = new SynchronizedBiMap(delegate().inverse(), this.mutex, this);
/*      */         }
/*      */ 
/*  995 */         return this.inverse;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedMap<K, V> extends Synchronized.SynchronizedObject
/*      */     implements Map<K, V>
/*      */   {
/*      */     transient Set<K> keySet;
/*      */     transient Collection<V> values;
/*      */     transient Set<Map.Entry<K, V>> entrySet;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     private SynchronizedMap(Map<K, V> delegate, @Nullable Object mutex)
/*      */     {
/*  848 */       super(mutex);
/*      */     }
/*      */ 
/*      */     Map<K, V> delegate()
/*      */     {
/*  853 */       return (Map)super.delegate();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  857 */       synchronized (this.mutex) {
/*  858 */         delegate().clear();
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  863 */       synchronized (this.mutex) {
/*  864 */         return delegate().containsKey(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsValue(Object value) {
/*  869 */       synchronized (this.mutex) {
/*  870 */         return delegate().containsValue(value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, V>> entrySet() {
/*  875 */       synchronized (this.mutex) {
/*  876 */         if (this.entrySet == null) {
/*  877 */           this.entrySet = Synchronized.set(delegate().entrySet(), this.mutex);
/*      */         }
/*  879 */         return this.entrySet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public V get(Object key) {
/*  884 */       synchronized (this.mutex) {
/*  885 */         return delegate().get(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/*  890 */       synchronized (this.mutex) {
/*  891 */         return delegate().isEmpty();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<K> keySet() {
/*  896 */       synchronized (this.mutex) {
/*  897 */         if (this.keySet == null) {
/*  898 */           this.keySet = Synchronized.set(delegate().keySet(), this.mutex);
/*      */         }
/*  900 */         return this.keySet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public V put(K key, V value) {
/*  905 */       synchronized (this.mutex) {
/*  906 */         return delegate().put(key, value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void putAll(Map<? extends K, ? extends V> map) {
/*  911 */       synchronized (this.mutex) {
/*  912 */         delegate().putAll(map);
/*      */       }
/*      */     }
/*      */ 
/*      */     public V remove(Object key) {
/*  917 */       synchronized (this.mutex) {
/*  918 */         return delegate().remove(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int size() {
/*  923 */       synchronized (this.mutex) {
/*  924 */         return delegate().size();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<V> values() {
/*  929 */       synchronized (this.mutex) {
/*  930 */         if (this.values == null) {
/*  931 */           this.values = Synchronized.access$600(delegate().values(), this.mutex);
/*      */         }
/*  933 */         return this.values;
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean equals(Object o) {
/*  938 */       if (o == this) {
/*  939 */         return true;
/*      */       }
/*  941 */       synchronized (this.mutex) {
/*  942 */         return delegate().equals(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  947 */       synchronized (this.mutex) {
/*  948 */         return delegate().hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedAsMapEntries<K, V> extends Synchronized.SynchronizedSet<Map.Entry<K, Collection<V>>>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedAsMapEntries(Set<Map.Entry<K, Collection<V>>> delegate, @Nullable Object mutex)
/*      */     {
/*  762 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     public Iterator<Map.Entry<K, Collection<V>>> iterator()
/*      */     {
/*  767 */       Iterator iterator = super.iterator();
/*  768 */       return new ForwardingIterator(iterator) {
/*      */         protected Iterator<Map.Entry<K, Collection<V>>> delegate() {
/*  770 */           return this.val$iterator;
/*      */         }
/*      */ 
/*      */         public Map.Entry<K, Collection<V>> next() {
/*  774 */           Map.Entry entry = (Map.Entry)this.val$iterator.next();
/*  775 */           return new ForwardingMapEntry(entry) {
/*      */             protected Map.Entry<K, Collection<V>> delegate() {
/*  777 */               return this.val$entry;
/*      */             }
/*      */             public Collection<V> getValue() {
/*  780 */               return Synchronized.access$500((Collection)this.val$entry.getValue(), Synchronized.SynchronizedAsMapEntries.this.mutex);
/*      */             }
/*      */           };
/*      */         }
/*      */       };
/*      */     }
/*      */ 
/*      */     public Object[] toArray() {
/*  790 */       synchronized (this.mutex) {
/*  791 */         return ObjectArrays.toArrayImpl(delegate());
/*      */       }
/*      */     }
/*      */ 
/*      */     public <T> T[] toArray(T[] array) {
/*  795 */       synchronized (this.mutex) {
/*  796 */         return ObjectArrays.toArrayImpl(delegate(), array);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/*  800 */       synchronized (this.mutex) {
/*  801 */         return Maps.containsEntryImpl(delegate(), o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsAll(Collection<?> c) {
/*  805 */       synchronized (this.mutex) {
/*  806 */         return Collections2.containsAll(delegate(), c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean equals(Object o) {
/*  810 */       if (o == this) {
/*  811 */         return true;
/*      */       }
/*  813 */       synchronized (this.mutex) {
/*  814 */         return Collections2.setEquals(delegate(), o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean remove(Object o) {
/*  818 */       synchronized (this.mutex) {
/*  819 */         return Maps.removeEntryImpl(delegate(), o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean removeAll(Collection<?> c) {
/*  823 */       synchronized (this.mutex) {
/*  824 */         return Iterators.removeAll(delegate().iterator(), c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean retainAll(Collection<?> c) {
/*  828 */       synchronized (this.mutex) {
/*  829 */         return Iterators.retainAll(delegate().iterator(), c);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedSortedSetMultimap<K, V> extends Synchronized.SynchronizedSetMultimap<K, V>
/*      */     implements SortedSetMultimap<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedSortedSetMultimap(SortedSetMultimap<K, V> delegate, @Nullable Object mutex)
/*      */     {
/*  706 */       super(mutex);
/*      */     }
/*      */     SortedSetMultimap<K, V> delegate() {
/*  709 */       return (SortedSetMultimap)super.delegate();
/*      */     }
/*      */     public SortedSet<V> get(K key) {
/*  712 */       synchronized (this.mutex) {
/*  713 */         return Synchronized.access$200(delegate().get(key), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public SortedSet<V> removeAll(Object key) {
/*  717 */       synchronized (this.mutex) {
/*  718 */         return delegate().removeAll(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values) {
/*  723 */       synchronized (this.mutex) {
/*  724 */         return delegate().replaceValues(key, values);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Comparator<? super V> valueComparator() {
/*  728 */       synchronized (this.mutex) {
/*  729 */         return delegate().valueComparator();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedSetMultimap<K, V> extends Synchronized.SynchronizedMultimap<K, V>
/*      */     implements SetMultimap<K, V>
/*      */   {
/*      */     transient Set<Map.Entry<K, V>> entrySet;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedSetMultimap(SetMultimap<K, V> delegate, @Nullable Object mutex)
/*      */     {
/*  665 */       super(mutex);
/*      */     }
/*      */     SetMultimap<K, V> delegate() {
/*  668 */       return (SetMultimap)super.delegate();
/*      */     }
/*      */     public Set<V> get(K key) {
/*  671 */       synchronized (this.mutex) {
/*  672 */         return Synchronized.set(delegate().get(key), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<V> removeAll(Object key) {
/*  676 */       synchronized (this.mutex) {
/*  677 */         return delegate().removeAll(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<V> replaceValues(K key, Iterable<? extends V> values) {
/*  682 */       synchronized (this.mutex) {
/*  683 */         return delegate().replaceValues(key, values);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<K, V>> entries() {
/*  687 */       synchronized (this.mutex) {
/*  688 */         if (this.entrySet == null) {
/*  689 */           this.entrySet = Synchronized.set(delegate().entries(), this.mutex);
/*      */         }
/*  691 */         return this.entrySet;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedListMultimap<K, V> extends Synchronized.SynchronizedMultimap<K, V>
/*      */     implements ListMultimap<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedListMultimap(ListMultimap<K, V> delegate, @Nullable Object mutex)
/*      */     {
/*  630 */       super(mutex);
/*      */     }
/*      */     ListMultimap<K, V> delegate() {
/*  633 */       return (ListMultimap)super.delegate();
/*      */     }
/*      */     public List<V> get(K key) {
/*  636 */       synchronized (this.mutex) {
/*  637 */         return Synchronized.access$300(delegate().get(key), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public List<V> removeAll(Object key) {
/*  641 */       synchronized (this.mutex) {
/*  642 */         return delegate().removeAll(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public List<V> replaceValues(K key, Iterable<? extends V> values) {
/*  647 */       synchronized (this.mutex) {
/*  648 */         return delegate().replaceValues(key, values);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedMultimap<K, V> extends Synchronized.SynchronizedObject
/*      */     implements Multimap<K, V>
/*      */   {
/*      */     transient Set<K> keySet;
/*      */     transient Collection<V> valuesCollection;
/*      */     transient Collection<Map.Entry<K, V>> entries;
/*      */     transient Map<K, Collection<V>> asMap;
/*      */     transient Multiset<K> keys;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     Multimap<K, V> delegate()
/*      */     {
/*  473 */       return (Multimap)super.delegate();
/*      */     }
/*      */ 
/*      */     SynchronizedMultimap(Multimap<K, V> delegate, @Nullable Object mutex) {
/*  477 */       super(mutex);
/*      */     }
/*      */ 
/*      */     public int size() {
/*  481 */       synchronized (this.mutex) {
/*  482 */         return delegate().size();
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/*  487 */       synchronized (this.mutex) {
/*  488 */         return delegate().isEmpty();
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  493 */       synchronized (this.mutex) {
/*  494 */         return delegate().containsKey(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsValue(Object value) {
/*  499 */       synchronized (this.mutex) {
/*  500 */         return delegate().containsValue(value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsEntry(Object key, Object value) {
/*  505 */       synchronized (this.mutex) {
/*  506 */         return delegate().containsEntry(key, value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<V> get(K key) {
/*  511 */       synchronized (this.mutex) {
/*  512 */         return Synchronized.access$500(delegate().get(key), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean put(K key, V value) {
/*  517 */       synchronized (this.mutex) {
/*  518 */         return delegate().put(key, value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean putAll(K key, Iterable<? extends V> values) {
/*  523 */       synchronized (this.mutex) {
/*  524 */         return delegate().putAll(key, values);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
/*  529 */       synchronized (this.mutex) {
/*  530 */         return delegate().putAll(multimap);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<V> replaceValues(K key, Iterable<? extends V> values) {
/*  535 */       synchronized (this.mutex) {
/*  536 */         return delegate().replaceValues(key, values);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean remove(Object key, Object value) {
/*  541 */       synchronized (this.mutex) {
/*  542 */         return delegate().remove(key, value);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<V> removeAll(Object key) {
/*  547 */       synchronized (this.mutex) {
/*  548 */         return delegate().removeAll(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  553 */       synchronized (this.mutex) {
/*  554 */         delegate().clear();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<K> keySet() {
/*  559 */       synchronized (this.mutex) {
/*  560 */         if (this.keySet == null) {
/*  561 */           this.keySet = Synchronized.access$400(delegate().keySet(), this.mutex);
/*      */         }
/*  563 */         return this.keySet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<V> values() {
/*  568 */       synchronized (this.mutex) {
/*  569 */         if (this.valuesCollection == null) {
/*  570 */           this.valuesCollection = Synchronized.access$600(delegate().values(), this.mutex);
/*      */         }
/*  572 */         return this.valuesCollection;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Collection<Map.Entry<K, V>> entries() {
/*  577 */       synchronized (this.mutex) {
/*  578 */         if (this.entries == null) {
/*  579 */           this.entries = Synchronized.access$500(delegate().entries(), this.mutex);
/*      */         }
/*  581 */         return this.entries;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Map<K, Collection<V>> asMap() {
/*  586 */       synchronized (this.mutex) {
/*  587 */         if (this.asMap == null) {
/*  588 */           this.asMap = new Synchronized.SynchronizedAsMap(delegate().asMap(), this.mutex);
/*      */         }
/*  590 */         return this.asMap;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Multiset<K> keys() {
/*  595 */       synchronized (this.mutex) {
/*  596 */         if (this.keys == null) {
/*  597 */           this.keys = Synchronized.multiset(delegate().keys(), this.mutex);
/*      */         }
/*  599 */         return this.keys;
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean equals(Object o) {
/*  604 */       if (o == this) {
/*  605 */         return true;
/*      */       }
/*  607 */       synchronized (this.mutex) {
/*  608 */         return delegate().equals(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  613 */       synchronized (this.mutex) {
/*  614 */         return delegate().hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedMultiset<E> extends Synchronized.SynchronizedCollection<E>
/*      */     implements Multiset<E>
/*      */   {
/*      */     transient Set<E> elementSet;
/*      */     transient Set<Multiset.Entry<E>> entrySet;
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedMultiset(Multiset<E> delegate, @Nullable Object mutex)
/*      */     {
/*  385 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     Multiset<E> delegate() {
/*  389 */       return (Multiset)super.delegate();
/*      */     }
/*      */ 
/*      */     public int count(Object o) {
/*  393 */       synchronized (this.mutex) {
/*  394 */         return delegate().count(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int add(E e, int n) {
/*  399 */       synchronized (this.mutex) {
/*  400 */         return delegate().add(e, n);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int remove(Object o, int n) {
/*  405 */       synchronized (this.mutex) {
/*  406 */         return delegate().remove(o, n);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int setCount(E element, int count) {
/*  411 */       synchronized (this.mutex) {
/*  412 */         return delegate().setCount(element, count);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean setCount(E element, int oldCount, int newCount) {
/*  417 */       synchronized (this.mutex) {
/*  418 */         return delegate().setCount(element, oldCount, newCount);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<E> elementSet() {
/*  423 */       synchronized (this.mutex) {
/*  424 */         if (this.elementSet == null) {
/*  425 */           this.elementSet = Synchronized.access$400(delegate().elementSet(), this.mutex);
/*      */         }
/*  427 */         return this.elementSet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<Multiset.Entry<E>> entrySet() {
/*  432 */       synchronized (this.mutex) {
/*  433 */         if (this.entrySet == null) {
/*  434 */           this.entrySet = Synchronized.access$400(delegate().entrySet(), this.mutex);
/*      */         }
/*  436 */         return this.entrySet;
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean equals(Object o) {
/*  441 */       if (o == this) {
/*  442 */         return true;
/*      */       }
/*  444 */       synchronized (this.mutex) {
/*  445 */         return delegate().equals(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  450 */       synchronized (this.mutex) {
/*  451 */         return delegate().hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedRandomAccessList<E> extends Synchronized.SynchronizedList<E>
/*      */     implements RandomAccess
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedRandomAccessList(List<E> list, @Nullable Object mutex)
/*      */     {
/*  369 */       super(mutex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedList<E> extends Synchronized.SynchronizedCollection<E>
/*      */     implements List<E>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedList(List<E> delegate, @Nullable Object mutex)
/*      */     {
/*  285 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     List<E> delegate() {
/*  289 */       return (List)super.delegate();
/*      */     }
/*      */ 
/*      */     public void add(int index, E element) {
/*  293 */       synchronized (this.mutex) {
/*  294 */         delegate().add(index, element);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean addAll(int index, Collection<? extends E> c) {
/*  299 */       synchronized (this.mutex) {
/*  300 */         return delegate().addAll(index, c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public E get(int index) {
/*  305 */       synchronized (this.mutex) {
/*  306 */         return delegate().get(index);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int indexOf(Object o) {
/*  311 */       synchronized (this.mutex) {
/*  312 */         return delegate().indexOf(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int lastIndexOf(Object o) {
/*  317 */       synchronized (this.mutex) {
/*  318 */         return delegate().lastIndexOf(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public ListIterator<E> listIterator() {
/*  323 */       return delegate().listIterator();
/*      */     }
/*      */ 
/*      */     public ListIterator<E> listIterator(int index) {
/*  327 */       return delegate().listIterator(index);
/*      */     }
/*      */ 
/*      */     public E remove(int index) {
/*  331 */       synchronized (this.mutex) {
/*  332 */         return delegate().remove(index);
/*      */       }
/*      */     }
/*      */ 
/*      */     public E set(int index, E element) {
/*  337 */       synchronized (this.mutex) {
/*  338 */         return delegate().set(index, element);
/*      */       }
/*      */     }
/*      */ 
/*      */     public List<E> subList(int fromIndex, int toIndex) {
/*  343 */       synchronized (this.mutex) {
/*  344 */         return Synchronized.access$300(delegate().subList(fromIndex, toIndex), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean equals(Object o) {
/*  349 */       if (o == this) {
/*  350 */         return true;
/*      */       }
/*  352 */       synchronized (this.mutex) {
/*  353 */         return delegate().equals(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  358 */       synchronized (this.mutex) {
/*  359 */         return delegate().hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedSortedSet<E> extends Synchronized.SynchronizedSet<E>
/*      */     implements SortedSet<E>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedSortedSet(SortedSet<E> delegate, @Nullable Object mutex)
/*      */     {
/*  230 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     SortedSet<E> delegate() {
/*  234 */       return (SortedSet)super.delegate();
/*      */     }
/*      */ 
/*      */     public Comparator<? super E> comparator() {
/*  238 */       synchronized (this.mutex) {
/*  239 */         return delegate().comparator();
/*      */       }
/*      */     }
/*      */ 
/*      */     public SortedSet<E> subSet(E fromElement, E toElement) {
/*  244 */       synchronized (this.mutex) {
/*  245 */         return Synchronized.access$200(delegate().subSet(fromElement, toElement), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public SortedSet<E> headSet(E toElement) {
/*  250 */       synchronized (this.mutex) {
/*  251 */         return Synchronized.access$200(delegate().headSet(toElement), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public SortedSet<E> tailSet(E fromElement) {
/*  256 */       synchronized (this.mutex) {
/*  257 */         return Synchronized.access$200(delegate().tailSet(fromElement), this.mutex);
/*      */       }
/*      */     }
/*      */ 
/*      */     public E first() {
/*  262 */       synchronized (this.mutex) {
/*  263 */         return delegate().first();
/*      */       }
/*      */     }
/*      */ 
/*      */     public E last() {
/*  268 */       synchronized (this.mutex) {
/*  269 */         return delegate().last();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static class SynchronizedSet<E> extends Synchronized.SynchronizedCollection<E>
/*      */     implements Set<E>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     private SynchronizedSet(Set<E> delegate, @Nullable Object mutex)
/*      */     {
/*  197 */       super(mutex, null);
/*      */     }
/*      */ 
/*      */     Set<E> delegate() {
/*  201 */       return (Set)super.delegate();
/*      */     }
/*      */ 
/*      */     public boolean equals(Object o) {
/*  205 */       if (o == this) {
/*  206 */         return true;
/*      */       }
/*  208 */       synchronized (this.mutex) {
/*  209 */         return delegate().equals(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  214 */       synchronized (this.mutex) {
/*  215 */         return delegate().hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static class SynchronizedCollection<E> extends Synchronized.SynchronizedObject
/*      */     implements Collection<E>
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     private SynchronizedCollection(Collection<E> delegate, @Nullable Object mutex)
/*      */     {
/*  103 */       super(mutex);
/*      */     }
/*      */ 
/*      */     Collection<E> delegate()
/*      */     {
/*  108 */       return (Collection)super.delegate();
/*      */     }
/*      */ 
/*      */     public boolean add(E e) {
/*  112 */       synchronized (this.mutex) {
/*  113 */         return delegate().add(e);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean addAll(Collection<? extends E> c) {
/*  118 */       synchronized (this.mutex) {
/*  119 */         return delegate().addAll(c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  124 */       synchronized (this.mutex) {
/*  125 */         delegate().clear();
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean contains(Object o) {
/*  130 */       synchronized (this.mutex) {
/*  131 */         return delegate().contains(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean containsAll(Collection<?> c) {
/*  136 */       synchronized (this.mutex) {
/*  137 */         return delegate().containsAll(c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean isEmpty() {
/*  142 */       synchronized (this.mutex) {
/*  143 */         return delegate().isEmpty();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Iterator<E> iterator() {
/*  148 */       return delegate().iterator();
/*      */     }
/*      */ 
/*      */     public boolean remove(Object o) {
/*  152 */       synchronized (this.mutex) {
/*  153 */         return delegate().remove(o);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean removeAll(Collection<?> c) {
/*  158 */       synchronized (this.mutex) {
/*  159 */         return delegate().removeAll(c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean retainAll(Collection<?> c) {
/*  164 */       synchronized (this.mutex) {
/*  165 */         return delegate().retainAll(c);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int size() {
/*  170 */       synchronized (this.mutex) {
/*  171 */         return delegate().size();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Object[] toArray() {
/*  176 */       synchronized (this.mutex) {
/*  177 */         return delegate().toArray();
/*      */       }
/*      */     }
/*      */ 
/*      */     public <T> T[] toArray(T[] a) {
/*  182 */       synchronized (this.mutex) {
/*  183 */         return delegate().toArray(a);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedObject
/*      */     implements Serializable
/*      */   {
/*      */     final Object delegate;
/*      */     final Object mutex;
/*      */ 
/*      */     @GwtIncompatible("not needed in emulated source")
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */     SynchronizedObject(Object delegate, @Nullable Object mutex)
/*      */     {
/*   62 */       this.delegate = Preconditions.checkNotNull(delegate);
/*   63 */       this.mutex = (mutex == null ? this : mutex);
/*      */     }
/*      */ 
/*      */     Object delegate() {
/*   67 */       return this.delegate;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*   73 */       synchronized (this.mutex) {
/*   74 */         return this.delegate.toString();
/*      */       }
/*      */     }
/*      */ 
/*      */     @GwtIncompatible("java.io.ObjectOutputStream")
/*      */     private void writeObject(ObjectOutputStream stream)
/*      */       throws IOException
/*      */     {
/*   85 */       synchronized (this.mutex) {
/*   86 */         stream.defaultWriteObject();
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Synchronized
 * JD-Core Version:    0.6.0
 */