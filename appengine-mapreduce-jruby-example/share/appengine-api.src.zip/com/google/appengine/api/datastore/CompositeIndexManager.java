/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.DatastorePb.Query;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Index;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Index.Property;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Index.Property.Direction;
/*     */ import java.util.List;
/*     */ 
/*     */ public class CompositeIndexManager
/*     */ {
/*     */   private static final String DATASTORE_INDEX_WITH_PROPERTIES_XML_FORMAT = "    <datastore-index kind=\"%s\" ancestor=\"%s\" source=\"%s\">\n%s    </datastore-index>\n\n";
/*     */   private static final String DATASTORE_INDEX_NO_PROPERTIES_XML_FORMAT = "    <datastore-index kind=\"%s\" ancestor=\"%s\" source=\"%s\"/>\n\n";
/*     */   private static final String PROPERTY_XML_FORMAT = "        <property name=\"%s\" direction=\"%s\"/>\n";
/*     */ 
/*     */   protected String generateXmlForIndex(OnestoreEntity.Index index, IndexSource source)
/*     */   {
/*  72 */     boolean isAncestor = index.isAncestor();
/*  73 */     if (index.propertySize() == 0) {
/*  74 */       return String.format("    <datastore-index kind=\"%s\" ancestor=\"%s\" source=\"%s\"/>\n\n", new Object[] { index.getEntityType(), Boolean.valueOf(isAncestor), source });
/*     */     }
/*     */ 
/*  78 */     StringBuilder sb = new StringBuilder();
/*  79 */     for (OnestoreEntity.Index.Property prop : index.propertys()) {
/*  80 */       String dir = prop.getDirectionEnum() == OnestoreEntity.Index.Property.Direction.ASCENDING ? "asc" : "desc";
/*  81 */       sb.append(String.format("        <property name=\"%s\" direction=\"%s\"/>\n", new Object[] { prop.getName(), dir }));
/*     */     }
/*  83 */     return String.format("    <datastore-index kind=\"%s\" ancestor=\"%s\" source=\"%s\">\n%s    </datastore-index>\n\n", new Object[] { index.getEntityType(), Boolean.valueOf(isAncestor), source, sb.toString() });
/*     */   }
/*     */ 
/*     */   protected OnestoreEntity.Index compositeIndexForQuery(IndexComponentsOnlyQuery indexOnlyQuery)
/*     */   {
/* 101 */     DatastorePb.Query query = indexOnlyQuery.getQuery();
/*     */ 
/* 103 */     boolean hasKind = query.hasKind();
/* 104 */     boolean hasAncestor = query.hasAncestor();
/* 105 */     List filters = query.filters();
/* 106 */     List orders = query.orders();
/*     */ 
/* 109 */     if ((filters.isEmpty()) && (orders.isEmpty()))
/*     */     {
/* 112 */       return null;
/*     */     }
/*     */ 
/* 116 */     List eqProps = indexOnlyQuery.getEqualityProps();
/* 117 */     List indexProperties = indexOnlyQuery.getIndexProps();
/*     */ 
/* 119 */     if ((hasKind) && (!eqProps.isEmpty()) && (eqProps.size() == filters.size()) && (!indexOnlyQuery.hasKeyProperty()) && (orders.isEmpty()))
/*     */     {
/* 129 */       return null;
/*     */     }
/*     */ 
/* 133 */     if ((hasKind) && (!hasAncestor) && (indexProperties.size() <= 1) && ((!indexOnlyQuery.hasKeyProperty()) || (((OnestoreEntity.Index.Property)indexProperties.get(0)).getDirectionEnum() == OnestoreEntity.Index.Property.Direction.ASCENDING)))
/*     */     {
/* 139 */       return null;
/*     */     }
/*     */ 
/* 142 */     OnestoreEntity.Index index = new OnestoreEntity.Index();
/* 143 */     index.setEntityType(query.getKind());
/* 144 */     index.setAncestor(hasAncestor);
/* 145 */     index.mutablePropertys().addAll(indexProperties);
/* 146 */     return index;
/*     */   }
/*     */ 
/*     */   protected static class ValidatedQuery extends ValidatedQuery
/*     */   {
/*     */     public ValidatedQuery(DatastorePb.Query query)
/*     */     {
/* 167 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class IndexComponentsOnlyQuery extends IndexComponentsOnlyQuery
/*     */   {
/*     */     public IndexComponentsOnlyQuery(DatastorePb.Query query)
/*     */     {
/* 156 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static enum IndexSource
/*     */   {
/*  52 */     auto, manual;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.CompositeIndexManager
 * JD-Core Version:    0.6.0
 */