/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import java.util.Comparator;
/*    */ import java.util.SortedMap;
/*    */ 
/*    */ @GwtCompatible
/*    */ public abstract class ForwardingSortedMap<K, V> extends ForwardingMap<K, V>
/*    */   implements SortedMap<K, V>
/*    */ {
/*    */   protected abstract SortedMap<K, V> delegate();
/*    */ 
/*    */   public Comparator<? super K> comparator()
/*    */   {
/* 43 */     return delegate().comparator();
/*    */   }
/*    */ 
/*    */   public K firstKey() {
/* 47 */     return delegate().firstKey();
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> headMap(K toKey) {
/* 51 */     return delegate().headMap(toKey);
/*    */   }
/*    */ 
/*    */   public K lastKey() {
/* 55 */     return delegate().lastKey();
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> subMap(K fromKey, K toKey) {
/* 59 */     return delegate().subMap(fromKey, toKey);
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> tailMap(K fromKey) {
/* 63 */     return delegate().tailMap(fromKey);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingSortedMap
 * JD-Core Version:    0.6.0
 */