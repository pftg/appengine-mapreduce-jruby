/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.appengine.repackaged.com.google.common.primitives.Primitives;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class MutableClassToInstanceMap<B> extends MapConstraints.ConstrainedMap<Class<? extends B>, B>
/*    */   implements ClassToInstanceMap<B>
/*    */ {
/* 59 */   private static final MapConstraint<Class<?>, Object> VALUE_CAN_BE_CAST_TO_KEY = new MapConstraint()
/*    */   {
/*    */     public void checkKeyValue(Class<?> key, Object value) {
/* 62 */       MutableClassToInstanceMap.access$000(key, value);
/*    */     }
/* 59 */   };
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public static <B> MutableClassToInstanceMap<B> create()
/*    */   {
/* 41 */     return new MutableClassToInstanceMap(new HashMap());
/*    */   }
/*    */ 
/*    */   public static <B> MutableClassToInstanceMap<B> create(Map<Class<? extends B>, B> backingMap)
/*    */   {
/* 52 */     return new MutableClassToInstanceMap(backingMap);
/*    */   }
/*    */ 
/*    */   private MutableClassToInstanceMap(Map<Class<? extends B>, B> delegate) {
/* 56 */     super(delegate, VALUE_CAN_BE_CAST_TO_KEY);
/*    */   }
/*    */ 
/*    */   public <T extends B> T putInstance(Class<T> type, T value)
/*    */   {
/* 67 */     return cast(type, put(type, value));
/*    */   }
/*    */ 
/*    */   public <T extends B> T getInstance(Class<T> type) {
/* 71 */     return cast(type, get(type));
/*    */   }
/*    */ 
/*    */   private static <B, T extends B> T cast(Class<T> type, B value) {
/* 75 */     return Primitives.wrap(type).cast(value);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.MutableClassToInstanceMap
 * JD-Core Version:    0.6.0
 */