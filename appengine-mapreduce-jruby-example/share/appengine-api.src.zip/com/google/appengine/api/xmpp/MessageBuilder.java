/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ public class MessageBuilder
/*    */ {
/* 13 */   private MessageType messageType = MessageType.CHAT;
/* 14 */   private boolean asXml = false;
/* 15 */   private String body = null;
/* 16 */   private JID fromJid = null;
/* 17 */   private JID[] recipientJids = null;
/* 18 */   private String stanza = null;
/*    */ 
/*    */   public MessageBuilder withMessageType(MessageType type) {
/* 21 */     this.messageType = type;
/* 22 */     return this;
/*    */   }
/*    */ 
/*    */   public MessageBuilder asXml(boolean asXml) {
/* 26 */     this.asXml = asXml;
/* 27 */     return this;
/*    */   }
/*    */ 
/*    */   public MessageBuilder withBody(String body) {
/* 31 */     this.body = body;
/* 32 */     return this;
/*    */   }
/*    */ 
/*    */   public MessageBuilder withFromJid(JID fromJid) {
/* 36 */     this.fromJid = fromJid;
/* 37 */     return this;
/*    */   }
/*    */ 
/*    */   public MessageBuilder withRecipientJids(JID[] recipientJids) {
/* 41 */     this.recipientJids = recipientJids;
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   MessageBuilder withStanza(String stanza)
/*    */   {
/* 48 */     this.stanza = stanza;
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */   public Message build() {
/* 53 */     if (this.body == null) {
/* 54 */       throw new IllegalArgumentException("Must set a body");
/*    */     }
/*    */ 
/* 57 */     if ((this.recipientJids == null) || (this.recipientJids.length == 0)) {
/* 58 */       throw new IllegalArgumentException("Must set recipient JIDs");
/*    */     }
/*    */ 
/* 61 */     return new Message(this.messageType, this.asXml, this.body, this.stanza, this.fromJid, this.recipientJids);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.MessageBuilder
 * JD-Core Version:    0.6.0
 */