package com.google.appengine.api.datastore;

import java.util.Iterator;

public abstract interface QueryResultIterator<T> extends Iterator<T>
{
  public abstract Cursor getCursor();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryResultIterator
 * JD-Core Version:    0.6.0
 */