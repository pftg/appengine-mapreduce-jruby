package com.google.appengine.repackaged.com.google.common.base;

public abstract interface FinalizableReference
{
  public abstract void finalizeReferent();
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.FinalizableReference
 * JD-Core Version:    0.6.0
 */