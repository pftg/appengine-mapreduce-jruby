/*      */ package com.google.appengine.api.channel;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ public class ChannelServicePb
/*      */ {
/*      */   public static class SendMessageRequest extends ProtocolMessage<SendMessageRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  803 */     private byte[] application_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  804 */     private byte[] message_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final SendMessageRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kapplication_key = 1;
/*      */     public static final int kmessage = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getApplicationKeyAsBytes()
/*      */     {
/*  810 */       return this.application_key_;
/*      */     }
/*      */     public final boolean hasApplicationKey() {
/*  813 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public SendMessageRequest clearApplicationKey() {
/*  816 */       this.optional_0_ &= -2;
/*  817 */       this.application_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  818 */       return this;
/*      */     }
/*      */     public SendMessageRequest setApplicationKeyAsBytes(byte[] x) {
/*  821 */       this.optional_0_ |= 1;
/*  822 */       this.application_key_ = x;
/*  823 */       return this;
/*      */     }
/*      */     public final String getApplicationKey() {
/*  826 */       return ProtocolSupport.toStringUtf8(this.application_key_);
/*      */     }
/*      */     public SendMessageRequest setApplicationKey(String v) {
/*  829 */       if (v == null) throw new NullPointerException();
/*  830 */       this.optional_0_ |= 1;
/*  831 */       this.application_key_ = ProtocolSupport.toBytesUtf8(v);
/*  832 */       return this;
/*      */     }
/*      */     public final String getApplicationKey(Charset cs) {
/*  835 */       return ProtocolSupport.toString(this.application_key_, cs);
/*      */     }
/*      */     public SendMessageRequest setApplicationKey(String v, Charset cs) {
/*  838 */       if (v == null) throw new NullPointerException();
/*  839 */       this.optional_0_ |= 1;
/*  840 */       this.application_key_ = ProtocolSupport.toBytes(v, cs);
/*  841 */       return this;
/*      */     }
/*      */ 
/*      */     public final byte[] getMessageAsBytes()
/*      */     {
/*  846 */       return this.message_;
/*      */     }
/*      */     public final boolean hasMessage() {
/*  849 */       return (this.optional_0_ & 0x2) != 0;
/*      */     }
/*      */     public SendMessageRequest clearMessage() {
/*  852 */       this.optional_0_ &= -3;
/*  853 */       this.message_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  854 */       return this;
/*      */     }
/*      */     public SendMessageRequest setMessageAsBytes(byte[] x) {
/*  857 */       this.optional_0_ |= 2;
/*  858 */       this.message_ = x;
/*  859 */       return this;
/*      */     }
/*      */     public final String getMessage() {
/*  862 */       return ProtocolSupport.toStringUtf8(this.message_);
/*      */     }
/*      */     public SendMessageRequest setMessage(String v) {
/*  865 */       if (v == null) throw new NullPointerException();
/*  866 */       this.optional_0_ |= 2;
/*  867 */       this.message_ = ProtocolSupport.toBytesUtf8(v);
/*  868 */       return this;
/*      */     }
/*      */     public final String getMessage(Charset cs) {
/*  871 */       return ProtocolSupport.toString(this.message_, cs);
/*      */     }
/*      */     public SendMessageRequest setMessage(String v, Charset cs) {
/*  874 */       if (v == null) throw new NullPointerException();
/*  875 */       this.optional_0_ |= 2;
/*  876 */       this.message_ = ProtocolSupport.toBytes(v, cs);
/*  877 */       return this;
/*      */     }
/*      */ 
/*      */     public SendMessageRequest mergeFrom(SendMessageRequest that)
/*      */     {
/*  884 */       assert (that != this);
/*  885 */       int this_t0 = this.optional_0_;
/*  886 */       int that_t0 = that.optional_0_;
/*      */ 
/*  888 */       if ((that_t0 & 0x1) != 0) {
/*  889 */         this_t0 |= 1;
/*  890 */         this.application_key_ = that.application_key_;
/*      */       }
/*      */ 
/*  893 */       if ((that_t0 & 0x2) != 0) {
/*  894 */         this_t0 |= 2;
/*  895 */         this.message_ = that.message_;
/*      */       }
/*      */ 
/*  898 */       if (that.uninterpreted != null) {
/*  899 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  901 */       this.optional_0_ = this_t0;
/*  902 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(SendMessageRequest that) {
/*  906 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(SendMessageRequest that) {
/*  910 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(SendMessageRequest that, boolean ignoreUninterpreted) {
/*  914 */       if (that == null) return false;
/*  915 */       if (that == this) return true;
/*  916 */       int this_t0 = this.optional_0_;
/*  917 */       int that_t0 = that.optional_0_;
/*  918 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  920 */       if (((this_t0 & 0x1) != 0) && 
/*  921 */         (!Arrays.equals(this.application_key_, that.application_key_))) return false;
/*      */ 
/*  924 */       if (((this_t0 & 0x2) != 0) && 
/*  925 */         (!Arrays.equals(this.message_, that.message_))) return false;
/*      */ 
/*  928 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  933 */       return ((that instanceof SendMessageRequest)) && (equals((SendMessageRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  937 */       int hash = 416334285;
/*      */ 
/*  939 */       int this_t0 = this.optional_0_;
/*  940 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.application_key_) : -113);
/*      */ 
/*  942 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.message_) : -113);
/*  943 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  944 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  946 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  950 */       int this_t0 = this.optional_0_;
/*  951 */       if ((this_t0 & 0x3) != 3)
/*      */       {
/*  953 */         return (this_t0 & 0x1) != 0;
/*      */       }
/*      */ 
/*  957 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  963 */       int n = 2 + Protocol.stringSize(this.application_key_.length) + Protocol.stringSize(this.message_.length);
/*      */ 
/*  966 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  973 */       int n = 12 + this.application_key_.length + this.message_.length;
/*      */ 
/*  975 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  980 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  984 */       this.optional_0_ = 0;
/*  985 */       this.application_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  986 */       this.message_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  987 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public SendMessageRequest newInstance() {
/*  991 */       return new SendMessageRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  995 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1018 */       sink.putByte(10);
/* 1019 */       sink.putPrefixedData(this.application_key_);
/*      */ 
/* 1021 */       sink.putByte(18);
/* 1022 */       sink.putPrefixedData(this.message_);
/*      */ 
/* 1024 */       if (this.uninterpreted != null)
/* 1025 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1030 */       boolean result = true;
/* 1031 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1033 */       while (source.hasRemaining()) {
/* 1034 */         int tt = source.getVarInt();
/* 1035 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1039 */           result = false;
/* 1040 */           break;
/*      */         case 10:
/* 1043 */           this.application_key_ = source.getPrefixedData();
/* 1044 */           this_t0 |= 1;
/* 1045 */           break;
/*      */         case 18:
/* 1048 */           this.message_ = source.getPrefixedData();
/* 1049 */           this_t0 |= 2;
/* 1050 */           break;
/*      */         default:
/* 1052 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1057 */       this.optional_0_ = this_t0;
/* 1058 */       return result;
/*      */     }
/*      */ 
/*      */     public SendMessageRequest getDefaultInstanceForType()
/*      */     {
/* 1063 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final SendMessageRequest getDefaultInstance() {
/* 1067 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public SendMessageRequest freeze()
/*      */     {
/* 1132 */       this.application_key_ = ProtocolSupport.freezeString(this.application_key_);
/* 1133 */       this.message_ = ProtocolSupport.freezeString(this.message_);
/* 1134 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1137 */       if (this.uninterpreted == null) {
/* 1138 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1140 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1071 */       IMMUTABLE_DEFAULT_INSTANCE = new SendMessageRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ChannelServicePb.SendMessageRequest clearApplicationKey()
/*      */         {
/* 1079 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest setApplicationKeyAsBytes(byte[] x) {
/* 1082 */           ProtocolSupport.unsupportedOperation();
/* 1083 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest setApplicationKey(String v) {
/* 1086 */           ProtocolSupport.unsupportedOperation();
/* 1087 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest setApplicationKey(String v, Charset cs) {
/* 1090 */           ProtocolSupport.unsupportedOperation();
/* 1091 */           return this;
/*      */         }
/*      */ 
/*      */         public ChannelServicePb.SendMessageRequest clearMessage()
/*      */         {
/* 1096 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest setMessageAsBytes(byte[] x) {
/* 1099 */           ProtocolSupport.unsupportedOperation();
/* 1100 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest setMessage(String v) {
/* 1103 */           ProtocolSupport.unsupportedOperation();
/* 1104 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest setMessage(String v, Charset cs) {
/* 1107 */           ProtocolSupport.unsupportedOperation();
/* 1108 */           return this;
/*      */         }
/*      */ 
/*      */         public ChannelServicePb.SendMessageRequest mergeFrom(ChannelServicePb.SendMessageRequest that) {
/* 1112 */           ProtocolSupport.unsupportedOperation();
/* 1113 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1116 */           ProtocolSupport.unsupportedOperation();
/* 1117 */           return false;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest freeze() {
/* 1120 */           return this;
/*      */         }
/*      */         public ChannelServicePb.SendMessageRequest unfreeze() {
/* 1123 */           ProtocolSupport.unsupportedOperation();
/* 1124 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1127 */           return true;
/*      */         }
/*      */       };
/* 1146 */       text = new String[3];
/*      */ 
/* 1148 */       text[0] = "ErrorCode";
/* 1149 */       text[1] = "application_key";
/* 1150 */       text[2] = "message";
/*      */ 
/* 1153 */       types = new int[3];
/*      */ 
/* 1155 */       Arrays.fill(types, 6);
/* 1156 */       types[0] = 0;
/* 1157 */       types[1] = 2;
/* 1158 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  999 */       private static final ProtocolType protocolType = new ProtocolType(ChannelServicePb.SendMessageRequest.class, "Z,apphosting/api/channel/channel_service.proto\n\035apphosting.SendMessageRequest\023\032\017application_key \001(\0020\t8\002\024\023\032\007message \002(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("application_key", "application_key", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("message", "message", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateChannelResponse extends ProtocolMessage<CreateChannelResponse>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  517 */     private byte[] client_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateChannelResponse IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kclient_id = 2;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getClientIdAsBytes()
/*      */     {
/*  523 */       return this.client_id_;
/*      */     }
/*      */     public final boolean hasClientId() {
/*  526 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateChannelResponse clearClientId() {
/*  529 */       this.optional_0_ &= -2;
/*  530 */       this.client_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  531 */       return this;
/*      */     }
/*      */     public CreateChannelResponse setClientIdAsBytes(byte[] x) {
/*  534 */       this.optional_0_ |= 1;
/*  535 */       this.client_id_ = x;
/*  536 */       return this;
/*      */     }
/*      */     public final String getClientId() {
/*  539 */       return ProtocolSupport.toStringUtf8(this.client_id_);
/*      */     }
/*      */     public CreateChannelResponse setClientId(String v) {
/*  542 */       if (v == null) throw new NullPointerException();
/*  543 */       this.optional_0_ |= 1;
/*  544 */       this.client_id_ = ProtocolSupport.toBytesUtf8(v);
/*  545 */       return this;
/*      */     }
/*      */     public final String getClientId(Charset cs) {
/*  548 */       return ProtocolSupport.toString(this.client_id_, cs);
/*      */     }
/*      */     public CreateChannelResponse setClientId(String v, Charset cs) {
/*  551 */       if (v == null) throw new NullPointerException();
/*  552 */       this.optional_0_ |= 1;
/*  553 */       this.client_id_ = ProtocolSupport.toBytes(v, cs);
/*  554 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateChannelResponse mergeFrom(CreateChannelResponse that)
/*      */     {
/*  561 */       assert (that != this);
/*  562 */       int this_t0 = this.optional_0_;
/*  563 */       int that_t0 = that.optional_0_;
/*      */ 
/*  565 */       if ((that_t0 & 0x1) != 0) {
/*  566 */         this_t0 |= 1;
/*  567 */         this.client_id_ = that.client_id_;
/*      */       }
/*      */ 
/*  570 */       if (that.uninterpreted != null) {
/*  571 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  573 */       this.optional_0_ = this_t0;
/*  574 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateChannelResponse that) {
/*  578 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateChannelResponse that) {
/*  582 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateChannelResponse that, boolean ignoreUninterpreted) {
/*  586 */       if (that == null) return false;
/*  587 */       if (that == this) return true;
/*  588 */       int this_t0 = this.optional_0_;
/*  589 */       int that_t0 = that.optional_0_;
/*  590 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  592 */       if (((this_t0 & 0x1) != 0) && 
/*  593 */         (!Arrays.equals(this.client_id_, that.client_id_))) return false;
/*      */ 
/*  596 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  601 */       return ((that instanceof CreateChannelResponse)) && (equals((CreateChannelResponse)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  605 */       int hash = 823526752;
/*      */ 
/*  607 */       int this_t0 = this.optional_0_;
/*  608 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.client_id_) : -113);
/*  609 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  610 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  612 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  616 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*  620 */       int n = 0;
/*  621 */       int this_t0 = this.optional_0_;
/*  622 */       if ((this_t0 & 0x1) != 0)
/*      */       {
/*  624 */         n += 1 + Protocol.stringSize(this.client_id_.length);
/*      */       }
/*      */ 
/*  627 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  632 */       int n = 0;
/*  633 */       int this_t0 = this.optional_0_;
/*  634 */       if ((this_t0 & 0x1) != 0)
/*      */       {
/*  636 */         n += 6 + this.client_id_.length;
/*      */       }
/*      */ 
/*  639 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  644 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  648 */       this.optional_0_ = 0;
/*  649 */       this.client_id_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  650 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateChannelResponse newInstance() {
/*  654 */       return new CreateChannelResponse();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  658 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  677 */       int this_t0 = this.optional_0_;
/*  678 */       if ((this_t0 & 0x1) != 0) {
/*  679 */         sink.putByte(18);
/*  680 */         sink.putPrefixedData(this.client_id_);
/*      */       }
/*      */ 
/*  683 */       if (this.uninterpreted != null)
/*  684 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  689 */       boolean result = true;
/*  690 */       int this_t0 = this.optional_0_;
/*      */ 
/*  692 */       while (source.hasRemaining()) {
/*  693 */         int tt = source.getVarInt();
/*  694 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  698 */           result = false;
/*  699 */           break;
/*      */         case 18:
/*  702 */           this.client_id_ = source.getPrefixedData();
/*  703 */           this_t0 |= 1;
/*  704 */           break;
/*      */         default:
/*  706 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  711 */       this.optional_0_ = this_t0;
/*  712 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateChannelResponse getDefaultInstanceForType()
/*      */     {
/*  717 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateChannelResponse getDefaultInstance() {
/*  721 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateChannelResponse freeze()
/*      */     {
/*  769 */       this.client_id_ = ProtocolSupport.freezeString(this.client_id_);
/*  770 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  773 */       if (this.uninterpreted == null) {
/*  774 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  776 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  725 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateChannelResponse()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ChannelServicePb.CreateChannelResponse clearClientId()
/*      */         {
/*  733 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelResponse setClientIdAsBytes(byte[] x) {
/*  736 */           ProtocolSupport.unsupportedOperation();
/*  737 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelResponse setClientId(String v) {
/*  740 */           ProtocolSupport.unsupportedOperation();
/*  741 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelResponse setClientId(String v, Charset cs) {
/*  744 */           ProtocolSupport.unsupportedOperation();
/*  745 */           return this;
/*      */         }
/*      */ 
/*      */         public ChannelServicePb.CreateChannelResponse mergeFrom(ChannelServicePb.CreateChannelResponse that) {
/*  749 */           ProtocolSupport.unsupportedOperation();
/*  750 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  753 */           ProtocolSupport.unsupportedOperation();
/*  754 */           return false;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelResponse freeze() {
/*  757 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelResponse unfreeze() {
/*  760 */           ProtocolSupport.unsupportedOperation();
/*  761 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  764 */           return true;
/*      */         }
/*      */       };
/*  781 */       text = new String[3];
/*      */ 
/*  783 */       text[0] = "ErrorCode";
/*  784 */       text[2] = "client_id";
/*      */ 
/*  787 */       types = new int[3];
/*      */ 
/*  789 */       Arrays.fill(types, 6);
/*  790 */       types[0] = 0;
/*  791 */       types[2] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  662 */       private static final ProtocolType protocolType = new ProtocolType(ChannelServicePb.CreateChannelResponse.class, "Z,apphosting/api/channel/channel_service.proto\n apphosting.CreateChannelResponse\023\032\tclient_id \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("client_id", "client_id", 2, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class CreateChannelRequest extends ProtocolMessage<CreateChannelRequest>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  237 */     private byte[] application_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final CreateChannelRequest IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kapplication_key = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getApplicationKeyAsBytes()
/*      */     {
/*  243 */       return this.application_key_;
/*      */     }
/*      */     public final boolean hasApplicationKey() {
/*  246 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public CreateChannelRequest clearApplicationKey() {
/*  249 */       this.optional_0_ &= -2;
/*  250 */       this.application_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  251 */       return this;
/*      */     }
/*      */     public CreateChannelRequest setApplicationKeyAsBytes(byte[] x) {
/*  254 */       this.optional_0_ |= 1;
/*  255 */       this.application_key_ = x;
/*  256 */       return this;
/*      */     }
/*      */     public final String getApplicationKey() {
/*  259 */       return ProtocolSupport.toStringUtf8(this.application_key_);
/*      */     }
/*      */     public CreateChannelRequest setApplicationKey(String v) {
/*  262 */       if (v == null) throw new NullPointerException();
/*  263 */       this.optional_0_ |= 1;
/*  264 */       this.application_key_ = ProtocolSupport.toBytesUtf8(v);
/*  265 */       return this;
/*      */     }
/*      */     public final String getApplicationKey(Charset cs) {
/*  268 */       return ProtocolSupport.toString(this.application_key_, cs);
/*      */     }
/*      */     public CreateChannelRequest setApplicationKey(String v, Charset cs) {
/*  271 */       if (v == null) throw new NullPointerException();
/*  272 */       this.optional_0_ |= 1;
/*  273 */       this.application_key_ = ProtocolSupport.toBytes(v, cs);
/*  274 */       return this;
/*      */     }
/*      */ 
/*      */     public CreateChannelRequest mergeFrom(CreateChannelRequest that)
/*      */     {
/*  281 */       assert (that != this);
/*  282 */       int this_t0 = this.optional_0_;
/*  283 */       int that_t0 = that.optional_0_;
/*      */ 
/*  285 */       if ((that_t0 & 0x1) != 0) {
/*  286 */         this_t0 |= 1;
/*  287 */         this.application_key_ = that.application_key_;
/*      */       }
/*      */ 
/*  290 */       if (that.uninterpreted != null) {
/*  291 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  293 */       this.optional_0_ = this_t0;
/*  294 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(CreateChannelRequest that) {
/*  298 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateChannelRequest that) {
/*  302 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(CreateChannelRequest that, boolean ignoreUninterpreted) {
/*  306 */       if (that == null) return false;
/*  307 */       if (that == this) return true;
/*  308 */       int this_t0 = this.optional_0_;
/*  309 */       int that_t0 = that.optional_0_;
/*  310 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  312 */       if (((this_t0 & 0x1) != 0) && 
/*  313 */         (!Arrays.equals(this.application_key_, that.application_key_))) return false;
/*      */ 
/*  316 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  321 */       return ((that instanceof CreateChannelRequest)) && (equals((CreateChannelRequest)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  325 */       int hash = 917783615;
/*      */ 
/*  327 */       int this_t0 = this.optional_0_;
/*  328 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.application_key_) : -113);
/*  329 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  330 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  332 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  336 */       int this_t0 = this.optional_0_;
/*      */ 
/*  338 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  345 */       int n = 1 + Protocol.stringSize(this.application_key_.length);
/*      */ 
/*  347 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  353 */       int n = 6 + this.application_key_.length;
/*      */ 
/*  355 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  360 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  364 */       this.optional_0_ = 0;
/*  365 */       this.application_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  366 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public CreateChannelRequest newInstance() {
/*  370 */       return new CreateChannelRequest();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  374 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  394 */       sink.putByte(10);
/*  395 */       sink.putPrefixedData(this.application_key_);
/*      */ 
/*  397 */       if (this.uninterpreted != null)
/*  398 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  403 */       boolean result = true;
/*  404 */       int this_t0 = this.optional_0_;
/*      */ 
/*  406 */       while (source.hasRemaining()) {
/*  407 */         int tt = source.getVarInt();
/*  408 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  412 */           result = false;
/*  413 */           break;
/*      */         case 10:
/*  416 */           this.application_key_ = source.getPrefixedData();
/*  417 */           this_t0 |= 1;
/*  418 */           break;
/*      */         default:
/*  420 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  425 */       this.optional_0_ = this_t0;
/*  426 */       return result;
/*      */     }
/*      */ 
/*      */     public CreateChannelRequest getDefaultInstanceForType()
/*      */     {
/*  431 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final CreateChannelRequest getDefaultInstance() {
/*  435 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public CreateChannelRequest freeze()
/*      */     {
/*  483 */       this.application_key_ = ProtocolSupport.freezeString(this.application_key_);
/*  484 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  487 */       if (this.uninterpreted == null) {
/*  488 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  490 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  439 */       IMMUTABLE_DEFAULT_INSTANCE = new CreateChannelRequest()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ChannelServicePb.CreateChannelRequest clearApplicationKey()
/*      */         {
/*  447 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelRequest setApplicationKeyAsBytes(byte[] x) {
/*  450 */           ProtocolSupport.unsupportedOperation();
/*  451 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelRequest setApplicationKey(String v) {
/*  454 */           ProtocolSupport.unsupportedOperation();
/*  455 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelRequest setApplicationKey(String v, Charset cs) {
/*  458 */           ProtocolSupport.unsupportedOperation();
/*  459 */           return this;
/*      */         }
/*      */ 
/*      */         public ChannelServicePb.CreateChannelRequest mergeFrom(ChannelServicePb.CreateChannelRequest that) {
/*  463 */           ProtocolSupport.unsupportedOperation();
/*  464 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  467 */           ProtocolSupport.unsupportedOperation();
/*  468 */           return false;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelRequest freeze() {
/*  471 */           return this;
/*      */         }
/*      */         public ChannelServicePb.CreateChannelRequest unfreeze() {
/*  474 */           ProtocolSupport.unsupportedOperation();
/*  475 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  478 */           return true;
/*      */         }
/*      */       };
/*  495 */       text = new String[2];
/*      */ 
/*  497 */       text[0] = "ErrorCode";
/*  498 */       text[1] = "application_key";
/*      */ 
/*  501 */       types = new int[2];
/*      */ 
/*  503 */       Arrays.fill(types, 6);
/*  504 */       types[0] = 0;
/*  505 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  378 */       private static final ProtocolType protocolType = new ProtocolType(ChannelServicePb.CreateChannelRequest.class, "Z,apphosting/api/channel/channel_service.proto\n\037apphosting.CreateChannelRequest\023\032\017application_key \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("application_key", "application_key", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ChannelServiceError extends ProtocolMessage<ChannelServiceError>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final ChannelServiceError IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public ChannelServiceError mergeFrom(ChannelServiceError that)
/*      */     {
/*   58 */       assert (that != this);
/*      */ 
/*   60 */       if (that.uninterpreted != null) {
/*   61 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   63 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(ChannelServiceError that) {
/*   67 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(ChannelServiceError that) {
/*   71 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(ChannelServiceError that, boolean ignoreUninterpreted) {
/*   75 */       if (that == null) return false;
/*   76 */       if (that == this) return true;
/*      */ 
/*   78 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*   83 */       return ((that instanceof ChannelServiceError)) && (equals((ChannelServiceError)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*   87 */       int hash = 1447663759;
/*   88 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*   89 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*   91 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*   95 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/*   99 */       int n = 0;
/*      */ 
/*  101 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  106 */       int n = 0;
/*      */ 
/*  108 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  113 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  117 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public ChannelServiceError newInstance() {
/*  121 */       return new ChannelServiceError();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  125 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  149 */       if (this.uninterpreted != null)
/*  150 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  155 */       boolean result = true;
/*      */ 
/*  157 */       while (source.hasRemaining()) {
/*  158 */         int tt = source.getVarInt();
/*  159 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  163 */           result = false;
/*  164 */           break;
/*      */         default:
/*  166 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  171 */       return result;
/*      */     }
/*      */ 
/*      */     public ChannelServiceError getDefaultInstanceForType()
/*      */     {
/*  176 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final ChannelServiceError getDefaultInstance() {
/*  180 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  210 */       if (this.uninterpreted == null) {
/*  211 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  213 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  184 */       IMMUTABLE_DEFAULT_INSTANCE = new ChannelServiceError()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ChannelServicePb.ChannelServiceError mergeFrom(ChannelServicePb.ChannelServiceError that)
/*      */         {
/*  191 */           ProtocolSupport.unsupportedOperation();
/*  192 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  195 */           ProtocolSupport.unsupportedOperation();
/*  196 */           return false;
/*      */         }
/*      */         public ChannelServicePb.ChannelServiceError freeze() {
/*  199 */           return this;
/*      */         }
/*      */         public ChannelServicePb.ChannelServiceError unfreeze() {
/*  202 */           ProtocolSupport.unsupportedOperation();
/*  203 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  206 */           return true;
/*      */         }
/*      */       };
/*  217 */       text = new String[1];
/*      */ 
/*  219 */       text[0] = "ErrorCode";
/*      */ 
/*  222 */       types = new int[1];
/*      */ 
/*  224 */       Arrays.fill(types, 6);
/*  225 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  129 */       private static final ProtocolType protocolType = new ProtocolType(ChannelServicePb.ChannelServiceError.class, "", new ProtocolType.FieldType[0]);
/*      */     }
/*      */ 
/*      */     public static enum ErrorCode
/*      */       implements ProtocolMessageEnum
/*      */     {
/*   28 */       OK(0), 
/*   29 */       INTERNAL_ERROR(1), 
/*   30 */       INVALID_CHANNEL_KEY(2), 
/*   31 */       BAD_MESSAGE(3), 
/*   32 */       CHANNEL_TIMEOUT(4);
/*      */ 
/*      */       public static final ErrorCode ErrorCode_MIN;
/*      */       public static final ErrorCode ErrorCode_MAX;
/*      */       private final int value;
/*      */ 
/*   37 */       public int getValue() { return this.value; }
/*      */ 
/*      */       public static ErrorCode valueOf(int value) {
/*   40 */         switch (value) { case 0:
/*   41 */           return OK;
/*      */         case 1:
/*   42 */           return INTERNAL_ERROR;
/*      */         case 2:
/*   43 */           return INVALID_CHANNEL_KEY;
/*      */         case 3:
/*   44 */           return BAD_MESSAGE;
/*      */         case 4:
/*   45 */           return CHANNEL_TIMEOUT;
/*      */         }
/*   47 */         return null;
/*      */       }
/*      */ 
/*      */       private ErrorCode(int v) {
/*   51 */         this.value = v;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*   34 */         ErrorCode_MIN = OK;
/*   35 */         ErrorCode_MAX = CHANNEL_TIMEOUT;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.channel.ChannelServicePb
 * JD-Core Version:    0.6.0
 */