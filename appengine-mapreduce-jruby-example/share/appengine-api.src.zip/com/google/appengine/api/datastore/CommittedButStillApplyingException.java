/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public class CommittedButStillApplyingException extends RuntimeException
/*    */ {
/*    */   public CommittedButStillApplyingException(String message)
/*    */   {
/* 16 */     super(message);
/*    */   }
/*    */ 
/*    */   public CommittedButStillApplyingException(String message, Throwable cause) {
/* 20 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.CommittedButStillApplyingException
 * JD-Core Version:    0.6.0
 */