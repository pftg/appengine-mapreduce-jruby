/*    */ package com.google.appengine.api.urlfetch;
/*    */ 
/*    */ public class ResponseTooLargeException extends RuntimeException
/*    */ {
/*    */   private static final String MESSAGE_FORMAT = "The response from url %s was too large.";
/*    */ 
/*    */   public ResponseTooLargeException(String url)
/*    */   {
/* 15 */     super(String.format("The response from url %s was too large.", new Object[] { url }));
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.ResponseTooLargeException
 * JD-Core Version:    0.6.0
 */