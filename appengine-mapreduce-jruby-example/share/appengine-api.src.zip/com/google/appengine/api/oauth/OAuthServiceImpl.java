/*    */ package com.google.appengine.api.oauth;
/*    */ 
/*    */ import com.google.appengine.api.users.User;
/*    */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*    */ import com.google.apphosting.api.ApiProxy;
/*    */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*    */ import com.google.apphosting.api.ApiProxy.Environment;
/*    */ import com.google.apphosting.api.UserServicePb.CheckOAuthSignatureRequest;
/*    */ import com.google.apphosting.api.UserServicePb.CheckOAuthSignatureResponse;
/*    */ import com.google.apphosting.api.UserServicePb.GetOAuthUserRequest;
/*    */ import com.google.apphosting.api.UserServicePb.GetOAuthUserResponse;
/*    */ import com.google.apphosting.api.UserServicePb.UserServiceError.ErrorCode;
/*    */ import java.util.Map;
/*    */ 
/*    */ final class OAuthServiceImpl
/*    */   implements OAuthService
/*    */ {
/*    */   static final String GET_OAUTH_USER_RESPONSE_KEY = "com.google.appengine.api.oauth.OAuthService.get_oauth_user_response";
/*    */   private static final String PACKAGE = "user";
/*    */   private static final String CHECK_SIGNATURE_METHOD = "CheckOAuthSignature";
/*    */   private static final String GET_OAUTH_USER_METHOD = "GetOAuthUser";
/*    */ 
/*    */   public User getCurrentUser()
/*    */     throws OAuthRequestException
/*    */   {
/* 28 */     UserServicePb.GetOAuthUserResponse response = getGetOAuthUserResponse();
/* 29 */     return new User(response.getEmail(), response.getAuthDomain(), response.getUserId());
/*    */   }
/*    */ 
/*    */   public boolean isUserAdmin() throws OAuthRequestException
/*    */   {
/* 34 */     UserServicePb.GetOAuthUserResponse response = getGetOAuthUserResponse();
/* 35 */     return response.isIsAdmin();
/*    */   }
/*    */ 
/*    */   public String getOAuthConsumerKey() throws OAuthRequestException {
/* 39 */     UserServicePb.CheckOAuthSignatureRequest request = new UserServicePb.CheckOAuthSignatureRequest();
/* 40 */     byte[] responseBytes = makeSyncCall("CheckOAuthSignature", request);
/* 41 */     UserServicePb.CheckOAuthSignatureResponse response = new UserServicePb.CheckOAuthSignatureResponse();
/* 42 */     response.mergeFrom(responseBytes);
/* 43 */     return response.getOauthConsumerKey();
/*    */   }
/*    */ 
/*    */   private UserServicePb.GetOAuthUserResponse getGetOAuthUserResponse() throws OAuthRequestException
/*    */   {
/* 48 */     ApiProxy.Environment environment = ApiProxy.getCurrentEnvironment();
/* 49 */     UserServicePb.GetOAuthUserResponse response = (UserServicePb.GetOAuthUserResponse)environment.getAttributes().get("com.google.appengine.api.oauth.OAuthService.get_oauth_user_response");
/*    */ 
/* 51 */     if (response == null) {
/* 52 */       UserServicePb.GetOAuthUserRequest request = new UserServicePb.GetOAuthUserRequest();
/* 53 */       byte[] responseBytes = makeSyncCall("GetOAuthUser", request);
/* 54 */       response = new UserServicePb.GetOAuthUserResponse();
/* 55 */       response.mergeFrom(responseBytes);
/* 56 */       environment.getAttributes().put("com.google.appengine.api.oauth.OAuthService.get_oauth_user_response", response);
/*    */     }
/* 58 */     return response;
/*    */   }
/*    */ 
/*    */   private byte[] makeSyncCall(String methodName, ProtocolMessage request) throws OAuthRequestException {
/*    */     byte[] responseBytes;
/*    */     try {
/* 65 */       byte[] requestBytes = request.toByteArray();
/* 66 */       responseBytes = ApiProxy.makeSyncCall("user", methodName, requestBytes);
/*    */     } catch (ApiProxy.ApplicationException ex) {
/* 68 */       UserServicePb.UserServiceError.ErrorCode errorCode = UserServicePb.UserServiceError.ErrorCode.valueOf(ex.getApplicationError());
/*    */ 
/* 70 */       switch (1.$SwitchMap$com$google$apphosting$api$UserServicePb$UserServiceError$ErrorCode[errorCode.ordinal()]) {
/*    */       case 1:
/*    */       case 2:
/* 73 */         throw new InvalidOAuthParametersException(ex.getErrorDetail());
/*    */       case 3:
/*    */       case 4: } 
/* 75 */     }throw new InvalidOAuthTokenException(ex.getErrorDetail());
/*    */ 
/* 78 */     throw new OAuthServiceFailureException(ex.getErrorDetail());
/*    */ 
/* 82 */     return responseBytes;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.oauth.OAuthServiceImpl
 * JD-Core Version:    0.6.0
 */