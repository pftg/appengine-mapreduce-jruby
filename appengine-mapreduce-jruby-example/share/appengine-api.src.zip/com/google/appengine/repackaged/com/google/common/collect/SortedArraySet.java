/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.NonFinalForGwt;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.SortedSet;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true)
/*     */ @GoogleInternal
/*     */ public final class SortedArraySet<E> extends AbstractSet<E>
/*     */   implements SortedSet<E>, Serializable
/*     */ {
/*     */   private ArrayList<E> contents;
/*     */ 
/*     */   @NonFinalForGwt
/*     */   private Comparator<? super E> comparator;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public SortedArraySet()
/*     */   {
/*  91 */     this(10);
/*     */   }
/*     */ 
/*     */   public SortedArraySet(int initialCapacity)
/*     */   {
/* 106 */     Preconditions.checkArgument(initialCapacity >= 0);
/* 107 */     this.comparator = orNaturalOrder(null);
/* 108 */     if (initialCapacity > 0)
/* 109 */       this.contents = new ArrayList(initialCapacity);
/*     */   }
/*     */ 
/*     */   public SortedArraySet(Comparator<? super E> comparator)
/*     */   {
/* 120 */     this(comparator, 10);
/*     */   }
/*     */ 
/*     */   public SortedArraySet(Comparator<? super E> comparator, int initialCapacity)
/*     */   {
/* 131 */     Preconditions.checkNotNull(comparator);
/* 132 */     this.comparator = comparator;
/* 133 */     if (initialCapacity > 0)
/* 134 */       this.contents = new ArrayList(initialCapacity);
/*     */   }
/*     */ 
/*     */   public SortedArraySet(Collection<? extends E> collection)
/*     */   {
/* 151 */     if ((collection instanceof SortedSet))
/* 152 */       this.comparator = orNaturalOrder(((SortedSet)collection).comparator());
/*     */     else {
/* 154 */       this.comparator = orNaturalOrder(null);
/*     */     }
/* 156 */     addAll(collection);
/*     */   }
/*     */ 
/*     */   public SortedArraySet(SortedSet<E> set)
/*     */   {
/* 166 */     this.comparator = orNaturalOrder(set.comparator());
/* 167 */     addAll(set);
/*     */   }
/*     */ 
/*     */   public void ensureCapacity(int minCapacity)
/*     */   {
/* 177 */     if (this.contents == null) {
/* 178 */       if (minCapacity > 0)
/* 179 */         this.contents = new ArrayList(minCapacity);
/*     */     }
/*     */     else
/* 182 */       this.contents.ensureCapacity(minCapacity);
/*     */   }
/*     */ 
/*     */   public void trimToSize()
/*     */   {
/* 192 */     if (size() == 0)
/* 193 */       this.contents = null;
/*     */     else
/* 195 */       this.contents.trimToSize();
/*     */   }
/*     */ 
/*     */   public boolean add(E o)
/*     */   {
/* 200 */     if (this.contents == null) {
/* 201 */       this.contents = new ArrayList(1);
/* 202 */       this.contents.add(o);
/* 203 */       return true;
/*     */     }
/* 205 */     int pos = binarySearch(o);
/* 206 */     if (pos < 0) {
/* 207 */       this.contents.add(-pos - 1, o);
/* 208 */       return true;
/*     */     }
/* 210 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean addAll(Collection<? extends E> c)
/*     */   {
/* 215 */     if (((this.contents == null) || (this.contents.isEmpty())) && (!c.isEmpty()) && ((c instanceof SortedSet)))
/*     */     {
/* 217 */       Comparator comparator2 = ((SortedSet)c).comparator();
/* 218 */       if (((this.comparator == Ordering.natural()) && (comparator2 == null)) || (this.comparator == comparator2))
/*     */       {
/* 221 */         if (this.contents == null)
/* 222 */           this.contents = new ArrayList(c);
/*     */         else {
/* 224 */           this.contents.addAll(c);
/*     */         }
/* 226 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 235 */     return super.addAll(c);
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 239 */     this.contents = null;
/*     */   }
/*     */ 
/*     */   public boolean contains(@Nullable Object o) {
/* 243 */     if ((o == null) && (this.comparator == Ordering.natural()))
/* 244 */       return false;
/*     */     try
/*     */     {
/* 247 */       return binarySearch(o) >= 0; } catch (NullPointerException e) {
/*     */     }
/* 249 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object o)
/*     */   {
/* 261 */     if (o == this) {
/* 262 */       return true;
/*     */     }
/* 264 */     if ((o instanceof SortedArraySet)) {
/* 265 */       SortedArraySet set = (SortedArraySet)o;
/* 266 */       if (Objects.equal(this.comparator, set.comparator)) {
/* 267 */         int n = size();
/* 268 */         return (n == set.size()) && ((n == 0) || (this.contents.equals(set.contents)));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 276 */     return super.equals(o);
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator() {
/* 280 */     return this.contents == null ? Iterators.emptyModifiableIterator() : this.contents.iterator();
/*     */   }
/*     */ 
/*     */   public boolean remove(@Nullable Object o)
/*     */   {
/* 285 */     if ((o == null) && (this.comparator == Ordering.natural()))
/* 286 */       return false;
/*     */     int pos;
/*     */     try {
/* 290 */       pos = binarySearch(o);
/*     */     } catch (NullPointerException e) {
/* 292 */       return false;
/*     */     }
/* 294 */     if (pos < 0) {
/* 295 */       return false;
/*     */     }
/* 297 */     this.contents.remove(pos);
/* 298 */     return true;
/*     */   }
/*     */ 
/*     */   public int size() {
/* 302 */     return this.contents == null ? 0 : this.contents.size();
/*     */   }
/*     */ 
/*     */   public Comparator<? super E> comparator()
/*     */   {
/* 313 */     return this.comparator;
/*     */   }
/*     */ 
/*     */   public SortedSet<E> subSet(E fromElement, E toElement) {
/* 317 */     Preconditions.checkArgument(this.comparator.compare(toElement, fromElement) >= 0);
/* 318 */     return new SubSet(fromElement, toElement, true, true);
/*     */   }
/*     */ 
/*     */   public SortedSet<E> headSet(E toElement) {
/* 322 */     return new SubSet(null, toElement, false, true);
/*     */   }
/*     */ 
/*     */   public SortedSet<E> tailSet(E fromElement) {
/* 326 */     return new SubSet(fromElement, null, true, false);
/*     */   }
/*     */ 
/*     */   public E first() {
/* 330 */     if (isEmpty()) {
/* 331 */       throw new NoSuchElementException();
/*     */     }
/* 333 */     return get(0);
/*     */   }
/*     */ 
/*     */   public E last() {
/* 337 */     if (isEmpty()) {
/* 338 */       throw new NoSuchElementException();
/*     */     }
/* 340 */     return get(size() - 1);
/*     */   }
/*     */ 
/*     */   private int binarySearch(Object o)
/*     */   {
/* 363 */     if (this.contents == null) {
/* 364 */       return -1;
/*     */     }
/*     */ 
/* 367 */     Object e = o;
/* 368 */     return Collections.binarySearch(this.contents, e, this.comparator);
/*     */   }
/*     */ 
/*     */   private E get(int index)
/*     */   {
/* 378 */     if (this.contents == null)
/* 379 */       throw new NoSuchElementException();
/*     */     try
/*     */     {
/* 382 */       return this.contents.get(index); } catch (IndexOutOfBoundsException e) {
/*     */     }
/* 384 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */   private static <E> Comparator<? super E> orNaturalOrder(@Nullable Comparator<? super E> comparator)
/*     */   {
/* 396 */     if (comparator != null) {
/* 397 */       return comparator;
/*     */     }
/* 399 */     return Ordering.natural();
/*     */   }
/*     */ 
/*     */   private class SubSet extends AbstractSet<E>
/*     */     implements SortedSet<E>
/*     */   {
/*     */     final E head;
/*     */     final E tail;
/*     */     final boolean hasHead;
/*     */     final boolean hasTail;
/*     */ 
/*     */     SubSet(@Nullable E fromElement, boolean toElement, boolean hasHead)
/*     */     {
/* 421 */       this.head = fromElement;
/* 422 */       this.tail = toElement;
/* 423 */       this.hasHead = hasHead;
/* 424 */       this.hasTail = hasTail;
/*     */     }
/*     */ 
/*     */     int headIndex()
/*     */     {
/* 432 */       if (!this.hasHead) {
/* 433 */         return 0;
/*     */       }
/*     */ 
/* 436 */       int pos = SortedArraySet.this.binarySearch(this.head);
/* 437 */       return pos < 0 ? -pos - 1 : pos;
/*     */     }
/*     */ 
/*     */     int tailIndex()
/*     */     {
/* 445 */       if (SortedArraySet.this.contents == null) {
/* 446 */         return 0;
/*     */       }
/* 448 */       if (!this.hasTail) {
/* 449 */         return SortedArraySet.this.contents.size();
/*     */       }
/*     */ 
/* 452 */       int pos = SortedArraySet.this.binarySearch(this.tail);
/* 453 */       return pos < 0 ? -pos - 1 : pos;
/*     */     }
/*     */ 
/*     */     void checkHead(E fromElement)
/*     */     {
/* 463 */       if (this.hasHead)
/* 464 */         Preconditions.checkArgument(SortedArraySet.this.comparator.compare(fromElement, this.head) >= 0);
/*     */     }
/*     */ 
/*     */     void checkTail(E toElement)
/*     */     {
/* 475 */       if (this.hasTail)
/* 476 */         Preconditions.checkArgument(SortedArraySet.this.comparator.compare(this.tail, toElement) > 0);
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 481 */       return tailIndex() - headIndex();
/*     */     }
/*     */ 
/*     */     public Comparator<? super E> comparator() {
/* 485 */       return SortedArraySet.this.comparator;
/*     */     }
/*     */ 
/*     */     public Iterator<E> iterator() {
/* 489 */       return SortedArraySet.this.contents == null ? Iterators.emptyIterator() : SortedArraySet.this.contents.subList(headIndex(), tailIndex()).iterator();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/*     */       try
/*     */       {
/* 497 */         Object e = o;
/* 498 */         if (((this.hasHead) && (SortedArraySet.this.comparator.compare(e, this.head) < 0)) || ((this.hasTail) && (SortedArraySet.this.comparator.compare(this.tail, e) <= 0)))
/*     */         {
/* 500 */           return false;
/*     */         }
/*     */       } catch (ClassCastException e) {
/* 503 */         return false;
/*     */       } catch (NullPointerException e) {
/* 505 */         return false;
/*     */       }
/* 507 */       return SortedArraySet.this.contains(o);
/*     */     }
/*     */ 
/*     */     public SortedSet<E> subSet(E fromElement, E toElement) {
/* 511 */       Preconditions.checkArgument(SortedArraySet.this.comparator.compare(toElement, fromElement) >= 0);
/* 512 */       checkHead(fromElement);
/* 513 */       checkTail(toElement);
/* 514 */       return new SubSet(SortedArraySet.this, fromElement, toElement, true, true);
/*     */     }
/*     */ 
/*     */     public SortedSet<E> headSet(E toElement) {
/* 518 */       checkHead(toElement);
/* 519 */       checkTail(toElement);
/* 520 */       return new SubSet(SortedArraySet.this, this.head, toElement, this.hasHead, true);
/*     */     }
/*     */ 
/*     */     public SortedSet<E> tailSet(E fromElement) {
/* 524 */       checkHead(fromElement);
/* 525 */       checkTail(fromElement);
/* 526 */       return new SubSet(SortedArraySet.this, fromElement, this.tail, true, this.hasTail);
/*     */     }
/*     */ 
/*     */     public E first() {
/* 530 */       Object o = SortedArraySet.this.get(headIndex());
/* 531 */       if ((this.hasTail) && (SortedArraySet.this.comparator.compare(this.tail, o) <= 0)) {
/* 532 */         throw new NoSuchElementException();
/*     */       }
/* 534 */       return o;
/*     */     }
/*     */ 
/*     */     public E last() {
/* 538 */       Object o = SortedArraySet.this.get(tailIndex() - 1);
/* 539 */       if ((this.hasHead) && (SortedArraySet.this.comparator.compare(o, this.head) < 0)) {
/* 540 */         throw new NoSuchElementException();
/*     */       }
/* 542 */       return o;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.SortedArraySet
 * JD-Core Version:    0.6.0
 */