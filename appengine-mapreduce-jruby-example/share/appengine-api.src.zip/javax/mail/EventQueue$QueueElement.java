/*    */ package javax.mail;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import javax.mail.event.MailEvent;
/*    */ 
/*    */ class EventQueue$QueueElement
/*    */ {
/* 55 */   QueueElement next = null;
/* 56 */   QueueElement prev = null;
/* 57 */   MailEvent event = null;
/* 58 */   Vector vector = null;
/*    */ 
/*    */   EventQueue$QueueElement(MailEvent event, Vector vector) {
/* 61 */     this.event = event;
/* 62 */     this.vector = vector;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.EventQueue.QueueElement
 * JD-Core Version:    0.6.0
 */