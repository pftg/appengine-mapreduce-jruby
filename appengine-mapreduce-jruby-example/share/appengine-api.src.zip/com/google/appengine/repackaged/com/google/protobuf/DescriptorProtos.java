/*       */ package com.google.appengine.repackaged.com.google.protobuf;
/*       */ 
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.ObjectStreamException;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Collections;
/*       */ import java.util.List;
/*       */ 
/*       */ public final class DescriptorProtos
/*       */ {
/*       */   private static Descriptors.Descriptor internal_static_proto2_FileDescriptorSet_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_FileDescriptorSet_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_FileDescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_FileDescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_DescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_DescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_DescriptorProto_ExtensionRange_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_DescriptorProto_ExtensionRange_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_FieldDescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_FieldDescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_EnumDescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_EnumDescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_EnumValueDescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_EnumValueDescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_ServiceDescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_ServiceDescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_MethodDescriptorProto_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_MethodDescriptorProto_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_FileOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_FileOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_MessageOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_MessageOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_FieldOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_FieldOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_EnumOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_EnumOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_EnumValueOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_EnumValueOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_ServiceOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_ServiceOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_MethodOptions_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_MethodOptions_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_UninterpretedOption_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_UninterpretedOption_fieldAccessorTable;
/*       */   private static Descriptors.Descriptor internal_static_proto2_UninterpretedOption_NamePart_descriptor;
/*       */   private static GeneratedMessage.FieldAccessorTable internal_static_proto2_UninterpretedOption_NamePart_fieldAccessorTable;
/*       */   private static Descriptors.FileDescriptor descriptor;
/*       */ 
/*       */   public static void registerAllExtensions(ExtensionRegistry registry)
/*       */   {
/*       */   }
/*       */ 
/*       */   public static Descriptors.FileDescriptor getDescriptor()
/*       */   {
/* 11515 */     return descriptor;
/*       */   }
/*       */   public static void internalForceInit() {
/*       */   }
/*       */   static {
/* 11520 */     String[] descriptorData = { "\n!net/proto2/proto/descriptor.proto\022\006proto2\">\n\021FileDescriptorSet\022)\n\004file\030\001 \003(\0132\033.proto2.FileDescriptorProto\"¯\002\n\023FileDescriptorProto\022\f\n\004name\030\001 \001(\t\022\017\n\007package\030\002 \001(\t\022\022\n\ndependency\030\003 \003(\t\022-\n\fmessage_type\030\004 \003(\0132\027.proto2.DescriptorProto\022.\n\tenum_type\030\005 \003(\0132\033.proto2.EnumDescriptorProto\022/\n\007service\030\006 \003(\0132\036.proto2.ServiceDescriptorProto\022/\n\textension\030\007 \003(\0132\034.proto2.FieldDescriptorProto\022$\n\007options\030\b \001(\0132\023.proto", "2.FileOptions\"ó\002\n\017DescriptorProto\022\f\n\004name\030\001 \001(\t\022+\n\005field\030\002 \003(\0132\034.proto2.FieldDescriptorProto\022/\n\textension\030\006 \003(\0132\034.proto2.FieldDescriptorProto\022,\n\013nested_type\030\003 \003(\0132\027.proto2.DescriptorProto\022.\n\tenum_type\030\004 \003(\0132\033.proto2.EnumDescriptorProto\022?\n\017extension_range\030\005 \003(\0132&.proto2.DescriptorProto.ExtensionRange\022'\n\007options\030\007 \001(\0132\026.proto2.MessageOptions\032,\n\016ExtensionRange\022\r\n\005start\030\001 \001(\005\022\013\n\003end\030\002 \001(\005\"ù\004\n\024FieldDes", "criptorProto\022\f\n\004name\030\001 \001(\t\022\016\n\006number\030\003 \001(\005\0221\n\005label\030\004 \001(\0162\".proto2.FieldDescriptorProto.Label\022/\n\004type\030\005 \001(\0162!.proto2.FieldDescriptorProto.Type\022\021\n\ttype_name\030\006 \001(\t\022\020\n\bextendee\030\002 \001(\t\022\025\n\rdefault_value\030\007 \001(\t\022%\n\007options\030\b \001(\0132\024.proto2.FieldOptions\"¶\002\n\004Type\022\017\n\013TYPE_DOUBLE\020\001\022\016\n\nTYPE_FLOAT\020\002\022\016\n\nTYPE_INT64\020\003\022\017\n\013TYPE_UINT64\020\004\022\016\n\nTYPE_INT32\020\005\022\020\n\fTYPE_FIXED64\020\006\022\020\n\fTYPE_FIXED32\020\007\022\r\n\tTYPE_BOOL\020\b\022\017\n\013TYPE_STRING\020\t", "\022\016\n\nTYPE_GROUP\020\n\022\020\n\fTYPE_MESSAGE\020\013\022\016\n\nTYPE_BYTES\020\f\022\017\n\013TYPE_UINT32\020\r\022\r\n\tTYPE_ENUM\020\016\022\021\n\rTYPE_SFIXED32\020\017\022\021\n\rTYPE_SFIXED64\020\020\022\017\n\013TYPE_SINT32\020\021\022\017\n\013TYPE_SINT64\020\022\"C\n\005Label\022\022\n\016LABEL_OPTIONAL\020\001\022\022\n\016LABEL_REQUIRED\020\002\022\022\n\016LABEL_REPEATED\020\003\"z\n\023EnumDescriptorProto\022\f\n\004name\030\001 \001(\t\022/\n\005value\030\002 \003(\0132 .proto2.EnumValueDescriptorProto\022$\n\007options\030\003 \001(\0132\023.proto2.EnumOptions\"c\n\030EnumValueDescriptorProto\022\f\n\004name\030\001 \001(\t\022\016\n\006number\030", "\002 \001(\005\022)\n\007options\030\003 \001(\0132\030.proto2.EnumValueOptions\"~\n\026ServiceDescriptorProto\022\f\n\004name\030\001 \001(\t\022-\n\006method\030\002 \003(\0132\035.proto2.MethodDescriptorProto\022'\n\007options\030\003 \001(\0132\026.proto2.ServiceOptions\"v\n\025MethodDescriptorProto\022\f\n\004name\030\001 \001(\t\022\022\n\ninput_type\030\002 \001(\t\022\023\n\013output_type\030\003 \001(\t\022&\n\007options\030\004 \001(\0132\025.proto2.MethodOptions\"ú\006\n\013FileOptions\022\031\n\016cc_api_version\030\002 \001(\005:\0012\022V\n\024cc_api_compatibility\030\017 \001(\0162&.proto2.FileOptions.Compatibi", "lityLevel:\020NO_COMPATIBILITY\022\024\n\fjava_package\030\001 \001(\t\022\031\n\016py_api_version\030\004 \001(\005:\0012\022\033\n\020java_api_version\030\005 \001(\005:\0012\022!\n\023java_use_javaproto2\030\006 \001(\b:\004true\022\036\n\020java_java5_enums\030\007 \001(\b:\004true\022)\n\032java_generate_rpc_baseimpl\030\r \001(\b:\005false\022\034\n\024java_alt_api_package\030\023 \001(\t\022\034\n\024java_outer_classname\030\b \001(\t\022\"\n\023java_multiple_files\030\n \001(\b:\005false\022=\n\foptimize_for\030\t \001(\0162 .proto2.FileOptions.OptimizeMode:\005SPEED\022\022\n\ngo_package\030\013 \001(\t\022\032\n\022ja", "", "eOptions\022&\n\027message_set_wire_format\030\001 \001(\b:\005false\022.\n\037no_standard_descriptor_accessor\030\002 \001(\b:\005false\022:\n\024uninterpreted_option\030ç\007 \003(\0132\033.proto2.UninterpretedOption*\t\bè\007\020\002\"Õ\002\n\fFieldOptions\0221\n\005ctype\030\001 \001(\0162\032.proto2.FieldOptions.CType:\006STRING\022\016\n\006packed\030\002 \001(\b\0221\n\005jtype\030\004 \001(\0162\032.proto2.FieldOptions.JType:\006NORMAL\022\031\n\ndeprecated\030\003 \001(\b:\005false\022\034\n\024experimental_map_key\030\t \001(\t\022:\n\024uninterpreted_option\030ç\007 \003(\0132\033.proto2.", "", "oto2.UninterpretedOption*\t\bè\007\020\002\"µ\005\n\rMethodOptions\0225\n\bprotocol\030\007 \001(\0162\036.proto2.MethodOptions.Protocol:\003TCP\022\024\n\bdeadline\030\b \001(\001:\002-1\022$\n\025duplicate_suppression\030\t \001(\b:\005false\022\030\n\tfail_fast\030\n \001(\b:\005false\022\033\n\016client_logging\030\013 \001(\021:\003256\022\033\n\016server_logging\030\f \001(\021:\003256\022A\n\016security_level\030\r \001(\0162#.proto2.MethodOptions.SecurityLevel:\004NONE\022C\n\017response_format\030\017 \001(\0162\034.proto2.MethodOptions.Format:\fUNCOMPRESSED\022B\n\016request_", "", "amePart\022\030\n\020identifier_value\030\003 \001(\t\022\032\n\022positive_int_value\030\004 \001(\004\022\032\n\022negative_int_value\030\005 \001(\003\022\024\n\fdouble_value\030\006 \001(\001\022\024\n\fstring_value\030\007 \001(\f\022\027\n\017aggregate_value\030\b \001(\t\0323\n\bNamePart\022\021\n\tname_part\030\001 \002(\t\022\024\n\fis_extension\030\002 \002(\bB)\n\023com.google.protobufB\020DescriptorProtosH\001" };
/*       */ 
/* 11639 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*       */     {
/*       */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*       */       {
/* 11643 */         DescriptorProtos.access$25302(root);
/* 11644 */         DescriptorProtos.access$002((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(0));
/*       */ 
/* 11646 */         DescriptorProtos.access$102(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_FileDescriptorSet_descriptor, new String[] { "File" }, DescriptorProtos.FileDescriptorSet.class, DescriptorProtos.FileDescriptorSet.Builder.class));
/*       */ 
/* 11652 */         DescriptorProtos.access$602((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(1));
/*       */ 
/* 11654 */         DescriptorProtos.access$702(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_FileDescriptorProto_descriptor, new String[] { "Name", "Package", "Dependency", "MessageType", "EnumType", "Service", "Extension", "Options" }, DescriptorProtos.FileDescriptorProto.class, DescriptorProtos.FileDescriptorProto.Builder.class));
/*       */ 
/* 11660 */         DescriptorProtos.access$2202((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(2));
/*       */ 
/* 11662 */         DescriptorProtos.access$2302(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_DescriptorProto_descriptor, new String[] { "Name", "Field", "Extension", "NestedType", "EnumType", "ExtensionRange", "Options" }, DescriptorProtos.DescriptorProto.class, DescriptorProtos.DescriptorProto.Builder.class));
/*       */ 
/* 11668 */         DescriptorProtos.access$2402((Descriptors.Descriptor)DescriptorProtos.internal_static_proto2_DescriptorProto_descriptor.getNestedTypes().get(0));
/*       */ 
/* 11670 */         DescriptorProtos.access$2502(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_DescriptorProto_ExtensionRange_descriptor, new String[] { "Start", "End" }, DescriptorProtos.DescriptorProto.ExtensionRange.class, DescriptorProtos.DescriptorProto.ExtensionRange.Builder.class));
/*       */ 
/* 11676 */         DescriptorProtos.access$4502((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(3));
/*       */ 
/* 11678 */         DescriptorProtos.access$4602(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_FieldDescriptorProto_descriptor, new String[] { "Name", "Number", "Label", "Type", "TypeName", "Extendee", "DefaultValue", "Options" }, DescriptorProtos.FieldDescriptorProto.class, DescriptorProtos.FieldDescriptorProto.Builder.class));
/*       */ 
/* 11684 */         DescriptorProtos.access$6602((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(4));
/*       */ 
/* 11686 */         DescriptorProtos.access$6702(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_EnumDescriptorProto_descriptor, new String[] { "Name", "Value", "Options" }, DescriptorProtos.EnumDescriptorProto.class, DescriptorProtos.EnumDescriptorProto.Builder.class));
/*       */ 
/* 11692 */         DescriptorProtos.access$7602((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(5));
/*       */ 
/* 11694 */         DescriptorProtos.access$7702(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_EnumValueDescriptorProto_descriptor, new String[] { "Name", "Number", "Options" }, DescriptorProtos.EnumValueDescriptorProto.class, DescriptorProtos.EnumValueDescriptorProto.Builder.class));
/*       */ 
/* 11700 */         DescriptorProtos.access$8702((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(6));
/*       */ 
/* 11702 */         DescriptorProtos.access$8802(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_ServiceDescriptorProto_descriptor, new String[] { "Name", "Method", "Options" }, DescriptorProtos.ServiceDescriptorProto.class, DescriptorProtos.ServiceDescriptorProto.Builder.class));
/*       */ 
/* 11708 */         DescriptorProtos.access$9702((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(7));
/*       */ 
/* 11710 */         DescriptorProtos.access$9802(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_MethodDescriptorProto_descriptor, new String[] { "Name", "InputType", "OutputType", "Options" }, DescriptorProtos.MethodDescriptorProto.class, DescriptorProtos.MethodDescriptorProto.Builder.class));
/*       */ 
/* 11716 */         DescriptorProtos.access$11002((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(8));
/*       */ 
/* 11718 */         DescriptorProtos.access$11102(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_FileOptions_descriptor, new String[] { "CcApiVersion", "CcApiCompatibility", "JavaPackage", "PyApiVersion", "JavaApiVersion", "JavaUseJavaproto2", "JavaJava5Enums", "JavaGenerateRpcBaseimpl", "JavaAltApiPackage", "JavaOuterClassname", "JavaMultipleFiles", "OptimizeFor", "GoPackage", "JavascriptPackage", "SzlApiVersion", "CcGenericServices", "JavaGenericServices", "PyGenericServices", "UninterpretedOption" }, DescriptorProtos.FileOptions.class, DescriptorProtos.FileOptions.Builder.class));
/*       */ 
/* 11724 */         DescriptorProtos.access$15202((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(9));
/*       */ 
/* 11726 */         DescriptorProtos.access$15302(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_MessageOptions_descriptor, new String[] { "MessageSetWireFormat", "NoStandardDescriptorAccessor", "UninterpretedOption" }, DescriptorProtos.MessageOptions.class, DescriptorProtos.MessageOptions.Builder.class));
/*       */ 
/* 11732 */         DescriptorProtos.access$16202((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(10));
/*       */ 
/* 11734 */         DescriptorProtos.access$16302(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_FieldOptions_descriptor, new String[] { "Ctype", "Packed", "Jtype", "Deprecated", "ExperimentalMapKey", "UninterpretedOption" }, DescriptorProtos.FieldOptions.class, DescriptorProtos.FieldOptions.Builder.class));
/*       */ 
/* 11740 */         DescriptorProtos.access$17802((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(11));
/*       */ 
/* 11742 */         DescriptorProtos.access$17902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_EnumOptions_descriptor, new String[] { "Proto1Name", "UninterpretedOption" }, DescriptorProtos.EnumOptions.class, DescriptorProtos.EnumOptions.Builder.class));
/*       */ 
/* 11748 */         DescriptorProtos.access$18602((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(12));
/*       */ 
/* 11750 */         DescriptorProtos.access$18702(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_EnumValueOptions_descriptor, new String[] { "UninterpretedOption" }, DescriptorProtos.EnumValueOptions.class, DescriptorProtos.EnumValueOptions.Builder.class));
/*       */ 
/* 11756 */         DescriptorProtos.access$19202((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(13));
/*       */ 
/* 11758 */         DescriptorProtos.access$19302(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_ServiceOptions_descriptor, new String[] { "FailureDetectionDelay", "UninterpretedOption" }, DescriptorProtos.ServiceOptions.class, DescriptorProtos.ServiceOptions.Builder.class));
/*       */ 
/* 11764 */         DescriptorProtos.access$20002((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(14));
/*       */ 
/* 11766 */         DescriptorProtos.access$20102(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_MethodOptions_descriptor, new String[] { "Protocol", "Deadline", "DuplicateSuppression", "FailFast", "ClientLogging", "ServerLogging", "SecurityLevel", "ResponseFormat", "RequestFormat", "StreamType", "UninterpretedOption" }, DescriptorProtos.MethodOptions.class, DescriptorProtos.MethodOptions.Builder.class));
/*       */ 
/* 11772 */         DescriptorProtos.access$22602((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(15));
/*       */ 
/* 11774 */         DescriptorProtos.access$22702(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_UninterpretedOption_descriptor, new String[] { "Name", "IdentifierValue", "PositiveIntValue", "NegativeIntValue", "DoubleValue", "StringValue", "AggregateValue" }, DescriptorProtos.UninterpretedOption.class, DescriptorProtos.UninterpretedOption.Builder.class));
/*       */ 
/* 11780 */         DescriptorProtos.access$22802((Descriptors.Descriptor)DescriptorProtos.internal_static_proto2_UninterpretedOption_descriptor.getNestedTypes().get(0));
/*       */ 
/* 11782 */         DescriptorProtos.access$22902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_proto2_UninterpretedOption_NamePart_descriptor, new String[] { "NamePart", "IsExtension" }, DescriptorProtos.UninterpretedOption.NamePart.class, DescriptorProtos.UninterpretedOption.NamePart.Builder.class));
/*       */ 
/* 11788 */         return null;
/*       */       }
/*       */     };
/* 11791 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/*       */   }
/*       */ 
/*       */   public static final class UninterpretedOption extends GeneratedMessage
/*       */   {
/* 11414 */     private static final UninterpretedOption defaultInstance = new UninterpretedOption(true);
/*       */     public static final int NAME_FIELD_NUMBER = 2;
/*       */     private List<NamePart> name_;
/*       */     public static final int IDENTIFIER_VALUE_FIELD_NUMBER = 3;
/*       */     private boolean hasIdentifierValue;
/*       */     private String identifierValue_;
/*       */     public static final int POSITIVE_INT_VALUE_FIELD_NUMBER = 4;
/*       */     private boolean hasPositiveIntValue;
/*       */     private long positiveIntValue_;
/*       */     public static final int NEGATIVE_INT_VALUE_FIELD_NUMBER = 5;
/*       */     private boolean hasNegativeIntValue;
/*       */     private long negativeIntValue_;
/*       */     public static final int DOUBLE_VALUE_FIELD_NUMBER = 6;
/*       */     private boolean hasDoubleValue;
/*       */     private double doubleValue_;
/*       */     public static final int STRING_VALUE_FIELD_NUMBER = 7;
/*       */     private boolean hasStringValue;
/*       */     private ByteString stringValue_;
/*       */     public static final int AGGREGATE_VALUE_FIELD_NUMBER = 8;
/*       */     private boolean hasAggregateValue;
/*       */     private String aggregateValue_;
/* 10906 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private UninterpretedOption(Builder builder)
/*       */     {
/* 10407 */       super();
/*       */     }
/*       */     private UninterpretedOption(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption getDefaultInstance() {
/* 10413 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public UninterpretedOption getDefaultInstanceForType() {
/* 10417 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/* 10422 */       return DescriptorProtos.internal_static_proto2_UninterpretedOption_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/* 10427 */       return DescriptorProtos.internal_static_proto2_UninterpretedOption_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public List<NamePart> getNameList()
/*       */     {
/* 10788 */       return this.name_;
/*       */     }
/*       */     public int getNameCount() {
/* 10791 */       return this.name_.size();
/*       */     }
/*       */     public NamePart getName(int index) {
/* 10794 */       return (NamePart)this.name_.get(index);
/*       */     }
/*       */ 
/*       */     public boolean hasIdentifierValue()
/*       */     {
/* 10802 */       return this.hasIdentifierValue;
/*       */     }
/*       */     public String getIdentifierValue() {
/* 10805 */       return this.identifierValue_;
/*       */     }
/*       */ 
/*       */     public boolean hasPositiveIntValue()
/*       */     {
/* 10813 */       return this.hasPositiveIntValue;
/*       */     }
/*       */     public long getPositiveIntValue() {
/* 10816 */       return this.positiveIntValue_;
/*       */     }
/*       */ 
/*       */     public boolean hasNegativeIntValue()
/*       */     {
/* 10824 */       return this.hasNegativeIntValue;
/*       */     }
/*       */     public long getNegativeIntValue() {
/* 10827 */       return this.negativeIntValue_;
/*       */     }
/*       */ 
/*       */     public boolean hasDoubleValue()
/*       */     {
/* 10835 */       return this.hasDoubleValue;
/*       */     }
/*       */     public double getDoubleValue() {
/* 10838 */       return this.doubleValue_;
/*       */     }
/*       */ 
/*       */     public boolean hasStringValue()
/*       */     {
/* 10846 */       return this.hasStringValue;
/*       */     }
/*       */     public ByteString getStringValue() {
/* 10849 */       return this.stringValue_;
/*       */     }
/*       */ 
/*       */     public boolean hasAggregateValue()
/*       */     {
/* 10857 */       return this.hasAggregateValue;
/*       */     }
/*       */     public String getAggregateValue() {
/* 10860 */       return this.aggregateValue_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/* 10864 */       this.name_ = Collections.emptyList();
/* 10865 */       this.identifierValue_ = "";
/* 10866 */       this.positiveIntValue_ = 0L;
/* 10867 */       this.negativeIntValue_ = 0L;
/* 10868 */       this.doubleValue_ = 0.0D;
/* 10869 */       this.stringValue_ = ByteString.EMPTY;
/* 10870 */       this.aggregateValue_ = "";
/*       */     }
/*       */     public final boolean isInitialized() {
/* 10873 */       for (NamePart element : getNameList()) {
/* 10874 */         if (!element.isInitialized()) return false;
/*       */       }
/* 10876 */       return true;
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output) throws IOException
/*       */     {
/* 10881 */       getSerializedSize();
/* 10882 */       for (NamePart element : getNameList()) {
/* 10883 */         output.writeMessage(2, element);
/*       */       }
/* 10885 */       if (hasIdentifierValue()) {
/* 10886 */         output.writeString(3, getIdentifierValue());
/*       */       }
/* 10888 */       if (hasPositiveIntValue()) {
/* 10889 */         output.writeUInt64(4, getPositiveIntValue());
/*       */       }
/* 10891 */       if (hasNegativeIntValue()) {
/* 10892 */         output.writeInt64(5, getNegativeIntValue());
/*       */       }
/* 10894 */       if (hasDoubleValue()) {
/* 10895 */         output.writeDouble(6, getDoubleValue());
/*       */       }
/* 10897 */       if (hasStringValue()) {
/* 10898 */         output.writeBytes(7, getStringValue());
/*       */       }
/* 10900 */       if (hasAggregateValue()) {
/* 10901 */         output.writeString(8, getAggregateValue());
/*       */       }
/* 10903 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/* 10908 */       int size = this.memoizedSerializedSize;
/* 10909 */       if (size != -1) return size;
/*       */ 
/* 10911 */       size = 0;
/* 10912 */       for (NamePart element : getNameList()) {
/* 10913 */         size += CodedOutputStream.computeMessageSize(2, element);
/*       */       }
/*       */ 
/* 10916 */       if (hasIdentifierValue()) {
/* 10917 */         size += CodedOutputStream.computeStringSize(3, getIdentifierValue());
/*       */       }
/*       */ 
/* 10920 */       if (hasPositiveIntValue()) {
/* 10921 */         size += CodedOutputStream.computeUInt64Size(4, getPositiveIntValue());
/*       */       }
/*       */ 
/* 10924 */       if (hasNegativeIntValue()) {
/* 10925 */         size += CodedOutputStream.computeInt64Size(5, getNegativeIntValue());
/*       */       }
/*       */ 
/* 10928 */       if (hasDoubleValue()) {
/* 10929 */         size += CodedOutputStream.computeDoubleSize(6, getDoubleValue());
/*       */       }
/*       */ 
/* 10932 */       if (hasStringValue()) {
/* 10933 */         size += CodedOutputStream.computeBytesSize(7, getStringValue());
/*       */       }
/*       */ 
/* 10936 */       if (hasAggregateValue()) {
/* 10937 */         size += CodedOutputStream.computeStringSize(8, getAggregateValue());
/*       */       }
/*       */ 
/* 10940 */       size += getUnknownFields().getSerializedSize();
/* 10941 */       this.memoizedSerializedSize = size;
/* 10942 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/* 10947 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/* 10953 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/* 10959 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/* 10964 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/* 10970 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(InputStream input) throws IOException
/*       */     {
/* 10975 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/* 10981 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/* 10986 */       Builder builder = newBuilder();
/* 10987 */       if (builder.mergeDelimitedFrom(input)) {
/* 10988 */         return builder.buildParsed();
/*       */       }
/* 10990 */       return null;
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/* 10997 */       Builder builder = newBuilder();
/* 10998 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 10999 */         return builder.buildParsed();
/*       */       }
/* 11001 */       return null;
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/* 11007 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static UninterpretedOption parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/* 11013 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/* 11017 */       return Builder.access$23800(); } 
/* 11018 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(UninterpretedOption prototype) {
/* 11020 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/* 11022 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 11415 */       DescriptorProtos.internalForceInit();
/* 11416 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/* 11222 */       private List<DescriptorProtos.UninterpretedOption.NamePart> name_ = Collections.emptyList();
/*       */       private boolean isNameMutable;
/*       */       private boolean hasIdentifierValue;
/* 11283 */       private String identifierValue_ = "";
/*       */       private boolean hasPositiveIntValue;
/*       */       private long positiveIntValue_;
/*       */       private boolean hasNegativeIntValue;
/*       */       private long negativeIntValue_;
/*       */       private boolean hasDoubleValue;
/*       */       private double doubleValue_;
/*       */       private boolean hasStringValue;
/* 11366 */       private ByteString stringValue_ = ByteString.EMPTY;
/*       */       private boolean hasAggregateValue;
/* 11389 */       private String aggregateValue_ = "";
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/* 11028 */         return DescriptorProtos.internal_static_proto2_UninterpretedOption_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/* 11033 */         return DescriptorProtos.internal_static_proto2_UninterpretedOption_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/* 11041 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/* 11045 */         super.clear();
/* 11046 */         this.name_ = Collections.emptyList();
/* 11047 */         this.isNameMutable = false;
/* 11048 */         this.identifierValue_ = "";
/* 11049 */         this.hasIdentifierValue = false;
/* 11050 */         this.positiveIntValue_ = 0L;
/* 11051 */         this.hasPositiveIntValue = false;
/* 11052 */         this.negativeIntValue_ = 0L;
/* 11053 */         this.hasNegativeIntValue = false;
/* 11054 */         this.doubleValue_ = 0.0D;
/* 11055 */         this.hasDoubleValue = false;
/* 11056 */         this.stringValue_ = ByteString.EMPTY;
/* 11057 */         this.hasStringValue = false;
/* 11058 */         this.aggregateValue_ = "";
/* 11059 */         this.hasAggregateValue = false;
/* 11060 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/* 11064 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/* 11069 */         return DescriptorProtos.UninterpretedOption.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.UninterpretedOption getDefaultInstanceForType() {
/* 11073 */         return DescriptorProtos.UninterpretedOption.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.UninterpretedOption build() {
/* 11077 */         DescriptorProtos.UninterpretedOption result = buildPartial();
/* 11078 */         if (!result.isInitialized()) {
/* 11079 */           throw newUninitializedMessageException(result);
/*       */         }
/* 11081 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.UninterpretedOption buildParsed() throws InvalidProtocolBufferException
/*       */       {
/* 11086 */         DescriptorProtos.UninterpretedOption result = buildPartial();
/* 11087 */         if (!result.isInitialized()) {
/* 11088 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/* 11091 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.UninterpretedOption buildPartial() {
/* 11095 */         DescriptorProtos.UninterpretedOption result = new DescriptorProtos.UninterpretedOption(this, null);
/* 11096 */         if (this.isNameMutable) {
/* 11097 */           this.name_ = Collections.unmodifiableList(this.name_);
/* 11098 */           this.isNameMutable = false;
/*       */         }
/* 11100 */         DescriptorProtos.UninterpretedOption.access$24002(result, this.name_);
/* 11101 */         DescriptorProtos.UninterpretedOption.access$24102(result, this.hasIdentifierValue);
/* 11102 */         DescriptorProtos.UninterpretedOption.access$24202(result, this.identifierValue_);
/* 11103 */         DescriptorProtos.UninterpretedOption.access$24302(result, this.hasPositiveIntValue);
/* 11104 */         DescriptorProtos.UninterpretedOption.access$24402(result, this.positiveIntValue_);
/* 11105 */         DescriptorProtos.UninterpretedOption.access$24502(result, this.hasNegativeIntValue);
/* 11106 */         DescriptorProtos.UninterpretedOption.access$24602(result, this.negativeIntValue_);
/* 11107 */         DescriptorProtos.UninterpretedOption.access$24702(result, this.hasDoubleValue);
/* 11108 */         DescriptorProtos.UninterpretedOption.access$24802(result, this.doubleValue_);
/* 11109 */         DescriptorProtos.UninterpretedOption.access$24902(result, this.hasStringValue);
/* 11110 */         DescriptorProtos.UninterpretedOption.access$25002(result, this.stringValue_);
/* 11111 */         DescriptorProtos.UninterpretedOption.access$25102(result, this.hasAggregateValue);
/* 11112 */         DescriptorProtos.UninterpretedOption.access$25202(result, this.aggregateValue_);
/* 11113 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/* 11117 */         if ((other instanceof DescriptorProtos.UninterpretedOption)) {
/* 11118 */           return mergeFrom((DescriptorProtos.UninterpretedOption)other);
/*       */         }
/* 11120 */         super.mergeFrom(other);
/* 11121 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.UninterpretedOption other)
/*       */       {
/* 11126 */         if (other == DescriptorProtos.UninterpretedOption.getDefaultInstance()) return this;
/* 11127 */         if (!other.name_.isEmpty()) {
/* 11128 */           if (this.name_.isEmpty()) {
/* 11129 */             this.name_ = other.name_;
/* 11130 */             this.isNameMutable = false;
/*       */           } else {
/* 11132 */             ensureNameIsMutable();
/* 11133 */             this.name_.addAll(other.name_);
/*       */           }
/*       */         }
/* 11136 */         if (other.hasIdentifierValue()) {
/* 11137 */           setIdentifierValue(other.getIdentifierValue());
/*       */         }
/* 11139 */         if (other.hasPositiveIntValue()) {
/* 11140 */           setPositiveIntValue(other.getPositiveIntValue());
/*       */         }
/* 11142 */         if (other.hasNegativeIntValue()) {
/* 11143 */           setNegativeIntValue(other.getNegativeIntValue());
/*       */         }
/* 11145 */         if (other.hasDoubleValue()) {
/* 11146 */           setDoubleValue(other.getDoubleValue());
/*       */         }
/* 11148 */         if (other.hasStringValue()) {
/* 11149 */           setStringValue(other.getStringValue());
/*       */         }
/* 11151 */         if (other.hasAggregateValue()) {
/* 11152 */           setAggregateValue(other.getAggregateValue());
/*       */         }
/* 11154 */         mergeUnknownFields(other.getUnknownFields());
/* 11155 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/* 11159 */         for (DescriptorProtos.UninterpretedOption.NamePart element : getNameList()) {
/* 11160 */           if (!element.isInitialized()) return false;
/*       */         }
/* 11162 */         return true;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/* 11169 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/* 11173 */           int tag = input.readTag();
/* 11174 */           switch (tag) {
/*       */           case 0:
/* 11176 */             setUnknownFields(unknownFields.build());
/* 11177 */             return this;
/*       */           default:
/* 11179 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/* 11181 */             setUnknownFields(unknownFields.build());
/* 11182 */             return this;
/*       */           case 18:
/* 11187 */             DescriptorProtos.UninterpretedOption.NamePart.Builder subBuilder = DescriptorProtos.UninterpretedOption.NamePart.newBuilder();
/* 11188 */             input.readMessage(subBuilder, extensionRegistry);
/* 11189 */             addName(subBuilder.buildPartial());
/* 11190 */             break;
/*       */           case 26:
/* 11193 */             setIdentifierValue(input.readString());
/* 11194 */             break;
/*       */           case 32:
/* 11197 */             setPositiveIntValue(input.readUInt64());
/* 11198 */             break;
/*       */           case 40:
/* 11201 */             setNegativeIntValue(input.readInt64());
/* 11202 */             break;
/*       */           case 49:
/* 11205 */             setDoubleValue(input.readDouble());
/* 11206 */             break;
/*       */           case 58:
/* 11209 */             setStringValue(input.readBytes());
/* 11210 */             break;
/*       */           case 66:
/* 11213 */             setAggregateValue(input.readString());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       private void ensureNameIsMutable()
/*       */       {
/* 11226 */         if (!this.isNameMutable) {
/* 11227 */           this.name_ = new ArrayList(this.name_);
/* 11228 */           this.isNameMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption.NamePart> getNameList() {
/* 11232 */         return Collections.unmodifiableList(this.name_);
/*       */       }
/*       */       public int getNameCount() {
/* 11235 */         return this.name_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption.NamePart getName(int index) {
/* 11238 */         return (DescriptorProtos.UninterpretedOption.NamePart)this.name_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setName(int index, DescriptorProtos.UninterpretedOption.NamePart value) {
/* 11242 */         if (value == null) {
/* 11243 */           throw new NullPointerException();
/*       */         }
/* 11245 */         ensureNameIsMutable();
/* 11246 */         this.name_.set(index, value);
/* 11247 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setName(int index, DescriptorProtos.UninterpretedOption.NamePart.Builder builderForValue) {
/* 11251 */         ensureNameIsMutable();
/* 11252 */         this.name_.set(index, builderForValue.build());
/* 11253 */         return this;
/*       */       }
/*       */       public Builder addName(DescriptorProtos.UninterpretedOption.NamePart value) {
/* 11256 */         if (value == null) {
/* 11257 */           throw new NullPointerException();
/*       */         }
/* 11259 */         ensureNameIsMutable();
/* 11260 */         this.name_.add(value);
/* 11261 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addName(DescriptorProtos.UninterpretedOption.NamePart.Builder builderForValue) {
/* 11265 */         ensureNameIsMutable();
/* 11266 */         this.name_.add(builderForValue.build());
/* 11267 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllName(Iterable<? extends DescriptorProtos.UninterpretedOption.NamePart> values) {
/* 11271 */         ensureNameIsMutable();
/* 11272 */         GeneratedMessage.Builder.addAll(values, this.name_);
/* 11273 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/* 11276 */         this.name_ = Collections.emptyList();
/* 11277 */         this.isNameMutable = false;
/* 11278 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasIdentifierValue()
/*       */       {
/* 11285 */         return this.hasIdentifierValue;
/*       */       }
/*       */       public String getIdentifierValue() {
/* 11288 */         return this.identifierValue_;
/*       */       }
/*       */       public Builder setIdentifierValue(String value) {
/* 11291 */         if (value == null) {
/* 11292 */           throw new NullPointerException();
/*       */         }
/* 11294 */         this.hasIdentifierValue = true;
/* 11295 */         this.identifierValue_ = value;
/* 11296 */         return this;
/*       */       }
/*       */       public Builder clearIdentifierValue() {
/* 11299 */         this.hasIdentifierValue = false;
/* 11300 */         this.identifierValue_ = DescriptorProtos.UninterpretedOption.getDefaultInstance().getIdentifierValue();
/* 11301 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasPositiveIntValue()
/*       */       {
/* 11308 */         return this.hasPositiveIntValue;
/*       */       }
/*       */       public long getPositiveIntValue() {
/* 11311 */         return this.positiveIntValue_;
/*       */       }
/*       */       public Builder setPositiveIntValue(long value) {
/* 11314 */         this.hasPositiveIntValue = true;
/* 11315 */         this.positiveIntValue_ = value;
/* 11316 */         return this;
/*       */       }
/*       */       public Builder clearPositiveIntValue() {
/* 11319 */         this.hasPositiveIntValue = false;
/* 11320 */         this.positiveIntValue_ = 0L;
/* 11321 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasNegativeIntValue()
/*       */       {
/* 11328 */         return this.hasNegativeIntValue;
/*       */       }
/*       */       public long getNegativeIntValue() {
/* 11331 */         return this.negativeIntValue_;
/*       */       }
/*       */       public Builder setNegativeIntValue(long value) {
/* 11334 */         this.hasNegativeIntValue = true;
/* 11335 */         this.negativeIntValue_ = value;
/* 11336 */         return this;
/*       */       }
/*       */       public Builder clearNegativeIntValue() {
/* 11339 */         this.hasNegativeIntValue = false;
/* 11340 */         this.negativeIntValue_ = 0L;
/* 11341 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasDoubleValue()
/*       */       {
/* 11348 */         return this.hasDoubleValue;
/*       */       }
/*       */       public double getDoubleValue() {
/* 11351 */         return this.doubleValue_;
/*       */       }
/*       */       public Builder setDoubleValue(double value) {
/* 11354 */         this.hasDoubleValue = true;
/* 11355 */         this.doubleValue_ = value;
/* 11356 */         return this;
/*       */       }
/*       */       public Builder clearDoubleValue() {
/* 11359 */         this.hasDoubleValue = false;
/* 11360 */         this.doubleValue_ = 0.0D;
/* 11361 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasStringValue()
/*       */       {
/* 11368 */         return this.hasStringValue;
/*       */       }
/*       */       public ByteString getStringValue() {
/* 11371 */         return this.stringValue_;
/*       */       }
/*       */       public Builder setStringValue(ByteString value) {
/* 11374 */         if (value == null) {
/* 11375 */           throw new NullPointerException();
/*       */         }
/* 11377 */         this.hasStringValue = true;
/* 11378 */         this.stringValue_ = value;
/* 11379 */         return this;
/*       */       }
/*       */       public Builder clearStringValue() {
/* 11382 */         this.hasStringValue = false;
/* 11383 */         this.stringValue_ = DescriptorProtos.UninterpretedOption.getDefaultInstance().getStringValue();
/* 11384 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasAggregateValue()
/*       */       {
/* 11391 */         return this.hasAggregateValue;
/*       */       }
/*       */       public String getAggregateValue() {
/* 11394 */         return this.aggregateValue_;
/*       */       }
/*       */       public Builder setAggregateValue(String value) {
/* 11397 */         if (value == null) {
/* 11398 */           throw new NullPointerException();
/*       */         }
/* 11400 */         this.hasAggregateValue = true;
/* 11401 */         this.aggregateValue_ = value;
/* 11402 */         return this;
/*       */       }
/*       */       public Builder clearAggregateValue() {
/* 11405 */         this.hasAggregateValue = false;
/* 11406 */         this.aggregateValue_ = DescriptorProtos.UninterpretedOption.getDefaultInstance().getAggregateValue();
/* 11407 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static final class NamePart extends GeneratedMessage
/*       */     {
/* 10776 */       private static final NamePart defaultInstance = new NamePart(true);
/*       */       public static final int NAME_PART_FIELD_NUMBER = 1;
/*       */       private boolean hasNamePart;
/*       */       private String namePart_;
/*       */       public static final int IS_EXTENSION_FIELD_NUMBER = 2;
/*       */       private boolean hasIsExtension;
/*       */       private boolean isExtension_;
/* 10501 */       private int memoizedSerializedSize = -1;
/*       */ 
/*       */       private NamePart(Builder builder)
/*       */       {
/* 10434 */         super();
/*       */       }
/*       */       private NamePart(boolean noInit) {
/*       */       }
/*       */ 
/*       */       public static NamePart getDefaultInstance() {
/* 10440 */         return defaultInstance;
/*       */       }
/*       */ 
/*       */       public NamePart getDefaultInstanceForType() {
/* 10444 */         return defaultInstance;
/*       */       }
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/* 10449 */         return DescriptorProtos.internal_static_proto2_UninterpretedOption_NamePart_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/* 10454 */         return DescriptorProtos.internal_static_proto2_UninterpretedOption_NamePart_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       public boolean hasNamePart()
/*       */       {
/* 10462 */         return this.hasNamePart;
/*       */       }
/*       */       public String getNamePart() {
/* 10465 */         return this.namePart_;
/*       */       }
/*       */ 
/*       */       public boolean hasIsExtension()
/*       */       {
/* 10473 */         return this.hasIsExtension;
/*       */       }
/*       */       public boolean getIsExtension() {
/* 10476 */         return this.isExtension_;
/*       */       }
/*       */ 
/*       */       private void initFields() {
/* 10480 */         this.namePart_ = "";
/* 10481 */         this.isExtension_ = false;
/*       */       }
/*       */       public final boolean isInitialized() {
/* 10484 */         if (!this.hasNamePart) return false;
/* 10485 */         return this.hasIsExtension;
/*       */       }
/*       */ 
/*       */       public void writeTo(CodedOutputStream output)
/*       */         throws IOException
/*       */       {
/* 10491 */         getSerializedSize();
/* 10492 */         if (hasNamePart()) {
/* 10493 */           output.writeString(1, getNamePart());
/*       */         }
/* 10495 */         if (hasIsExtension()) {
/* 10496 */           output.writeBool(2, getIsExtension());
/*       */         }
/* 10498 */         getUnknownFields().writeTo(output);
/*       */       }
/*       */ 
/*       */       public int getSerializedSize()
/*       */       {
/* 10503 */         int size = this.memoizedSerializedSize;
/* 10504 */         if (size != -1) return size;
/*       */ 
/* 10506 */         size = 0;
/* 10507 */         if (hasNamePart()) {
/* 10508 */           size += CodedOutputStream.computeStringSize(1, getNamePart());
/*       */         }
/*       */ 
/* 10511 */         if (hasIsExtension()) {
/* 10512 */           size += CodedOutputStream.computeBoolSize(2, getIsExtension());
/*       */         }
/*       */ 
/* 10515 */         size += getUnknownFields().getSerializedSize();
/* 10516 */         this.memoizedSerializedSize = size;
/* 10517 */         return size;
/*       */       }
/*       */ 
/*       */       protected Object writeReplace() throws ObjectStreamException
/*       */       {
/* 10522 */         return super.writeReplace();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(ByteString data)
/*       */         throws InvalidProtocolBufferException
/*       */       {
/* 10528 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */         throws InvalidProtocolBufferException
/*       */       {
/* 10534 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */       {
/* 10539 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */         throws InvalidProtocolBufferException
/*       */       {
/* 10545 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(InputStream input) throws IOException
/*       */       {
/* 10550 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/* 10556 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseDelimitedFrom(InputStream input) throws IOException
/*       */       {
/* 10561 */         Builder builder = newBuilder();
/* 10562 */         if (builder.mergeDelimitedFrom(input)) {
/* 10563 */           return builder.buildParsed();
/*       */         }
/* 10565 */         return null;
/*       */       }
/*       */ 
/*       */       public static NamePart parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/* 10572 */         Builder builder = newBuilder();
/* 10573 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 10574 */           return builder.buildParsed();
/*       */         }
/* 10576 */         return null;
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(CodedInputStream input)
/*       */         throws IOException
/*       */       {
/* 10582 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static NamePart parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/* 10588 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */       }
/*       */ 
/*       */       public static Builder newBuilder() {
/* 10592 */         return Builder.access$23100(); } 
/* 10593 */       public Builder newBuilderForType() { return newBuilder(); } 
/*       */       public static Builder newBuilder(NamePart prototype) {
/* 10595 */         return newBuilder().mergeFrom(prototype);
/*       */       }
/* 10597 */       public Builder toBuilder() { return newBuilder(this);
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/* 10777 */         DescriptorProtos.internalForceInit();
/* 10778 */         defaultInstance.initFields();
/*       */       }
/*       */ 
/*       */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */       {
/*       */         private boolean hasNamePart;
/* 10731 */         private String namePart_ = "";
/*       */         private boolean hasIsExtension;
/*       */         private boolean isExtension_;
/*       */ 
/*       */         public static final Descriptors.Descriptor getDescriptor()
/*       */         {
/* 10603 */           return DescriptorProtos.internal_static_proto2_UninterpretedOption_NamePart_descriptor;
/*       */         }
/*       */ 
/*       */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */         {
/* 10608 */           return DescriptorProtos.internal_static_proto2_UninterpretedOption_NamePart_fieldAccessorTable;
/*       */         }
/*       */ 
/*       */         private static Builder create()
/*       */         {
/* 10616 */           return new Builder();
/*       */         }
/*       */ 
/*       */         public Builder clear() {
/* 10620 */           super.clear();
/* 10621 */           this.namePart_ = "";
/* 10622 */           this.hasNamePart = false;
/* 10623 */           this.isExtension_ = false;
/* 10624 */           this.hasIsExtension = false;
/* 10625 */           return this;
/*       */         }
/*       */ 
/*       */         public Builder clone() {
/* 10629 */           return create().mergeFrom(buildPartial());
/*       */         }
/*       */ 
/*       */         public Descriptors.Descriptor getDescriptorForType()
/*       */         {
/* 10634 */           return DescriptorProtos.UninterpretedOption.NamePart.getDescriptor();
/*       */         }
/*       */ 
/*       */         public DescriptorProtos.UninterpretedOption.NamePart getDefaultInstanceForType() {
/* 10638 */           return DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance();
/*       */         }
/*       */ 
/*       */         public DescriptorProtos.UninterpretedOption.NamePart build() {
/* 10642 */           DescriptorProtos.UninterpretedOption.NamePart result = buildPartial();
/* 10643 */           if (!result.isInitialized()) {
/* 10644 */             throw newUninitializedMessageException(result);
/*       */           }
/* 10646 */           return result;
/*       */         }
/*       */ 
/*       */         private DescriptorProtos.UninterpretedOption.NamePart buildParsed() throws InvalidProtocolBufferException
/*       */         {
/* 10651 */           DescriptorProtos.UninterpretedOption.NamePart result = buildPartial();
/* 10652 */           if (!result.isInitialized()) {
/* 10653 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */           }
/*       */ 
/* 10656 */           return result;
/*       */         }
/*       */ 
/*       */         public DescriptorProtos.UninterpretedOption.NamePart buildPartial() {
/* 10660 */           DescriptorProtos.UninterpretedOption.NamePart result = new DescriptorProtos.UninterpretedOption.NamePart(this, null);
/* 10661 */           DescriptorProtos.UninterpretedOption.NamePart.access$23302(result, this.hasNamePart);
/* 10662 */           DescriptorProtos.UninterpretedOption.NamePart.access$23402(result, this.namePart_);
/* 10663 */           DescriptorProtos.UninterpretedOption.NamePart.access$23502(result, this.hasIsExtension);
/* 10664 */           DescriptorProtos.UninterpretedOption.NamePart.access$23602(result, this.isExtension_);
/* 10665 */           return result;
/*       */         }
/*       */ 
/*       */         public Builder mergeFrom(Message other) {
/* 10669 */           if ((other instanceof DescriptorProtos.UninterpretedOption.NamePart)) {
/* 10670 */             return mergeFrom((DescriptorProtos.UninterpretedOption.NamePart)other);
/*       */           }
/* 10672 */           super.mergeFrom(other);
/* 10673 */           return this;
/*       */         }
/*       */ 
/*       */         public Builder mergeFrom(DescriptorProtos.UninterpretedOption.NamePart other)
/*       */         {
/* 10678 */           if (other == DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance()) return this;
/* 10679 */           if (other.hasNamePart()) {
/* 10680 */             setNamePart(other.getNamePart());
/*       */           }
/* 10682 */           if (other.hasIsExtension()) {
/* 10683 */             setIsExtension(other.getIsExtension());
/*       */           }
/* 10685 */           mergeUnknownFields(other.getUnknownFields());
/* 10686 */           return this;
/*       */         }
/*       */ 
/*       */         public final boolean isInitialized() {
/* 10690 */           if (!this.hasNamePart) return false;
/* 10691 */           return this.hasIsExtension;
/*       */         }
/*       */ 
/*       */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */           throws IOException
/*       */         {
/* 10699 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */           while (true)
/*       */           {
/* 10703 */             int tag = input.readTag();
/* 10704 */             switch (tag) {
/*       */             case 0:
/* 10706 */               setUnknownFields(unknownFields.build());
/* 10707 */               return this;
/*       */             default:
/* 10709 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */                 break;
/* 10711 */               setUnknownFields(unknownFields.build());
/* 10712 */               return this;
/*       */             case 10:
/* 10717 */               setNamePart(input.readString());
/* 10718 */               break;
/*       */             case 16:
/* 10721 */               setIsExtension(input.readBool());
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */         public boolean hasNamePart()
/*       */         {
/* 10733 */           return this.hasNamePart;
/*       */         }
/*       */         public String getNamePart() {
/* 10736 */           return this.namePart_;
/*       */         }
/*       */         public Builder setNamePart(String value) {
/* 10739 */           if (value == null) {
/* 10740 */             throw new NullPointerException();
/*       */           }
/* 10742 */           this.hasNamePart = true;
/* 10743 */           this.namePart_ = value;
/* 10744 */           return this;
/*       */         }
/*       */         public Builder clearNamePart() {
/* 10747 */           this.hasNamePart = false;
/* 10748 */           this.namePart_ = DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance().getNamePart();
/* 10749 */           return this;
/*       */         }
/*       */ 
/*       */         public boolean hasIsExtension()
/*       */         {
/* 10756 */           return this.hasIsExtension;
/*       */         }
/*       */         public boolean getIsExtension() {
/* 10759 */           return this.isExtension_;
/*       */         }
/*       */         public Builder setIsExtension(boolean value) {
/* 10762 */           this.hasIsExtension = true;
/* 10763 */           this.isExtension_ = value;
/* 10764 */           return this;
/*       */         }
/*       */         public Builder clearIsExtension() {
/* 10767 */           this.hasIsExtension = false;
/* 10768 */           this.isExtension_ = false;
/* 10769 */           return this;
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class MethodOptions extends GeneratedMessage.ExtendableMessage<MethodOptions>
/*       */   {
/* 10395 */     private static final MethodOptions defaultInstance = new MethodOptions(true);
/*       */     public static final int PROTOCOL_FIELD_NUMBER = 7;
/*       */     private boolean hasProtocol;
/*       */     private Protocol protocol_;
/*       */     public static final int DEADLINE_FIELD_NUMBER = 8;
/*       */     private boolean hasDeadline;
/*       */     private double deadline_;
/*       */     public static final int DUPLICATE_SUPPRESSION_FIELD_NUMBER = 9;
/*       */     private boolean hasDuplicateSuppression;
/*       */     private boolean duplicateSuppression_;
/*       */     public static final int FAIL_FAST_FIELD_NUMBER = 10;
/*       */     private boolean hasFailFast;
/*       */     private boolean failFast_;
/*       */     public static final int CLIENT_LOGGING_FIELD_NUMBER = 11;
/*       */     private boolean hasClientLogging;
/*       */     private int clientLogging_;
/*       */     public static final int SERVER_LOGGING_FIELD_NUMBER = 12;
/*       */     private boolean hasServerLogging;
/*       */     private int serverLogging_;
/*       */     public static final int SECURITY_LEVEL_FIELD_NUMBER = 13;
/*       */     private boolean hasSecurityLevel;
/*       */     private SecurityLevel securityLevel_;
/*       */     public static final int RESPONSE_FORMAT_FIELD_NUMBER = 15;
/*       */     private boolean hasResponseFormat;
/*       */     private Format responseFormat_;
/*       */     public static final int REQUEST_FORMAT_FIELD_NUMBER = 17;
/*       */     private boolean hasRequestFormat;
/*       */     private Format requestFormat_;
/*       */     public static final int STREAM_TYPE_FIELD_NUMBER = 18;
/*       */     private boolean hasStreamType;
/*       */     private String streamType_;
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  9713 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private MethodOptions(Builder builder)
/*       */     {
/*  9288 */       super();
/*       */     }
/*       */     private MethodOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static MethodOptions getDefaultInstance() {
/*  9294 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public MethodOptions getDefaultInstanceForType() {
/*  9298 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  9303 */       return DescriptorProtos.internal_static_proto2_MethodOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  9308 */       return DescriptorProtos.internal_static_proto2_MethodOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasProtocol()
/*       */     {
/*  9532 */       return this.hasProtocol;
/*       */     }
/*       */     public Protocol getProtocol() {
/*  9535 */       return this.protocol_;
/*       */     }
/*       */ 
/*       */     public boolean hasDeadline()
/*       */     {
/*  9543 */       return this.hasDeadline;
/*       */     }
/*       */     public double getDeadline() {
/*  9546 */       return this.deadline_;
/*       */     }
/*       */ 
/*       */     public boolean hasDuplicateSuppression()
/*       */     {
/*  9554 */       return this.hasDuplicateSuppression;
/*       */     }
/*       */     public boolean getDuplicateSuppression() {
/*  9557 */       return this.duplicateSuppression_;
/*       */     }
/*       */ 
/*       */     public boolean hasFailFast()
/*       */     {
/*  9565 */       return this.hasFailFast;
/*       */     }
/*       */     public boolean getFailFast() {
/*  9568 */       return this.failFast_;
/*       */     }
/*       */ 
/*       */     public boolean hasClientLogging()
/*       */     {
/*  9576 */       return this.hasClientLogging;
/*       */     }
/*       */     public int getClientLogging() {
/*  9579 */       return this.clientLogging_;
/*       */     }
/*       */ 
/*       */     public boolean hasServerLogging()
/*       */     {
/*  9587 */       return this.hasServerLogging;
/*       */     }
/*       */     public int getServerLogging() {
/*  9590 */       return this.serverLogging_;
/*       */     }
/*       */ 
/*       */     public boolean hasSecurityLevel()
/*       */     {
/*  9598 */       return this.hasSecurityLevel;
/*       */     }
/*       */     public SecurityLevel getSecurityLevel() {
/*  9601 */       return this.securityLevel_;
/*       */     }
/*       */ 
/*       */     public boolean hasResponseFormat()
/*       */     {
/*  9609 */       return this.hasResponseFormat;
/*       */     }
/*       */     public Format getResponseFormat() {
/*  9612 */       return this.responseFormat_;
/*       */     }
/*       */ 
/*       */     public boolean hasRequestFormat()
/*       */     {
/*  9620 */       return this.hasRequestFormat;
/*       */     }
/*       */     public Format getRequestFormat() {
/*  9623 */       return this.requestFormat_;
/*       */     }
/*       */ 
/*       */     public boolean hasStreamType()
/*       */     {
/*  9631 */       return this.hasStreamType;
/*       */     }
/*       */     public String getStreamType() {
/*  9634 */       return this.streamType_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  9641 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  9644 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  9647 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  9651 */       this.protocol_ = Protocol.TCP;
/*  9652 */       this.deadline_ = -1.0D;
/*  9653 */       this.duplicateSuppression_ = false;
/*  9654 */       this.failFast_ = false;
/*  9655 */       this.clientLogging_ = 256;
/*  9656 */       this.serverLogging_ = 256;
/*  9657 */       this.securityLevel_ = SecurityLevel.NONE;
/*  9658 */       this.responseFormat_ = Format.UNCOMPRESSED;
/*  9659 */       this.requestFormat_ = Format.UNCOMPRESSED;
/*  9660 */       this.streamType_ = "";
/*  9661 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  9664 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  9665 */         if (!element.isInitialized()) return false;
/*       */       }
/*  9667 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  9673 */       getSerializedSize();
/*       */ 
/*  9675 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  9676 */       if (hasProtocol()) {
/*  9677 */         output.writeEnum(7, getProtocol().getNumber());
/*       */       }
/*  9679 */       if (hasDeadline()) {
/*  9680 */         output.writeDouble(8, getDeadline());
/*       */       }
/*  9682 */       if (hasDuplicateSuppression()) {
/*  9683 */         output.writeBool(9, getDuplicateSuppression());
/*       */       }
/*  9685 */       if (hasFailFast()) {
/*  9686 */         output.writeBool(10, getFailFast());
/*       */       }
/*  9688 */       if (hasClientLogging()) {
/*  9689 */         output.writeSInt32(11, getClientLogging());
/*       */       }
/*  9691 */       if (hasServerLogging()) {
/*  9692 */         output.writeSInt32(12, getServerLogging());
/*       */       }
/*  9694 */       if (hasSecurityLevel()) {
/*  9695 */         output.writeEnum(13, getSecurityLevel().getNumber());
/*       */       }
/*  9697 */       if (hasResponseFormat()) {
/*  9698 */         output.writeEnum(15, getResponseFormat().getNumber());
/*       */       }
/*  9700 */       if (hasRequestFormat()) {
/*  9701 */         output.writeEnum(17, getRequestFormat().getNumber());
/*       */       }
/*  9703 */       if (hasStreamType()) {
/*  9704 */         output.writeString(18, getStreamType());
/*       */       }
/*  9706 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  9707 */         output.writeMessage(999, element);
/*       */       }
/*  9709 */       extensionWriter.writeUntil(536870912, output);
/*  9710 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  9715 */       int size = this.memoizedSerializedSize;
/*  9716 */       if (size != -1) return size;
/*       */ 
/*  9718 */       size = 0;
/*  9719 */       if (hasProtocol()) {
/*  9720 */         size += CodedOutputStream.computeEnumSize(7, getProtocol().getNumber());
/*       */       }
/*       */ 
/*  9723 */       if (hasDeadline()) {
/*  9724 */         size += CodedOutputStream.computeDoubleSize(8, getDeadline());
/*       */       }
/*       */ 
/*  9727 */       if (hasDuplicateSuppression()) {
/*  9728 */         size += CodedOutputStream.computeBoolSize(9, getDuplicateSuppression());
/*       */       }
/*       */ 
/*  9731 */       if (hasFailFast()) {
/*  9732 */         size += CodedOutputStream.computeBoolSize(10, getFailFast());
/*       */       }
/*       */ 
/*  9735 */       if (hasClientLogging()) {
/*  9736 */         size += CodedOutputStream.computeSInt32Size(11, getClientLogging());
/*       */       }
/*       */ 
/*  9739 */       if (hasServerLogging()) {
/*  9740 */         size += CodedOutputStream.computeSInt32Size(12, getServerLogging());
/*       */       }
/*       */ 
/*  9743 */       if (hasSecurityLevel()) {
/*  9744 */         size += CodedOutputStream.computeEnumSize(13, getSecurityLevel().getNumber());
/*       */       }
/*       */ 
/*  9747 */       if (hasResponseFormat()) {
/*  9748 */         size += CodedOutputStream.computeEnumSize(15, getResponseFormat().getNumber());
/*       */       }
/*       */ 
/*  9751 */       if (hasRequestFormat()) {
/*  9752 */         size += CodedOutputStream.computeEnumSize(17, getRequestFormat().getNumber());
/*       */       }
/*       */ 
/*  9755 */       if (hasStreamType()) {
/*  9756 */         size += CodedOutputStream.computeStringSize(18, getStreamType());
/*       */       }
/*       */ 
/*  9759 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  9760 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  9763 */       size += extensionsSerializedSize();
/*  9764 */       size += getUnknownFields().getSerializedSize();
/*  9765 */       this.memoizedSerializedSize = size;
/*  9766 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  9771 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  9777 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  9783 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  9788 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  9794 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  9799 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  9805 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  9810 */       Builder builder = newBuilder();
/*  9811 */       if (builder.mergeDelimitedFrom(input)) {
/*  9812 */         return builder.buildParsed();
/*       */       }
/*  9814 */       return null;
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  9821 */       Builder builder = newBuilder();
/*  9822 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  9823 */         return builder.buildParsed();
/*       */       }
/*  9825 */       return null;
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  9831 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  9837 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  9841 */       return Builder.access$20300(); } 
/*  9842 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(MethodOptions prototype) {
/*  9844 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  9846 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 10396 */       DescriptorProtos.internalForceInit();
/* 10397 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.MethodOptions, Builder>
/*       */     {
/*       */       private boolean hasProtocol;
/* 10118 */       private DescriptorProtos.MethodOptions.Protocol protocol_ = DescriptorProtos.MethodOptions.Protocol.TCP;
/*       */       private boolean hasDeadline;
/* 10141 */       private double deadline_ = -1.0D;
/*       */       private boolean hasDuplicateSuppression;
/*       */       private boolean duplicateSuppression_;
/*       */       private boolean hasFailFast;
/*       */       private boolean failFast_;
/*       */       private boolean hasClientLogging;
/* 10201 */       private int clientLogging_ = 256;
/*       */       private boolean hasServerLogging;
/* 10221 */       private int serverLogging_ = 256;
/*       */       private boolean hasSecurityLevel;
/* 10241 */       private DescriptorProtos.MethodOptions.SecurityLevel securityLevel_ = DescriptorProtos.MethodOptions.SecurityLevel.NONE;
/*       */       private boolean hasResponseFormat;
/* 10264 */       private DescriptorProtos.MethodOptions.Format responseFormat_ = DescriptorProtos.MethodOptions.Format.UNCOMPRESSED;
/*       */       private boolean hasRequestFormat;
/* 10287 */       private DescriptorProtos.MethodOptions.Format requestFormat_ = DescriptorProtos.MethodOptions.Format.UNCOMPRESSED;
/*       */       private boolean hasStreamType;
/* 10310 */       private String streamType_ = "";
/*       */ 
/* 10332 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  9853 */         return DescriptorProtos.internal_static_proto2_MethodOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  9858 */         return DescriptorProtos.internal_static_proto2_MethodOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  9866 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  9870 */         super.clear();
/*  9871 */         this.protocol_ = DescriptorProtos.MethodOptions.Protocol.TCP;
/*  9872 */         this.hasProtocol = false;
/*  9873 */         this.deadline_ = -1.0D;
/*  9874 */         this.hasDeadline = false;
/*  9875 */         this.duplicateSuppression_ = false;
/*  9876 */         this.hasDuplicateSuppression = false;
/*  9877 */         this.failFast_ = false;
/*  9878 */         this.hasFailFast = false;
/*  9879 */         this.clientLogging_ = 256;
/*  9880 */         this.hasClientLogging = false;
/*  9881 */         this.serverLogging_ = 256;
/*  9882 */         this.hasServerLogging = false;
/*  9883 */         this.securityLevel_ = DescriptorProtos.MethodOptions.SecurityLevel.NONE;
/*  9884 */         this.hasSecurityLevel = false;
/*  9885 */         this.responseFormat_ = DescriptorProtos.MethodOptions.Format.UNCOMPRESSED;
/*  9886 */         this.hasResponseFormat = false;
/*  9887 */         this.requestFormat_ = DescriptorProtos.MethodOptions.Format.UNCOMPRESSED;
/*  9888 */         this.hasRequestFormat = false;
/*  9889 */         this.streamType_ = "";
/*  9890 */         this.hasStreamType = false;
/*  9891 */         this.uninterpretedOption_ = Collections.emptyList();
/*  9892 */         this.isUninterpretedOptionMutable = false;
/*  9893 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  9897 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  9902 */         return DescriptorProtos.MethodOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MethodOptions getDefaultInstanceForType() {
/*  9906 */         return DescriptorProtos.MethodOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MethodOptions build() {
/*  9910 */         DescriptorProtos.MethodOptions result = buildPartial();
/*  9911 */         if (!result.isInitialized()) {
/*  9912 */           throw newUninitializedMessageException(result);
/*       */         }
/*  9914 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.MethodOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  9919 */         DescriptorProtos.MethodOptions result = buildPartial();
/*  9920 */         if (!result.isInitialized()) {
/*  9921 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  9924 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MethodOptions buildPartial() {
/*  9928 */         DescriptorProtos.MethodOptions result = new DescriptorProtos.MethodOptions(this, null);
/*  9929 */         DescriptorProtos.MethodOptions.access$20502(result, this.hasProtocol);
/*  9930 */         DescriptorProtos.MethodOptions.access$20602(result, this.protocol_);
/*  9931 */         DescriptorProtos.MethodOptions.access$20702(result, this.hasDeadline);
/*  9932 */         DescriptorProtos.MethodOptions.access$20802(result, this.deadline_);
/*  9933 */         DescriptorProtos.MethodOptions.access$20902(result, this.hasDuplicateSuppression);
/*  9934 */         DescriptorProtos.MethodOptions.access$21002(result, this.duplicateSuppression_);
/*  9935 */         DescriptorProtos.MethodOptions.access$21102(result, this.hasFailFast);
/*  9936 */         DescriptorProtos.MethodOptions.access$21202(result, this.failFast_);
/*  9937 */         DescriptorProtos.MethodOptions.access$21302(result, this.hasClientLogging);
/*  9938 */         DescriptorProtos.MethodOptions.access$21402(result, this.clientLogging_);
/*  9939 */         DescriptorProtos.MethodOptions.access$21502(result, this.hasServerLogging);
/*  9940 */         DescriptorProtos.MethodOptions.access$21602(result, this.serverLogging_);
/*  9941 */         DescriptorProtos.MethodOptions.access$21702(result, this.hasSecurityLevel);
/*  9942 */         DescriptorProtos.MethodOptions.access$21802(result, this.securityLevel_);
/*  9943 */         DescriptorProtos.MethodOptions.access$21902(result, this.hasResponseFormat);
/*  9944 */         DescriptorProtos.MethodOptions.access$22002(result, this.responseFormat_);
/*  9945 */         DescriptorProtos.MethodOptions.access$22102(result, this.hasRequestFormat);
/*  9946 */         DescriptorProtos.MethodOptions.access$22202(result, this.requestFormat_);
/*  9947 */         DescriptorProtos.MethodOptions.access$22302(result, this.hasStreamType);
/*  9948 */         DescriptorProtos.MethodOptions.access$22402(result, this.streamType_);
/*  9949 */         if (this.isUninterpretedOptionMutable) {
/*  9950 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  9951 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  9953 */         DescriptorProtos.MethodOptions.access$22502(result, this.uninterpretedOption_);
/*  9954 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  9958 */         if ((other instanceof DescriptorProtos.MethodOptions)) {
/*  9959 */           return mergeFrom((DescriptorProtos.MethodOptions)other);
/*       */         }
/*  9961 */         super.mergeFrom(other);
/*  9962 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.MethodOptions other)
/*       */       {
/*  9967 */         if (other == DescriptorProtos.MethodOptions.getDefaultInstance()) return this;
/*  9968 */         if (other.hasProtocol()) {
/*  9969 */           setProtocol(other.getProtocol());
/*       */         }
/*  9971 */         if (other.hasDeadline()) {
/*  9972 */           setDeadline(other.getDeadline());
/*       */         }
/*  9974 */         if (other.hasDuplicateSuppression()) {
/*  9975 */           setDuplicateSuppression(other.getDuplicateSuppression());
/*       */         }
/*  9977 */         if (other.hasFailFast()) {
/*  9978 */           setFailFast(other.getFailFast());
/*       */         }
/*  9980 */         if (other.hasClientLogging()) {
/*  9981 */           setClientLogging(other.getClientLogging());
/*       */         }
/*  9983 */         if (other.hasServerLogging()) {
/*  9984 */           setServerLogging(other.getServerLogging());
/*       */         }
/*  9986 */         if (other.hasSecurityLevel()) {
/*  9987 */           setSecurityLevel(other.getSecurityLevel());
/*       */         }
/*  9989 */         if (other.hasResponseFormat()) {
/*  9990 */           setResponseFormat(other.getResponseFormat());
/*       */         }
/*  9992 */         if (other.hasRequestFormat()) {
/*  9993 */           setRequestFormat(other.getRequestFormat());
/*       */         }
/*  9995 */         if (other.hasStreamType()) {
/*  9996 */           setStreamType(other.getStreamType());
/*       */         }
/*  9998 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  9999 */           if (this.uninterpretedOption_.isEmpty()) {
/* 10000 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/* 10001 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/* 10003 */             ensureUninterpretedOptionIsMutable();
/* 10004 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/* 10007 */         mergeExtensionFields(other);
/* 10008 */         mergeUnknownFields(other.getUnknownFields());
/* 10009 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/* 10013 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/* 10014 */           if (!element.isInitialized()) return false;
/*       */         }
/* 10016 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/* 10024 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/* 10028 */           int tag = input.readTag();
/* 10029 */           switch (tag) {
/*       */           case 0:
/* 10031 */             setUnknownFields(unknownFields.build());
/* 10032 */             return this;
/*       */           default:
/* 10034 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/* 10036 */             setUnknownFields(unknownFields.build());
/* 10037 */             return this;
/*       */           case 56:
/* 10042 */             int rawValue = input.readEnum();
/* 10043 */             DescriptorProtos.MethodOptions.Protocol value = DescriptorProtos.MethodOptions.Protocol.valueOf(rawValue);
/* 10044 */             if (value == null)
/* 10045 */               unknownFields.mergeVarintField(7, rawValue);
/*       */             else {
/* 10047 */               setProtocol(value);
/*       */             }
/* 10049 */             break;
/*       */           case 65:
/* 10052 */             setDeadline(input.readDouble());
/* 10053 */             break;
/*       */           case 72:
/* 10056 */             setDuplicateSuppression(input.readBool());
/* 10057 */             break;
/*       */           case 80:
/* 10060 */             setFailFast(input.readBool());
/* 10061 */             break;
/*       */           case 88:
/* 10064 */             setClientLogging(input.readSInt32());
/* 10065 */             break;
/*       */           case 96:
/* 10068 */             setServerLogging(input.readSInt32());
/* 10069 */             break;
/*       */           case 104:
/* 10072 */             int rawValue = input.readEnum();
/* 10073 */             DescriptorProtos.MethodOptions.SecurityLevel value = DescriptorProtos.MethodOptions.SecurityLevel.valueOf(rawValue);
/* 10074 */             if (value == null)
/* 10075 */               unknownFields.mergeVarintField(13, rawValue);
/*       */             else {
/* 10077 */               setSecurityLevel(value);
/*       */             }
/* 10079 */             break;
/*       */           case 120:
/* 10082 */             int rawValue = input.readEnum();
/* 10083 */             DescriptorProtos.MethodOptions.Format value = DescriptorProtos.MethodOptions.Format.valueOf(rawValue);
/* 10084 */             if (value == null)
/* 10085 */               unknownFields.mergeVarintField(15, rawValue);
/*       */             else {
/* 10087 */               setResponseFormat(value);
/*       */             }
/* 10089 */             break;
/*       */           case 136:
/* 10092 */             int rawValue = input.readEnum();
/* 10093 */             DescriptorProtos.MethodOptions.Format value = DescriptorProtos.MethodOptions.Format.valueOf(rawValue);
/* 10094 */             if (value == null)
/* 10095 */               unknownFields.mergeVarintField(17, rawValue);
/*       */             else {
/* 10097 */               setRequestFormat(value);
/*       */             }
/* 10099 */             break;
/*       */           case 146:
/* 10102 */             setStreamType(input.readString());
/* 10103 */             break;
/*       */           case 7994:
/* 10106 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/* 10107 */             input.readMessage(subBuilder, extensionRegistry);
/* 10108 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasProtocol()
/*       */       {
/* 10120 */         return this.hasProtocol;
/*       */       }
/*       */       public DescriptorProtos.MethodOptions.Protocol getProtocol() {
/* 10123 */         return this.protocol_;
/*       */       }
/*       */       public Builder setProtocol(DescriptorProtos.MethodOptions.Protocol value) {
/* 10126 */         if (value == null) {
/* 10127 */           throw new NullPointerException();
/*       */         }
/* 10129 */         this.hasProtocol = true;
/* 10130 */         this.protocol_ = value;
/* 10131 */         return this;
/*       */       }
/*       */       public Builder clearProtocol() {
/* 10134 */         this.hasProtocol = false;
/* 10135 */         this.protocol_ = DescriptorProtos.MethodOptions.Protocol.TCP;
/* 10136 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasDeadline()
/*       */       {
/* 10143 */         return this.hasDeadline;
/*       */       }
/*       */       public double getDeadline() {
/* 10146 */         return this.deadline_;
/*       */       }
/*       */       public Builder setDeadline(double value) {
/* 10149 */         this.hasDeadline = true;
/* 10150 */         this.deadline_ = value;
/* 10151 */         return this;
/*       */       }
/*       */       public Builder clearDeadline() {
/* 10154 */         this.hasDeadline = false;
/* 10155 */         this.deadline_ = -1.0D;
/* 10156 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasDuplicateSuppression()
/*       */       {
/* 10163 */         return this.hasDuplicateSuppression;
/*       */       }
/*       */       public boolean getDuplicateSuppression() {
/* 10166 */         return this.duplicateSuppression_;
/*       */       }
/*       */       public Builder setDuplicateSuppression(boolean value) {
/* 10169 */         this.hasDuplicateSuppression = true;
/* 10170 */         this.duplicateSuppression_ = value;
/* 10171 */         return this;
/*       */       }
/*       */       public Builder clearDuplicateSuppression() {
/* 10174 */         this.hasDuplicateSuppression = false;
/* 10175 */         this.duplicateSuppression_ = false;
/* 10176 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasFailFast()
/*       */       {
/* 10183 */         return this.hasFailFast;
/*       */       }
/*       */       public boolean getFailFast() {
/* 10186 */         return this.failFast_;
/*       */       }
/*       */       public Builder setFailFast(boolean value) {
/* 10189 */         this.hasFailFast = true;
/* 10190 */         this.failFast_ = value;
/* 10191 */         return this;
/*       */       }
/*       */       public Builder clearFailFast() {
/* 10194 */         this.hasFailFast = false;
/* 10195 */         this.failFast_ = false;
/* 10196 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasClientLogging()
/*       */       {
/* 10203 */         return this.hasClientLogging;
/*       */       }
/*       */       public int getClientLogging() {
/* 10206 */         return this.clientLogging_;
/*       */       }
/*       */       public Builder setClientLogging(int value) {
/* 10209 */         this.hasClientLogging = true;
/* 10210 */         this.clientLogging_ = value;
/* 10211 */         return this;
/*       */       }
/*       */       public Builder clearClientLogging() {
/* 10214 */         this.hasClientLogging = false;
/* 10215 */         this.clientLogging_ = 256;
/* 10216 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasServerLogging()
/*       */       {
/* 10223 */         return this.hasServerLogging;
/*       */       }
/*       */       public int getServerLogging() {
/* 10226 */         return this.serverLogging_;
/*       */       }
/*       */       public Builder setServerLogging(int value) {
/* 10229 */         this.hasServerLogging = true;
/* 10230 */         this.serverLogging_ = value;
/* 10231 */         return this;
/*       */       }
/*       */       public Builder clearServerLogging() {
/* 10234 */         this.hasServerLogging = false;
/* 10235 */         this.serverLogging_ = 256;
/* 10236 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasSecurityLevel()
/*       */       {
/* 10243 */         return this.hasSecurityLevel;
/*       */       }
/*       */       public DescriptorProtos.MethodOptions.SecurityLevel getSecurityLevel() {
/* 10246 */         return this.securityLevel_;
/*       */       }
/*       */       public Builder setSecurityLevel(DescriptorProtos.MethodOptions.SecurityLevel value) {
/* 10249 */         if (value == null) {
/* 10250 */           throw new NullPointerException();
/*       */         }
/* 10252 */         this.hasSecurityLevel = true;
/* 10253 */         this.securityLevel_ = value;
/* 10254 */         return this;
/*       */       }
/*       */       public Builder clearSecurityLevel() {
/* 10257 */         this.hasSecurityLevel = false;
/* 10258 */         this.securityLevel_ = DescriptorProtos.MethodOptions.SecurityLevel.NONE;
/* 10259 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasResponseFormat()
/*       */       {
/* 10266 */         return this.hasResponseFormat;
/*       */       }
/*       */       public DescriptorProtos.MethodOptions.Format getResponseFormat() {
/* 10269 */         return this.responseFormat_;
/*       */       }
/*       */       public Builder setResponseFormat(DescriptorProtos.MethodOptions.Format value) {
/* 10272 */         if (value == null) {
/* 10273 */           throw new NullPointerException();
/*       */         }
/* 10275 */         this.hasResponseFormat = true;
/* 10276 */         this.responseFormat_ = value;
/* 10277 */         return this;
/*       */       }
/*       */       public Builder clearResponseFormat() {
/* 10280 */         this.hasResponseFormat = false;
/* 10281 */         this.responseFormat_ = DescriptorProtos.MethodOptions.Format.UNCOMPRESSED;
/* 10282 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasRequestFormat()
/*       */       {
/* 10289 */         return this.hasRequestFormat;
/*       */       }
/*       */       public DescriptorProtos.MethodOptions.Format getRequestFormat() {
/* 10292 */         return this.requestFormat_;
/*       */       }
/*       */       public Builder setRequestFormat(DescriptorProtos.MethodOptions.Format value) {
/* 10295 */         if (value == null) {
/* 10296 */           throw new NullPointerException();
/*       */         }
/* 10298 */         this.hasRequestFormat = true;
/* 10299 */         this.requestFormat_ = value;
/* 10300 */         return this;
/*       */       }
/*       */       public Builder clearRequestFormat() {
/* 10303 */         this.hasRequestFormat = false;
/* 10304 */         this.requestFormat_ = DescriptorProtos.MethodOptions.Format.UNCOMPRESSED;
/* 10305 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasStreamType()
/*       */       {
/* 10312 */         return this.hasStreamType;
/*       */       }
/*       */       public String getStreamType() {
/* 10315 */         return this.streamType_;
/*       */       }
/*       */       public Builder setStreamType(String value) {
/* 10318 */         if (value == null) {
/* 10319 */           throw new NullPointerException();
/*       */         }
/* 10321 */         this.hasStreamType = true;
/* 10322 */         this.streamType_ = value;
/* 10323 */         return this;
/*       */       }
/*       */       public Builder clearStreamType() {
/* 10326 */         this.hasStreamType = false;
/* 10327 */         this.streamType_ = DescriptorProtos.MethodOptions.getDefaultInstance().getStreamType();
/* 10328 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/* 10336 */         if (!this.isUninterpretedOptionMutable) {
/* 10337 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/* 10338 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/* 10342 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/* 10345 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/* 10348 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/* 10352 */         if (value == null) {
/* 10353 */           throw new NullPointerException();
/*       */         }
/* 10355 */         ensureUninterpretedOptionIsMutable();
/* 10356 */         this.uninterpretedOption_.set(index, value);
/* 10357 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/* 10361 */         ensureUninterpretedOptionIsMutable();
/* 10362 */         this.uninterpretedOption_.set(index, builderForValue.build());
/* 10363 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/* 10366 */         if (value == null) {
/* 10367 */           throw new NullPointerException();
/*       */         }
/* 10369 */         ensureUninterpretedOptionIsMutable();
/* 10370 */         this.uninterpretedOption_.add(value);
/* 10371 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/* 10375 */         ensureUninterpretedOptionIsMutable();
/* 10376 */         this.uninterpretedOption_.add(builderForValue.build());
/* 10377 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/* 10381 */         ensureUninterpretedOptionIsMutable();
/* 10382 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/* 10383 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/* 10386 */         this.uninterpretedOption_ = Collections.emptyList();
/* 10387 */         this.isUninterpretedOptionMutable = false;
/* 10388 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum Format
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  9459 */       UNCOMPRESSED(0, 0), 
/*  9460 */       ZIPPY_COMPRESSED(1, 1);
/*       */ 
/*       */       public static final int UNCOMPRESSED_VALUE = 0;
/*       */       public static final int ZIPPY_COMPRESSED_VALUE = 1;
/*       */       private static Internal.EnumLiteMap<Format> internalValueMap;
/*       */       private static final Format[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  9467 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static Format valueOf(int value) {
/*  9470 */         switch (value) { case 0:
/*  9471 */           return UNCOMPRESSED;
/*       */         case 1:
/*  9472 */           return ZIPPY_COMPRESSED; }
/*  9473 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<Format> internalGetValueMap()
/*       */       {
/*  9479 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  9491 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  9495 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  9499 */         return (Descriptors.EnumDescriptor)DescriptorProtos.MethodOptions.getDescriptor().getEnumTypes().get(2);
/*       */       }
/*       */ 
/*       */       public static Format valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  9507 */         if (desc.getType() != getDescriptor()) {
/*  9508 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  9511 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private Format(int index, int value)
/*       */       {
/*  9516 */         this.index = index;
/*  9517 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  9482 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.MethodOptions.Format findValueByNumber(int number) {
/*  9485 */             return DescriptorProtos.MethodOptions.Format.valueOf(number);
/*       */           }
/*       */         };
/*  9502 */         VALUES = new Format[] { UNCOMPRESSED, ZIPPY_COMPRESSED };
/*       */ 
/*  9521 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum SecurityLevel
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  9383 */       NONE(0, 0), 
/*  9384 */       INTEGRITY(1, 1), 
/*  9385 */       PRIVACY_AND_INTEGRITY(2, 2), 
/*  9386 */       STRONG_PRIVACY_AND_INTEGRITY(3, 3);
/*       */ 
/*       */       public static final int NONE_VALUE = 0;
/*       */       public static final int INTEGRITY_VALUE = 1;
/*       */       public static final int PRIVACY_AND_INTEGRITY_VALUE = 2;
/*       */       public static final int STRONG_PRIVACY_AND_INTEGRITY_VALUE = 3;
/*       */       private static Internal.EnumLiteMap<SecurityLevel> internalValueMap;
/*       */       private static final SecurityLevel[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  9395 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static SecurityLevel valueOf(int value) {
/*  9398 */         switch (value) { case 0:
/*  9399 */           return NONE;
/*       */         case 1:
/*  9400 */           return INTEGRITY;
/*       */         case 2:
/*  9401 */           return PRIVACY_AND_INTEGRITY;
/*       */         case 3:
/*  9402 */           return STRONG_PRIVACY_AND_INTEGRITY; }
/*  9403 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<SecurityLevel> internalGetValueMap()
/*       */       {
/*  9409 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  9421 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  9425 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  9429 */         return (Descriptors.EnumDescriptor)DescriptorProtos.MethodOptions.getDescriptor().getEnumTypes().get(1);
/*       */       }
/*       */ 
/*       */       public static SecurityLevel valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  9437 */         if (desc.getType() != getDescriptor()) {
/*  9438 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  9441 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private SecurityLevel(int index, int value)
/*       */       {
/*  9446 */         this.index = index;
/*  9447 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  9412 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.MethodOptions.SecurityLevel findValueByNumber(int number) {
/*  9415 */             return DescriptorProtos.MethodOptions.SecurityLevel.valueOf(number);
/*       */           }
/*       */         };
/*  9432 */         VALUES = new SecurityLevel[] { NONE, INTEGRITY, PRIVACY_AND_INTEGRITY, STRONG_PRIVACY_AND_INTEGRITY };
/*       */ 
/*  9451 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum Protocol
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  9313 */       TCP(0, 0), 
/*  9314 */       UDP(1, 1);
/*       */ 
/*       */       public static final int TCP_VALUE = 0;
/*       */       public static final int UDP_VALUE = 1;
/*       */       private static Internal.EnumLiteMap<Protocol> internalValueMap;
/*       */       private static final Protocol[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  9321 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static Protocol valueOf(int value) {
/*  9324 */         switch (value) { case 0:
/*  9325 */           return TCP;
/*       */         case 1:
/*  9326 */           return UDP; }
/*  9327 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<Protocol> internalGetValueMap()
/*       */       {
/*  9333 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  9345 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  9349 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  9353 */         return (Descriptors.EnumDescriptor)DescriptorProtos.MethodOptions.getDescriptor().getEnumTypes().get(0);
/*       */       }
/*       */ 
/*       */       public static Protocol valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  9361 */         if (desc.getType() != getDescriptor()) {
/*  9362 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  9365 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private Protocol(int index, int value)
/*       */       {
/*  9370 */         this.index = index;
/*  9371 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  9336 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.MethodOptions.Protocol findValueByNumber(int number) {
/*  9339 */             return DescriptorProtos.MethodOptions.Protocol.valueOf(number);
/*       */           }
/*       */         };
/*  9356 */         VALUES = new Protocol[] { TCP, UDP };
/*       */ 
/*  9375 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class ServiceOptions extends GeneratedMessage.ExtendableMessage<ServiceOptions>
/*       */   {
/*  9275 */     private static final ServiceOptions defaultInstance = new ServiceOptions(true);
/*       */     public static final int FAILURE_DETECTION_DELAY_FIELD_NUMBER = 16;
/*       */     private boolean hasFailureDetectionDelay;
/*       */     private double failureDetectionDelay_;
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  8947 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private ServiceOptions(Builder builder)
/*       */     {
/*  8873 */       super();
/*       */     }
/*       */     private ServiceOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static ServiceOptions getDefaultInstance() {
/*  8879 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public ServiceOptions getDefaultInstanceForType() {
/*  8883 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  8888 */       return DescriptorProtos.internal_static_proto2_ServiceOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  8893 */       return DescriptorProtos.internal_static_proto2_ServiceOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasFailureDetectionDelay()
/*       */     {
/*  8901 */       return this.hasFailureDetectionDelay;
/*       */     }
/*       */     public double getFailureDetectionDelay() {
/*  8904 */       return this.failureDetectionDelay_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  8911 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  8914 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  8917 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  8921 */       this.failureDetectionDelay_ = -1.0D;
/*  8922 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  8925 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8926 */         if (!element.isInitialized()) return false;
/*       */       }
/*  8928 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  8934 */       getSerializedSize();
/*       */ 
/*  8936 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  8937 */       if (hasFailureDetectionDelay()) {
/*  8938 */         output.writeDouble(16, getFailureDetectionDelay());
/*       */       }
/*  8940 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8941 */         output.writeMessage(999, element);
/*       */       }
/*  8943 */       extensionWriter.writeUntil(536870912, output);
/*  8944 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  8949 */       int size = this.memoizedSerializedSize;
/*  8950 */       if (size != -1) return size;
/*       */ 
/*  8952 */       size = 0;
/*  8953 */       if (hasFailureDetectionDelay()) {
/*  8954 */         size += CodedOutputStream.computeDoubleSize(16, getFailureDetectionDelay());
/*       */       }
/*       */ 
/*  8957 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8958 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  8961 */       size += extensionsSerializedSize();
/*  8962 */       size += getUnknownFields().getSerializedSize();
/*  8963 */       this.memoizedSerializedSize = size;
/*  8964 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  8969 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8975 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8981 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  8986 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8992 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  8997 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  9003 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  9008 */       Builder builder = newBuilder();
/*  9009 */       if (builder.mergeDelimitedFrom(input)) {
/*  9010 */         return builder.buildParsed();
/*       */       }
/*  9012 */       return null;
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  9019 */       Builder builder = newBuilder();
/*  9020 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  9021 */         return builder.buildParsed();
/*       */       }
/*  9023 */       return null;
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  9029 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  9035 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  9039 */       return Builder.access$19500(); } 
/*  9040 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(ServiceOptions prototype) {
/*  9042 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  9044 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  9276 */       DescriptorProtos.internalForceInit();
/*  9277 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.ServiceOptions, Builder>
/*       */     {
/*       */       private boolean hasFailureDetectionDelay;
/*  9193 */       private double failureDetectionDelay_ = -1.0D;
/*       */ 
/*  9212 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  9051 */         return DescriptorProtos.internal_static_proto2_ServiceOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  9056 */         return DescriptorProtos.internal_static_proto2_ServiceOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  9064 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  9068 */         super.clear();
/*  9069 */         this.failureDetectionDelay_ = -1.0D;
/*  9070 */         this.hasFailureDetectionDelay = false;
/*  9071 */         this.uninterpretedOption_ = Collections.emptyList();
/*  9072 */         this.isUninterpretedOptionMutable = false;
/*  9073 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  9077 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  9082 */         return DescriptorProtos.ServiceOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.ServiceOptions getDefaultInstanceForType() {
/*  9086 */         return DescriptorProtos.ServiceOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.ServiceOptions build() {
/*  9090 */         DescriptorProtos.ServiceOptions result = buildPartial();
/*  9091 */         if (!result.isInitialized()) {
/*  9092 */           throw newUninitializedMessageException(result);
/*       */         }
/*  9094 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.ServiceOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  9099 */         DescriptorProtos.ServiceOptions result = buildPartial();
/*  9100 */         if (!result.isInitialized()) {
/*  9101 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  9104 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.ServiceOptions buildPartial() {
/*  9108 */         DescriptorProtos.ServiceOptions result = new DescriptorProtos.ServiceOptions(this, null);
/*  9109 */         DescriptorProtos.ServiceOptions.access$19702(result, this.hasFailureDetectionDelay);
/*  9110 */         DescriptorProtos.ServiceOptions.access$19802(result, this.failureDetectionDelay_);
/*  9111 */         if (this.isUninterpretedOptionMutable) {
/*  9112 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  9113 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  9115 */         DescriptorProtos.ServiceOptions.access$19902(result, this.uninterpretedOption_);
/*  9116 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  9120 */         if ((other instanceof DescriptorProtos.ServiceOptions)) {
/*  9121 */           return mergeFrom((DescriptorProtos.ServiceOptions)other);
/*       */         }
/*  9123 */         super.mergeFrom(other);
/*  9124 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.ServiceOptions other)
/*       */       {
/*  9129 */         if (other == DescriptorProtos.ServiceOptions.getDefaultInstance()) return this;
/*  9130 */         if (other.hasFailureDetectionDelay()) {
/*  9131 */           setFailureDetectionDelay(other.getFailureDetectionDelay());
/*       */         }
/*  9133 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  9134 */           if (this.uninterpretedOption_.isEmpty()) {
/*  9135 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/*  9136 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/*  9138 */             ensureUninterpretedOptionIsMutable();
/*  9139 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/*  9142 */         mergeExtensionFields(other);
/*  9143 */         mergeUnknownFields(other.getUnknownFields());
/*  9144 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  9148 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  9149 */           if (!element.isInitialized()) return false;
/*       */         }
/*  9151 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  9159 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  9163 */           int tag = input.readTag();
/*  9164 */           switch (tag) {
/*       */           case 0:
/*  9166 */             setUnknownFields(unknownFields.build());
/*  9167 */             return this;
/*       */           default:
/*  9169 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  9171 */             setUnknownFields(unknownFields.build());
/*  9172 */             return this;
/*       */           case 129:
/*  9177 */             setFailureDetectionDelay(input.readDouble());
/*  9178 */             break;
/*       */           case 7994:
/*  9181 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/*  9182 */             input.readMessage(subBuilder, extensionRegistry);
/*  9183 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasFailureDetectionDelay()
/*       */       {
/*  9195 */         return this.hasFailureDetectionDelay;
/*       */       }
/*       */       public double getFailureDetectionDelay() {
/*  9198 */         return this.failureDetectionDelay_;
/*       */       }
/*       */       public Builder setFailureDetectionDelay(double value) {
/*  9201 */         this.hasFailureDetectionDelay = true;
/*  9202 */         this.failureDetectionDelay_ = value;
/*  9203 */         return this;
/*       */       }
/*       */       public Builder clearFailureDetectionDelay() {
/*  9206 */         this.hasFailureDetectionDelay = false;
/*  9207 */         this.failureDetectionDelay_ = -1.0D;
/*  9208 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/*  9216 */         if (!this.isUninterpretedOptionMutable) {
/*  9217 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/*  9218 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/*  9222 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/*  9225 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  9228 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/*  9232 */         if (value == null) {
/*  9233 */           throw new NullPointerException();
/*       */         }
/*  9235 */         ensureUninterpretedOptionIsMutable();
/*  9236 */         this.uninterpretedOption_.set(index, value);
/*  9237 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  9241 */         ensureUninterpretedOptionIsMutable();
/*  9242 */         this.uninterpretedOption_.set(index, builderForValue.build());
/*  9243 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/*  9246 */         if (value == null) {
/*  9247 */           throw new NullPointerException();
/*       */         }
/*  9249 */         ensureUninterpretedOptionIsMutable();
/*  9250 */         this.uninterpretedOption_.add(value);
/*  9251 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  9255 */         ensureUninterpretedOptionIsMutable();
/*  9256 */         this.uninterpretedOption_.add(builderForValue.build());
/*  9257 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/*  9261 */         ensureUninterpretedOptionIsMutable();
/*  9262 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/*  9263 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/*  9266 */         this.uninterpretedOption_ = Collections.emptyList();
/*  9267 */         this.isUninterpretedOptionMutable = false;
/*  9268 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class EnumValueOptions extends GeneratedMessage.ExtendableMessage<EnumValueOptions>
/*       */   {
/*  8860 */     private static final EnumValueOptions defaultInstance = new EnumValueOptions(true);
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  8567 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private EnumValueOptions(Builder builder)
/*       */     {
/*  8508 */       super();
/*       */     }
/*       */     private EnumValueOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions getDefaultInstance() {
/*  8514 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public EnumValueOptions getDefaultInstanceForType() {
/*  8518 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  8523 */       return DescriptorProtos.internal_static_proto2_EnumValueOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  8528 */       return DescriptorProtos.internal_static_proto2_EnumValueOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  8535 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  8538 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  8541 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  8545 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  8548 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8549 */         if (!element.isInitialized()) return false;
/*       */       }
/*  8551 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  8557 */       getSerializedSize();
/*       */ 
/*  8559 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  8560 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8561 */         output.writeMessage(999, element);
/*       */       }
/*  8563 */       extensionWriter.writeUntil(536870912, output);
/*  8564 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  8569 */       int size = this.memoizedSerializedSize;
/*  8570 */       if (size != -1) return size;
/*       */ 
/*  8572 */       size = 0;
/*  8573 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8574 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  8577 */       size += extensionsSerializedSize();
/*  8578 */       size += getUnknownFields().getSerializedSize();
/*  8579 */       this.memoizedSerializedSize = size;
/*  8580 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  8585 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8591 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8597 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  8602 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8608 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  8613 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  8619 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  8624 */       Builder builder = newBuilder();
/*  8625 */       if (builder.mergeDelimitedFrom(input)) {
/*  8626 */         return builder.buildParsed();
/*       */       }
/*  8628 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  8635 */       Builder builder = newBuilder();
/*  8636 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  8637 */         return builder.buildParsed();
/*       */       }
/*  8639 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  8645 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  8651 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  8655 */       return Builder.access$18900(); } 
/*  8656 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(EnumValueOptions prototype) {
/*  8658 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  8660 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  8861 */       DescriptorProtos.internalForceInit();
/*  8862 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.EnumValueOptions, Builder>
/*       */     {
/*  8797 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  8667 */         return DescriptorProtos.internal_static_proto2_EnumValueOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  8672 */         return DescriptorProtos.internal_static_proto2_EnumValueOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  8680 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  8684 */         super.clear();
/*  8685 */         this.uninterpretedOption_ = Collections.emptyList();
/*  8686 */         this.isUninterpretedOptionMutable = false;
/*  8687 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  8691 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  8696 */         return DescriptorProtos.EnumValueOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumValueOptions getDefaultInstanceForType() {
/*  8700 */         return DescriptorProtos.EnumValueOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumValueOptions build() {
/*  8704 */         DescriptorProtos.EnumValueOptions result = buildPartial();
/*  8705 */         if (!result.isInitialized()) {
/*  8706 */           throw newUninitializedMessageException(result);
/*       */         }
/*  8708 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.EnumValueOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  8713 */         DescriptorProtos.EnumValueOptions result = buildPartial();
/*  8714 */         if (!result.isInitialized()) {
/*  8715 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  8718 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumValueOptions buildPartial() {
/*  8722 */         DescriptorProtos.EnumValueOptions result = new DescriptorProtos.EnumValueOptions(this, null);
/*  8723 */         if (this.isUninterpretedOptionMutable) {
/*  8724 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  8725 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  8727 */         DescriptorProtos.EnumValueOptions.access$19102(result, this.uninterpretedOption_);
/*  8728 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  8732 */         if ((other instanceof DescriptorProtos.EnumValueOptions)) {
/*  8733 */           return mergeFrom((DescriptorProtos.EnumValueOptions)other);
/*       */         }
/*  8735 */         super.mergeFrom(other);
/*  8736 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.EnumValueOptions other)
/*       */       {
/*  8741 */         if (other == DescriptorProtos.EnumValueOptions.getDefaultInstance()) return this;
/*  8742 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  8743 */           if (this.uninterpretedOption_.isEmpty()) {
/*  8744 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/*  8745 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/*  8747 */             ensureUninterpretedOptionIsMutable();
/*  8748 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/*  8751 */         mergeExtensionFields(other);
/*  8752 */         mergeUnknownFields(other.getUnknownFields());
/*  8753 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  8757 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8758 */           if (!element.isInitialized()) return false;
/*       */         }
/*  8760 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  8768 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  8772 */           int tag = input.readTag();
/*  8773 */           switch (tag) {
/*       */           case 0:
/*  8775 */             setUnknownFields(unknownFields.build());
/*  8776 */             return this;
/*       */           default:
/*  8778 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  8780 */             setUnknownFields(unknownFields.build());
/*  8781 */             return this;
/*       */           case 7994:
/*  8786 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/*  8787 */             input.readMessage(subBuilder, extensionRegistry);
/*  8788 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/*  8801 */         if (!this.isUninterpretedOptionMutable) {
/*  8802 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/*  8803 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/*  8807 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/*  8810 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  8813 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/*  8817 */         if (value == null) {
/*  8818 */           throw new NullPointerException();
/*       */         }
/*  8820 */         ensureUninterpretedOptionIsMutable();
/*  8821 */         this.uninterpretedOption_.set(index, value);
/*  8822 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  8826 */         ensureUninterpretedOptionIsMutable();
/*  8827 */         this.uninterpretedOption_.set(index, builderForValue.build());
/*  8828 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/*  8831 */         if (value == null) {
/*  8832 */           throw new NullPointerException();
/*       */         }
/*  8834 */         ensureUninterpretedOptionIsMutable();
/*  8835 */         this.uninterpretedOption_.add(value);
/*  8836 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  8840 */         ensureUninterpretedOptionIsMutable();
/*  8841 */         this.uninterpretedOption_.add(builderForValue.build());
/*  8842 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/*  8846 */         ensureUninterpretedOptionIsMutable();
/*  8847 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/*  8848 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/*  8851 */         this.uninterpretedOption_ = Collections.emptyList();
/*  8852 */         this.isUninterpretedOptionMutable = false;
/*  8853 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class EnumOptions extends GeneratedMessage.ExtendableMessage<EnumOptions>
/*       */   {
/*  8495 */     private static final EnumOptions defaultInstance = new EnumOptions(true);
/*       */     public static final int PROTO1_NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasProto1Name;
/*       */     private String proto1Name_;
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  8164 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private EnumOptions(Builder builder)
/*       */     {
/*  8090 */       super();
/*       */     }
/*       */     private EnumOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static EnumOptions getDefaultInstance() {
/*  8096 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public EnumOptions getDefaultInstanceForType() {
/*  8100 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  8105 */       return DescriptorProtos.internal_static_proto2_EnumOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  8110 */       return DescriptorProtos.internal_static_proto2_EnumOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasProto1Name()
/*       */     {
/*  8118 */       return this.hasProto1Name;
/*       */     }
/*       */     public String getProto1Name() {
/*  8121 */       return this.proto1Name_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  8128 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  8131 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  8134 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  8138 */       this.proto1Name_ = "";
/*  8139 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  8142 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8143 */         if (!element.isInitialized()) return false;
/*       */       }
/*  8145 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  8151 */       getSerializedSize();
/*       */ 
/*  8153 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  8154 */       if (hasProto1Name()) {
/*  8155 */         output.writeString(1, getProto1Name());
/*       */       }
/*  8157 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8158 */         output.writeMessage(999, element);
/*       */       }
/*  8160 */       extensionWriter.writeUntil(536870912, output);
/*  8161 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  8166 */       int size = this.memoizedSerializedSize;
/*  8167 */       if (size != -1) return size;
/*       */ 
/*  8169 */       size = 0;
/*  8170 */       if (hasProto1Name()) {
/*  8171 */         size += CodedOutputStream.computeStringSize(1, getProto1Name());
/*       */       }
/*       */ 
/*  8174 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8175 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  8178 */       size += extensionsSerializedSize();
/*  8179 */       size += getUnknownFields().getSerializedSize();
/*  8180 */       this.memoizedSerializedSize = size;
/*  8181 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  8186 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8192 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8198 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  8203 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  8209 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  8214 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  8220 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  8225 */       Builder builder = newBuilder();
/*  8226 */       if (builder.mergeDelimitedFrom(input)) {
/*  8227 */         return builder.buildParsed();
/*       */       }
/*  8229 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  8236 */       Builder builder = newBuilder();
/*  8237 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  8238 */         return builder.buildParsed();
/*       */       }
/*  8240 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  8246 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  8252 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  8256 */       return Builder.access$18100(); } 
/*  8257 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(EnumOptions prototype) {
/*  8259 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  8261 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  8496 */       DescriptorProtos.internalForceInit();
/*  8497 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.EnumOptions, Builder>
/*       */     {
/*       */       private boolean hasProto1Name;
/*  8410 */       private String proto1Name_ = "";
/*       */ 
/*  8432 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  8268 */         return DescriptorProtos.internal_static_proto2_EnumOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  8273 */         return DescriptorProtos.internal_static_proto2_EnumOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  8281 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  8285 */         super.clear();
/*  8286 */         this.proto1Name_ = "";
/*  8287 */         this.hasProto1Name = false;
/*  8288 */         this.uninterpretedOption_ = Collections.emptyList();
/*  8289 */         this.isUninterpretedOptionMutable = false;
/*  8290 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  8294 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  8299 */         return DescriptorProtos.EnumOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumOptions getDefaultInstanceForType() {
/*  8303 */         return DescriptorProtos.EnumOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumOptions build() {
/*  8307 */         DescriptorProtos.EnumOptions result = buildPartial();
/*  8308 */         if (!result.isInitialized()) {
/*  8309 */           throw newUninitializedMessageException(result);
/*       */         }
/*  8311 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.EnumOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  8316 */         DescriptorProtos.EnumOptions result = buildPartial();
/*  8317 */         if (!result.isInitialized()) {
/*  8318 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  8321 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumOptions buildPartial() {
/*  8325 */         DescriptorProtos.EnumOptions result = new DescriptorProtos.EnumOptions(this, null);
/*  8326 */         DescriptorProtos.EnumOptions.access$18302(result, this.hasProto1Name);
/*  8327 */         DescriptorProtos.EnumOptions.access$18402(result, this.proto1Name_);
/*  8328 */         if (this.isUninterpretedOptionMutable) {
/*  8329 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  8330 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  8332 */         DescriptorProtos.EnumOptions.access$18502(result, this.uninterpretedOption_);
/*  8333 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  8337 */         if ((other instanceof DescriptorProtos.EnumOptions)) {
/*  8338 */           return mergeFrom((DescriptorProtos.EnumOptions)other);
/*       */         }
/*  8340 */         super.mergeFrom(other);
/*  8341 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.EnumOptions other)
/*       */       {
/*  8346 */         if (other == DescriptorProtos.EnumOptions.getDefaultInstance()) return this;
/*  8347 */         if (other.hasProto1Name()) {
/*  8348 */           setProto1Name(other.getProto1Name());
/*       */         }
/*  8350 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  8351 */           if (this.uninterpretedOption_.isEmpty()) {
/*  8352 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/*  8353 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/*  8355 */             ensureUninterpretedOptionIsMutable();
/*  8356 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/*  8359 */         mergeExtensionFields(other);
/*  8360 */         mergeUnknownFields(other.getUnknownFields());
/*  8361 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  8365 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  8366 */           if (!element.isInitialized()) return false;
/*       */         }
/*  8368 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  8376 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  8380 */           int tag = input.readTag();
/*  8381 */           switch (tag) {
/*       */           case 0:
/*  8383 */             setUnknownFields(unknownFields.build());
/*  8384 */             return this;
/*       */           default:
/*  8386 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  8388 */             setUnknownFields(unknownFields.build());
/*  8389 */             return this;
/*       */           case 10:
/*  8394 */             setProto1Name(input.readString());
/*  8395 */             break;
/*       */           case 7994:
/*  8398 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/*  8399 */             input.readMessage(subBuilder, extensionRegistry);
/*  8400 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasProto1Name()
/*       */       {
/*  8412 */         return this.hasProto1Name;
/*       */       }
/*       */       public String getProto1Name() {
/*  8415 */         return this.proto1Name_;
/*       */       }
/*       */       public Builder setProto1Name(String value) {
/*  8418 */         if (value == null) {
/*  8419 */           throw new NullPointerException();
/*       */         }
/*  8421 */         this.hasProto1Name = true;
/*  8422 */         this.proto1Name_ = value;
/*  8423 */         return this;
/*       */       }
/*       */       public Builder clearProto1Name() {
/*  8426 */         this.hasProto1Name = false;
/*  8427 */         this.proto1Name_ = DescriptorProtos.EnumOptions.getDefaultInstance().getProto1Name();
/*  8428 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/*  8436 */         if (!this.isUninterpretedOptionMutable) {
/*  8437 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/*  8438 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/*  8442 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/*  8445 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  8448 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/*  8452 */         if (value == null) {
/*  8453 */           throw new NullPointerException();
/*       */         }
/*  8455 */         ensureUninterpretedOptionIsMutable();
/*  8456 */         this.uninterpretedOption_.set(index, value);
/*  8457 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  8461 */         ensureUninterpretedOptionIsMutable();
/*  8462 */         this.uninterpretedOption_.set(index, builderForValue.build());
/*  8463 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/*  8466 */         if (value == null) {
/*  8467 */           throw new NullPointerException();
/*       */         }
/*  8469 */         ensureUninterpretedOptionIsMutable();
/*  8470 */         this.uninterpretedOption_.add(value);
/*  8471 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  8475 */         ensureUninterpretedOptionIsMutable();
/*  8476 */         this.uninterpretedOption_.add(builderForValue.build());
/*  8477 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/*  8481 */         ensureUninterpretedOptionIsMutable();
/*  8482 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/*  8483 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/*  8486 */         this.uninterpretedOption_ = Collections.emptyList();
/*  8487 */         this.isUninterpretedOptionMutable = false;
/*  8488 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class FieldOptions extends GeneratedMessage.ExtendableMessage<FieldOptions>
/*       */   {
/*  8077 */     private static final FieldOptions defaultInstance = new FieldOptions(true);
/*       */     public static final int CTYPE_FIELD_NUMBER = 1;
/*       */     private boolean hasCtype;
/*       */     private CType ctype_;
/*       */     public static final int PACKED_FIELD_NUMBER = 2;
/*       */     private boolean hasPacked;
/*       */     private boolean packed_;
/*       */     public static final int JTYPE_FIELD_NUMBER = 4;
/*       */     private boolean hasJtype;
/*       */     private JType jtype_;
/*       */     public static final int DEPRECATED_FIELD_NUMBER = 3;
/*       */     private boolean hasDeprecated;
/*       */     private boolean deprecated_;
/*       */     public static final int EXPERIMENTAL_MAP_KEY_FIELD_NUMBER = 9;
/*       */     private boolean hasExperimentalMapKey;
/*       */     private String experimentalMapKey_;
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  7588 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private FieldOptions(Builder builder)
/*       */     {
/*  7311 */       super();
/*       */     }
/*       */     private FieldOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static FieldOptions getDefaultInstance() {
/*  7317 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public FieldOptions getDefaultInstanceForType() {
/*  7321 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  7326 */       return DescriptorProtos.internal_static_proto2_FieldOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  7331 */       return DescriptorProtos.internal_static_proto2_FieldOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasCtype()
/*       */     {
/*  7482 */       return this.hasCtype;
/*       */     }
/*       */     public CType getCtype() {
/*  7485 */       return this.ctype_;
/*       */     }
/*       */ 
/*       */     public boolean hasPacked()
/*       */     {
/*  7493 */       return this.hasPacked;
/*       */     }
/*       */     public boolean getPacked() {
/*  7496 */       return this.packed_;
/*       */     }
/*       */ 
/*       */     public boolean hasJtype()
/*       */     {
/*  7504 */       return this.hasJtype;
/*       */     }
/*       */     public JType getJtype() {
/*  7507 */       return this.jtype_;
/*       */     }
/*       */ 
/*       */     public boolean hasDeprecated()
/*       */     {
/*  7515 */       return this.hasDeprecated;
/*       */     }
/*       */     public boolean getDeprecated() {
/*  7518 */       return this.deprecated_;
/*       */     }
/*       */ 
/*       */     public boolean hasExperimentalMapKey()
/*       */     {
/*  7526 */       return this.hasExperimentalMapKey;
/*       */     }
/*       */     public String getExperimentalMapKey() {
/*  7529 */       return this.experimentalMapKey_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  7536 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  7539 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  7542 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  7546 */       this.ctype_ = CType.STRING;
/*  7547 */       this.packed_ = false;
/*  7548 */       this.jtype_ = JType.NORMAL;
/*  7549 */       this.deprecated_ = false;
/*  7550 */       this.experimentalMapKey_ = "";
/*  7551 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  7554 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  7555 */         if (!element.isInitialized()) return false;
/*       */       }
/*  7557 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  7563 */       getSerializedSize();
/*       */ 
/*  7565 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  7566 */       if (hasCtype()) {
/*  7567 */         output.writeEnum(1, getCtype().getNumber());
/*       */       }
/*  7569 */       if (hasPacked()) {
/*  7570 */         output.writeBool(2, getPacked());
/*       */       }
/*  7572 */       if (hasDeprecated()) {
/*  7573 */         output.writeBool(3, getDeprecated());
/*       */       }
/*  7575 */       if (hasJtype()) {
/*  7576 */         output.writeEnum(4, getJtype().getNumber());
/*       */       }
/*  7578 */       if (hasExperimentalMapKey()) {
/*  7579 */         output.writeString(9, getExperimentalMapKey());
/*       */       }
/*  7581 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  7582 */         output.writeMessage(999, element);
/*       */       }
/*  7584 */       extensionWriter.writeUntil(536870912, output);
/*  7585 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  7590 */       int size = this.memoizedSerializedSize;
/*  7591 */       if (size != -1) return size;
/*       */ 
/*  7593 */       size = 0;
/*  7594 */       if (hasCtype()) {
/*  7595 */         size += CodedOutputStream.computeEnumSize(1, getCtype().getNumber());
/*       */       }
/*       */ 
/*  7598 */       if (hasPacked()) {
/*  7599 */         size += CodedOutputStream.computeBoolSize(2, getPacked());
/*       */       }
/*       */ 
/*  7602 */       if (hasDeprecated()) {
/*  7603 */         size += CodedOutputStream.computeBoolSize(3, getDeprecated());
/*       */       }
/*       */ 
/*  7606 */       if (hasJtype()) {
/*  7607 */         size += CodedOutputStream.computeEnumSize(4, getJtype().getNumber());
/*       */       }
/*       */ 
/*  7610 */       if (hasExperimentalMapKey()) {
/*  7611 */         size += CodedOutputStream.computeStringSize(9, getExperimentalMapKey());
/*       */       }
/*       */ 
/*  7614 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  7615 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  7618 */       size += extensionsSerializedSize();
/*  7619 */       size += getUnknownFields().getSerializedSize();
/*  7620 */       this.memoizedSerializedSize = size;
/*  7621 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  7626 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  7632 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  7638 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  7643 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  7649 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  7654 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  7660 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  7665 */       Builder builder = newBuilder();
/*  7666 */       if (builder.mergeDelimitedFrom(input)) {
/*  7667 */         return builder.buildParsed();
/*       */       }
/*  7669 */       return null;
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  7676 */       Builder builder = newBuilder();
/*  7677 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  7678 */         return builder.buildParsed();
/*       */       }
/*  7680 */       return null;
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  7686 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  7692 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  7696 */       return Builder.access$16500(); } 
/*  7697 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(FieldOptions prototype) {
/*  7699 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  7701 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  8078 */       DescriptorProtos.internalForceInit();
/*  8079 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.FieldOptions, Builder>
/*       */     {
/*       */       private boolean hasCtype;
/*  7906 */       private DescriptorProtos.FieldOptions.CType ctype_ = DescriptorProtos.FieldOptions.CType.STRING;
/*       */       private boolean hasPacked;
/*       */       private boolean packed_;
/*       */       private boolean hasJtype;
/*  7949 */       private DescriptorProtos.FieldOptions.JType jtype_ = DescriptorProtos.FieldOptions.JType.NORMAL;
/*       */       private boolean hasDeprecated;
/*       */       private boolean deprecated_;
/*       */       private boolean hasExperimentalMapKey;
/*  7992 */       private String experimentalMapKey_ = "";
/*       */ 
/*  8014 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  7708 */         return DescriptorProtos.internal_static_proto2_FieldOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  7713 */         return DescriptorProtos.internal_static_proto2_FieldOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  7721 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  7725 */         super.clear();
/*  7726 */         this.ctype_ = DescriptorProtos.FieldOptions.CType.STRING;
/*  7727 */         this.hasCtype = false;
/*  7728 */         this.packed_ = false;
/*  7729 */         this.hasPacked = false;
/*  7730 */         this.jtype_ = DescriptorProtos.FieldOptions.JType.NORMAL;
/*  7731 */         this.hasJtype = false;
/*  7732 */         this.deprecated_ = false;
/*  7733 */         this.hasDeprecated = false;
/*  7734 */         this.experimentalMapKey_ = "";
/*  7735 */         this.hasExperimentalMapKey = false;
/*  7736 */         this.uninterpretedOption_ = Collections.emptyList();
/*  7737 */         this.isUninterpretedOptionMutable = false;
/*  7738 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  7742 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  7747 */         return DescriptorProtos.FieldOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FieldOptions getDefaultInstanceForType() {
/*  7751 */         return DescriptorProtos.FieldOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FieldOptions build() {
/*  7755 */         DescriptorProtos.FieldOptions result = buildPartial();
/*  7756 */         if (!result.isInitialized()) {
/*  7757 */           throw newUninitializedMessageException(result);
/*       */         }
/*  7759 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.FieldOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  7764 */         DescriptorProtos.FieldOptions result = buildPartial();
/*  7765 */         if (!result.isInitialized()) {
/*  7766 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  7769 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FieldOptions buildPartial() {
/*  7773 */         DescriptorProtos.FieldOptions result = new DescriptorProtos.FieldOptions(this, null);
/*  7774 */         DescriptorProtos.FieldOptions.access$16702(result, this.hasCtype);
/*  7775 */         DescriptorProtos.FieldOptions.access$16802(result, this.ctype_);
/*  7776 */         DescriptorProtos.FieldOptions.access$16902(result, this.hasPacked);
/*  7777 */         DescriptorProtos.FieldOptions.access$17002(result, this.packed_);
/*  7778 */         DescriptorProtos.FieldOptions.access$17102(result, this.hasJtype);
/*  7779 */         DescriptorProtos.FieldOptions.access$17202(result, this.jtype_);
/*  7780 */         DescriptorProtos.FieldOptions.access$17302(result, this.hasDeprecated);
/*  7781 */         DescriptorProtos.FieldOptions.access$17402(result, this.deprecated_);
/*  7782 */         DescriptorProtos.FieldOptions.access$17502(result, this.hasExperimentalMapKey);
/*  7783 */         DescriptorProtos.FieldOptions.access$17602(result, this.experimentalMapKey_);
/*  7784 */         if (this.isUninterpretedOptionMutable) {
/*  7785 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  7786 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  7788 */         DescriptorProtos.FieldOptions.access$17702(result, this.uninterpretedOption_);
/*  7789 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  7793 */         if ((other instanceof DescriptorProtos.FieldOptions)) {
/*  7794 */           return mergeFrom((DescriptorProtos.FieldOptions)other);
/*       */         }
/*  7796 */         super.mergeFrom(other);
/*  7797 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.FieldOptions other)
/*       */       {
/*  7802 */         if (other == DescriptorProtos.FieldOptions.getDefaultInstance()) return this;
/*  7803 */         if (other.hasCtype()) {
/*  7804 */           setCtype(other.getCtype());
/*       */         }
/*  7806 */         if (other.hasPacked()) {
/*  7807 */           setPacked(other.getPacked());
/*       */         }
/*  7809 */         if (other.hasJtype()) {
/*  7810 */           setJtype(other.getJtype());
/*       */         }
/*  7812 */         if (other.hasDeprecated()) {
/*  7813 */           setDeprecated(other.getDeprecated());
/*       */         }
/*  7815 */         if (other.hasExperimentalMapKey()) {
/*  7816 */           setExperimentalMapKey(other.getExperimentalMapKey());
/*       */         }
/*  7818 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  7819 */           if (this.uninterpretedOption_.isEmpty()) {
/*  7820 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/*  7821 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/*  7823 */             ensureUninterpretedOptionIsMutable();
/*  7824 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/*  7827 */         mergeExtensionFields(other);
/*  7828 */         mergeUnknownFields(other.getUnknownFields());
/*  7829 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  7833 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  7834 */           if (!element.isInitialized()) return false;
/*       */         }
/*  7836 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  7844 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  7848 */           int tag = input.readTag();
/*  7849 */           switch (tag) {
/*       */           case 0:
/*  7851 */             setUnknownFields(unknownFields.build());
/*  7852 */             return this;
/*       */           default:
/*  7854 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  7856 */             setUnknownFields(unknownFields.build());
/*  7857 */             return this;
/*       */           case 8:
/*  7862 */             int rawValue = input.readEnum();
/*  7863 */             DescriptorProtos.FieldOptions.CType value = DescriptorProtos.FieldOptions.CType.valueOf(rawValue);
/*  7864 */             if (value == null)
/*  7865 */               unknownFields.mergeVarintField(1, rawValue);
/*       */             else {
/*  7867 */               setCtype(value);
/*       */             }
/*  7869 */             break;
/*       */           case 16:
/*  7872 */             setPacked(input.readBool());
/*  7873 */             break;
/*       */           case 24:
/*  7876 */             setDeprecated(input.readBool());
/*  7877 */             break;
/*       */           case 32:
/*  7880 */             int rawValue = input.readEnum();
/*  7881 */             DescriptorProtos.FieldOptions.JType value = DescriptorProtos.FieldOptions.JType.valueOf(rawValue);
/*  7882 */             if (value == null)
/*  7883 */               unknownFields.mergeVarintField(4, rawValue);
/*       */             else {
/*  7885 */               setJtype(value);
/*       */             }
/*  7887 */             break;
/*       */           case 74:
/*  7890 */             setExperimentalMapKey(input.readString());
/*  7891 */             break;
/*       */           case 7994:
/*  7894 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/*  7895 */             input.readMessage(subBuilder, extensionRegistry);
/*  7896 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasCtype()
/*       */       {
/*  7908 */         return this.hasCtype;
/*       */       }
/*       */       public DescriptorProtos.FieldOptions.CType getCtype() {
/*  7911 */         return this.ctype_;
/*       */       }
/*       */       public Builder setCtype(DescriptorProtos.FieldOptions.CType value) {
/*  7914 */         if (value == null) {
/*  7915 */           throw new NullPointerException();
/*       */         }
/*  7917 */         this.hasCtype = true;
/*  7918 */         this.ctype_ = value;
/*  7919 */         return this;
/*       */       }
/*       */       public Builder clearCtype() {
/*  7922 */         this.hasCtype = false;
/*  7923 */         this.ctype_ = DescriptorProtos.FieldOptions.CType.STRING;
/*  7924 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasPacked()
/*       */       {
/*  7931 */         return this.hasPacked;
/*       */       }
/*       */       public boolean getPacked() {
/*  7934 */         return this.packed_;
/*       */       }
/*       */       public Builder setPacked(boolean value) {
/*  7937 */         this.hasPacked = true;
/*  7938 */         this.packed_ = value;
/*  7939 */         return this;
/*       */       }
/*       */       public Builder clearPacked() {
/*  7942 */         this.hasPacked = false;
/*  7943 */         this.packed_ = false;
/*  7944 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJtype()
/*       */       {
/*  7951 */         return this.hasJtype;
/*       */       }
/*       */       public DescriptorProtos.FieldOptions.JType getJtype() {
/*  7954 */         return this.jtype_;
/*       */       }
/*       */       public Builder setJtype(DescriptorProtos.FieldOptions.JType value) {
/*  7957 */         if (value == null) {
/*  7958 */           throw new NullPointerException();
/*       */         }
/*  7960 */         this.hasJtype = true;
/*  7961 */         this.jtype_ = value;
/*  7962 */         return this;
/*       */       }
/*       */       public Builder clearJtype() {
/*  7965 */         this.hasJtype = false;
/*  7966 */         this.jtype_ = DescriptorProtos.FieldOptions.JType.NORMAL;
/*  7967 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasDeprecated()
/*       */       {
/*  7974 */         return this.hasDeprecated;
/*       */       }
/*       */       public boolean getDeprecated() {
/*  7977 */         return this.deprecated_;
/*       */       }
/*       */       public Builder setDeprecated(boolean value) {
/*  7980 */         this.hasDeprecated = true;
/*  7981 */         this.deprecated_ = value;
/*  7982 */         return this;
/*       */       }
/*       */       public Builder clearDeprecated() {
/*  7985 */         this.hasDeprecated = false;
/*  7986 */         this.deprecated_ = false;
/*  7987 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasExperimentalMapKey()
/*       */       {
/*  7994 */         return this.hasExperimentalMapKey;
/*       */       }
/*       */       public String getExperimentalMapKey() {
/*  7997 */         return this.experimentalMapKey_;
/*       */       }
/*       */       public Builder setExperimentalMapKey(String value) {
/*  8000 */         if (value == null) {
/*  8001 */           throw new NullPointerException();
/*       */         }
/*  8003 */         this.hasExperimentalMapKey = true;
/*  8004 */         this.experimentalMapKey_ = value;
/*  8005 */         return this;
/*       */       }
/*       */       public Builder clearExperimentalMapKey() {
/*  8008 */         this.hasExperimentalMapKey = false;
/*  8009 */         this.experimentalMapKey_ = DescriptorProtos.FieldOptions.getDefaultInstance().getExperimentalMapKey();
/*  8010 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/*  8018 */         if (!this.isUninterpretedOptionMutable) {
/*  8019 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/*  8020 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/*  8024 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/*  8027 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  8030 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/*  8034 */         if (value == null) {
/*  8035 */           throw new NullPointerException();
/*       */         }
/*  8037 */         ensureUninterpretedOptionIsMutable();
/*  8038 */         this.uninterpretedOption_.set(index, value);
/*  8039 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  8043 */         ensureUninterpretedOptionIsMutable();
/*  8044 */         this.uninterpretedOption_.set(index, builderForValue.build());
/*  8045 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/*  8048 */         if (value == null) {
/*  8049 */           throw new NullPointerException();
/*       */         }
/*  8051 */         ensureUninterpretedOptionIsMutable();
/*  8052 */         this.uninterpretedOption_.add(value);
/*  8053 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  8057 */         ensureUninterpretedOptionIsMutable();
/*  8058 */         this.uninterpretedOption_.add(builderForValue.build());
/*  8059 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/*  8063 */         ensureUninterpretedOptionIsMutable();
/*  8064 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/*  8065 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/*  8068 */         this.uninterpretedOption_ = Collections.emptyList();
/*  8069 */         this.isUninterpretedOptionMutable = false;
/*  8070 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum JType
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  7409 */       NORMAL(0, 0), 
/*  7410 */       BYTES(1, 1);
/*       */ 
/*       */       public static final int NORMAL_VALUE = 0;
/*       */       public static final int BYTES_VALUE = 1;
/*       */       private static Internal.EnumLiteMap<JType> internalValueMap;
/*       */       private static final JType[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  7417 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static JType valueOf(int value) {
/*  7420 */         switch (value) { case 0:
/*  7421 */           return NORMAL;
/*       */         case 1:
/*  7422 */           return BYTES; }
/*  7423 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<JType> internalGetValueMap()
/*       */       {
/*  7429 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  7441 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  7445 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  7449 */         return (Descriptors.EnumDescriptor)DescriptorProtos.FieldOptions.getDescriptor().getEnumTypes().get(1);
/*       */       }
/*       */ 
/*       */       public static JType valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  7457 */         if (desc.getType() != getDescriptor()) {
/*  7458 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  7461 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private JType(int index, int value)
/*       */       {
/*  7466 */         this.index = index;
/*  7467 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  7432 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.FieldOptions.JType findValueByNumber(int number) {
/*  7435 */             return DescriptorProtos.FieldOptions.JType.valueOf(number);
/*       */           }
/*       */         };
/*  7452 */         VALUES = new JType[] { NORMAL, BYTES };
/*       */ 
/*  7471 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum CType
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  7336 */       STRING(0, 0), 
/*  7337 */       CORD(1, 1), 
/*  7338 */       STRING_PIECE(2, 2);
/*       */ 
/*       */       public static final int STRING_VALUE = 0;
/*       */       public static final int CORD_VALUE = 1;
/*       */       public static final int STRING_PIECE_VALUE = 2;
/*       */       private static Internal.EnumLiteMap<CType> internalValueMap;
/*       */       private static final CType[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  7346 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static CType valueOf(int value) {
/*  7349 */         switch (value) { case 0:
/*  7350 */           return STRING;
/*       */         case 1:
/*  7351 */           return CORD;
/*       */         case 2:
/*  7352 */           return STRING_PIECE; }
/*  7353 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<CType> internalGetValueMap()
/*       */       {
/*  7359 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  7371 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  7375 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  7379 */         return (Descriptors.EnumDescriptor)DescriptorProtos.FieldOptions.getDescriptor().getEnumTypes().get(0);
/*       */       }
/*       */ 
/*       */       public static CType valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  7387 */         if (desc.getType() != getDescriptor()) {
/*  7388 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  7391 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private CType(int index, int value)
/*       */       {
/*  7396 */         this.index = index;
/*  7397 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  7362 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.FieldOptions.CType findValueByNumber(int number) {
/*  7365 */             return DescriptorProtos.FieldOptions.CType.valueOf(number);
/*       */           }
/*       */         };
/*  7382 */         VALUES = new CType[] { STRING, CORD, STRING_PIECE };
/*       */ 
/*  7401 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class MessageOptions extends GeneratedMessage.ExtendableMessage<MessageOptions>
/*       */   {
/*  7298 */     private static final MessageOptions defaultInstance = new MessageOptions(true);
/*       */     public static final int MESSAGE_SET_WIRE_FORMAT_FIELD_NUMBER = 1;
/*       */     private boolean hasMessageSetWireFormat;
/*       */     private boolean messageSetWireFormat_;
/*       */     public static final int NO_STANDARD_DESCRIPTOR_ACCESSOR_FIELD_NUMBER = 2;
/*       */     private boolean hasNoStandardDescriptorAccessor;
/*       */     private boolean noStandardDescriptorAccessor_;
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  6935 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private MessageOptions(Builder builder)
/*       */     {
/*  6846 */       super();
/*       */     }
/*       */     private MessageOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static MessageOptions getDefaultInstance() {
/*  6852 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public MessageOptions getDefaultInstanceForType() {
/*  6856 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  6861 */       return DescriptorProtos.internal_static_proto2_MessageOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  6866 */       return DescriptorProtos.internal_static_proto2_MessageOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasMessageSetWireFormat()
/*       */     {
/*  6874 */       return this.hasMessageSetWireFormat;
/*       */     }
/*       */     public boolean getMessageSetWireFormat() {
/*  6877 */       return this.messageSetWireFormat_;
/*       */     }
/*       */ 
/*       */     public boolean hasNoStandardDescriptorAccessor()
/*       */     {
/*  6885 */       return this.hasNoStandardDescriptorAccessor;
/*       */     }
/*       */     public boolean getNoStandardDescriptorAccessor() {
/*  6888 */       return this.noStandardDescriptorAccessor_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  6895 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  6898 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  6901 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  6905 */       this.messageSetWireFormat_ = false;
/*  6906 */       this.noStandardDescriptorAccessor_ = false;
/*  6907 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  6910 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  6911 */         if (!element.isInitialized()) return false;
/*       */       }
/*  6913 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  6919 */       getSerializedSize();
/*       */ 
/*  6921 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  6922 */       if (hasMessageSetWireFormat()) {
/*  6923 */         output.writeBool(1, getMessageSetWireFormat());
/*       */       }
/*  6925 */       if (hasNoStandardDescriptorAccessor()) {
/*  6926 */         output.writeBool(2, getNoStandardDescriptorAccessor());
/*       */       }
/*  6928 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  6929 */         output.writeMessage(999, element);
/*       */       }
/*  6931 */       extensionWriter.writeUntil(536870912, output);
/*  6932 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  6937 */       int size = this.memoizedSerializedSize;
/*  6938 */       if (size != -1) return size;
/*       */ 
/*  6940 */       size = 0;
/*  6941 */       if (hasMessageSetWireFormat()) {
/*  6942 */         size += CodedOutputStream.computeBoolSize(1, getMessageSetWireFormat());
/*       */       }
/*       */ 
/*  6945 */       if (hasNoStandardDescriptorAccessor()) {
/*  6946 */         size += CodedOutputStream.computeBoolSize(2, getNoStandardDescriptorAccessor());
/*       */       }
/*       */ 
/*  6949 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  6950 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  6953 */       size += extensionsSerializedSize();
/*  6954 */       size += getUnknownFields().getSerializedSize();
/*  6955 */       this.memoizedSerializedSize = size;
/*  6956 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  6961 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  6967 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  6973 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  6978 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  6984 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  6989 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  6995 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  7000 */       Builder builder = newBuilder();
/*  7001 */       if (builder.mergeDelimitedFrom(input)) {
/*  7002 */         return builder.buildParsed();
/*       */       }
/*  7004 */       return null;
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  7011 */       Builder builder = newBuilder();
/*  7012 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  7013 */         return builder.buildParsed();
/*       */       }
/*  7015 */       return null;
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  7021 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MessageOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  7027 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  7031 */       return Builder.access$15500(); } 
/*  7032 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(MessageOptions prototype) {
/*  7034 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  7036 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  7299 */       DescriptorProtos.internalForceInit();
/*  7300 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.MessageOptions, Builder>
/*       */     {
/*       */       private boolean hasMessageSetWireFormat;
/*       */       private boolean messageSetWireFormat_;
/*       */       private boolean hasNoStandardDescriptorAccessor;
/*       */       private boolean noStandardDescriptorAccessor_;
/*  7235 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  7043 */         return DescriptorProtos.internal_static_proto2_MessageOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  7048 */         return DescriptorProtos.internal_static_proto2_MessageOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  7056 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  7060 */         super.clear();
/*  7061 */         this.messageSetWireFormat_ = false;
/*  7062 */         this.hasMessageSetWireFormat = false;
/*  7063 */         this.noStandardDescriptorAccessor_ = false;
/*  7064 */         this.hasNoStandardDescriptorAccessor = false;
/*  7065 */         this.uninterpretedOption_ = Collections.emptyList();
/*  7066 */         this.isUninterpretedOptionMutable = false;
/*  7067 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  7071 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  7076 */         return DescriptorProtos.MessageOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MessageOptions getDefaultInstanceForType() {
/*  7080 */         return DescriptorProtos.MessageOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MessageOptions build() {
/*  7084 */         DescriptorProtos.MessageOptions result = buildPartial();
/*  7085 */         if (!result.isInitialized()) {
/*  7086 */           throw newUninitializedMessageException(result);
/*       */         }
/*  7088 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.MessageOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  7093 */         DescriptorProtos.MessageOptions result = buildPartial();
/*  7094 */         if (!result.isInitialized()) {
/*  7095 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  7098 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MessageOptions buildPartial() {
/*  7102 */         DescriptorProtos.MessageOptions result = new DescriptorProtos.MessageOptions(this, null);
/*  7103 */         DescriptorProtos.MessageOptions.access$15702(result, this.hasMessageSetWireFormat);
/*  7104 */         DescriptorProtos.MessageOptions.access$15802(result, this.messageSetWireFormat_);
/*  7105 */         DescriptorProtos.MessageOptions.access$15902(result, this.hasNoStandardDescriptorAccessor);
/*  7106 */         DescriptorProtos.MessageOptions.access$16002(result, this.noStandardDescriptorAccessor_);
/*  7107 */         if (this.isUninterpretedOptionMutable) {
/*  7108 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  7109 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  7111 */         DescriptorProtos.MessageOptions.access$16102(result, this.uninterpretedOption_);
/*  7112 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  7116 */         if ((other instanceof DescriptorProtos.MessageOptions)) {
/*  7117 */           return mergeFrom((DescriptorProtos.MessageOptions)other);
/*       */         }
/*  7119 */         super.mergeFrom(other);
/*  7120 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.MessageOptions other)
/*       */       {
/*  7125 */         if (other == DescriptorProtos.MessageOptions.getDefaultInstance()) return this;
/*  7126 */         if (other.hasMessageSetWireFormat()) {
/*  7127 */           setMessageSetWireFormat(other.getMessageSetWireFormat());
/*       */         }
/*  7129 */         if (other.hasNoStandardDescriptorAccessor()) {
/*  7130 */           setNoStandardDescriptorAccessor(other.getNoStandardDescriptorAccessor());
/*       */         }
/*  7132 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  7133 */           if (this.uninterpretedOption_.isEmpty()) {
/*  7134 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/*  7135 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/*  7137 */             ensureUninterpretedOptionIsMutable();
/*  7138 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/*  7141 */         mergeExtensionFields(other);
/*  7142 */         mergeUnknownFields(other.getUnknownFields());
/*  7143 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  7147 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  7148 */           if (!element.isInitialized()) return false;
/*       */         }
/*  7150 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  7158 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  7162 */           int tag = input.readTag();
/*  7163 */           switch (tag) {
/*       */           case 0:
/*  7165 */             setUnknownFields(unknownFields.build());
/*  7166 */             return this;
/*       */           default:
/*  7168 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  7170 */             setUnknownFields(unknownFields.build());
/*  7171 */             return this;
/*       */           case 8:
/*  7176 */             setMessageSetWireFormat(input.readBool());
/*  7177 */             break;
/*       */           case 16:
/*  7180 */             setNoStandardDescriptorAccessor(input.readBool());
/*  7181 */             break;
/*       */           case 7994:
/*  7184 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/*  7185 */             input.readMessage(subBuilder, extensionRegistry);
/*  7186 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasMessageSetWireFormat()
/*       */       {
/*  7198 */         return this.hasMessageSetWireFormat;
/*       */       }
/*       */       public boolean getMessageSetWireFormat() {
/*  7201 */         return this.messageSetWireFormat_;
/*       */       }
/*       */       public Builder setMessageSetWireFormat(boolean value) {
/*  7204 */         this.hasMessageSetWireFormat = true;
/*  7205 */         this.messageSetWireFormat_ = value;
/*  7206 */         return this;
/*       */       }
/*       */       public Builder clearMessageSetWireFormat() {
/*  7209 */         this.hasMessageSetWireFormat = false;
/*  7210 */         this.messageSetWireFormat_ = false;
/*  7211 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasNoStandardDescriptorAccessor()
/*       */       {
/*  7218 */         return this.hasNoStandardDescriptorAccessor;
/*       */       }
/*       */       public boolean getNoStandardDescriptorAccessor() {
/*  7221 */         return this.noStandardDescriptorAccessor_;
/*       */       }
/*       */       public Builder setNoStandardDescriptorAccessor(boolean value) {
/*  7224 */         this.hasNoStandardDescriptorAccessor = true;
/*  7225 */         this.noStandardDescriptorAccessor_ = value;
/*  7226 */         return this;
/*       */       }
/*       */       public Builder clearNoStandardDescriptorAccessor() {
/*  7229 */         this.hasNoStandardDescriptorAccessor = false;
/*  7230 */         this.noStandardDescriptorAccessor_ = false;
/*  7231 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/*  7239 */         if (!this.isUninterpretedOptionMutable) {
/*  7240 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/*  7241 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/*  7245 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/*  7248 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  7251 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/*  7255 */         if (value == null) {
/*  7256 */           throw new NullPointerException();
/*       */         }
/*  7258 */         ensureUninterpretedOptionIsMutable();
/*  7259 */         this.uninterpretedOption_.set(index, value);
/*  7260 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  7264 */         ensureUninterpretedOptionIsMutable();
/*  7265 */         this.uninterpretedOption_.set(index, builderForValue.build());
/*  7266 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/*  7269 */         if (value == null) {
/*  7270 */           throw new NullPointerException();
/*       */         }
/*  7272 */         ensureUninterpretedOptionIsMutable();
/*  7273 */         this.uninterpretedOption_.add(value);
/*  7274 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  7278 */         ensureUninterpretedOptionIsMutable();
/*  7279 */         this.uninterpretedOption_.add(builderForValue.build());
/*  7280 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/*  7284 */         ensureUninterpretedOptionIsMutable();
/*  7285 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/*  7286 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/*  7289 */         this.uninterpretedOption_ = Collections.emptyList();
/*  7290 */         this.isUninterpretedOptionMutable = false;
/*  7291 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class FileOptions extends GeneratedMessage.ExtendableMessage<FileOptions>
/*       */   {
/*  6833 */     private static final FileOptions defaultInstance = new FileOptions(true);
/*       */     public static final int CC_API_VERSION_FIELD_NUMBER = 2;
/*       */     private boolean hasCcApiVersion;
/*       */     private int ccApiVersion_;
/*       */     public static final int CC_API_COMPATIBILITY_FIELD_NUMBER = 15;
/*       */     private boolean hasCcApiCompatibility;
/*       */     private CompatibilityLevel ccApiCompatibility_;
/*       */     public static final int JAVA_PACKAGE_FIELD_NUMBER = 1;
/*       */     private boolean hasJavaPackage;
/*       */     private String javaPackage_;
/*       */     public static final int PY_API_VERSION_FIELD_NUMBER = 4;
/*       */     private boolean hasPyApiVersion;
/*       */     private int pyApiVersion_;
/*       */     public static final int JAVA_API_VERSION_FIELD_NUMBER = 5;
/*       */     private boolean hasJavaApiVersion;
/*       */     private int javaApiVersion_;
/*       */     public static final int JAVA_USE_JAVAPROTO2_FIELD_NUMBER = 6;
/*       */     private boolean hasJavaUseJavaproto2;
/*       */     private boolean javaUseJavaproto2_;
/*       */     public static final int JAVA_JAVA5_ENUMS_FIELD_NUMBER = 7;
/*       */     private boolean hasJavaJava5Enums;
/*       */     private boolean javaJava5Enums_;
/*       */     public static final int JAVA_GENERATE_RPC_BASEIMPL_FIELD_NUMBER = 13;
/*       */     private boolean hasJavaGenerateRpcBaseimpl;
/*       */     private boolean javaGenerateRpcBaseimpl_;
/*       */     public static final int JAVA_ALT_API_PACKAGE_FIELD_NUMBER = 19;
/*       */     private boolean hasJavaAltApiPackage;
/*       */     private String javaAltApiPackage_;
/*       */     public static final int JAVA_OUTER_CLASSNAME_FIELD_NUMBER = 8;
/*       */     private boolean hasJavaOuterClassname;
/*       */     private String javaOuterClassname_;
/*       */     public static final int JAVA_MULTIPLE_FILES_FIELD_NUMBER = 10;
/*       */     private boolean hasJavaMultipleFiles;
/*       */     private boolean javaMultipleFiles_;
/*       */     public static final int OPTIMIZE_FOR_FIELD_NUMBER = 9;
/*       */     private boolean hasOptimizeFor;
/*       */     private OptimizeMode optimizeFor_;
/*       */     public static final int GO_PACKAGE_FIELD_NUMBER = 11;
/*       */     private boolean hasGoPackage;
/*       */     private String goPackage_;
/*       */     public static final int JAVASCRIPT_PACKAGE_FIELD_NUMBER = 12;
/*       */     private boolean hasJavascriptPackage;
/*       */     private String javascriptPackage_;
/*       */     public static final int SZL_API_VERSION_FIELD_NUMBER = 14;
/*       */     private boolean hasSzlApiVersion;
/*       */     private int szlApiVersion_;
/*       */     public static final int CC_GENERIC_SERVICES_FIELD_NUMBER = 16;
/*       */     private boolean hasCcGenericServices;
/*       */     private boolean ccGenericServices_;
/*       */     public static final int JAVA_GENERIC_SERVICES_FIELD_NUMBER = 17;
/*       */     private boolean hasJavaGenericServices;
/*       */     private boolean javaGenericServices_;
/*       */     public static final int PY_GENERIC_SERVICES_FIELD_NUMBER = 18;
/*       */     private boolean hasPyGenericServices;
/*       */     private boolean pyGenericServices_;
/*       */     public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
/*       */     private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
/*  5877 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private FileOptions(Builder builder)
/*       */     {
/*  5402 */       super();
/*       */     }
/*       */     private FileOptions(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static FileOptions getDefaultInstance() {
/*  5408 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public FileOptions getDefaultInstanceForType() {
/*  5412 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  5417 */       return DescriptorProtos.internal_static_proto2_FileOptions_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  5422 */       return DescriptorProtos.internal_static_proto2_FileOptions_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasCcApiVersion()
/*       */     {
/*  5576 */       return this.hasCcApiVersion;
/*       */     }
/*       */     public int getCcApiVersion() {
/*  5579 */       return this.ccApiVersion_;
/*       */     }
/*       */ 
/*       */     public boolean hasCcApiCompatibility()
/*       */     {
/*  5587 */       return this.hasCcApiCompatibility;
/*       */     }
/*       */     public CompatibilityLevel getCcApiCompatibility() {
/*  5590 */       return this.ccApiCompatibility_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaPackage()
/*       */     {
/*  5598 */       return this.hasJavaPackage;
/*       */     }
/*       */     public String getJavaPackage() {
/*  5601 */       return this.javaPackage_;
/*       */     }
/*       */ 
/*       */     public boolean hasPyApiVersion()
/*       */     {
/*  5609 */       return this.hasPyApiVersion;
/*       */     }
/*       */     public int getPyApiVersion() {
/*  5612 */       return this.pyApiVersion_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaApiVersion()
/*       */     {
/*  5620 */       return this.hasJavaApiVersion;
/*       */     }
/*       */     public int getJavaApiVersion() {
/*  5623 */       return this.javaApiVersion_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaUseJavaproto2()
/*       */     {
/*  5631 */       return this.hasJavaUseJavaproto2;
/*       */     }
/*       */     public boolean getJavaUseJavaproto2() {
/*  5634 */       return this.javaUseJavaproto2_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaJava5Enums()
/*       */     {
/*  5642 */       return this.hasJavaJava5Enums;
/*       */     }
/*       */     public boolean getJavaJava5Enums() {
/*  5645 */       return this.javaJava5Enums_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaGenerateRpcBaseimpl()
/*       */     {
/*  5653 */       return this.hasJavaGenerateRpcBaseimpl;
/*       */     }
/*       */     public boolean getJavaGenerateRpcBaseimpl() {
/*  5656 */       return this.javaGenerateRpcBaseimpl_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaAltApiPackage()
/*       */     {
/*  5664 */       return this.hasJavaAltApiPackage;
/*       */     }
/*       */     public String getJavaAltApiPackage() {
/*  5667 */       return this.javaAltApiPackage_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaOuterClassname()
/*       */     {
/*  5675 */       return this.hasJavaOuterClassname;
/*       */     }
/*       */     public String getJavaOuterClassname() {
/*  5678 */       return this.javaOuterClassname_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaMultipleFiles()
/*       */     {
/*  5686 */       return this.hasJavaMultipleFiles;
/*       */     }
/*       */     public boolean getJavaMultipleFiles() {
/*  5689 */       return this.javaMultipleFiles_;
/*       */     }
/*       */ 
/*       */     public boolean hasOptimizeFor()
/*       */     {
/*  5697 */       return this.hasOptimizeFor;
/*       */     }
/*       */     public OptimizeMode getOptimizeFor() {
/*  5700 */       return this.optimizeFor_;
/*       */     }
/*       */ 
/*       */     public boolean hasGoPackage()
/*       */     {
/*  5708 */       return this.hasGoPackage;
/*       */     }
/*       */     public String getGoPackage() {
/*  5711 */       return this.goPackage_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavascriptPackage()
/*       */     {
/*  5719 */       return this.hasJavascriptPackage;
/*       */     }
/*       */     public String getJavascriptPackage() {
/*  5722 */       return this.javascriptPackage_;
/*       */     }
/*       */ 
/*       */     public boolean hasSzlApiVersion()
/*       */     {
/*  5730 */       return this.hasSzlApiVersion;
/*       */     }
/*       */     public int getSzlApiVersion() {
/*  5733 */       return this.szlApiVersion_;
/*       */     }
/*       */ 
/*       */     public boolean hasCcGenericServices()
/*       */     {
/*  5741 */       return this.hasCcGenericServices;
/*       */     }
/*       */     public boolean getCcGenericServices() {
/*  5744 */       return this.ccGenericServices_;
/*       */     }
/*       */ 
/*       */     public boolean hasJavaGenericServices()
/*       */     {
/*  5752 */       return this.hasJavaGenericServices;
/*       */     }
/*       */     public boolean getJavaGenericServices() {
/*  5755 */       return this.javaGenericServices_;
/*       */     }
/*       */ 
/*       */     public boolean hasPyGenericServices()
/*       */     {
/*  5763 */       return this.hasPyGenericServices;
/*       */     }
/*       */     public boolean getPyGenericServices() {
/*  5766 */       return this.pyGenericServices_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
/*       */     {
/*  5773 */       return this.uninterpretedOption_;
/*       */     }
/*       */     public int getUninterpretedOptionCount() {
/*  5776 */       return this.uninterpretedOption_.size();
/*       */     }
/*       */     public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  5779 */       return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  5783 */       this.ccApiVersion_ = 2;
/*  5784 */       this.ccApiCompatibility_ = CompatibilityLevel.NO_COMPATIBILITY;
/*  5785 */       this.javaPackage_ = "";
/*  5786 */       this.pyApiVersion_ = 2;
/*  5787 */       this.javaApiVersion_ = 2;
/*  5788 */       this.javaUseJavaproto2_ = true;
/*  5789 */       this.javaJava5Enums_ = true;
/*  5790 */       this.javaGenerateRpcBaseimpl_ = false;
/*  5791 */       this.javaAltApiPackage_ = "";
/*  5792 */       this.javaOuterClassname_ = "";
/*  5793 */       this.javaMultipleFiles_ = false;
/*  5794 */       this.optimizeFor_ = OptimizeMode.SPEED;
/*  5795 */       this.goPackage_ = "";
/*  5796 */       this.javascriptPackage_ = "";
/*  5797 */       this.szlApiVersion_ = 1;
/*  5798 */       this.ccGenericServices_ = true;
/*  5799 */       this.javaGenericServices_ = true;
/*  5800 */       this.pyGenericServices_ = true;
/*  5801 */       this.uninterpretedOption_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  5804 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  5805 */         if (!element.isInitialized()) return false;
/*       */       }
/*  5807 */       return extensionsAreInitialized();
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  5813 */       getSerializedSize();
/*       */ 
/*  5815 */       GeneratedMessage.ExtendableMessage.ExtensionWriter extensionWriter = newExtensionWriter();
/*  5816 */       if (hasJavaPackage()) {
/*  5817 */         output.writeString(1, getJavaPackage());
/*       */       }
/*  5819 */       if (hasCcApiVersion()) {
/*  5820 */         output.writeInt32(2, getCcApiVersion());
/*       */       }
/*  5822 */       if (hasPyApiVersion()) {
/*  5823 */         output.writeInt32(4, getPyApiVersion());
/*       */       }
/*  5825 */       if (hasJavaApiVersion()) {
/*  5826 */         output.writeInt32(5, getJavaApiVersion());
/*       */       }
/*  5828 */       if (hasJavaUseJavaproto2()) {
/*  5829 */         output.writeBool(6, getJavaUseJavaproto2());
/*       */       }
/*  5831 */       if (hasJavaJava5Enums()) {
/*  5832 */         output.writeBool(7, getJavaJava5Enums());
/*       */       }
/*  5834 */       if (hasJavaOuterClassname()) {
/*  5835 */         output.writeString(8, getJavaOuterClassname());
/*       */       }
/*  5837 */       if (hasOptimizeFor()) {
/*  5838 */         output.writeEnum(9, getOptimizeFor().getNumber());
/*       */       }
/*  5840 */       if (hasJavaMultipleFiles()) {
/*  5841 */         output.writeBool(10, getJavaMultipleFiles());
/*       */       }
/*  5843 */       if (hasGoPackage()) {
/*  5844 */         output.writeString(11, getGoPackage());
/*       */       }
/*  5846 */       if (hasJavascriptPackage()) {
/*  5847 */         output.writeString(12, getJavascriptPackage());
/*       */       }
/*  5849 */       if (hasJavaGenerateRpcBaseimpl()) {
/*  5850 */         output.writeBool(13, getJavaGenerateRpcBaseimpl());
/*       */       }
/*  5852 */       if (hasSzlApiVersion()) {
/*  5853 */         output.writeInt32(14, getSzlApiVersion());
/*       */       }
/*  5855 */       if (hasCcApiCompatibility()) {
/*  5856 */         output.writeEnum(15, getCcApiCompatibility().getNumber());
/*       */       }
/*  5858 */       if (hasCcGenericServices()) {
/*  5859 */         output.writeBool(16, getCcGenericServices());
/*       */       }
/*  5861 */       if (hasJavaGenericServices()) {
/*  5862 */         output.writeBool(17, getJavaGenericServices());
/*       */       }
/*  5864 */       if (hasPyGenericServices()) {
/*  5865 */         output.writeBool(18, getPyGenericServices());
/*       */       }
/*  5867 */       if (hasJavaAltApiPackage()) {
/*  5868 */         output.writeString(19, getJavaAltApiPackage());
/*       */       }
/*  5870 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  5871 */         output.writeMessage(999, element);
/*       */       }
/*  5873 */       extensionWriter.writeUntil(536870912, output);
/*  5874 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  5879 */       int size = this.memoizedSerializedSize;
/*  5880 */       if (size != -1) return size;
/*       */ 
/*  5882 */       size = 0;
/*  5883 */       if (hasJavaPackage()) {
/*  5884 */         size += CodedOutputStream.computeStringSize(1, getJavaPackage());
/*       */       }
/*       */ 
/*  5887 */       if (hasCcApiVersion()) {
/*  5888 */         size += CodedOutputStream.computeInt32Size(2, getCcApiVersion());
/*       */       }
/*       */ 
/*  5891 */       if (hasPyApiVersion()) {
/*  5892 */         size += CodedOutputStream.computeInt32Size(4, getPyApiVersion());
/*       */       }
/*       */ 
/*  5895 */       if (hasJavaApiVersion()) {
/*  5896 */         size += CodedOutputStream.computeInt32Size(5, getJavaApiVersion());
/*       */       }
/*       */ 
/*  5899 */       if (hasJavaUseJavaproto2()) {
/*  5900 */         size += CodedOutputStream.computeBoolSize(6, getJavaUseJavaproto2());
/*       */       }
/*       */ 
/*  5903 */       if (hasJavaJava5Enums()) {
/*  5904 */         size += CodedOutputStream.computeBoolSize(7, getJavaJava5Enums());
/*       */       }
/*       */ 
/*  5907 */       if (hasJavaOuterClassname()) {
/*  5908 */         size += CodedOutputStream.computeStringSize(8, getJavaOuterClassname());
/*       */       }
/*       */ 
/*  5911 */       if (hasOptimizeFor()) {
/*  5912 */         size += CodedOutputStream.computeEnumSize(9, getOptimizeFor().getNumber());
/*       */       }
/*       */ 
/*  5915 */       if (hasJavaMultipleFiles()) {
/*  5916 */         size += CodedOutputStream.computeBoolSize(10, getJavaMultipleFiles());
/*       */       }
/*       */ 
/*  5919 */       if (hasGoPackage()) {
/*  5920 */         size += CodedOutputStream.computeStringSize(11, getGoPackage());
/*       */       }
/*       */ 
/*  5923 */       if (hasJavascriptPackage()) {
/*  5924 */         size += CodedOutputStream.computeStringSize(12, getJavascriptPackage());
/*       */       }
/*       */ 
/*  5927 */       if (hasJavaGenerateRpcBaseimpl()) {
/*  5928 */         size += CodedOutputStream.computeBoolSize(13, getJavaGenerateRpcBaseimpl());
/*       */       }
/*       */ 
/*  5931 */       if (hasSzlApiVersion()) {
/*  5932 */         size += CodedOutputStream.computeInt32Size(14, getSzlApiVersion());
/*       */       }
/*       */ 
/*  5935 */       if (hasCcApiCompatibility()) {
/*  5936 */         size += CodedOutputStream.computeEnumSize(15, getCcApiCompatibility().getNumber());
/*       */       }
/*       */ 
/*  5939 */       if (hasCcGenericServices()) {
/*  5940 */         size += CodedOutputStream.computeBoolSize(16, getCcGenericServices());
/*       */       }
/*       */ 
/*  5943 */       if (hasJavaGenericServices()) {
/*  5944 */         size += CodedOutputStream.computeBoolSize(17, getJavaGenericServices());
/*       */       }
/*       */ 
/*  5947 */       if (hasPyGenericServices()) {
/*  5948 */         size += CodedOutputStream.computeBoolSize(18, getPyGenericServices());
/*       */       }
/*       */ 
/*  5951 */       if (hasJavaAltApiPackage()) {
/*  5952 */         size += CodedOutputStream.computeStringSize(19, getJavaAltApiPackage());
/*       */       }
/*       */ 
/*  5955 */       for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  5956 */         size += CodedOutputStream.computeMessageSize(999, element);
/*       */       }
/*       */ 
/*  5959 */       size += extensionsSerializedSize();
/*  5960 */       size += getUnknownFields().getSerializedSize();
/*  5961 */       this.memoizedSerializedSize = size;
/*  5962 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  5967 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  5973 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  5979 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  5984 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  5990 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(InputStream input) throws IOException
/*       */     {
/*  5995 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  6001 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  6006 */       Builder builder = newBuilder();
/*  6007 */       if (builder.mergeDelimitedFrom(input)) {
/*  6008 */         return builder.buildParsed();
/*       */       }
/*  6010 */       return null;
/*       */     }
/*       */ 
/*       */     public static FileOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  6017 */       Builder builder = newBuilder();
/*  6018 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  6019 */         return builder.buildParsed();
/*       */       }
/*  6021 */       return null;
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  6027 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  6033 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  6037 */       return Builder.access$11300(); } 
/*  6038 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(FileOptions prototype) {
/*  6040 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  6042 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  6834 */       DescriptorProtos.internalForceInit();
/*  6835 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.FileOptions, Builder>
/*       */     {
/*       */       private boolean hasCcApiVersion;
/*  6390 */       private int ccApiVersion_ = 2;
/*       */       private boolean hasCcApiCompatibility;
/*  6410 */       private DescriptorProtos.FileOptions.CompatibilityLevel ccApiCompatibility_ = DescriptorProtos.FileOptions.CompatibilityLevel.NO_COMPATIBILITY;
/*       */       private boolean hasJavaPackage;
/*  6433 */       private String javaPackage_ = "";
/*       */       private boolean hasPyApiVersion;
/*  6456 */       private int pyApiVersion_ = 2;
/*       */       private boolean hasJavaApiVersion;
/*  6476 */       private int javaApiVersion_ = 2;
/*       */       private boolean hasJavaUseJavaproto2;
/*  6496 */       private boolean javaUseJavaproto2_ = true;
/*       */       private boolean hasJavaJava5Enums;
/*  6516 */       private boolean javaJava5Enums_ = true;
/*       */       private boolean hasJavaGenerateRpcBaseimpl;
/*       */       private boolean javaGenerateRpcBaseimpl_;
/*       */       private boolean hasJavaAltApiPackage;
/*  6556 */       private String javaAltApiPackage_ = "";
/*       */       private boolean hasJavaOuterClassname;
/*  6579 */       private String javaOuterClassname_ = "";
/*       */       private boolean hasJavaMultipleFiles;
/*       */       private boolean javaMultipleFiles_;
/*       */       private boolean hasOptimizeFor;
/*  6622 */       private DescriptorProtos.FileOptions.OptimizeMode optimizeFor_ = DescriptorProtos.FileOptions.OptimizeMode.SPEED;
/*       */       private boolean hasGoPackage;
/*  6645 */       private String goPackage_ = "";
/*       */       private boolean hasJavascriptPackage;
/*  6668 */       private String javascriptPackage_ = "";
/*       */       private boolean hasSzlApiVersion;
/*  6691 */       private int szlApiVersion_ = 1;
/*       */       private boolean hasCcGenericServices;
/*  6711 */       private boolean ccGenericServices_ = true;
/*       */       private boolean hasJavaGenericServices;
/*  6731 */       private boolean javaGenericServices_ = true;
/*       */       private boolean hasPyGenericServices;
/*  6751 */       private boolean pyGenericServices_ = true;
/*       */ 
/*  6770 */       private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
/*       */       private boolean isUninterpretedOptionMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  6049 */         return DescriptorProtos.internal_static_proto2_FileOptions_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  6054 */         return DescriptorProtos.internal_static_proto2_FileOptions_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  6062 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  6066 */         super.clear();
/*  6067 */         this.ccApiVersion_ = 2;
/*  6068 */         this.hasCcApiVersion = false;
/*  6069 */         this.ccApiCompatibility_ = DescriptorProtos.FileOptions.CompatibilityLevel.NO_COMPATIBILITY;
/*  6070 */         this.hasCcApiCompatibility = false;
/*  6071 */         this.javaPackage_ = "";
/*  6072 */         this.hasJavaPackage = false;
/*  6073 */         this.pyApiVersion_ = 2;
/*  6074 */         this.hasPyApiVersion = false;
/*  6075 */         this.javaApiVersion_ = 2;
/*  6076 */         this.hasJavaApiVersion = false;
/*  6077 */         this.javaUseJavaproto2_ = true;
/*  6078 */         this.hasJavaUseJavaproto2 = false;
/*  6079 */         this.javaJava5Enums_ = true;
/*  6080 */         this.hasJavaJava5Enums = false;
/*  6081 */         this.javaGenerateRpcBaseimpl_ = false;
/*  6082 */         this.hasJavaGenerateRpcBaseimpl = false;
/*  6083 */         this.javaAltApiPackage_ = "";
/*  6084 */         this.hasJavaAltApiPackage = false;
/*  6085 */         this.javaOuterClassname_ = "";
/*  6086 */         this.hasJavaOuterClassname = false;
/*  6087 */         this.javaMultipleFiles_ = false;
/*  6088 */         this.hasJavaMultipleFiles = false;
/*  6089 */         this.optimizeFor_ = DescriptorProtos.FileOptions.OptimizeMode.SPEED;
/*  6090 */         this.hasOptimizeFor = false;
/*  6091 */         this.goPackage_ = "";
/*  6092 */         this.hasGoPackage = false;
/*  6093 */         this.javascriptPackage_ = "";
/*  6094 */         this.hasJavascriptPackage = false;
/*  6095 */         this.szlApiVersion_ = 1;
/*  6096 */         this.hasSzlApiVersion = false;
/*  6097 */         this.ccGenericServices_ = true;
/*  6098 */         this.hasCcGenericServices = false;
/*  6099 */         this.javaGenericServices_ = true;
/*  6100 */         this.hasJavaGenericServices = false;
/*  6101 */         this.pyGenericServices_ = true;
/*  6102 */         this.hasPyGenericServices = false;
/*  6103 */         this.uninterpretedOption_ = Collections.emptyList();
/*  6104 */         this.isUninterpretedOptionMutable = false;
/*  6105 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  6109 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  6114 */         return DescriptorProtos.FileOptions.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileOptions getDefaultInstanceForType() {
/*  6118 */         return DescriptorProtos.FileOptions.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileOptions build() {
/*  6122 */         DescriptorProtos.FileOptions result = buildPartial();
/*  6123 */         if (!result.isInitialized()) {
/*  6124 */           throw newUninitializedMessageException(result);
/*       */         }
/*  6126 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.FileOptions buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  6131 */         DescriptorProtos.FileOptions result = buildPartial();
/*  6132 */         if (!result.isInitialized()) {
/*  6133 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  6136 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileOptions buildPartial() {
/*  6140 */         DescriptorProtos.FileOptions result = new DescriptorProtos.FileOptions(this, null);
/*  6141 */         DescriptorProtos.FileOptions.access$11502(result, this.hasCcApiVersion);
/*  6142 */         DescriptorProtos.FileOptions.access$11602(result, this.ccApiVersion_);
/*  6143 */         DescriptorProtos.FileOptions.access$11702(result, this.hasCcApiCompatibility);
/*  6144 */         DescriptorProtos.FileOptions.access$11802(result, this.ccApiCompatibility_);
/*  6145 */         DescriptorProtos.FileOptions.access$11902(result, this.hasJavaPackage);
/*  6146 */         DescriptorProtos.FileOptions.access$12002(result, this.javaPackage_);
/*  6147 */         DescriptorProtos.FileOptions.access$12102(result, this.hasPyApiVersion);
/*  6148 */         DescriptorProtos.FileOptions.access$12202(result, this.pyApiVersion_);
/*  6149 */         DescriptorProtos.FileOptions.access$12302(result, this.hasJavaApiVersion);
/*  6150 */         DescriptorProtos.FileOptions.access$12402(result, this.javaApiVersion_);
/*  6151 */         DescriptorProtos.FileOptions.access$12502(result, this.hasJavaUseJavaproto2);
/*  6152 */         DescriptorProtos.FileOptions.access$12602(result, this.javaUseJavaproto2_);
/*  6153 */         DescriptorProtos.FileOptions.access$12702(result, this.hasJavaJava5Enums);
/*  6154 */         DescriptorProtos.FileOptions.access$12802(result, this.javaJava5Enums_);
/*  6155 */         DescriptorProtos.FileOptions.access$12902(result, this.hasJavaGenerateRpcBaseimpl);
/*  6156 */         DescriptorProtos.FileOptions.access$13002(result, this.javaGenerateRpcBaseimpl_);
/*  6157 */         DescriptorProtos.FileOptions.access$13102(result, this.hasJavaAltApiPackage);
/*  6158 */         DescriptorProtos.FileOptions.access$13202(result, this.javaAltApiPackage_);
/*  6159 */         DescriptorProtos.FileOptions.access$13302(result, this.hasJavaOuterClassname);
/*  6160 */         DescriptorProtos.FileOptions.access$13402(result, this.javaOuterClassname_);
/*  6161 */         DescriptorProtos.FileOptions.access$13502(result, this.hasJavaMultipleFiles);
/*  6162 */         DescriptorProtos.FileOptions.access$13602(result, this.javaMultipleFiles_);
/*  6163 */         DescriptorProtos.FileOptions.access$13702(result, this.hasOptimizeFor);
/*  6164 */         DescriptorProtos.FileOptions.access$13802(result, this.optimizeFor_);
/*  6165 */         DescriptorProtos.FileOptions.access$13902(result, this.hasGoPackage);
/*  6166 */         DescriptorProtos.FileOptions.access$14002(result, this.goPackage_);
/*  6167 */         DescriptorProtos.FileOptions.access$14102(result, this.hasJavascriptPackage);
/*  6168 */         DescriptorProtos.FileOptions.access$14202(result, this.javascriptPackage_);
/*  6169 */         DescriptorProtos.FileOptions.access$14302(result, this.hasSzlApiVersion);
/*  6170 */         DescriptorProtos.FileOptions.access$14402(result, this.szlApiVersion_);
/*  6171 */         DescriptorProtos.FileOptions.access$14502(result, this.hasCcGenericServices);
/*  6172 */         DescriptorProtos.FileOptions.access$14602(result, this.ccGenericServices_);
/*  6173 */         DescriptorProtos.FileOptions.access$14702(result, this.hasJavaGenericServices);
/*  6174 */         DescriptorProtos.FileOptions.access$14802(result, this.javaGenericServices_);
/*  6175 */         DescriptorProtos.FileOptions.access$14902(result, this.hasPyGenericServices);
/*  6176 */         DescriptorProtos.FileOptions.access$15002(result, this.pyGenericServices_);
/*  6177 */         if (this.isUninterpretedOptionMutable) {
/*  6178 */           this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
/*  6179 */           this.isUninterpretedOptionMutable = false;
/*       */         }
/*  6181 */         DescriptorProtos.FileOptions.access$15102(result, this.uninterpretedOption_);
/*  6182 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  6186 */         if ((other instanceof DescriptorProtos.FileOptions)) {
/*  6187 */           return mergeFrom((DescriptorProtos.FileOptions)other);
/*       */         }
/*  6189 */         super.mergeFrom(other);
/*  6190 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.FileOptions other)
/*       */       {
/*  6195 */         if (other == DescriptorProtos.FileOptions.getDefaultInstance()) return this;
/*  6196 */         if (other.hasCcApiVersion()) {
/*  6197 */           setCcApiVersion(other.getCcApiVersion());
/*       */         }
/*  6199 */         if (other.hasCcApiCompatibility()) {
/*  6200 */           setCcApiCompatibility(other.getCcApiCompatibility());
/*       */         }
/*  6202 */         if (other.hasJavaPackage()) {
/*  6203 */           setJavaPackage(other.getJavaPackage());
/*       */         }
/*  6205 */         if (other.hasPyApiVersion()) {
/*  6206 */           setPyApiVersion(other.getPyApiVersion());
/*       */         }
/*  6208 */         if (other.hasJavaApiVersion()) {
/*  6209 */           setJavaApiVersion(other.getJavaApiVersion());
/*       */         }
/*  6211 */         if (other.hasJavaUseJavaproto2()) {
/*  6212 */           setJavaUseJavaproto2(other.getJavaUseJavaproto2());
/*       */         }
/*  6214 */         if (other.hasJavaJava5Enums()) {
/*  6215 */           setJavaJava5Enums(other.getJavaJava5Enums());
/*       */         }
/*  6217 */         if (other.hasJavaGenerateRpcBaseimpl()) {
/*  6218 */           setJavaGenerateRpcBaseimpl(other.getJavaGenerateRpcBaseimpl());
/*       */         }
/*  6220 */         if (other.hasJavaAltApiPackage()) {
/*  6221 */           setJavaAltApiPackage(other.getJavaAltApiPackage());
/*       */         }
/*  6223 */         if (other.hasJavaOuterClassname()) {
/*  6224 */           setJavaOuterClassname(other.getJavaOuterClassname());
/*       */         }
/*  6226 */         if (other.hasJavaMultipleFiles()) {
/*  6227 */           setJavaMultipleFiles(other.getJavaMultipleFiles());
/*       */         }
/*  6229 */         if (other.hasOptimizeFor()) {
/*  6230 */           setOptimizeFor(other.getOptimizeFor());
/*       */         }
/*  6232 */         if (other.hasGoPackage()) {
/*  6233 */           setGoPackage(other.getGoPackage());
/*       */         }
/*  6235 */         if (other.hasJavascriptPackage()) {
/*  6236 */           setJavascriptPackage(other.getJavascriptPackage());
/*       */         }
/*  6238 */         if (other.hasSzlApiVersion()) {
/*  6239 */           setSzlApiVersion(other.getSzlApiVersion());
/*       */         }
/*  6241 */         if (other.hasCcGenericServices()) {
/*  6242 */           setCcGenericServices(other.getCcGenericServices());
/*       */         }
/*  6244 */         if (other.hasJavaGenericServices()) {
/*  6245 */           setJavaGenericServices(other.getJavaGenericServices());
/*       */         }
/*  6247 */         if (other.hasPyGenericServices()) {
/*  6248 */           setPyGenericServices(other.getPyGenericServices());
/*       */         }
/*  6250 */         if (!other.uninterpretedOption_.isEmpty()) {
/*  6251 */           if (this.uninterpretedOption_.isEmpty()) {
/*  6252 */             this.uninterpretedOption_ = other.uninterpretedOption_;
/*  6253 */             this.isUninterpretedOptionMutable = false;
/*       */           } else {
/*  6255 */             ensureUninterpretedOptionIsMutable();
/*  6256 */             this.uninterpretedOption_.addAll(other.uninterpretedOption_);
/*       */           }
/*       */         }
/*  6259 */         mergeExtensionFields(other);
/*  6260 */         mergeUnknownFields(other.getUnknownFields());
/*  6261 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  6265 */         for (DescriptorProtos.UninterpretedOption element : getUninterpretedOptionList()) {
/*  6266 */           if (!element.isInitialized()) return false;
/*       */         }
/*  6268 */         return extensionsAreInitialized();
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  6276 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  6280 */           int tag = input.readTag();
/*  6281 */           switch (tag) {
/*       */           case 0:
/*  6283 */             setUnknownFields(unknownFields.build());
/*  6284 */             return this;
/*       */           default:
/*  6286 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  6288 */             setUnknownFields(unknownFields.build());
/*  6289 */             return this;
/*       */           case 10:
/*  6294 */             setJavaPackage(input.readString());
/*  6295 */             break;
/*       */           case 16:
/*  6298 */             setCcApiVersion(input.readInt32());
/*  6299 */             break;
/*       */           case 32:
/*  6302 */             setPyApiVersion(input.readInt32());
/*  6303 */             break;
/*       */           case 40:
/*  6306 */             setJavaApiVersion(input.readInt32());
/*  6307 */             break;
/*       */           case 48:
/*  6310 */             setJavaUseJavaproto2(input.readBool());
/*  6311 */             break;
/*       */           case 56:
/*  6314 */             setJavaJava5Enums(input.readBool());
/*  6315 */             break;
/*       */           case 66:
/*  6318 */             setJavaOuterClassname(input.readString());
/*  6319 */             break;
/*       */           case 72:
/*  6322 */             int rawValue = input.readEnum();
/*  6323 */             DescriptorProtos.FileOptions.OptimizeMode value = DescriptorProtos.FileOptions.OptimizeMode.valueOf(rawValue);
/*  6324 */             if (value == null)
/*  6325 */               unknownFields.mergeVarintField(9, rawValue);
/*       */             else {
/*  6327 */               setOptimizeFor(value);
/*       */             }
/*  6329 */             break;
/*       */           case 80:
/*  6332 */             setJavaMultipleFiles(input.readBool());
/*  6333 */             break;
/*       */           case 90:
/*  6336 */             setGoPackage(input.readString());
/*  6337 */             break;
/*       */           case 98:
/*  6340 */             setJavascriptPackage(input.readString());
/*  6341 */             break;
/*       */           case 104:
/*  6344 */             setJavaGenerateRpcBaseimpl(input.readBool());
/*  6345 */             break;
/*       */           case 112:
/*  6348 */             setSzlApiVersion(input.readInt32());
/*  6349 */             break;
/*       */           case 120:
/*  6352 */             int rawValue = input.readEnum();
/*  6353 */             DescriptorProtos.FileOptions.CompatibilityLevel value = DescriptorProtos.FileOptions.CompatibilityLevel.valueOf(rawValue);
/*  6354 */             if (value == null)
/*  6355 */               unknownFields.mergeVarintField(15, rawValue);
/*       */             else {
/*  6357 */               setCcApiCompatibility(value);
/*       */             }
/*  6359 */             break;
/*       */           case 128:
/*  6362 */             setCcGenericServices(input.readBool());
/*  6363 */             break;
/*       */           case 136:
/*  6366 */             setJavaGenericServices(input.readBool());
/*  6367 */             break;
/*       */           case 144:
/*  6370 */             setPyGenericServices(input.readBool());
/*  6371 */             break;
/*       */           case 154:
/*  6374 */             setJavaAltApiPackage(input.readString());
/*  6375 */             break;
/*       */           case 7994:
/*  6378 */             DescriptorProtos.UninterpretedOption.Builder subBuilder = DescriptorProtos.UninterpretedOption.newBuilder();
/*  6379 */             input.readMessage(subBuilder, extensionRegistry);
/*  6380 */             addUninterpretedOption(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasCcApiVersion()
/*       */       {
/*  6392 */         return this.hasCcApiVersion;
/*       */       }
/*       */       public int getCcApiVersion() {
/*  6395 */         return this.ccApiVersion_;
/*       */       }
/*       */       public Builder setCcApiVersion(int value) {
/*  6398 */         this.hasCcApiVersion = true;
/*  6399 */         this.ccApiVersion_ = value;
/*  6400 */         return this;
/*       */       }
/*       */       public Builder clearCcApiVersion() {
/*  6403 */         this.hasCcApiVersion = false;
/*  6404 */         this.ccApiVersion_ = 2;
/*  6405 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasCcApiCompatibility()
/*       */       {
/*  6412 */         return this.hasCcApiCompatibility;
/*       */       }
/*       */       public DescriptorProtos.FileOptions.CompatibilityLevel getCcApiCompatibility() {
/*  6415 */         return this.ccApiCompatibility_;
/*       */       }
/*       */       public Builder setCcApiCompatibility(DescriptorProtos.FileOptions.CompatibilityLevel value) {
/*  6418 */         if (value == null) {
/*  6419 */           throw new NullPointerException();
/*       */         }
/*  6421 */         this.hasCcApiCompatibility = true;
/*  6422 */         this.ccApiCompatibility_ = value;
/*  6423 */         return this;
/*       */       }
/*       */       public Builder clearCcApiCompatibility() {
/*  6426 */         this.hasCcApiCompatibility = false;
/*  6427 */         this.ccApiCompatibility_ = DescriptorProtos.FileOptions.CompatibilityLevel.NO_COMPATIBILITY;
/*  6428 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaPackage()
/*       */       {
/*  6435 */         return this.hasJavaPackage;
/*       */       }
/*       */       public String getJavaPackage() {
/*  6438 */         return this.javaPackage_;
/*       */       }
/*       */       public Builder setJavaPackage(String value) {
/*  6441 */         if (value == null) {
/*  6442 */           throw new NullPointerException();
/*       */         }
/*  6444 */         this.hasJavaPackage = true;
/*  6445 */         this.javaPackage_ = value;
/*  6446 */         return this;
/*       */       }
/*       */       public Builder clearJavaPackage() {
/*  6449 */         this.hasJavaPackage = false;
/*  6450 */         this.javaPackage_ = DescriptorProtos.FileOptions.getDefaultInstance().getJavaPackage();
/*  6451 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasPyApiVersion()
/*       */       {
/*  6458 */         return this.hasPyApiVersion;
/*       */       }
/*       */       public int getPyApiVersion() {
/*  6461 */         return this.pyApiVersion_;
/*       */       }
/*       */       public Builder setPyApiVersion(int value) {
/*  6464 */         this.hasPyApiVersion = true;
/*  6465 */         this.pyApiVersion_ = value;
/*  6466 */         return this;
/*       */       }
/*       */       public Builder clearPyApiVersion() {
/*  6469 */         this.hasPyApiVersion = false;
/*  6470 */         this.pyApiVersion_ = 2;
/*  6471 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaApiVersion()
/*       */       {
/*  6478 */         return this.hasJavaApiVersion;
/*       */       }
/*       */       public int getJavaApiVersion() {
/*  6481 */         return this.javaApiVersion_;
/*       */       }
/*       */       public Builder setJavaApiVersion(int value) {
/*  6484 */         this.hasJavaApiVersion = true;
/*  6485 */         this.javaApiVersion_ = value;
/*  6486 */         return this;
/*       */       }
/*       */       public Builder clearJavaApiVersion() {
/*  6489 */         this.hasJavaApiVersion = false;
/*  6490 */         this.javaApiVersion_ = 2;
/*  6491 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaUseJavaproto2()
/*       */       {
/*  6498 */         return this.hasJavaUseJavaproto2;
/*       */       }
/*       */       public boolean getJavaUseJavaproto2() {
/*  6501 */         return this.javaUseJavaproto2_;
/*       */       }
/*       */       public Builder setJavaUseJavaproto2(boolean value) {
/*  6504 */         this.hasJavaUseJavaproto2 = true;
/*  6505 */         this.javaUseJavaproto2_ = value;
/*  6506 */         return this;
/*       */       }
/*       */       public Builder clearJavaUseJavaproto2() {
/*  6509 */         this.hasJavaUseJavaproto2 = false;
/*  6510 */         this.javaUseJavaproto2_ = true;
/*  6511 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaJava5Enums()
/*       */       {
/*  6518 */         return this.hasJavaJava5Enums;
/*       */       }
/*       */       public boolean getJavaJava5Enums() {
/*  6521 */         return this.javaJava5Enums_;
/*       */       }
/*       */       public Builder setJavaJava5Enums(boolean value) {
/*  6524 */         this.hasJavaJava5Enums = true;
/*  6525 */         this.javaJava5Enums_ = value;
/*  6526 */         return this;
/*       */       }
/*       */       public Builder clearJavaJava5Enums() {
/*  6529 */         this.hasJavaJava5Enums = false;
/*  6530 */         this.javaJava5Enums_ = true;
/*  6531 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaGenerateRpcBaseimpl()
/*       */       {
/*  6538 */         return this.hasJavaGenerateRpcBaseimpl;
/*       */       }
/*       */       public boolean getJavaGenerateRpcBaseimpl() {
/*  6541 */         return this.javaGenerateRpcBaseimpl_;
/*       */       }
/*       */       public Builder setJavaGenerateRpcBaseimpl(boolean value) {
/*  6544 */         this.hasJavaGenerateRpcBaseimpl = true;
/*  6545 */         this.javaGenerateRpcBaseimpl_ = value;
/*  6546 */         return this;
/*       */       }
/*       */       public Builder clearJavaGenerateRpcBaseimpl() {
/*  6549 */         this.hasJavaGenerateRpcBaseimpl = false;
/*  6550 */         this.javaGenerateRpcBaseimpl_ = false;
/*  6551 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaAltApiPackage()
/*       */       {
/*  6558 */         return this.hasJavaAltApiPackage;
/*       */       }
/*       */       public String getJavaAltApiPackage() {
/*  6561 */         return this.javaAltApiPackage_;
/*       */       }
/*       */       public Builder setJavaAltApiPackage(String value) {
/*  6564 */         if (value == null) {
/*  6565 */           throw new NullPointerException();
/*       */         }
/*  6567 */         this.hasJavaAltApiPackage = true;
/*  6568 */         this.javaAltApiPackage_ = value;
/*  6569 */         return this;
/*       */       }
/*       */       public Builder clearJavaAltApiPackage() {
/*  6572 */         this.hasJavaAltApiPackage = false;
/*  6573 */         this.javaAltApiPackage_ = DescriptorProtos.FileOptions.getDefaultInstance().getJavaAltApiPackage();
/*  6574 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaOuterClassname()
/*       */       {
/*  6581 */         return this.hasJavaOuterClassname;
/*       */       }
/*       */       public String getJavaOuterClassname() {
/*  6584 */         return this.javaOuterClassname_;
/*       */       }
/*       */       public Builder setJavaOuterClassname(String value) {
/*  6587 */         if (value == null) {
/*  6588 */           throw new NullPointerException();
/*       */         }
/*  6590 */         this.hasJavaOuterClassname = true;
/*  6591 */         this.javaOuterClassname_ = value;
/*  6592 */         return this;
/*       */       }
/*       */       public Builder clearJavaOuterClassname() {
/*  6595 */         this.hasJavaOuterClassname = false;
/*  6596 */         this.javaOuterClassname_ = DescriptorProtos.FileOptions.getDefaultInstance().getJavaOuterClassname();
/*  6597 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaMultipleFiles()
/*       */       {
/*  6604 */         return this.hasJavaMultipleFiles;
/*       */       }
/*       */       public boolean getJavaMultipleFiles() {
/*  6607 */         return this.javaMultipleFiles_;
/*       */       }
/*       */       public Builder setJavaMultipleFiles(boolean value) {
/*  6610 */         this.hasJavaMultipleFiles = true;
/*  6611 */         this.javaMultipleFiles_ = value;
/*  6612 */         return this;
/*       */       }
/*       */       public Builder clearJavaMultipleFiles() {
/*  6615 */         this.hasJavaMultipleFiles = false;
/*  6616 */         this.javaMultipleFiles_ = false;
/*  6617 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptimizeFor()
/*       */       {
/*  6624 */         return this.hasOptimizeFor;
/*       */       }
/*       */       public DescriptorProtos.FileOptions.OptimizeMode getOptimizeFor() {
/*  6627 */         return this.optimizeFor_;
/*       */       }
/*       */       public Builder setOptimizeFor(DescriptorProtos.FileOptions.OptimizeMode value) {
/*  6630 */         if (value == null) {
/*  6631 */           throw new NullPointerException();
/*       */         }
/*  6633 */         this.hasOptimizeFor = true;
/*  6634 */         this.optimizeFor_ = value;
/*  6635 */         return this;
/*       */       }
/*       */       public Builder clearOptimizeFor() {
/*  6638 */         this.hasOptimizeFor = false;
/*  6639 */         this.optimizeFor_ = DescriptorProtos.FileOptions.OptimizeMode.SPEED;
/*  6640 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasGoPackage()
/*       */       {
/*  6647 */         return this.hasGoPackage;
/*       */       }
/*       */       public String getGoPackage() {
/*  6650 */         return this.goPackage_;
/*       */       }
/*       */       public Builder setGoPackage(String value) {
/*  6653 */         if (value == null) {
/*  6654 */           throw new NullPointerException();
/*       */         }
/*  6656 */         this.hasGoPackage = true;
/*  6657 */         this.goPackage_ = value;
/*  6658 */         return this;
/*       */       }
/*       */       public Builder clearGoPackage() {
/*  6661 */         this.hasGoPackage = false;
/*  6662 */         this.goPackage_ = DescriptorProtos.FileOptions.getDefaultInstance().getGoPackage();
/*  6663 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavascriptPackage()
/*       */       {
/*  6670 */         return this.hasJavascriptPackage;
/*       */       }
/*       */       public String getJavascriptPackage() {
/*  6673 */         return this.javascriptPackage_;
/*       */       }
/*       */       public Builder setJavascriptPackage(String value) {
/*  6676 */         if (value == null) {
/*  6677 */           throw new NullPointerException();
/*       */         }
/*  6679 */         this.hasJavascriptPackage = true;
/*  6680 */         this.javascriptPackage_ = value;
/*  6681 */         return this;
/*       */       }
/*       */       public Builder clearJavascriptPackage() {
/*  6684 */         this.hasJavascriptPackage = false;
/*  6685 */         this.javascriptPackage_ = DescriptorProtos.FileOptions.getDefaultInstance().getJavascriptPackage();
/*  6686 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasSzlApiVersion()
/*       */       {
/*  6693 */         return this.hasSzlApiVersion;
/*       */       }
/*       */       public int getSzlApiVersion() {
/*  6696 */         return this.szlApiVersion_;
/*       */       }
/*       */       public Builder setSzlApiVersion(int value) {
/*  6699 */         this.hasSzlApiVersion = true;
/*  6700 */         this.szlApiVersion_ = value;
/*  6701 */         return this;
/*       */       }
/*       */       public Builder clearSzlApiVersion() {
/*  6704 */         this.hasSzlApiVersion = false;
/*  6705 */         this.szlApiVersion_ = 1;
/*  6706 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasCcGenericServices()
/*       */       {
/*  6713 */         return this.hasCcGenericServices;
/*       */       }
/*       */       public boolean getCcGenericServices() {
/*  6716 */         return this.ccGenericServices_;
/*       */       }
/*       */       public Builder setCcGenericServices(boolean value) {
/*  6719 */         this.hasCcGenericServices = true;
/*  6720 */         this.ccGenericServices_ = value;
/*  6721 */         return this;
/*       */       }
/*       */       public Builder clearCcGenericServices() {
/*  6724 */         this.hasCcGenericServices = false;
/*  6725 */         this.ccGenericServices_ = true;
/*  6726 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasJavaGenericServices()
/*       */       {
/*  6733 */         return this.hasJavaGenericServices;
/*       */       }
/*       */       public boolean getJavaGenericServices() {
/*  6736 */         return this.javaGenericServices_;
/*       */       }
/*       */       public Builder setJavaGenericServices(boolean value) {
/*  6739 */         this.hasJavaGenericServices = true;
/*  6740 */         this.javaGenericServices_ = value;
/*  6741 */         return this;
/*       */       }
/*       */       public Builder clearJavaGenericServices() {
/*  6744 */         this.hasJavaGenericServices = false;
/*  6745 */         this.javaGenericServices_ = true;
/*  6746 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasPyGenericServices()
/*       */       {
/*  6753 */         return this.hasPyGenericServices;
/*       */       }
/*       */       public boolean getPyGenericServices() {
/*  6756 */         return this.pyGenericServices_;
/*       */       }
/*       */       public Builder setPyGenericServices(boolean value) {
/*  6759 */         this.hasPyGenericServices = true;
/*  6760 */         this.pyGenericServices_ = value;
/*  6761 */         return this;
/*       */       }
/*       */       public Builder clearPyGenericServices() {
/*  6764 */         this.hasPyGenericServices = false;
/*  6765 */         this.pyGenericServices_ = true;
/*  6766 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureUninterpretedOptionIsMutable()
/*       */       {
/*  6774 */         if (!this.isUninterpretedOptionMutable) {
/*  6775 */           this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
/*  6776 */           this.isUninterpretedOptionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList() {
/*  6780 */         return Collections.unmodifiableList(this.uninterpretedOption_);
/*       */       }
/*       */       public int getUninterpretedOptionCount() {
/*  6783 */         return this.uninterpretedOption_.size();
/*       */       }
/*       */       public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index) {
/*  6786 */         return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value) {
/*  6790 */         if (value == null) {
/*  6791 */           throw new NullPointerException();
/*       */         }
/*  6793 */         ensureUninterpretedOptionIsMutable();
/*  6794 */         this.uninterpretedOption_.set(index, value);
/*  6795 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  6799 */         ensureUninterpretedOptionIsMutable();
/*  6800 */         this.uninterpretedOption_.set(index, builderForValue.build());
/*  6801 */         return this;
/*       */       }
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value) {
/*  6804 */         if (value == null) {
/*  6805 */           throw new NullPointerException();
/*       */         }
/*  6807 */         ensureUninterpretedOptionIsMutable();
/*  6808 */         this.uninterpretedOption_.add(value);
/*  6809 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue) {
/*  6813 */         ensureUninterpretedOptionIsMutable();
/*  6814 */         this.uninterpretedOption_.add(builderForValue.build());
/*  6815 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values) {
/*  6819 */         ensureUninterpretedOptionIsMutable();
/*  6820 */         GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
/*  6821 */         return this;
/*       */       }
/*       */       public Builder clearUninterpretedOption() {
/*  6824 */         this.uninterpretedOption_ = Collections.emptyList();
/*  6825 */         this.isUninterpretedOptionMutable = false;
/*  6826 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum OptimizeMode
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  5500 */       SPEED(0, 1), 
/*  5501 */       CODE_SIZE(1, 2), 
/*  5502 */       LITE_RUNTIME(2, 3);
/*       */ 
/*       */       public static final int SPEED_VALUE = 1;
/*       */       public static final int CODE_SIZE_VALUE = 2;
/*       */       public static final int LITE_RUNTIME_VALUE = 3;
/*       */       private static Internal.EnumLiteMap<OptimizeMode> internalValueMap;
/*       */       private static final OptimizeMode[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  5510 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static OptimizeMode valueOf(int value) {
/*  5513 */         switch (value) { case 1:
/*  5514 */           return SPEED;
/*       */         case 2:
/*  5515 */           return CODE_SIZE;
/*       */         case 3:
/*  5516 */           return LITE_RUNTIME; }
/*  5517 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<OptimizeMode> internalGetValueMap()
/*       */       {
/*  5523 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  5535 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  5539 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  5543 */         return (Descriptors.EnumDescriptor)DescriptorProtos.FileOptions.getDescriptor().getEnumTypes().get(1);
/*       */       }
/*       */ 
/*       */       public static OptimizeMode valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  5551 */         if (desc.getType() != getDescriptor()) {
/*  5552 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  5555 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private OptimizeMode(int index, int value)
/*       */       {
/*  5560 */         this.index = index;
/*  5561 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  5526 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.FileOptions.OptimizeMode findValueByNumber(int number) {
/*  5529 */             return DescriptorProtos.FileOptions.OptimizeMode.valueOf(number);
/*       */           }
/*       */         };
/*  5546 */         VALUES = new OptimizeMode[] { SPEED, CODE_SIZE, LITE_RUNTIME };
/*       */ 
/*  5565 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum CompatibilityLevel
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  5427 */       NO_COMPATIBILITY(0, 0), 
/*  5428 */       PROTO1_COMPATIBLE(1, 100), 
/*  5429 */       DEPRECATED_PROTO1_COMPATIBLE(2, 50);
/*       */ 
/*       */       public static final int NO_COMPATIBILITY_VALUE = 0;
/*       */       public static final int PROTO1_COMPATIBLE_VALUE = 100;
/*       */       public static final int DEPRECATED_PROTO1_COMPATIBLE_VALUE = 50;
/*       */       private static Internal.EnumLiteMap<CompatibilityLevel> internalValueMap;
/*       */       private static final CompatibilityLevel[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  5437 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static CompatibilityLevel valueOf(int value) {
/*  5440 */         switch (value) { case 0:
/*  5441 */           return NO_COMPATIBILITY;
/*       */         case 100:
/*  5442 */           return PROTO1_COMPATIBLE;
/*       */         case 50:
/*  5443 */           return DEPRECATED_PROTO1_COMPATIBLE; }
/*  5444 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<CompatibilityLevel> internalGetValueMap()
/*       */       {
/*  5450 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  5462 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  5466 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  5470 */         return (Descriptors.EnumDescriptor)DescriptorProtos.FileOptions.getDescriptor().getEnumTypes().get(0);
/*       */       }
/*       */ 
/*       */       public static CompatibilityLevel valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  5478 */         if (desc.getType() != getDescriptor()) {
/*  5479 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  5482 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private CompatibilityLevel(int index, int value)
/*       */       {
/*  5487 */         this.index = index;
/*  5488 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  5453 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.FileOptions.CompatibilityLevel findValueByNumber(int number) {
/*  5456 */             return DescriptorProtos.FileOptions.CompatibilityLevel.valueOf(number);
/*       */           }
/*       */         };
/*  5473 */         VALUES = new CompatibilityLevel[] { NO_COMPATIBILITY, PROTO1_COMPATIBLE, DEPRECATED_PROTO1_COMPATIBLE };
/*       */ 
/*  5492 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class MethodDescriptorProto extends GeneratedMessage
/*       */   {
/*  5389 */     private static final MethodDescriptorProto defaultInstance = new MethodDescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int INPUT_TYPE_FIELD_NUMBER = 2;
/*       */     private boolean hasInputType;
/*       */     private String inputType_;
/*       */     public static final int OUTPUT_TYPE_FIELD_NUMBER = 3;
/*       */     private boolean hasOutputType;
/*       */     private String outputType_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 4;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.MethodOptions options_;
/*  5012 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private MethodDescriptorProto(Builder builder)
/*       */     {
/*  4914 */       super();
/*       */     }
/*       */     private MethodDescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto getDefaultInstance() {
/*  4920 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public MethodDescriptorProto getDefaultInstanceForType() {
/*  4924 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  4929 */       return DescriptorProtos.internal_static_proto2_MethodDescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  4934 */       return DescriptorProtos.internal_static_proto2_MethodDescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*  4942 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*  4945 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public boolean hasInputType()
/*       */     {
/*  4953 */       return this.hasInputType;
/*       */     }
/*       */     public String getInputType() {
/*  4956 */       return this.inputType_;
/*       */     }
/*       */ 
/*       */     public boolean hasOutputType()
/*       */     {
/*  4964 */       return this.hasOutputType;
/*       */     }
/*       */     public String getOutputType() {
/*  4967 */       return this.outputType_;
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*  4975 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.MethodOptions getOptions() {
/*  4978 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  4982 */       this.name_ = "";
/*  4983 */       this.inputType_ = "";
/*  4984 */       this.outputType_ = "";
/*  4985 */       this.options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
/*       */     }
/*       */ 
/*       */     public final boolean isInitialized() {
/*  4989 */       return (!hasOptions()) || 
/*  4989 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  4996 */       getSerializedSize();
/*  4997 */       if (hasName()) {
/*  4998 */         output.writeString(1, getName());
/*       */       }
/*  5000 */       if (hasInputType()) {
/*  5001 */         output.writeString(2, getInputType());
/*       */       }
/*  5003 */       if (hasOutputType()) {
/*  5004 */         output.writeString(3, getOutputType());
/*       */       }
/*  5006 */       if (hasOptions()) {
/*  5007 */         output.writeMessage(4, getOptions());
/*       */       }
/*  5009 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  5014 */       int size = this.memoizedSerializedSize;
/*  5015 */       if (size != -1) return size;
/*       */ 
/*  5017 */       size = 0;
/*  5018 */       if (hasName()) {
/*  5019 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*  5022 */       if (hasInputType()) {
/*  5023 */         size += CodedOutputStream.computeStringSize(2, getInputType());
/*       */       }
/*       */ 
/*  5026 */       if (hasOutputType()) {
/*  5027 */         size += CodedOutputStream.computeStringSize(3, getOutputType());
/*       */       }
/*       */ 
/*  5030 */       if (hasOptions()) {
/*  5031 */         size += CodedOutputStream.computeMessageSize(4, getOptions());
/*       */       }
/*       */ 
/*  5034 */       size += getUnknownFields().getSerializedSize();
/*  5035 */       this.memoizedSerializedSize = size;
/*  5036 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  5041 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  5047 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  5053 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  5058 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  5064 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*  5069 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  5075 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  5080 */       Builder builder = newBuilder();
/*  5081 */       if (builder.mergeDelimitedFrom(input)) {
/*  5082 */         return builder.buildParsed();
/*       */       }
/*  5084 */       return null;
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  5091 */       Builder builder = newBuilder();
/*  5092 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  5093 */         return builder.buildParsed();
/*       */       }
/*  5095 */       return null;
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  5101 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static MethodDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  5107 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  5111 */       return Builder.access$10000(); } 
/*  5112 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(MethodDescriptorProto prototype) {
/*  5114 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  5116 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  5390 */       DescriptorProtos.internalForceInit();
/*  5391 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*  5278 */       private String name_ = "";
/*       */       private boolean hasInputType;
/*  5301 */       private String inputType_ = "";
/*       */       private boolean hasOutputType;
/*  5324 */       private String outputType_ = "";
/*       */       private boolean hasOptions;
/*  5347 */       private DescriptorProtos.MethodOptions options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  5122 */         return DescriptorProtos.internal_static_proto2_MethodDescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  5127 */         return DescriptorProtos.internal_static_proto2_MethodDescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  5135 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  5139 */         super.clear();
/*  5140 */         this.name_ = "";
/*  5141 */         this.hasName = false;
/*  5142 */         this.inputType_ = "";
/*  5143 */         this.hasInputType = false;
/*  5144 */         this.outputType_ = "";
/*  5145 */         this.hasOutputType = false;
/*  5146 */         this.options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
/*  5147 */         this.hasOptions = false;
/*  5148 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  5152 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  5157 */         return DescriptorProtos.MethodDescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MethodDescriptorProto getDefaultInstanceForType() {
/*  5161 */         return DescriptorProtos.MethodDescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MethodDescriptorProto build() {
/*  5165 */         DescriptorProtos.MethodDescriptorProto result = buildPartial();
/*  5166 */         if (!result.isInitialized()) {
/*  5167 */           throw newUninitializedMessageException(result);
/*       */         }
/*  5169 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.MethodDescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  5174 */         DescriptorProtos.MethodDescriptorProto result = buildPartial();
/*  5175 */         if (!result.isInitialized()) {
/*  5176 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  5179 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.MethodDescriptorProto buildPartial() {
/*  5183 */         DescriptorProtos.MethodDescriptorProto result = new DescriptorProtos.MethodDescriptorProto(this, null);
/*  5184 */         DescriptorProtos.MethodDescriptorProto.access$10202(result, this.hasName);
/*  5185 */         DescriptorProtos.MethodDescriptorProto.access$10302(result, this.name_);
/*  5186 */         DescriptorProtos.MethodDescriptorProto.access$10402(result, this.hasInputType);
/*  5187 */         DescriptorProtos.MethodDescriptorProto.access$10502(result, this.inputType_);
/*  5188 */         DescriptorProtos.MethodDescriptorProto.access$10602(result, this.hasOutputType);
/*  5189 */         DescriptorProtos.MethodDescriptorProto.access$10702(result, this.outputType_);
/*  5190 */         DescriptorProtos.MethodDescriptorProto.access$10802(result, this.hasOptions);
/*  5191 */         DescriptorProtos.MethodDescriptorProto.access$10902(result, this.options_);
/*  5192 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  5196 */         if ((other instanceof DescriptorProtos.MethodDescriptorProto)) {
/*  5197 */           return mergeFrom((DescriptorProtos.MethodDescriptorProto)other);
/*       */         }
/*  5199 */         super.mergeFrom(other);
/*  5200 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.MethodDescriptorProto other)
/*       */       {
/*  5205 */         if (other == DescriptorProtos.MethodDescriptorProto.getDefaultInstance()) return this;
/*  5206 */         if (other.hasName()) {
/*  5207 */           setName(other.getName());
/*       */         }
/*  5209 */         if (other.hasInputType()) {
/*  5210 */           setInputType(other.getInputType());
/*       */         }
/*  5212 */         if (other.hasOutputType()) {
/*  5213 */           setOutputType(other.getOutputType());
/*       */         }
/*  5215 */         if (other.hasOptions()) {
/*  5216 */           mergeOptions(other.getOptions());
/*       */         }
/*  5218 */         mergeUnknownFields(other.getUnknownFields());
/*  5219 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized()
/*       */       {
/*  5224 */         return (!hasOptions()) || 
/*  5224 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  5233 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  5237 */           int tag = input.readTag();
/*  5238 */           switch (tag) {
/*       */           case 0:
/*  5240 */             setUnknownFields(unknownFields.build());
/*  5241 */             return this;
/*       */           default:
/*  5243 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  5245 */             setUnknownFields(unknownFields.build());
/*  5246 */             return this;
/*       */           case 10:
/*  5251 */             setName(input.readString());
/*  5252 */             break;
/*       */           case 18:
/*  5255 */             setInputType(input.readString());
/*  5256 */             break;
/*       */           case 26:
/*  5259 */             setOutputType(input.readString());
/*  5260 */             break;
/*       */           case 34:
/*  5263 */             DescriptorProtos.MethodOptions.Builder subBuilder = DescriptorProtos.MethodOptions.newBuilder();
/*  5264 */             if (hasOptions()) {
/*  5265 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*  5267 */             input.readMessage(subBuilder, extensionRegistry);
/*  5268 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*  5280 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*  5283 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*  5286 */         if (value == null) {
/*  5287 */           throw new NullPointerException();
/*       */         }
/*  5289 */         this.hasName = true;
/*  5290 */         this.name_ = value;
/*  5291 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*  5294 */         this.hasName = false;
/*  5295 */         this.name_ = DescriptorProtos.MethodDescriptorProto.getDefaultInstance().getName();
/*  5296 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasInputType()
/*       */       {
/*  5303 */         return this.hasInputType;
/*       */       }
/*       */       public String getInputType() {
/*  5306 */         return this.inputType_;
/*       */       }
/*       */       public Builder setInputType(String value) {
/*  5309 */         if (value == null) {
/*  5310 */           throw new NullPointerException();
/*       */         }
/*  5312 */         this.hasInputType = true;
/*  5313 */         this.inputType_ = value;
/*  5314 */         return this;
/*       */       }
/*       */       public Builder clearInputType() {
/*  5317 */         this.hasInputType = false;
/*  5318 */         this.inputType_ = DescriptorProtos.MethodDescriptorProto.getDefaultInstance().getInputType();
/*  5319 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOutputType()
/*       */       {
/*  5326 */         return this.hasOutputType;
/*       */       }
/*       */       public String getOutputType() {
/*  5329 */         return this.outputType_;
/*       */       }
/*       */       public Builder setOutputType(String value) {
/*  5332 */         if (value == null) {
/*  5333 */           throw new NullPointerException();
/*       */         }
/*  5335 */         this.hasOutputType = true;
/*  5336 */         this.outputType_ = value;
/*  5337 */         return this;
/*       */       }
/*       */       public Builder clearOutputType() {
/*  5340 */         this.hasOutputType = false;
/*  5341 */         this.outputType_ = DescriptorProtos.MethodDescriptorProto.getDefaultInstance().getOutputType();
/*  5342 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  5349 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.MethodOptions getOptions() {
/*  5352 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.MethodOptions value) {
/*  5355 */         if (value == null) {
/*  5356 */           throw new NullPointerException();
/*       */         }
/*  5358 */         this.hasOptions = true;
/*  5359 */         this.options_ = value;
/*  5360 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.MethodOptions.Builder builderForValue) {
/*  5364 */         this.hasOptions = true;
/*  5365 */         this.options_ = builderForValue.build();
/*  5366 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.MethodOptions value) {
/*  5369 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.MethodOptions.getDefaultInstance()))
/*       */         {
/*  5371 */           this.options_ = DescriptorProtos.MethodOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  5374 */           this.options_ = value;
/*       */         }
/*  5376 */         this.hasOptions = true;
/*  5377 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  5380 */         this.hasOptions = false;
/*  5381 */         this.options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
/*  5382 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class ServiceDescriptorProto extends GeneratedMessage
/*       */   {
/*  4902 */     private static final ServiceDescriptorProto defaultInstance = new ServiceDescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int METHOD_FIELD_NUMBER = 2;
/*       */     private List<DescriptorProtos.MethodDescriptorProto> method_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 3;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.ServiceOptions options_;
/*  4512 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private ServiceDescriptorProto(Builder builder)
/*       */     {
/*  4424 */       super();
/*       */     }
/*       */     private ServiceDescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto getDefaultInstance() {
/*  4430 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public ServiceDescriptorProto getDefaultInstanceForType() {
/*  4434 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  4439 */       return DescriptorProtos.internal_static_proto2_ServiceDescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  4444 */       return DescriptorProtos.internal_static_proto2_ServiceDescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*  4452 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*  4455 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.MethodDescriptorProto> getMethodList()
/*       */     {
/*  4462 */       return this.method_;
/*       */     }
/*       */     public int getMethodCount() {
/*  4465 */       return this.method_.size();
/*       */     }
/*       */     public DescriptorProtos.MethodDescriptorProto getMethod(int index) {
/*  4468 */       return (DescriptorProtos.MethodDescriptorProto)this.method_.get(index);
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*  4476 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.ServiceOptions getOptions() {
/*  4479 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  4483 */       this.name_ = "";
/*  4484 */       this.method_ = Collections.emptyList();
/*  4485 */       this.options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  4488 */       for (DescriptorProtos.MethodDescriptorProto element : getMethodList()) {
/*  4489 */         if (!element.isInitialized()) return false;
/*       */       }
/*       */ 
/*  4492 */       return (!hasOptions()) || 
/*  4492 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  4499 */       getSerializedSize();
/*  4500 */       if (hasName()) {
/*  4501 */         output.writeString(1, getName());
/*       */       }
/*  4503 */       for (DescriptorProtos.MethodDescriptorProto element : getMethodList()) {
/*  4504 */         output.writeMessage(2, element);
/*       */       }
/*  4506 */       if (hasOptions()) {
/*  4507 */         output.writeMessage(3, getOptions());
/*       */       }
/*  4509 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  4514 */       int size = this.memoizedSerializedSize;
/*  4515 */       if (size != -1) return size;
/*       */ 
/*  4517 */       size = 0;
/*  4518 */       if (hasName()) {
/*  4519 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*  4522 */       for (DescriptorProtos.MethodDescriptorProto element : getMethodList()) {
/*  4523 */         size += CodedOutputStream.computeMessageSize(2, element);
/*       */       }
/*       */ 
/*  4526 */       if (hasOptions()) {
/*  4527 */         size += CodedOutputStream.computeMessageSize(3, getOptions());
/*       */       }
/*       */ 
/*  4530 */       size += getUnknownFields().getSerializedSize();
/*  4531 */       this.memoizedSerializedSize = size;
/*  4532 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  4537 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  4543 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  4549 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  4554 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  4560 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*  4565 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  4571 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  4576 */       Builder builder = newBuilder();
/*  4577 */       if (builder.mergeDelimitedFrom(input)) {
/*  4578 */         return builder.buildParsed();
/*       */       }
/*  4580 */       return null;
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  4587 */       Builder builder = newBuilder();
/*  4588 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  4589 */         return builder.buildParsed();
/*       */       }
/*  4591 */       return null;
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  4597 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static ServiceDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  4603 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  4607 */       return Builder.access$9000(); } 
/*  4608 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(ServiceDescriptorProto prototype) {
/*  4610 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  4612 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  4903 */       DescriptorProtos.internalForceInit();
/*  4904 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*  4777 */       private String name_ = "";
/*       */ 
/*  4799 */       private List<DescriptorProtos.MethodDescriptorProto> method_ = Collections.emptyList();
/*       */       private boolean isMethodMutable;
/*       */       private boolean hasOptions;
/*  4860 */       private DescriptorProtos.ServiceOptions options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  4618 */         return DescriptorProtos.internal_static_proto2_ServiceDescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  4623 */         return DescriptorProtos.internal_static_proto2_ServiceDescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  4631 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  4635 */         super.clear();
/*  4636 */         this.name_ = "";
/*  4637 */         this.hasName = false;
/*  4638 */         this.method_ = Collections.emptyList();
/*  4639 */         this.isMethodMutable = false;
/*  4640 */         this.options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
/*  4641 */         this.hasOptions = false;
/*  4642 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  4646 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  4651 */         return DescriptorProtos.ServiceDescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.ServiceDescriptorProto getDefaultInstanceForType() {
/*  4655 */         return DescriptorProtos.ServiceDescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.ServiceDescriptorProto build() {
/*  4659 */         DescriptorProtos.ServiceDescriptorProto result = buildPartial();
/*  4660 */         if (!result.isInitialized()) {
/*  4661 */           throw newUninitializedMessageException(result);
/*       */         }
/*  4663 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.ServiceDescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  4668 */         DescriptorProtos.ServiceDescriptorProto result = buildPartial();
/*  4669 */         if (!result.isInitialized()) {
/*  4670 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  4673 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.ServiceDescriptorProto buildPartial() {
/*  4677 */         DescriptorProtos.ServiceDescriptorProto result = new DescriptorProtos.ServiceDescriptorProto(this, null);
/*  4678 */         DescriptorProtos.ServiceDescriptorProto.access$9202(result, this.hasName);
/*  4679 */         DescriptorProtos.ServiceDescriptorProto.access$9302(result, this.name_);
/*  4680 */         if (this.isMethodMutable) {
/*  4681 */           this.method_ = Collections.unmodifiableList(this.method_);
/*  4682 */           this.isMethodMutable = false;
/*       */         }
/*  4684 */         DescriptorProtos.ServiceDescriptorProto.access$9402(result, this.method_);
/*  4685 */         DescriptorProtos.ServiceDescriptorProto.access$9502(result, this.hasOptions);
/*  4686 */         DescriptorProtos.ServiceDescriptorProto.access$9602(result, this.options_);
/*  4687 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  4691 */         if ((other instanceof DescriptorProtos.ServiceDescriptorProto)) {
/*  4692 */           return mergeFrom((DescriptorProtos.ServiceDescriptorProto)other);
/*       */         }
/*  4694 */         super.mergeFrom(other);
/*  4695 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.ServiceDescriptorProto other)
/*       */       {
/*  4700 */         if (other == DescriptorProtos.ServiceDescriptorProto.getDefaultInstance()) return this;
/*  4701 */         if (other.hasName()) {
/*  4702 */           setName(other.getName());
/*       */         }
/*  4704 */         if (!other.method_.isEmpty()) {
/*  4705 */           if (this.method_.isEmpty()) {
/*  4706 */             this.method_ = other.method_;
/*  4707 */             this.isMethodMutable = false;
/*       */           } else {
/*  4709 */             ensureMethodIsMutable();
/*  4710 */             this.method_.addAll(other.method_);
/*       */           }
/*       */         }
/*  4713 */         if (other.hasOptions()) {
/*  4714 */           mergeOptions(other.getOptions());
/*       */         }
/*  4716 */         mergeUnknownFields(other.getUnknownFields());
/*  4717 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  4721 */         for (DescriptorProtos.MethodDescriptorProto element : getMethodList()) {
/*  4722 */           if (!element.isInitialized()) return false;
/*       */         }
/*       */ 
/*  4725 */         return (!hasOptions()) || 
/*  4725 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  4734 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  4738 */           int tag = input.readTag();
/*  4739 */           switch (tag) {
/*       */           case 0:
/*  4741 */             setUnknownFields(unknownFields.build());
/*  4742 */             return this;
/*       */           default:
/*  4744 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  4746 */             setUnknownFields(unknownFields.build());
/*  4747 */             return this;
/*       */           case 10:
/*  4752 */             setName(input.readString());
/*  4753 */             break;
/*       */           case 18:
/*  4756 */             DescriptorProtos.MethodDescriptorProto.Builder subBuilder = DescriptorProtos.MethodDescriptorProto.newBuilder();
/*  4757 */             input.readMessage(subBuilder, extensionRegistry);
/*  4758 */             addMethod(subBuilder.buildPartial());
/*  4759 */             break;
/*       */           case 26:
/*  4762 */             DescriptorProtos.ServiceOptions.Builder subBuilder = DescriptorProtos.ServiceOptions.newBuilder();
/*  4763 */             if (hasOptions()) {
/*  4764 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*  4766 */             input.readMessage(subBuilder, extensionRegistry);
/*  4767 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*  4779 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*  4782 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*  4785 */         if (value == null) {
/*  4786 */           throw new NullPointerException();
/*       */         }
/*  4788 */         this.hasName = true;
/*  4789 */         this.name_ = value;
/*  4790 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*  4793 */         this.hasName = false;
/*  4794 */         this.name_ = DescriptorProtos.ServiceDescriptorProto.getDefaultInstance().getName();
/*  4795 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureMethodIsMutable()
/*       */       {
/*  4803 */         if (!this.isMethodMutable) {
/*  4804 */           this.method_ = new ArrayList(this.method_);
/*  4805 */           this.isMethodMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.MethodDescriptorProto> getMethodList() {
/*  4809 */         return Collections.unmodifiableList(this.method_);
/*       */       }
/*       */       public int getMethodCount() {
/*  4812 */         return this.method_.size();
/*       */       }
/*       */       public DescriptorProtos.MethodDescriptorProto getMethod(int index) {
/*  4815 */         return (DescriptorProtos.MethodDescriptorProto)this.method_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setMethod(int index, DescriptorProtos.MethodDescriptorProto value) {
/*  4819 */         if (value == null) {
/*  4820 */           throw new NullPointerException();
/*       */         }
/*  4822 */         ensureMethodIsMutable();
/*  4823 */         this.method_.set(index, value);
/*  4824 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setMethod(int index, DescriptorProtos.MethodDescriptorProto.Builder builderForValue) {
/*  4828 */         ensureMethodIsMutable();
/*  4829 */         this.method_.set(index, builderForValue.build());
/*  4830 */         return this;
/*       */       }
/*       */       public Builder addMethod(DescriptorProtos.MethodDescriptorProto value) {
/*  4833 */         if (value == null) {
/*  4834 */           throw new NullPointerException();
/*       */         }
/*  4836 */         ensureMethodIsMutable();
/*  4837 */         this.method_.add(value);
/*  4838 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addMethod(DescriptorProtos.MethodDescriptorProto.Builder builderForValue) {
/*  4842 */         ensureMethodIsMutable();
/*  4843 */         this.method_.add(builderForValue.build());
/*  4844 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllMethod(Iterable<? extends DescriptorProtos.MethodDescriptorProto> values) {
/*  4848 */         ensureMethodIsMutable();
/*  4849 */         GeneratedMessage.Builder.addAll(values, this.method_);
/*  4850 */         return this;
/*       */       }
/*       */       public Builder clearMethod() {
/*  4853 */         this.method_ = Collections.emptyList();
/*  4854 */         this.isMethodMutable = false;
/*  4855 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  4862 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.ServiceOptions getOptions() {
/*  4865 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.ServiceOptions value) {
/*  4868 */         if (value == null) {
/*  4869 */           throw new NullPointerException();
/*       */         }
/*  4871 */         this.hasOptions = true;
/*  4872 */         this.options_ = value;
/*  4873 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.ServiceOptions.Builder builderForValue) {
/*  4877 */         this.hasOptions = true;
/*  4878 */         this.options_ = builderForValue.build();
/*  4879 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.ServiceOptions value) {
/*  4882 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.ServiceOptions.getDefaultInstance()))
/*       */         {
/*  4884 */           this.options_ = DescriptorProtos.ServiceOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  4887 */           this.options_ = value;
/*       */         }
/*  4889 */         this.hasOptions = true;
/*  4890 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  4893 */         this.hasOptions = false;
/*  4894 */         this.options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
/*  4895 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class EnumValueDescriptorProto extends GeneratedMessage
/*       */   {
/*  4412 */     private static final EnumValueDescriptorProto defaultInstance = new EnumValueDescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int NUMBER_FIELD_NUMBER = 2;
/*       */     private boolean hasNumber;
/*       */     private int number_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 3;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.EnumValueOptions options_;
/*  4076 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private EnumValueDescriptorProto(Builder builder)
/*       */     {
/*  3993 */       super();
/*       */     }
/*       */     private EnumValueDescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto getDefaultInstance() {
/*  3999 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public EnumValueDescriptorProto getDefaultInstanceForType() {
/*  4003 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  4008 */       return DescriptorProtos.internal_static_proto2_EnumValueDescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  4013 */       return DescriptorProtos.internal_static_proto2_EnumValueDescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*  4021 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*  4024 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public boolean hasNumber()
/*       */     {
/*  4032 */       return this.hasNumber;
/*       */     }
/*       */     public int getNumber() {
/*  4035 */       return this.number_;
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*  4043 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.EnumValueOptions getOptions() {
/*  4046 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  4050 */       this.name_ = "";
/*  4051 */       this.number_ = 0;
/*  4052 */       this.options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
/*       */     }
/*       */ 
/*       */     public final boolean isInitialized() {
/*  4056 */       return (!hasOptions()) || 
/*  4056 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  4063 */       getSerializedSize();
/*  4064 */       if (hasName()) {
/*  4065 */         output.writeString(1, getName());
/*       */       }
/*  4067 */       if (hasNumber()) {
/*  4068 */         output.writeInt32(2, getNumber());
/*       */       }
/*  4070 */       if (hasOptions()) {
/*  4071 */         output.writeMessage(3, getOptions());
/*       */       }
/*  4073 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  4078 */       int size = this.memoizedSerializedSize;
/*  4079 */       if (size != -1) return size;
/*       */ 
/*  4081 */       size = 0;
/*  4082 */       if (hasName()) {
/*  4083 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*  4086 */       if (hasNumber()) {
/*  4087 */         size += CodedOutputStream.computeInt32Size(2, getNumber());
/*       */       }
/*       */ 
/*  4090 */       if (hasOptions()) {
/*  4091 */         size += CodedOutputStream.computeMessageSize(3, getOptions());
/*       */       }
/*       */ 
/*  4094 */       size += getUnknownFields().getSerializedSize();
/*  4095 */       this.memoizedSerializedSize = size;
/*  4096 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  4101 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  4107 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  4113 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  4118 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  4124 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*  4129 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  4135 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  4140 */       Builder builder = newBuilder();
/*  4141 */       if (builder.mergeDelimitedFrom(input)) {
/*  4142 */         return builder.buildParsed();
/*       */       }
/*  4144 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  4151 */       Builder builder = newBuilder();
/*  4152 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  4153 */         return builder.buildParsed();
/*       */       }
/*  4155 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  4161 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumValueDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  4167 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  4171 */       return Builder.access$7900(); } 
/*  4172 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(EnumValueDescriptorProto prototype) {
/*  4174 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  4176 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  4413 */       DescriptorProtos.internalForceInit();
/*  4414 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*  4327 */       private String name_ = "";
/*       */       private boolean hasNumber;
/*       */       private int number_;
/*       */       private boolean hasOptions;
/*  4370 */       private DescriptorProtos.EnumValueOptions options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  4182 */         return DescriptorProtos.internal_static_proto2_EnumValueDescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  4187 */         return DescriptorProtos.internal_static_proto2_EnumValueDescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  4195 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  4199 */         super.clear();
/*  4200 */         this.name_ = "";
/*  4201 */         this.hasName = false;
/*  4202 */         this.number_ = 0;
/*  4203 */         this.hasNumber = false;
/*  4204 */         this.options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
/*  4205 */         this.hasOptions = false;
/*  4206 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  4210 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  4215 */         return DescriptorProtos.EnumValueDescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumValueDescriptorProto getDefaultInstanceForType() {
/*  4219 */         return DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumValueDescriptorProto build() {
/*  4223 */         DescriptorProtos.EnumValueDescriptorProto result = buildPartial();
/*  4224 */         if (!result.isInitialized()) {
/*  4225 */           throw newUninitializedMessageException(result);
/*       */         }
/*  4227 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.EnumValueDescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  4232 */         DescriptorProtos.EnumValueDescriptorProto result = buildPartial();
/*  4233 */         if (!result.isInitialized()) {
/*  4234 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  4237 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumValueDescriptorProto buildPartial() {
/*  4241 */         DescriptorProtos.EnumValueDescriptorProto result = new DescriptorProtos.EnumValueDescriptorProto(this, null);
/*  4242 */         DescriptorProtos.EnumValueDescriptorProto.access$8102(result, this.hasName);
/*  4243 */         DescriptorProtos.EnumValueDescriptorProto.access$8202(result, this.name_);
/*  4244 */         DescriptorProtos.EnumValueDescriptorProto.access$8302(result, this.hasNumber);
/*  4245 */         DescriptorProtos.EnumValueDescriptorProto.access$8402(result, this.number_);
/*  4246 */         DescriptorProtos.EnumValueDescriptorProto.access$8502(result, this.hasOptions);
/*  4247 */         DescriptorProtos.EnumValueDescriptorProto.access$8602(result, this.options_);
/*  4248 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  4252 */         if ((other instanceof DescriptorProtos.EnumValueDescriptorProto)) {
/*  4253 */           return mergeFrom((DescriptorProtos.EnumValueDescriptorProto)other);
/*       */         }
/*  4255 */         super.mergeFrom(other);
/*  4256 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.EnumValueDescriptorProto other)
/*       */       {
/*  4261 */         if (other == DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance()) return this;
/*  4262 */         if (other.hasName()) {
/*  4263 */           setName(other.getName());
/*       */         }
/*  4265 */         if (other.hasNumber()) {
/*  4266 */           setNumber(other.getNumber());
/*       */         }
/*  4268 */         if (other.hasOptions()) {
/*  4269 */           mergeOptions(other.getOptions());
/*       */         }
/*  4271 */         mergeUnknownFields(other.getUnknownFields());
/*  4272 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized()
/*       */       {
/*  4277 */         return (!hasOptions()) || 
/*  4277 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  4286 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  4290 */           int tag = input.readTag();
/*  4291 */           switch (tag) {
/*       */           case 0:
/*  4293 */             setUnknownFields(unknownFields.build());
/*  4294 */             return this;
/*       */           default:
/*  4296 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  4298 */             setUnknownFields(unknownFields.build());
/*  4299 */             return this;
/*       */           case 10:
/*  4304 */             setName(input.readString());
/*  4305 */             break;
/*       */           case 16:
/*  4308 */             setNumber(input.readInt32());
/*  4309 */             break;
/*       */           case 26:
/*  4312 */             DescriptorProtos.EnumValueOptions.Builder subBuilder = DescriptorProtos.EnumValueOptions.newBuilder();
/*  4313 */             if (hasOptions()) {
/*  4314 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*  4316 */             input.readMessage(subBuilder, extensionRegistry);
/*  4317 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*  4329 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*  4332 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*  4335 */         if (value == null) {
/*  4336 */           throw new NullPointerException();
/*       */         }
/*  4338 */         this.hasName = true;
/*  4339 */         this.name_ = value;
/*  4340 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*  4343 */         this.hasName = false;
/*  4344 */         this.name_ = DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance().getName();
/*  4345 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasNumber()
/*       */       {
/*  4352 */         return this.hasNumber;
/*       */       }
/*       */       public int getNumber() {
/*  4355 */         return this.number_;
/*       */       }
/*       */       public Builder setNumber(int value) {
/*  4358 */         this.hasNumber = true;
/*  4359 */         this.number_ = value;
/*  4360 */         return this;
/*       */       }
/*       */       public Builder clearNumber() {
/*  4363 */         this.hasNumber = false;
/*  4364 */         this.number_ = 0;
/*  4365 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  4372 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.EnumValueOptions getOptions() {
/*  4375 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.EnumValueOptions value) {
/*  4378 */         if (value == null) {
/*  4379 */           throw new NullPointerException();
/*       */         }
/*  4381 */         this.hasOptions = true;
/*  4382 */         this.options_ = value;
/*  4383 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.EnumValueOptions.Builder builderForValue) {
/*  4387 */         this.hasOptions = true;
/*  4388 */         this.options_ = builderForValue.build();
/*  4389 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.EnumValueOptions value) {
/*  4392 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.EnumValueOptions.getDefaultInstance()))
/*       */         {
/*  4394 */           this.options_ = DescriptorProtos.EnumValueOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  4397 */           this.options_ = value;
/*       */         }
/*  4399 */         this.hasOptions = true;
/*  4400 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  4403 */         this.hasOptions = false;
/*  4404 */         this.options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
/*  4405 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class EnumDescriptorProto extends GeneratedMessage
/*       */   {
/*  3981 */     private static final EnumDescriptorProto defaultInstance = new EnumDescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int VALUE_FIELD_NUMBER = 2;
/*       */     private List<DescriptorProtos.EnumValueDescriptorProto> value_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 3;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.EnumOptions options_;
/*  3591 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private EnumDescriptorProto(Builder builder)
/*       */     {
/*  3503 */       super();
/*       */     }
/*       */     private EnumDescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto getDefaultInstance() {
/*  3509 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public EnumDescriptorProto getDefaultInstanceForType() {
/*  3513 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  3518 */       return DescriptorProtos.internal_static_proto2_EnumDescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  3523 */       return DescriptorProtos.internal_static_proto2_EnumDescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*  3531 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*  3534 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.EnumValueDescriptorProto> getValueList()
/*       */     {
/*  3541 */       return this.value_;
/*       */     }
/*       */     public int getValueCount() {
/*  3544 */       return this.value_.size();
/*       */     }
/*       */     public DescriptorProtos.EnumValueDescriptorProto getValue(int index) {
/*  3547 */       return (DescriptorProtos.EnumValueDescriptorProto)this.value_.get(index);
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*  3555 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.EnumOptions getOptions() {
/*  3558 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  3562 */       this.name_ = "";
/*  3563 */       this.value_ = Collections.emptyList();
/*  3564 */       this.options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  3567 */       for (DescriptorProtos.EnumValueDescriptorProto element : getValueList()) {
/*  3568 */         if (!element.isInitialized()) return false;
/*       */       }
/*       */ 
/*  3571 */       return (!hasOptions()) || 
/*  3571 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  3578 */       getSerializedSize();
/*  3579 */       if (hasName()) {
/*  3580 */         output.writeString(1, getName());
/*       */       }
/*  3582 */       for (DescriptorProtos.EnumValueDescriptorProto element : getValueList()) {
/*  3583 */         output.writeMessage(2, element);
/*       */       }
/*  3585 */       if (hasOptions()) {
/*  3586 */         output.writeMessage(3, getOptions());
/*       */       }
/*  3588 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  3593 */       int size = this.memoizedSerializedSize;
/*  3594 */       if (size != -1) return size;
/*       */ 
/*  3596 */       size = 0;
/*  3597 */       if (hasName()) {
/*  3598 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*  3601 */       for (DescriptorProtos.EnumValueDescriptorProto element : getValueList()) {
/*  3602 */         size += CodedOutputStream.computeMessageSize(2, element);
/*       */       }
/*       */ 
/*  3605 */       if (hasOptions()) {
/*  3606 */         size += CodedOutputStream.computeMessageSize(3, getOptions());
/*       */       }
/*       */ 
/*  3609 */       size += getUnknownFields().getSerializedSize();
/*  3610 */       this.memoizedSerializedSize = size;
/*  3611 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  3616 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  3622 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  3628 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  3633 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  3639 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*  3644 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  3650 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  3655 */       Builder builder = newBuilder();
/*  3656 */       if (builder.mergeDelimitedFrom(input)) {
/*  3657 */         return builder.buildParsed();
/*       */       }
/*  3659 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  3666 */       Builder builder = newBuilder();
/*  3667 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  3668 */         return builder.buildParsed();
/*       */       }
/*  3670 */       return null;
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  3676 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static EnumDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  3682 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  3686 */       return Builder.access$6900(); } 
/*  3687 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(EnumDescriptorProto prototype) {
/*  3689 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  3691 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  3982 */       DescriptorProtos.internalForceInit();
/*  3983 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*  3856 */       private String name_ = "";
/*       */ 
/*  3878 */       private List<DescriptorProtos.EnumValueDescriptorProto> value_ = Collections.emptyList();
/*       */       private boolean isValueMutable;
/*       */       private boolean hasOptions;
/*  3939 */       private DescriptorProtos.EnumOptions options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  3697 */         return DescriptorProtos.internal_static_proto2_EnumDescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  3702 */         return DescriptorProtos.internal_static_proto2_EnumDescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  3710 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  3714 */         super.clear();
/*  3715 */         this.name_ = "";
/*  3716 */         this.hasName = false;
/*  3717 */         this.value_ = Collections.emptyList();
/*  3718 */         this.isValueMutable = false;
/*  3719 */         this.options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
/*  3720 */         this.hasOptions = false;
/*  3721 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  3725 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  3730 */         return DescriptorProtos.EnumDescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumDescriptorProto getDefaultInstanceForType() {
/*  3734 */         return DescriptorProtos.EnumDescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumDescriptorProto build() {
/*  3738 */         DescriptorProtos.EnumDescriptorProto result = buildPartial();
/*  3739 */         if (!result.isInitialized()) {
/*  3740 */           throw newUninitializedMessageException(result);
/*       */         }
/*  3742 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.EnumDescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  3747 */         DescriptorProtos.EnumDescriptorProto result = buildPartial();
/*  3748 */         if (!result.isInitialized()) {
/*  3749 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  3752 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.EnumDescriptorProto buildPartial() {
/*  3756 */         DescriptorProtos.EnumDescriptorProto result = new DescriptorProtos.EnumDescriptorProto(this, null);
/*  3757 */         DescriptorProtos.EnumDescriptorProto.access$7102(result, this.hasName);
/*  3758 */         DescriptorProtos.EnumDescriptorProto.access$7202(result, this.name_);
/*  3759 */         if (this.isValueMutable) {
/*  3760 */           this.value_ = Collections.unmodifiableList(this.value_);
/*  3761 */           this.isValueMutable = false;
/*       */         }
/*  3763 */         DescriptorProtos.EnumDescriptorProto.access$7302(result, this.value_);
/*  3764 */         DescriptorProtos.EnumDescriptorProto.access$7402(result, this.hasOptions);
/*  3765 */         DescriptorProtos.EnumDescriptorProto.access$7502(result, this.options_);
/*  3766 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  3770 */         if ((other instanceof DescriptorProtos.EnumDescriptorProto)) {
/*  3771 */           return mergeFrom((DescriptorProtos.EnumDescriptorProto)other);
/*       */         }
/*  3773 */         super.mergeFrom(other);
/*  3774 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.EnumDescriptorProto other)
/*       */       {
/*  3779 */         if (other == DescriptorProtos.EnumDescriptorProto.getDefaultInstance()) return this;
/*  3780 */         if (other.hasName()) {
/*  3781 */           setName(other.getName());
/*       */         }
/*  3783 */         if (!other.value_.isEmpty()) {
/*  3784 */           if (this.value_.isEmpty()) {
/*  3785 */             this.value_ = other.value_;
/*  3786 */             this.isValueMutable = false;
/*       */           } else {
/*  3788 */             ensureValueIsMutable();
/*  3789 */             this.value_.addAll(other.value_);
/*       */           }
/*       */         }
/*  3792 */         if (other.hasOptions()) {
/*  3793 */           mergeOptions(other.getOptions());
/*       */         }
/*  3795 */         mergeUnknownFields(other.getUnknownFields());
/*  3796 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  3800 */         for (DescriptorProtos.EnumValueDescriptorProto element : getValueList()) {
/*  3801 */           if (!element.isInitialized()) return false;
/*       */         }
/*       */ 
/*  3804 */         return (!hasOptions()) || 
/*  3804 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  3813 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  3817 */           int tag = input.readTag();
/*  3818 */           switch (tag) {
/*       */           case 0:
/*  3820 */             setUnknownFields(unknownFields.build());
/*  3821 */             return this;
/*       */           default:
/*  3823 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  3825 */             setUnknownFields(unknownFields.build());
/*  3826 */             return this;
/*       */           case 10:
/*  3831 */             setName(input.readString());
/*  3832 */             break;
/*       */           case 18:
/*  3835 */             DescriptorProtos.EnumValueDescriptorProto.Builder subBuilder = DescriptorProtos.EnumValueDescriptorProto.newBuilder();
/*  3836 */             input.readMessage(subBuilder, extensionRegistry);
/*  3837 */             addValue(subBuilder.buildPartial());
/*  3838 */             break;
/*       */           case 26:
/*  3841 */             DescriptorProtos.EnumOptions.Builder subBuilder = DescriptorProtos.EnumOptions.newBuilder();
/*  3842 */             if (hasOptions()) {
/*  3843 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*  3845 */             input.readMessage(subBuilder, extensionRegistry);
/*  3846 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*  3858 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*  3861 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*  3864 */         if (value == null) {
/*  3865 */           throw new NullPointerException();
/*       */         }
/*  3867 */         this.hasName = true;
/*  3868 */         this.name_ = value;
/*  3869 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*  3872 */         this.hasName = false;
/*  3873 */         this.name_ = DescriptorProtos.EnumDescriptorProto.getDefaultInstance().getName();
/*  3874 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureValueIsMutable()
/*       */       {
/*  3882 */         if (!this.isValueMutable) {
/*  3883 */           this.value_ = new ArrayList(this.value_);
/*  3884 */           this.isValueMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.EnumValueDescriptorProto> getValueList() {
/*  3888 */         return Collections.unmodifiableList(this.value_);
/*       */       }
/*       */       public int getValueCount() {
/*  3891 */         return this.value_.size();
/*       */       }
/*       */       public DescriptorProtos.EnumValueDescriptorProto getValue(int index) {
/*  3894 */         return (DescriptorProtos.EnumValueDescriptorProto)this.value_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setValue(int index, DescriptorProtos.EnumValueDescriptorProto value) {
/*  3898 */         if (value == null) {
/*  3899 */           throw new NullPointerException();
/*       */         }
/*  3901 */         ensureValueIsMutable();
/*  3902 */         this.value_.set(index, value);
/*  3903 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setValue(int index, DescriptorProtos.EnumValueDescriptorProto.Builder builderForValue) {
/*  3907 */         ensureValueIsMutable();
/*  3908 */         this.value_.set(index, builderForValue.build());
/*  3909 */         return this;
/*       */       }
/*       */       public Builder addValue(DescriptorProtos.EnumValueDescriptorProto value) {
/*  3912 */         if (value == null) {
/*  3913 */           throw new NullPointerException();
/*       */         }
/*  3915 */         ensureValueIsMutable();
/*  3916 */         this.value_.add(value);
/*  3917 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addValue(DescriptorProtos.EnumValueDescriptorProto.Builder builderForValue) {
/*  3921 */         ensureValueIsMutable();
/*  3922 */         this.value_.add(builderForValue.build());
/*  3923 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllValue(Iterable<? extends DescriptorProtos.EnumValueDescriptorProto> values) {
/*  3927 */         ensureValueIsMutable();
/*  3928 */         GeneratedMessage.Builder.addAll(values, this.value_);
/*  3929 */         return this;
/*       */       }
/*       */       public Builder clearValue() {
/*  3932 */         this.value_ = Collections.emptyList();
/*  3933 */         this.isValueMutable = false;
/*  3934 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  3941 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.EnumOptions getOptions() {
/*  3944 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.EnumOptions value) {
/*  3947 */         if (value == null) {
/*  3948 */           throw new NullPointerException();
/*       */         }
/*  3950 */         this.hasOptions = true;
/*  3951 */         this.options_ = value;
/*  3952 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.EnumOptions.Builder builderForValue) {
/*  3956 */         this.hasOptions = true;
/*  3957 */         this.options_ = builderForValue.build();
/*  3958 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.EnumOptions value) {
/*  3961 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.EnumOptions.getDefaultInstance()))
/*       */         {
/*  3963 */           this.options_ = DescriptorProtos.EnumOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  3966 */           this.options_ = value;
/*       */         }
/*  3968 */         this.hasOptions = true;
/*  3969 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  3972 */         this.hasOptions = false;
/*  3973 */         this.options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
/*  3974 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class FieldDescriptorProto extends GeneratedMessage
/*       */   {
/*  3491 */     private static final FieldDescriptorProto defaultInstance = new FieldDescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int NUMBER_FIELD_NUMBER = 3;
/*       */     private boolean hasNumber;
/*       */     private int number_;
/*       */     public static final int LABEL_FIELD_NUMBER = 4;
/*       */     private boolean hasLabel;
/*       */     private Label label_;
/*       */     public static final int TYPE_FIELD_NUMBER = 5;
/*       */     private boolean hasType;
/*       */     private Type type_;
/*       */     public static final int TYPE_NAME_FIELD_NUMBER = 6;
/*       */     private boolean hasTypeName;
/*       */     private String typeName_;
/*       */     public static final int EXTENDEE_FIELD_NUMBER = 2;
/*       */     private boolean hasExtendee;
/*       */     private String extendee_;
/*       */     public static final int DEFAULT_VALUE_FIELD_NUMBER = 7;
/*       */     private boolean hasDefaultValue;
/*       */     private String defaultValue_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 8;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.FieldOptions options_;
/*  2953 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private FieldDescriptorProto(Builder builder)
/*       */     {
/*  2604 */       super();
/*       */     }
/*       */     private FieldDescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto getDefaultInstance() {
/*  2610 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public FieldDescriptorProto getDefaultInstanceForType() {
/*  2614 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  2619 */       return DescriptorProtos.internal_static_proto2_FieldDescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  2624 */       return DescriptorProtos.internal_static_proto2_FieldDescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*  2823 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*  2826 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public boolean hasNumber()
/*       */     {
/*  2834 */       return this.hasNumber;
/*       */     }
/*       */     public int getNumber() {
/*  2837 */       return this.number_;
/*       */     }
/*       */ 
/*       */     public boolean hasLabel()
/*       */     {
/*  2845 */       return this.hasLabel;
/*       */     }
/*       */     public Label getLabel() {
/*  2848 */       return this.label_;
/*       */     }
/*       */ 
/*       */     public boolean hasType()
/*       */     {
/*  2856 */       return this.hasType;
/*       */     }
/*       */     public Type getType() {
/*  2859 */       return this.type_;
/*       */     }
/*       */ 
/*       */     public boolean hasTypeName()
/*       */     {
/*  2867 */       return this.hasTypeName;
/*       */     }
/*       */     public String getTypeName() {
/*  2870 */       return this.typeName_;
/*       */     }
/*       */ 
/*       */     public boolean hasExtendee()
/*       */     {
/*  2878 */       return this.hasExtendee;
/*       */     }
/*       */     public String getExtendee() {
/*  2881 */       return this.extendee_;
/*       */     }
/*       */ 
/*       */     public boolean hasDefaultValue()
/*       */     {
/*  2889 */       return this.hasDefaultValue;
/*       */     }
/*       */     public String getDefaultValue() {
/*  2892 */       return this.defaultValue_;
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*  2900 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.FieldOptions getOptions() {
/*  2903 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  2907 */       this.name_ = "";
/*  2908 */       this.number_ = 0;
/*  2909 */       this.label_ = Label.LABEL_OPTIONAL;
/*  2910 */       this.type_ = Type.TYPE_DOUBLE;
/*  2911 */       this.typeName_ = "";
/*  2912 */       this.extendee_ = "";
/*  2913 */       this.defaultValue_ = "";
/*  2914 */       this.options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
/*       */     }
/*       */ 
/*       */     public final boolean isInitialized() {
/*  2918 */       return (!hasOptions()) || 
/*  2918 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  2925 */       getSerializedSize();
/*  2926 */       if (hasName()) {
/*  2927 */         output.writeString(1, getName());
/*       */       }
/*  2929 */       if (hasExtendee()) {
/*  2930 */         output.writeString(2, getExtendee());
/*       */       }
/*  2932 */       if (hasNumber()) {
/*  2933 */         output.writeInt32(3, getNumber());
/*       */       }
/*  2935 */       if (hasLabel()) {
/*  2936 */         output.writeEnum(4, getLabel().getNumber());
/*       */       }
/*  2938 */       if (hasType()) {
/*  2939 */         output.writeEnum(5, getType().getNumber());
/*       */       }
/*  2941 */       if (hasTypeName()) {
/*  2942 */         output.writeString(6, getTypeName());
/*       */       }
/*  2944 */       if (hasDefaultValue()) {
/*  2945 */         output.writeString(7, getDefaultValue());
/*       */       }
/*  2947 */       if (hasOptions()) {
/*  2948 */         output.writeMessage(8, getOptions());
/*       */       }
/*  2950 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  2955 */       int size = this.memoizedSerializedSize;
/*  2956 */       if (size != -1) return size;
/*       */ 
/*  2958 */       size = 0;
/*  2959 */       if (hasName()) {
/*  2960 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*  2963 */       if (hasExtendee()) {
/*  2964 */         size += CodedOutputStream.computeStringSize(2, getExtendee());
/*       */       }
/*       */ 
/*  2967 */       if (hasNumber()) {
/*  2968 */         size += CodedOutputStream.computeInt32Size(3, getNumber());
/*       */       }
/*       */ 
/*  2971 */       if (hasLabel()) {
/*  2972 */         size += CodedOutputStream.computeEnumSize(4, getLabel().getNumber());
/*       */       }
/*       */ 
/*  2975 */       if (hasType()) {
/*  2976 */         size += CodedOutputStream.computeEnumSize(5, getType().getNumber());
/*       */       }
/*       */ 
/*  2979 */       if (hasTypeName()) {
/*  2980 */         size += CodedOutputStream.computeStringSize(6, getTypeName());
/*       */       }
/*       */ 
/*  2983 */       if (hasDefaultValue()) {
/*  2984 */         size += CodedOutputStream.computeStringSize(7, getDefaultValue());
/*       */       }
/*       */ 
/*  2987 */       if (hasOptions()) {
/*  2988 */         size += CodedOutputStream.computeMessageSize(8, getOptions());
/*       */       }
/*       */ 
/*  2991 */       size += getUnknownFields().getSerializedSize();
/*  2992 */       this.memoizedSerializedSize = size;
/*  2993 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  2998 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  3004 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  3010 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  3015 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  3021 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*  3026 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  3032 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  3037 */       Builder builder = newBuilder();
/*  3038 */       if (builder.mergeDelimitedFrom(input)) {
/*  3039 */         return builder.buildParsed();
/*       */       }
/*  3041 */       return null;
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  3048 */       Builder builder = newBuilder();
/*  3049 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  3050 */         return builder.buildParsed();
/*       */       }
/*  3052 */       return null;
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  3058 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FieldDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  3064 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  3068 */       return Builder.access$4800(); } 
/*  3069 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(FieldDescriptorProto prototype) {
/*  3071 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  3073 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  3492 */       DescriptorProtos.internalForceInit();
/*  3493 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*  3291 */       private String name_ = "";
/*       */       private boolean hasNumber;
/*       */       private int number_;
/*       */       private boolean hasLabel;
/*  3334 */       private DescriptorProtos.FieldDescriptorProto.Label label_ = DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
/*       */       private boolean hasType;
/*  3357 */       private DescriptorProtos.FieldDescriptorProto.Type type_ = DescriptorProtos.FieldDescriptorProto.Type.TYPE_DOUBLE;
/*       */       private boolean hasTypeName;
/*  3380 */       private String typeName_ = "";
/*       */       private boolean hasExtendee;
/*  3403 */       private String extendee_ = "";
/*       */       private boolean hasDefaultValue;
/*  3426 */       private String defaultValue_ = "";
/*       */       private boolean hasOptions;
/*  3449 */       private DescriptorProtos.FieldOptions options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  3079 */         return DescriptorProtos.internal_static_proto2_FieldDescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  3084 */         return DescriptorProtos.internal_static_proto2_FieldDescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  3092 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  3096 */         super.clear();
/*  3097 */         this.name_ = "";
/*  3098 */         this.hasName = false;
/*  3099 */         this.number_ = 0;
/*  3100 */         this.hasNumber = false;
/*  3101 */         this.label_ = DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
/*  3102 */         this.hasLabel = false;
/*  3103 */         this.type_ = DescriptorProtos.FieldDescriptorProto.Type.TYPE_DOUBLE;
/*  3104 */         this.hasType = false;
/*  3105 */         this.typeName_ = "";
/*  3106 */         this.hasTypeName = false;
/*  3107 */         this.extendee_ = "";
/*  3108 */         this.hasExtendee = false;
/*  3109 */         this.defaultValue_ = "";
/*  3110 */         this.hasDefaultValue = false;
/*  3111 */         this.options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
/*  3112 */         this.hasOptions = false;
/*  3113 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  3117 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  3122 */         return DescriptorProtos.FieldDescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FieldDescriptorProto getDefaultInstanceForType() {
/*  3126 */         return DescriptorProtos.FieldDescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FieldDescriptorProto build() {
/*  3130 */         DescriptorProtos.FieldDescriptorProto result = buildPartial();
/*  3131 */         if (!result.isInitialized()) {
/*  3132 */           throw newUninitializedMessageException(result);
/*       */         }
/*  3134 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.FieldDescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  3139 */         DescriptorProtos.FieldDescriptorProto result = buildPartial();
/*  3140 */         if (!result.isInitialized()) {
/*  3141 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  3144 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FieldDescriptorProto buildPartial() {
/*  3148 */         DescriptorProtos.FieldDescriptorProto result = new DescriptorProtos.FieldDescriptorProto(this, null);
/*  3149 */         DescriptorProtos.FieldDescriptorProto.access$5002(result, this.hasName);
/*  3150 */         DescriptorProtos.FieldDescriptorProto.access$5102(result, this.name_);
/*  3151 */         DescriptorProtos.FieldDescriptorProto.access$5202(result, this.hasNumber);
/*  3152 */         DescriptorProtos.FieldDescriptorProto.access$5302(result, this.number_);
/*  3153 */         DescriptorProtos.FieldDescriptorProto.access$5402(result, this.hasLabel);
/*  3154 */         DescriptorProtos.FieldDescriptorProto.access$5502(result, this.label_);
/*  3155 */         DescriptorProtos.FieldDescriptorProto.access$5602(result, this.hasType);
/*  3156 */         DescriptorProtos.FieldDescriptorProto.access$5702(result, this.type_);
/*  3157 */         DescriptorProtos.FieldDescriptorProto.access$5802(result, this.hasTypeName);
/*  3158 */         DescriptorProtos.FieldDescriptorProto.access$5902(result, this.typeName_);
/*  3159 */         DescriptorProtos.FieldDescriptorProto.access$6002(result, this.hasExtendee);
/*  3160 */         DescriptorProtos.FieldDescriptorProto.access$6102(result, this.extendee_);
/*  3161 */         DescriptorProtos.FieldDescriptorProto.access$6202(result, this.hasDefaultValue);
/*  3162 */         DescriptorProtos.FieldDescriptorProto.access$6302(result, this.defaultValue_);
/*  3163 */         DescriptorProtos.FieldDescriptorProto.access$6402(result, this.hasOptions);
/*  3164 */         DescriptorProtos.FieldDescriptorProto.access$6502(result, this.options_);
/*  3165 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  3169 */         if ((other instanceof DescriptorProtos.FieldDescriptorProto)) {
/*  3170 */           return mergeFrom((DescriptorProtos.FieldDescriptorProto)other);
/*       */         }
/*  3172 */         super.mergeFrom(other);
/*  3173 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.FieldDescriptorProto other)
/*       */       {
/*  3178 */         if (other == DescriptorProtos.FieldDescriptorProto.getDefaultInstance()) return this;
/*  3179 */         if (other.hasName()) {
/*  3180 */           setName(other.getName());
/*       */         }
/*  3182 */         if (other.hasNumber()) {
/*  3183 */           setNumber(other.getNumber());
/*       */         }
/*  3185 */         if (other.hasLabel()) {
/*  3186 */           setLabel(other.getLabel());
/*       */         }
/*  3188 */         if (other.hasType()) {
/*  3189 */           setType(other.getType());
/*       */         }
/*  3191 */         if (other.hasTypeName()) {
/*  3192 */           setTypeName(other.getTypeName());
/*       */         }
/*  3194 */         if (other.hasExtendee()) {
/*  3195 */           setExtendee(other.getExtendee());
/*       */         }
/*  3197 */         if (other.hasDefaultValue()) {
/*  3198 */           setDefaultValue(other.getDefaultValue());
/*       */         }
/*  3200 */         if (other.hasOptions()) {
/*  3201 */           mergeOptions(other.getOptions());
/*       */         }
/*  3203 */         mergeUnknownFields(other.getUnknownFields());
/*  3204 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized()
/*       */       {
/*  3209 */         return (!hasOptions()) || 
/*  3209 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  3218 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  3222 */           int tag = input.readTag();
/*  3223 */           switch (tag) {
/*       */           case 0:
/*  3225 */             setUnknownFields(unknownFields.build());
/*  3226 */             return this;
/*       */           default:
/*  3228 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  3230 */             setUnknownFields(unknownFields.build());
/*  3231 */             return this;
/*       */           case 10:
/*  3236 */             setName(input.readString());
/*  3237 */             break;
/*       */           case 18:
/*  3240 */             setExtendee(input.readString());
/*  3241 */             break;
/*       */           case 24:
/*  3244 */             setNumber(input.readInt32());
/*  3245 */             break;
/*       */           case 32:
/*  3248 */             int rawValue = input.readEnum();
/*  3249 */             DescriptorProtos.FieldDescriptorProto.Label value = DescriptorProtos.FieldDescriptorProto.Label.valueOf(rawValue);
/*  3250 */             if (value == null)
/*  3251 */               unknownFields.mergeVarintField(4, rawValue);
/*       */             else {
/*  3253 */               setLabel(value);
/*       */             }
/*  3255 */             break;
/*       */           case 40:
/*  3258 */             int rawValue = input.readEnum();
/*  3259 */             DescriptorProtos.FieldDescriptorProto.Type value = DescriptorProtos.FieldDescriptorProto.Type.valueOf(rawValue);
/*  3260 */             if (value == null)
/*  3261 */               unknownFields.mergeVarintField(5, rawValue);
/*       */             else {
/*  3263 */               setType(value);
/*       */             }
/*  3265 */             break;
/*       */           case 50:
/*  3268 */             setTypeName(input.readString());
/*  3269 */             break;
/*       */           case 58:
/*  3272 */             setDefaultValue(input.readString());
/*  3273 */             break;
/*       */           case 66:
/*  3276 */             DescriptorProtos.FieldOptions.Builder subBuilder = DescriptorProtos.FieldOptions.newBuilder();
/*  3277 */             if (hasOptions()) {
/*  3278 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*  3280 */             input.readMessage(subBuilder, extensionRegistry);
/*  3281 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*  3293 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*  3296 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*  3299 */         if (value == null) {
/*  3300 */           throw new NullPointerException();
/*       */         }
/*  3302 */         this.hasName = true;
/*  3303 */         this.name_ = value;
/*  3304 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*  3307 */         this.hasName = false;
/*  3308 */         this.name_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getName();
/*  3309 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasNumber()
/*       */       {
/*  3316 */         return this.hasNumber;
/*       */       }
/*       */       public int getNumber() {
/*  3319 */         return this.number_;
/*       */       }
/*       */       public Builder setNumber(int value) {
/*  3322 */         this.hasNumber = true;
/*  3323 */         this.number_ = value;
/*  3324 */         return this;
/*       */       }
/*       */       public Builder clearNumber() {
/*  3327 */         this.hasNumber = false;
/*  3328 */         this.number_ = 0;
/*  3329 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasLabel()
/*       */       {
/*  3336 */         return this.hasLabel;
/*       */       }
/*       */       public DescriptorProtos.FieldDescriptorProto.Label getLabel() {
/*  3339 */         return this.label_;
/*       */       }
/*       */       public Builder setLabel(DescriptorProtos.FieldDescriptorProto.Label value) {
/*  3342 */         if (value == null) {
/*  3343 */           throw new NullPointerException();
/*       */         }
/*  3345 */         this.hasLabel = true;
/*  3346 */         this.label_ = value;
/*  3347 */         return this;
/*       */       }
/*       */       public Builder clearLabel() {
/*  3350 */         this.hasLabel = false;
/*  3351 */         this.label_ = DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
/*  3352 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasType()
/*       */       {
/*  3359 */         return this.hasType;
/*       */       }
/*       */       public DescriptorProtos.FieldDescriptorProto.Type getType() {
/*  3362 */         return this.type_;
/*       */       }
/*       */       public Builder setType(DescriptorProtos.FieldDescriptorProto.Type value) {
/*  3365 */         if (value == null) {
/*  3366 */           throw new NullPointerException();
/*       */         }
/*  3368 */         this.hasType = true;
/*  3369 */         this.type_ = value;
/*  3370 */         return this;
/*       */       }
/*       */       public Builder clearType() {
/*  3373 */         this.hasType = false;
/*  3374 */         this.type_ = DescriptorProtos.FieldDescriptorProto.Type.TYPE_DOUBLE;
/*  3375 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasTypeName()
/*       */       {
/*  3382 */         return this.hasTypeName;
/*       */       }
/*       */       public String getTypeName() {
/*  3385 */         return this.typeName_;
/*       */       }
/*       */       public Builder setTypeName(String value) {
/*  3388 */         if (value == null) {
/*  3389 */           throw new NullPointerException();
/*       */         }
/*  3391 */         this.hasTypeName = true;
/*  3392 */         this.typeName_ = value;
/*  3393 */         return this;
/*       */       }
/*       */       public Builder clearTypeName() {
/*  3396 */         this.hasTypeName = false;
/*  3397 */         this.typeName_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getTypeName();
/*  3398 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasExtendee()
/*       */       {
/*  3405 */         return this.hasExtendee;
/*       */       }
/*       */       public String getExtendee() {
/*  3408 */         return this.extendee_;
/*       */       }
/*       */       public Builder setExtendee(String value) {
/*  3411 */         if (value == null) {
/*  3412 */           throw new NullPointerException();
/*       */         }
/*  3414 */         this.hasExtendee = true;
/*  3415 */         this.extendee_ = value;
/*  3416 */         return this;
/*       */       }
/*       */       public Builder clearExtendee() {
/*  3419 */         this.hasExtendee = false;
/*  3420 */         this.extendee_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getExtendee();
/*  3421 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasDefaultValue()
/*       */       {
/*  3428 */         return this.hasDefaultValue;
/*       */       }
/*       */       public String getDefaultValue() {
/*  3431 */         return this.defaultValue_;
/*       */       }
/*       */       public Builder setDefaultValue(String value) {
/*  3434 */         if (value == null) {
/*  3435 */           throw new NullPointerException();
/*       */         }
/*  3437 */         this.hasDefaultValue = true;
/*  3438 */         this.defaultValue_ = value;
/*  3439 */         return this;
/*       */       }
/*       */       public Builder clearDefaultValue() {
/*  3442 */         this.hasDefaultValue = false;
/*  3443 */         this.defaultValue_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getDefaultValue();
/*  3444 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  3451 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.FieldOptions getOptions() {
/*  3454 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.FieldOptions value) {
/*  3457 */         if (value == null) {
/*  3458 */           throw new NullPointerException();
/*       */         }
/*  3460 */         this.hasOptions = true;
/*  3461 */         this.options_ = value;
/*  3462 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.FieldOptions.Builder builderForValue) {
/*  3466 */         this.hasOptions = true;
/*  3467 */         this.options_ = builderForValue.build();
/*  3468 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.FieldOptions value) {
/*  3471 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.FieldOptions.getDefaultInstance()))
/*       */         {
/*  3473 */           this.options_ = DescriptorProtos.FieldOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  3476 */           this.options_ = value;
/*       */         }
/*  3478 */         this.hasOptions = true;
/*  3479 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  3482 */         this.hasOptions = false;
/*  3483 */         this.options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
/*  3484 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum Label
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  2747 */       LABEL_OPTIONAL(0, 1), 
/*  2748 */       LABEL_REQUIRED(1, 2), 
/*  2749 */       LABEL_REPEATED(2, 3);
/*       */ 
/*       */       public static final int LABEL_OPTIONAL_VALUE = 1;
/*       */       public static final int LABEL_REQUIRED_VALUE = 2;
/*       */       public static final int LABEL_REPEATED_VALUE = 3;
/*       */       private static Internal.EnumLiteMap<Label> internalValueMap;
/*       */       private static final Label[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  2757 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static Label valueOf(int value) {
/*  2760 */         switch (value) { case 1:
/*  2761 */           return LABEL_OPTIONAL;
/*       */         case 2:
/*  2762 */           return LABEL_REQUIRED;
/*       */         case 3:
/*  2763 */           return LABEL_REPEATED; }
/*  2764 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<Label> internalGetValueMap()
/*       */       {
/*  2770 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  2782 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  2786 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  2790 */         return (Descriptors.EnumDescriptor)DescriptorProtos.FieldDescriptorProto.getDescriptor().getEnumTypes().get(1);
/*       */       }
/*       */ 
/*       */       public static Label valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  2798 */         if (desc.getType() != getDescriptor()) {
/*  2799 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  2802 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private Label(int index, int value)
/*       */       {
/*  2807 */         this.index = index;
/*  2808 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  2773 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.FieldDescriptorProto.Label findValueByNumber(int number) {
/*  2776 */             return DescriptorProtos.FieldDescriptorProto.Label.valueOf(number);
/*       */           }
/*       */         };
/*  2793 */         VALUES = new Label[] { LABEL_OPTIONAL, LABEL_REQUIRED, LABEL_REPEATED };
/*       */ 
/*  2812 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum Type
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  2629 */       TYPE_DOUBLE(0, 1), 
/*  2630 */       TYPE_FLOAT(1, 2), 
/*  2631 */       TYPE_INT64(2, 3), 
/*  2632 */       TYPE_UINT64(3, 4), 
/*  2633 */       TYPE_INT32(4, 5), 
/*  2634 */       TYPE_FIXED64(5, 6), 
/*  2635 */       TYPE_FIXED32(6, 7), 
/*  2636 */       TYPE_BOOL(7, 8), 
/*  2637 */       TYPE_STRING(8, 9), 
/*  2638 */       TYPE_GROUP(9, 10), 
/*  2639 */       TYPE_MESSAGE(10, 11), 
/*  2640 */       TYPE_BYTES(11, 12), 
/*  2641 */       TYPE_UINT32(12, 13), 
/*  2642 */       TYPE_ENUM(13, 14), 
/*  2643 */       TYPE_SFIXED32(14, 15), 
/*  2644 */       TYPE_SFIXED64(15, 16), 
/*  2645 */       TYPE_SINT32(16, 17), 
/*  2646 */       TYPE_SINT64(17, 18);
/*       */ 
/*       */       public static final int TYPE_DOUBLE_VALUE = 1;
/*       */       public static final int TYPE_FLOAT_VALUE = 2;
/*       */       public static final int TYPE_INT64_VALUE = 3;
/*       */       public static final int TYPE_UINT64_VALUE = 4;
/*       */       public static final int TYPE_INT32_VALUE = 5;
/*       */       public static final int TYPE_FIXED64_VALUE = 6;
/*       */       public static final int TYPE_FIXED32_VALUE = 7;
/*       */       public static final int TYPE_BOOL_VALUE = 8;
/*       */       public static final int TYPE_STRING_VALUE = 9;
/*       */       public static final int TYPE_GROUP_VALUE = 10;
/*       */       public static final int TYPE_MESSAGE_VALUE = 11;
/*       */       public static final int TYPE_BYTES_VALUE = 12;
/*       */       public static final int TYPE_UINT32_VALUE = 13;
/*       */       public static final int TYPE_ENUM_VALUE = 14;
/*       */       public static final int TYPE_SFIXED32_VALUE = 15;
/*       */       public static final int TYPE_SFIXED64_VALUE = 16;
/*       */       public static final int TYPE_SINT32_VALUE = 17;
/*       */       public static final int TYPE_SINT64_VALUE = 18;
/*       */       private static Internal.EnumLiteMap<Type> internalValueMap;
/*       */       private static final Type[] VALUES;
/*       */       private final int index;
/*       */       private final int value;
/*       */ 
/*  2669 */       public final int getNumber() { return this.value; }
/*       */ 
/*       */       public static Type valueOf(int value) {
/*  2672 */         switch (value) { case 1:
/*  2673 */           return TYPE_DOUBLE;
/*       */         case 2:
/*  2674 */           return TYPE_FLOAT;
/*       */         case 3:
/*  2675 */           return TYPE_INT64;
/*       */         case 4:
/*  2676 */           return TYPE_UINT64;
/*       */         case 5:
/*  2677 */           return TYPE_INT32;
/*       */         case 6:
/*  2678 */           return TYPE_FIXED64;
/*       */         case 7:
/*  2679 */           return TYPE_FIXED32;
/*       */         case 8:
/*  2680 */           return TYPE_BOOL;
/*       */         case 9:
/*  2681 */           return TYPE_STRING;
/*       */         case 10:
/*  2682 */           return TYPE_GROUP;
/*       */         case 11:
/*  2683 */           return TYPE_MESSAGE;
/*       */         case 12:
/*  2684 */           return TYPE_BYTES;
/*       */         case 13:
/*  2685 */           return TYPE_UINT32;
/*       */         case 14:
/*  2686 */           return TYPE_ENUM;
/*       */         case 15:
/*  2687 */           return TYPE_SFIXED32;
/*       */         case 16:
/*  2688 */           return TYPE_SFIXED64;
/*       */         case 17:
/*  2689 */           return TYPE_SINT32;
/*       */         case 18:
/*  2690 */           return TYPE_SINT64; }
/*  2691 */         return null;
/*       */       }
/*       */ 
/*       */       public static Internal.EnumLiteMap<Type> internalGetValueMap()
/*       */       {
/*  2697 */         return internalValueMap;
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*       */       {
/*  2709 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*       */       }
/*       */ 
/*       */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  2713 */         return getDescriptor();
/*       */       }
/*       */ 
/*       */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  2717 */         return (Descriptors.EnumDescriptor)DescriptorProtos.FieldDescriptorProto.getDescriptor().getEnumTypes().get(0);
/*       */       }
/*       */ 
/*       */       public static Type valueOf(Descriptors.EnumValueDescriptor desc)
/*       */       {
/*  2725 */         if (desc.getType() != getDescriptor()) {
/*  2726 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*       */         }
/*       */ 
/*  2729 */         return VALUES[desc.getIndex()];
/*       */       }
/*       */ 
/*       */       private Type(int index, int value)
/*       */       {
/*  2734 */         this.index = index;
/*  2735 */         this.value = value;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  2700 */         internalValueMap = new Internal.EnumLiteMap()
/*       */         {
/*       */           public DescriptorProtos.FieldDescriptorProto.Type findValueByNumber(int number) {
/*  2703 */             return DescriptorProtos.FieldDescriptorProto.Type.valueOf(number);
/*       */           }
/*       */         };
/*  2720 */         VALUES = new Type[] { TYPE_DOUBLE, TYPE_FLOAT, TYPE_INT64, TYPE_UINT64, TYPE_INT32, TYPE_FIXED64, TYPE_FIXED32, TYPE_BOOL, TYPE_STRING, TYPE_GROUP, TYPE_MESSAGE, TYPE_BYTES, TYPE_UINT32, TYPE_ENUM, TYPE_SFIXED32, TYPE_SFIXED64, TYPE_SINT32, TYPE_SINT64 };
/*       */ 
/*  2739 */         DescriptorProtos.getDescriptor();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class DescriptorProto extends GeneratedMessage
/*       */   {
/*  2592 */     private static final DescriptorProto defaultInstance = new DescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int FIELD_FIELD_NUMBER = 2;
/*       */     private List<DescriptorProtos.FieldDescriptorProto> field_;
/*       */     public static final int EXTENSION_FIELD_NUMBER = 6;
/*       */     private List<DescriptorProtos.FieldDescriptorProto> extension_;
/*       */     public static final int NESTED_TYPE_FIELD_NUMBER = 3;
/*       */     private List<DescriptorProto> nestedType_;
/*       */     public static final int ENUM_TYPE_FIELD_NUMBER = 4;
/*       */     private List<DescriptorProtos.EnumDescriptorProto> enumType_;
/*       */     public static final int EXTENSION_RANGE_FIELD_NUMBER = 5;
/*       */     private List<ExtensionRange> extensionRange_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 7;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.MessageOptions options_;
/*  1849 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private DescriptorProto(Builder builder)
/*       */     {
/*  1337 */       super();
/*       */     }
/*       */     private DescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static DescriptorProto getDefaultInstance() {
/*  1343 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public DescriptorProto getDefaultInstanceForType() {
/*  1347 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*  1352 */       return DescriptorProtos.internal_static_proto2_DescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*  1357 */       return DescriptorProtos.internal_static_proto2_DescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*  1712 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*  1715 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.FieldDescriptorProto> getFieldList()
/*       */     {
/*  1722 */       return this.field_;
/*       */     }
/*       */     public int getFieldCount() {
/*  1725 */       return this.field_.size();
/*       */     }
/*       */     public DescriptorProtos.FieldDescriptorProto getField(int index) {
/*  1728 */       return (DescriptorProtos.FieldDescriptorProto)this.field_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.FieldDescriptorProto> getExtensionList()
/*       */     {
/*  1735 */       return this.extension_;
/*       */     }
/*       */     public int getExtensionCount() {
/*  1738 */       return this.extension_.size();
/*       */     }
/*       */     public DescriptorProtos.FieldDescriptorProto getExtension(int index) {
/*  1741 */       return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProto> getNestedTypeList()
/*       */     {
/*  1748 */       return this.nestedType_;
/*       */     }
/*       */     public int getNestedTypeCount() {
/*  1751 */       return this.nestedType_.size();
/*       */     }
/*       */     public DescriptorProto getNestedType(int index) {
/*  1754 */       return (DescriptorProto)this.nestedType_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList()
/*       */     {
/*  1761 */       return this.enumType_;
/*       */     }
/*       */     public int getEnumTypeCount() {
/*  1764 */       return this.enumType_.size();
/*       */     }
/*       */     public DescriptorProtos.EnumDescriptorProto getEnumType(int index) {
/*  1767 */       return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
/*       */     }
/*       */ 
/*       */     public List<ExtensionRange> getExtensionRangeList()
/*       */     {
/*  1774 */       return this.extensionRange_;
/*       */     }
/*       */     public int getExtensionRangeCount() {
/*  1777 */       return this.extensionRange_.size();
/*       */     }
/*       */     public ExtensionRange getExtensionRange(int index) {
/*  1780 */       return (ExtensionRange)this.extensionRange_.get(index);
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*  1788 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.MessageOptions getOptions() {
/*  1791 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*  1795 */       this.name_ = "";
/*  1796 */       this.field_ = Collections.emptyList();
/*  1797 */       this.extension_ = Collections.emptyList();
/*  1798 */       this.nestedType_ = Collections.emptyList();
/*  1799 */       this.enumType_ = Collections.emptyList();
/*  1800 */       this.extensionRange_ = Collections.emptyList();
/*  1801 */       this.options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
/*       */     }
/*       */     public final boolean isInitialized() {
/*  1804 */       for (DescriptorProtos.FieldDescriptorProto element : getFieldList()) {
/*  1805 */         if (!element.isInitialized()) return false;
/*       */       }
/*  1807 */       for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*  1808 */         if (!element.isInitialized()) return false;
/*       */       }
/*  1810 */       for (DescriptorProto element : getNestedTypeList()) {
/*  1811 */         if (!element.isInitialized()) return false;
/*       */       }
/*  1813 */       for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*  1814 */         if (!element.isInitialized()) return false;
/*       */       }
/*       */ 
/*  1817 */       return (!hasOptions()) || 
/*  1817 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*  1824 */       getSerializedSize();
/*  1825 */       if (hasName()) {
/*  1826 */         output.writeString(1, getName());
/*       */       }
/*  1828 */       for (DescriptorProtos.FieldDescriptorProto element : getFieldList()) {
/*  1829 */         output.writeMessage(2, element);
/*       */       }
/*  1831 */       for (DescriptorProto element : getNestedTypeList()) {
/*  1832 */         output.writeMessage(3, element);
/*       */       }
/*  1834 */       for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*  1835 */         output.writeMessage(4, element);
/*       */       }
/*  1837 */       for (ExtensionRange element : getExtensionRangeList()) {
/*  1838 */         output.writeMessage(5, element);
/*       */       }
/*  1840 */       for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*  1841 */         output.writeMessage(6, element);
/*       */       }
/*  1843 */       if (hasOptions()) {
/*  1844 */         output.writeMessage(7, getOptions());
/*       */       }
/*  1846 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*  1851 */       int size = this.memoizedSerializedSize;
/*  1852 */       if (size != -1) return size;
/*       */ 
/*  1854 */       size = 0;
/*  1855 */       if (hasName()) {
/*  1856 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*  1859 */       for (DescriptorProtos.FieldDescriptorProto element : getFieldList()) {
/*  1860 */         size += CodedOutputStream.computeMessageSize(2, element);
/*       */       }
/*       */ 
/*  1863 */       for (DescriptorProto element : getNestedTypeList()) {
/*  1864 */         size += CodedOutputStream.computeMessageSize(3, element);
/*       */       }
/*       */ 
/*  1867 */       for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*  1868 */         size += CodedOutputStream.computeMessageSize(4, element);
/*       */       }
/*       */ 
/*  1871 */       for (ExtensionRange element : getExtensionRangeList()) {
/*  1872 */         size += CodedOutputStream.computeMessageSize(5, element);
/*       */       }
/*       */ 
/*  1875 */       for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*  1876 */         size += CodedOutputStream.computeMessageSize(6, element);
/*       */       }
/*       */ 
/*  1879 */       if (hasOptions()) {
/*  1880 */         size += CodedOutputStream.computeMessageSize(7, getOptions());
/*       */       }
/*       */ 
/*  1883 */       size += getUnknownFields().getSerializedSize();
/*  1884 */       this.memoizedSerializedSize = size;
/*  1885 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*  1890 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  1896 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  1902 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*  1907 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*  1913 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*  1918 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  1924 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*  1929 */       Builder builder = newBuilder();
/*  1930 */       if (builder.mergeDelimitedFrom(input)) {
/*  1931 */         return builder.buildParsed();
/*       */       }
/*  1933 */       return null;
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  1940 */       Builder builder = newBuilder();
/*  1941 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  1942 */         return builder.buildParsed();
/*       */       }
/*  1944 */       return null;
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*  1950 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static DescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*  1956 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*  1960 */       return Builder.access$3400(); } 
/*  1961 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(DescriptorProto prototype) {
/*  1963 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*  1965 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  2593 */       DescriptorProtos.internalForceInit();
/*  2594 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*  2227 */       private String name_ = "";
/*       */ 
/*  2249 */       private List<DescriptorProtos.FieldDescriptorProto> field_ = Collections.emptyList();
/*       */       private boolean isFieldMutable;
/*  2309 */       private List<DescriptorProtos.FieldDescriptorProto> extension_ = Collections.emptyList();
/*       */       private boolean isExtensionMutable;
/*  2369 */       private List<DescriptorProtos.DescriptorProto> nestedType_ = Collections.emptyList();
/*       */       private boolean isNestedTypeMutable;
/*  2429 */       private List<DescriptorProtos.EnumDescriptorProto> enumType_ = Collections.emptyList();
/*       */       private boolean isEnumTypeMutable;
/*  2489 */       private List<DescriptorProtos.DescriptorProto.ExtensionRange> extensionRange_ = Collections.emptyList();
/*       */       private boolean isExtensionRangeMutable;
/*       */       private boolean hasOptions;
/*  2550 */       private DescriptorProtos.MessageOptions options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  1971 */         return DescriptorProtos.internal_static_proto2_DescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  1976 */         return DescriptorProtos.internal_static_proto2_DescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*  1984 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*  1988 */         super.clear();
/*  1989 */         this.name_ = "";
/*  1990 */         this.hasName = false;
/*  1991 */         this.field_ = Collections.emptyList();
/*  1992 */         this.isFieldMutable = false;
/*  1993 */         this.extension_ = Collections.emptyList();
/*  1994 */         this.isExtensionMutable = false;
/*  1995 */         this.nestedType_ = Collections.emptyList();
/*  1996 */         this.isNestedTypeMutable = false;
/*  1997 */         this.enumType_ = Collections.emptyList();
/*  1998 */         this.isEnumTypeMutable = false;
/*  1999 */         this.extensionRange_ = Collections.emptyList();
/*  2000 */         this.isExtensionRangeMutable = false;
/*  2001 */         this.options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
/*  2002 */         this.hasOptions = false;
/*  2003 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*  2007 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*  2012 */         return DescriptorProtos.DescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.DescriptorProto getDefaultInstanceForType() {
/*  2016 */         return DescriptorProtos.DescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.DescriptorProto build() {
/*  2020 */         DescriptorProtos.DescriptorProto result = buildPartial();
/*  2021 */         if (!result.isInitialized()) {
/*  2022 */           throw newUninitializedMessageException(result);
/*       */         }
/*  2024 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.DescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*  2029 */         DescriptorProtos.DescriptorProto result = buildPartial();
/*  2030 */         if (!result.isInitialized()) {
/*  2031 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*  2034 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.DescriptorProto buildPartial() {
/*  2038 */         DescriptorProtos.DescriptorProto result = new DescriptorProtos.DescriptorProto(this, null);
/*  2039 */         DescriptorProtos.DescriptorProto.access$3602(result, this.hasName);
/*  2040 */         DescriptorProtos.DescriptorProto.access$3702(result, this.name_);
/*  2041 */         if (this.isFieldMutable) {
/*  2042 */           this.field_ = Collections.unmodifiableList(this.field_);
/*  2043 */           this.isFieldMutable = false;
/*       */         }
/*  2045 */         DescriptorProtos.DescriptorProto.access$3802(result, this.field_);
/*  2046 */         if (this.isExtensionMutable) {
/*  2047 */           this.extension_ = Collections.unmodifiableList(this.extension_);
/*  2048 */           this.isExtensionMutable = false;
/*       */         }
/*  2050 */         DescriptorProtos.DescriptorProto.access$3902(result, this.extension_);
/*  2051 */         if (this.isNestedTypeMutable) {
/*  2052 */           this.nestedType_ = Collections.unmodifiableList(this.nestedType_);
/*  2053 */           this.isNestedTypeMutable = false;
/*       */         }
/*  2055 */         DescriptorProtos.DescriptorProto.access$4002(result, this.nestedType_);
/*  2056 */         if (this.isEnumTypeMutable) {
/*  2057 */           this.enumType_ = Collections.unmodifiableList(this.enumType_);
/*  2058 */           this.isEnumTypeMutable = false;
/*       */         }
/*  2060 */         DescriptorProtos.DescriptorProto.access$4102(result, this.enumType_);
/*  2061 */         if (this.isExtensionRangeMutable) {
/*  2062 */           this.extensionRange_ = Collections.unmodifiableList(this.extensionRange_);
/*  2063 */           this.isExtensionRangeMutable = false;
/*       */         }
/*  2065 */         DescriptorProtos.DescriptorProto.access$4202(result, this.extensionRange_);
/*  2066 */         DescriptorProtos.DescriptorProto.access$4302(result, this.hasOptions);
/*  2067 */         DescriptorProtos.DescriptorProto.access$4402(result, this.options_);
/*  2068 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*  2072 */         if ((other instanceof DescriptorProtos.DescriptorProto)) {
/*  2073 */           return mergeFrom((DescriptorProtos.DescriptorProto)other);
/*       */         }
/*  2075 */         super.mergeFrom(other);
/*  2076 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.DescriptorProto other)
/*       */       {
/*  2081 */         if (other == DescriptorProtos.DescriptorProto.getDefaultInstance()) return this;
/*  2082 */         if (other.hasName()) {
/*  2083 */           setName(other.getName());
/*       */         }
/*  2085 */         if (!other.field_.isEmpty()) {
/*  2086 */           if (this.field_.isEmpty()) {
/*  2087 */             this.field_ = other.field_;
/*  2088 */             this.isFieldMutable = false;
/*       */           } else {
/*  2090 */             ensureFieldIsMutable();
/*  2091 */             this.field_.addAll(other.field_);
/*       */           }
/*       */         }
/*  2094 */         if (!other.extension_.isEmpty()) {
/*  2095 */           if (this.extension_.isEmpty()) {
/*  2096 */             this.extension_ = other.extension_;
/*  2097 */             this.isExtensionMutable = false;
/*       */           } else {
/*  2099 */             ensureExtensionIsMutable();
/*  2100 */             this.extension_.addAll(other.extension_);
/*       */           }
/*       */         }
/*  2103 */         if (!other.nestedType_.isEmpty()) {
/*  2104 */           if (this.nestedType_.isEmpty()) {
/*  2105 */             this.nestedType_ = other.nestedType_;
/*  2106 */             this.isNestedTypeMutable = false;
/*       */           } else {
/*  2108 */             ensureNestedTypeIsMutable();
/*  2109 */             this.nestedType_.addAll(other.nestedType_);
/*       */           }
/*       */         }
/*  2112 */         if (!other.enumType_.isEmpty()) {
/*  2113 */           if (this.enumType_.isEmpty()) {
/*  2114 */             this.enumType_ = other.enumType_;
/*  2115 */             this.isEnumTypeMutable = false;
/*       */           } else {
/*  2117 */             ensureEnumTypeIsMutable();
/*  2118 */             this.enumType_.addAll(other.enumType_);
/*       */           }
/*       */         }
/*  2121 */         if (!other.extensionRange_.isEmpty()) {
/*  2122 */           if (this.extensionRange_.isEmpty()) {
/*  2123 */             this.extensionRange_ = other.extensionRange_;
/*  2124 */             this.isExtensionRangeMutable = false;
/*       */           } else {
/*  2126 */             ensureExtensionRangeIsMutable();
/*  2127 */             this.extensionRange_.addAll(other.extensionRange_);
/*       */           }
/*       */         }
/*  2130 */         if (other.hasOptions()) {
/*  2131 */           mergeOptions(other.getOptions());
/*       */         }
/*  2133 */         mergeUnknownFields(other.getUnknownFields());
/*  2134 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*  2138 */         for (DescriptorProtos.FieldDescriptorProto element : getFieldList()) {
/*  2139 */           if (!element.isInitialized()) return false;
/*       */         }
/*  2141 */         for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*  2142 */           if (!element.isInitialized()) return false;
/*       */         }
/*  2144 */         for (DescriptorProtos.DescriptorProto element : getNestedTypeList()) {
/*  2145 */           if (!element.isInitialized()) return false;
/*       */         }
/*  2147 */         for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*  2148 */           if (!element.isInitialized()) return false;
/*       */         }
/*       */ 
/*  2151 */         return (!hasOptions()) || 
/*  2151 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  2160 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*  2164 */           int tag = input.readTag();
/*  2165 */           switch (tag) {
/*       */           case 0:
/*  2167 */             setUnknownFields(unknownFields.build());
/*  2168 */             return this;
/*       */           default:
/*  2170 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*  2172 */             setUnknownFields(unknownFields.build());
/*  2173 */             return this;
/*       */           case 10:
/*  2178 */             setName(input.readString());
/*  2179 */             break;
/*       */           case 18:
/*  2182 */             DescriptorProtos.FieldDescriptorProto.Builder subBuilder = DescriptorProtos.FieldDescriptorProto.newBuilder();
/*  2183 */             input.readMessage(subBuilder, extensionRegistry);
/*  2184 */             addField(subBuilder.buildPartial());
/*  2185 */             break;
/*       */           case 26:
/*  2188 */             Builder subBuilder = DescriptorProtos.DescriptorProto.newBuilder();
/*  2189 */             input.readMessage(subBuilder, extensionRegistry);
/*  2190 */             addNestedType(subBuilder.buildPartial());
/*  2191 */             break;
/*       */           case 34:
/*  2194 */             DescriptorProtos.EnumDescriptorProto.Builder subBuilder = DescriptorProtos.EnumDescriptorProto.newBuilder();
/*  2195 */             input.readMessage(subBuilder, extensionRegistry);
/*  2196 */             addEnumType(subBuilder.buildPartial());
/*  2197 */             break;
/*       */           case 42:
/*  2200 */             DescriptorProtos.DescriptorProto.ExtensionRange.Builder subBuilder = DescriptorProtos.DescriptorProto.ExtensionRange.newBuilder();
/*  2201 */             input.readMessage(subBuilder, extensionRegistry);
/*  2202 */             addExtensionRange(subBuilder.buildPartial());
/*  2203 */             break;
/*       */           case 50:
/*  2206 */             DescriptorProtos.FieldDescriptorProto.Builder subBuilder = DescriptorProtos.FieldDescriptorProto.newBuilder();
/*  2207 */             input.readMessage(subBuilder, extensionRegistry);
/*  2208 */             addExtension(subBuilder.buildPartial());
/*  2209 */             break;
/*       */           case 58:
/*  2212 */             DescriptorProtos.MessageOptions.Builder subBuilder = DescriptorProtos.MessageOptions.newBuilder();
/*  2213 */             if (hasOptions()) {
/*  2214 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*  2216 */             input.readMessage(subBuilder, extensionRegistry);
/*  2217 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*  2229 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*  2232 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*  2235 */         if (value == null) {
/*  2236 */           throw new NullPointerException();
/*       */         }
/*  2238 */         this.hasName = true;
/*  2239 */         this.name_ = value;
/*  2240 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*  2243 */         this.hasName = false;
/*  2244 */         this.name_ = DescriptorProtos.DescriptorProto.getDefaultInstance().getName();
/*  2245 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureFieldIsMutable()
/*       */       {
/*  2253 */         if (!this.isFieldMutable) {
/*  2254 */           this.field_ = new ArrayList(this.field_);
/*  2255 */           this.isFieldMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.FieldDescriptorProto> getFieldList() {
/*  2259 */         return Collections.unmodifiableList(this.field_);
/*       */       }
/*       */       public int getFieldCount() {
/*  2262 */         return this.field_.size();
/*       */       }
/*       */       public DescriptorProtos.FieldDescriptorProto getField(int index) {
/*  2265 */         return (DescriptorProtos.FieldDescriptorProto)this.field_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setField(int index, DescriptorProtos.FieldDescriptorProto value) {
/*  2269 */         if (value == null) {
/*  2270 */           throw new NullPointerException();
/*       */         }
/*  2272 */         ensureFieldIsMutable();
/*  2273 */         this.field_.set(index, value);
/*  2274 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setField(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue) {
/*  2278 */         ensureFieldIsMutable();
/*  2279 */         this.field_.set(index, builderForValue.build());
/*  2280 */         return this;
/*       */       }
/*       */       public Builder addField(DescriptorProtos.FieldDescriptorProto value) {
/*  2283 */         if (value == null) {
/*  2284 */           throw new NullPointerException();
/*       */         }
/*  2286 */         ensureFieldIsMutable();
/*  2287 */         this.field_.add(value);
/*  2288 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addField(DescriptorProtos.FieldDescriptorProto.Builder builderForValue) {
/*  2292 */         ensureFieldIsMutable();
/*  2293 */         this.field_.add(builderForValue.build());
/*  2294 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllField(Iterable<? extends DescriptorProtos.FieldDescriptorProto> values) {
/*  2298 */         ensureFieldIsMutable();
/*  2299 */         GeneratedMessage.Builder.addAll(values, this.field_);
/*  2300 */         return this;
/*       */       }
/*       */       public Builder clearField() {
/*  2303 */         this.field_ = Collections.emptyList();
/*  2304 */         this.isFieldMutable = false;
/*  2305 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureExtensionIsMutable()
/*       */       {
/*  2313 */         if (!this.isExtensionMutable) {
/*  2314 */           this.extension_ = new ArrayList(this.extension_);
/*  2315 */           this.isExtensionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.FieldDescriptorProto> getExtensionList() {
/*  2319 */         return Collections.unmodifiableList(this.extension_);
/*       */       }
/*       */       public int getExtensionCount() {
/*  2322 */         return this.extension_.size();
/*       */       }
/*       */       public DescriptorProtos.FieldDescriptorProto getExtension(int index) {
/*  2325 */         return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto value) {
/*  2329 */         if (value == null) {
/*  2330 */           throw new NullPointerException();
/*       */         }
/*  2332 */         ensureExtensionIsMutable();
/*  2333 */         this.extension_.set(index, value);
/*  2334 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue) {
/*  2338 */         ensureExtensionIsMutable();
/*  2339 */         this.extension_.set(index, builderForValue.build());
/*  2340 */         return this;
/*       */       }
/*       */       public Builder addExtension(DescriptorProtos.FieldDescriptorProto value) {
/*  2343 */         if (value == null) {
/*  2344 */           throw new NullPointerException();
/*       */         }
/*  2346 */         ensureExtensionIsMutable();
/*  2347 */         this.extension_.add(value);
/*  2348 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addExtension(DescriptorProtos.FieldDescriptorProto.Builder builderForValue) {
/*  2352 */         ensureExtensionIsMutable();
/*  2353 */         this.extension_.add(builderForValue.build());
/*  2354 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllExtension(Iterable<? extends DescriptorProtos.FieldDescriptorProto> values) {
/*  2358 */         ensureExtensionIsMutable();
/*  2359 */         GeneratedMessage.Builder.addAll(values, this.extension_);
/*  2360 */         return this;
/*       */       }
/*       */       public Builder clearExtension() {
/*  2363 */         this.extension_ = Collections.emptyList();
/*  2364 */         this.isExtensionMutable = false;
/*  2365 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureNestedTypeIsMutable()
/*       */       {
/*  2373 */         if (!this.isNestedTypeMutable) {
/*  2374 */           this.nestedType_ = new ArrayList(this.nestedType_);
/*  2375 */           this.isNestedTypeMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.DescriptorProto> getNestedTypeList() {
/*  2379 */         return Collections.unmodifiableList(this.nestedType_);
/*       */       }
/*       */       public int getNestedTypeCount() {
/*  2382 */         return this.nestedType_.size();
/*       */       }
/*       */       public DescriptorProtos.DescriptorProto getNestedType(int index) {
/*  2385 */         return (DescriptorProtos.DescriptorProto)this.nestedType_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setNestedType(int index, DescriptorProtos.DescriptorProto value) {
/*  2389 */         if (value == null) {
/*  2390 */           throw new NullPointerException();
/*       */         }
/*  2392 */         ensureNestedTypeIsMutable();
/*  2393 */         this.nestedType_.set(index, value);
/*  2394 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setNestedType(int index, Builder builderForValue) {
/*  2398 */         ensureNestedTypeIsMutable();
/*  2399 */         this.nestedType_.set(index, builderForValue.build());
/*  2400 */         return this;
/*       */       }
/*       */       public Builder addNestedType(DescriptorProtos.DescriptorProto value) {
/*  2403 */         if (value == null) {
/*  2404 */           throw new NullPointerException();
/*       */         }
/*  2406 */         ensureNestedTypeIsMutable();
/*  2407 */         this.nestedType_.add(value);
/*  2408 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addNestedType(Builder builderForValue) {
/*  2412 */         ensureNestedTypeIsMutable();
/*  2413 */         this.nestedType_.add(builderForValue.build());
/*  2414 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllNestedType(Iterable<? extends DescriptorProtos.DescriptorProto> values) {
/*  2418 */         ensureNestedTypeIsMutable();
/*  2419 */         GeneratedMessage.Builder.addAll(values, this.nestedType_);
/*  2420 */         return this;
/*       */       }
/*       */       public Builder clearNestedType() {
/*  2423 */         this.nestedType_ = Collections.emptyList();
/*  2424 */         this.isNestedTypeMutable = false;
/*  2425 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureEnumTypeIsMutable()
/*       */       {
/*  2433 */         if (!this.isEnumTypeMutable) {
/*  2434 */           this.enumType_ = new ArrayList(this.enumType_);
/*  2435 */           this.isEnumTypeMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList() {
/*  2439 */         return Collections.unmodifiableList(this.enumType_);
/*       */       }
/*       */       public int getEnumTypeCount() {
/*  2442 */         return this.enumType_.size();
/*       */       }
/*       */       public DescriptorProtos.EnumDescriptorProto getEnumType(int index) {
/*  2445 */         return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto value) {
/*  2449 */         if (value == null) {
/*  2450 */           throw new NullPointerException();
/*       */         }
/*  2452 */         ensureEnumTypeIsMutable();
/*  2453 */         this.enumType_.set(index, value);
/*  2454 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto.Builder builderForValue) {
/*  2458 */         ensureEnumTypeIsMutable();
/*  2459 */         this.enumType_.set(index, builderForValue.build());
/*  2460 */         return this;
/*       */       }
/*       */       public Builder addEnumType(DescriptorProtos.EnumDescriptorProto value) {
/*  2463 */         if (value == null) {
/*  2464 */           throw new NullPointerException();
/*       */         }
/*  2466 */         ensureEnumTypeIsMutable();
/*  2467 */         this.enumType_.add(value);
/*  2468 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addEnumType(DescriptorProtos.EnumDescriptorProto.Builder builderForValue) {
/*  2472 */         ensureEnumTypeIsMutable();
/*  2473 */         this.enumType_.add(builderForValue.build());
/*  2474 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllEnumType(Iterable<? extends DescriptorProtos.EnumDescriptorProto> values) {
/*  2478 */         ensureEnumTypeIsMutable();
/*  2479 */         GeneratedMessage.Builder.addAll(values, this.enumType_);
/*  2480 */         return this;
/*       */       }
/*       */       public Builder clearEnumType() {
/*  2483 */         this.enumType_ = Collections.emptyList();
/*  2484 */         this.isEnumTypeMutable = false;
/*  2485 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureExtensionRangeIsMutable()
/*       */       {
/*  2493 */         if (!this.isExtensionRangeMutable) {
/*  2494 */           this.extensionRange_ = new ArrayList(this.extensionRange_);
/*  2495 */           this.isExtensionRangeMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.DescriptorProto.ExtensionRange> getExtensionRangeList() {
/*  2499 */         return Collections.unmodifiableList(this.extensionRange_);
/*       */       }
/*       */       public int getExtensionRangeCount() {
/*  2502 */         return this.extensionRange_.size();
/*       */       }
/*       */       public DescriptorProtos.DescriptorProto.ExtensionRange getExtensionRange(int index) {
/*  2505 */         return (DescriptorProtos.DescriptorProto.ExtensionRange)this.extensionRange_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setExtensionRange(int index, DescriptorProtos.DescriptorProto.ExtensionRange value) {
/*  2509 */         if (value == null) {
/*  2510 */           throw new NullPointerException();
/*       */         }
/*  2512 */         ensureExtensionRangeIsMutable();
/*  2513 */         this.extensionRange_.set(index, value);
/*  2514 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setExtensionRange(int index, DescriptorProtos.DescriptorProto.ExtensionRange.Builder builderForValue) {
/*  2518 */         ensureExtensionRangeIsMutable();
/*  2519 */         this.extensionRange_.set(index, builderForValue.build());
/*  2520 */         return this;
/*       */       }
/*       */       public Builder addExtensionRange(DescriptorProtos.DescriptorProto.ExtensionRange value) {
/*  2523 */         if (value == null) {
/*  2524 */           throw new NullPointerException();
/*       */         }
/*  2526 */         ensureExtensionRangeIsMutable();
/*  2527 */         this.extensionRange_.add(value);
/*  2528 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addExtensionRange(DescriptorProtos.DescriptorProto.ExtensionRange.Builder builderForValue) {
/*  2532 */         ensureExtensionRangeIsMutable();
/*  2533 */         this.extensionRange_.add(builderForValue.build());
/*  2534 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllExtensionRange(Iterable<? extends DescriptorProtos.DescriptorProto.ExtensionRange> values) {
/*  2538 */         ensureExtensionRangeIsMutable();
/*  2539 */         GeneratedMessage.Builder.addAll(values, this.extensionRange_);
/*  2540 */         return this;
/*       */       }
/*       */       public Builder clearExtensionRange() {
/*  2543 */         this.extensionRange_ = Collections.emptyList();
/*  2544 */         this.isExtensionRangeMutable = false;
/*  2545 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  2552 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.MessageOptions getOptions() {
/*  2555 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.MessageOptions value) {
/*  2558 */         if (value == null) {
/*  2559 */           throw new NullPointerException();
/*       */         }
/*  2561 */         this.hasOptions = true;
/*  2562 */         this.options_ = value;
/*  2563 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.MessageOptions.Builder builderForValue) {
/*  2567 */         this.hasOptions = true;
/*  2568 */         this.options_ = builderForValue.build();
/*  2569 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.MessageOptions value) {
/*  2572 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.MessageOptions.getDefaultInstance()))
/*       */         {
/*  2574 */           this.options_ = DescriptorProtos.MessageOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  2577 */           this.options_ = value;
/*       */         }
/*  2579 */         this.hasOptions = true;
/*  2580 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  2583 */         this.hasOptions = false;
/*  2584 */         this.options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
/*  2585 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static final class ExtensionRange extends GeneratedMessage
/*       */     {
/*  1699 */       private static final ExtensionRange defaultInstance = new ExtensionRange(true);
/*       */       public static final int START_FIELD_NUMBER = 1;
/*       */       private boolean hasStart;
/*       */       private int start_;
/*       */       public static final int END_FIELD_NUMBER = 2;
/*       */       private boolean hasEnd;
/*       */       private int end_;
/*  1429 */       private int memoizedSerializedSize = -1;
/*       */ 
/*       */       private ExtensionRange(Builder builder)
/*       */       {
/*  1364 */         super();
/*       */       }
/*       */       private ExtensionRange(boolean noInit) {
/*       */       }
/*       */ 
/*       */       public static ExtensionRange getDefaultInstance() {
/*  1370 */         return defaultInstance;
/*       */       }
/*       */ 
/*       */       public ExtensionRange getDefaultInstanceForType() {
/*  1374 */         return defaultInstance;
/*       */       }
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*  1379 */         return DescriptorProtos.internal_static_proto2_DescriptorProto_ExtensionRange_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*  1384 */         return DescriptorProtos.internal_static_proto2_DescriptorProto_ExtensionRange_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       public boolean hasStart()
/*       */       {
/*  1392 */         return this.hasStart;
/*       */       }
/*       */       public int getStart() {
/*  1395 */         return this.start_;
/*       */       }
/*       */ 
/*       */       public boolean hasEnd()
/*       */       {
/*  1403 */         return this.hasEnd;
/*       */       }
/*       */       public int getEnd() {
/*  1406 */         return this.end_;
/*       */       }
/*       */ 
/*       */       private void initFields() {
/*  1410 */         this.start_ = 0;
/*  1411 */         this.end_ = 0;
/*       */       }
/*       */       public final boolean isInitialized() {
/*  1414 */         return true;
/*       */       }
/*       */ 
/*       */       public void writeTo(CodedOutputStream output) throws IOException
/*       */       {
/*  1419 */         getSerializedSize();
/*  1420 */         if (hasStart()) {
/*  1421 */           output.writeInt32(1, getStart());
/*       */         }
/*  1423 */         if (hasEnd()) {
/*  1424 */           output.writeInt32(2, getEnd());
/*       */         }
/*  1426 */         getUnknownFields().writeTo(output);
/*       */       }
/*       */ 
/*       */       public int getSerializedSize()
/*       */       {
/*  1431 */         int size = this.memoizedSerializedSize;
/*  1432 */         if (size != -1) return size;
/*       */ 
/*  1434 */         size = 0;
/*  1435 */         if (hasStart()) {
/*  1436 */           size += CodedOutputStream.computeInt32Size(1, getStart());
/*       */         }
/*       */ 
/*  1439 */         if (hasEnd()) {
/*  1440 */           size += CodedOutputStream.computeInt32Size(2, getEnd());
/*       */         }
/*       */ 
/*  1443 */         size += getUnknownFields().getSerializedSize();
/*  1444 */         this.memoizedSerializedSize = size;
/*  1445 */         return size;
/*       */       }
/*       */ 
/*       */       protected Object writeReplace() throws ObjectStreamException
/*       */       {
/*  1450 */         return super.writeReplace();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(ByteString data)
/*       */         throws InvalidProtocolBufferException
/*       */       {
/*  1456 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */         throws InvalidProtocolBufferException
/*       */       {
/*  1462 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */       {
/*  1467 */         return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */         throws InvalidProtocolBufferException
/*       */       {
/*  1473 */         return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(InputStream input) throws IOException
/*       */       {
/*  1478 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  1484 */         return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseDelimitedFrom(InputStream input) throws IOException
/*       */       {
/*  1489 */         Builder builder = newBuilder();
/*  1490 */         if (builder.mergeDelimitedFrom(input)) {
/*  1491 */           return builder.buildParsed();
/*       */         }
/*  1493 */         return null;
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  1500 */         Builder builder = newBuilder();
/*  1501 */         if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  1502 */           return builder.buildParsed();
/*       */         }
/*  1504 */         return null;
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(CodedInputStream input)
/*       */         throws IOException
/*       */       {
/*  1510 */         return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */       }
/*       */ 
/*       */       public static ExtensionRange parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*  1516 */         return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */       }
/*       */ 
/*       */       public static Builder newBuilder() {
/*  1520 */         return Builder.access$2700(); } 
/*  1521 */       public Builder newBuilderForType() { return newBuilder(); } 
/*       */       public static Builder newBuilder(ExtensionRange prototype) {
/*  1523 */         return newBuilder().mergeFrom(prototype);
/*       */       }
/*  1525 */       public Builder toBuilder() { return newBuilder(this);
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  1700 */         DescriptorProtos.internalForceInit();
/*  1701 */         defaultInstance.initFields();
/*       */       }
/*       */ 
/*       */       public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */       {
/*       */         private boolean hasStart;
/*       */         private int start_;
/*       */         private boolean hasEnd;
/*       */         private int end_;
/*       */ 
/*       */         public static final Descriptors.Descriptor getDescriptor()
/*       */         {
/*  1531 */           return DescriptorProtos.internal_static_proto2_DescriptorProto_ExtensionRange_descriptor;
/*       */         }
/*       */ 
/*       */         protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */         {
/*  1536 */           return DescriptorProtos.internal_static_proto2_DescriptorProto_ExtensionRange_fieldAccessorTable;
/*       */         }
/*       */ 
/*       */         private static Builder create()
/*       */         {
/*  1544 */           return new Builder();
/*       */         }
/*       */ 
/*       */         public Builder clear() {
/*  1548 */           super.clear();
/*  1549 */           this.start_ = 0;
/*  1550 */           this.hasStart = false;
/*  1551 */           this.end_ = 0;
/*  1552 */           this.hasEnd = false;
/*  1553 */           return this;
/*       */         }
/*       */ 
/*       */         public Builder clone() {
/*  1557 */           return create().mergeFrom(buildPartial());
/*       */         }
/*       */ 
/*       */         public Descriptors.Descriptor getDescriptorForType()
/*       */         {
/*  1562 */           return DescriptorProtos.DescriptorProto.ExtensionRange.getDescriptor();
/*       */         }
/*       */ 
/*       */         public DescriptorProtos.DescriptorProto.ExtensionRange getDefaultInstanceForType() {
/*  1566 */           return DescriptorProtos.DescriptorProto.ExtensionRange.getDefaultInstance();
/*       */         }
/*       */ 
/*       */         public DescriptorProtos.DescriptorProto.ExtensionRange build() {
/*  1570 */           DescriptorProtos.DescriptorProto.ExtensionRange result = buildPartial();
/*  1571 */           if (!result.isInitialized()) {
/*  1572 */             throw newUninitializedMessageException(result);
/*       */           }
/*  1574 */           return result;
/*       */         }
/*       */ 
/*       */         private DescriptorProtos.DescriptorProto.ExtensionRange buildParsed() throws InvalidProtocolBufferException
/*       */         {
/*  1579 */           DescriptorProtos.DescriptorProto.ExtensionRange result = buildPartial();
/*  1580 */           if (!result.isInitialized()) {
/*  1581 */             throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */           }
/*       */ 
/*  1584 */           return result;
/*       */         }
/*       */ 
/*       */         public DescriptorProtos.DescriptorProto.ExtensionRange buildPartial() {
/*  1588 */           DescriptorProtos.DescriptorProto.ExtensionRange result = new DescriptorProtos.DescriptorProto.ExtensionRange(this, null);
/*  1589 */           DescriptorProtos.DescriptorProto.ExtensionRange.access$2902(result, this.hasStart);
/*  1590 */           DescriptorProtos.DescriptorProto.ExtensionRange.access$3002(result, this.start_);
/*  1591 */           DescriptorProtos.DescriptorProto.ExtensionRange.access$3102(result, this.hasEnd);
/*  1592 */           DescriptorProtos.DescriptorProto.ExtensionRange.access$3202(result, this.end_);
/*  1593 */           return result;
/*       */         }
/*       */ 
/*       */         public Builder mergeFrom(Message other) {
/*  1597 */           if ((other instanceof DescriptorProtos.DescriptorProto.ExtensionRange)) {
/*  1598 */             return mergeFrom((DescriptorProtos.DescriptorProto.ExtensionRange)other);
/*       */           }
/*  1600 */           super.mergeFrom(other);
/*  1601 */           return this;
/*       */         }
/*       */ 
/*       */         public Builder mergeFrom(DescriptorProtos.DescriptorProto.ExtensionRange other)
/*       */         {
/*  1606 */           if (other == DescriptorProtos.DescriptorProto.ExtensionRange.getDefaultInstance()) return this;
/*  1607 */           if (other.hasStart()) {
/*  1608 */             setStart(other.getStart());
/*       */           }
/*  1610 */           if (other.hasEnd()) {
/*  1611 */             setEnd(other.getEnd());
/*       */           }
/*  1613 */           mergeUnknownFields(other.getUnknownFields());
/*  1614 */           return this;
/*       */         }
/*       */ 
/*       */         public final boolean isInitialized() {
/*  1618 */           return true;
/*       */         }
/*       */ 
/*       */         public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */           throws IOException
/*       */         {
/*  1625 */           UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */           while (true)
/*       */           {
/*  1629 */             int tag = input.readTag();
/*  1630 */             switch (tag) {
/*       */             case 0:
/*  1632 */               setUnknownFields(unknownFields.build());
/*  1633 */               return this;
/*       */             default:
/*  1635 */               if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */                 break;
/*  1637 */               setUnknownFields(unknownFields.build());
/*  1638 */               return this;
/*       */             case 8:
/*  1643 */               setStart(input.readInt32());
/*  1644 */               break;
/*       */             case 16:
/*  1647 */               setEnd(input.readInt32());
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */         public boolean hasStart()
/*       */         {
/*  1659 */           return this.hasStart;
/*       */         }
/*       */         public int getStart() {
/*  1662 */           return this.start_;
/*       */         }
/*       */         public Builder setStart(int value) {
/*  1665 */           this.hasStart = true;
/*  1666 */           this.start_ = value;
/*  1667 */           return this;
/*       */         }
/*       */         public Builder clearStart() {
/*  1670 */           this.hasStart = false;
/*  1671 */           this.start_ = 0;
/*  1672 */           return this;
/*       */         }
/*       */ 
/*       */         public boolean hasEnd()
/*       */         {
/*  1679 */           return this.hasEnd;
/*       */         }
/*       */         public int getEnd() {
/*  1682 */           return this.end_;
/*       */         }
/*       */         public Builder setEnd(int value) {
/*  1685 */           this.hasEnd = true;
/*  1686 */           this.end_ = value;
/*  1687 */           return this;
/*       */         }
/*       */         public Builder clearEnd() {
/*  1690 */           this.hasEnd = false;
/*  1691 */           this.end_ = 0;
/*  1692 */           return this;
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class FileDescriptorProto extends GeneratedMessage
/*       */   {
/*  1325 */     private static final FileDescriptorProto defaultInstance = new FileDescriptorProto(true);
/*       */     public static final int NAME_FIELD_NUMBER = 1;
/*       */     private boolean hasName;
/*       */     private String name_;
/*       */     public static final int PACKAGE_FIELD_NUMBER = 2;
/*       */     private boolean hasPackage;
/*       */     private String package_;
/*       */     public static final int DEPENDENCY_FIELD_NUMBER = 3;
/*       */     private List<String> dependency_;
/*       */     public static final int MESSAGE_TYPE_FIELD_NUMBER = 4;
/*       */     private List<DescriptorProtos.DescriptorProto> messageType_;
/*       */     public static final int ENUM_TYPE_FIELD_NUMBER = 5;
/*       */     private List<DescriptorProtos.EnumDescriptorProto> enumType_;
/*       */     public static final int SERVICE_FIELD_NUMBER = 6;
/*       */     private List<DescriptorProtos.ServiceDescriptorProto> service_;
/*       */     public static final int EXTENSION_FIELD_NUMBER = 7;
/*       */     private List<DescriptorProtos.FieldDescriptorProto> extension_;
/*       */     public static final int OPTIONS_FIELD_NUMBER = 8;
/*       */     private boolean hasOptions;
/*       */     private DescriptorProtos.FileOptions options_;
/*   552 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private FileDescriptorProto(Builder builder)
/*       */     {
/*   371 */       super();
/*       */     }
/*       */     private FileDescriptorProto(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto getDefaultInstance() {
/*   377 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public FileDescriptorProto getDefaultInstanceForType() {
/*   381 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*   386 */       return DescriptorProtos.internal_static_proto2_FileDescriptorProto_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*   391 */       return DescriptorProtos.internal_static_proto2_FileDescriptorProto_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public boolean hasName()
/*       */     {
/*   399 */       return this.hasName;
/*       */     }
/*       */     public String getName() {
/*   402 */       return this.name_;
/*       */     }
/*       */ 
/*       */     public boolean hasPackage()
/*       */     {
/*   410 */       return this.hasPackage;
/*       */     }
/*       */     public String getPackage() {
/*   413 */       return this.package_;
/*       */     }
/*       */ 
/*       */     public List<String> getDependencyList()
/*       */     {
/*   421 */       return this.dependency_;
/*       */     }
/*       */     public int getDependencyCount() {
/*   424 */       return this.dependency_.size();
/*       */     }
/*       */     public String getDependency(int index) {
/*   427 */       return (String)this.dependency_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.DescriptorProto> getMessageTypeList()
/*       */     {
/*   434 */       return this.messageType_;
/*       */     }
/*       */     public int getMessageTypeCount() {
/*   437 */       return this.messageType_.size();
/*       */     }
/*       */     public DescriptorProtos.DescriptorProto getMessageType(int index) {
/*   440 */       return (DescriptorProtos.DescriptorProto)this.messageType_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList()
/*       */     {
/*   447 */       return this.enumType_;
/*       */     }
/*       */     public int getEnumTypeCount() {
/*   450 */       return this.enumType_.size();
/*       */     }
/*       */     public DescriptorProtos.EnumDescriptorProto getEnumType(int index) {
/*   453 */       return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.ServiceDescriptorProto> getServiceList()
/*       */     {
/*   460 */       return this.service_;
/*       */     }
/*       */     public int getServiceCount() {
/*   463 */       return this.service_.size();
/*       */     }
/*       */     public DescriptorProtos.ServiceDescriptorProto getService(int index) {
/*   466 */       return (DescriptorProtos.ServiceDescriptorProto)this.service_.get(index);
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.FieldDescriptorProto> getExtensionList()
/*       */     {
/*   473 */       return this.extension_;
/*       */     }
/*       */     public int getExtensionCount() {
/*   476 */       return this.extension_.size();
/*       */     }
/*       */     public DescriptorProtos.FieldDescriptorProto getExtension(int index) {
/*   479 */       return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
/*       */     }
/*       */ 
/*       */     public boolean hasOptions()
/*       */     {
/*   487 */       return this.hasOptions;
/*       */     }
/*       */     public DescriptorProtos.FileOptions getOptions() {
/*   490 */       return this.options_;
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*   494 */       this.name_ = "";
/*   495 */       this.package_ = "";
/*   496 */       this.dependency_ = Collections.emptyList();
/*   497 */       this.messageType_ = Collections.emptyList();
/*   498 */       this.enumType_ = Collections.emptyList();
/*   499 */       this.service_ = Collections.emptyList();
/*   500 */       this.extension_ = Collections.emptyList();
/*   501 */       this.options_ = DescriptorProtos.FileOptions.getDefaultInstance();
/*       */     }
/*       */     public final boolean isInitialized() {
/*   504 */       for (DescriptorProtos.DescriptorProto element : getMessageTypeList()) {
/*   505 */         if (!element.isInitialized()) return false;
/*       */       }
/*   507 */       for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*   508 */         if (!element.isInitialized()) return false;
/*       */       }
/*   510 */       for (DescriptorProtos.ServiceDescriptorProto element : getServiceList()) {
/*   511 */         if (!element.isInitialized()) return false;
/*       */       }
/*   513 */       for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*   514 */         if (!element.isInitialized()) return false;
/*       */       }
/*       */ 
/*   517 */       return (!hasOptions()) || 
/*   517 */         (getOptions().isInitialized());
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output)
/*       */       throws IOException
/*       */     {
/*   524 */       getSerializedSize();
/*   525 */       if (hasName()) {
/*   526 */         output.writeString(1, getName());
/*       */       }
/*   528 */       if (hasPackage()) {
/*   529 */         output.writeString(2, getPackage());
/*       */       }
/*   531 */       for (String element : getDependencyList()) {
/*   532 */         output.writeString(3, element);
/*       */       }
/*   534 */       for (DescriptorProtos.DescriptorProto element : getMessageTypeList()) {
/*   535 */         output.writeMessage(4, element);
/*       */       }
/*   537 */       for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*   538 */         output.writeMessage(5, element);
/*       */       }
/*   540 */       for (DescriptorProtos.ServiceDescriptorProto element : getServiceList()) {
/*   541 */         output.writeMessage(6, element);
/*       */       }
/*   543 */       for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*   544 */         output.writeMessage(7, element);
/*       */       }
/*   546 */       if (hasOptions()) {
/*   547 */         output.writeMessage(8, getOptions());
/*       */       }
/*   549 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*   554 */       int size = this.memoizedSerializedSize;
/*   555 */       if (size != -1) return size;
/*       */ 
/*   557 */       size = 0;
/*   558 */       if (hasName()) {
/*   559 */         size += CodedOutputStream.computeStringSize(1, getName());
/*       */       }
/*       */ 
/*   562 */       if (hasPackage()) {
/*   563 */         size += CodedOutputStream.computeStringSize(2, getPackage());
/*       */       }
/*       */ 
/*   567 */       int dataSize = 0;
/*   568 */       for (String element : getDependencyList()) {
/*   569 */         dataSize += CodedOutputStream.computeStringSizeNoTag(element);
/*       */       }
/*       */ 
/*   572 */       size += dataSize;
/*   573 */       size += 1 * getDependencyList().size();
/*       */ 
/*   575 */       for (DescriptorProtos.DescriptorProto element : getMessageTypeList()) {
/*   576 */         size += CodedOutputStream.computeMessageSize(4, element);
/*       */       }
/*       */ 
/*   579 */       for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*   580 */         size += CodedOutputStream.computeMessageSize(5, element);
/*       */       }
/*       */ 
/*   583 */       for (DescriptorProtos.ServiceDescriptorProto element : getServiceList()) {
/*   584 */         size += CodedOutputStream.computeMessageSize(6, element);
/*       */       }
/*       */ 
/*   587 */       for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*   588 */         size += CodedOutputStream.computeMessageSize(7, element);
/*       */       }
/*       */ 
/*   591 */       if (hasOptions()) {
/*   592 */         size += CodedOutputStream.computeMessageSize(8, getOptions());
/*       */       }
/*       */ 
/*   595 */       size += getUnknownFields().getSerializedSize();
/*   596 */       this.memoizedSerializedSize = size;
/*   597 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*   602 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*   608 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*   614 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*   619 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*   625 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(InputStream input) throws IOException
/*       */     {
/*   630 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*   636 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*   641 */       Builder builder = newBuilder();
/*   642 */       if (builder.mergeDelimitedFrom(input)) {
/*   643 */         return builder.buildParsed();
/*       */       }
/*   645 */       return null;
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*   652 */       Builder builder = newBuilder();
/*   653 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*   654 */         return builder.buildParsed();
/*       */       }
/*   656 */       return null;
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*   662 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*   668 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*   672 */       return Builder.access$900(); } 
/*   673 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(FileDescriptorProto prototype) {
/*   675 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*   677 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  1326 */       DescriptorProtos.internalForceInit();
/*  1327 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*       */       private boolean hasName;
/*   948 */       private String name_ = "";
/*       */       private boolean hasPackage;
/*   971 */       private String package_ = "";
/*       */ 
/*   993 */       private List<String> dependency_ = Collections.emptyList();
/*       */       private boolean isDependencyMutable;
/*  1042 */       private List<DescriptorProtos.DescriptorProto> messageType_ = Collections.emptyList();
/*       */       private boolean isMessageTypeMutable;
/*  1102 */       private List<DescriptorProtos.EnumDescriptorProto> enumType_ = Collections.emptyList();
/*       */       private boolean isEnumTypeMutable;
/*  1162 */       private List<DescriptorProtos.ServiceDescriptorProto> service_ = Collections.emptyList();
/*       */       private boolean isServiceMutable;
/*  1222 */       private List<DescriptorProtos.FieldDescriptorProto> extension_ = Collections.emptyList();
/*       */       private boolean isExtensionMutable;
/*       */       private boolean hasOptions;
/*  1283 */       private DescriptorProtos.FileOptions options_ = DescriptorProtos.FileOptions.getDefaultInstance();
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*   683 */         return DescriptorProtos.internal_static_proto2_FileDescriptorProto_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*   688 */         return DescriptorProtos.internal_static_proto2_FileDescriptorProto_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*   696 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*   700 */         super.clear();
/*   701 */         this.name_ = "";
/*   702 */         this.hasName = false;
/*   703 */         this.package_ = "";
/*   704 */         this.hasPackage = false;
/*   705 */         this.dependency_ = Collections.emptyList();
/*   706 */         this.isDependencyMutable = false;
/*   707 */         this.messageType_ = Collections.emptyList();
/*   708 */         this.isMessageTypeMutable = false;
/*   709 */         this.enumType_ = Collections.emptyList();
/*   710 */         this.isEnumTypeMutable = false;
/*   711 */         this.service_ = Collections.emptyList();
/*   712 */         this.isServiceMutable = false;
/*   713 */         this.extension_ = Collections.emptyList();
/*   714 */         this.isExtensionMutable = false;
/*   715 */         this.options_ = DescriptorProtos.FileOptions.getDefaultInstance();
/*   716 */         this.hasOptions = false;
/*   717 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*   721 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*   726 */         return DescriptorProtos.FileDescriptorProto.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileDescriptorProto getDefaultInstanceForType() {
/*   730 */         return DescriptorProtos.FileDescriptorProto.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileDescriptorProto build() {
/*   734 */         DescriptorProtos.FileDescriptorProto result = buildPartial();
/*   735 */         if (!result.isInitialized()) {
/*   736 */           throw newUninitializedMessageException(result);
/*       */         }
/*   738 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.FileDescriptorProto buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*   743 */         DescriptorProtos.FileDescriptorProto result = buildPartial();
/*   744 */         if (!result.isInitialized()) {
/*   745 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*   748 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileDescriptorProto buildPartial() {
/*   752 */         DescriptorProtos.FileDescriptorProto result = new DescriptorProtos.FileDescriptorProto(this, null);
/*   753 */         DescriptorProtos.FileDescriptorProto.access$1102(result, this.hasName);
/*   754 */         DescriptorProtos.FileDescriptorProto.access$1202(result, this.name_);
/*   755 */         DescriptorProtos.FileDescriptorProto.access$1302(result, this.hasPackage);
/*   756 */         DescriptorProtos.FileDescriptorProto.access$1402(result, this.package_);
/*   757 */         if (this.isDependencyMutable) {
/*   758 */           this.dependency_ = Collections.unmodifiableList(this.dependency_);
/*   759 */           this.isDependencyMutable = false;
/*       */         }
/*   761 */         DescriptorProtos.FileDescriptorProto.access$1502(result, this.dependency_);
/*   762 */         if (this.isMessageTypeMutable) {
/*   763 */           this.messageType_ = Collections.unmodifiableList(this.messageType_);
/*   764 */           this.isMessageTypeMutable = false;
/*       */         }
/*   766 */         DescriptorProtos.FileDescriptorProto.access$1602(result, this.messageType_);
/*   767 */         if (this.isEnumTypeMutable) {
/*   768 */           this.enumType_ = Collections.unmodifiableList(this.enumType_);
/*   769 */           this.isEnumTypeMutable = false;
/*       */         }
/*   771 */         DescriptorProtos.FileDescriptorProto.access$1702(result, this.enumType_);
/*   772 */         if (this.isServiceMutable) {
/*   773 */           this.service_ = Collections.unmodifiableList(this.service_);
/*   774 */           this.isServiceMutable = false;
/*       */         }
/*   776 */         DescriptorProtos.FileDescriptorProto.access$1802(result, this.service_);
/*   777 */         if (this.isExtensionMutable) {
/*   778 */           this.extension_ = Collections.unmodifiableList(this.extension_);
/*   779 */           this.isExtensionMutable = false;
/*       */         }
/*   781 */         DescriptorProtos.FileDescriptorProto.access$1902(result, this.extension_);
/*   782 */         DescriptorProtos.FileDescriptorProto.access$2002(result, this.hasOptions);
/*   783 */         DescriptorProtos.FileDescriptorProto.access$2102(result, this.options_);
/*   784 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*   788 */         if ((other instanceof DescriptorProtos.FileDescriptorProto)) {
/*   789 */           return mergeFrom((DescriptorProtos.FileDescriptorProto)other);
/*       */         }
/*   791 */         super.mergeFrom(other);
/*   792 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.FileDescriptorProto other)
/*       */       {
/*   797 */         if (other == DescriptorProtos.FileDescriptorProto.getDefaultInstance()) return this;
/*   798 */         if (other.hasName()) {
/*   799 */           setName(other.getName());
/*       */         }
/*   801 */         if (other.hasPackage()) {
/*   802 */           setPackage(other.getPackage());
/*       */         }
/*   804 */         if (!other.dependency_.isEmpty()) {
/*   805 */           if (this.dependency_.isEmpty()) {
/*   806 */             this.dependency_ = other.dependency_;
/*   807 */             this.isDependencyMutable = false;
/*       */           } else {
/*   809 */             ensureDependencyIsMutable();
/*   810 */             this.dependency_.addAll(other.dependency_);
/*       */           }
/*       */         }
/*   813 */         if (!other.messageType_.isEmpty()) {
/*   814 */           if (this.messageType_.isEmpty()) {
/*   815 */             this.messageType_ = other.messageType_;
/*   816 */             this.isMessageTypeMutable = false;
/*       */           } else {
/*   818 */             ensureMessageTypeIsMutable();
/*   819 */             this.messageType_.addAll(other.messageType_);
/*       */           }
/*       */         }
/*   822 */         if (!other.enumType_.isEmpty()) {
/*   823 */           if (this.enumType_.isEmpty()) {
/*   824 */             this.enumType_ = other.enumType_;
/*   825 */             this.isEnumTypeMutable = false;
/*       */           } else {
/*   827 */             ensureEnumTypeIsMutable();
/*   828 */             this.enumType_.addAll(other.enumType_);
/*       */           }
/*       */         }
/*   831 */         if (!other.service_.isEmpty()) {
/*   832 */           if (this.service_.isEmpty()) {
/*   833 */             this.service_ = other.service_;
/*   834 */             this.isServiceMutable = false;
/*       */           } else {
/*   836 */             ensureServiceIsMutable();
/*   837 */             this.service_.addAll(other.service_);
/*       */           }
/*       */         }
/*   840 */         if (!other.extension_.isEmpty()) {
/*   841 */           if (this.extension_.isEmpty()) {
/*   842 */             this.extension_ = other.extension_;
/*   843 */             this.isExtensionMutable = false;
/*       */           } else {
/*   845 */             ensureExtensionIsMutable();
/*   846 */             this.extension_.addAll(other.extension_);
/*       */           }
/*       */         }
/*   849 */         if (other.hasOptions()) {
/*   850 */           mergeOptions(other.getOptions());
/*       */         }
/*   852 */         mergeUnknownFields(other.getUnknownFields());
/*   853 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*   857 */         for (DescriptorProtos.DescriptorProto element : getMessageTypeList()) {
/*   858 */           if (!element.isInitialized()) return false;
/*       */         }
/*   860 */         for (DescriptorProtos.EnumDescriptorProto element : getEnumTypeList()) {
/*   861 */           if (!element.isInitialized()) return false;
/*       */         }
/*   863 */         for (DescriptorProtos.ServiceDescriptorProto element : getServiceList()) {
/*   864 */           if (!element.isInitialized()) return false;
/*       */         }
/*   866 */         for (DescriptorProtos.FieldDescriptorProto element : getExtensionList()) {
/*   867 */           if (!element.isInitialized()) return false;
/*       */         }
/*       */ 
/*   870 */         return (!hasOptions()) || 
/*   870 */           (getOptions().isInitialized());
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*   879 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*   883 */           int tag = input.readTag();
/*   884 */           switch (tag) {
/*       */           case 0:
/*   886 */             setUnknownFields(unknownFields.build());
/*   887 */             return this;
/*       */           default:
/*   889 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*   891 */             setUnknownFields(unknownFields.build());
/*   892 */             return this;
/*       */           case 10:
/*   897 */             setName(input.readString());
/*   898 */             break;
/*       */           case 18:
/*   901 */             setPackage(input.readString());
/*   902 */             break;
/*       */           case 26:
/*   905 */             addDependency(input.readString());
/*   906 */             break;
/*       */           case 34:
/*   909 */             DescriptorProtos.DescriptorProto.Builder subBuilder = DescriptorProtos.DescriptorProto.newBuilder();
/*   910 */             input.readMessage(subBuilder, extensionRegistry);
/*   911 */             addMessageType(subBuilder.buildPartial());
/*   912 */             break;
/*       */           case 42:
/*   915 */             DescriptorProtos.EnumDescriptorProto.Builder subBuilder = DescriptorProtos.EnumDescriptorProto.newBuilder();
/*   916 */             input.readMessage(subBuilder, extensionRegistry);
/*   917 */             addEnumType(subBuilder.buildPartial());
/*   918 */             break;
/*       */           case 50:
/*   921 */             DescriptorProtos.ServiceDescriptorProto.Builder subBuilder = DescriptorProtos.ServiceDescriptorProto.newBuilder();
/*   922 */             input.readMessage(subBuilder, extensionRegistry);
/*   923 */             addService(subBuilder.buildPartial());
/*   924 */             break;
/*       */           case 58:
/*   927 */             DescriptorProtos.FieldDescriptorProto.Builder subBuilder = DescriptorProtos.FieldDescriptorProto.newBuilder();
/*   928 */             input.readMessage(subBuilder, extensionRegistry);
/*   929 */             addExtension(subBuilder.buildPartial());
/*   930 */             break;
/*       */           case 66:
/*   933 */             DescriptorProtos.FileOptions.Builder subBuilder = DescriptorProtos.FileOptions.newBuilder();
/*   934 */             if (hasOptions()) {
/*   935 */               subBuilder.mergeFrom(getOptions());
/*       */             }
/*   937 */             input.readMessage(subBuilder, extensionRegistry);
/*   938 */             setOptions(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       public boolean hasName()
/*       */       {
/*   950 */         return this.hasName;
/*       */       }
/*       */       public String getName() {
/*   953 */         return this.name_;
/*       */       }
/*       */       public Builder setName(String value) {
/*   956 */         if (value == null) {
/*   957 */           throw new NullPointerException();
/*       */         }
/*   959 */         this.hasName = true;
/*   960 */         this.name_ = value;
/*   961 */         return this;
/*       */       }
/*       */       public Builder clearName() {
/*   964 */         this.hasName = false;
/*   965 */         this.name_ = DescriptorProtos.FileDescriptorProto.getDefaultInstance().getName();
/*   966 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasPackage()
/*       */       {
/*   973 */         return this.hasPackage;
/*       */       }
/*       */       public String getPackage() {
/*   976 */         return this.package_;
/*       */       }
/*       */       public Builder setPackage(String value) {
/*   979 */         if (value == null) {
/*   980 */           throw new NullPointerException();
/*       */         }
/*   982 */         this.hasPackage = true;
/*   983 */         this.package_ = value;
/*   984 */         return this;
/*       */       }
/*       */       public Builder clearPackage() {
/*   987 */         this.hasPackage = false;
/*   988 */         this.package_ = DescriptorProtos.FileDescriptorProto.getDefaultInstance().getPackage();
/*   989 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureDependencyIsMutable()
/*       */       {
/*   997 */         if (!this.isDependencyMutable) {
/*   998 */           this.dependency_ = new ArrayList(this.dependency_);
/*   999 */           this.isDependencyMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<String> getDependencyList() {
/*  1004 */         return Collections.unmodifiableList(this.dependency_);
/*       */       }
/*       */       public int getDependencyCount() {
/*  1007 */         return this.dependency_.size();
/*       */       }
/*       */       public String getDependency(int index) {
/*  1010 */         return (String)this.dependency_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setDependency(int index, String value) {
/*  1014 */         if (value == null) {
/*  1015 */           throw new NullPointerException();
/*       */         }
/*  1017 */         ensureDependencyIsMutable();
/*  1018 */         this.dependency_.set(index, value);
/*  1019 */         return this;
/*       */       }
/*       */       public Builder addDependency(String value) {
/*  1022 */         if (value == null) {
/*  1023 */           throw new NullPointerException();
/*       */         }
/*  1025 */         ensureDependencyIsMutable();
/*  1026 */         this.dependency_.add(value);
/*  1027 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllDependency(Iterable<? extends String> values) {
/*  1031 */         ensureDependencyIsMutable();
/*  1032 */         GeneratedMessage.Builder.addAll(values, this.dependency_);
/*  1033 */         return this;
/*       */       }
/*       */       public Builder clearDependency() {
/*  1036 */         this.dependency_ = Collections.emptyList();
/*  1037 */         this.isDependencyMutable = false;
/*  1038 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureMessageTypeIsMutable()
/*       */       {
/*  1046 */         if (!this.isMessageTypeMutable) {
/*  1047 */           this.messageType_ = new ArrayList(this.messageType_);
/*  1048 */           this.isMessageTypeMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.DescriptorProto> getMessageTypeList() {
/*  1052 */         return Collections.unmodifiableList(this.messageType_);
/*       */       }
/*       */       public int getMessageTypeCount() {
/*  1055 */         return this.messageType_.size();
/*       */       }
/*       */       public DescriptorProtos.DescriptorProto getMessageType(int index) {
/*  1058 */         return (DescriptorProtos.DescriptorProto)this.messageType_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setMessageType(int index, DescriptorProtos.DescriptorProto value) {
/*  1062 */         if (value == null) {
/*  1063 */           throw new NullPointerException();
/*       */         }
/*  1065 */         ensureMessageTypeIsMutable();
/*  1066 */         this.messageType_.set(index, value);
/*  1067 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setMessageType(int index, DescriptorProtos.DescriptorProto.Builder builderForValue) {
/*  1071 */         ensureMessageTypeIsMutable();
/*  1072 */         this.messageType_.set(index, builderForValue.build());
/*  1073 */         return this;
/*       */       }
/*       */       public Builder addMessageType(DescriptorProtos.DescriptorProto value) {
/*  1076 */         if (value == null) {
/*  1077 */           throw new NullPointerException();
/*       */         }
/*  1079 */         ensureMessageTypeIsMutable();
/*  1080 */         this.messageType_.add(value);
/*  1081 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addMessageType(DescriptorProtos.DescriptorProto.Builder builderForValue) {
/*  1085 */         ensureMessageTypeIsMutable();
/*  1086 */         this.messageType_.add(builderForValue.build());
/*  1087 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllMessageType(Iterable<? extends DescriptorProtos.DescriptorProto> values) {
/*  1091 */         ensureMessageTypeIsMutable();
/*  1092 */         GeneratedMessage.Builder.addAll(values, this.messageType_);
/*  1093 */         return this;
/*       */       }
/*       */       public Builder clearMessageType() {
/*  1096 */         this.messageType_ = Collections.emptyList();
/*  1097 */         this.isMessageTypeMutable = false;
/*  1098 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureEnumTypeIsMutable()
/*       */       {
/*  1106 */         if (!this.isEnumTypeMutable) {
/*  1107 */           this.enumType_ = new ArrayList(this.enumType_);
/*  1108 */           this.isEnumTypeMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList() {
/*  1112 */         return Collections.unmodifiableList(this.enumType_);
/*       */       }
/*       */       public int getEnumTypeCount() {
/*  1115 */         return this.enumType_.size();
/*       */       }
/*       */       public DescriptorProtos.EnumDescriptorProto getEnumType(int index) {
/*  1118 */         return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto value) {
/*  1122 */         if (value == null) {
/*  1123 */           throw new NullPointerException();
/*       */         }
/*  1125 */         ensureEnumTypeIsMutable();
/*  1126 */         this.enumType_.set(index, value);
/*  1127 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto.Builder builderForValue) {
/*  1131 */         ensureEnumTypeIsMutable();
/*  1132 */         this.enumType_.set(index, builderForValue.build());
/*  1133 */         return this;
/*       */       }
/*       */       public Builder addEnumType(DescriptorProtos.EnumDescriptorProto value) {
/*  1136 */         if (value == null) {
/*  1137 */           throw new NullPointerException();
/*       */         }
/*  1139 */         ensureEnumTypeIsMutable();
/*  1140 */         this.enumType_.add(value);
/*  1141 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addEnumType(DescriptorProtos.EnumDescriptorProto.Builder builderForValue) {
/*  1145 */         ensureEnumTypeIsMutable();
/*  1146 */         this.enumType_.add(builderForValue.build());
/*  1147 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllEnumType(Iterable<? extends DescriptorProtos.EnumDescriptorProto> values) {
/*  1151 */         ensureEnumTypeIsMutable();
/*  1152 */         GeneratedMessage.Builder.addAll(values, this.enumType_);
/*  1153 */         return this;
/*       */       }
/*       */       public Builder clearEnumType() {
/*  1156 */         this.enumType_ = Collections.emptyList();
/*  1157 */         this.isEnumTypeMutable = false;
/*  1158 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureServiceIsMutable()
/*       */       {
/*  1166 */         if (!this.isServiceMutable) {
/*  1167 */           this.service_ = new ArrayList(this.service_);
/*  1168 */           this.isServiceMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.ServiceDescriptorProto> getServiceList() {
/*  1172 */         return Collections.unmodifiableList(this.service_);
/*       */       }
/*       */       public int getServiceCount() {
/*  1175 */         return this.service_.size();
/*       */       }
/*       */       public DescriptorProtos.ServiceDescriptorProto getService(int index) {
/*  1178 */         return (DescriptorProtos.ServiceDescriptorProto)this.service_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setService(int index, DescriptorProtos.ServiceDescriptorProto value) {
/*  1182 */         if (value == null) {
/*  1183 */           throw new NullPointerException();
/*       */         }
/*  1185 */         ensureServiceIsMutable();
/*  1186 */         this.service_.set(index, value);
/*  1187 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setService(int index, DescriptorProtos.ServiceDescriptorProto.Builder builderForValue) {
/*  1191 */         ensureServiceIsMutable();
/*  1192 */         this.service_.set(index, builderForValue.build());
/*  1193 */         return this;
/*       */       }
/*       */       public Builder addService(DescriptorProtos.ServiceDescriptorProto value) {
/*  1196 */         if (value == null) {
/*  1197 */           throw new NullPointerException();
/*       */         }
/*  1199 */         ensureServiceIsMutable();
/*  1200 */         this.service_.add(value);
/*  1201 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addService(DescriptorProtos.ServiceDescriptorProto.Builder builderForValue) {
/*  1205 */         ensureServiceIsMutable();
/*  1206 */         this.service_.add(builderForValue.build());
/*  1207 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllService(Iterable<? extends DescriptorProtos.ServiceDescriptorProto> values) {
/*  1211 */         ensureServiceIsMutable();
/*  1212 */         GeneratedMessage.Builder.addAll(values, this.service_);
/*  1213 */         return this;
/*       */       }
/*       */       public Builder clearService() {
/*  1216 */         this.service_ = Collections.emptyList();
/*  1217 */         this.isServiceMutable = false;
/*  1218 */         return this;
/*       */       }
/*       */ 
/*       */       private void ensureExtensionIsMutable()
/*       */       {
/*  1226 */         if (!this.isExtensionMutable) {
/*  1227 */           this.extension_ = new ArrayList(this.extension_);
/*  1228 */           this.isExtensionMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.FieldDescriptorProto> getExtensionList() {
/*  1232 */         return Collections.unmodifiableList(this.extension_);
/*       */       }
/*       */       public int getExtensionCount() {
/*  1235 */         return this.extension_.size();
/*       */       }
/*       */       public DescriptorProtos.FieldDescriptorProto getExtension(int index) {
/*  1238 */         return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto value) {
/*  1242 */         if (value == null) {
/*  1243 */           throw new NullPointerException();
/*       */         }
/*  1245 */         ensureExtensionIsMutable();
/*  1246 */         this.extension_.set(index, value);
/*  1247 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue) {
/*  1251 */         ensureExtensionIsMutable();
/*  1252 */         this.extension_.set(index, builderForValue.build());
/*  1253 */         return this;
/*       */       }
/*       */       public Builder addExtension(DescriptorProtos.FieldDescriptorProto value) {
/*  1256 */         if (value == null) {
/*  1257 */           throw new NullPointerException();
/*       */         }
/*  1259 */         ensureExtensionIsMutable();
/*  1260 */         this.extension_.add(value);
/*  1261 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addExtension(DescriptorProtos.FieldDescriptorProto.Builder builderForValue) {
/*  1265 */         ensureExtensionIsMutable();
/*  1266 */         this.extension_.add(builderForValue.build());
/*  1267 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllExtension(Iterable<? extends DescriptorProtos.FieldDescriptorProto> values) {
/*  1271 */         ensureExtensionIsMutable();
/*  1272 */         GeneratedMessage.Builder.addAll(values, this.extension_);
/*  1273 */         return this;
/*       */       }
/*       */       public Builder clearExtension() {
/*  1276 */         this.extension_ = Collections.emptyList();
/*  1277 */         this.isExtensionMutable = false;
/*  1278 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean hasOptions()
/*       */       {
/*  1285 */         return this.hasOptions;
/*       */       }
/*       */       public DescriptorProtos.FileOptions getOptions() {
/*  1288 */         return this.options_;
/*       */       }
/*       */       public Builder setOptions(DescriptorProtos.FileOptions value) {
/*  1291 */         if (value == null) {
/*  1292 */           throw new NullPointerException();
/*       */         }
/*  1294 */         this.hasOptions = true;
/*  1295 */         this.options_ = value;
/*  1296 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setOptions(DescriptorProtos.FileOptions.Builder builderForValue) {
/*  1300 */         this.hasOptions = true;
/*  1301 */         this.options_ = builderForValue.build();
/*  1302 */         return this;
/*       */       }
/*       */       public Builder mergeOptions(DescriptorProtos.FileOptions value) {
/*  1305 */         if ((this.hasOptions) && (this.options_ != DescriptorProtos.FileOptions.getDefaultInstance()))
/*       */         {
/*  1307 */           this.options_ = DescriptorProtos.FileOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
/*       */         }
/*       */         else {
/*  1310 */           this.options_ = value;
/*       */         }
/*  1312 */         this.hasOptions = true;
/*  1313 */         return this;
/*       */       }
/*       */       public Builder clearOptions() {
/*  1316 */         this.hasOptions = false;
/*  1317 */         this.options_ = DescriptorProtos.FileOptions.getDefaultInstance();
/*  1318 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static final class FileDescriptorSet extends GeneratedMessage
/*       */   {
/*   359 */     private static final FileDescriptorSet defaultInstance = new FileDescriptorSet(true);
/*       */     public static final int FILE_FIELD_NUMBER = 1;
/*       */     private List<DescriptorProtos.FileDescriptorProto> file_;
/*    70 */     private int memoizedSerializedSize = -1;
/*       */ 
/*       */     private FileDescriptorSet(Builder builder)
/*       */     {
/*    15 */       super();
/*       */     }
/*       */     private FileDescriptorSet(boolean noInit) {
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet getDefaultInstance() {
/*    21 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public FileDescriptorSet getDefaultInstanceForType() {
/*    25 */       return defaultInstance;
/*       */     }
/*       */ 
/*       */     public static final Descriptors.Descriptor getDescriptor()
/*       */     {
/*    30 */       return DescriptorProtos.internal_static_proto2_FileDescriptorSet_descriptor;
/*       */     }
/*       */ 
/*       */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */     {
/*    35 */       return DescriptorProtos.internal_static_proto2_FileDescriptorSet_fieldAccessorTable;
/*       */     }
/*       */ 
/*       */     public List<DescriptorProtos.FileDescriptorProto> getFileList()
/*       */     {
/*    42 */       return this.file_;
/*       */     }
/*       */     public int getFileCount() {
/*    45 */       return this.file_.size();
/*       */     }
/*       */     public DescriptorProtos.FileDescriptorProto getFile(int index) {
/*    48 */       return (DescriptorProtos.FileDescriptorProto)this.file_.get(index);
/*       */     }
/*       */ 
/*       */     private void initFields() {
/*    52 */       this.file_ = Collections.emptyList();
/*       */     }
/*       */     public final boolean isInitialized() {
/*    55 */       for (DescriptorProtos.FileDescriptorProto element : getFileList()) {
/*    56 */         if (!element.isInitialized()) return false;
/*       */       }
/*    58 */       return true;
/*       */     }
/*       */ 
/*       */     public void writeTo(CodedOutputStream output) throws IOException
/*       */     {
/*    63 */       getSerializedSize();
/*    64 */       for (DescriptorProtos.FileDescriptorProto element : getFileList()) {
/*    65 */         output.writeMessage(1, element);
/*       */       }
/*    67 */       getUnknownFields().writeTo(output);
/*       */     }
/*       */ 
/*       */     public int getSerializedSize()
/*       */     {
/*    72 */       int size = this.memoizedSerializedSize;
/*    73 */       if (size != -1) return size;
/*       */ 
/*    75 */       size = 0;
/*    76 */       for (DescriptorProtos.FileDescriptorProto element : getFileList()) {
/*    77 */         size += CodedOutputStream.computeMessageSize(1, element);
/*       */       }
/*       */ 
/*    80 */       size += getUnknownFields().getSerializedSize();
/*    81 */       this.memoizedSerializedSize = size;
/*    82 */       return size;
/*       */     }
/*       */ 
/*       */     protected Object writeReplace() throws ObjectStreamException
/*       */     {
/*    87 */       return super.writeReplace();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(ByteString data)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*    93 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*    99 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(byte[] data) throws InvalidProtocolBufferException
/*       */     {
/*   104 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*       */       throws InvalidProtocolBufferException
/*       */     {
/*   110 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(InputStream input) throws IOException
/*       */     {
/*   115 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*   121 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseDelimitedFrom(InputStream input) throws IOException
/*       */     {
/*   126 */       Builder builder = newBuilder();
/*   127 */       if (builder.mergeDelimitedFrom(input)) {
/*   128 */         return builder.buildParsed();
/*       */       }
/*   130 */       return null;
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*   137 */       Builder builder = newBuilder();
/*   138 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*   139 */         return builder.buildParsed();
/*       */       }
/*   141 */       return null;
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(CodedInputStream input)
/*       */       throws IOException
/*       */     {
/*   147 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*       */     }
/*       */ 
/*       */     public static FileDescriptorSet parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */       throws IOException
/*       */     {
/*   153 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*       */     }
/*       */ 
/*       */     public static Builder newBuilder() {
/*   157 */       return Builder.access$300(); } 
/*   158 */     public Builder newBuilderForType() { return newBuilder(); } 
/*       */     public static Builder newBuilder(FileDescriptorSet prototype) {
/*   160 */       return newBuilder().mergeFrom(prototype);
/*       */     }
/*   162 */     public Builder toBuilder() { return newBuilder(this);
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*   360 */       DescriptorProtos.internalForceInit();
/*   361 */       defaultInstance.initFields();
/*       */     }
/*       */ 
/*       */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*       */     {
/*   296 */       private List<DescriptorProtos.FileDescriptorProto> file_ = Collections.emptyList();
/*       */       private boolean isFileMutable;
/*       */ 
/*       */       public static final Descriptors.Descriptor getDescriptor()
/*       */       {
/*   168 */         return DescriptorProtos.internal_static_proto2_FileDescriptorSet_descriptor;
/*       */       }
/*       */ 
/*       */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*       */       {
/*   173 */         return DescriptorProtos.internal_static_proto2_FileDescriptorSet_fieldAccessorTable;
/*       */       }
/*       */ 
/*       */       private static Builder create()
/*       */       {
/*   181 */         return new Builder();
/*       */       }
/*       */ 
/*       */       public Builder clear() {
/*   185 */         super.clear();
/*   186 */         this.file_ = Collections.emptyList();
/*   187 */         this.isFileMutable = false;
/*   188 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder clone() {
/*   192 */         return create().mergeFrom(buildPartial());
/*       */       }
/*       */ 
/*       */       public Descriptors.Descriptor getDescriptorForType()
/*       */       {
/*   197 */         return DescriptorProtos.FileDescriptorSet.getDescriptor();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileDescriptorSet getDefaultInstanceForType() {
/*   201 */         return DescriptorProtos.FileDescriptorSet.getDefaultInstance();
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileDescriptorSet build() {
/*   205 */         DescriptorProtos.FileDescriptorSet result = buildPartial();
/*   206 */         if (!result.isInitialized()) {
/*   207 */           throw newUninitializedMessageException(result);
/*       */         }
/*   209 */         return result;
/*       */       }
/*       */ 
/*       */       private DescriptorProtos.FileDescriptorSet buildParsed() throws InvalidProtocolBufferException
/*       */       {
/*   214 */         DescriptorProtos.FileDescriptorSet result = buildPartial();
/*   215 */         if (!result.isInitialized()) {
/*   216 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*       */         }
/*       */ 
/*   219 */         return result;
/*       */       }
/*       */ 
/*       */       public DescriptorProtos.FileDescriptorSet buildPartial() {
/*   223 */         DescriptorProtos.FileDescriptorSet result = new DescriptorProtos.FileDescriptorSet(this, null);
/*   224 */         if (this.isFileMutable) {
/*   225 */           this.file_ = Collections.unmodifiableList(this.file_);
/*   226 */           this.isFileMutable = false;
/*       */         }
/*   228 */         DescriptorProtos.FileDescriptorSet.access$502(result, this.file_);
/*   229 */         return result;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(Message other) {
/*   233 */         if ((other instanceof DescriptorProtos.FileDescriptorSet)) {
/*   234 */           return mergeFrom((DescriptorProtos.FileDescriptorSet)other);
/*       */         }
/*   236 */         super.mergeFrom(other);
/*   237 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(DescriptorProtos.FileDescriptorSet other)
/*       */       {
/*   242 */         if (other == DescriptorProtos.FileDescriptorSet.getDefaultInstance()) return this;
/*   243 */         if (!other.file_.isEmpty()) {
/*   244 */           if (this.file_.isEmpty()) {
/*   245 */             this.file_ = other.file_;
/*   246 */             this.isFileMutable = false;
/*       */           } else {
/*   248 */             ensureFileIsMutable();
/*   249 */             this.file_.addAll(other.file_);
/*       */           }
/*       */         }
/*   252 */         mergeUnknownFields(other.getUnknownFields());
/*   253 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isInitialized() {
/*   257 */         for (DescriptorProtos.FileDescriptorProto element : getFileList()) {
/*   258 */           if (!element.isInitialized()) return false;
/*       */         }
/*   260 */         return true;
/*       */       }
/*       */ 
/*       */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*       */         throws IOException
/*       */       {
/*   267 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*       */         while (true)
/*       */         {
/*   271 */           int tag = input.readTag();
/*   272 */           switch (tag) {
/*       */           case 0:
/*   274 */             setUnknownFields(unknownFields.build());
/*   275 */             return this;
/*       */           default:
/*   277 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*       */               break;
/*   279 */             setUnknownFields(unknownFields.build());
/*   280 */             return this;
/*       */           case 10:
/*   285 */             DescriptorProtos.FileDescriptorProto.Builder subBuilder = DescriptorProtos.FileDescriptorProto.newBuilder();
/*   286 */             input.readMessage(subBuilder, extensionRegistry);
/*   287 */             addFile(subBuilder.buildPartial());
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       private void ensureFileIsMutable()
/*       */       {
/*   300 */         if (!this.isFileMutable) {
/*   301 */           this.file_ = new ArrayList(this.file_);
/*   302 */           this.isFileMutable = true;
/*       */         }
/*       */       }
/*       */ 
/*       */       public List<DescriptorProtos.FileDescriptorProto> getFileList() {
/*   306 */         return Collections.unmodifiableList(this.file_);
/*       */       }
/*       */       public int getFileCount() {
/*   309 */         return this.file_.size();
/*       */       }
/*       */       public DescriptorProtos.FileDescriptorProto getFile(int index) {
/*   312 */         return (DescriptorProtos.FileDescriptorProto)this.file_.get(index);
/*       */       }
/*       */ 
/*       */       public Builder setFile(int index, DescriptorProtos.FileDescriptorProto value) {
/*   316 */         if (value == null) {
/*   317 */           throw new NullPointerException();
/*       */         }
/*   319 */         ensureFileIsMutable();
/*   320 */         this.file_.set(index, value);
/*   321 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder setFile(int index, DescriptorProtos.FileDescriptorProto.Builder builderForValue) {
/*   325 */         ensureFileIsMutable();
/*   326 */         this.file_.set(index, builderForValue.build());
/*   327 */         return this;
/*       */       }
/*       */       public Builder addFile(DescriptorProtos.FileDescriptorProto value) {
/*   330 */         if (value == null) {
/*   331 */           throw new NullPointerException();
/*       */         }
/*   333 */         ensureFileIsMutable();
/*   334 */         this.file_.add(value);
/*   335 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addFile(DescriptorProtos.FileDescriptorProto.Builder builderForValue) {
/*   339 */         ensureFileIsMutable();
/*   340 */         this.file_.add(builderForValue.build());
/*   341 */         return this;
/*       */       }
/*       */ 
/*       */       public Builder addAllFile(Iterable<? extends DescriptorProtos.FileDescriptorProto> values) {
/*   345 */         ensureFileIsMutable();
/*   346 */         GeneratedMessage.Builder.addAll(values, this.file_);
/*   347 */         return this;
/*       */       }
/*       */       public Builder clearFile() {
/*   350 */         this.file_ = Collections.emptyList();
/*   351 */         this.isFileMutable = false;
/*   352 */         return this;
/*       */       }
/*       */     }
/*       */   }
/*       */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.DescriptorProtos
 * JD-Core Version:    0.6.0
 */