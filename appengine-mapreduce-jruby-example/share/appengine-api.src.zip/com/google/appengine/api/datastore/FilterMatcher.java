/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ class FilterMatcher
/*     */ {
/*  67 */   public static final FilterMatcher MATCH_ALL = new FilterMatcher()
/*     */   {
/*     */     public void addFilter(DatastorePb.Query.Filter filter) {
/*  70 */       throw new UnsupportedOperationException("FilterMatcher.MATCH_ALL is immutable");
/*     */     }
/*     */ 
/*     */     public boolean matches(List<Comparable<Object>> values)
/*     */     {
/*  75 */       return true;
/*     */     }
/*     */ 
/*     */     boolean matchesRange(Comparable<Object> value)
/*     */     {
/*  80 */       return true;
/*     */     }
/*  67 */   };
/*     */ 
/*  96 */   Comparable<Object> min = NoValue.INSTANCE;
/*     */   boolean minInclusive;
/*  99 */   Comparable<Object> max = NoValue.INSTANCE;
/*     */   boolean maxInclusive;
/* 101 */   List<Comparable<Object>> equalValues = new ArrayList();
/*     */ 
/*     */   public boolean considerValueForOrder(Comparable<Object> value)
/*     */   {
/* 110 */     return matchesRange(value);
/*     */   }
/*     */ 
/*     */   boolean matchesRange(Comparable<Object> value)
/*     */   {
/* 115 */     if (this.min != NoValue.INSTANCE) {
/* 116 */       int cmp = EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(value, this.min);
/* 117 */       if ((cmp < 0) || ((cmp == 0) && (!this.minInclusive))) {
/* 118 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 122 */     if (this.max != NoValue.INSTANCE) {
/* 123 */       int cmp = EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(value, this.max);
/* 124 */       if ((cmp > 0) || ((cmp == 0) && (!this.maxInclusive))) {
/* 125 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean matches(List<Comparable<Object>> values)
/*     */   {
/* 136 */     Collections.sort(values, EntityProtoComparators.MULTI_TYPE_COMPARATOR);
/*     */ 
/* 138 */     for (Comparable eqValue : this.equalValues) {
/* 139 */       if (Collections.binarySearch(values, eqValue, EntityProtoComparators.MULTI_TYPE_COMPARATOR) < 0)
/*     */       {
/* 141 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 146 */     for (Comparable value : values) {
/* 147 */       if (matchesRange(value)) {
/* 148 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   public void addFilter(DatastorePb.Query.Filter filter) {
/* 156 */     Comparable value = DataTypeTranslator.getComparablePropertyValue(filter.getProperty(0));
/* 157 */     switch (2.$SwitchMap$com$google$apphosting$api$DatastorePb$Query$Filter$Operator[filter.getOpEnum().ordinal()]) {
/*     */     case 1:
/* 159 */       this.equalValues.add(value);
/* 160 */       break;
/*     */     case 2:
/* 162 */       if ((this.min != NoValue.INSTANCE) && (EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(this.min, value) > 0))
/*     */         break;
/* 164 */       this.min = value;
/* 165 */       this.minInclusive = false; break;
/*     */     case 3:
/* 169 */       if ((this.min != NoValue.INSTANCE) && (EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(this.min, value) >= 0))
/*     */         break;
/* 171 */       this.min = value;
/* 172 */       this.minInclusive = true; break;
/*     */     case 4:
/* 176 */       if ((this.max != NoValue.INSTANCE) && (EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(this.max, value) < 0))
/*     */         break;
/* 178 */       this.max = value;
/* 179 */       this.maxInclusive = false; break;
/*     */     case 5:
/* 183 */       if ((this.max != NoValue.INSTANCE) && (EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(this.max, value) <= 0))
/*     */         break;
/* 185 */       this.max = value;
/* 186 */       this.maxInclusive = true; break;
/*     */     case 6:
/* 190 */       break;
/*     */     default:
/* 192 */       throw new IllegalArgumentException("Unable to perform filter using operator " + filter.getOp());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 199 */     StringBuilder result = new StringBuilder("FilterMatcher [");
/*     */ 
/* 201 */     if ((this.min != NoValue.INSTANCE) || (this.max != NoValue.INSTANCE)) {
/* 202 */       if (this.min != NoValue.INSTANCE) {
/* 203 */         result.append(this.min);
/* 204 */         result.append(this.minInclusive ? " <= " : " < ");
/*     */       }
/* 206 */       result.append("X");
/* 207 */       if (this.max != NoValue.INSTANCE) {
/* 208 */         result.append(this.maxInclusive ? " <= " : " < ");
/* 209 */         result.append(this.max);
/*     */       }
/* 211 */       if (!this.equalValues.isEmpty()) {
/* 212 */         result.append(" && ");
/*     */       }
/*     */     }
/* 215 */     if (!this.equalValues.isEmpty()) {
/* 216 */       result.append("X CONTAINS ");
/* 217 */       result.append(this.equalValues);
/*     */     }
/*     */ 
/* 220 */     result.append("]");
/* 221 */     return result.toString();
/*     */   }
/*     */ 
/*     */   static class NoValue
/*     */     implements Comparable<Object>
/*     */   {
/*  86 */     static final NoValue INSTANCE = new NoValue();
/*     */ 
/*     */     public int compareTo(Object o)
/*     */     {
/*  92 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.FilterMatcher
 * JD-Core Version:    0.6.0
 */