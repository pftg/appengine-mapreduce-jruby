/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.Set;
/*     */ 
/*     */ class PreparedMultiQuery extends BasePreparedQuery.UncompilablePreparedQuery
/*     */ {
/*     */   private final ApiProxy.ApiConfig apiConfig;
/*     */   private final DatastoreServiceConfig datastoreServiceConfig;
/*     */   private final MultiQueryBuilder queryBuilder;
/*     */   private final EntityComparator entityComparator;
/*     */   private final Transaction txn;
/*     */ 
/*     */   PreparedMultiQuery(ApiProxy.ApiConfig apiConfig, DatastoreServiceConfig datastoreServiceConfig, MultiQueryBuilder queryBuilder, Transaction txn)
/*     */   {
/*  53 */     this.apiConfig = apiConfig;
/*  54 */     this.datastoreServiceConfig = datastoreServiceConfig;
/*  55 */     this.txn = txn;
/*  56 */     this.queryBuilder = queryBuilder;
/*     */ 
/*  58 */     if (queryBuilder.hasParallelQueries()) {
/*  59 */       if (queryBuilder.isKeysOnly()) {
/*  60 */         for (Query.SortPredicate sp : queryBuilder.getSortPredicates()) {
/*  61 */           if (!sp.getPropertyName().equals("__key__")) {
/*  62 */             throw new IllegalArgumentException("The provided keys-only multi-query needs to perform some sorting in memory.  As a result, this query can only be sorted by the key property as this is the only property that is available in memory.");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  70 */       this.entityComparator = new EntityComparator(queryBuilder.getSortPredicates());
/*     */     } else {
/*  72 */       this.entityComparator = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<PreparedQuery> prepareQueries(List<Query> queries)
/*     */   {
/*  82 */     List preparedQueries = new ArrayList(queries.size());
/*  83 */     for (Query q : queries) {
/*  84 */       preparedQueries.add(new PreparedQueryImpl(this.apiConfig, this.datastoreServiceConfig, q, this.txn));
/*     */     }
/*  86 */     return preparedQueries;
/*     */   }
/*     */ 
/*     */   Iterator<Entity> makeHeapIterator(List<PreparedQuery> preparedQueries, FetchOptions fetchOptions)
/*     */   {
/* 209 */     PriorityQueue heap = new PriorityQueue();
/*     */ 
/* 211 */     for (PreparedQuery pq : preparedQueries) {
/* 212 */       Iterator iter = pq.asIterator(fetchOptions);
/* 213 */       if (iter.hasNext()) {
/* 214 */         heap.add(new EntitySource(this.entityComparator, iter));
/*     */       }
/*     */     }
/* 217 */     return new HeapIterator(heap);
/*     */   }
/*     */ 
/*     */   static Entity nextResult(PriorityQueue<EntitySource> availableEntitySources)
/*     */   {
/* 225 */     EntitySource current = (EntitySource)availableEntitySources.poll();
/* 226 */     if (current == null)
/*     */     {
/* 228 */       return null;
/*     */     }
/* 230 */     Entity result = current.currentEntity;
/*     */ 
/* 232 */     current.advance();
/* 233 */     if (current.currentEntity != null)
/*     */     {
/* 235 */       availableEntitySources.add(current);
/*     */     }
/*     */ 
/* 239 */     return result;
/*     */   }
/*     */ 
/*     */   public Entity asSingleEntity()
/*     */     throws PreparedQuery.TooManyResultsException
/*     */   {
/* 298 */     List result = asList(FetchOptions.Builder.withLimit(2));
/* 299 */     if (result.size() == 1)
/* 300 */       return (Entity)result.get(0);
/* 301 */     if (result.size() > 1) {
/* 302 */       throw new PreparedQuery.TooManyResultsException();
/*     */     }
/* 304 */     return null;
/*     */   }
/*     */ 
/*     */   public int countEntities()
/*     */   {
/* 309 */     int result = 0;
/* 310 */     for (List queries : this.queryBuilder) {
/* 311 */       List preparedQueries = prepareQueries(queries);
/* 312 */       for (PreparedQuery query : preparedQueries) {
/* 313 */         result += query.countEntities();
/* 314 */         if (result >= 1000) {
/* 315 */           return 1000;
/*     */         }
/*     */       }
/*     */     }
/* 319 */     return result;
/*     */   }
/*     */ 
/*     */   public Iterator<Entity> asIterator(FetchOptions fetchOptions)
/*     */   {
/* 333 */     if ((fetchOptions.getOffset() != null) || (fetchOptions.getLimit() != null)) {
/* 334 */       FetchOptions override = new FetchOptions(fetchOptions);
/* 335 */       if (fetchOptions.getOffset() != null) {
/* 336 */         override.clearOffset();
/* 337 */         if (fetchOptions.getLimit() != null)
/*     */         {
/* 340 */           override.limit(fetchOptions.getOffset().intValue() + fetchOptions.getLimit().intValue());
/*     */         }
/*     */       }
/* 343 */       return new SlicingIterator(new DedupingMultiQueryIterator(override), fetchOptions.getOffset(), fetchOptions.getLimit());
/*     */     }
/*     */ 
/* 351 */     return new DedupingMultiQueryIterator(fetchOptions);
/*     */   }
/*     */ 
/*     */   public List<Entity> asList(FetchOptions fetchOptions)
/*     */   {
/* 356 */     FetchOptions override = new FetchOptions(fetchOptions);
/*     */ 
/* 363 */     if (override.getPrefetchSize() == null) {
/* 364 */       override.prefetchSize(2147483647);
/*     */     }
/* 366 */     if (override.getChunkSize() == null) {
/* 367 */       override.chunkSize(2147483647);
/*     */     }
/*     */ 
/* 370 */     List results = new ArrayList();
/* 371 */     for (Entity e : asIterable(override)) {
/* 372 */       results.add(e);
/*     */     }
/* 374 */     return results;
/*     */   }
/*     */ 
/*     */   static final class EntityComparator
/*     */     implements Comparator<Entity>
/*     */   {
/*     */     private final EntityProtoComparators.EntityProtoComparator delegate;
/*     */ 
/*     */     EntityComparator(List<Query.SortPredicate> sortPreds)
/*     */     {
/* 281 */       this.delegate = new EntityProtoComparators.EntityProtoComparator(sortPredicatesToOrders(sortPreds));
/*     */     }
/*     */ 
/*     */     private static List<DatastorePb.Query.Order> sortPredicatesToOrders(List<Query.SortPredicate> sortPreds) {
/* 285 */       List orders = new ArrayList();
/* 286 */       for (Query.SortPredicate sp : sortPreds) {
/* 287 */         orders.add(QueryTranslator.convertSortPredicateToPb(sp));
/*     */       }
/* 289 */       return orders;
/*     */     }
/*     */ 
/*     */     public int compare(Entity e1, Entity e2) {
/* 293 */       return this.delegate.compare(e1.getEntityProto(), e2.getEntityProto());
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class EntitySource
/*     */     implements Comparable<EntitySource>
/*     */   {
/*     */     private final PreparedMultiQuery.EntityComparator entityComparator;
/*     */     private final Iterator<Entity> source;
/*     */     private Entity currentEntity;
/*     */ 
/*     */     EntitySource(PreparedMultiQuery.EntityComparator entityComparator, Iterator<Entity> source)
/*     */     {
/* 253 */       this.entityComparator = entityComparator;
/* 254 */       this.source = source;
/* 255 */       if (!source.hasNext())
/*     */       {
/* 257 */         throw new IllegalArgumentException("Source iterator has no data.");
/*     */       }
/* 259 */       this.currentEntity = ((Entity)source.next());
/*     */     }
/*     */ 
/*     */     private void advance() {
/* 263 */       this.currentEntity = (this.source.hasNext() ? (Entity)this.source.next() : null);
/*     */     }
/*     */ 
/*     */     public int compareTo(EntitySource entitySource) {
/* 267 */       return this.entityComparator.compare(this.currentEntity, entitySource.currentEntity);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class HeapIterator extends AbstractIterator<Entity>
/*     */   {
/*     */     private final PriorityQueue<PreparedMultiQuery.EntitySource> heap;
/*     */ 
/*     */     HeapIterator(PriorityQueue<PreparedMultiQuery.EntitySource> heap)
/*     */     {
/* 192 */       this.heap = heap;
/*     */     }
/*     */ 
/*     */     protected Entity computeNext()
/*     */     {
/* 198 */       Entity result = PreparedMultiQuery.nextResult(this.heap);
/* 199 */       if (result == null) {
/* 200 */         endOfData();
/*     */       }
/* 202 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DedupingMultiQueryIterator extends AbstractIterator<Entity>
/*     */   {
/*     */     private final Iterator<List<Query>> multiQueryIterator;
/*     */     private final FetchOptions baseFetchOptions;
/* 101 */     private final Set<Key> returnedKeys = new HashSet();
/*     */ 
/* 103 */     private Iterator<Entity> currentIterator = new Iterator()
/*     */     {
/*     */       public boolean hasNext() {
/* 106 */         return false;
/*     */       }
/*     */ 
/*     */       public Entity next() {
/* 110 */         throw new NoSuchElementException();
/*     */       }
/*     */ 
/*     */       public void remove() {
/* 114 */         throw new NoSuchElementException();
/*     */       }
/* 103 */     };
/*     */ 
/*     */     public DedupingMultiQueryIterator(FetchOptions fetchOptions)
/*     */     {
/* 119 */       this.multiQueryIterator = PreparedMultiQuery.this.queryBuilder.iterator();
/* 120 */       this.baseFetchOptions = fetchOptions;
/*     */     }
/*     */ 
/*     */     private FetchOptions getFetchOptions()
/*     */     {
/* 127 */       if (this.baseFetchOptions.getLimit() != null) {
/* 128 */         int limit = this.baseFetchOptions.getLimit().intValue() - this.returnedKeys.size();
/* 129 */         if (limit > 0) {
/* 130 */           return new FetchOptions(this.baseFetchOptions).clearLimit().limit(limit);
/*     */         }
/* 132 */         return null;
/*     */       }
/*     */ 
/* 135 */       return this.baseFetchOptions;
/*     */     }
/*     */ 
/*     */     Iterator<Entity> getNextIterator()
/*     */     {
/* 142 */       FetchOptions fetchOptions = getFetchOptions();
/* 143 */       if (fetchOptions == null) {
/* 144 */         return null;
/*     */       }
/*     */ 
/* 148 */       while (this.multiQueryIterator.hasNext()) {
/* 149 */         List queries = PreparedMultiQuery.this.prepareQueries((List)this.multiQueryIterator.next());
/*     */         Iterator result;
/*     */         Iterator result;
/* 152 */         if (queries.size() == 1)
/*     */         {
/* 154 */           result = ((PreparedQuery)queries.get(0)).asIterator(fetchOptions);
/*     */         }
/*     */         else
/*     */         {
/* 158 */           result = PreparedMultiQuery.this.makeHeapIterator(queries, fetchOptions);
/*     */         }
/*     */ 
/* 161 */         if (result.hasNext()) {
/* 162 */           return result;
/*     */         }
/*     */       }
/* 165 */       return null;
/*     */     }
/*     */ 
/*     */     protected Entity computeNext()
/*     */     {
/* 170 */       Entity result = null;
/*     */       do {
/* 172 */         if (!this.currentIterator.hasNext()) {
/* 173 */           this.currentIterator = getNextIterator();
/* 174 */           if (this.currentIterator == null)
/*     */           {
/* 176 */             endOfData();
/* 177 */             return null;
/*     */           }
/*     */         }
/*     */ 
/* 181 */         result = (Entity)this.currentIterator.next();
/* 182 */       }while (this.returnedKeys.contains(result.getKey()));
/* 183 */       this.returnedKeys.add(result.getKey());
/* 184 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.PreparedMultiQuery
 * JD-Core Version:    0.6.0
 */