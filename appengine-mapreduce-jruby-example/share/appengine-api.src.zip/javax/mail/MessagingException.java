/*    */ package javax.mail;
/*    */ 
/*    */ public class MessagingException extends Exception
/*    */ {
/*    */   private Exception next;
/*    */ 
/*    */   public MessagingException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MessagingException(String message)
/*    */   {
/* 34 */     super(message);
/*    */   }
/*    */ 
/*    */   public MessagingException(String message, Exception cause) {
/* 38 */     super(message, cause);
/* 39 */     this.next = cause;
/*    */   }
/*    */ 
/*    */   public Exception getNextException() {
/* 43 */     return this.next;
/*    */   }
/*    */ 
/*    */   public synchronized boolean setNextException(Exception cause) {
/* 47 */     if (this.next == null) {
/* 48 */       initCause(cause);
/* 49 */       this.next = cause;
/* 50 */       return true;
/* 51 */     }if ((this.next instanceof MessagingException)) {
/* 52 */       return ((MessagingException)this.next).setNextException(cause);
/*    */     }
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 59 */     Exception next = getNextException();
/* 60 */     if (next == null) {
/* 61 */       return super.getMessage();
/*    */     }
/* 63 */     return super.getMessage() + " (" + next.getClass().getName() + ": " + next.getMessage() + ")";
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.MessagingException
 * JD-Core Version:    0.6.0
 */