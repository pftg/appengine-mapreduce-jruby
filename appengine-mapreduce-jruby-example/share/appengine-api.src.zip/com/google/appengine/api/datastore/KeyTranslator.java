/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Path;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Path.Element;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*    */ import java.util.List;
/*    */ 
/*    */ class KeyTranslator
/*    */ {
/*    */   public static Key createFromPb(OnestoreEntity.Reference reference)
/*    */   {
/* 22 */     Key parentKey = null;
/* 23 */     OnestoreEntity.Path path = reference.getPath();
/* 24 */     List elements = path.elements();
/* 25 */     if (elements.isEmpty()) {
/* 26 */       throw new IllegalArgumentException("Invalid Key PB: no elements.");
/*    */     }
/*    */ 
/* 29 */     AppIdNamespace appIdNamespace = new AppIdNamespace(reference.getApp(), reference.hasNameSpace() ? reference.getNameSpace() : "");
/*    */ 
/* 32 */     for (OnestoreEntity.Path.Element e : elements) {
/* 33 */       String kind = e.getType();
/* 34 */       if ((e.hasName()) && (e.hasId()))
/* 35 */         throw new IllegalArgumentException("Invalid Key PB: both id and name are set.");
/* 36 */       if (e.hasName())
/* 37 */         parentKey = new Key(kind, parentKey, 0L, e.getName(), appIdNamespace);
/* 38 */       else if (e.hasId()) {
/* 39 */         parentKey = new Key(kind, parentKey, e.getId(), null, appIdNamespace);
/*    */       }
/*    */       else
/*    */       {
/* 45 */         parentKey = new Key(kind, parentKey, 0L, null, appIdNamespace);
/*    */       }
/*    */     }
/*    */ 
/* 49 */     return parentKey;
/*    */   }
/*    */ 
/*    */   public static OnestoreEntity.Reference convertToPb(Key key) {
/* 53 */     OnestoreEntity.Reference reference = new OnestoreEntity.Reference();
/*    */ 
/* 55 */     reference.setApp(key.getAppIdNamespace().getAppId());
/* 56 */     String nameSpace = key.getAppIdNamespace().getNamespace();
/* 57 */     if (nameSpace.length() != 0) {
/* 58 */       reference.setNameSpace(nameSpace);
/*    */     }
/*    */ 
/* 61 */     OnestoreEntity.Path path = reference.getMutablePath();
/* 62 */     while (key != null) {
/* 63 */       OnestoreEntity.Path.Element pathElement = new OnestoreEntity.Path.Element();
/* 64 */       pathElement.setType(key.getKind());
/* 65 */       if (key.getName() != null)
/* 66 */         pathElement.setName(key.getName());
/* 67 */       else if (key.getId() != 0L) {
/* 68 */         pathElement.setId(key.getId());
/*    */       }
/* 70 */       path.insertElement(0, pathElement);
/* 71 */       key = key.getParent();
/*    */     }
/* 73 */     return reference;
/*    */   }
/*    */ 
/*    */   public static void updateKey(OnestoreEntity.Reference reference, Key key)
/*    */   {
/* 80 */     if (key.getName() == null) {
/* 81 */       OnestoreEntity.Path path = reference.getPath();
/* 82 */       key.setId(path.getElement(path.elementSize() - 1).getId());
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.KeyTranslator
 * JD-Core Version:    0.6.0
 */