/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSequentialList;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public final class LinkedListMultimap<K, V>
/*     */   implements ListMultimap<K, V>, Serializable
/*     */ {
/*     */   private transient Node<K, V> head;
/*     */   private transient Node<K, V> tail;
/*     */   private transient Multiset<K> keyCount;
/*     */   private transient Map<K, Node<K, V>> keyToKeyHead;
/*     */   private transient Map<K, Node<K, V>> keyToKeyTail;
/*     */   private transient Set<K> keySet;
/*     */   private transient Multiset<K> keys;
/*     */   private transient Collection<V> valuesCollection;
/*     */   private transient Collection<Map.Entry<K, V>> entries;
/*     */   private transient Map<K, Collection<V>> map;
/*     */ 
/*     */   @GwtIncompatible("java serialization not supported")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> LinkedListMultimap<K, V> create()
/*     */   {
/* 136 */     return new LinkedListMultimap();
/*     */   }
/*     */ 
/*     */   public static <K, V> LinkedListMultimap<K, V> create(int expectedKeys)
/*     */   {
/* 147 */     return new LinkedListMultimap(expectedKeys);
/*     */   }
/*     */ 
/*     */   public static <K, V> LinkedListMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*     */   {
/* 159 */     return new LinkedListMultimap(multimap);
/*     */   }
/*     */ 
/*     */   private LinkedListMultimap() {
/* 163 */     this.keyCount = LinkedHashMultiset.create();
/* 164 */     this.keyToKeyHead = Maps.newHashMap();
/* 165 */     this.keyToKeyTail = Maps.newHashMap();
/*     */   }
/*     */ 
/*     */   private LinkedListMultimap(int expectedKeys) {
/* 169 */     this.keyCount = LinkedHashMultiset.create(expectedKeys);
/* 170 */     this.keyToKeyHead = Maps.newHashMapWithExpectedSize(expectedKeys);
/* 171 */     this.keyToKeyTail = Maps.newHashMapWithExpectedSize(expectedKeys);
/*     */   }
/*     */ 
/*     */   private LinkedListMultimap(Multimap<? extends K, ? extends V> multimap) {
/* 175 */     this(multimap.keySet().size());
/* 176 */     putAll(multimap);
/*     */   }
/*     */ 
/*     */   private Node<K, V> addNode(@Nullable K key, @Nullable V value, @Nullable Node<K, V> nextSibling)
/*     */   {
/* 187 */     Node node = new Node(key, value);
/* 188 */     if (this.head == null) {
/* 189 */       this.head = (this.tail = node);
/* 190 */       this.keyToKeyHead.put(key, node);
/* 191 */       this.keyToKeyTail.put(key, node);
/* 192 */     } else if (nextSibling == null) {
/* 193 */       this.tail.next = node;
/* 194 */       node.previous = this.tail;
/* 195 */       Node keyTail = (Node)this.keyToKeyTail.get(key);
/* 196 */       if (keyTail == null) {
/* 197 */         this.keyToKeyHead.put(key, node);
/*     */       } else {
/* 199 */         keyTail.nextSibling = node;
/* 200 */         node.previousSibling = keyTail;
/*     */       }
/* 202 */       this.keyToKeyTail.put(key, node);
/* 203 */       this.tail = node;
/*     */     } else {
/* 205 */       node.previous = nextSibling.previous;
/* 206 */       node.previousSibling = nextSibling.previousSibling;
/* 207 */       node.next = nextSibling;
/* 208 */       node.nextSibling = nextSibling;
/* 209 */       if (nextSibling.previousSibling == null)
/* 210 */         this.keyToKeyHead.put(key, node);
/*     */       else {
/* 212 */         nextSibling.previousSibling.nextSibling = node;
/*     */       }
/* 214 */       if (nextSibling.previous == null)
/* 215 */         this.head = node;
/*     */       else {
/* 217 */         nextSibling.previous.next = node;
/*     */       }
/* 219 */       nextSibling.previous = node;
/* 220 */       nextSibling.previousSibling = node;
/*     */     }
/* 222 */     this.keyCount.add(key);
/* 223 */     return node;
/*     */   }
/*     */ 
/*     */   private void removeNode(Node<K, V> node)
/*     */   {
/* 232 */     if (node.previous != null)
/* 233 */       node.previous.next = node.next;
/*     */     else {
/* 235 */       this.head = node.next;
/*     */     }
/* 237 */     if (node.next != null)
/* 238 */       node.next.previous = node.previous;
/*     */     else {
/* 240 */       this.tail = node.previous;
/*     */     }
/* 242 */     if (node.previousSibling != null)
/* 243 */       node.previousSibling.nextSibling = node.nextSibling;
/* 244 */     else if (node.nextSibling != null)
/* 245 */       this.keyToKeyHead.put(node.key, node.nextSibling);
/*     */     else {
/* 247 */       this.keyToKeyHead.remove(node.key);
/*     */     }
/* 249 */     if (node.nextSibling != null)
/* 250 */       node.nextSibling.previousSibling = node.previousSibling;
/* 251 */     else if (node.previousSibling != null)
/* 252 */       this.keyToKeyTail.put(node.key, node.previousSibling);
/*     */     else {
/* 254 */       this.keyToKeyTail.remove(node.key);
/*     */     }
/* 256 */     this.keyCount.remove(node.key);
/*     */   }
/*     */ 
/*     */   private void removeAllNodes(@Nullable Object key)
/*     */   {
/* 261 */     for (Iterator i = new ValueForKeyIterator(key); i.hasNext(); ) {
/* 262 */       i.next();
/* 263 */       i.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void checkElement(@Nullable Object node)
/*     */   {
/* 269 */     if (node == null)
/* 270 */       throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 422 */     return this.keyCount.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 426 */     return this.head == null;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(@Nullable Object key) {
/* 430 */     return this.keyToKeyHead.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(@Nullable Object value) {
/* 434 */     for (Iterator i = new NodeIterator(null); i.hasNext(); ) {
/* 435 */       if (Objects.equal(((Node)i.next()).value, value)) {
/* 436 */         return true;
/*     */       }
/*     */     }
/* 439 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean containsEntry(@Nullable Object key, @Nullable Object value) {
/* 443 */     for (Iterator i = new ValueForKeyIterator(key); i.hasNext(); ) {
/* 444 */       if (Objects.equal(i.next(), value)) {
/* 445 */         return true;
/*     */       }
/*     */     }
/* 448 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean put(@Nullable K key, @Nullable V value)
/*     */   {
/* 461 */     addNode(key, value, null);
/* 462 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean remove(@Nullable Object key, @Nullable Object value) {
/* 466 */     Iterator values = new ValueForKeyIterator(key);
/* 467 */     while (values.hasNext()) {
/* 468 */       if (Objects.equal(values.next(), value)) {
/* 469 */         values.remove();
/* 470 */         return true;
/*     */       }
/*     */     }
/* 473 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean putAll(@Nullable K key, Iterable<? extends V> values)
/*     */   {
/* 479 */     boolean changed = false;
/* 480 */     for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 481 */       changed |= put(key, value);
/*     */     }
/* 483 */     return changed;
/*     */   }
/*     */ 
/*     */   public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
/* 487 */     boolean changed = false;
/* 488 */     for (Map.Entry entry : multimap.entries()) {
/* 489 */       changed |= put(entry.getKey(), entry.getValue());
/*     */     }
/* 491 */     return changed;
/*     */   }
/*     */ 
/*     */   public List<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/*     */   {
/* 505 */     List oldValues = getCopy(key);
/* 506 */     ListIterator keyValues = new ValueForKeyIterator(key);
/* 507 */     Iterator newValues = values.iterator();
/*     */ 
/* 510 */     while ((keyValues.hasNext()) && (newValues.hasNext())) {
/* 511 */       keyValues.next();
/* 512 */       keyValues.set(newValues.next());
/*     */     }
/*     */ 
/* 516 */     while (keyValues.hasNext()) {
/* 517 */       keyValues.next();
/* 518 */       keyValues.remove();
/*     */     }
/*     */ 
/* 522 */     while (newValues.hasNext()) {
/* 523 */       keyValues.add(newValues.next());
/*     */     }
/*     */ 
/* 526 */     return oldValues;
/*     */   }
/*     */ 
/*     */   private List<V> getCopy(@Nullable Object key) {
/* 530 */     return Collections.unmodifiableList(Lists.newArrayList(new ValueForKeyIterator(key)));
/*     */   }
/*     */ 
/*     */   public List<V> removeAll(@Nullable Object key)
/*     */   {
/* 540 */     List oldValues = getCopy(key);
/* 541 */     removeAllNodes(key);
/* 542 */     return oldValues;
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 546 */     this.head = null;
/* 547 */     this.tail = null;
/* 548 */     this.keyCount.clear();
/* 549 */     this.keyToKeyHead.clear();
/* 550 */     this.keyToKeyTail.clear();
/*     */   }
/*     */ 
/*     */   public List<V> get(@Nullable K key)
/*     */   {
/* 565 */     return new AbstractSequentialList(key) {
/*     */       public int size() {
/* 567 */         return LinkedListMultimap.this.keyCount.count(this.val$key);
/*     */       }
/*     */       public ListIterator<V> listIterator(int index) {
/* 570 */         return new LinkedListMultimap.ValueForKeyIterator(LinkedListMultimap.this, this.val$key, index);
/*     */       }
/*     */       public boolean removeAll(Collection<?> c) {
/* 573 */         return Iterators.removeAll(iterator(), c);
/*     */       }
/*     */       public boolean retainAll(Collection<?> c) {
/* 576 */         return Iterators.retainAll(iterator(), c);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/* 584 */     Set result = this.keySet;
/* 585 */     if (result == null)
/* 586 */       this.keySet = (result = new AbstractSet() {
/*     */         public int size() {
/* 588 */           return LinkedListMultimap.this.keyCount.elementSet().size();
/*     */         }
/*     */         public Iterator<K> iterator() {
/* 591 */           return new LinkedListMultimap.DistinctKeyIterator(LinkedListMultimap.this, null);
/*     */         }
/*     */         public boolean contains(Object key) {
/* 594 */           return LinkedListMultimap.this.keyCount.contains(key);
/*     */         }
/*     */       });
/* 598 */     return result;
/*     */   }
/*     */ 
/*     */   public Multiset<K> keys()
/*     */   {
/* 604 */     Multiset result = this.keys;
/* 605 */     if (result == null) {
/* 606 */       this.keys = (result = new MultisetView(null));
/*     */     }
/* 608 */     return result;
/*     */   }
/*     */ 
/*     */   public Collection<V> values()
/*     */   {
/* 726 */     Collection result = this.valuesCollection;
/* 727 */     if (result == null)
/* 728 */       this.valuesCollection = (result = new AbstractCollection() {
/*     */         public int size() {
/* 730 */           return LinkedListMultimap.this.keyCount.size();
/*     */         }
/*     */         public Iterator<V> iterator() {
/* 733 */           Iterator nodes = new LinkedListMultimap.NodeIterator(LinkedListMultimap.this, null);
/* 734 */           return new Iterator(nodes) {
/*     */             public boolean hasNext() {
/* 736 */               return this.val$nodes.hasNext();
/*     */             }
/*     */             public V next() {
/* 739 */               return ((LinkedListMultimap.Node)this.val$nodes.next()).value;
/*     */             }
/*     */             public void remove() {
/* 742 */               this.val$nodes.remove();
/*     */             } } ;
/*     */         }
/*     */       });
/* 748 */     return result;
/*     */   }
/*     */ 
/*     */   public Collection<Map.Entry<K, V>> entries()
/*     */   {
/* 769 */     Collection result = this.entries;
/* 770 */     if (result == null)
/* 771 */       this.entries = (result = new AbstractCollection() {
/*     */         public int size() {
/* 773 */           return LinkedListMultimap.this.keyCount.size();
/*     */         }
/*     */ 
/*     */         public Iterator<Map.Entry<K, V>> iterator() {
/* 777 */           Iterator nodes = new LinkedListMultimap.NodeIterator(LinkedListMultimap.this, null);
/* 778 */           return new Iterator(nodes) {
/*     */             public boolean hasNext() {
/* 780 */               return this.val$nodes.hasNext();
/*     */             }
/*     */ 
/*     */             public Map.Entry<K, V> next() {
/* 784 */               LinkedListMultimap.Node node = (LinkedListMultimap.Node)this.val$nodes.next();
/* 785 */               return new AbstractMapEntry(node) {
/*     */                 public K getKey() {
/* 787 */                   return this.val$node.key;
/*     */                 }
/*     */                 public V getValue() {
/* 790 */                   return this.val$node.value;
/*     */                 }
/*     */                 public V setValue(V value) {
/* 793 */                   Object oldValue = this.val$node.value;
/* 794 */                   this.val$node.value = value;
/* 795 */                   return oldValue;
/*     */                 } } ;
/*     */             }
/*     */ 
/*     */             public void remove() {
/* 801 */               this.val$nodes.remove();
/*     */             } } ;
/*     */         }
/*     */       });
/* 807 */     return result;
/*     */   }
/*     */ 
/*     */   public Map<K, Collection<V>> asMap()
/*     */   {
/* 848 */     Map result = this.map;
/* 849 */     if (result == null) {
/* 850 */       this.map = (result = new AbstractMap() {
/*     */         Set<Map.Entry<K, Collection<V>>> entrySet;
/*     */ 
/* 854 */         public Set<Map.Entry<K, Collection<V>>> entrySet() { Set result = this.entrySet;
/* 855 */           if (result == null) {
/* 856 */             this.entrySet = (result = new LinkedListMultimap.AsMapEntries(LinkedListMultimap.this, null));
/*     */           }
/* 858 */           return result;
/*     */         }
/*     */ 
/*     */         public boolean containsKey(@Nullable Object key)
/*     */         {
/* 864 */           return LinkedListMultimap.this.containsKey(key);
/*     */         }
/*     */ 
/*     */         public Collection<V> get(@Nullable Object key)
/*     */         {
/* 869 */           Collection collection = LinkedListMultimap.this.get(key);
/* 870 */           return collection.isEmpty() ? null : collection;
/*     */         }
/*     */ 
/*     */         public Collection<V> remove(@Nullable Object key) {
/* 874 */           Collection collection = LinkedListMultimap.this.removeAll(key);
/* 875 */           return collection.isEmpty() ? null : collection;
/*     */         }
/*     */       });
/*     */     }
/* 880 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 893 */     if (other == this) {
/* 894 */       return true;
/*     */     }
/* 896 */     if ((other instanceof Multimap)) {
/* 897 */       Multimap that = (Multimap)other;
/* 898 */       return asMap().equals(that.asMap());
/*     */     }
/* 900 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 910 */     return asMap().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 920 */     return asMap().toString();
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 930 */     stream.defaultWriteObject();
/* 931 */     stream.writeInt(size());
/* 932 */     for (Map.Entry entry : entries()) {
/* 933 */       stream.writeObject(entry.getKey());
/* 934 */       stream.writeObject(entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectInputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 941 */     stream.defaultReadObject();
/* 942 */     this.keyCount = LinkedHashMultiset.create();
/* 943 */     this.keyToKeyHead = Maps.newHashMap();
/* 944 */     this.keyToKeyTail = Maps.newHashMap();
/* 945 */     int size = stream.readInt();
/* 946 */     for (int i = 0; i < size; i++)
/*     */     {
/* 948 */       Object key = stream.readObject();
/*     */ 
/* 950 */       Object value = stream.readObject();
/* 951 */       put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AsMapEntries extends AbstractSet<Map.Entry<K, Collection<V>>>
/*     */   {
/*     */     private AsMapEntries()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 815 */       return LinkedListMultimap.this.keyCount.elementSet().size();
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, Collection<V>>> iterator() {
/* 819 */       Iterator keyIterator = new LinkedListMultimap.DistinctKeyIterator(LinkedListMultimap.this, null);
/* 820 */       return new Iterator(keyIterator) {
/*     */         public boolean hasNext() {
/* 822 */           return this.val$keyIterator.hasNext();
/*     */         }
/*     */ 
/*     */         public Map.Entry<K, Collection<V>> next() {
/* 826 */           Object key = this.val$keyIterator.next();
/* 827 */           return new AbstractMapEntry(key) {
/*     */             public K getKey() {
/* 829 */               return this.val$key;
/*     */             }
/*     */ 
/*     */             public Collection<V> getValue() {
/* 833 */               return LinkedListMultimap.this.get(this.val$key);
/*     */             } } ;
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 839 */           this.val$keyIterator.remove();
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MultisetView extends AbstractCollection<K>
/*     */     implements Multiset<K>
/*     */   {
/*     */     private MultisetView()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 615 */       return LinkedListMultimap.this.keyCount.size();
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator() {
/* 619 */       Iterator nodes = new LinkedListMultimap.NodeIterator(LinkedListMultimap.this, null);
/* 620 */       return new Iterator(nodes) {
/*     */         public boolean hasNext() {
/* 622 */           return this.val$nodes.hasNext();
/*     */         }
/*     */         public K next() {
/* 625 */           return ((LinkedListMultimap.Node)this.val$nodes.next()).key;
/*     */         }
/*     */         public void remove() {
/* 628 */           this.val$nodes.remove();
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public int count(@Nullable Object key) {
/* 634 */       return LinkedListMultimap.this.keyCount.count(key);
/*     */     }
/*     */ 
/*     */     public int add(@Nullable K key, int occurrences) {
/* 638 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int remove(@Nullable Object key, int occurrences) {
/* 642 */       Preconditions.checkArgument(occurrences >= 0);
/* 643 */       int oldCount = count(key);
/* 644 */       Iterator values = new LinkedListMultimap.ValueForKeyIterator(LinkedListMultimap.this, key);
/* 645 */       while ((occurrences-- > 0) && (values.hasNext())) {
/* 646 */         values.next();
/* 647 */         values.remove();
/*     */       }
/* 649 */       return oldCount;
/*     */     }
/*     */ 
/*     */     public int setCount(K element, int count) {
/* 653 */       return Multisets.setCountImpl(this, element, count);
/*     */     }
/*     */ 
/*     */     public boolean setCount(K element, int oldCount, int newCount) {
/* 657 */       return Multisets.setCountImpl(this, element, oldCount, newCount);
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> c) {
/* 661 */       return Iterators.removeAll(iterator(), c);
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> c) {
/* 665 */       return Iterators.retainAll(iterator(), c);
/*     */     }
/*     */ 
/*     */     public Set<K> elementSet() {
/* 669 */       return LinkedListMultimap.this.keySet();
/*     */     }
/*     */ 
/*     */     public Set<Multiset.Entry<K>> entrySet()
/*     */     {
/* 674 */       return new AbstractSet() {
/*     */         public int size() {
/* 676 */           return LinkedListMultimap.this.keyCount.elementSet().size();
/*     */         }
/*     */ 
/*     */         public Iterator<Multiset.Entry<K>> iterator() {
/* 680 */           Iterator keyIterator = new LinkedListMultimap.DistinctKeyIterator(LinkedListMultimap.this, null);
/* 681 */           return new Iterator(keyIterator) {
/*     */             public boolean hasNext() {
/* 683 */               return this.val$keyIterator.hasNext();
/*     */             }
/*     */             public Multiset.Entry<K> next() {
/* 686 */               Object key = this.val$keyIterator.next();
/* 687 */               return new Multisets.AbstractEntry(key) {
/*     */                 public K getElement() {
/* 689 */                   return this.val$key;
/*     */                 }
/*     */                 public int getCount() {
/* 692 */                   return LinkedListMultimap.this.keyCount.count(this.val$key);
/*     */                 } } ;
/*     */             }
/*     */ 
/*     */             public void remove() {
/* 697 */               this.val$keyIterator.remove();
/*     */             } } ;
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object object) {
/* 705 */       return LinkedListMultimap.this.keyCount.equals(object);
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 709 */       return LinkedListMultimap.this.keyCount.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 713 */       return LinkedListMultimap.this.keyCount.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ValueForKeyIterator
/*     */     implements ListIterator<V>
/*     */   {
/*     */     final Object key;
/*     */     int nextIndex;
/*     */     LinkedListMultimap.Node<K, V> next;
/*     */     LinkedListMultimap.Node<K, V> current;
/*     */     LinkedListMultimap.Node<K, V> previous;
/*     */ 
/*     */     package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */     import com.google.common.annotations.GwtCompatible;
/*     */     import java.util.Iterator;
/*     */     import java.util.Map;
/*     */     import java.util.Map.Entry;
/*     */     import java.util.Set;
/*     */     import javax.annotation.Nullable;
/*     */ 
/*     */     @GwtCompatible(serializable=true, emulated=true)
/*     */     final class SingletonImmutableMap<K, V> extends ImmutableMap<K, V>
/*     */     {
/*     */       final transient K singleKey;
/*     */       final transient V singleValue;
/*     */       private transient Map.Entry<K, V> entry;
/*     */       private transient ImmutableSet<Map.Entry<K, V>> entrySet;
/*     */       private transient ImmutableSet<K> keySet;
/*     */       private transient ImmutableCollection<V> values;
/*     */ 
/*     */       SingletonImmutableMap(K singleKey, V singleValue)
/*     */       {
/*  41 */         this.singleKey = singleKey;
/*  42 */         this.singleValue = singleValue;
/*     */       }
/*     */ 
/*     */       SingletonImmutableMap(Map.Entry<K, V> entry) {
/*  46 */         this.entry = entry;
/*  47 */         this.singleKey = entry.getKey();
/*  48 */         this.singleValue = entry.getValue();
/*     */       }
/*     */ 
/*     */       private Map.Entry<K, V> entry() {
/*  52 */         Map.Entry e = this.entry;
/*  53 */         return e == null ? (this.entry = Maps.immutableEntry(this.singleKey, this.singleValue)) : e;
/*     */       }
/*     */ 
/*     */       public V get(Object key)
/*     */       {
/*  58 */         return this.singleKey.equals(key) ? this.singleValue : null;
/*     */       }
/*     */ 
/*     */       public int size() {
/*  62 */         return 1;
/*     */       }
/*     */ 
/*     */       public boolean isEmpty() {
/*  66 */         return false;
/*     */       }
/*     */ 
/*     */       public boolean containsKey(Object key) {
/*  70 */         return this.singleKey.equals(key);
/*     */       }
/*     */ 
/*     */       public boolean containsValue(Object value) {
/*  74 */         return this.singleValue.equals(value);
/*     */       }
/*     */ 
/*     */       public ImmutableSet<Map.Entry<K, V>> entrySet()
/*     */       {
/*  80 */         ImmutableSet es = this.entrySet;
/*  81 */         return es == null ? (this.entrySet = ImmutableSet.of(entry())) : es;
/*     */       }
/*     */ 
/*     */       public ImmutableSet<K> keySet()
/*     */       {
/*  87 */         ImmutableSet ks = this.keySet;
/*  88 */         return ks == null ? (this.keySet = ImmutableSet.of(this.singleKey)) : ks;
/*     */       }
/*     */ 
/*     */       public ImmutableCollection<V> values()
/*     */       {
/*  94 */         ImmutableCollection v = this.values;
/*  95 */         return v == null ? (this.values = new Values(this.singleValue)) : v;
/*     */       }
/*     */ 
/*     */       public boolean equals(@Nullable Object object)
/*     */       {
/* 124 */         if (object == this) {
/* 125 */           return true;
/*     */         }
/* 127 */         if ((object instanceof Map)) {
/* 128 */           Map that = (Map)object;
/* 129 */           if (that.size() != 1) {
/* 130 */             return false;
/*     */           }
/* 132 */           Map.Entry entry = (Map.Entry)that.entrySet().iterator().next();
/* 133 */           return (this.singleKey.equals(entry.getKey())) && (this.singleValue.equals(entry.getValue()));
/*     */         }
/*     */ 
/* 136 */         return false;
/*     */       }
/*     */ 
/*     */       public int hashCode() {
/* 140 */         return this.singleKey.hashCode() ^ this.singleValue.hashCode();
/*     */       }
/*     */ 
/*     */       public String toString() {
/* 144 */         return '{' + this.singleKey.toString() + '=' + this.singleValue.toString() + '}';
/*     */       }
/*     */ 
/*     */       private static class Values<V> extends ImmutableCollection<V>
/*     */       {
/*     */         final V singleValue;
/*     */ 
/*     */         Values(V singleValue)
/*     */         {
/* 103 */           this.singleValue = singleValue;
/*     */         }
/*     */ 
/*     */         public boolean contains(Object object) {
/* 107 */           return this.singleValue.equals(object);
/*     */         }
/*     */ 
/*     */         public boolean isEmpty() {
/* 111 */           return false;
/*     */         }
/*     */ 
/*     */         public int size() {
/* 115 */           return 1;
/*     */         }
/*     */ 
/*     */         public UnmodifiableIterator<V> iterator() {
/* 119 */           return Iterators.singletonIterator(this.singleValue);
/*     */         }
/*     */       }
/*     */     }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.SingletonImmutableMap
 * JD-Core Version:    0.6.0
 */