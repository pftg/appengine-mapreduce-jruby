package com.google.appengine.api.blobstore;

import java.io.IOException;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface BlobstoreService
{
  public static final int MAX_BLOB_FETCH_SIZE = 1015808;

  public abstract String createUploadUrl(String paramString);

  public abstract void serve(BlobKey paramBlobKey, HttpServletResponse paramHttpServletResponse)
    throws IOException;

  public abstract void serve(BlobKey paramBlobKey, ByteRange paramByteRange, HttpServletResponse paramHttpServletResponse)
    throws IOException;

  public abstract void serve(BlobKey paramBlobKey, String paramString, HttpServletResponse paramHttpServletResponse)
    throws IOException;

  public abstract ByteRange getByteRange(HttpServletRequest paramHttpServletRequest);

  public abstract void delete(BlobKey[] paramArrayOfBlobKey);

  public abstract Map<String, BlobKey> getUploadedBlobs(HttpServletRequest paramHttpServletRequest);

  public abstract byte[] fetchData(BlobKey paramBlobKey, long paramLong1, long paramLong2);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobstoreService
 * JD-Core Version:    0.6.0
 */