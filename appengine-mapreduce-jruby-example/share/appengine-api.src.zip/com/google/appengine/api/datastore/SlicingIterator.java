/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ class SlicingIterator<T> extends AbstractIterator<T>
/*    */ {
/*    */   private final Iterator<T> delegate;
/*    */   private int remainingOffset;
/*    */   private final Integer limit;
/* 17 */   private Integer numEntitiesReturned = Integer.valueOf(0);
/*    */ 
/*    */   SlicingIterator(Iterator<T> delegate, Integer offset, Integer limit)
/*    */   {
/* 26 */     this.remainingOffset = (offset == null ? 0 : offset.intValue());
/* 27 */     this.limit = limit;
/* 28 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   protected T computeNext()
/*    */   {
/* 33 */     if (this.numEntitiesReturned.equals(this.limit)) {
/* 34 */       endOfData();
/*    */     }
/* 36 */     Object next = null;
/*    */ 
/* 39 */     while ((this.delegate.hasNext()) && (this.remainingOffset-- >= 0))
/* 40 */       next = this.delegate.next();
/*    */     Integer localInteger1;
/* 43 */     if ((this.remainingOffset >= 0) || (next == null))
/*    */     {
/* 46 */       endOfData();
/*    */     }
/*    */     else {
/* 49 */       this.remainingOffset = 0;
/* 50 */       localInteger1 = this.numEntitiesReturned; Integer localInteger2 = this.numEntitiesReturned = Integer.valueOf(this.numEntitiesReturned.intValue() + 1);
/*    */     }
/* 52 */     return next;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.SlicingIterator
 * JD-Core Version:    0.6.0
 */