/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ class NotEqualQuerySplitter extends BaseQuerySplitter
/*     */ {
/*     */   public List<QuerySplitComponent> split(List<Query.FilterPredicate> remainingFilters, List<Query.SortPredicate> sorts)
/*     */   {
/*  53 */     String propertyName = null;
/*  54 */     List values = null;
/*     */ 
/*  56 */     Iterator itr = remainingFilters.iterator();
/*  57 */     while (itr.hasNext()) {
/*  58 */       Query.FilterPredicate filter = (Query.FilterPredicate)itr.next();
/*  59 */       if (filter.getOperator() == Query.FilterOperator.NOT_EQUAL)
/*     */       {
/*  61 */         if (propertyName == null)
/*     */         {
/*  63 */           propertyName = filter.getPropertyName();
/*  64 */           values = new ArrayList();
/*  65 */         } else if (!propertyName.equals(filter.getPropertyName())) {
/*  66 */           throw new IllegalArgumentException("Queries with NOT_EQUAL filters on different properties are not supported.");
/*     */         }
/*     */ 
/*  70 */         values.add(new BaseQuerySplitter.ComparableValue(filter.getValue()));
/*  71 */         itr.remove();
/*     */       }
/*     */     }
/*     */ 
/*  75 */     if (values != null) {
/*  76 */       ArrayList result = new ArrayList(values.size() + 1);
/*  77 */       result.add(makeComponent(propertyName, values, sorts));
/*  78 */       return result;
/*     */     }
/*  80 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   private QuerySplitComponent makeComponent(String propertyName, List<BaseQuerySplitter.ComparableValue> values, List<Query.SortPredicate> sorts)
/*     */   {
/*  94 */     QuerySplitComponent result = new QuerySplitComponent(propertyName, sorts);
/*  95 */     if ((!sorts.isEmpty()) && (result.getSortIndex() != 0)) {
/*  96 */       throw new IllegalArgumentException("The first sort order must be on the same property as the NOT_EQUAL filter");
/*     */     }
/*     */ 
/* 100 */     Collections.sort(values, getValueComparator(result.getDirection()));
/* 101 */     Object first = ((BaseQuerySplitter.ComparableValue)values.get(0)).getValue();
/* 102 */     Object last = ((BaseQuerySplitter.ComparableValue)values.get(values.size() - 1)).getValue();
/* 103 */     if (result.getDirection() == Query.SortDirection.DESCENDING) {
/* 104 */       result.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(propertyName, Query.FilterOperator.GREATER_THAN, first) });
/* 105 */       for (int i = 1; i < values.size(); i++) {
/* 106 */         Object prev = ((BaseQuerySplitter.ComparableValue)values.get(i - 1)).getValue();
/* 107 */         Object next = ((BaseQuerySplitter.ComparableValue)values.get(i)).getValue();
/* 108 */         result.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(propertyName, Query.FilterOperator.LESS_THAN, prev), new Query.FilterPredicate(propertyName, Query.FilterOperator.GREATER_THAN, next) });
/*     */       }
/*     */ 
/* 111 */       if (last != null)
/* 112 */         result.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(propertyName, Query.FilterOperator.LESS_THAN, last) });
/*     */     }
/*     */     else
/*     */     {
/* 116 */       if (first != null) {
/* 117 */         result.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(propertyName, Query.FilterOperator.LESS_THAN, first) });
/*     */       }
/* 119 */       for (int i = 1; i < values.size(); i++) {
/* 120 */         Object prev = ((BaseQuerySplitter.ComparableValue)values.get(i - 1)).getValue();
/* 121 */         Object next = ((BaseQuerySplitter.ComparableValue)values.get(i)).getValue();
/* 122 */         result.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(propertyName, Query.FilterOperator.GREATER_THAN, prev), new Query.FilterPredicate(propertyName, Query.FilterOperator.LESS_THAN, next) });
/*     */       }
/*     */ 
/* 125 */       result.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(propertyName, Query.FilterOperator.GREATER_THAN, last) });
/*     */     }
/* 127 */     return result;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.NotEqualQuerySplitter
 * JD-Core Version:    0.6.0
 */