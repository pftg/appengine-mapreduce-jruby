/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ @GwtCompatible(serializable=true)
/*     */ @GoogleInternal
/*     */ public class HashBasedTable<R, C, V> extends StandardTable<R, C, V>
/*     */ {
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   private static <C, V> Map<C, V> newHashMapWithExpectedSize(int expectedSize)
/*     */   {
/*  75 */     Preconditions.checkArgument(expectedSize >= 0);
/*  76 */     return new HashMap(Math.max(expectedSize * 2, 16));
/*     */   }
/*     */ 
/*     */   public static <R, C, V> HashBasedTable<R, C, V> create()
/*     */   {
/*  83 */     return new HashBasedTable(new HashMap(), new Factory(0));
/*     */   }
/*     */ 
/*     */   public static <R, C, V> HashBasedTable<R, C, V> create(int expectedRows, int expectedCellsPerRow)
/*     */   {
/*  98 */     Preconditions.checkArgument(expectedCellsPerRow >= 0);
/*  99 */     Map backingMap = newHashMapWithExpectedSize(expectedRows);
/* 100 */     return new HashBasedTable(backingMap, new Factory(expectedCellsPerRow));
/*     */   }
/*     */ 
/*     */   public static <R, C, V> HashBasedTable<R, C, V> create(Table<? extends R, ? extends C, ? extends V> table)
/*     */   {
/* 115 */     HashBasedTable result = create();
/* 116 */     result.putAll(table);
/* 117 */     return result;
/*     */   }
/*     */ 
/*     */   HashBasedTable(Map<R, Map<C, V>> backingMap, Factory<C, V> factory) {
/* 121 */     super(backingMap, factory);
/*     */   }
/*     */ 
/*     */   private static class Factory<C, V>
/*     */     implements Supplier<Map<C, V>>, Serializable
/*     */   {
/*     */     final int expectedSize;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     Factory(int expectedSize)
/*     */     {
/*  57 */       this.expectedSize = expectedSize;
/*     */     }
/*     */     public Map<C, V> get() {
/*  60 */       return HashBasedTable.access$000(this.expectedSize);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.HashBasedTable
 * JD-Core Version:    0.6.0
 */