/*    */ package com.google.appengine.api.channel;
/*    */ 
/*    */ public final class ChannelFailureException extends RuntimeException
/*    */ {
/*    */   public ChannelFailureException(String message)
/*    */   {
/* 14 */     super(message);
/*    */   }
/*    */ 
/*    */   public ChannelFailureException(String message, Throwable cause) {
/* 18 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.channel.ChannelFailureException
 * JD-Core Version:    0.6.0
 */