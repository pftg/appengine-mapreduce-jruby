/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public abstract class AbstractMessageLite
/*     */   implements MessageLite
/*     */ {
/*     */   public ByteString toByteString()
/*     */   {
/*     */     try
/*     */     {
/*  21 */       ByteString.CodedBuilder out = ByteString.newCodedBuilder(getSerializedSize());
/*     */ 
/*  23 */       writeTo(out.getCodedOutput());
/*  24 */       return out.build(); } catch (IOException e) {
/*     */     }
/*  26 */     throw new RuntimeException("Serializing to a ByteString threw an IOException (should never happen).", e);
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray()
/*     */   {
/*     */     try
/*     */     {
/*  34 */       byte[] result = new byte[getSerializedSize()];
/*  35 */       CodedOutputStream output = CodedOutputStream.newInstance(result);
/*  36 */       writeTo(output);
/*  37 */       output.checkNoSpaceLeft();
/*  38 */       return result; } catch (IOException e) {
/*     */     }
/*  40 */     throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream output)
/*     */     throws IOException
/*     */   {
/*  47 */     int bufferSize = CodedOutputStream.computePreferredBufferSize(getSerializedSize());
/*     */ 
/*  49 */     CodedOutputStream codedOutput = CodedOutputStream.newInstance(output, bufferSize);
/*     */ 
/*  51 */     writeTo(codedOutput);
/*  52 */     codedOutput.flush();
/*     */   }
/*     */ 
/*     */   public void writeDelimitedTo(OutputStream output) throws IOException {
/*  56 */     int serialized = getSerializedSize();
/*  57 */     int bufferSize = CodedOutputStream.computePreferredBufferSize(CodedOutputStream.computeRawVarint32Size(serialized) + serialized);
/*     */ 
/*  59 */     CodedOutputStream codedOutput = CodedOutputStream.newInstance(output, bufferSize);
/*     */ 
/*  61 */     codedOutput.writeRawVarint32(serialized);
/*  62 */     writeTo(codedOutput);
/*  63 */     codedOutput.flush();
/*     */   }
/*     */ 
/*     */   public static abstract class Builder<BuilderType extends Builder>
/*     */     implements MessageLite.Builder
/*     */   {
/*     */     public abstract BuilderType clone();
/*     */ 
/*     */     public BuilderType mergeFrom(CodedInputStream input)
/*     */       throws IOException
/*     */     {
/*  80 */       return mergeFrom(input, ExtensionRegistryLite.getEmptyRegistry());
/*     */     }
/*     */ 
/*     */     public abstract BuilderType mergeFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite)
/*     */       throws IOException;
/*     */ 
/*     */     public BuilderType mergeFrom(ByteString data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*     */       try
/*     */       {
/*  92 */         CodedInputStream input = data.newCodedInput();
/*  93 */         mergeFrom(input);
/*  94 */         input.checkLastTagWas(0);
/*  95 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/*  97 */         throw e; } catch (IOException e) {
/*     */       }
/*  99 */       throw new RuntimeException("Reading from a ByteString threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*     */       try
/*     */       {
/* 110 */         CodedInputStream input = data.newCodedInput();
/* 111 */         mergeFrom(input, extensionRegistry);
/* 112 */         input.checkLastTagWas(0);
/* 113 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/* 115 */         throw e; } catch (IOException e) {
/*     */       }
/* 117 */       throw new RuntimeException("Reading from a ByteString threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 125 */       return mergeFrom(data, 0, data.length);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data, int off, int len) throws InvalidProtocolBufferException
/*     */     {
/*     */       try
/*     */       {
/* 132 */         CodedInputStream input = CodedInputStream.newInstance(data, off, len);
/*     */ 
/* 134 */         mergeFrom(input);
/* 135 */         input.checkLastTagWas(0);
/* 136 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/* 138 */         throw e; } catch (IOException e) {
/*     */       }
/* 140 */       throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 150 */       return mergeFrom(data, 0, data.length, extensionRegistry);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(byte[] data, int off, int len, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*     */       try
/*     */       {
/* 158 */         CodedInputStream input = CodedInputStream.newInstance(data, off, len);
/*     */ 
/* 160 */         mergeFrom(input, extensionRegistry);
/* 161 */         input.checkLastTagWas(0);
/* 162 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/* 164 */         throw e; } catch (IOException e) {
/*     */       }
/* 166 */       throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(InputStream input)
/*     */       throws IOException
/*     */     {
/* 173 */       CodedInputStream codedInput = CodedInputStream.newInstance(input);
/* 174 */       mergeFrom(codedInput);
/* 175 */       codedInput.checkLastTagWas(0);
/* 176 */       return this;
/*     */     }
/*     */ 
/*     */     public BuilderType mergeFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 183 */       CodedInputStream codedInput = CodedInputStream.newInstance(input);
/* 184 */       mergeFrom(codedInput, extensionRegistry);
/* 185 */       codedInput.checkLastTagWas(0);
/* 186 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean mergeDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 248 */       int firstByte = input.read();
/* 249 */       if (firstByte == -1) {
/* 250 */         return false;
/*     */       }
/* 252 */       int size = CodedInputStream.readRawVarint32(firstByte, input);
/* 253 */       InputStream limitedInput = new LimitedInputStream(input, size);
/* 254 */       mergeFrom(limitedInput, extensionRegistry);
/* 255 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean mergeDelimitedFrom(InputStream input) throws IOException
/*     */     {
/* 260 */       return mergeDelimitedFrom(input, ExtensionRegistryLite.getEmptyRegistry());
/*     */     }
/*     */ 
/*     */     protected static UninitializedMessageException newUninitializedMessageException(MessageLite message)
/*     */     {
/* 270 */       return new UninitializedMessageException(message);
/*     */     }
/*     */ 
/*     */     protected static <T> void addAll(Iterable<T> values, Collection<? super T> list)
/*     */     {
/* 282 */       for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 283 */         if (value == null)
/* 284 */           throw new NullPointerException();
/*     */       }
/*     */       Iterator i$;
/* 287 */       if ((values instanceof Collection))
/*     */       {
/* 289 */         Collection collection = (Collection)values;
/* 290 */         list.addAll(collection);
/*     */       } else {
/* 292 */         for (i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 293 */           list.add(value);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     static final class LimitedInputStream extends FilterInputStream
/*     */     {
/*     */       private int limit;
/*     */ 
/*     */       LimitedInputStream(InputStream in, int limit)
/*     */       {
/* 199 */         super();
/* 200 */         this.limit = limit;
/*     */       }
/*     */ 
/*     */       public int available() throws IOException
/*     */       {
/* 205 */         return Math.min(super.available(), this.limit);
/*     */       }
/*     */ 
/*     */       public int read() throws IOException
/*     */       {
/* 210 */         if (this.limit <= 0) {
/* 211 */           return -1;
/*     */         }
/* 213 */         int result = super.read();
/* 214 */         if (result >= 0) {
/* 215 */           this.limit -= 1;
/*     */         }
/* 217 */         return result;
/*     */       }
/*     */ 
/*     */       public int read(byte[] b, int off, int len)
/*     */         throws IOException
/*     */       {
/* 223 */         if (this.limit <= 0) {
/* 224 */           return -1;
/*     */         }
/* 226 */         len = Math.min(len, this.limit);
/* 227 */         int result = super.read(b, off, len);
/* 228 */         if (result >= 0) {
/* 229 */           this.limit -= result;
/*     */         }
/* 231 */         return result;
/*     */       }
/*     */ 
/*     */       public long skip(long n) throws IOException
/*     */       {
/* 236 */         long result = super.skip(Math.min(n, this.limit));
/* 237 */         if (result >= 0L) {
/* 238 */           this.limit = (int)(this.limit - result);
/*     */         }
/* 240 */         return result;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.AbstractMessageLite
 * JD-Core Version:    0.6.0
 */