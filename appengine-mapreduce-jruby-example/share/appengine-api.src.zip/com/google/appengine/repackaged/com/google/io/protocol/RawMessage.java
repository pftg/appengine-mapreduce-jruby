/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.proto.ProtocolDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ public final class RawMessage extends ProtocolMessage<RawMessage>
/*     */ {
/*  48 */   public static final RawMessage IMMUTABLE_DEFAULT_INSTANCE = new RawMessage();
/*     */ 
/*  60 */   private ByteBuffer byteBuffer = ByteBuffer.allocate(128).order(ByteOrder.LITTLE_ENDIAN);
/*     */   private static ProtocolType cachedClassProtocolType;
/*     */ 
/*     */   public RawMessage getDefaultInstanceForType()
/*     */   {
/*  52 */     return IMMUTABLE_DEFAULT_INSTANCE;
/*     */   }
/*     */ 
/*     */   public ByteBuffer contents()
/*     */   {
/*  68 */     ByteBuffer buf = this.byteBuffer.asReadOnlyBuffer();
/*  69 */     buf.flip();
/*  70 */     return buf.order(ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */   public int encodingSize() {
/*  82 */     return this.byteBuffer.position();
/*     */   }
/*     */ 
/*     */   public int maxEncodingSize() {
/*  86 */     return encodingSize();
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  90 */     this.byteBuffer.clear();
/*     */   }
/*     */ 
/*     */   public RawMessage newInstance() {
/*  94 */     return new RawMessage();
/*     */   }
/*     */ 
/*     */   public void outputTo(ProtocolSink sink) {
/*  98 */     sink.putBytes(this.byteBuffer.array(), 0, this.byteBuffer.position());
/*     */   }
/*     */ 
/*     */   private void ensureCapacity(int minCapacity)
/*     */   {
/* 105 */     if (this.byteBuffer.capacity() < minCapacity)
/*     */     {
/* 108 */       int newCapacity = Math.max(this.byteBuffer.capacity() * 2, Integer.highestOneBit(minCapacity) * 2);
/*     */ 
/* 110 */       ByteBuffer newByteBuffer = ByteBuffer.allocate(newCapacity).order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/* 112 */       newByteBuffer.put(this.byteBuffer.array(), 0, this.byteBuffer.position());
/* 113 */       this.byteBuffer = newByteBuffer;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean merge(ProtocolSource source) {
/* 118 */     int remaining = source.remaining();
/* 119 */     ensureCapacity(this.byteBuffer.position() + remaining);
/* 120 */     source.getBytes(this.byteBuffer.array(), this.byteBuffer.position(), remaining);
/*     */ 
/* 122 */     this.byteBuffer.position(this.byteBuffer.position() + remaining);
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   public RawMessage mergeFrom(RawMessage other)
/*     */   {
/* 131 */     if (other == this) {
/* 132 */       throw new IllegalArgumentException("Cannot merge from the same instance");
/*     */     }
/* 134 */     ensureCapacity(this.byteBuffer.position() + other.byteBuffer.position());
/* 135 */     this.byteBuffer.put(other.byteBuffer.array(), 0, other.byteBuffer.position());
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   public void mergeFromOther(ProtocolMessage proto)
/*     */   {
/* 143 */     mergeFrom(proto.toByteArray());
/*     */   }
/*     */ 
/*     */   public void mergeTo(ProtocolMessage proto)
/*     */   {
/* 156 */     ByteBuffer reference = this.byteBuffer.duplicate();
/* 157 */     reference.flip();
/* 158 */     proto.mergeFrom(reference);
/*     */   }
/*     */ 
/*     */   public void mergeToOther(ProtocolMessage proto)
/*     */   {
/* 165 */     mergeTo(proto);
/*     */   }
/*     */ 
/*     */   public boolean equalsIgnoreUninterpreted(RawMessage that) {
/* 169 */     return equals(that, true);
/*     */   }
/*     */ 
/*     */   public boolean equals(RawMessage that) {
/* 173 */     return equals(that, false);
/*     */   }
/*     */ 
/*     */   public boolean equals(RawMessage other, boolean uninterpreted) {
/* 177 */     if (other == this) {
/* 178 */       return true;
/*     */     }
/* 180 */     if ((other == null) || (other.byteBuffer.position() != this.byteBuffer.position()))
/*     */     {
/* 182 */       return false;
/*     */     }
/*     */ 
/* 185 */     int size = this.byteBuffer.position();
/* 186 */     for (int i = 0; i < size; i++) {
/* 187 */       if (this.byteBuffer.get(i) != other.byteBuffer.get(i)) {
/* 188 */         return false;
/*     */       }
/*     */     }
/* 191 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object that) {
/* 195 */     return ((that instanceof RawMessage)) && (equals((RawMessage)that));
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 199 */     return 104729 + this.byteBuffer.hashCode();
/*     */   }
/*     */ 
/*     */   public ProtocolType getProtocolType()
/*     */   {
/* 207 */     return getClassProtocolType();
/*     */   }
/*     */ 
/*     */   private static synchronized ProtocolType getClassProtocolType()
/*     */   {
/* 213 */     if (cachedClassProtocolType == null) {
/* 214 */       String name = RawMessage.class.getName();
/* 215 */       String fileName = "java/" + name.replace('.', '/') + ".java";
/* 216 */       ProtocolDescriptor descriptor = new ProtocolDescriptor().setName(name).setProtoName("RawMessage").setFilename(fileName);
/*     */ 
/* 221 */       cachedClassProtocolType = new ProtocolType(RawMessage.class, null, new ProtocolType.FieldType[0], descriptor)
/*     */       {
/*     */         protected void visitInternal(ProtocolMessage message, ProtocolType.Visitor visitor, Iterable<ProtocolType.FieldType> fields) {
/* 224 */           RawMessage rawMessage = (RawMessage)message;
/* 225 */           visitor.visitRawMessage(rawMessage.contents());
/*     */         }
/*     */ 
/*     */         protected void visitInternal(ProtocolMessage message, MessageVisitor visitor, Iterable<ProtocolType.FieldType> fields)
/*     */         {
/* 230 */           visitor.visitRawMessage(((RawMessage)message).contents());
/*     */         }
/*     */ 
/*     */         public ProtocolDescriptor getProtocolDescriptor() {
/* 234 */           return this.val$descriptor;
/*     */         } } ;
/*     */     }
/* 238 */     return cachedClassProtocolType;
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream s)
/*     */     throws IOException
/*     */   {
/* 252 */     s.writeInt(this.byteBuffer.position());
/* 253 */     s.write(this.byteBuffer.array(), 0, this.byteBuffer.position());
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream s)
/*     */     throws IOException
/*     */   {
/* 261 */     int size = s.readInt();
/*     */ 
/* 263 */     if (this.byteBuffer == null)
/* 264 */       this.byteBuffer = ByteBuffer.allocate(size);
/*     */     else {
/* 266 */       ensureCapacity(this.byteBuffer.position() + size);
/*     */     }
/* 268 */     s.read(this.byteBuffer.array(), this.byteBuffer.position(), size);
/* 269 */     this.byteBuffer.position(this.byteBuffer.position() + size);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.RawMessage
 * JD-Core Version:    0.6.0
 */