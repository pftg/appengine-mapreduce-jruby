/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Equivalence;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ class ComputingConcurrentHashMap<K, V> extends CustomConcurrentHashMap<K, V>
/*     */   implements MapMaker.Cache<K, V>
/*     */ {
/*     */   final Function<? super K, ? extends V> computingFunction;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   ComputingConcurrentHashMap(MapMaker builder, Function<? super K, ? extends V> computingFunction)
/*     */   {
/*  52 */     super(builder);
/*  53 */     this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/*     */   }
/*     */ 
/*     */   public ConcurrentMap<K, V> asMap() {
/*  57 */     return this;
/*     */   }
/*     */ 
/*     */   public V apply(K key) {
/*  61 */     Preconditions.checkNotNull(key);
/*     */ 
/*  63 */     int hash = hash(key);
/*  64 */     CustomConcurrentHashMap.Segment segment = segmentFor(hash);
/*     */     while (true) {
/*  66 */       CustomConcurrentHashMap.ReferenceEntry entry = segment.getEntry(key, hash);
/*     */       Object value;
/*  67 */       if (entry == null) { boolean created = false;
/*  69 */         segment.lock();
/*     */         int index;
/*     */         try { if (this.expires) {
/*  72 */             segment.expireEntries();
/*     */           }
/*     */ 
/*  76 */           entry = segment.getEntry(key, hash);
/*  77 */           if (entry == null)
/*     */           {
/*  79 */             created = true;
/*  80 */             int count = segment.count;
/*  81 */             if (count++ > segment.threshold) {
/*  82 */               segment.expand();
/*     */             }
/*  84 */             AtomicReferenceArray table = segment.table;
/*  85 */             index = hash & table.length() - 1;
/*  86 */             CustomConcurrentHashMap.ReferenceEntry first = (CustomConcurrentHashMap.ReferenceEntry)table.get(index);
/*  87 */             segment.modCount += 1;
/*  88 */             entry = this.entryFactory.newEntry(this, key, hash, first);
/*  89 */             table.set(index, entry);
/*  90 */             segment.count = count;
/*     */           }
/*     */         } finally {
/*  93 */           segment.unlock();
/*     */         }
/*     */ 
/*  96 */         if (created)
/*     */         {
/*  98 */           boolean success = false;
/*     */           try {
/* 100 */             value = compute(segment, key, entry);
/* 101 */             Preconditions.checkNotNull(value, "compute() returned null unexpectedly");
/*     */ 
/* 103 */             success = true;
/* 104 */             index = value;
/*     */             return index;
/*     */           }
/*     */           finally
/*     */           {
/* 106 */             if (!success) {
/* 107 */               segment.removeEntry(entry, hash);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 114 */       boolean interrupted = false;
/*     */       try
/*     */       {
/* 118 */         Object value = waitForValue(entry);
/* 119 */         if (value == null)
/*     */         {
/* 121 */           segment.removeEntry(entry, hash);
/*     */ 
/* 130 */           if (interrupted) {
/* 131 */             Thread.currentThread().interrupt(); continue;
/*     */           }
/*     */         }
/* 124 */         value = value;
/*     */         return value;
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/*     */         while (true)
/* 126 */           interrupted = true;
/*     */       }
/*     */       finally
/*     */       {
/* 130 */         if (interrupted)
/* 131 */           Thread.currentThread().interrupt(); 
/*     */       }
/* 131 */     }throw localObject3;
/*     */   }
/*     */ 
/*     */   void setValueReference(CustomConcurrentHashMap.ReferenceEntry<K, V> entry, CustomConcurrentHashMap.ValueReference<K, V> valueReference)
/*     */   {
/* 139 */     boolean notifyOthers = entry.getValueReference() == UNSET;
/* 140 */     entry.setValueReference(valueReference);
/* 141 */     if (notifyOthers)
/* 142 */       synchronized (entry) {
/* 143 */         entry.notifyAll();
/*     */       }
/*     */   }
/*     */ 
/*     */   public V waitForValue(CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*     */     throws InterruptedException
/*     */   {
/* 154 */     CustomConcurrentHashMap.ValueReference valueReference = entry.getValueReference();
/* 155 */     if (valueReference == UNSET) {
/* 156 */       synchronized (entry) {
/* 157 */         while ((valueReference = entry.getValueReference()) == UNSET) {
/* 158 */           entry.wait();
/*     */         }
/*     */       }
/*     */     }
/* 162 */     return valueReference.waitForValue();
/*     */   }
/*     */ 
/*     */   public V compute(CustomConcurrentHashMap<K, V>.Segment segment, K key, CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*     */   {
/*     */     Object value;
/*     */     try
/*     */     {
/* 206 */       value = this.computingFunction.apply(key);
/*     */     }
/*     */     catch (ComputationException e)
/*     */     {
/* 213 */       setValueReference(entry, new ComputationExceptionReference(e.getCause()));
/*     */ 
/* 215 */       throw e;
/*     */     } catch (Throwable t) {
/* 217 */       setValueReference(entry, new ComputationExceptionReference(t));
/* 218 */       throw new ComputationException(t);
/*     */     }
/*     */ 
/* 221 */     if (value == null) {
/* 222 */       String message = this.computingFunction + " returned null for key " + key + ".";
/*     */ 
/* 227 */       setValueReference(entry, new NullOutputExceptionReference(message));
/*     */ 
/* 229 */       throw new NullOutputException(message);
/*     */     }
/*     */ 
/* 232 */     if (this.expires) {
/* 233 */       segment.lock();
/*     */       try {
/* 235 */         segment.setValue(entry, value, true);
/*     */       } finally {
/* 237 */         segment.unlock();
/*     */       }
/*     */     } else {
/* 240 */       segment.setValue(entry, value, true);
/*     */     }
/* 242 */     return value;
/*     */   }
/*     */ 
/*     */   CustomConcurrentHashMap.ReferenceEntry<K, V> copyEntry(CustomConcurrentHashMap.ReferenceEntry<K, V> original, CustomConcurrentHashMap.ReferenceEntry<K, V> newNext)
/*     */   {
/* 247 */     CustomConcurrentHashMap.ReferenceEntry newEntry = this.entryFactory.copyEntry(this, original, newNext);
/*     */ 
/* 249 */     CustomConcurrentHashMap.ValueReference valueReference = original.getValueReference();
/* 250 */     if (valueReference == UNSET) {
/* 251 */       newEntry.setValueReference(new FutureValueReference(original, newEntry));
/*     */     }
/*     */     else {
/* 254 */       newEntry.setValueReference(valueReference.copyFor(newEntry));
/*     */     }
/* 256 */     return newEntry;
/*     */   }
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 321 */     return new ComputingSerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence, this.expirationNanos, this.maximumSize, this.concurrencyLevel, this, this.computingFunction);
/*     */   }
/*     */ 
/*     */   static class ComputingSerializationProxy<K, V> extends CustomConcurrentHashMap.AbstractSerializationProxy<K, V>
/*     */   {
/*     */     final Function<? super K, ? extends V> computingFunction;
/*     */     transient MapMaker.Cache<K, V> cache;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     ComputingSerializationProxy(CustomConcurrentHashMap.Strength keyStrength, CustomConcurrentHashMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expirationNanos, int maximumSize, int concurrencyLevel, ConcurrentMap<K, V> delegate, Function<? super K, ? extends V> computingFunction)
/*     */     {
/* 341 */       super(valueStrength, keyEquivalence, valueEquivalence, expirationNanos, maximumSize, concurrencyLevel, delegate);
/*     */ 
/* 343 */       this.computingFunction = computingFunction;
/*     */     }
/*     */ 
/*     */     private void writeObject(ObjectOutputStream out) throws IOException
/*     */     {
/* 348 */       out.defaultWriteObject();
/* 349 */       writeMapTo(out);
/*     */     }
/*     */ 
/*     */     private void readObject(ObjectInputStream in)
/*     */       throws IOException, ClassNotFoundException
/*     */     {
/* 355 */       in.defaultReadObject();
/* 356 */       MapMaker mapMaker = readMapMaker(in);
/* 357 */       this.cache = mapMaker.makeCache(this.computingFunction);
/* 358 */       this.delegate = this.cache.asMap();
/* 359 */       readEntries(in);
/*     */     }
/*     */ 
/*     */     Object readResolve() {
/* 363 */       return this.cache;
/*     */     }
/*     */ 
/*     */     public ConcurrentMap<K, V> asMap() {
/* 367 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     public V apply(@Nullable K from) {
/* 371 */       return this.cache.apply(from);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class FutureValueReference
/*     */     implements CustomConcurrentHashMap.ValueReference<K, V>
/*     */   {
/*     */     final CustomConcurrentHashMap.ReferenceEntry<K, V> original;
/*     */     final CustomConcurrentHashMap.ReferenceEntry<K, V> newEntry;
/*     */ 
/*     */     FutureValueReference(CustomConcurrentHashMap.ReferenceEntry<K, V> original)
/*     */     {
/* 270 */       this.original = original;
/* 271 */       this.newEntry = newEntry;
/*     */     }
/*     */ 
/*     */     public V get() {
/* 275 */       boolean success = false;
/*     */       try {
/* 277 */         Object value = this.original.getValueReference().get();
/* 278 */         success = true;
/* 279 */         Object localObject1 = value;
/*     */         return localObject1;
/*     */       }
/*     */       finally
/*     */       {
/* 281 */         if (!success)
/* 282 */           removeEntry(); 
/* 282 */       }throw localObject2;
/*     */     }
/*     */ 
/*     */     public CustomConcurrentHashMap.ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> entry)
/*     */     {
/* 288 */       return new FutureValueReference(ComputingConcurrentHashMap.this, this.original, entry);
/*     */     }
/*     */ 
/*     */     public V waitForValue() throws InterruptedException {
/* 292 */       boolean success = false;
/*     */       try
/*     */       {
/* 295 */         Object value = ComputingConcurrentHashMap.this.waitForValue(this.original);
/* 296 */         success = true;
/* 297 */         Object localObject1 = value;
/*     */         return localObject1;
/*     */       }
/*     */       finally
/*     */       {
/* 299 */         if (!success)
/* 300 */           removeEntry(); 
/* 300 */       }throw localObject2;
/*     */     }
/*     */ 
/*     */     void removeEntry()
/*     */     {
/* 312 */       ComputingConcurrentHashMap.this.removeEntry(this.newEntry);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ComputationExceptionReference<K, V>
/*     */     implements CustomConcurrentHashMap.ValueReference<K, V>
/*     */   {
/*     */     final Throwable t;
/*     */ 
/*     */     ComputationExceptionReference(Throwable t)
/*     */     {
/* 189 */       this.t = t;
/*     */     }
/*     */     public V get() {
/* 192 */       return null;
/*     */     }
/*     */ 
/*     */     public CustomConcurrentHashMap.ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> entry) {
/* 196 */       return this;
/*     */     }
/*     */     public V waitForValue() {
/* 199 */       throw new AsynchronousComputationException(this.t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class NullOutputExceptionReference<K, V>
/*     */     implements CustomConcurrentHashMap.ValueReference<K, V>
/*     */   {
/*     */     final String message;
/*     */ 
/*     */     NullOutputExceptionReference(String message)
/*     */     {
/* 170 */       this.message = message;
/*     */     }
/*     */     public V get() {
/* 173 */       return null;
/*     */     }
/*     */ 
/*     */     public CustomConcurrentHashMap.ValueReference<K, V> copyFor(CustomConcurrentHashMap.ReferenceEntry<K, V> entry) {
/* 177 */       return this;
/*     */     }
/*     */     public V waitForValue() {
/* 180 */       throw new NullOutputException(this.message);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ComputingConcurrentHashMap
 * JD-Core Version:    0.6.0
 */