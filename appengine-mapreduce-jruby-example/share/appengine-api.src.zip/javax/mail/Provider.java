/*    */ package javax.mail;
/*    */ 
/*    */ public class Provider
/*    */ {
/*    */   private final String className;
/*    */   private final String protocol;
/*    */   private final Type type;
/*    */   private final String vendor;
/*    */   private final String version;
/*    */ 
/*    */   public Provider(Type type, String protocol, String className, String vendor, String version)
/*    */   {
/* 51 */     this.protocol = protocol;
/* 52 */     this.className = className;
/* 53 */     this.type = type;
/* 54 */     this.vendor = vendor;
/* 55 */     this.version = version;
/*    */   }
/*    */ 
/*    */   public String getClassName() {
/* 59 */     return this.className;
/*    */   }
/*    */ 
/*    */   public String getProtocol() {
/* 63 */     return this.protocol;
/*    */   }
/*    */ 
/*    */   public Type getType() {
/* 67 */     return this.type;
/*    */   }
/*    */ 
/*    */   public String getVendor() {
/* 71 */     return this.vendor;
/*    */   }
/*    */ 
/*    */   public String getVersion() {
/* 75 */     return this.version;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 79 */     return "protocol=" + this.protocol + "; type=" + this.type + "; class=" + this.className + (this.vendor == null ? "" : new StringBuilder().append("; vendor=").append(this.vendor).toString()) + (this.version == null ? "" : new StringBuilder().append(";version=").append(this.version).toString());
/*    */   }
/*    */ 
/*    */   public static class Type
/*    */   {
/* 33 */     public static final Type STORE = new Type();
/*    */ 
/* 38 */     public static final Type TRANSPORT = new Type();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Provider
 * JD-Core Version:    0.6.0
 */