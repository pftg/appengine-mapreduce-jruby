/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ class QuerySplitComponent
/*     */   implements Comparable<QuerySplitComponent>
/*     */ {
/*     */   private final Order order;
/*     */   private final String propertyName;
/*     */   private final int sortIndex;
/*     */   private final Query.SortDirection direction;
/*  26 */   private final List<List<Query.FilterPredicate>> filters = new ArrayList();
/*     */ 
/*     */   public QuerySplitComponent(String propertyName, List<Query.SortPredicate> sorts)
/*     */   {
/*  38 */     this.propertyName = propertyName;
/*  39 */     for (int i = 0; i < sorts.size(); i++) {
/*  40 */       if (((Query.SortPredicate)sorts.get(i)).getPropertyName().equals(propertyName)) {
/*  41 */         this.order = Order.SEQUENTIAL;
/*  42 */         this.sortIndex = i;
/*  43 */         this.direction = ((Query.SortPredicate)sorts.get(i)).getDirection();
/*  44 */         return;
/*     */       }
/*     */     }
/*  47 */     this.order = Order.ARBITRARY;
/*  48 */     this.sortIndex = -1;
/*  49 */     this.direction = null;
/*     */   }
/*     */ 
/*     */   public void addFilters(Query.FilterPredicate[] filters)
/*     */   {
/*  58 */     this.filters.add(Arrays.asList(filters));
/*     */   }
/*     */ 
/*     */   public List<List<Query.FilterPredicate>> getFilters() {
/*  62 */     return this.filters;
/*     */   }
/*     */ 
/*     */   public Order getOrder() {
/*  66 */     return this.order;
/*     */   }
/*     */ 
/*     */   public int getSortIndex() {
/*  70 */     return this.sortIndex;
/*     */   }
/*     */ 
/*     */   public Query.SortDirection getDirection() {
/*  74 */     return this.direction;
/*     */   }
/*     */ 
/*     */   public int compareTo(QuerySplitComponent o)
/*     */   {
/*  79 */     if (!this.order.equals(o.order)) {
/*  80 */       return this.order.compareTo(o.order);
/*     */     }
/*  82 */     return this.sortIndex - o.sortIndex;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  88 */     return Arrays.hashCode(new Object[] { this.direction, this.filters, this.order, this.propertyName, Integer.valueOf(this.sortIndex) });
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  93 */     if (this == obj)
/*  94 */       return true;
/*  95 */     if (!(obj instanceof QuerySplitComponent)) {
/*  96 */       return false;
/*     */     }
/*     */ 
/*  99 */     QuerySplitComponent other = (QuerySplitComponent)obj;
/*     */ 
/* 101 */     return (this.direction == other.direction) || ((this.direction != null) && (this.direction.equals(other.direction)) && (this.filters == other.filters)) || ((this.filters != null) && (this.filters.equals(other.filters)) && (this.order == other.order)) || ((this.order != null) && (this.order.equals(other.order)) && (this.propertyName == other.propertyName)) || ((this.propertyName != null) && (this.propertyName.equals(other.propertyName)) && (this.sortIndex == other.sortIndex));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 112 */     String result = "QuerySplitComponent [filters=" + this.filters;
/* 113 */     if (this.direction != null) {
/* 114 */       result = result + ", direction=" + this.direction + ", " + "sortIndex=" + this.sortIndex;
/*     */     }
/* 116 */     return result + "]";
/*     */   }
/*     */ 
/*     */   public static enum Order
/*     */   {
/*  20 */     SEQUENTIAL, ARBITRARY;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QuerySplitComponent
 * JD-Core Version:    0.6.0
 */