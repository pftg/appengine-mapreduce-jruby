/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import com.google.apphosting.api.DatastorePb.Error.ErrorCode;
/*     */ import com.google.apphosting.api.DatastorePb.Query;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter.Operator;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order.Direction;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Property;
/*     */ import java.util.Set;
/*     */ 
/*     */ class ValidatedQuery extends NormalizedQuery
/*     */ {
/*  19 */   static final Set<DatastorePb.Query.Filter.Operator> UNSUPPORTED_OPERATORS = makeImmutableSet(new DatastorePb.Query.Filter.Operator[] { DatastorePb.Query.Filter.Operator.IN });
/*     */ 
/*     */   ValidatedQuery(DatastorePb.Query query)
/*     */   {
/*  26 */     super(query);
/*  27 */     validateQuery();
/*     */   }
/*     */ 
/*     */   private void validateQuery()
/*     */   {
/*  37 */     if ((this.query.hasTransaction()) && (!this.query.hasAncestor())) {
/*  38 */       throw new IllegalQueryException("Only ancestor queries are allowed inside transactions.", IllegalQueryType.TRANSACTION_REQUIRES_ANCESTOR);
/*     */     }
/*     */ 
/*  44 */     if (!this.query.hasKind()) {
/*  45 */       for (DatastorePb.Query.Filter filter : this.query.filters()) {
/*  46 */         if (!filter.getProperty(0).getName().equals("__key__")) {
/*  47 */           throw new IllegalQueryException("kind is required for non-__key__ filters", IllegalQueryType.KIND_REQUIRED);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  52 */       for (DatastorePb.Query.Order order : this.query.orders()) {
/*  53 */         if ((!order.getProperty().equals("__key__")) || (order.getDirection() != DatastorePb.Query.Order.Direction.ASCENDING.getValue()))
/*     */         {
/*  55 */           throw new IllegalQueryException("kind is required for all orders except __key__ ascending", IllegalQueryType.KIND_REQUIRED);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  64 */     String ineqProp = null;
/*  65 */     for (DatastorePb.Query.Filter filter : this.query.filters()) {
/*  66 */       int numProps = filter.propertySize();
/*  67 */       if (numProps != 1) {
/*  68 */         throw new IllegalQueryException(String.format("Filter has %s properties, expected 1", new Object[] { Integer.valueOf(numProps) }), IllegalQueryType.FILTER_WITH_MULTIPLE_PROPS);
/*     */       }
/*     */ 
/*  72 */       String propName = filter.getProperty(0).getName();
/*  73 */       if (INEQUALITY_OPERATORS.contains(filter.getOpEnum())) {
/*  74 */         if (ineqProp == null)
/*  75 */           ineqProp = propName;
/*  76 */         else if (!ineqProp.equals(propName)) {
/*  77 */           throw new IllegalQueryException(String.format("Only one inequality filter per query is supported.  Encountered both %s and %s", new Object[] { ineqProp, propName }), IllegalQueryType.MULTIPLE_INEQ_FILTERS);
/*     */         }
/*     */ 
/*     */       }
/*  82 */       else if (UNSUPPORTED_OPERATORS.contains(filter.getOpEnum())) {
/*  83 */         throw new IllegalQueryException(String.format("Unsupported filter operator: %s", new Object[] { Integer.valueOf(filter.getOp()) }), IllegalQueryType.UNSUPPORTED_FILTER);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  89 */     if ((ineqProp != null) && 
/*  90 */       (this.query.orderSize() > 0) && 
/*  91 */       (!ineqProp.equals(this.query.getOrder(0).getProperty())))
/*     */     {
/*  93 */       throw new IllegalQueryException(String.format("The first sort property must be the same as the property to which the inequality filter is applied.  In your query the first sort property is %s but the inequality filter is on %s", new Object[] { this.query.getOrder(0).getProperty(), ineqProp }), IllegalQueryType.FIRST_SORT_NEQ_INEQ_PROP);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 106 */     if (this == o) {
/* 107 */       return true;
/*     */     }
/* 109 */     if ((o == null) || (getClass() != o.getClass())) {
/* 110 */       return false;
/*     */     }
/*     */ 
/* 113 */     ValidatedQuery that = (ValidatedQuery)o;
/*     */ 
/* 116 */     return this.query.equals(that.query);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 124 */     return this.query.hashCode();
/*     */   }
/*     */ 
/*     */   static class IllegalQueryException extends ApiProxy.ApplicationException
/*     */   {
/*     */     private final ValidatedQuery.IllegalQueryType illegalQueryType;
/*     */ 
/*     */     IllegalQueryException(String errorDetail, ValidatedQuery.IllegalQueryType illegalQueryType)
/*     */     {
/* 144 */       super(errorDetail);
/* 145 */       this.illegalQueryType = illegalQueryType;
/*     */     }
/*     */ 
/*     */     ValidatedQuery.IllegalQueryType getIllegalQueryType() {
/* 149 */       return this.illegalQueryType;
/*     */     }
/*     */   }
/*     */ 
/*     */   static enum IllegalQueryType
/*     */   {
/* 129 */     KIND_REQUIRED, 
/* 130 */     UNSUPPORTED_FILTER, 
/* 131 */     FILTER_WITH_MULTIPLE_PROPS, 
/* 132 */     MULTIPLE_INEQ_FILTERS, 
/* 133 */     FIRST_SORT_NEQ_INEQ_PROP, 
/* 134 */     TRANSACTION_REQUIRES_ANCESTOR;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.ValidatedQuery
 * JD-Core Version:    0.6.0
 */