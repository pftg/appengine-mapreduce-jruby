/*    */ package com.google.appengine.api.mail;
/*    */ 
/*    */ public class MailServiceFactory
/*    */ {
/*    */   public static MailService getMailService()
/*    */   {
/* 15 */     return new MailServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.mail.MailServiceFactory
 * JD-Core Version:    0.6.0
 */