/*     */ package com.google.appengine.api.mail;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ class MailServiceImpl
/*     */   implements MailService
/*     */ {
/*     */   static final String PACKAGE = "mail";
/*     */ 
/*     */   public void sendToAdmins(MailService.Message message)
/*     */     throws IllegalArgumentException, IOException
/*     */   {
/*  26 */     doSend(message, true);
/*     */   }
/*     */ 
/*     */   public void send(MailService.Message message)
/*     */     throws IllegalArgumentException, IOException
/*     */   {
/*  32 */     doSend(message, false);
/*     */   }
/*     */ 
/*     */   private void doSend(MailService.Message message, boolean toAdmin)
/*     */     throws IllegalArgumentException, IOException
/*     */   {
/*  49 */     MailServicePb.MailMessage msgProto = new MailServicePb.MailMessage();
/*  50 */     if (message.getSender() != null) {
/*  51 */       msgProto.setSender(message.getSender());
/*     */     }
/*  53 */     if (message.getTo() != null) {
/*  54 */       for (String to : message.getTo()) {
/*  55 */         msgProto.addTo(to);
/*     */       }
/*     */     }
/*  58 */     if (message.getCc() != null) {
/*  59 */       for (String cc : message.getCc()) {
/*  60 */         msgProto.addCc(cc);
/*     */       }
/*     */     }
/*  63 */     if (message.getBcc() != null) {
/*  64 */       for (String bcc : message.getBcc()) {
/*  65 */         msgProto.addBcc(bcc);
/*     */       }
/*     */     }
/*  68 */     if (message.getReplyTo() != null) {
/*  69 */       msgProto.setReplyTo(message.getReplyTo());
/*     */     }
/*  71 */     if (message.getSubject() != null) {
/*  72 */       msgProto.setSubject(message.getSubject());
/*     */     }
/*  74 */     if (message.getTextBody() != null) {
/*  75 */       msgProto.setTextBody(message.getTextBody());
/*     */     }
/*  77 */     if (message.getHtmlBody() != null) {
/*  78 */       msgProto.setHtmlBody(message.getHtmlBody());
/*     */     }
/*  80 */     if (message.getAttachments() != null) {
/*  81 */       for (MailService.Attachment attach : message.getAttachments()) {
/*  82 */         MailServicePb.MailAttachment attachProto = new MailServicePb.MailAttachment();
/*  83 */         attachProto.setFileName(attach.getFileName());
/*  84 */         attachProto.setDataAsBytes(attach.getData());
/*  85 */         msgProto.addAttachment(attachProto);
/*     */       }
/*     */     }
/*     */ 
/*  89 */     byte[] msgBytes = msgProto.toByteArray();
/*     */     try
/*     */     {
/*  92 */       if (toAdmin)
/*  93 */         ApiProxy.makeSyncCall("mail", "SendToAdmins", msgBytes);
/*     */       else
/*  95 */         ApiProxy.makeSyncCall("mail", "Send", msgBytes);
/*     */     }
/*     */     catch (ApiProxy.ApplicationException ex)
/*     */     {
/*  99 */       switch (1.$SwitchMap$com$google$appengine$api$mail$MailServicePb$MailServiceError$ErrorCode[MailServicePb.MailServiceError.ErrorCode.valueOf(ex.getApplicationError()).ordinal()]) {
/*     */       case 1:
/* 101 */         throw new IllegalArgumentException("Bad Request: " + ex.getErrorDetail());
/*     */       case 2:
/*     */       case 3:
/*     */       case 4: } 
/* 104 */     }throw new IllegalArgumentException("Unauthorized Sender: " + ex.getErrorDetail());
/*     */ 
/* 107 */     throw new IllegalArgumentException("Invalid Attachment Type: " + ex.getErrorDetail());
/*     */ 
/* 111 */     throw new IOException(ex.getErrorDetail());
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.mail.MailServiceImpl
 * JD-Core Version:    0.6.0
 */