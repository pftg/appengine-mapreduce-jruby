/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ @GoogleInternal
/*    */ public final class AtomicTracerStatMap
/*    */ {
/* 20 */   private final ConcurrentMap<String, Long> map = new ConcurrentHashMap();
/*    */ 
/*    */   public void incrementBy(String key, long delta)
/*    */   {
/* 32 */     Long oldValue = (Long)this.map.get(key);
/* 33 */     if (oldValue == null)
/*    */     {
/* 35 */       oldValue = (Long)this.map.putIfAbsent(key, Long.valueOf(delta));
/* 36 */       if (oldValue == null) {
/* 37 */         return;
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 42 */     while (!this.map.replace(key, oldValue, Long.valueOf(oldValue.longValue() + delta)))
/*    */     {
/* 45 */       oldValue = (Long)this.map.get(key);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Map<String, Long> getMap()
/*    */   {
/* 53 */     return this.map;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.AtomicTracerStatMap
 * JD-Core Version:    0.6.0
 */