/*    */ package com.google.appengine.api.quota;
/*    */ 
/*    */ public class QuotaServiceFactory
/*    */ {
/* 12 */   private static final QuotaServiceImpl INSTANCE = new QuotaServiceImpl();
/*    */ 
/*    */   public static QuotaService getQuotaService()
/*    */   {
/* 25 */     return INSTANCE;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.quota.QuotaServiceFactory
 * JD-Core Version:    0.6.0
 */