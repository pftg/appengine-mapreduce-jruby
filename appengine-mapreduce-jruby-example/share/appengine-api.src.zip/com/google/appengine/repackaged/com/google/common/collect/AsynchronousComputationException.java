/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ public class AsynchronousComputationException extends ComputationException
/*    */ {
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public AsynchronousComputationException(Throwable cause)
/*    */   {
/* 29 */     super(cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.AsynchronousComputationException
 * JD-Core Version:    0.6.0
 */