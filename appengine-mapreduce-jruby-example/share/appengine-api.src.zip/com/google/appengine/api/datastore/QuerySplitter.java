package com.google.appengine.api.datastore;

import java.util.List;

abstract interface QuerySplitter
{
  public abstract List<QuerySplitComponent> split(List<Query.FilterPredicate> paramList, List<Query.SortPredicate> paramList1);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QuerySplitter
 * JD-Core Version:    0.6.0
 */