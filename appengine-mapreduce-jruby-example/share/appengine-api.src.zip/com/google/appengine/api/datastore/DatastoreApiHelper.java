/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import com.google.appengine.api.NamespaceManager;
/*    */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*    */ import com.google.apphosting.api.ApiProxy;
/*    */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*    */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*    */ import com.google.apphosting.api.ApiProxy.Environment;
/*    */ import com.google.apphosting.api.DatastorePb.Error.ErrorCode;
/*    */ import java.util.ConcurrentModificationException;
/*    */ 
/*    */ public final class DatastoreApiHelper
/*    */ {
/*    */   static final String PACKAGE = "datastore_v3";
/*    */ 
/*    */   public static RuntimeException translateError(ApiProxy.ApplicationException exception)
/*    */   {
/* 28 */     DatastorePb.Error.ErrorCode errorCode = DatastorePb.Error.ErrorCode.valueOf(exception.getApplicationError());
/* 29 */     if (errorCode == null) {
/* 30 */       return new DatastoreFailureException(exception.getErrorDetail());
/*    */     }
/* 32 */     switch (1.$SwitchMap$com$google$apphosting$api$DatastorePb$Error$ErrorCode[errorCode.ordinal()]) {
/*    */     case 1:
/* 34 */       return new IllegalArgumentException(exception.getErrorDetail());
/*    */     case 2:
/* 37 */       return new ConcurrentModificationException(exception.getErrorDetail());
/*    */     case 3:
/* 40 */       return new DatastoreNeedIndexException(exception.getErrorDetail());
/*    */     case 4:
/*    */     case 5:
/* 44 */       return new DatastoreTimeoutException(exception.getErrorDetail());
/*    */     case 6:
/* 47 */       return new CommittedButStillApplyingException(exception.getErrorDetail());
/*    */     case 7:
/*    */     }
/*    */ 
/* 51 */     return new DatastoreFailureException(exception.getErrorDetail());
/*    */   }
/*    */ 
/*    */   static void makeSyncCall(ApiProxy.ApiConfig apiConfig, String method, ProtocolMessage<?> request, ProtocolMessage<?> response)
/*    */   {
/*    */     try
/*    */     {
/* 58 */       byte[] responseBytes = ApiProxy.makeSyncCall("datastore_v3", method, request.toByteArray(), apiConfig);
/*    */ 
/* 63 */       if (responseBytes != null)
/* 64 */         response.mergeFrom(responseBytes);
/*    */     }
/*    */     catch (ApiProxy.ApplicationException exception) {
/* 67 */       throw translateError(exception);
/*    */     }
/*    */   }
/*    */ 
/*    */   static String getCurrentAppId() {
/* 72 */     ApiProxy.Environment environment = ApiProxy.getCurrentEnvironment();
/* 73 */     if (environment == null) {
/* 74 */       throw new NullPointerException("No API environment is registered for this thread.");
/*    */     }
/* 76 */     return environment.getAppId();
/*    */   }
/*    */ 
/*    */   static AppIdNamespace getCurrentAppIdNamespace()
/*    */   {
/* 84 */     return getCurrentAppIdNamespace(getCurrentAppId());
/*    */   }
/*    */ 
/*    */   static AppIdNamespace getCurrentAppIdNamespace(String appId)
/*    */   {
/* 92 */     String namespace = NamespaceManager.get();
/* 93 */     namespace = namespace == null ? "" : namespace;
/* 94 */     return new AppIdNamespace(appId, namespace);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreApiHelper
 * JD-Core Version:    0.6.0
 */