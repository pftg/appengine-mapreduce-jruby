/*    */ package com.google.apphosting.utils.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.logging.Logger;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class WarmupServlet extends HttpServlet
/*    */ {
/* 23 */   private static final Logger logger = Logger.getLogger(SessionCleanupServlet.class.getName());
/*    */ 
/*    */   public void init()
/*    */   {
/* 27 */     logger.fine("Initializing warm-up servlet.");
/*    */   }
/*    */ 
/*    */   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException
/*    */   {
/* 32 */     logger.info("Executing warm-up request.");
/*    */ 
/* 35 */     Thread.currentThread().getContextClassLoader().getResources("_ah_nonexistent");
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.utils.servlet.WarmupServlet
 * JD-Core Version:    0.6.0
 */