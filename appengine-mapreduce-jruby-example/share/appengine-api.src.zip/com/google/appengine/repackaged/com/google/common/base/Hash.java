/*      */ package com.google.appengine.repackaged.com.google.common.base;
/*      */ 
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigInteger;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.IntBuffer;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.util.Arrays;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GoogleInternal
/*      */ public final class Hash
/*      */ {
/*   55 */   private static final Pattern FPRINT96_FORMAT = Pattern.compile("\\p{XDigit}{8}_\\p{XDigit}{8}_\\p{XDigit}{8}");
/*      */   static final int SEED32 = 314159265;
/*      */   static final long SEED64 = 3141592653589793238L;
/*      */   static final int CONSTANT32 = -1640531527;
/*      */   static final long CONSTANT64 = -2266404186210603134L;
/*      */ 
/*      */   public static int hash32(int value)
/*      */   {
/*   81 */     return mix32(value, -1640531527, 314159265);
/*      */   }
/*      */ 
/*      */   public static int hash32(int value, int seed)
/*      */   {
/*   92 */     return mix32(value, -1640531527, seed);
/*      */   }
/*      */ 
/*      */   public static int consistentHash32(long h, int n)
/*      */   {
/*  111 */     Preconditions.checkArgument(n > 0, "n must be positive: %s", new Object[] { Integer.valueOf(n) });
/*      */ 
/*  113 */     int b = 0;
/*  114 */     int j = 1;
/*      */ 
/*  117 */     while ((j > 0) && (j <= n)) {
/*  118 */       b = j;
/*  119 */       h = 2862933555777941757L * h + 1L;
/*      */ 
/*  122 */       double inv = 2147483648.0D / (int)((h >>> 33) + 1L);
/*  123 */       j = (int)(b * inv + 1.0D);
/*      */     }
/*      */ 
/*  126 */     return b - 1;
/*      */   }
/*      */ 
/*      */   public static int hash32(long value)
/*      */   {
/*  140 */     return (int)mix64(value, -2266404186210603134L, 3141592653589793238L);
/*      */   }
/*      */ 
/*      */   public static int hash32(long value, long seed)
/*      */   {
/*  152 */     return (int)mix64(value, -2266404186210603134L, seed);
/*      */   }
/*      */ 
/*      */   public static long hash64(long value)
/*      */   {
/*  162 */     return mix64(value, -2266404186210603134L, 3141592653589793238L);
/*      */   }
/*      */ 
/*      */   public static long hash64(long value, long seed)
/*      */   {
/*  173 */     return mix64(value, -2266404186210603134L, seed);
/*      */   }
/*      */ 
/*      */   public static long hash64Cat(long x, long y)
/*      */   {
/*  185 */     return mix64(x, -2266404186210603134L, y);
/*      */   }
/*      */ 
/*      */   public static int hash32(@Nullable String value)
/*      */   {
/*  201 */     return hash32(value, 314159265);
/*      */   }
/*      */ 
/*      */   public static int hash32(@Nullable String value, int seed)
/*      */   {
/*  212 */     if (value == null) {
/*  213 */       return hash32(null, 0, 0, seed);
/*      */     }
/*  215 */     return hash32(value.getBytes(), seed);
/*      */   }
/*      */ 
/*      */   public static long hash64(@Nullable String value)
/*      */   {
/*  225 */     return hash64(value, 3141592653589793238L);
/*      */   }
/*      */ 
/*      */   public static long hash64(@Nullable String value, long seed)
/*      */   {
/*  236 */     if (value == null) {
/*  237 */       return hash64(null, 0, 0, seed);
/*      */     }
/*  239 */     return hash64(value.getBytes(), seed);
/*      */   }
/*      */ 
/*      */   public static long fingerprint(String value)
/*      */   {
/*      */     try
/*      */     {
/*  261 */       byte[] temp = value.getBytes("UTF-8");
/*  262 */       return fingerprint(temp, 0, temp.length);
/*      */     } catch (UnsupportedEncodingException e) {
/*  264 */       X.assertTrue(false);
/*  265 */     }return 0L;
/*      */   }
/*      */ 
/*      */   public static byte[] fprint96(String value)
/*      */   {
/*  284 */     return fprint96(value.getBytes(Charsets.UTF_8));
/*      */   }
/*      */ 
/*      */   public static byte[] fprint96(byte[] value)
/*      */   {
/*      */     MessageDigest md;
/*      */     try
/*      */     {
/*  300 */       md = MessageDigest.getInstance("SHA-1");
/*      */     } catch (NoSuchAlgorithmException e) {
/*  302 */       throw new IllegalStateException("SHA-1 should be available in the JVM.");
/*      */     }
/*  304 */     md.update(value);
/*  305 */     byte[] hash = md.digest();
/*  306 */     return Arrays.copyOfRange(hash, 0, 12);
/*      */   }
/*      */ 
/*      */   public static String fprint96AsString(String value)
/*      */   {
/*  324 */     return formatFprint96AsString(fprint96(value));
/*      */   }
/*      */ 
/*      */   public static String fprint96AsKey(String value)
/*      */   {
/*  338 */     return fprint96AsKey(value.getBytes(Charsets.UTF_8));
/*      */   }
/*      */ 
/*      */   public static String fprint96AsKey(byte[] value)
/*      */   {
/*  352 */     byte[] fp96 = fprint96(value);
/*  353 */     char[] chars = new char[12];
/*  354 */     for (int i = 0; i < 12; i++) {
/*  355 */       chars[i] = (char)(fp96[i] & 0xFF);
/*      */     }
/*  357 */     return new String(chars);
/*      */   }
/*      */ 
/*      */   public static byte[] keyToFprint96(String key)
/*      */   {
/*  369 */     byte[] fprint96 = new byte[12];
/*  370 */     for (int i = 0; i < 12; i++) {
/*  371 */       fprint96[i] = (byte)(key.charAt(i) & 0xFF);
/*      */     }
/*  373 */     return fprint96;
/*      */   }
/*      */ 
/*      */   public static int fprint96KeyModShard(String value, int numShards)
/*      */   {
/*  384 */     return fprint96KeyModShardFromKey(fprint96AsKey(value), numShards);
/*      */   }
/*      */ 
/*      */   public static int fprint96KeyModShardFromKey(String key, int numShards)
/*      */   {
/*  398 */     Preconditions.checkArgument(numShards > 0);
/*      */ 
/*  400 */     IntBuffer ib = ByteBuffer.wrap(keyToFprint96(key)).asIntBuffer();
/*  401 */     BigInteger mod = BigInteger.valueOf(numShards);
/*      */ 
/*  407 */     BigInteger group0 = BigInteger.valueOf(ib.get() & 0xFFFFFFFF);
/*  408 */     BigInteger group1 = BigInteger.valueOf(ib.get() & 0xFFFFFFFF);
/*  409 */     BigInteger group2 = BigInteger.valueOf(ib.get() & 0xFFFFFFFF);
/*  410 */     group0 = group0.shiftLeft(32);
/*  411 */     BigInteger remainder = group0.or(group1).mod(mod);
/*  412 */     return remainder.shiftLeft(32).or(group2).mod(mod).intValue();
/*      */   }
/*      */ 
/*      */   public static String formatFprint96AsString(byte[] value)
/*      */   {
/*  427 */     Preconditions.checkArgument(value.length == 12);
/*      */ 
/*  429 */     IntBuffer ib = ByteBuffer.wrap(value).asIntBuffer();
/*  430 */     long group0 = ib.get() & 0xFFFFFFFF;
/*  431 */     long group1 = ib.get() & 0xFFFFFFFF;
/*  432 */     long group2 = ib.get() & 0xFFFFFFFF;
/*  433 */     return String.format("%08X_%08X_%08X", new Object[] { Long.valueOf(group0), Long.valueOf(group1), Long.valueOf(group2) });
/*      */   }
/*      */ 
/*      */   public static byte[] tryStringToFprint96(String fpString)
/*      */   {
/*  450 */     Preconditions.checkArgument(FPRINT96_FORMAT.matcher(fpString).matches());
/*      */ 
/*  452 */     byte[] fp = new byte[12];
/*  453 */     int str = 0;
/*  454 */     for (int i = 0; i < 12; i++) {
/*  455 */       if ((i == 4) || (i == 8)) {
/*  456 */         str++;
/*      */       }
/*      */ 
/*  459 */       fp[i] = (byte)Integer.parseInt(fpString.substring(str, str + 2), 16);
/*  460 */       str += 2;
/*      */     }
/*  462 */     return fp;
/*      */   }
/*      */ 
/*      */   public static int hash32(byte[] value)
/*      */   {
/*  476 */     return hash32(value, 0, value == null ? 0 : value.length);
/*      */   }
/*      */ 
/*      */   public static int hash32(byte[] value, int offset, int length)
/*      */   {
/*  488 */     return hash32(value, offset, length, 314159265);
/*      */   }
/*      */ 
/*      */   public static int hash32(byte[] value, int seed)
/*      */   {
/*  499 */     return hash32(value, 0, value == null ? 0 : value.length, seed);
/*      */   }
/*      */ 
/*      */   public static int hash32(byte[] value, int offset, int length, int seed)
/*      */   {
/*  513 */     int a = -1640531527;
/*  514 */     int b = a;
/*  515 */     int c = seed;
/*      */ 
/*  518 */     for (int keylen = length; keylen >= 12; offset += 12) {
/*  519 */       a += word32At(value, offset);
/*  520 */       b += word32At(value, offset + 4);
/*  521 */       c += word32At(value, offset + 8);
/*      */ 
/*  524 */       a -= b; a -= c; a ^= c >>> 13;
/*  525 */       b -= c; b -= a; b ^= a << 8;
/*  526 */       c -= a; c -= b; c ^= b >>> 13;
/*  527 */       a -= b; a -= c; a ^= c >>> 12;
/*  528 */       b -= c; b -= a; b ^= a << 16;
/*  529 */       c -= a; c -= b; c ^= b >>> 5;
/*  530 */       a -= b; a -= c; a ^= c >>> 3;
/*  531 */       b -= c; b -= a; b ^= a << 10;
/*  532 */       c -= a; c -= b; c ^= b >>> 15;
/*      */ 
/*  518 */       keylen -= 12;
/*      */     }
/*      */ 
/*  536 */     c += length;
/*  537 */     switch (keylen) {
/*      */     case 11:
/*  539 */       c += (value[(offset + 10)] << 24);
/*      */     case 10:
/*  541 */       c += ((value[(offset + 9)] & 0xFF) << 16);
/*      */     case 9:
/*  543 */       c += ((value[(offset + 8)] & 0xFF) << 8);
/*      */     case 8:
/*  546 */       b += word32At(value, offset + 4);
/*  547 */       a += word32At(value, offset);
/*  548 */       break;
/*      */     case 7:
/*  550 */       b += ((value[(offset + 6)] & 0xFF) << 16);
/*      */     case 6:
/*  552 */       b += ((value[(offset + 5)] & 0xFF) << 8);
/*      */     case 5:
/*  554 */       b += (value[(offset + 4)] & 0xFF);
/*      */     case 4:
/*  556 */       a += word32At(value, offset);
/*  557 */       break;
/*      */     case 3:
/*  559 */       a += ((value[(offset + 2)] & 0xFF) << 16);
/*      */     case 2:
/*  561 */       a += ((value[(offset + 1)] & 0xFF) << 8);
/*      */     case 1:
/*  563 */       a += (value[(offset + 0)] & 0xFF);
/*      */     }
/*      */ 
/*  566 */     return mix32(a, b, c);
/*      */   }
/*      */ 
/*      */   public static long hash64(byte[] value)
/*      */   {
/*  576 */     return hash64(value, 0, value == null ? 0 : value.length);
/*      */   }
/*      */ 
/*      */   public static long hash64(byte[] value, int offset, int length)
/*      */   {
/*  588 */     return hash64(value, offset, length, 3141592653589793238L);
/*      */   }
/*      */ 
/*      */   public static long hash64(byte[] value, long seed)
/*      */   {
/*  599 */     return hash64(value, 0, value == null ? 0 : value.length, seed);
/*      */   }
/*      */ 
/*      */   public static long hash64(byte[] value, int offset, int length, long seed)
/*      */   {
/*  613 */     long a = -2266404186210603134L;
/*  614 */     long b = a;
/*  615 */     long c = seed;
/*      */ 
/*  618 */     for (int keylen = length; keylen >= 24; offset += 24) {
/*  619 */       a += word64At(value, offset);
/*  620 */       b += word64At(value, offset + 8);
/*  621 */       c += word64At(value, offset + 16);
/*      */ 
/*  624 */       a -= b; a -= c; a ^= c >>> 43;
/*  625 */       b -= c; b -= a; b ^= a << 9;
/*  626 */       c -= a; c -= b; c ^= b >>> 8;
/*  627 */       a -= b; a -= c; a ^= c >>> 38;
/*  628 */       b -= c; b -= a; b ^= a << 23;
/*  629 */       c -= a; c -= b; c ^= b >>> 5;
/*  630 */       a -= b; a -= c; a ^= c >>> 35;
/*  631 */       b -= c; b -= a; b ^= a << 49;
/*  632 */       c -= a; c -= b; c ^= b >>> 11;
/*  633 */       a -= b; a -= c; a ^= c >>> 12;
/*  634 */       b -= c; b -= a; b ^= a << 18;
/*  635 */       c -= a; c -= b; c ^= b >>> 22;
/*      */ 
/*  618 */       keylen -= 24;
/*      */     }
/*      */ 
/*  638 */     c += length;
/*  639 */     switch (keylen) {
/*      */     case 23:
/*  641 */       c += (value[(offset + 22)] << 56);
/*      */     case 22:
/*  643 */       c += ((value[(offset + 21)] & 0xFF) << 48);
/*      */     case 21:
/*  645 */       c += ((value[(offset + 20)] & 0xFF) << 40);
/*      */     case 20:
/*  647 */       c += ((value[(offset + 19)] & 0xFF) << 32);
/*      */     case 19:
/*  649 */       c += ((value[(offset + 18)] & 0xFF) << 24);
/*      */     case 18:
/*  651 */       c += ((value[(offset + 17)] & 0xFF) << 16);
/*      */     case 17:
/*  653 */       c += ((value[(offset + 16)] & 0xFF) << 8);
/*      */     case 16:
/*  656 */       b += word64At(value, offset + 8);
/*  657 */       a += word64At(value, offset);
/*  658 */       break;
/*      */     case 15:
/*  660 */       b += ((value[(offset + 14)] & 0xFF) << 48);
/*      */     case 14:
/*  662 */       b += ((value[(offset + 13)] & 0xFF) << 40);
/*      */     case 13:
/*  664 */       b += ((value[(offset + 12)] & 0xFF) << 32);
/*      */     case 12:
/*  666 */       b += ((value[(offset + 11)] & 0xFF) << 24);
/*      */     case 11:
/*  668 */       b += ((value[(offset + 10)] & 0xFF) << 16);
/*      */     case 10:
/*  670 */       b += ((value[(offset + 9)] & 0xFF) << 8);
/*      */     case 9:
/*  672 */       b += (value[(offset + 8)] & 0xFF);
/*      */     case 8:
/*  674 */       a += word64At(value, offset);
/*  675 */       break;
/*      */     case 7:
/*  677 */       a += ((value[(offset + 6)] & 0xFF) << 48);
/*      */     case 6:
/*  679 */       a += ((value[(offset + 5)] & 0xFF) << 40);
/*      */     case 5:
/*  681 */       a += ((value[(offset + 4)] & 0xFF) << 32);
/*      */     case 4:
/*  683 */       a += ((value[(offset + 3)] & 0xFF) << 24);
/*      */     case 3:
/*  685 */       a += ((value[(offset + 2)] & 0xFF) << 16);
/*      */     case 2:
/*  687 */       a += ((value[(offset + 1)] & 0xFF) << 8);
/*      */     case 1:
/*  689 */       a += (value[(offset + 0)] & 0xFF);
/*      */     }
/*      */ 
/*  692 */     return mix64(a, b, c);
/*      */   }
/*      */ 
/*      */   public static int word32At(byte[] bytes, int offset)
/*      */   {
/*  702 */     return bytes[(offset + 0)] + (bytes[(offset + 1)] << 8) + (bytes[(offset + 2)] << 16) + (bytes[(offset + 3)] << 24);
/*      */   }
/*      */ 
/*      */   private static long word64At(byte[] bytes, int offset)
/*      */   {
/*  709 */     return (bytes[(offset + 0)] & 0xFF) + ((bytes[(offset + 1)] & 0xFF) << 8) + ((bytes[(offset + 2)] & 0xFF) << 16) + ((bytes[(offset + 3)] & 0xFF) << 24) + ((bytes[(offset + 4)] & 0xFF) << 32) + ((bytes[(offset + 5)] & 0xFF) << 40) + ((bytes[(offset + 6)] & 0xFF) << 48) + ((bytes[(offset + 7)] & 0xFF) << 56);
/*      */   }
/*      */ 
/*      */   public static long fingerprint(byte[] value)
/*      */   {
/*  730 */     return fingerprint(value, 0, value == null ? 0 : value.length);
/*      */   }
/*      */ 
/*      */   public static long fingerprint(byte[] value, int offset, int length)
/*      */   {
/*  747 */     int hi = hash32(value, offset, length, 0);
/*  748 */     int lo = hash32(value, offset, length, 102072);
/*  749 */     if ((hi == 0) && ((lo == 0) || (lo == 1)))
/*      */     {
/*  751 */       hi ^= 319790063;
/*  752 */       lo ^= -1801410264;
/*      */     }
/*  754 */     return hi << 32 | lo & 0xFFFFFFFF;
/*      */   }
/*      */ 
/*      */   public static int hash32(ByteBuffer buf, int length)
/*      */   {
/*  775 */     if (buf.order() != ByteOrder.LITTLE_ENDIAN) {
/*  776 */       throw new IllegalArgumentException("Buffer must be little endian");
/*      */     }
/*  778 */     int a = -1640531527;
/*  779 */     int b = a;
/*  780 */     int c = 314159265;
/*      */ 
/*  783 */     int numGroups = length / 12;
/*  784 */     for (int i = 0; i < numGroups; i++) {
/*  785 */       a += getInt(buf);
/*  786 */       b += getInt(buf);
/*  787 */       c += getInt(buf);
/*      */ 
/*  790 */       a -= b; a -= c; a ^= c >>> 13;
/*  791 */       b -= c; b -= a; b ^= a << 8;
/*  792 */       c -= a; c -= b; c ^= b >>> 13;
/*  793 */       a -= b; a -= c; a ^= c >>> 12;
/*  794 */       b -= c; b -= a; b ^= a << 16;
/*  795 */       c -= a; c -= b; c ^= b >>> 5;
/*  796 */       a -= b; a -= c; a ^= c >>> 3;
/*  797 */       b -= c; b -= a; b ^= a << 10;
/*  798 */       c -= a; c -= b; c ^= b >>> 15;
/*      */     }
/*      */ 
/*  802 */     c += length;
/*  803 */     int position = buf.position();
/*  804 */     switch (length - numGroups * 12) {
/*      */     case 11:
/*  806 */       c += (buf.get(position + 10) << 24);
/*      */     case 10:
/*  808 */       c += ((buf.get(position + 9) & 0xFF) << 16);
/*      */     case 9:
/*  810 */       c += ((buf.get(position + 8) & 0xFF) << 8);
/*      */     case 8:
/*  813 */       b += getInt(buf, position + 4);
/*  814 */       a += getInt(buf, position);
/*  815 */       break;
/*      */     case 7:
/*  817 */       b += ((buf.get(position + 6) & 0xFF) << 16);
/*      */     case 6:
/*  819 */       b += ((buf.get(position + 5) & 0xFF) << 8);
/*      */     case 5:
/*  821 */       b += (buf.get(position + 4) & 0xFF);
/*      */     case 4:
/*  823 */       a += getInt(buf, position);
/*  824 */       break;
/*      */     case 3:
/*  826 */       a += ((buf.get(position + 2) & 0xFF) << 16);
/*      */     case 2:
/*  828 */       a += ((buf.get(position + 1) & 0xFF) << 8);
/*      */     case 1:
/*  830 */       a += (buf.get(position) & 0xFF);
/*      */     }
/*      */ 
/*  834 */     return mix32(a, b, c);
/*      */   }
/*      */ 
/*      */   public static long hash64(ByteBuffer buf, int length)
/*      */   {
/*  851 */     if (buf.order() != ByteOrder.LITTLE_ENDIAN) {
/*  852 */       throw new IllegalArgumentException("Buffer must be little endian");
/*      */     }
/*  854 */     long a = -2266404186210603134L;
/*  855 */     long b = a;
/*  856 */     long c = 3141592653589793238L;
/*      */ 
/*  859 */     int numGroups = length / 24;
/*  860 */     for (int i = 0; i < numGroups; i++) {
/*  861 */       a += buf.getLong();
/*  862 */       b += buf.getLong();
/*  863 */       c += buf.getLong();
/*      */ 
/*  866 */       a -= b; a -= c; a ^= c >>> 43;
/*  867 */       b -= c; b -= a; b ^= a << 9;
/*  868 */       c -= a; c -= b; c ^= b >>> 8;
/*  869 */       a -= b; a -= c; a ^= c >>> 38;
/*  870 */       b -= c; b -= a; b ^= a << 23;
/*  871 */       c -= a; c -= b; c ^= b >>> 5;
/*  872 */       a -= b; a -= c; a ^= c >>> 35;
/*  873 */       b -= c; b -= a; b ^= a << 49;
/*  874 */       c -= a; c -= b; c ^= b >>> 11;
/*  875 */       a -= b; a -= c; a ^= c >>> 12;
/*  876 */       b -= c; b -= a; b ^= a << 18;
/*  877 */       c -= a; c -= b; c ^= b >>> 22;
/*      */     }
/*      */ 
/*  881 */     c += length;
/*  882 */     int position = buf.position();
/*  883 */     switch (length - numGroups * 24) {
/*      */     case 23:
/*  885 */       c += (buf.get(position + 22) << 56);
/*      */     case 22:
/*  887 */       c += ((buf.get(position + 21) & 0xFF) << 48);
/*      */     case 21:
/*  889 */       c += ((buf.get(position + 20) & 0xFF) << 40);
/*      */     case 20:
/*  891 */       c += ((buf.get(position + 19) & 0xFF) << 32);
/*      */     case 19:
/*  893 */       c += ((buf.get(position + 18) & 0xFF) << 24);
/*      */     case 18:
/*  895 */       c += ((buf.get(position + 17) & 0xFF) << 16);
/*      */     case 17:
/*  897 */       c += ((buf.get(position + 16) & 0xFF) << 8);
/*      */     case 16:
/*  900 */       b += buf.getLong(position + 8);
/*  901 */       a += buf.getLong(position);
/*  902 */       break;
/*      */     case 15:
/*  904 */       b += ((buf.get(position + 14) & 0xFF) << 48);
/*      */     case 14:
/*  906 */       b += ((buf.get(position + 13) & 0xFF) << 40);
/*      */     case 13:
/*  908 */       b += ((buf.get(position + 12) & 0xFF) << 32);
/*      */     case 12:
/*  910 */       b += ((buf.get(position + 11) & 0xFF) << 24);
/*      */     case 11:
/*  912 */       b += ((buf.get(position + 10) & 0xFF) << 16);
/*      */     case 10:
/*  914 */       b += ((buf.get(position + 9) & 0xFF) << 8);
/*      */     case 9:
/*  916 */       b += (buf.get(position + 8) & 0xFF);
/*      */     case 8:
/*  918 */       a += buf.getLong(position);
/*  919 */       break;
/*      */     case 7:
/*  921 */       a += ((buf.get(position + 6) & 0xFF) << 48);
/*      */     case 6:
/*  923 */       a += ((buf.get(position + 5) & 0xFF) << 40);
/*      */     case 5:
/*  925 */       a += ((buf.get(position + 4) & 0xFF) << 32);
/*      */     case 4:
/*  927 */       a += ((buf.get(position + 3) & 0xFF) << 24);
/*      */     case 3:
/*  929 */       a += ((buf.get(position + 2) & 0xFF) << 16);
/*      */     case 2:
/*  931 */       a += ((buf.get(position + 1) & 0xFF) << 8);
/*      */     case 1:
/*  933 */       a += (buf.get(position + 0) & 0xFF);
/*      */     }
/*      */ 
/*  937 */     return mix64(a, b, c);
/*      */   }
/*      */ 
/*      */   private static int getInt(ByteBuffer buf)
/*      */   {
/*  948 */     return addSignCruft(buf.getInt());
/*      */   }
/*      */ 
/*      */   private static int getInt(ByteBuffer buf, int pos)
/*      */   {
/*  957 */     return addSignCruft(buf.getInt(pos));
/*      */   }
/*      */ 
/*      */   private static int addSignCruft(int i)
/*      */   {
/*  973 */     return (i & 0x7F7F7F7F) - (i & 0x80808080);
/*      */   }
/*      */ 
/*      */   static int mix32(int a, int b, int c)
/*      */   {
/*  984 */     a -= b; a -= c; a ^= c >>> 13;
/*  985 */     b -= c; b -= a; b ^= a << 8;
/*  986 */     c -= a; c -= b; c ^= b >>> 13;
/*  987 */     a -= b; a -= c; a ^= c >>> 12;
/*  988 */     b -= c; b -= a; b ^= a << 16;
/*  989 */     c -= a; c -= b; c ^= b >>> 5;
/*  990 */     a -= b; a -= c; a ^= c >>> 3;
/*  991 */     b -= c; b -= a; b ^= a << 10;
/*  992 */     c -= a; c -= b; c ^= b >>> 15;
/*  993 */     return c;
/*      */   }
/*      */ 
/*      */   static long mix64(long a, long b, long c)
/*      */   {
/* 1000 */     a -= b; a -= c; a ^= c >>> 43;
/* 1001 */     b -= c; b -= a; b ^= a << 9;
/* 1002 */     c -= a; c -= b; c ^= b >>> 8;
/* 1003 */     a -= b; a -= c; a ^= c >>> 38;
/* 1004 */     b -= c; b -= a; b ^= a << 23;
/* 1005 */     c -= a; c -= b; c ^= b >>> 5;
/* 1006 */     a -= b; a -= c; a ^= c >>> 35;
/* 1007 */     b -= c; b -= a; b ^= a << 49;
/* 1008 */     c -= a; c -= b; c ^= b >>> 11;
/* 1009 */     a -= b; a -= c; a ^= c >>> 12;
/* 1010 */     b -= c; b -= a; b ^= a << 18;
/* 1011 */     c -= a; c -= b; c ^= b >>> 22;
/* 1012 */     return c;
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Hash
 * JD-Core Version:    0.6.0
 */