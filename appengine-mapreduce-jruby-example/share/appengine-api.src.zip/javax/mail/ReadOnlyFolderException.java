/*    */ package javax.mail;
/*    */ 
/*    */ public class ReadOnlyFolderException extends MessagingException
/*    */ {
/*    */   private transient Folder _folder;
/*    */ 
/*    */   public ReadOnlyFolderException(Folder folder)
/*    */   {
/* 29 */     this(folder, "Folder not found: " + folder.getName());
/*    */   }
/*    */ 
/*    */   public ReadOnlyFolderException(Folder folder, String message) {
/* 33 */     super(message);
/* 34 */     this._folder = folder;
/*    */   }
/*    */ 
/*    */   public Folder getFolder() {
/* 38 */     return this._folder;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.ReadOnlyFolderException
 * JD-Core Version:    0.6.0
 */