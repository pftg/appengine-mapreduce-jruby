/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ public final class RpcUtil
/*     */ {
/*     */   public static <Type extends Message> RpcCallback<Type> specializeCallback(RpcCallback<Message> originalCallback)
/*     */   {
/*  21 */     return originalCallback;
/*     */   }
/*     */ 
/*     */   public static <Type extends Message> RpcCallback<Message> generalizeCallback(RpcCallback<Type> originalCallback, Class<Type> originalClass, Type defaultInstance)
/*     */   {
/*  45 */     return new RpcCallback(originalClass, defaultInstance, originalCallback) {
/*     */       public void run(Message parameter) {
/*     */         Message typedParameter;
/*     */         try { typedParameter = (Message)this.val$originalClass.cast(parameter);
/*     */         } catch (ClassCastException ignored) {
/*  51 */           typedParameter = RpcUtil.access$000(this.val$defaultInstance, parameter);
/*     */         }
/*  53 */         this.val$originalCallback.run(typedParameter);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private static <Type extends Message> Type copyAsType(Type typeDefaultInstance, Message source)
/*     */   {
/*  66 */     return typeDefaultInstance.newBuilderForType().mergeFrom(source).build();
/*     */   }
/*     */ 
/*     */   public static <ParameterType> RpcCallback<ParameterType> newOneTimeCallback(RpcCallback<ParameterType> originalCallback)
/*     */   {
/*  80 */     return new RpcCallback(originalCallback) {
/*  81 */       private boolean alreadyCalled = false;
/*     */ 
/*     */       public void run(ParameterType parameter) {
/*  84 */         synchronized (this) {
/*  85 */           if (this.alreadyCalled) {
/*  86 */             throw new RpcUtil.AlreadyCalledException();
/*     */           }
/*  88 */           this.alreadyCalled = true;
/*     */         }
/*     */ 
/*  91 */         this.val$originalCallback.run(parameter);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static final class AlreadyCalledException extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = 5469741279507848266L;
/*     */ 
/*     */     public AlreadyCalledException() {
/* 103 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.RpcUtil
 * JD-Core Version:    0.6.0
 */