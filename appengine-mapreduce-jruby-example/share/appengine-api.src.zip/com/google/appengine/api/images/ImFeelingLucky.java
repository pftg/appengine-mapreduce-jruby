/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ final class ImFeelingLucky extends Transform
/*    */ {
/*    */   void apply(ImagesServicePb.ImagesTransformRequest request)
/*    */   {
/* 15 */     request.addTransform().setAutolevels(true);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.ImFeelingLucky
 * JD-Core Version:    0.6.0
 */