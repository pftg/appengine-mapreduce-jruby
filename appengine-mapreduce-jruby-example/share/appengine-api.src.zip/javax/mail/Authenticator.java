/*    */ package javax.mail;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ public abstract class Authenticator
/*    */ {
/*    */   private InetAddress host;
/*    */   private int port;
/*    */   private String prompt;
/*    */   private String protocol;
/*    */   private String username;
/*    */ 
/*    */   synchronized PasswordAuthentication authenticate(InetAddress host, int port, String protocol, String prompt, String username)
/*    */   {
/* 35 */     this.host = host;
/* 36 */     this.port = port;
/* 37 */     this.protocol = protocol;
/* 38 */     this.prompt = prompt;
/* 39 */     this.username = username;
/* 40 */     return getPasswordAuthentication();
/*    */   }
/*    */ 
/*    */   protected final String getDefaultUserName() {
/* 44 */     return this.username;
/*    */   }
/*    */ 
/*    */   protected PasswordAuthentication getPasswordAuthentication() {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   protected final int getRequestingPort() {
/* 52 */     return this.port;
/*    */   }
/*    */ 
/*    */   protected final String getRequestingPrompt() {
/* 56 */     return this.prompt;
/*    */   }
/*    */ 
/*    */   protected final String getRequestingProtocol() {
/* 60 */     return this.protocol;
/*    */   }
/*    */ 
/*    */   protected final InetAddress getRequestingSite() {
/* 64 */     return this.host;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Authenticator
 * JD-Core Version:    0.6.0
 */