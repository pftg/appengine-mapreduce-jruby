/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class Flags
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private int system_flags;
/*     */   private final Hashtable user_flags;
/*     */ 
/*     */   public Flags()
/*     */   {
/*  90 */     this.user_flags = new Hashtable();
/*     */   }
/*     */ 
/*     */   public Flags(Flag flag)
/*     */   {
/*  98 */     this.system_flags = flag.mask;
/*  99 */     this.user_flags = new Hashtable();
/*     */   }
/*     */ 
/*     */   public Flags(Flags flags)
/*     */   {
/* 107 */     this.system_flags = flags.system_flags;
/* 108 */     this.user_flags = new Hashtable(flags.user_flags);
/*     */   }
/*     */ 
/*     */   public Flags(String name)
/*     */   {
/* 117 */     this.user_flags = new Hashtable();
/* 118 */     this.user_flags.put(name.toLowerCase(), name);
/*     */   }
/*     */ 
/*     */   public void add(Flag flag)
/*     */   {
/* 126 */     this.system_flags |= flag.mask;
/*     */   }
/*     */ 
/*     */   public void add(Flags flags)
/*     */   {
/* 135 */     this.system_flags |= flags.system_flags;
/* 136 */     this.user_flags.putAll(flags.user_flags);
/*     */   }
/*     */ 
/*     */   public void add(String name)
/*     */   {
/* 145 */     this.user_flags.put(name.toLowerCase(), name);
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 153 */     return new Flags(this);
/*     */   }
/*     */ 
/*     */   public boolean contains(Flag flag)
/*     */   {
/* 162 */     return (this.system_flags & flag.mask) != 0;
/*     */   }
/*     */ 
/*     */   public boolean contains(Flags flags)
/*     */   {
/* 171 */     return ((this.system_flags & flags.system_flags) == flags.system_flags) && (this.user_flags.keySet().containsAll(flags.user_flags.keySet()));
/*     */   }
/*     */ 
/*     */   public boolean contains(String name)
/*     */   {
/* 181 */     return this.user_flags.containsKey(name.toLowerCase());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 191 */     if (other == this) return true;
/* 192 */     if (!(other instanceof Flags)) return false;
/* 193 */     Flags flags = (Flags)other;
/* 194 */     return (this.system_flags == flags.system_flags) && (this.user_flags.keySet().equals(flags.user_flags.keySet()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 202 */     return this.system_flags ^ this.user_flags.keySet().hashCode();
/*     */   }
/*     */ 
/*     */   public Flag[] getSystemFlags()
/*     */   {
/* 211 */     int size = 0;
/* 212 */     if ((this.system_flags & Flag.ANSWERED.mask) != 0) size++;
/* 213 */     if ((this.system_flags & Flag.DELETED.mask) != 0) size++;
/* 214 */     if ((this.system_flags & Flag.DRAFT.mask) != 0) size++;
/* 215 */     if ((this.system_flags & Flag.FLAGGED.mask) != 0) size++;
/* 216 */     if ((this.system_flags & Flag.RECENT.mask) != 0) size++;
/* 217 */     if ((this.system_flags & Flag.SEEN.mask) != 0) size++;
/* 218 */     if ((this.system_flags & Flag.USER.mask) != 0) size++;
/* 219 */     Flag[] result = new Flag[size];
/* 220 */     if ((this.system_flags & Flag.USER.mask) != 0) { size--; result[size] = Flag.USER; }
/* 221 */     if ((this.system_flags & Flag.SEEN.mask) != 0) { size--; result[size] = Flag.SEEN; }
/* 222 */     if ((this.system_flags & Flag.RECENT.mask) != 0) { size--; result[size] = Flag.RECENT; }
/* 223 */     if ((this.system_flags & Flag.FLAGGED.mask) != 0) { size--; result[size] = Flag.FLAGGED; }
/* 224 */     if ((this.system_flags & Flag.DRAFT.mask) != 0) { size--; result[size] = Flag.DRAFT; }
/* 225 */     if ((this.system_flags & Flag.DELETED.mask) != 0) { size--; result[size] = Flag.DELETED; }
/* 226 */     if ((this.system_flags & Flag.ANSWERED.mask) != 0) { size--; result[size] = Flag.ANSWERED; }
/* 227 */     return result;
/*     */   }
/*     */ 
/*     */   public String[] getUserFlags()
/*     */   {
/* 235 */     return (String[])(String[])this.user_flags.values().toArray(new String[this.user_flags.values().size()]);
/*     */   }
/*     */ 
/*     */   public void remove(Flag flag)
/*     */   {
/* 244 */     this.system_flags &= (flag.mask ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   public void remove(Flags flags)
/*     */   {
/* 252 */     this.system_flags &= (flags.system_flags ^ 0xFFFFFFFF);
/* 253 */     this.user_flags.keySet().removeAll(flags.user_flags.keySet());
/*     */   }
/*     */ 
/*     */   public void remove(String name)
/*     */   {
/* 261 */     this.user_flags.remove(name.toLowerCase());
/*     */   }
/*     */ 
/*     */   public static final class Flag
/*     */   {
/*  44 */     public static final Flag ANSWERED = new Flag(1);
/*     */ 
/*  49 */     public static final Flag DELETED = new Flag(2);
/*     */ 
/*  53 */     public static final Flag DRAFT = new Flag(4);
/*     */ 
/*  57 */     public static final Flag FLAGGED = new Flag(8);
/*     */ 
/*  62 */     public static final Flag RECENT = new Flag(16);
/*     */ 
/*  68 */     public static final Flag SEEN = new Flag(32);
/*     */ 
/*  72 */     public static final Flag USER = new Flag(-2147483648);
/*     */     private final int mask;
/*     */ 
/*     */     private Flag(int mask)
/*     */     {
/*  77 */       this.mask = mask;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Flags
 * JD-Core Version:    0.6.0
 */