/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Objects
/*     */ {
/*     */   public static boolean equal(@Nullable Object a, @Nullable Object b)
/*     */   {
/*  53 */     return (a == b) || ((a != null) && (a.equals(b)));
/*     */   }
/*     */ 
/*     */   public static int hashCode(Object[] objects)
/*     */   {
/*  72 */     return Arrays.hashCode(objects);
/*     */   }
/*     */ 
/*     */   public static ToStringHelper toStringHelper(Object self)
/*     */   {
/*  99 */     return new ToStringHelper(self, null);
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <T> T nonNull(T obj)
/*     */   {
/* 116 */     if (obj == null) {
/* 117 */       throw new NullPointerException();
/*     */     }
/* 119 */     return obj;
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <T> T nonNull(T obj, @Nullable String message)
/*     */   {
/* 138 */     if (obj == null) {
/* 139 */       throw new NullPointerException(message);
/*     */     }
/* 141 */     return obj;
/*     */   }
/*     */ 
/*     */   public static <T> T firstNonNull(@Nullable T first, @Nullable T second)
/*     */   {
/* 156 */     return first != null ? first : Preconditions.checkNotNull(second);
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static boolean deepEquals(@Nullable Object a, @Nullable Object b)
/*     */   {
/* 174 */     if (a == b) {
/* 175 */       return true;
/*     */     }
/* 177 */     if ((a == null) || (b == null)) {
/* 178 */       return false;
/*     */     }
/*     */ 
/* 181 */     Class type1 = a.getClass();
/* 182 */     Class type2 = b.getClass();
/* 183 */     if ((!type1.isArray()) || (!type2.isArray())) {
/* 184 */       return a.equals(b);
/*     */     }
/* 186 */     if (((a instanceof Object[])) && ((b instanceof Object[]))) {
/* 187 */       return Arrays.deepEquals((Object[])(Object[])a, (Object[])(Object[])b);
/*     */     }
/* 189 */     if (type1 != type2) {
/* 190 */       return false;
/*     */     }
/* 192 */     if ((a instanceof boolean[])) {
/* 193 */       return Arrays.equals((boolean[])(boolean[])a, (boolean[])(boolean[])b);
/*     */     }
/* 195 */     if ((a instanceof char[])) {
/* 196 */       return Arrays.equals((char[])(char[])a, (char[])(char[])b);
/*     */     }
/* 198 */     if ((a instanceof byte[])) {
/* 199 */       return Arrays.equals((byte[])(byte[])a, (byte[])(byte[])b);
/*     */     }
/* 201 */     if ((a instanceof short[])) {
/* 202 */       return Arrays.equals((short[])(short[])a, (short[])(short[])b);
/*     */     }
/* 204 */     if ((a instanceof int[])) {
/* 205 */       return Arrays.equals((int[])(int[])a, (int[])(int[])b);
/*     */     }
/* 207 */     if ((a instanceof long[])) {
/* 208 */       return Arrays.equals((long[])(long[])a, (long[])(long[])b);
/*     */     }
/* 210 */     if ((a instanceof float[])) {
/* 211 */       return Arrays.equals((float[])(float[])a, (float[])(float[])b);
/*     */     }
/* 213 */     if ((a instanceof double[])) {
/* 214 */       return Arrays.equals((double[])(double[])a, (double[])(double[])b);
/*     */     }
/* 216 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static int deepHashCode(@Nullable Object obj)
/*     */   {
/* 231 */     if (obj == null) {
/* 232 */       return 0;
/*     */     }
/* 234 */     if (!obj.getClass().isArray()) {
/* 235 */       return obj.hashCode();
/*     */     }
/* 237 */     if ((obj instanceof Object[])) {
/* 238 */       return Arrays.deepHashCode((Object[])(Object[])obj);
/*     */     }
/* 240 */     if ((obj instanceof boolean[])) {
/* 241 */       return Arrays.hashCode((boolean[])(boolean[])obj);
/*     */     }
/* 243 */     if ((obj instanceof char[])) {
/* 244 */       return Arrays.hashCode((char[])(char[])obj);
/*     */     }
/* 246 */     if ((obj instanceof byte[])) {
/* 247 */       return Arrays.hashCode((byte[])(byte[])obj);
/*     */     }
/* 249 */     if ((obj instanceof short[])) {
/* 250 */       return Arrays.hashCode((short[])(short[])obj);
/*     */     }
/* 252 */     if ((obj instanceof int[])) {
/* 253 */       return Arrays.hashCode((int[])(int[])obj);
/*     */     }
/* 255 */     if ((obj instanceof long[])) {
/* 256 */       return Arrays.hashCode((long[])(long[])obj);
/*     */     }
/* 258 */     if ((obj instanceof float[])) {
/* 259 */       return Arrays.hashCode((float[])(float[])obj);
/*     */     }
/* 261 */     if ((obj instanceof double[])) {
/* 262 */       return Arrays.hashCode((double[])(double[])obj);
/*     */     }
/* 264 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   @GoogleInternal
/*     */   public static String deepToString(@Nullable Object obj)
/*     */   {
/* 278 */     if (obj == null) {
/* 279 */       return String.valueOf(obj);
/*     */     }
/* 281 */     if (!obj.getClass().isArray()) {
/* 282 */       return obj.toString();
/*     */     }
/* 284 */     if ((obj instanceof Object[])) {
/* 285 */       return Arrays.deepToString((Object[])(Object[])obj);
/*     */     }
/* 287 */     if ((obj instanceof boolean[])) {
/* 288 */       return Arrays.toString((boolean[])(boolean[])obj);
/*     */     }
/* 290 */     if ((obj instanceof char[])) {
/* 291 */       return Arrays.toString((char[])(char[])obj);
/*     */     }
/* 293 */     if ((obj instanceof byte[])) {
/* 294 */       return Arrays.toString((byte[])(byte[])obj);
/*     */     }
/* 296 */     if ((obj instanceof short[])) {
/* 297 */       return Arrays.toString((short[])(short[])obj);
/*     */     }
/* 299 */     if ((obj instanceof int[])) {
/* 300 */       return Arrays.toString((int[])(int[])obj);
/*     */     }
/* 302 */     if ((obj instanceof long[])) {
/* 303 */       return Arrays.toString((long[])(long[])obj);
/*     */     }
/* 305 */     if ((obj instanceof float[])) {
/* 306 */       return Arrays.toString((float[])(float[])obj);
/*     */     }
/* 308 */     if ((obj instanceof double[])) {
/* 309 */       return Arrays.toString((double[])(double[])obj);
/*     */     }
/* 311 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   public static class ToStringHelper
/*     */   {
/* 321 */     private final List<String> fieldString = new ArrayList();
/*     */     private final Object instance;
/* 351 */     private static final Joiner JOINER = Joiner.on(", ");
/*     */ 
/*     */     private ToStringHelper(Object instance)
/*     */     {
/* 328 */       this.instance = Preconditions.checkNotNull(instance);
/*     */     }
/*     */ 
/*     */     public ToStringHelper add(String name, @Nullable Object value)
/*     */     {
/* 337 */       return addValue((String)Preconditions.checkNotNull(name) + "=" + value);
/*     */     }
/*     */ 
/*     */     public ToStringHelper addValue(@Nullable Object value)
/*     */     {
/* 347 */       this.fieldString.add(String.valueOf(value));
/* 348 */       return this;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 357 */       StringBuilder builder = new StringBuilder(100).append(simpleName(this.instance.getClass())).append('{');
/*     */ 
/* 360 */       return '}';
/*     */     }
/*     */ 
/*     */     @VisibleForTesting
/*     */     static String simpleName(Class<?> clazz)
/*     */     {
/* 371 */       String name = clazz.getName();
/*     */ 
/* 374 */       int start = name.lastIndexOf('$');
/*     */ 
/* 378 */       if (start == -1) {
/* 379 */         start = name.lastIndexOf('.');
/*     */       }
/* 381 */       return name.substring(start + 1);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Objects
 * JD-Core Version:    0.6.0
 */