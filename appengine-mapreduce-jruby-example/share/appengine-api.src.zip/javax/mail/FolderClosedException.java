/*    */ package javax.mail;
/*    */ 
/*    */ public class FolderClosedException extends MessagingException
/*    */ {
/*    */   private transient Folder _folder;
/*    */ 
/*    */   public FolderClosedException(Folder folder)
/*    */   {
/* 29 */     this(folder, "Folder Closed: " + folder.getName());
/*    */   }
/*    */ 
/*    */   public FolderClosedException(Folder folder, String message) {
/* 33 */     super(message);
/* 34 */     this._folder = folder;
/*    */   }
/*    */ 
/*    */   public Folder getFolder() {
/* 38 */     return this._folder;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.FolderClosedException
 * JD-Core Version:    0.6.0
 */