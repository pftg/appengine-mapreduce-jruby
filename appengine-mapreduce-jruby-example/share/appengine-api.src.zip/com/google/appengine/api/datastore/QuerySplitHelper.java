/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ final class QuerySplitHelper
/*     */ {
/*     */   private static final int MAX_PARALLEL_QUERIES = 30;
/*  56 */   private static final Collection<QuerySplitter> QUERY_SPLITTERS = Collections.synchronizedCollection(Arrays.asList(new QuerySplitter[] { new NotEqualQuerySplitter(), new InQuerySplitter() }));
/*     */ 
/*     */   static MultiQueryBuilder splitQuery(Query query)
/*     */   {
/*  69 */     return splitQuery(query, QUERY_SPLITTERS);
/*     */   }
/*     */ 
/*     */   static MultiQueryBuilder splitQuery(Query query, Collection<QuerySplitter> splitters)
/*     */   {
/*  80 */     List remainingFilters = new LinkedList(query.getFilterPredicates());
/*     */ 
/*  82 */     List components = new ArrayList();
/*  83 */     for (QuerySplitter splitter : splitters) {
/*  84 */       components.addAll(splitter.split(remainingFilters, query.getSortPredicates()));
/*     */     }
/*     */ 
/*  87 */     if (components.size() > 0) {
/*  88 */       return new MultiQueryBuilder(query, remainingFilters, convertComponents(components, query.getSortPredicates().size()));
/*     */     }
/*     */ 
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */   static List<MultiQueryComponent> convertComponents(List<QuerySplitComponent> components, int numberOfSorts)
/*     */   {
/* 106 */     if (components.isEmpty()) {
/* 107 */       throw new IllegalArgumentException();
/*     */     }
/* 109 */     List result = new ArrayList(components.size());
/*     */ 
/* 118 */     Collections.sort(components);
/*     */ 
/* 121 */     MultiQueryComponent.Order applyToRemaining = numberOfSorts == 0 ? MultiQueryComponent.Order.SERIAL : null;
/*     */ 
/* 124 */     int currentSortIndex = 0;
/* 125 */     int totalParallelQueries = 1;
/* 126 */     for (QuerySplitComponent component : components) {
/* 127 */       if ((applyToRemaining == null) && (component.getSortIndex() != currentSortIndex)) {
/* 128 */         if (component.getSortIndex() == currentSortIndex + 1)
/*     */         {
/* 134 */           currentSortIndex++;
/*     */         }
/*     */         else
/*     */         {
/* 140 */           applyToRemaining = MultiQueryComponent.Order.PARALLEL;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 147 */       result.add(new MultiQueryComponent(applyToRemaining != null ? applyToRemaining : MultiQueryComponent.Order.SERIAL, component.getFilters()));
/*     */ 
/* 151 */       if (applyToRemaining == MultiQueryComponent.Order.PARALLEL) {
/* 152 */         totalParallelQueries *= component.getFilters().size();
/* 153 */         if (totalParallelQueries > 30) {
/* 154 */           throw new IllegalArgumentException("Splitting the provided query requires that too many subqueries are merged in memory.");
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 160 */     return result;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QuerySplitHelper
 * JD-Core Version:    0.6.0
 */