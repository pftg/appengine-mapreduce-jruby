/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public class DatastoreFailureException extends RuntimeException
/*    */ {
/*    */   public DatastoreFailureException(String message)
/*    */   {
/* 15 */     super(message);
/*    */   }
/*    */ 
/*    */   public DatastoreFailureException(String message, Throwable cause) {
/* 19 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreFailureException
 * JD-Core Version:    0.6.0
 */