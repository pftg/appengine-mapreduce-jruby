/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Pair;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicate;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicates;
/*      */ import com.google.common.annotations.Beta;
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import com.google.common.annotations.GwtIncompatible;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.NoSuchElementException;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GwtCompatible(emulated=true)
/*      */ public final class Iterators
/*      */ {
/*   61 */   static final UnmodifiableIterator<Object> EMPTY_ITERATOR = new UnmodifiableIterator()
/*      */   {
/*      */     public boolean hasNext() {
/*   64 */       return false;
/*      */     }
/*      */     public Object next() {
/*   67 */       throw new NoSuchElementException();
/*      */     }
/*   61 */   };
/*      */ 
/*   83 */   private static final Iterator<Object> EMPTY_MODIFIABLE_ITERATOR = new Iterator()
/*      */   {
/*      */     public boolean hasNext() {
/*   86 */       return false;
/*      */     }
/*      */ 
/*      */     public Object next() {
/*   90 */       throw new NoSuchElementException();
/*      */     }
/*      */ 
/*      */     public void remove() {
/*   94 */       throw new IllegalStateException();
/*      */     }
/*   83 */   };
/*      */ 
/*      */   public static <T> UnmodifiableIterator<T> emptyIterator()
/*      */   {
/*   80 */     return EMPTY_ITERATOR;
/*      */   }
/*      */ 
/*      */   static <T> Iterator<T> emptyModifiableIterator()
/*      */   {
/*  107 */     return EMPTY_MODIFIABLE_ITERATOR;
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<T> unmodifiableIterator(Iterator<T> iterator)
/*      */   {
/*  113 */     Preconditions.checkNotNull(iterator);
/*  114 */     return new UnmodifiableIterator(iterator) {
/*      */       public boolean hasNext() {
/*  116 */         return this.val$iterator.hasNext();
/*      */       }
/*      */       public T next() {
/*  119 */         return this.val$iterator.next();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static int size(Iterator<?> iterator)
/*      */   {
/*  130 */     int count = 0;
/*  131 */     while (iterator.hasNext()) {
/*  132 */       iterator.next();
/*  133 */       count++;
/*      */     }
/*  135 */     return count;
/*      */   }
/*      */ 
/*      */   public static boolean contains(Iterator<?> iterator, @Nullable Object element)
/*      */   {
/*  143 */     if (element == null) {
/*      */       do if (!iterator.hasNext())
/*      */           break; while (iterator.next() != null);
/*  146 */       return true;
/*      */     }
/*      */ 
/*  150 */     while (iterator.hasNext()) {
/*  151 */       if (element.equals(iterator.next())) {
/*  152 */         return true;
/*      */       }
/*      */     }
/*      */ 
/*  156 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean removeAll(Iterator<?> removeFrom, Collection<?> elementsToRemove)
/*      */   {
/*  170 */     Preconditions.checkNotNull(elementsToRemove);
/*  171 */     boolean modified = false;
/*  172 */     while (removeFrom.hasNext()) {
/*  173 */       if (elementsToRemove.contains(removeFrom.next())) {
/*  174 */         removeFrom.remove();
/*  175 */         modified = true;
/*      */       }
/*      */     }
/*  178 */     return modified;
/*      */   }
/*      */ 
/*      */   public static <T> boolean removeIf(Iterator<T> removeFrom, Predicate<? super T> predicate)
/*      */   {
/*  194 */     Preconditions.checkNotNull(predicate);
/*  195 */     boolean modified = false;
/*  196 */     while (removeFrom.hasNext()) {
/*  197 */       if (predicate.apply(removeFrom.next())) {
/*  198 */         removeFrom.remove();
/*  199 */         modified = true;
/*      */       }
/*      */     }
/*  202 */     return modified;
/*      */   }
/*      */ 
/*      */   public static boolean retainAll(Iterator<?> removeFrom, Collection<?> elementsToRetain)
/*      */   {
/*  216 */     Preconditions.checkNotNull(elementsToRetain);
/*  217 */     boolean modified = false;
/*  218 */     while (removeFrom.hasNext()) {
/*  219 */       if (!elementsToRetain.contains(removeFrom.next())) {
/*  220 */         removeFrom.remove();
/*  221 */         modified = true;
/*      */       }
/*      */     }
/*  224 */     return modified;
/*      */   }
/*      */ 
/*      */   public static boolean elementsEqual(Iterator<?> iterator1, Iterator<?> iterator2)
/*      */   {
/*  239 */     while (iterator1.hasNext()) {
/*  240 */       if (!iterator2.hasNext()) {
/*  241 */         return false;
/*      */       }
/*  243 */       Object o1 = iterator1.next();
/*  244 */       Object o2 = iterator2.next();
/*  245 */       if (!Objects.equal(o1, o2)) {
/*  246 */         return false;
/*      */       }
/*      */     }
/*  249 */     return !iterator2.hasNext();
/*      */   }
/*      */ 
/*      */   public static String toString(Iterator<?> iterator)
/*      */   {
/*  258 */     if (!iterator.hasNext()) {
/*  259 */       return "[]";
/*      */     }
/*  261 */     StringBuilder builder = new StringBuilder();
/*  262 */     builder.append('[').append(iterator.next());
/*  263 */     while (iterator.hasNext()) {
/*  264 */       builder.append(", ").append(iterator.next());
/*      */     }
/*  266 */     return ']';
/*      */   }
/*      */ 
/*      */   public static <T> T getOnlyElement(Iterator<T> iterator)
/*      */   {
/*  277 */     Object first = iterator.next();
/*  278 */     if (!iterator.hasNext()) {
/*  279 */       return first;
/*      */     }
/*      */ 
/*  282 */     StringBuilder sb = new StringBuilder();
/*  283 */     sb.append("expected one element but was: <" + first);
/*  284 */     for (int i = 0; (i < 4) && (iterator.hasNext()); i++) {
/*  285 */       sb.append(", " + iterator.next());
/*      */     }
/*  287 */     if (iterator.hasNext()) {
/*  288 */       sb.append(", ...");
/*      */     }
/*  290 */     sb.append(">");
/*      */ 
/*  292 */     throw new IllegalArgumentException(sb.toString());
/*      */   }
/*      */ 
/*      */   public static <T> T getOnlyElement(Iterator<T> iterator, @Nullable T defaultValue)
/*      */   {
/*  304 */     return iterator.hasNext() ? getOnlyElement(iterator) : defaultValue;
/*      */   }
/*      */ 
/*      */   public static <T> T[] toArray(Iterator<? extends T> iterator, Class<T> type)
/*      */   {
/*  318 */     List list = Lists.newArrayList(iterator);
/*  319 */     return Iterables.toArray(list, type);
/*      */   }
/*      */ 
/*      */   public static <T> boolean addAll(Collection<T> addTo, Iterator<? extends T> iterator)
/*      */   {
/*  332 */     Preconditions.checkNotNull(addTo);
/*  333 */     boolean wasModified = false;
/*  334 */     while (iterator.hasNext()) {
/*  335 */       wasModified |= addTo.add(iterator.next());
/*      */     }
/*  337 */     return wasModified;
/*      */   }
/*      */ 
/*      */   public static int frequency(Iterator<?> iterator, @Nullable Object element)
/*      */   {
/*  348 */     int result = 0;
/*  349 */     if (element == null) {
/*  350 */       while (iterator.hasNext()) {
/*  351 */         if (iterator.next() == null) {
/*  352 */           result++;
/*      */         }
/*      */       }
/*      */     }
/*  356 */     while (iterator.hasNext()) {
/*  357 */       if (element.equals(iterator.next())) {
/*  358 */         result++;
/*      */       }
/*      */     }
/*      */ 
/*  362 */     return result;
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> cycle(Iterable<T> iterable)
/*      */   {
/*  380 */     Preconditions.checkNotNull(iterable);
/*  381 */     return new Iterator(iterable) { Iterator<T> iterator = Iterators.emptyIterator();
/*      */       Iterator<T> removeFrom;
/*      */ 
/*  386 */       public boolean hasNext() { if (!this.iterator.hasNext()) {
/*  387 */           this.iterator = this.val$iterable.iterator();
/*      */         }
/*  389 */         return this.iterator.hasNext(); }
/*      */ 
/*      */       public T next() {
/*  392 */         if (!hasNext()) {
/*  393 */           throw new NoSuchElementException();
/*      */         }
/*  395 */         this.removeFrom = this.iterator;
/*  396 */         return this.iterator.next();
/*      */       }
/*      */       public void remove() {
/*  399 */         Preconditions.checkState(this.removeFrom != null, "no calls to next() since last call to remove()");
/*      */ 
/*  401 */         this.removeFrom.remove();
/*  402 */         this.removeFrom = null;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> cycle(T[] elements)
/*      */   {
/*  421 */     return cycle(Lists.newArrayList(elements));
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b)
/*      */   {
/*  435 */     Preconditions.checkNotNull(a);
/*  436 */     Preconditions.checkNotNull(b);
/*  437 */     return concat(Arrays.asList(new Iterator[] { a, b }).iterator());
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b, Iterator<? extends T> c)
/*      */   {
/*  452 */     Preconditions.checkNotNull(a);
/*  453 */     Preconditions.checkNotNull(b);
/*  454 */     Preconditions.checkNotNull(c);
/*  455 */     return concat(Arrays.asList(new Iterator[] { a, b, c }).iterator());
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b, Iterator<? extends T> c, Iterator<? extends T> d)
/*      */   {
/*  471 */     Preconditions.checkNotNull(a);
/*  472 */     Preconditions.checkNotNull(b);
/*  473 */     Preconditions.checkNotNull(c);
/*  474 */     Preconditions.checkNotNull(d);
/*  475 */     return concat(Arrays.asList(new Iterator[] { a, b, c, d }).iterator());
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> concat(Iterator<? extends T>[] inputs)
/*      */   {
/*  489 */     return concat(ImmutableList.copyOf(inputs).iterator());
/*      */   }
/*      */ 
/*      */   public static <T> Iterator<T> concat(Iterator<? extends Iterator<? extends T>> inputs)
/*      */   {
/*  503 */     Preconditions.checkNotNull(inputs);
/*  504 */     return new Iterator(inputs) {
/*  505 */       Iterator<? extends T> current = Iterators.emptyIterator();
/*      */       Iterator<? extends T> removeFrom;
/*      */ 
/*      */       public boolean hasNext()
/*      */       {
/*      */         boolean currentHasNext;
/*  512 */         while ((!(currentHasNext = this.current.hasNext())) && (this.val$inputs.hasNext())) {
/*  513 */           this.current = ((Iterator)this.val$inputs.next());
/*      */         }
/*  515 */         return currentHasNext;
/*      */       }
/*      */       public T next() {
/*  518 */         if (!hasNext()) {
/*  519 */           throw new NoSuchElementException();
/*      */         }
/*  521 */         this.removeFrom = this.current;
/*  522 */         return this.current.next();
/*      */       }
/*      */       public void remove() {
/*  525 */         Preconditions.checkState(this.removeFrom != null, "no calls to next() since last call to remove()");
/*      */ 
/*  527 */         this.removeFrom.remove();
/*  528 */         this.removeFrom = null;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<List<T>> partition(Iterator<T> iterator, int size)
/*      */   {
/*  550 */     return partitionImpl(iterator, size, false);
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<List<T>> paddedPartition(Iterator<T> iterator, int size)
/*      */   {
/*  571 */     return partitionImpl(iterator, size, true);
/*      */   }
/*      */ 
/*      */   private static <T> UnmodifiableIterator<List<T>> partitionImpl(Iterator<T> iterator, int size, boolean pad)
/*      */   {
/*  576 */     Preconditions.checkNotNull(iterator);
/*  577 */     Preconditions.checkArgument(size > 0);
/*  578 */     return new UnmodifiableIterator(iterator, size, pad) {
/*      */       public boolean hasNext() {
/*  580 */         return this.val$iterator.hasNext();
/*      */       }
/*      */       public List<T> next() {
/*  583 */         if (!hasNext()) {
/*  584 */           throw new NoSuchElementException();
/*      */         }
/*  586 */         Object[] array = new Object[this.val$size];
/*  587 */         int count = 0;
/*  588 */         for (; (count < this.val$size) && (this.val$iterator.hasNext()); count++) {
/*  589 */           array[count] = this.val$iterator.next();
/*      */         }
/*      */ 
/*  593 */         List list = Collections.unmodifiableList(Arrays.asList(array));
/*      */ 
/*  595 */         return (this.val$pad) || (count == this.val$size) ? list : list.subList(0, count);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <A, B> Iterator<Pair<A, B>> pairUp(Iterator<A> first, Iterator<B> second)
/*      */   {
/*  612 */     Preconditions.checkNotNull(first);
/*  613 */     Preconditions.checkNotNull(second);
/*  614 */     return new Iterator(first, second) {
/*      */       public boolean hasNext() {
/*  616 */         return (this.val$first.hasNext()) && (this.val$second.hasNext());
/*      */       }
/*      */ 
/*      */       public Pair<A, B> next() {
/*  620 */         if (!hasNext()) {
/*  621 */           throw new NoSuchElementException();
/*      */         }
/*  623 */         return Pair.of(this.val$first.next(), this.val$second.next());
/*      */       }
/*      */ 
/*      */       public void remove()
/*      */       {
/*  631 */         throw new UnsupportedOperationException("remove() not yet implemented for paired lists.");
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<T> filter(Iterator<T> unfiltered, Predicate<? super T> predicate)
/*      */   {
/*  642 */     Preconditions.checkNotNull(unfiltered);
/*  643 */     Preconditions.checkNotNull(predicate);
/*  644 */     return new AbstractIterator(unfiltered, predicate) {
/*      */       protected T computeNext() {
/*  646 */         while (this.val$unfiltered.hasNext()) {
/*  647 */           Object element = this.val$unfiltered.next();
/*  648 */           if (this.val$predicate.apply(element)) {
/*  649 */             return element;
/*      */           }
/*      */         }
/*  652 */         return endOfData();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   @GwtIncompatible("Class.isInstance")
/*      */   public static <T> UnmodifiableIterator<T> filter(Iterator<?> unfiltered, Class<T> type)
/*      */   {
/*  671 */     return filter(unfiltered, Predicates.instanceOf(type));
/*      */   }
/*      */ 
/*      */   public static <T> boolean any(Iterator<T> iterator, Predicate<? super T> predicate)
/*      */   {
/*  681 */     Preconditions.checkNotNull(predicate);
/*  682 */     while (iterator.hasNext()) {
/*  683 */       Object element = iterator.next();
/*  684 */       if (predicate.apply(element)) {
/*  685 */         return true;
/*      */       }
/*      */     }
/*  688 */     return false;
/*      */   }
/*      */ 
/*      */   public static <T> boolean all(Iterator<T> iterator, Predicate<? super T> predicate)
/*      */   {
/*  698 */     Preconditions.checkNotNull(predicate);
/*  699 */     while (iterator.hasNext()) {
/*  700 */       Object element = iterator.next();
/*  701 */       if (!predicate.apply(element)) {
/*  702 */         return false;
/*      */       }
/*      */     }
/*  705 */     return true;
/*      */   }
/*      */ 
/*      */   public static <T> T find(Iterator<T> iterator, Predicate<? super T> predicate)
/*      */   {
/*  718 */     return filter(iterator, predicate).next();
/*      */   }
/*      */ 
/*      */   @GoogleInternal
/*      */   public static <T> T find(Iterator<T> iterator, Predicate<? super T> predicate, @Nullable T defaultValue)
/*      */   {
/*  730 */     UnmodifiableIterator filteredIterator = filter(iterator, predicate);
/*  731 */     return filteredIterator.hasNext() ? filteredIterator.next() : defaultValue;
/*      */   }
/*      */ 
/*      */   public static <T> int indexOf(Iterator<T> iterator, Predicate<? super T> predicate)
/*      */   {
/*  752 */     Preconditions.checkNotNull(predicate, "predicate");
/*  753 */     int i = 0;
/*  754 */     while (iterator.hasNext()) {
/*  755 */       Object current = iterator.next();
/*  756 */       if (predicate.apply(current)) {
/*  757 */         return i;
/*      */       }
/*  759 */       i++;
/*      */     }
/*  761 */     return -1;
/*      */   }
/*      */ 
/*      */   public static <F, T> Iterator<T> transform(Iterator<F> fromIterator, Function<? super F, ? extends T> function)
/*      */   {
/*  774 */     Preconditions.checkNotNull(fromIterator);
/*  775 */     Preconditions.checkNotNull(function);
/*  776 */     return new Iterator(fromIterator, function) {
/*      */       public boolean hasNext() {
/*  778 */         return this.val$fromIterator.hasNext();
/*      */       }
/*      */       public T next() {
/*  781 */         Object from = this.val$fromIterator.next();
/*  782 */         return this.val$function.apply(from);
/*      */       }
/*      */       public void remove() {
/*  785 */         this.val$fromIterator.remove();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> T get(Iterator<T> iterator, int position)
/*      */   {
/*  801 */     checkNonnegative(position);
/*      */ 
/*  803 */     int skipped = 0;
/*  804 */     while (iterator.hasNext()) {
/*  805 */       Object t = iterator.next();
/*  806 */       if (skipped++ == position) {
/*  807 */         return t;
/*      */       }
/*      */     }
/*      */ 
/*  811 */     throw new IndexOutOfBoundsException("position (" + position + ") must be less than the number of elements that remained (" + skipped + ")");
/*      */   }
/*      */ 
/*      */   private static void checkNonnegative(int position)
/*      */   {
/*  817 */     if (position < 0)
/*  818 */       throw new IndexOutOfBoundsException("position (" + position + ") must not be negative");
/*      */   }
/*      */ 
/*      */   @Beta
/*      */   public static <T> T get(Iterator<T> iterator, int position, @Nullable T defaultValue)
/*      */   {
/*  841 */     checkNonnegative(position);
/*      */     try
/*      */     {
/*  844 */       return get(iterator, position); } catch (IndexOutOfBoundsException e) {
/*      */     }
/*  846 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   public static <T> T getLast(Iterator<T> iterator)
/*      */   {
/*      */     while (true)
/*      */     {
/*  858 */       Object current = iterator.next();
/*  859 */       if (!iterator.hasNext())
/*  860 */         return current;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static <T> T getLast(Iterator<T> iterator, @Nullable T defaultValue)
/*      */   {
/*  874 */     return iterator.hasNext() ? getLast(iterator) : defaultValue;
/*      */   }
/*      */ 
/*      */   @Beta
/*      */   public static <T> int skip(Iterator<T> iterator, int numberToSkip)
/*      */   {
/*  886 */     Preconditions.checkNotNull(iterator);
/*  887 */     Preconditions.checkArgument(numberToSkip >= 0, "number to skip cannot be negative");
/*      */ 
/*  890 */     for (int i = 0; (i < numberToSkip) && (iterator.hasNext()); i++) {
/*  891 */       iterator.next();
/*      */     }
/*  893 */     return i;
/*      */   }
/*      */ 
/*      */   @Beta
/*      */   public static <T> Iterator<T> limit(Iterator<T> iterator, int limitSize)
/*      */   {
/*  911 */     Preconditions.checkNotNull(iterator);
/*  912 */     Preconditions.checkArgument(limitSize >= 0, "limit is negative");
/*  913 */     return new Iterator(limitSize, iterator) {
/*      */       private int count;
/*      */ 
/*  917 */       public boolean hasNext() { return (this.count < this.val$limitSize) && (this.val$iterator.hasNext()); }
/*      */ 
/*      */       public T next()
/*      */       {
/*  921 */         if (!hasNext()) {
/*  922 */           throw new NoSuchElementException();
/*      */         }
/*  924 */         this.count += 1;
/*  925 */         return this.val$iterator.next();
/*      */       }
/*      */ 
/*      */       public void remove() {
/*  929 */         this.val$iterator.remove();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   @Beta
/*      */   public static <T> Iterator<T> consumingIterator(Iterator<T> iterator)
/*      */   {
/*  949 */     Preconditions.checkNotNull(iterator);
/*  950 */     return new UnmodifiableIterator(iterator) {
/*      */       public boolean hasNext() {
/*  952 */         return this.val$iterator.hasNext();
/*      */       }
/*      */ 
/*      */       public T next() {
/*  956 */         Object next = this.val$iterator.next();
/*  957 */         this.val$iterator.remove();
/*  958 */         return next;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<T> forArray(T[] array)
/*      */   {
/*  980 */     Preconditions.checkNotNull(array);
/*  981 */     return new UnmodifiableIterator(array) {
/*  982 */       final int length = this.val$array.length;
/*  983 */       int i = 0;
/*      */ 
/*  985 */       public boolean hasNext() { return this.i < this.length; }
/*      */ 
/*      */       public T next() {
/*  988 */         if (this.i < this.length) {
/*  989 */           return this.val$array[(this.i++)];
/*      */         }
/*  991 */         throw new NoSuchElementException();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   static <T> UnmodifiableIterator<T> forArray(T[] array, int offset, int length)
/*      */   {
/* 1014 */     Preconditions.checkArgument(length >= 0);
/* 1015 */     int end = offset + length;
/*      */ 
/* 1018 */     Preconditions.checkPositionIndexes(offset, end, array.length);
/*      */ 
/* 1022 */     return new UnmodifiableIterator(offset, end, array) {
/* 1023 */       int i = this.val$offset;
/*      */ 
/* 1025 */       public boolean hasNext() { return this.i < this.val$end; }
/*      */ 
/*      */       public T next() {
/* 1028 */         if (!hasNext()) {
/* 1029 */           throw new NoSuchElementException();
/*      */         }
/* 1031 */         return this.val$array[(this.i++)];
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<T> singletonIterator(@Nullable T value)
/*      */   {
/* 1044 */     return new UnmodifiableIterator(value) { boolean done;
/*      */ 
/* 1047 */       public boolean hasNext() { return !this.done; }
/*      */ 
/*      */       public T next() {
/* 1050 */         if (this.done) {
/* 1051 */           throw new NoSuchElementException();
/*      */         }
/* 1053 */         this.done = true;
/* 1054 */         return this.val$value;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> UnmodifiableIterator<T> forEnumeration(Enumeration<T> enumeration)
/*      */   {
/* 1069 */     Preconditions.checkNotNull(enumeration);
/* 1070 */     return new UnmodifiableIterator(enumeration) {
/*      */       public boolean hasNext() {
/* 1072 */         return this.val$enumeration.hasMoreElements();
/*      */       }
/*      */       public T next() {
/* 1075 */         return this.val$enumeration.nextElement();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> Enumeration<T> asEnumeration(Iterator<T> iterator)
/*      */   {
/* 1088 */     Preconditions.checkNotNull(iterator);
/* 1089 */     return new Enumeration(iterator) {
/*      */       public boolean hasMoreElements() {
/* 1091 */         return this.val$iterator.hasNext();
/*      */       }
/*      */       public T nextElement() {
/* 1094 */         return this.val$iterator.next();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   public static <T> PeekingIterator<T> peekingIterator(Iterator<? extends T> iterator)
/*      */   {
/* 1180 */     if ((iterator instanceof PeekingImpl))
/*      */     {
/* 1184 */       PeekingImpl peeking = (PeekingImpl)iterator;
/* 1185 */       return peeking;
/*      */     }
/* 1187 */     return new PeekingImpl(iterator);
/*      */   }
/*      */ 
/*      */   private static class PeekingImpl<E>
/*      */     implements PeekingIterator<E>
/*      */   {
/*      */     private final Iterator<? extends E> iterator;
/*      */     private boolean hasPeeked;
/*      */     private E peekedElement;
/*      */ 
/*      */     public PeekingImpl(Iterator<? extends E> iterator)
/*      */     {
/* 1109 */       this.iterator = ((Iterator)Preconditions.checkNotNull(iterator));
/*      */     }
/*      */ 
/*      */     public boolean hasNext() {
/* 1113 */       return (this.hasPeeked) || (this.iterator.hasNext());
/*      */     }
/*      */ 
/*      */     public E next() {
/* 1117 */       if (!this.hasPeeked) {
/* 1118 */         return this.iterator.next();
/*      */       }
/* 1120 */       Object result = this.peekedElement;
/* 1121 */       this.hasPeeked = false;
/* 1122 */       this.peekedElement = null;
/* 1123 */       return result;
/*      */     }
/*      */ 
/*      */     public void remove() {
/* 1127 */       Preconditions.checkState(!this.hasPeeked, "Can't remove after you've peeked at next");
/* 1128 */       this.iterator.remove();
/*      */     }
/*      */ 
/*      */     public E peek() {
/* 1132 */       if (!this.hasPeeked) {
/* 1133 */         this.peekedElement = this.iterator.next();
/* 1134 */         this.hasPeeked = true;
/*      */       }
/* 1136 */       return this.peekedElement;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Iterators
 * JD-Core Version:    0.6.0
 */