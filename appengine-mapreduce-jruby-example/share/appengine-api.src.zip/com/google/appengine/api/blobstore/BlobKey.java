/*    */ package com.google.appengine.api.blobstore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class BlobKey
/*    */   implements Serializable, Comparable<BlobKey>
/*    */ {
/*    */   private final String blobKey;
/*    */ 
/*    */   public BlobKey(String blobKey)
/*    */   {
/* 23 */     if (blobKey == null) {
/* 24 */       throw new IllegalArgumentException("Argument must not be null.");
/*    */     }
/* 26 */     this.blobKey = blobKey;
/*    */   }
/*    */ 
/*    */   public String getKeyString()
/*    */   {
/* 33 */     return this.blobKey;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 38 */     return this.blobKey.hashCode();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 47 */     if ((object instanceof BlobKey)) {
/* 48 */       BlobKey key = (BlobKey)object;
/* 49 */       return key.blobKey.equals(this.blobKey);
/*    */     }
/* 51 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 56 */     return "<BlobKey: " + this.blobKey + ">";
/*    */   }
/*    */ 
/*    */   public int compareTo(BlobKey o) {
/* 60 */     return this.blobKey.compareTo(o.blobKey);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobKey
 * JD-Core Version:    0.6.0
 */