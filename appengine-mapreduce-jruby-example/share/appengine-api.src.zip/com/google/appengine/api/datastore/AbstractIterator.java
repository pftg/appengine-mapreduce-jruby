/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ abstract class AbstractIterator<T>
/*    */   implements Iterator<T>
/*    */ {
/*    */   private State state;
/*    */   private T next;
/*    */ 
/*    */   AbstractIterator()
/*    */   {
/* 18 */     this.state = State.NOT_READY;
/*    */   }
/*    */ 
/*    */   protected abstract T computeNext();
/*    */ 
/*    */   protected final T endOfData()
/*    */   {
/* 32 */     this.state = State.DONE;
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */   public final boolean hasNext() {
/* 37 */     if (this.state == State.FAILED) {
/* 38 */       throw new IllegalStateException();
/*    */     }
/* 40 */     switch (1.$SwitchMap$com$google$appengine$api$datastore$AbstractIterator$State[this.state.ordinal()]) {
/*    */     case 1:
/* 42 */       return false;
/*    */     case 2:
/* 44 */       return true;
/*    */     }
/*    */ 
/* 47 */     return tryToComputeNext();
/*    */   }
/*    */ 
/*    */   private boolean tryToComputeNext() {
/* 51 */     this.state = State.FAILED;
/* 52 */     this.next = computeNext();
/* 53 */     if (this.state != State.DONE) {
/* 54 */       this.state = State.READY;
/* 55 */       return true;
/*    */     }
/* 57 */     return false;
/*    */   }
/*    */ 
/*    */   public final T next() {
/* 61 */     if (!hasNext()) {
/* 62 */       throw new NoSuchElementException();
/*    */     }
/* 64 */     this.state = State.NOT_READY;
/* 65 */     return this.next;
/*    */   }
/*    */ 
/*    */   public void remove() {
/* 69 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   static enum State
/*    */   {
/* 21 */     READY, 
/* 22 */     NOT_READY, 
/* 23 */     DONE, 
/* 24 */     FAILED;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.AbstractIterator
 * JD-Core Version:    0.6.0
 */