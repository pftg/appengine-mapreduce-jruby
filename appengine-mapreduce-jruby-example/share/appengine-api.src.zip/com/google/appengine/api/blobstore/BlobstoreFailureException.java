/*    */ package com.google.appengine.api.blobstore;
/*    */ 
/*    */ public class BlobstoreFailureException extends RuntimeException
/*    */ {
/*    */   public BlobstoreFailureException(String message)
/*    */   {
/* 14 */     super(message);
/*    */   }
/*    */ 
/*    */   public BlobstoreFailureException(String message, Throwable cause) {
/* 18 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobstoreFailureException
 * JD-Core Version:    0.6.0
 */