/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public final class Tables
/*     */ {
/*     */   public static <R, C, V> Table.Cell<R, C, V> immutableCell(@Nullable R rowKey, @Nullable C columnKey, @Nullable V value)
/*     */   {
/*  58 */     return new ImmutableCell(rowKey, columnKey, value);
/*     */   }
/*     */ 
/*     */   public static <R, C, V> Table<C, R, V> transpose(Table<R, C, V> table)
/*     */   {
/* 131 */     return (table instanceof TransposeTable) ? ((TransposeTable)table).original : new TransposeTable(table);
/*     */   }
/*     */ 
/*     */   private static class TransposeTable<C, R, V>
/*     */     implements Table<C, R, V>
/*     */   {
/*     */     final Table<R, C, V> original;
/* 238 */     private static final Function TRANSPOSE_CELL = new Function() {
/*     */       public Object apply(Object from) {
/* 240 */         Table.Cell cell = (Table.Cell)from;
/* 241 */         return Tables.immutableCell(cell.getColumnKey(), cell.getRowKey(), cell.getValue());
/*     */       }
/* 238 */     };
/*     */     TransposeTable<C, R, V>.CellSet cellSet;
/*     */ 
/*     */     TransposeTable(Table<R, C, V> original)
/*     */     {
/* 140 */       this.original = ((Table)Preconditions.checkNotNull(original));
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 144 */       this.original.clear();
/*     */     }
/*     */ 
/*     */     public Map<C, V> column(R columnKey) {
/* 148 */       return this.original.row(columnKey);
/*     */     }
/*     */ 
/*     */     public Set<R> columnKeySet() {
/* 152 */       return this.original.rowKeySet();
/*     */     }
/*     */ 
/*     */     public Map<R, Map<C, V>> columnMap() {
/* 156 */       return this.original.rowMap();
/*     */     }
/*     */ 
/*     */     public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*     */     {
/* 161 */       return this.original.contains(columnKey, rowKey);
/*     */     }
/*     */ 
/*     */     public boolean containsColumn(@Nullable Object columnKey) {
/* 165 */       return this.original.containsRow(columnKey);
/*     */     }
/*     */ 
/*     */     public boolean containsRow(@Nullable Object rowKey) {
/* 169 */       return this.original.containsColumn(rowKey);
/*     */     }
/*     */ 
/*     */     public boolean containsValue(@Nullable Object value) {
/* 173 */       return this.original.containsValue(value);
/*     */     }
/*     */ 
/*     */     public V get(@Nullable Object rowKey, @Nullable Object columnKey) {
/* 177 */       return this.original.get(columnKey, rowKey);
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 181 */       return this.original.isEmpty();
/*     */     }
/*     */ 
/*     */     public V put(C rowKey, R columnKey, V value) {
/* 185 */       return this.original.put(columnKey, rowKey, value);
/*     */     }
/*     */ 
/*     */     public void putAll(Table<? extends C, ? extends R, ? extends V> table) {
/* 189 */       this.original.putAll(Tables.transpose(table));
/*     */     }
/*     */ 
/*     */     public V remove(@Nullable Object rowKey, @Nullable Object columnKey) {
/* 193 */       return this.original.remove(columnKey, rowKey);
/*     */     }
/*     */ 
/*     */     public Map<R, V> row(C rowKey) {
/* 197 */       return this.original.column(rowKey);
/*     */     }
/*     */ 
/*     */     public Set<C> rowKeySet() {
/* 201 */       return this.original.columnKeySet();
/*     */     }
/*     */ 
/*     */     public Map<C, Map<R, V>> rowMap() {
/* 205 */       return this.original.columnMap();
/*     */     }
/*     */ 
/*     */     public int size() {
/* 209 */       return this.original.size();
/*     */     }
/*     */ 
/*     */     public Collection<V> values() {
/* 213 */       return this.original.values();
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object obj) {
/* 217 */       if (obj == this) {
/* 218 */         return true;
/*     */       }
/* 220 */       if ((obj instanceof Table)) {
/* 221 */         Table other = (Table)obj;
/* 222 */         return cellSet().equals(other.cellSet());
/*     */       }
/* 224 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 229 */       return this.original.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 233 */       return rowMap().toString();
/*     */     }
/*     */ 
/*     */     public Set<Table.Cell<C, R, V>> cellSet()
/*     */     {
/* 249 */       CellSet result = this.cellSet;
/* 250 */       return result == null ? (this.cellSet = new CellSet()) : result;
/*     */     }
/*     */ 
/*     */     class CellSet extends Collections2.TransformedCollection<Table.Cell<R, C, V>, Table.Cell<C, R, V>>
/*     */       implements Set<Table.Cell<C, R, V>>
/*     */     {
/*     */       CellSet()
/*     */       {
/* 259 */         super(Tables.TransposeTable.TRANSPOSE_CELL);
/*     */       }
/*     */ 
/*     */       public boolean equals(Object obj) {
/* 263 */         if (obj == this) {
/* 264 */           return true;
/*     */         }
/* 266 */         if (!(obj instanceof Set)) {
/* 267 */           return false;
/*     */         }
/* 269 */         Set os = (Set)obj;
/* 270 */         if (os.size() != size()) {
/* 271 */           return false;
/*     */         }
/* 273 */         return containsAll(os);
/*     */       }
/*     */ 
/*     */       public int hashCode() {
/* 277 */         return Tables.TransposeTable.this.original.hashCode();
/*     */       }
/*     */ 
/*     */       public boolean contains(Object obj) {
/* 281 */         if ((obj instanceof Table.Cell)) {
/* 282 */           Table.Cell cell = (Table.Cell)obj;
/* 283 */           return Tables.TransposeTable.this.original.cellSet().contains(Tables.immutableCell(cell.getColumnKey(), cell.getRowKey(), cell.getValue()));
/*     */         }
/*     */ 
/* 286 */         return false;
/*     */       }
/*     */ 
/*     */       public boolean remove(Object obj) {
/* 290 */         if ((obj instanceof Table.Cell)) {
/* 291 */           Table.Cell cell = (Table.Cell)obj;
/* 292 */           return Tables.TransposeTable.this.original.cellSet().remove(Tables.immutableCell(cell.getColumnKey(), cell.getRowKey(), cell.getValue()));
/*     */         }
/*     */ 
/* 295 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract class AbstractCell<R, C, V>
/*     */     implements Table.Cell<R, C, V>
/*     */   {
/*     */     public boolean equals(Object obj)
/*     */     {
/*  93 */       if (obj == this) {
/*  94 */         return true;
/*     */       }
/*  96 */       if ((obj instanceof Table.Cell)) {
/*  97 */         Table.Cell other = (Table.Cell)obj;
/*  98 */         return (Objects.equal(getRowKey(), other.getRowKey())) && (Objects.equal(getColumnKey(), other.getColumnKey())) && (Objects.equal(getValue(), other.getValue()));
/*     */       }
/*     */ 
/* 102 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 106 */       return (getRowKey() == null ? 0 : getRowKey().hashCode()) ^ (getColumnKey() == null ? 0 : getColumnKey().hashCode()) ^ (getValue() == null ? 0 : getValue().hashCode());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 112 */       return "(" + getRowKey() + "," + getColumnKey() + ")=" + getValue() + "";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImmutableCell<R, C, V> extends Tables.AbstractCell<R, C, V>
/*     */     implements Serializable
/*     */   {
/*     */     final R rowKey;
/*     */     final C columnKey;
/*     */     final V value;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     ImmutableCell(@Nullable R rowKey, @Nullable C columnKey, @Nullable V value)
/*     */     {
/*  69 */       this.rowKey = rowKey;
/*  70 */       this.columnKey = columnKey;
/*  71 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public R getRowKey() {
/*  75 */       return this.rowKey;
/*     */     }
/*     */     public C getColumnKey() {
/*  78 */       return this.columnKey;
/*     */     }
/*     */     public V getValue() {
/*  81 */       return this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Tables
 * JD-Core Version:    0.6.0
 */