package com.google.appengine.repackaged.com.google.io.protocol;

public abstract interface CategoryInformation<T extends ProtocolMessage>
{
  public abstract String getSimpleClassName(T paramT);

  public abstract String getFullClassName(T paramT);

  public abstract T parse(CharSequence paramCharSequence, T paramT);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.CategoryInformation
 * JD-Core Version:    0.6.0
 */