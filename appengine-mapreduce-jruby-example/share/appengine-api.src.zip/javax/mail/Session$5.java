/*      */ package javax.mail;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ 
/*      */ class Session$5
/*      */   implements PrivilegedAction
/*      */ {
/*      */   public Object run()
/*      */   {
/* 1219 */     URL[] ret = null;
/*      */     try {
/* 1221 */       Vector v = new Vector();
/* 1222 */       Enumeration e = this.val$cl.getResources(this.val$name);
/* 1223 */       while ((e != null) && (e.hasMoreElements())) {
/* 1224 */         URL url = (URL)e.nextElement();
/* 1225 */         if (url != null)
/* 1226 */           v.addElement(url);
/*      */       }
/* 1228 */       if (v.size() > 0) {
/* 1229 */         ret = new URL[v.size()];
/* 1230 */         v.copyInto(ret);
/*      */       }
/*      */     } catch (IOException ioex) {
/*      */     } catch (SecurityException ex) {
/*      */     }
/* 1234 */     return ret;
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Session.5
 * JD-Core Version:    0.6.0
 */