/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public final class UnknownFieldSet
/*     */   implements MessageLite
/*     */ {
/*  54 */   private static final UnknownFieldSet defaultInstance = new UnknownFieldSet(Collections.emptyMap());
/*     */   private Map<Integer, Field> fields;
/*     */ 
/*     */   private UnknownFieldSet()
/*     */   {
/*     */   }
/*     */ 
/*     */   public static Builder newBuilder()
/*     */   {
/*  36 */     return Builder.access$000();
/*     */   }
/*     */ 
/*     */   public static Builder newBuilder(UnknownFieldSet copyFrom)
/*     */   {
/*  44 */     return newBuilder().mergeFrom(copyFrom);
/*     */   }
/*     */ 
/*     */   public static UnknownFieldSet getDefaultInstance()
/*     */   {
/*  49 */     return defaultInstance;
/*     */   }
/*     */   public UnknownFieldSet getDefaultInstanceForType() {
/*  52 */     return defaultInstance;
/*     */   }
/*     */ 
/*     */   private UnknownFieldSet(Map<Integer, Field> fields)
/*     */   {
/*  62 */     this.fields = fields;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  68 */     if (this == other) {
/*  69 */       return true;
/*     */     }
/*  71 */     return ((other instanceof UnknownFieldSet)) && (this.fields.equals(((UnknownFieldSet)other).fields));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  77 */     return this.fields.hashCode();
/*     */   }
/*     */ 
/*     */   public Map<Integer, Field> asMap()
/*     */   {
/*  82 */     return this.fields;
/*     */   }
/*     */ 
/*     */   public boolean hasField(int number)
/*     */   {
/*  87 */     return this.fields.containsKey(Integer.valueOf(number));
/*     */   }
/*     */ 
/*     */   public Field getField(int number)
/*     */   {
/*  95 */     Field result = (Field)this.fields.get(Integer.valueOf(number));
/*  96 */     return result == null ? Field.getDefaultInstance() : result;
/*     */   }
/*     */ 
/*     */   public void writeTo(CodedOutputStream output) throws IOException
/*     */   {
/* 101 */     for (Map.Entry entry : this.fields.entrySet())
/* 102 */       ((Field)entry.getValue()).writeTo(((Integer)entry.getKey()).intValue(), output);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 113 */     return TextFormat.printToString(this);
/*     */   }
/*     */ 
/*     */   public ByteString toByteString()
/*     */   {
/*     */     try
/*     */     {
/* 122 */       ByteString.CodedBuilder out = ByteString.newCodedBuilder(getSerializedSize());
/*     */ 
/* 124 */       writeTo(out.getCodedOutput());
/* 125 */       return out.build(); } catch (IOException e) {
/*     */     }
/* 127 */     throw new RuntimeException("Serializing to a ByteString threw an IOException (should never happen).", e);
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray()
/*     */   {
/*     */     try
/*     */     {
/* 139 */       byte[] result = new byte[getSerializedSize()];
/* 140 */       CodedOutputStream output = CodedOutputStream.newInstance(result);
/* 141 */       writeTo(output);
/* 142 */       output.checkNoSpaceLeft();
/* 143 */       return result; } catch (IOException e) {
/*     */     }
/* 145 */     throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream output)
/*     */     throws IOException
/*     */   {
/* 156 */     CodedOutputStream codedOutput = CodedOutputStream.newInstance(output);
/* 157 */     writeTo(codedOutput);
/* 158 */     codedOutput.flush();
/*     */   }
/*     */ 
/*     */   public void writeDelimitedTo(OutputStream output) throws IOException {
/* 162 */     CodedOutputStream codedOutput = CodedOutputStream.newInstance(output);
/* 163 */     codedOutput.writeRawVarint32(getSerializedSize());
/* 164 */     writeTo(codedOutput);
/* 165 */     codedOutput.flush();
/*     */   }
/*     */ 
/*     */   public int getSerializedSize()
/*     */   {
/* 170 */     int result = 0;
/* 171 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 172 */       result += ((Field)entry.getValue()).getSerializedSize(((Integer)entry.getKey()).intValue());
/*     */     }
/* 174 */     return result;
/*     */   }
/*     */ 
/*     */   public void writeAsMessageSetTo(CodedOutputStream output)
/*     */     throws IOException
/*     */   {
/* 183 */     for (Map.Entry entry : this.fields.entrySet())
/* 184 */       ((Field)entry.getValue()).writeAsMessageSetExtensionTo(((Integer)entry.getKey()).intValue(), output);
/*     */   }
/*     */ 
/*     */   public int getSerializedSizeAsMessageSet()
/*     */   {
/* 194 */     int result = 0;
/* 195 */     for (Map.Entry entry : this.fields.entrySet()) {
/* 196 */       result += ((Field)entry.getValue()).getSerializedSizeAsMessageSetExtension(((Integer)entry.getKey()).intValue());
/*     */     }
/*     */ 
/* 199 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */   public static UnknownFieldSet parseFrom(CodedInputStream input)
/*     */     throws IOException
/*     */   {
/* 211 */     return newBuilder().mergeFrom(input).build();
/*     */   }
/*     */ 
/*     */   public static UnknownFieldSet parseFrom(ByteString data)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 217 */     return newBuilder().mergeFrom(data).build();
/*     */   }
/*     */ 
/*     */   public static UnknownFieldSet parseFrom(byte[] data)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 223 */     return newBuilder().mergeFrom(data).build();
/*     */   }
/*     */ 
/*     */   public static UnknownFieldSet parseFrom(InputStream input)
/*     */     throws IOException
/*     */   {
/* 229 */     return newBuilder().mergeFrom(input).build();
/*     */   }
/*     */ 
/*     */   public Builder newBuilderForType() {
/* 233 */     return newBuilder();
/*     */   }
/*     */ 
/*     */   public Builder toBuilder() {
/* 237 */     return newBuilder().mergeFrom(this); } 
/* 648 */   public static final class Field { private static final Field fieldDefaultInstance = newBuilder().build();
/*     */     private List<Long> varint;
/*     */     private List<Integer> fixed32;
/*     */     private List<Long> fixed64;
/*     */     private List<ByteString> lengthDelimited;
/*     */     private List<UnknownFieldSet> group;
/*     */ 
/* 633 */     public static Builder newBuilder() { return Builder.access$300();
/*     */     }
/*     */ 
/*     */     public static Builder newBuilder(Field copyFrom)
/*     */     {
/* 641 */       return newBuilder().mergeFrom(copyFrom);
/*     */     }
/*     */ 
/*     */     public static Field getDefaultInstance()
/*     */     {
/* 646 */       return fieldDefaultInstance;
/*     */     }
/*     */ 
/*     */     public List<Long> getVarintList()
/*     */     {
/* 651 */       return this.varint;
/*     */     }
/*     */     public List<Integer> getFixed32List() {
/* 654 */       return this.fixed32;
/*     */     }
/*     */     public List<Long> getFixed64List() {
/* 657 */       return this.fixed64;
/*     */     }
/*     */     public List<ByteString> getLengthDelimitedList() {
/* 660 */       return this.lengthDelimited;
/*     */     }
/*     */ 
/*     */     public List<UnknownFieldSet> getGroupList()
/*     */     {
/* 667 */       return this.group;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/* 671 */       if (this == other) {
/* 672 */         return true;
/*     */       }
/* 674 */       if (!(other instanceof Field)) {
/* 675 */         return false;
/*     */       }
/* 677 */       return Arrays.equals(getIdentityArray(), ((Field)other).getIdentityArray());
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 683 */       return Arrays.hashCode(getIdentityArray());
/*     */     }
/*     */ 
/*     */     private Object[] getIdentityArray()
/*     */     {
/* 691 */       return new Object[] { this.varint, this.fixed32, this.fixed64, this.lengthDelimited, this.group };
/*     */     }
/*     */ 
/*     */     public void writeTo(int fieldNumber, CodedOutputStream output)
/*     */       throws IOException
/*     */     {
/* 705 */       for (Iterator i$ = this.varint.iterator(); i$.hasNext(); ) { long value = ((Long)i$.next()).longValue();
/* 706 */         output.writeUInt64(fieldNumber, value);
/*     */       }
/* 708 */       for (Iterator i$ = this.fixed32.iterator(); i$.hasNext(); ) { int value = ((Integer)i$.next()).intValue();
/* 709 */         output.writeFixed32(fieldNumber, value);
/*     */       }
/* 711 */       for (Iterator i$ = this.fixed64.iterator(); i$.hasNext(); ) { long value = ((Long)i$.next()).longValue();
/* 712 */         output.writeFixed64(fieldNumber, value);
/*     */       }
/* 714 */       for (ByteString value : this.lengthDelimited) {
/* 715 */         output.writeBytes(fieldNumber, value);
/*     */       }
/* 717 */       for (UnknownFieldSet value : this.group)
/* 718 */         output.writeGroup(fieldNumber, value);
/*     */     }
/*     */ 
/*     */     public int getSerializedSize(int fieldNumber)
/*     */     {
/* 727 */       int result = 0;
/* 728 */       for (Iterator i$ = this.varint.iterator(); i$.hasNext(); ) { long value = ((Long)i$.next()).longValue();
/* 729 */         result += CodedOutputStream.computeUInt64Size(fieldNumber, value);
/*     */       }
/* 731 */       for (Iterator i$ = this.fixed32.iterator(); i$.hasNext(); ) { int value = ((Integer)i$.next()).intValue();
/* 732 */         result += CodedOutputStream.computeFixed32Size(fieldNumber, value);
/*     */       }
/* 734 */       for (Iterator i$ = this.fixed64.iterator(); i$.hasNext(); ) { long value = ((Long)i$.next()).longValue();
/* 735 */         result += CodedOutputStream.computeFixed64Size(fieldNumber, value);
/*     */       }
/* 737 */       for (ByteString value : this.lengthDelimited) {
/* 738 */         result += CodedOutputStream.computeBytesSize(fieldNumber, value);
/*     */       }
/* 740 */       for (UnknownFieldSet value : this.group) {
/* 741 */         result += CodedOutputStream.computeGroupSize(fieldNumber, value);
/*     */       }
/* 743 */       return result;
/*     */     }
/*     */ 
/*     */     public void writeAsMessageSetExtensionTo(int fieldNumber, CodedOutputStream output)
/*     */       throws IOException
/*     */     {
/* 754 */       for (ByteString value : this.lengthDelimited)
/* 755 */         output.writeRawMessageSetExtension(fieldNumber, value);
/*     */     }
/*     */ 
/*     */     public int getSerializedSizeAsMessageSetExtension(int fieldNumber)
/*     */     {
/* 764 */       int result = 0;
/* 765 */       for (ByteString value : this.lengthDelimited) {
/* 766 */         result += CodedOutputStream.computeRawMessageSetExtensionSize(fieldNumber, value);
/*     */       }
/*     */ 
/* 769 */       return result;
/*     */     }
/*     */ 
/*     */     public static final class Builder
/*     */     {
/*     */       private UnknownFieldSet.Field result;
/*     */ 
/*     */       private static Builder create()
/*     */       {
/* 788 */         Builder builder = new Builder();
/* 789 */         builder.result = new UnknownFieldSet.Field(null);
/* 790 */         return builder;
/*     */       }
/*     */ 
/*     */       public UnknownFieldSet.Field build()
/*     */       {
/* 802 */         if (this.result.varint == null)
/* 803 */           UnknownFieldSet.Field.access$502(this.result, Collections.emptyList());
/*     */         else {
/* 805 */           UnknownFieldSet.Field.access$502(this.result, Collections.unmodifiableList(this.result.varint));
/*     */         }
/* 807 */         if (this.result.fixed32 == null)
/* 808 */           UnknownFieldSet.Field.access$602(this.result, Collections.emptyList());
/*     */         else {
/* 810 */           UnknownFieldSet.Field.access$602(this.result, Collections.unmodifiableList(this.result.fixed32));
/*     */         }
/* 812 */         if (this.result.fixed64 == null)
/* 813 */           UnknownFieldSet.Field.access$702(this.result, Collections.emptyList());
/*     */         else {
/* 815 */           UnknownFieldSet.Field.access$702(this.result, Collections.unmodifiableList(this.result.fixed64));
/*     */         }
/* 817 */         if (this.result.lengthDelimited == null)
/* 818 */           UnknownFieldSet.Field.access$802(this.result, Collections.emptyList());
/*     */         else {
/* 820 */           UnknownFieldSet.Field.access$802(this.result, Collections.unmodifiableList(this.result.lengthDelimited));
/*     */         }
/*     */ 
/* 823 */         if (this.result.group == null)
/* 824 */           UnknownFieldSet.Field.access$902(this.result, Collections.emptyList());
/*     */         else {
/* 826 */           UnknownFieldSet.Field.access$902(this.result, Collections.unmodifiableList(this.result.group));
/*     */         }
/*     */ 
/* 829 */         UnknownFieldSet.Field returnMe = this.result;
/* 830 */         this.result = null;
/* 831 */         return returnMe;
/*     */       }
/*     */ 
/*     */       public Builder clear()
/*     */       {
/* 836 */         this.result = new UnknownFieldSet.Field(null);
/* 837 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder mergeFrom(UnknownFieldSet.Field other)
/*     */       {
/* 846 */         if (!other.varint.isEmpty()) {
/* 847 */           if (this.result.varint == null) {
/* 848 */             UnknownFieldSet.Field.access$502(this.result, new ArrayList());
/*     */           }
/* 850 */           this.result.varint.addAll(other.varint);
/*     */         }
/* 852 */         if (!other.fixed32.isEmpty()) {
/* 853 */           if (this.result.fixed32 == null) {
/* 854 */             UnknownFieldSet.Field.access$602(this.result, new ArrayList());
/*     */           }
/* 856 */           this.result.fixed32.addAll(other.fixed32);
/*     */         }
/* 858 */         if (!other.fixed64.isEmpty()) {
/* 859 */           if (this.result.fixed64 == null) {
/* 860 */             UnknownFieldSet.Field.access$702(this.result, new ArrayList());
/*     */           }
/* 862 */           this.result.fixed64.addAll(other.fixed64);
/*     */         }
/* 864 */         if (!other.lengthDelimited.isEmpty()) {
/* 865 */           if (this.result.lengthDelimited == null) {
/* 866 */             UnknownFieldSet.Field.access$802(this.result, new ArrayList());
/*     */           }
/* 868 */           this.result.lengthDelimited.addAll(other.lengthDelimited);
/*     */         }
/* 870 */         if (!other.group.isEmpty()) {
/* 871 */           if (this.result.group == null) {
/* 872 */             UnknownFieldSet.Field.access$902(this.result, new ArrayList());
/*     */           }
/* 874 */           this.result.group.addAll(other.group);
/*     */         }
/* 876 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder addVarint(long value)
/*     */       {
/* 881 */         if (this.result.varint == null) {
/* 882 */           UnknownFieldSet.Field.access$502(this.result, new ArrayList());
/*     */         }
/* 884 */         this.result.varint.add(Long.valueOf(value));
/* 885 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder addFixed32(int value)
/*     */       {
/* 890 */         if (this.result.fixed32 == null) {
/* 891 */           UnknownFieldSet.Field.access$602(this.result, new ArrayList());
/*     */         }
/* 893 */         this.result.fixed32.add(Integer.valueOf(value));
/* 894 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder addFixed64(long value)
/*     */       {
/* 899 */         if (this.result.fixed64 == null) {
/* 900 */           UnknownFieldSet.Field.access$702(this.result, new ArrayList());
/*     */         }
/* 902 */         this.result.fixed64.add(Long.valueOf(value));
/* 903 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder addLengthDelimited(ByteString value)
/*     */       {
/* 908 */         if (this.result.lengthDelimited == null) {
/* 909 */           UnknownFieldSet.Field.access$802(this.result, new ArrayList());
/*     */         }
/* 911 */         this.result.lengthDelimited.add(value);
/* 912 */         return this;
/*     */       }
/*     */ 
/*     */       public Builder addGroup(UnknownFieldSet value)
/*     */       {
/* 917 */         if (this.result.group == null) {
/* 918 */           UnknownFieldSet.Field.access$902(this.result, new ArrayList());
/*     */         }
/* 920 */         this.result.group.add(value);
/* 921 */         return this;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */     implements MessageLite.Builder
/*     */   {
/*     */     private Map<Integer, UnknownFieldSet.Field> fields;
/*     */     private int lastFieldNumber;
/*     */     private UnknownFieldSet.Field.Builder lastField;
/*     */ 
/*     */     private static Builder create()
/*     */     {
/* 265 */       Builder builder = new Builder();
/* 266 */       builder.reinitialize();
/* 267 */       return builder;
/*     */     }
/*     */ 
/*     */     private UnknownFieldSet.Field.Builder getFieldBuilder(int number)
/*     */     {
/* 275 */       if (this.lastField != null) {
/* 276 */         if (number == this.lastFieldNumber) {
/* 277 */           return this.lastField;
/*     */         }
/*     */ 
/* 280 */         addField(this.lastFieldNumber, this.lastField.build());
/*     */       }
/* 282 */       if (number == 0) {
/* 283 */         return null;
/*     */       }
/* 285 */       UnknownFieldSet.Field existing = (UnknownFieldSet.Field)this.fields.get(Integer.valueOf(number));
/* 286 */       this.lastFieldNumber = number;
/* 287 */       this.lastField = UnknownFieldSet.Field.newBuilder();
/* 288 */       if (existing != null) {
/* 289 */         this.lastField.mergeFrom(existing);
/*     */       }
/* 291 */       return this.lastField;
/*     */     }
/*     */ 
/*     */     public UnknownFieldSet build()
/*     */     {
/* 304 */       getFieldBuilder(0);
/*     */       UnknownFieldSet result;
/*     */       UnknownFieldSet result;
/* 306 */       if (this.fields.isEmpty())
/* 307 */         result = UnknownFieldSet.getDefaultInstance();
/*     */       else {
/* 309 */         result = new UnknownFieldSet(Collections.unmodifiableMap(this.fields), null);
/*     */       }
/* 311 */       this.fields = null;
/* 312 */       return result;
/*     */     }
/*     */ 
/*     */     public UnknownFieldSet buildPartial()
/*     */     {
/* 317 */       return build();
/*     */     }
/*     */ 
/*     */     public Builder clone()
/*     */     {
/* 322 */       getFieldBuilder(0);
/* 323 */       return UnknownFieldSet.newBuilder().mergeFrom(new UnknownFieldSet(this.fields, null));
/*     */     }
/*     */ 
/*     */     public UnknownFieldSet getDefaultInstanceForType()
/*     */     {
/* 328 */       return UnknownFieldSet.getDefaultInstance();
/*     */     }
/*     */ 
/*     */     private void reinitialize() {
/* 332 */       this.fields = Collections.emptyMap();
/* 333 */       this.lastFieldNumber = 0;
/* 334 */       this.lastField = null;
/*     */     }
/*     */ 
/*     */     public Builder clear()
/*     */     {
/* 339 */       reinitialize();
/* 340 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(UnknownFieldSet other)
/*     */     {
/* 349 */       if (other != UnknownFieldSet.getDefaultInstance()) {
/* 350 */         for (Map.Entry entry : other.fields.entrySet()) {
/* 351 */           mergeField(((Integer)entry.getKey()).intValue(), (UnknownFieldSet.Field)entry.getValue());
/*     */         }
/*     */       }
/* 354 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder mergeField(int number, UnknownFieldSet.Field field)
/*     */     {
/* 362 */       if (number == 0) {
/* 363 */         throw new IllegalArgumentException("Zero is not a valid field number.");
/*     */       }
/* 365 */       if (hasField(number)) {
/* 366 */         getFieldBuilder(number).mergeFrom(field);
/*     */       }
/*     */       else
/*     */       {
/* 371 */         addField(number, field);
/*     */       }
/* 373 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder mergeVarintField(int number, int value)
/*     */     {
/* 382 */       if (number == 0) {
/* 383 */         throw new IllegalArgumentException("Zero is not a valid field number.");
/*     */       }
/* 385 */       getFieldBuilder(number).addVarint(value);
/* 386 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean hasField(int number)
/*     */     {
/* 391 */       if (number == 0) {
/* 392 */         throw new IllegalArgumentException("Zero is not a valid field number.");
/*     */       }
/* 394 */       return (number == this.lastFieldNumber) || (this.fields.containsKey(Integer.valueOf(number)));
/*     */     }
/*     */ 
/*     */     public Builder addField(int number, UnknownFieldSet.Field field)
/*     */     {
/* 402 */       if (number == 0) {
/* 403 */         throw new IllegalArgumentException("Zero is not a valid field number.");
/*     */       }
/* 405 */       if ((this.lastField != null) && (this.lastFieldNumber == number))
/*     */       {
/* 407 */         this.lastField = null;
/* 408 */         this.lastFieldNumber = 0;
/*     */       }
/* 410 */       if (this.fields.isEmpty()) {
/* 411 */         this.fields = new TreeMap();
/*     */       }
/* 413 */       this.fields.put(Integer.valueOf(number), field);
/* 414 */       return this;
/*     */     }
/*     */ 
/*     */     public Map<Integer, UnknownFieldSet.Field> asMap()
/*     */     {
/* 422 */       getFieldBuilder(0);
/* 423 */       return Collections.unmodifiableMap(this.fields);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(CodedInputStream input)
/*     */       throws IOException
/*     */     {
/*     */       while (true)
/*     */       {
/* 432 */         int tag = input.readTag();
/* 433 */         if ((tag == 0) || (!mergeFieldFrom(tag, input))) {
/*     */           break;
/*     */         }
/*     */       }
/* 437 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean mergeFieldFrom(int tag, CodedInputStream input)
/*     */       throws IOException
/*     */     {
/* 447 */       int number = WireFormat.getTagFieldNumber(tag);
/* 448 */       switch (WireFormat.getTagWireType(tag)) {
/*     */       case 0:
/* 450 */         getFieldBuilder(number).addVarint(input.readInt64());
/* 451 */         return true;
/*     */       case 1:
/* 453 */         getFieldBuilder(number).addFixed64(input.readFixed64());
/* 454 */         return true;
/*     */       case 2:
/* 456 */         getFieldBuilder(number).addLengthDelimited(input.readBytes());
/* 457 */         return true;
/*     */       case 3:
/* 459 */         Builder subBuilder = UnknownFieldSet.newBuilder();
/* 460 */         input.readGroup(number, subBuilder, ExtensionRegistry.getEmptyRegistry());
/*     */ 
/* 462 */         getFieldBuilder(number).addGroup(subBuilder.build());
/* 463 */         return true;
/*     */       case 4:
/* 465 */         return false;
/*     */       case 5:
/* 467 */         getFieldBuilder(number).addFixed32(input.readFixed32());
/* 468 */         return true;
/*     */       }
/* 470 */       throw InvalidProtocolBufferException.invalidWireType();
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(ByteString data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*     */       try
/*     */       {
/* 482 */         CodedInputStream input = data.newCodedInput();
/* 483 */         mergeFrom(input);
/* 484 */         input.checkLastTagWas(0);
/* 485 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/* 487 */         throw e; } catch (IOException e) {
/*     */       }
/* 489 */       throw new RuntimeException("Reading from a ByteString threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(byte[] data)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/*     */       try
/*     */       {
/* 503 */         CodedInputStream input = CodedInputStream.newInstance(data);
/* 504 */         mergeFrom(input);
/* 505 */         input.checkLastTagWas(0);
/* 506 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/* 508 */         throw e; } catch (IOException e) {
/*     */       }
/* 510 */       throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(InputStream input)
/*     */       throws IOException
/*     */     {
/* 522 */       CodedInputStream codedInput = CodedInputStream.newInstance(input);
/* 523 */       mergeFrom(codedInput);
/* 524 */       codedInput.checkLastTagWas(0);
/* 525 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean mergeDelimitedFrom(InputStream input) throws IOException
/*     */     {
/* 530 */       int firstByte = input.read();
/* 531 */       if (firstByte == -1) {
/* 532 */         return false;
/*     */       }
/* 534 */       int size = CodedInputStream.readRawVarint32(firstByte, input);
/* 535 */       InputStream limitedInput = new AbstractMessageLite.Builder.LimitedInputStream(input, size);
/* 536 */       mergeFrom(limitedInput);
/* 537 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean mergeDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 544 */       return mergeDelimitedFrom(input);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 551 */       return mergeFrom(input);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 559 */       return mergeFrom(data);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(byte[] data, int off, int len) throws InvalidProtocolBufferException
/*     */     {
/*     */       try {
/* 565 */         CodedInputStream input = CodedInputStream.newInstance(data, off, len);
/*     */ 
/* 567 */         mergeFrom(input);
/* 568 */         input.checkLastTagWas(0);
/* 569 */         return this;
/*     */       } catch (InvalidProtocolBufferException e) {
/* 571 */         throw e; } catch (IOException e) {
/*     */       }
/* 573 */       throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).", e);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 584 */       return mergeFrom(data);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(byte[] data, int off, int len, ExtensionRegistryLite extensionRegistry)
/*     */       throws InvalidProtocolBufferException
/*     */     {
/* 592 */       return mergeFrom(data, off, len);
/*     */     }
/*     */ 
/*     */     public Builder mergeFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*     */       throws IOException
/*     */     {
/* 599 */       return mergeFrom(input);
/*     */     }
/*     */ 
/*     */     public boolean isInitialized()
/*     */     {
/* 605 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet
 * JD-Core Version:    0.6.0
 */