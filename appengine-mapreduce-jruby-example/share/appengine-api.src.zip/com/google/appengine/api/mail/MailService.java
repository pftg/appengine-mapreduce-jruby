/*     */ package com.google.appengine.api.mail;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public abstract interface MailService
/*     */ {
/*     */   public abstract void send(Message paramMessage)
/*     */     throws IOException;
/*     */ 
/*     */   public abstract void sendToAdmins(Message paramMessage)
/*     */     throws IOException;
/*     */ 
/*     */   public static class Message
/*     */   {
/*     */     private String sender;
/*     */     private String replyTo;
/*     */     private Collection<String> to;
/*     */     private Collection<String> cc;
/*     */     private Collection<String> bcc;
/*     */     private String subject;
/*     */     private String textBody;
/*     */     private String htmlBody;
/*     */     private Collection<MailService.Attachment> attachments;
/*     */ 
/*     */     public Message()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Message(String sender, String to, String subject, String textBody)
/*     */     {
/*  90 */       this.sender = sender;
/*  91 */       this.to = Arrays.asList(new String[] { to });
/*  92 */       this.subject = subject;
/*  93 */       this.textBody = textBody;
/*     */     }
/*     */ 
/*     */     public String getSender()
/*     */     {
/* 102 */       return this.sender;
/*     */     }
/*     */ 
/*     */     public void setSender(String sender)
/*     */     {
/* 111 */       this.sender = sender;
/*     */     }
/*     */ 
/*     */     public String getReplyTo()
/*     */     {
/* 120 */       return this.replyTo;
/*     */     }
/*     */ 
/*     */     public void setReplyTo(String replyTo)
/*     */     {
/* 128 */       this.replyTo = replyTo;
/*     */     }
/*     */ 
/*     */     public Collection<String> getTo()
/*     */     {
/* 137 */       return this.to;
/*     */     }
/*     */ 
/*     */     public void setTo(Collection<String> to)
/*     */     {
/* 148 */       this.to = to;
/*     */     }
/*     */ 
/*     */     public void setTo(String[] to)
/*     */     {
/* 159 */       this.to = Arrays.asList(to);
/*     */     }
/*     */ 
/*     */     public Collection<String> getCc()
/*     */     {
/* 168 */       return this.cc;
/*     */     }
/*     */ 
/*     */     public void setCc(Collection<String> cc)
/*     */     {
/* 179 */       this.cc = cc;
/*     */     }
/*     */ 
/*     */     public void setCc(String[] cc)
/*     */     {
/* 190 */       this.cc = Arrays.asList(cc);
/*     */     }
/*     */ 
/*     */     public Collection<String> getBcc()
/*     */     {
/* 199 */       return this.bcc;
/*     */     }
/*     */ 
/*     */     public void setBcc(Collection<String> bcc)
/*     */     {
/* 210 */       this.bcc = bcc;
/*     */     }
/*     */ 
/*     */     public void setBcc(String[] bcc)
/*     */     {
/* 221 */       this.bcc = Arrays.asList(bcc);
/*     */     }
/*     */ 
/*     */     public String getSubject()
/*     */     {
/* 230 */       return this.subject;
/*     */     }
/*     */ 
/*     */     public void setSubject(String subject)
/*     */     {
/* 240 */       this.subject = subject;
/*     */     }
/*     */ 
/*     */     public String getTextBody()
/*     */     {
/* 249 */       return this.textBody;
/*     */     }
/*     */ 
/*     */     public void setTextBody(String textBody)
/*     */     {
/* 258 */       this.textBody = textBody;
/*     */     }
/*     */ 
/*     */     public String getHtmlBody()
/*     */     {
/* 267 */       return this.htmlBody;
/*     */     }
/*     */ 
/*     */     public void setHtmlBody(String htmlBody)
/*     */     {
/* 276 */       this.htmlBody = htmlBody;
/*     */     }
/*     */ 
/*     */     public Collection<MailService.Attachment> getAttachments()
/*     */     {
/* 285 */       return this.attachments;
/*     */     }
/*     */ 
/*     */     public void setAttachments(Collection<MailService.Attachment> attachments)
/*     */     {
/* 295 */       this.attachments = attachments;
/*     */     }
/*     */ 
/*     */     public void setAttachments(MailService.Attachment[] attachments)
/*     */     {
/* 305 */       this.attachments = Arrays.asList(attachments);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Attachment
/*     */   {
/*     */     private final String fileName;
/*     */     private final byte[] data;
/*     */ 
/*     */     public Attachment(String fileName, byte[] data)
/*     */     {
/*  38 */       if ((data == null) || (fileName == null) || (fileName.length() == 0)) {
/*  39 */         throw new IllegalArgumentException("Attachment needs content and name");
/*     */       }
/*  41 */       this.fileName = fileName;
/*  42 */       this.data = data;
/*     */     }
/*     */ 
/*     */     public String getFileName()
/*     */     {
/*  51 */       return this.fileName;
/*     */     }
/*     */ 
/*     */     public byte[] getData()
/*     */     {
/*  60 */       return this.data;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.mail.MailService
 * JD-Core Version:    0.6.0
 */