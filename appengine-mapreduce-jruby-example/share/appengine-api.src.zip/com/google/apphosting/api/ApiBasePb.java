/*      */ package com.google.apphosting.api;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ public class ApiBasePb
/*      */ {
/*      */   public static class VoidProto extends ProtocolMessage<VoidProto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     public static final VoidProto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public VoidProto mergeFrom(VoidProto that)
/*      */     {
/* 1574 */       assert (that != this);
/*      */ 
/* 1576 */       if (that.uninterpreted != null) {
/* 1577 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1579 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(VoidProto that) {
/* 1583 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(VoidProto that) {
/* 1587 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(VoidProto that, boolean ignoreUninterpreted) {
/* 1591 */       if (that == null) return false;
/* 1592 */       if (that == this) return true;
/*      */ 
/* 1594 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1599 */       return ((that instanceof VoidProto)) && (equals((VoidProto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1603 */       int hash = -2081765763;
/* 1604 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1605 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1607 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1611 */       return true;
/*      */     }
/*      */ 
/*      */     public int encodingSize() {
/* 1615 */       int n = 0;
/*      */ 
/* 1617 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1622 */       int n = 0;
/*      */ 
/* 1624 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1629 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1633 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public VoidProto newInstance() {
/* 1637 */       return new VoidProto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1641 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1655 */       if (this.uninterpreted != null)
/* 1656 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1661 */       boolean result = true;
/*      */ 
/* 1663 */       while (source.hasRemaining()) {
/* 1664 */         int tt = source.getVarInt();
/* 1665 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1669 */           result = false;
/* 1670 */           break;
/*      */         default:
/* 1672 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1677 */       return result;
/*      */     }
/*      */ 
/*      */     public VoidProto getDefaultInstanceForType()
/*      */     {
/* 1682 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final VoidProto getDefaultInstance() {
/* 1686 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1716 */       if (this.uninterpreted == null) {
/* 1717 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1719 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1690 */       IMMUTABLE_DEFAULT_INSTANCE = new VoidProto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.VoidProto mergeFrom(ApiBasePb.VoidProto that)
/*      */         {
/* 1697 */           ProtocolSupport.unsupportedOperation();
/* 1698 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1701 */           ProtocolSupport.unsupportedOperation();
/* 1702 */           return false;
/*      */         }
/*      */         public ApiBasePb.VoidProto freeze() {
/* 1705 */           return this;
/*      */         }
/*      */         public ApiBasePb.VoidProto unfreeze() {
/* 1708 */           ProtocolSupport.unsupportedOperation();
/* 1709 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1712 */           return true;
/*      */         }
/*      */       };
/* 1723 */       text = new String[1];
/*      */ 
/* 1725 */       text[0] = "ErrorCode";
/*      */ 
/* 1728 */       types = new int[1];
/*      */ 
/* 1730 */       Arrays.fill(types, 6);
/* 1731 */       types[0] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1645 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.VoidProto.class, "Z\035apphosting/api/api_base.proto\n\031apphosting.base.VoidProto", new ProtocolType.FieldType[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class BytesProto extends ProtocolMessage<BytesProto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1290 */     private byte[] value_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final BytesProto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kvalue = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getValueAsBytes()
/*      */     {
/* 1296 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/* 1299 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public BytesProto clearValue() {
/* 1302 */       this.optional_0_ &= -2;
/* 1303 */       this.value_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1304 */       return this;
/*      */     }
/*      */     public BytesProto setValueAsBytes(byte[] x) {
/* 1307 */       this.optional_0_ |= 1;
/* 1308 */       this.value_ = x;
/* 1309 */       return this;
/*      */     }
/*      */     public final String getValue() {
/* 1312 */       return ProtocolSupport.toStringUtf8(this.value_);
/*      */     }
/*      */     public BytesProto setValue(String v) {
/* 1315 */       if (v == null) throw new NullPointerException();
/* 1316 */       this.optional_0_ |= 1;
/* 1317 */       this.value_ = ProtocolSupport.toBytesUtf8(v);
/* 1318 */       return this;
/*      */     }
/*      */     public final String getValue(Charset cs) {
/* 1321 */       return ProtocolSupport.toString(this.value_, cs);
/*      */     }
/*      */     public BytesProto setValue(String v, Charset cs) {
/* 1324 */       if (v == null) throw new NullPointerException();
/* 1325 */       this.optional_0_ |= 1;
/* 1326 */       this.value_ = ProtocolSupport.toBytes(v, cs);
/* 1327 */       return this;
/*      */     }
/*      */ 
/*      */     public BytesProto mergeFrom(BytesProto that)
/*      */     {
/* 1334 */       assert (that != this);
/* 1335 */       int this_t0 = this.optional_0_;
/* 1336 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1338 */       if ((that_t0 & 0x1) != 0) {
/* 1339 */         this_t0 |= 1;
/* 1340 */         this.value_ = that.value_;
/*      */       }
/*      */ 
/* 1343 */       if (that.uninterpreted != null) {
/* 1344 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1346 */       this.optional_0_ = this_t0;
/* 1347 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(BytesProto that) {
/* 1351 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(BytesProto that) {
/* 1355 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(BytesProto that, boolean ignoreUninterpreted) {
/* 1359 */       if (that == null) return false;
/* 1360 */       if (that == this) return true;
/* 1361 */       int this_t0 = this.optional_0_;
/* 1362 */       int that_t0 = that.optional_0_;
/* 1363 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1365 */       if (((this_t0 & 0x1) != 0) && 
/* 1366 */         (!Arrays.equals(this.value_, that.value_))) return false;
/*      */ 
/* 1369 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1374 */       return ((that instanceof BytesProto)) && (equals((BytesProto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1378 */       int hash = -1311396311;
/*      */ 
/* 1380 */       int this_t0 = this.optional_0_;
/* 1381 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.value_) : -113);
/* 1382 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1383 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1385 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1389 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1391 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1398 */       int n = 1 + Protocol.stringSize(this.value_.length);
/*      */ 
/* 1400 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1406 */       int n = 6 + this.value_.length;
/*      */ 
/* 1408 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1413 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1417 */       this.optional_0_ = 0;
/* 1418 */       this.value_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 1419 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public BytesProto newInstance() {
/* 1423 */       return new BytesProto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1427 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1446 */       sink.putByte(10);
/* 1447 */       sink.putPrefixedData(this.value_);
/*      */ 
/* 1449 */       if (this.uninterpreted != null)
/* 1450 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1455 */       boolean result = true;
/* 1456 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1458 */       while (source.hasRemaining()) {
/* 1459 */         int tt = source.getVarInt();
/* 1460 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1464 */           result = false;
/* 1465 */           break;
/*      */         case 10:
/* 1468 */           this.value_ = source.getPrefixedData();
/* 1469 */           this_t0 |= 1;
/* 1470 */           break;
/*      */         default:
/* 1472 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1477 */       this.optional_0_ = this_t0;
/* 1478 */       return result;
/*      */     }
/*      */ 
/*      */     public BytesProto getDefaultInstanceForType()
/*      */     {
/* 1483 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final BytesProto getDefaultInstance() {
/* 1487 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public BytesProto freeze()
/*      */     {
/* 1535 */       this.value_ = ProtocolSupport.freezeString(this.value_);
/* 1536 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/* 1539 */       if (this.uninterpreted == null) {
/* 1540 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1542 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1491 */       IMMUTABLE_DEFAULT_INSTANCE = new BytesProto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.BytesProto clearValue()
/*      */         {
/* 1499 */           return this;
/*      */         }
/*      */         public ApiBasePb.BytesProto setValueAsBytes(byte[] x) {
/* 1502 */           ProtocolSupport.unsupportedOperation();
/* 1503 */           return this;
/*      */         }
/*      */         public ApiBasePb.BytesProto setValue(String v) {
/* 1506 */           ProtocolSupport.unsupportedOperation();
/* 1507 */           return this;
/*      */         }
/*      */         public ApiBasePb.BytesProto setValue(String v, Charset cs) {
/* 1510 */           ProtocolSupport.unsupportedOperation();
/* 1511 */           return this;
/*      */         }
/*      */ 
/*      */         public ApiBasePb.BytesProto mergeFrom(ApiBasePb.BytesProto that) {
/* 1515 */           ProtocolSupport.unsupportedOperation();
/* 1516 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1519 */           ProtocolSupport.unsupportedOperation();
/* 1520 */           return false;
/*      */         }
/*      */         public ApiBasePb.BytesProto freeze() {
/* 1523 */           return this;
/*      */         }
/*      */         public ApiBasePb.BytesProto unfreeze() {
/* 1526 */           ProtocolSupport.unsupportedOperation();
/* 1527 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1530 */           return true;
/*      */         }
/*      */       };
/* 1547 */       text = new String[2];
/*      */ 
/* 1549 */       text[0] = "ErrorCode";
/* 1550 */       text[1] = "value";
/*      */ 
/* 1553 */       types = new int[2];
/*      */ 
/* 1555 */       Arrays.fill(types, 6);
/* 1556 */       types[0] = 0;
/* 1557 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1431 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.BytesProto.class, "Z\035apphosting/api/api_base.proto\n\032apphosting.base.BytesProto\023\032\005value \001(\0020\t8\002£\001ª\001\005ctype²\001\004Cord¤\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("value", "value", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class DoubleProto extends ProtocolMessage<DoubleProto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/* 1043 */     private double value_ = 0.0D;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final DoubleProto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kvalue = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final double getValue()
/*      */     {
/* 1049 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/* 1052 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public DoubleProto clearValue() {
/* 1055 */       this.optional_0_ &= -2;
/* 1056 */       this.value_ = 0.0D;
/* 1057 */       return this;
/*      */     }
/*      */     public DoubleProto setValue(double x) {
/* 1060 */       this.optional_0_ |= 1;
/* 1061 */       this.value_ = x;
/* 1062 */       return this;
/*      */     }
/*      */ 
/*      */     public DoubleProto mergeFrom(DoubleProto that)
/*      */     {
/* 1069 */       assert (that != this);
/* 1070 */       int this_t0 = this.optional_0_;
/* 1071 */       int that_t0 = that.optional_0_;
/*      */ 
/* 1073 */       if ((that_t0 & 0x1) != 0) {
/* 1074 */         this_t0 |= 1;
/* 1075 */         this.value_ = that.value_;
/*      */       }
/*      */ 
/* 1078 */       if (that.uninterpreted != null) {
/* 1079 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/* 1081 */       this.optional_0_ = this_t0;
/* 1082 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(DoubleProto that) {
/* 1086 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(DoubleProto that) {
/* 1090 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(DoubleProto that, boolean ignoreUninterpreted) {
/* 1094 */       if (that == null) return false;
/* 1095 */       if (that == this) return true;
/* 1096 */       int this_t0 = this.optional_0_;
/* 1097 */       int that_t0 = that.optional_0_;
/* 1098 */       if (this_t0 != that_t0) return false;
/*      */ 
/* 1100 */       if (((this_t0 & 0x1) != 0) && 
/* 1101 */         (this.value_ != that.value_)) return false;
/*      */ 
/* 1104 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/* 1109 */       return ((that instanceof DoubleProto)) && (equals((DoubleProto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/* 1113 */       int hash = -332337649;
/*      */ 
/* 1115 */       int this_t0 = this.optional_0_;
/* 1116 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.value_) : -113);
/* 1117 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 1118 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/* 1120 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/* 1124 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1126 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/* 1133 */       int n = 9;
/*      */ 
/* 1135 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/* 1141 */       int n = 9;
/*      */ 
/* 1143 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/* 1148 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/* 1152 */       this.optional_0_ = 0;
/* 1153 */       this.value_ = 0.0D;
/* 1154 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public DoubleProto newInstance() {
/* 1158 */       return new DoubleProto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/* 1162 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/* 1180 */       sink.putByte(9);
/* 1181 */       sink.putDouble(this.value_);
/*      */ 
/* 1183 */       if (this.uninterpreted != null)
/* 1184 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/* 1189 */       boolean result = true;
/* 1190 */       int this_t0 = this.optional_0_;
/*      */ 
/* 1192 */       while (source.hasRemaining()) {
/* 1193 */         int tt = source.getVarInt();
/* 1194 */         switch (tt)
/*      */         {
/*      */         case 0:
/* 1198 */           result = false;
/* 1199 */           break;
/*      */         case 9:
/* 1202 */           this.value_ = source.getDouble();
/* 1203 */           this_t0 |= 1;
/* 1204 */           break;
/*      */         default:
/* 1206 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1211 */       this.optional_0_ = this_t0;
/* 1212 */       return result;
/*      */     }
/*      */ 
/*      */     public DoubleProto getDefaultInstanceForType()
/*      */     {
/* 1217 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final DoubleProto getDefaultInstance() {
/* 1221 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1260 */       if (this.uninterpreted == null) {
/* 1261 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1263 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1225 */       IMMUTABLE_DEFAULT_INSTANCE = new DoubleProto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.DoubleProto clearValue()
/*      */         {
/* 1233 */           return this;
/*      */         }
/*      */         public ApiBasePb.DoubleProto setValue(double x) {
/* 1236 */           ProtocolSupport.unsupportedOperation();
/* 1237 */           return this;
/*      */         }
/*      */ 
/*      */         public ApiBasePb.DoubleProto mergeFrom(ApiBasePb.DoubleProto that) {
/* 1241 */           ProtocolSupport.unsupportedOperation();
/* 1242 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/* 1245 */           ProtocolSupport.unsupportedOperation();
/* 1246 */           return false;
/*      */         }
/*      */         public ApiBasePb.DoubleProto freeze() {
/* 1249 */           return this;
/*      */         }
/*      */         public ApiBasePb.DoubleProto unfreeze() {
/* 1252 */           ProtocolSupport.unsupportedOperation();
/* 1253 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1256 */           return true;
/*      */         }
/*      */       };
/* 1268 */       text = new String[2];
/*      */ 
/* 1270 */       text[0] = "ErrorCode";
/* 1271 */       text[1] = "value";
/*      */ 
/* 1274 */       types = new int[2];
/*      */ 
/* 1276 */       Arrays.fill(types, 6);
/* 1277 */       types[0] = 0;
/* 1278 */       types[1] = 1;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/* 1166 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.DoubleProto.class, "Z\035apphosting/api/api_base.proto\n\033apphosting.base.DoubleProto\023\032\005value \001(\0010\0018\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("value", "value", 1, 0, ProtocolType.FieldBaseType.DOUBLE, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class BoolProto extends ProtocolMessage<BoolProto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  797 */     private boolean value_ = false;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final BoolProto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kvalue = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final boolean isValue()
/*      */     {
/*  803 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/*  806 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public BoolProto clearValue() {
/*  809 */       this.optional_0_ &= -2;
/*  810 */       this.value_ = false;
/*  811 */       return this;
/*      */     }
/*      */     public BoolProto setValue(boolean x) {
/*  814 */       this.optional_0_ |= 1;
/*  815 */       this.value_ = x;
/*  816 */       return this;
/*      */     }
/*      */ 
/*      */     public BoolProto mergeFrom(BoolProto that)
/*      */     {
/*  823 */       assert (that != this);
/*  824 */       int this_t0 = this.optional_0_;
/*  825 */       int that_t0 = that.optional_0_;
/*      */ 
/*  827 */       if ((that_t0 & 0x1) != 0) {
/*  828 */         this_t0 |= 1;
/*  829 */         this.value_ = that.value_;
/*      */       }
/*      */ 
/*  832 */       if (that.uninterpreted != null) {
/*  833 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  835 */       this.optional_0_ = this_t0;
/*  836 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(BoolProto that) {
/*  840 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(BoolProto that) {
/*  844 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(BoolProto that, boolean ignoreUninterpreted) {
/*  848 */       if (that == null) return false;
/*  849 */       if (that == this) return true;
/*  850 */       int this_t0 = this.optional_0_;
/*  851 */       int that_t0 = that.optional_0_;
/*  852 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  854 */       if (((this_t0 & 0x1) != 0) && 
/*  855 */         (this.value_ != that.value_)) return false;
/*      */ 
/*  858 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  863 */       return ((that instanceof BoolProto)) && (equals((BoolProto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  867 */       int hash = -634183901;
/*      */ 
/*  869 */       int this_t0 = this.optional_0_;
/*  870 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? 1237 : this.value_ ? 1231 : -113);
/*  871 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  872 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  874 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  878 */       int this_t0 = this.optional_0_;
/*      */ 
/*  880 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  887 */       int n = 2;
/*      */ 
/*  889 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  895 */       int n = 2;
/*      */ 
/*  897 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  902 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  906 */       this.optional_0_ = 0;
/*  907 */       this.value_ = false;
/*  908 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public BoolProto newInstance() {
/*  912 */       return new BoolProto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  916 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  933 */       sink.putByte(8);
/*  934 */       sink.putBoolean(this.value_);
/*      */ 
/*  936 */       if (this.uninterpreted != null)
/*  937 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  942 */       boolean result = true;
/*  943 */       int this_t0 = this.optional_0_;
/*      */ 
/*  945 */       while (source.hasRemaining()) {
/*  946 */         int tt = source.getVarInt();
/*  947 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  951 */           result = false;
/*  952 */           break;
/*      */         case 8:
/*  955 */           this.value_ = source.getBoolean();
/*  956 */           this_t0 |= 1;
/*  957 */           break;
/*      */         default:
/*  959 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  964 */       this.optional_0_ = this_t0;
/*  965 */       return result;
/*      */     }
/*      */ 
/*      */     public BoolProto getDefaultInstanceForType()
/*      */     {
/*  970 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final BoolProto getDefaultInstance() {
/*  974 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/* 1013 */       if (this.uninterpreted == null) {
/* 1014 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/* 1016 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  978 */       IMMUTABLE_DEFAULT_INSTANCE = new BoolProto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.BoolProto clearValue()
/*      */         {
/*  986 */           return this;
/*      */         }
/*      */         public ApiBasePb.BoolProto setValue(boolean x) {
/*  989 */           ProtocolSupport.unsupportedOperation();
/*  990 */           return this;
/*      */         }
/*      */ 
/*      */         public ApiBasePb.BoolProto mergeFrom(ApiBasePb.BoolProto that) {
/*  994 */           ProtocolSupport.unsupportedOperation();
/*  995 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  998 */           ProtocolSupport.unsupportedOperation();
/*  999 */           return false;
/*      */         }
/*      */         public ApiBasePb.BoolProto freeze() {
/* 1002 */           return this;
/*      */         }
/*      */         public ApiBasePb.BoolProto unfreeze() {
/* 1005 */           ProtocolSupport.unsupportedOperation();
/* 1006 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/* 1009 */           return true;
/*      */         }
/*      */       };
/* 1021 */       text = new String[2];
/*      */ 
/* 1023 */       text[0] = "ErrorCode";
/* 1024 */       text[1] = "value";
/*      */ 
/* 1027 */       types = new int[2];
/*      */ 
/* 1029 */       Arrays.fill(types, 6);
/* 1030 */       types[0] = 0;
/* 1031 */       types[1] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  920 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.BoolProto.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("value", "value", 1, 0, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Integer64Proto extends ProtocolMessage<Integer64Proto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  550 */     private long value_ = 0L;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final Integer64Proto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kvalue = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final long getValue()
/*      */     {
/*  556 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/*  559 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public Integer64Proto clearValue() {
/*  562 */       this.optional_0_ &= -2;
/*  563 */       this.value_ = 0L;
/*  564 */       return this;
/*      */     }
/*      */     public Integer64Proto setValue(long x) {
/*  567 */       this.optional_0_ |= 1;
/*  568 */       this.value_ = x;
/*  569 */       return this;
/*      */     }
/*      */ 
/*      */     public Integer64Proto mergeFrom(Integer64Proto that)
/*      */     {
/*  576 */       assert (that != this);
/*  577 */       int this_t0 = this.optional_0_;
/*  578 */       int that_t0 = that.optional_0_;
/*      */ 
/*  580 */       if ((that_t0 & 0x1) != 0) {
/*  581 */         this_t0 |= 1;
/*  582 */         this.value_ = that.value_;
/*      */       }
/*      */ 
/*  585 */       if (that.uninterpreted != null) {
/*  586 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  588 */       this.optional_0_ = this_t0;
/*  589 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Integer64Proto that) {
/*  593 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Integer64Proto that) {
/*  597 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Integer64Proto that, boolean ignoreUninterpreted) {
/*  601 */       if (that == null) return false;
/*  602 */       if (that == this) return true;
/*  603 */       int this_t0 = this.optional_0_;
/*  604 */       int that_t0 = that.optional_0_;
/*  605 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  607 */       if (((this_t0 & 0x1) != 0) && 
/*  608 */         (this.value_ != that.value_)) return false;
/*      */ 
/*  611 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  616 */       return ((that instanceof Integer64Proto)) && (equals((Integer64Proto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  620 */       int hash = 868223442;
/*      */ 
/*  622 */       int this_t0 = this.optional_0_;
/*  623 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.value_) : -113);
/*  624 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  625 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  627 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  631 */       int this_t0 = this.optional_0_;
/*      */ 
/*  633 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  640 */       int n = 1 + Protocol.varLongSize(this.value_);
/*      */ 
/*  642 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  648 */       int n = 11;
/*      */ 
/*  650 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  655 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  659 */       this.optional_0_ = 0;
/*  660 */       this.value_ = 0L;
/*  661 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Integer64Proto newInstance() {
/*  665 */       return new Integer64Proto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  669 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  687 */       sink.putByte(8);
/*  688 */       sink.putVarLong(this.value_);
/*      */ 
/*  690 */       if (this.uninterpreted != null)
/*  691 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  696 */       boolean result = true;
/*  697 */       int this_t0 = this.optional_0_;
/*      */ 
/*  699 */       while (source.hasRemaining()) {
/*  700 */         int tt = source.getVarInt();
/*  701 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  705 */           result = false;
/*  706 */           break;
/*      */         case 8:
/*  709 */           this.value_ = source.getVarLong();
/*  710 */           this_t0 |= 1;
/*  711 */           break;
/*      */         default:
/*  713 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  718 */       this.optional_0_ = this_t0;
/*  719 */       return result;
/*      */     }
/*      */ 
/*      */     public Integer64Proto getDefaultInstanceForType()
/*      */     {
/*  724 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Integer64Proto getDefaultInstance() {
/*  728 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  767 */       if (this.uninterpreted == null) {
/*  768 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  770 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  732 */       IMMUTABLE_DEFAULT_INSTANCE = new Integer64Proto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.Integer64Proto clearValue()
/*      */         {
/*  740 */           return this;
/*      */         }
/*      */         public ApiBasePb.Integer64Proto setValue(long x) {
/*  743 */           ProtocolSupport.unsupportedOperation();
/*  744 */           return this;
/*      */         }
/*      */ 
/*      */         public ApiBasePb.Integer64Proto mergeFrom(ApiBasePb.Integer64Proto that) {
/*  748 */           ProtocolSupport.unsupportedOperation();
/*  749 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  752 */           ProtocolSupport.unsupportedOperation();
/*  753 */           return false;
/*      */         }
/*      */         public ApiBasePb.Integer64Proto freeze() {
/*  756 */           return this;
/*      */         }
/*      */         public ApiBasePb.Integer64Proto unfreeze() {
/*  759 */           ProtocolSupport.unsupportedOperation();
/*  760 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  763 */           return true;
/*      */         }
/*      */       };
/*  775 */       text = new String[2];
/*      */ 
/*  777 */       text[0] = "ErrorCode";
/*  778 */       text[1] = "value";
/*      */ 
/*  781 */       types = new int[2];
/*      */ 
/*  783 */       Arrays.fill(types, 6);
/*  784 */       types[0] = 0;
/*  785 */       types[1] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  673 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.Integer64Proto.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("value", "value", 1, 0, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Integer32Proto extends ProtocolMessage<Integer32Proto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  303 */     private int value_ = 0;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final Integer32Proto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kvalue = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final int getValue()
/*      */     {
/*  309 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/*  312 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public Integer32Proto clearValue() {
/*  315 */       this.optional_0_ &= -2;
/*  316 */       this.value_ = 0;
/*  317 */       return this;
/*      */     }
/*      */     public Integer32Proto setValue(int x) {
/*  320 */       this.optional_0_ |= 1;
/*  321 */       this.value_ = x;
/*  322 */       return this;
/*      */     }
/*      */ 
/*      */     public Integer32Proto mergeFrom(Integer32Proto that)
/*      */     {
/*  329 */       assert (that != this);
/*  330 */       int this_t0 = this.optional_0_;
/*  331 */       int that_t0 = that.optional_0_;
/*      */ 
/*  333 */       if ((that_t0 & 0x1) != 0) {
/*  334 */         this_t0 |= 1;
/*  335 */         this.value_ = that.value_;
/*      */       }
/*      */ 
/*  338 */       if (that.uninterpreted != null) {
/*  339 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*  341 */       this.optional_0_ = this_t0;
/*  342 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(Integer32Proto that) {
/*  346 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(Integer32Proto that) {
/*  350 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(Integer32Proto that, boolean ignoreUninterpreted) {
/*  354 */       if (that == null) return false;
/*  355 */       if (that == this) return true;
/*  356 */       int this_t0 = this.optional_0_;
/*  357 */       int that_t0 = that.optional_0_;
/*  358 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  360 */       if (((this_t0 & 0x1) != 0) && 
/*  361 */         (this.value_ != that.value_)) return false;
/*      */ 
/*  364 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  369 */       return ((that instanceof Integer32Proto)) && (equals((Integer32Proto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  373 */       int hash = 1078155998;
/*      */ 
/*  375 */       int this_t0 = this.optional_0_;
/*  376 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.value_ : -113);
/*  377 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  378 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  380 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  384 */       int this_t0 = this.optional_0_;
/*      */ 
/*  386 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  393 */       int n = 1 + Protocol.varLongSize(this.value_);
/*      */ 
/*  395 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  401 */       int n = 11;
/*      */ 
/*  403 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  408 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  412 */       this.optional_0_ = 0;
/*  413 */       this.value_ = 0;
/*  414 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public Integer32Proto newInstance() {
/*  418 */       return new Integer32Proto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  422 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  440 */       sink.putByte(8);
/*  441 */       sink.putVarLong(this.value_);
/*      */ 
/*  443 */       if (this.uninterpreted != null)
/*  444 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  449 */       boolean result = true;
/*  450 */       int this_t0 = this.optional_0_;
/*      */ 
/*  452 */       while (source.hasRemaining()) {
/*  453 */         int tt = source.getVarInt();
/*  454 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  458 */           result = false;
/*  459 */           break;
/*      */         case 8:
/*  462 */           this.value_ = source.getVarInt();
/*  463 */           this_t0 |= 1;
/*  464 */           break;
/*      */         default:
/*  466 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  471 */       this.optional_0_ = this_t0;
/*  472 */       return result;
/*      */     }
/*      */ 
/*      */     public Integer32Proto getDefaultInstanceForType()
/*      */     {
/*  477 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final Integer32Proto getDefaultInstance() {
/*  481 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public UninterpretedTags getUninterpretedForWrite()
/*      */     {
/*  520 */       if (this.uninterpreted == null) {
/*  521 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  523 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  485 */       IMMUTABLE_DEFAULT_INSTANCE = new Integer32Proto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.Integer32Proto clearValue()
/*      */         {
/*  493 */           return this;
/*      */         }
/*      */         public ApiBasePb.Integer32Proto setValue(int x) {
/*  496 */           ProtocolSupport.unsupportedOperation();
/*  497 */           return this;
/*      */         }
/*      */ 
/*      */         public ApiBasePb.Integer32Proto mergeFrom(ApiBasePb.Integer32Proto that) {
/*  501 */           ProtocolSupport.unsupportedOperation();
/*  502 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  505 */           ProtocolSupport.unsupportedOperation();
/*  506 */           return false;
/*      */         }
/*      */         public ApiBasePb.Integer32Proto freeze() {
/*  509 */           return this;
/*      */         }
/*      */         public ApiBasePb.Integer32Proto unfreeze() {
/*  512 */           ProtocolSupport.unsupportedOperation();
/*  513 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  516 */           return true;
/*      */         }
/*      */       };
/*  528 */       text = new String[2];
/*      */ 
/*  530 */       text[0] = "ErrorCode";
/*  531 */       text[1] = "value";
/*      */ 
/*  534 */       types = new int[2];
/*      */ 
/*  536 */       Arrays.fill(types, 6);
/*  537 */       types[0] = 0;
/*  538 */       types[1] = 0;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  426 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.Integer32Proto.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("value", "value", 1, 0, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class StringProto extends ProtocolMessage<StringProto>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*   25 */     private byte[] value_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*      */     private UninterpretedTags uninterpreted;
/*      */     private int optional_0_;
/*      */     public static final StringProto IMMUTABLE_DEFAULT_INSTANCE;
/*      */     public static final int kvalue = 1;
/*      */     public static final String[] text;
/*      */     public static final int[] types;
/*      */     public static final String style = "";
/*      */     public static final String style_content_type = "";
/*      */ 
/*      */     public final byte[] getValueAsBytes()
/*      */     {
/*   31 */       return this.value_;
/*      */     }
/*      */     public final boolean hasValue() {
/*   34 */       return (this.optional_0_ & 0x1) != 0;
/*      */     }
/*      */     public StringProto clearValue() {
/*   37 */       this.optional_0_ &= -2;
/*   38 */       this.value_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*   39 */       return this;
/*      */     }
/*      */     public StringProto setValueAsBytes(byte[] x) {
/*   42 */       this.optional_0_ |= 1;
/*   43 */       this.value_ = x;
/*   44 */       return this;
/*      */     }
/*      */     public final String getValue() {
/*   47 */       return ProtocolSupport.toStringUtf8(this.value_);
/*      */     }
/*      */     public StringProto setValue(String v) {
/*   50 */       if (v == null) throw new NullPointerException();
/*   51 */       this.optional_0_ |= 1;
/*   52 */       this.value_ = ProtocolSupport.toBytesUtf8(v);
/*   53 */       return this;
/*      */     }
/*      */     public final String getValue(Charset cs) {
/*   56 */       return ProtocolSupport.toString(this.value_, cs);
/*      */     }
/*      */     public StringProto setValue(String v, Charset cs) {
/*   59 */       if (v == null) throw new NullPointerException();
/*   60 */       this.optional_0_ |= 1;
/*   61 */       this.value_ = ProtocolSupport.toBytes(v, cs);
/*   62 */       return this;
/*      */     }
/*      */ 
/*      */     public StringProto mergeFrom(StringProto that)
/*      */     {
/*   69 */       assert (that != this);
/*   70 */       int this_t0 = this.optional_0_;
/*   71 */       int that_t0 = that.optional_0_;
/*      */ 
/*   73 */       if ((that_t0 & 0x1) != 0) {
/*   74 */         this_t0 |= 1;
/*   75 */         this.value_ = that.value_;
/*      */       }
/*      */ 
/*   78 */       if (that.uninterpreted != null) {
/*   79 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*      */       }
/*   81 */       this.optional_0_ = this_t0;
/*   82 */       return this;
/*      */     }
/*      */ 
/*      */     public boolean equalsIgnoreUninterpreted(StringProto that) {
/*   86 */       return equals(that, true);
/*      */     }
/*      */ 
/*      */     public boolean equals(StringProto that) {
/*   90 */       return equals(that, false);
/*      */     }
/*      */ 
/*      */     public boolean equals(StringProto that, boolean ignoreUninterpreted) {
/*   94 */       if (that == null) return false;
/*   95 */       if (that == this) return true;
/*   96 */       int this_t0 = this.optional_0_;
/*   97 */       int that_t0 = that.optional_0_;
/*   98 */       if (this_t0 != that_t0) return false;
/*      */ 
/*  100 */       if (((this_t0 & 0x1) != 0) && 
/*  101 */         (!Arrays.equals(this.value_, that.value_))) return false;
/*      */ 
/*  104 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*      */     }
/*      */ 
/*      */     public boolean equals(Object that)
/*      */     {
/*  109 */       return ((that instanceof StringProto)) && (equals((StringProto)that));
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  113 */       int hash = 1875365105;
/*      */ 
/*  115 */       int this_t0 = this.optional_0_;
/*  116 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.value_) : -113);
/*  117 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  118 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*      */       }
/*  120 */       return hash;
/*      */     }
/*      */ 
/*      */     public boolean isInitialized() {
/*  124 */       int this_t0 = this.optional_0_;
/*      */ 
/*  126 */       return (this_t0 & 0x1) == 1;
/*      */     }
/*      */ 
/*      */     public int encodingSize()
/*      */     {
/*  133 */       int n = 1 + Protocol.stringSize(this.value_.length);
/*      */ 
/*  135 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*      */     }
/*      */ 
/*      */     public int maxEncodingSize()
/*      */     {
/*  141 */       int n = 6 + this.value_.length;
/*      */ 
/*  143 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*      */     }
/*      */ 
/*      */     public MessageAppender getMessageAppender()
/*      */     {
/*  148 */       return getUninterpretedForWrite();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  152 */       this.optional_0_ = 0;
/*  153 */       this.value_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  154 */       this.uninterpreted = null;
/*      */     }
/*      */ 
/*      */     public StringProto newInstance() {
/*  158 */       return new StringProto();
/*      */     }
/*      */ 
/*      */     public ProtocolType getProtocolType() {
/*  162 */       return StaticHolder.protocolType;
/*      */     }
/*      */ 
/*      */     public void outputTo(ProtocolSink sink)
/*      */     {
/*  180 */       sink.putByte(10);
/*  181 */       sink.putPrefixedData(this.value_);
/*      */ 
/*  183 */       if (this.uninterpreted != null)
/*  184 */         this.uninterpreted.put(sink);
/*      */     }
/*      */ 
/*      */     public boolean merge(ProtocolSource source)
/*      */     {
/*  189 */       boolean result = true;
/*  190 */       int this_t0 = this.optional_0_;
/*      */ 
/*  192 */       while (source.hasRemaining()) {
/*  193 */         int tt = source.getVarInt();
/*  194 */         switch (tt)
/*      */         {
/*      */         case 0:
/*  198 */           result = false;
/*  199 */           break;
/*      */         case 10:
/*  202 */           this.value_ = source.getPrefixedData();
/*  203 */           this_t0 |= 1;
/*  204 */           break;
/*      */         default:
/*  206 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  211 */       this.optional_0_ = this_t0;
/*  212 */       return result;
/*      */     }
/*      */ 
/*      */     public StringProto getDefaultInstanceForType()
/*      */     {
/*  217 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public static final StringProto getDefaultInstance() {
/*  221 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     public StringProto freeze()
/*      */     {
/*  269 */       this.value_ = ProtocolSupport.freezeString(this.value_);
/*  270 */       return this;
/*      */     }
/*      */     public UninterpretedTags getUninterpretedForWrite() {
/*  273 */       if (this.uninterpreted == null) {
/*  274 */         this.uninterpreted = new UninterpretedTags();
/*      */       }
/*  276 */       return this.uninterpreted;
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  225 */       IMMUTABLE_DEFAULT_INSTANCE = new StringProto()
/*      */       {
/*      */         private static final long serialVersionUID = 1L;
/*      */ 
/*      */         public ApiBasePb.StringProto clearValue()
/*      */         {
/*  233 */           return this;
/*      */         }
/*      */         public ApiBasePb.StringProto setValueAsBytes(byte[] x) {
/*  236 */           ProtocolSupport.unsupportedOperation();
/*  237 */           return this;
/*      */         }
/*      */         public ApiBasePb.StringProto setValue(String v) {
/*  240 */           ProtocolSupport.unsupportedOperation();
/*  241 */           return this;
/*      */         }
/*      */         public ApiBasePb.StringProto setValue(String v, Charset cs) {
/*  244 */           ProtocolSupport.unsupportedOperation();
/*  245 */           return this;
/*      */         }
/*      */ 
/*      */         public ApiBasePb.StringProto mergeFrom(ApiBasePb.StringProto that) {
/*  249 */           ProtocolSupport.unsupportedOperation();
/*  250 */           return this;
/*      */         }
/*      */         public boolean merge(ProtocolSource source) {
/*  253 */           ProtocolSupport.unsupportedOperation();
/*  254 */           return false;
/*      */         }
/*      */         public ApiBasePb.StringProto freeze() {
/*  257 */           return this;
/*      */         }
/*      */         public ApiBasePb.StringProto unfreeze() {
/*  260 */           ProtocolSupport.unsupportedOperation();
/*  261 */           return this;
/*      */         }
/*      */         public boolean isFrozen() {
/*  264 */           return true;
/*      */         }
/*      */       };
/*  281 */       text = new String[2];
/*      */ 
/*  283 */       text[0] = "ErrorCode";
/*  284 */       text[1] = "value";
/*      */ 
/*  287 */       types = new int[2];
/*      */ 
/*  289 */       Arrays.fill(types, 6);
/*  290 */       types[0] = 0;
/*  291 */       types[1] = 2;
/*      */     }
/*      */ 
/*      */     private static class StaticHolder
/*      */     {
/*  166 */       private static final ProtocolType protocolType = new ProtocolType(ApiBasePb.StringProto.class, "Z\035apphosting/api/api_base.proto\n\033apphosting.base.StringProto\023\032\005value \001(\0020\t8\002\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("value", "value", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED) });
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.api.ApiBasePb
 * JD-Core Version:    0.6.0
 */