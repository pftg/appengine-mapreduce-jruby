/*    */ package com.google.appengine.api.capabilities;
/*    */ 
/*    */ public class CapabilitiesServiceFactory
/*    */ {
/*    */   public static CapabilitiesService getCapabilitiesService()
/*    */   {
/* 18 */     return new CapabilitiesServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.CapabilitiesServiceFactory
 * JD-Core Version:    0.6.0
 */