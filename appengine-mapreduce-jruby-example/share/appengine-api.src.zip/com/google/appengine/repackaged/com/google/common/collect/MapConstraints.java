/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.Beta;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @Beta
/*     */ @GwtCompatible
/*     */ public final class MapConstraints
/*     */ {
/*     */   public static MapConstraint<Object, Object> notNull()
/*     */   {
/*  53 */     return NotNullMapConstraint.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <K, V> Map<K, V> constrainedMap(Map<K, V> map, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/*  84 */     return new ConstrainedMap(map, constraint);
/*     */   }
/*     */ 
/*     */   public static <K, V> Multimap<K, V> constrainedMultimap(Multimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 105 */     return new ConstrainedMultimap(multimap, constraint);
/*     */   }
/*     */ 
/*     */   public static <K, V> ListMultimap<K, V> constrainedListMultimap(ListMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 127 */     return new ConstrainedListMultimap(multimap, constraint);
/*     */   }
/*     */ 
/*     */   public static <K, V> SetMultimap<K, V> constrainedSetMultimap(SetMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 148 */     return new ConstrainedSetMultimap(multimap, constraint);
/*     */   }
/*     */ 
/*     */   public static <K, V> SortedSetMultimap<K, V> constrainedSortedSetMultimap(SortedSetMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 169 */     return new ConstrainedSortedSetMultimap(multimap, constraint);
/*     */   }
/*     */ 
/*     */   private static <K, V> Map.Entry<K, V> constrainedEntry(Map.Entry<K, V> entry, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 184 */     Preconditions.checkNotNull(entry);
/* 185 */     Preconditions.checkNotNull(constraint);
/* 186 */     return new ForwardingMapEntry(entry, constraint) {
/*     */       protected Map.Entry<K, V> delegate() {
/* 188 */         return this.val$entry;
/*     */       }
/*     */       public V setValue(V value) {
/* 191 */         this.val$constraint.checkKeyValue(getKey(), value);
/* 192 */         return this.val$entry.setValue(value);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private static <K, V> Map.Entry<K, Collection<V>> constrainedAsMapEntry(Map.Entry<K, Collection<V>> entry, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 210 */     Preconditions.checkNotNull(entry);
/* 211 */     Preconditions.checkNotNull(constraint);
/* 212 */     return new ForwardingMapEntry(entry, constraint) {
/*     */       protected Map.Entry<K, Collection<V>> delegate() {
/* 214 */         return this.val$entry;
/*     */       }
/*     */       public Collection<V> getValue() {
/* 217 */         return Constraints.constrainedTypePreservingCollection((Collection)this.val$entry.getValue(), new Constraint()
/*     */         {
/*     */           public V checkElement(V value) {
/* 220 */             MapConstraints.2.this.val$constraint.checkKeyValue(MapConstraints.2.this.getKey(), value);
/* 221 */             return value;
/*     */           }
/*     */         });
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private static <K, V> Set<Map.Entry<K, Collection<V>>> constrainedAsMapEntries(Set<Map.Entry<K, Collection<V>>> entries, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 243 */     return new ConstrainedAsMapEntries(entries, constraint);
/*     */   }
/*     */ 
/*     */   private static <K, V> Collection<Map.Entry<K, V>> constrainedEntries(Collection<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 261 */     if ((entries instanceof Set)) {
/* 262 */       return constrainedEntrySet((Set)entries, constraint);
/*     */     }
/* 264 */     return new ConstrainedEntries(entries, constraint);
/*     */   }
/*     */ 
/*     */   private static <K, V> Set<Map.Entry<K, V>> constrainedEntrySet(Set<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 284 */     return new ConstrainedEntrySet(entries, constraint);
/*     */   }
/*     */ 
/*     */   public static <K, V> BiMap<K, V> constrainedBiMap(BiMap<K, V> map, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 331 */     return new ConstrainedBiMap(map, null, constraint);
/*     */   }
/*     */ 
/*     */   private static <K, V> Collection<V> checkValues(K key, Iterable<? extends V> values, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 758 */     Collection copy = Lists.newArrayList(values);
/* 759 */     for (Iterator i$ = copy.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 760 */       constraint.checkKeyValue(key, value);
/*     */     }
/* 762 */     return copy;
/*     */   }
/*     */ 
/*     */   private static <K, V> Map<K, V> checkMap(Map<? extends K, ? extends V> map, MapConstraint<? super K, ? super V> constraint)
/*     */   {
/* 767 */     Map copy = new LinkedHashMap(map);
/* 768 */     for (Map.Entry entry : copy.entrySet()) {
/* 769 */       constraint.checkKeyValue(entry.getKey(), entry.getValue());
/*     */     }
/* 771 */     return copy;
/*     */   }
/*     */ 
/*     */   private static class ConstrainedSortedSetMultimap<K, V> extends MapConstraints.ConstrainedSetMultimap<K, V>
/*     */     implements SortedSetMultimap<K, V>
/*     */   {
/*     */     ConstrainedSortedSetMultimap(SortedSetMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 738 */       super(constraint);
/*     */     }
/*     */     public SortedSet<V> get(K key) {
/* 741 */       return (SortedSet)super.get(key);
/*     */     }
/*     */     public SortedSet<V> removeAll(Object key) {
/* 744 */       return (SortedSet)super.removeAll(key);
/*     */     }
/*     */ 
/*     */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values) {
/* 748 */       return (SortedSet)super.replaceValues(key, values);
/*     */     }
/*     */     public Comparator<? super V> valueComparator() {
/* 751 */       return ((SortedSetMultimap)delegate()).valueComparator();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstrainedSetMultimap<K, V> extends MapConstraints.ConstrainedMultimap<K, V>
/*     */     implements SetMultimap<K, V>
/*     */   {
/*     */     ConstrainedSetMultimap(SetMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 717 */       super(constraint);
/*     */     }
/*     */     public Set<V> get(K key) {
/* 720 */       return (Set)super.get(key);
/*     */     }
/*     */     public Set<Map.Entry<K, V>> entries() {
/* 723 */       return (Set)super.entries();
/*     */     }
/*     */     public Set<V> removeAll(Object key) {
/* 726 */       return (Set)super.removeAll(key);
/*     */     }
/*     */ 
/*     */     public Set<V> replaceValues(K key, Iterable<? extends V> values) {
/* 730 */       return (Set)super.replaceValues(key, values);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstrainedListMultimap<K, V> extends MapConstraints.ConstrainedMultimap<K, V>
/*     */     implements ListMultimap<K, V>
/*     */   {
/*     */     ConstrainedListMultimap(ListMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 699 */       super(constraint);
/*     */     }
/*     */     public List<V> get(K key) {
/* 702 */       return (List)super.get(key);
/*     */     }
/*     */     public List<V> removeAll(Object key) {
/* 705 */       return (List)super.removeAll(key);
/*     */     }
/*     */ 
/*     */     public List<V> replaceValues(K key, Iterable<? extends V> values) {
/* 709 */       return (List)super.replaceValues(key, values);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ConstrainedAsMapEntries<K, V> extends ForwardingSet<Map.Entry<K, Collection<V>>>
/*     */   {
/*     */     private final MapConstraint<? super K, ? super V> constraint;
/*     */     private final Set<Map.Entry<K, Collection<V>>> entries;
/*     */ 
/*     */     ConstrainedAsMapEntries(Set<Map.Entry<K, Collection<V>>> entries, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 636 */       this.entries = entries;
/* 637 */       this.constraint = constraint;
/*     */     }
/*     */ 
/*     */     protected Set<Map.Entry<K, Collection<V>>> delegate() {
/* 641 */       return this.entries;
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, Collection<V>>> iterator() {
/* 645 */       Iterator iterator = this.entries.iterator();
/* 646 */       return new ForwardingIterator(iterator) {
/*     */         public Map.Entry<K, Collection<V>> next() {
/* 648 */           return MapConstraints.access$700((Map.Entry)this.val$iterator.next(), MapConstraints.ConstrainedAsMapEntries.this.constraint);
/*     */         }
/*     */         protected Iterator<Map.Entry<K, Collection<V>>> delegate() {
/* 651 */           return this.val$iterator;
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 659 */       return ObjectArrays.toArrayImpl(this);
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 663 */       return ObjectArrays.toArrayImpl(this, array);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 667 */       return Maps.containsEntryImpl(delegate(), o);
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection<?> c) {
/* 671 */       return Collections2.containsAll(this, c);
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object object) {
/* 675 */       return Collections2.setEquals(this, object);
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 679 */       return Sets.hashCodeImpl(this);
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 683 */       return Maps.removeEntryImpl(delegate(), o);
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> c) {
/* 687 */       return Iterators.removeAll(iterator(), c);
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> c) {
/* 691 */       return Iterators.retainAll(iterator(), c);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ConstrainedEntrySet<K, V> extends MapConstraints.ConstrainedEntries<K, V>
/*     */     implements Set<Map.Entry<K, V>>
/*     */   {
/*     */     ConstrainedEntrySet(Set<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 614 */       super(constraint);
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object object)
/*     */     {
/* 620 */       return Collections2.setEquals(this, object);
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 624 */       return Sets.hashCodeImpl(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstrainedEntries<K, V> extends ForwardingCollection<Map.Entry<K, V>>
/*     */   {
/*     */     final MapConstraint<? super K, ? super V> constraint;
/*     */     final Collection<Map.Entry<K, V>> entries;
/*     */ 
/*     */     ConstrainedEntries(Collection<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 565 */       this.entries = entries;
/* 566 */       this.constraint = constraint;
/*     */     }
/*     */     protected Collection<Map.Entry<K, V>> delegate() {
/* 569 */       return this.entries;
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, V>> iterator() {
/* 573 */       Iterator iterator = this.entries.iterator();
/* 574 */       return new ForwardingIterator(iterator) {
/*     */         public Map.Entry<K, V> next() {
/* 576 */           return MapConstraints.access$500((Map.Entry)this.val$iterator.next(), MapConstraints.ConstrainedEntries.this.constraint);
/*     */         }
/*     */         protected Iterator<Map.Entry<K, V>> delegate() {
/* 579 */           return this.val$iterator;
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 587 */       return ObjectArrays.toArrayImpl(this);
/*     */     }
/*     */     public <T> T[] toArray(T[] array) {
/* 590 */       return ObjectArrays.toArrayImpl(this, array);
/*     */     }
/*     */     public boolean contains(Object o) {
/* 593 */       return Maps.containsEntryImpl(delegate(), o);
/*     */     }
/*     */     public boolean containsAll(Collection<?> c) {
/* 596 */       return Collections2.containsAll(this, c);
/*     */     }
/*     */     public boolean remove(Object o) {
/* 599 */       return Maps.removeEntryImpl(delegate(), o);
/*     */     }
/*     */     public boolean removeAll(Collection<?> c) {
/* 602 */       return Iterators.removeAll(iterator(), c);
/*     */     }
/*     */     public boolean retainAll(Collection<?> c) {
/* 605 */       return Iterators.retainAll(iterator(), c);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstrainedAsMapValues<K, V> extends ForwardingCollection<Collection<V>>
/*     */   {
/*     */     final Collection<Collection<V>> delegate;
/*     */     final Set<Map.Entry<K, Collection<V>>> entrySet;
/*     */ 
/*     */     ConstrainedAsMapValues(Collection<Collection<V>> delegate, Set<Map.Entry<K, Collection<V>>> entrySet)
/*     */     {
/* 512 */       this.delegate = delegate;
/* 513 */       this.entrySet = entrySet;
/*     */     }
/*     */     protected Collection<Collection<V>> delegate() {
/* 516 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     public Iterator<Collection<V>> iterator() {
/* 520 */       Iterator iterator = this.entrySet.iterator();
/* 521 */       return new Iterator(iterator) {
/*     */         public boolean hasNext() {
/* 523 */           return this.val$iterator.hasNext();
/*     */         }
/*     */         public Collection<V> next() {
/* 526 */           return (Collection)((Map.Entry)this.val$iterator.next()).getValue();
/*     */         }
/*     */         public void remove() {
/* 529 */           this.val$iterator.remove();
/*     */         } } ;
/*     */     }
/*     */ 
/*     */     public Object[] toArray() {
/* 535 */       return ObjectArrays.toArrayImpl(this);
/*     */     }
/*     */     public <T> T[] toArray(T[] array) {
/* 538 */       return ObjectArrays.toArrayImpl(this, array);
/*     */     }
/*     */     public boolean contains(Object o) {
/* 541 */       return Iterators.contains(iterator(), o);
/*     */     }
/*     */     public boolean containsAll(Collection<?> c) {
/* 544 */       return Collections2.containsAll(this, c);
/*     */     }
/*     */     public boolean remove(Object o) {
/* 547 */       return Iterables.remove(this, o);
/*     */     }
/*     */     public boolean removeAll(Collection<?> c) {
/* 550 */       return Iterators.removeAll(iterator(), c);
/*     */     }
/*     */     public boolean retainAll(Collection<?> c) {
/* 553 */       return Iterators.retainAll(iterator(), c);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstrainedMultimap<K, V> extends ForwardingMultimap<K, V>
/*     */   {
/*     */     final MapConstraint<? super K, ? super V> constraint;
/*     */     final Multimap<K, V> delegate;
/*     */     transient Collection<Map.Entry<K, V>> entries;
/*     */     transient Map<K, Collection<V>> asMap;
/*     */ 
/*     */     public ConstrainedMultimap(Multimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 401 */       this.delegate = ((Multimap)Preconditions.checkNotNull(delegate));
/* 402 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/*     */     }
/*     */ 
/*     */     protected Multimap<K, V> delegate() {
/* 406 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     public Map<K, Collection<V>> asMap() {
/* 410 */       Map result = this.asMap;
/* 411 */       if (result == null) {
/* 412 */         Map asMapDelegate = this.delegate.asMap();
/*     */ 
/* 414 */         this.asMap = (result = new ForwardingMap(asMapDelegate) { Set<Map.Entry<K, Collection<V>>> entrySet;
/*     */           Collection<Collection<V>> values;
/*     */ 
/* 419 */           protected Map<K, Collection<V>> delegate() { return this.val$asMapDelegate; }
/*     */ 
/*     */           public Set<Map.Entry<K, Collection<V>>> entrySet()
/*     */           {
/* 423 */             Set result = this.entrySet;
/* 424 */             if (result == null) {
/* 425 */               this.entrySet = (result = MapConstraints.access$200(this.val$asMapDelegate.entrySet(), MapConstraints.ConstrainedMultimap.this.constraint));
/*     */             }
/*     */ 
/* 428 */             return result;
/*     */           }
/*     */ 
/*     */           public Collection<V> get(Object key)
/*     */           {
/*     */             try {
/* 434 */               Collection collection = MapConstraints.ConstrainedMultimap.this.get(key);
/* 435 */               return collection.isEmpty() ? null : collection; } catch (ClassCastException e) {
/*     */             }
/* 437 */             return null;
/*     */           }
/*     */ 
/*     */           public Collection<Collection<V>> values()
/*     */           {
/* 442 */             Collection result = this.values;
/* 443 */             if (result == null) {
/* 444 */               this.values = (result = new MapConstraints.ConstrainedAsMapValues(delegate().values(), entrySet()));
/*     */             }
/*     */ 
/* 447 */             return result;
/*     */           }
/*     */ 
/*     */           public boolean containsValue(Object o) {
/* 451 */             return values().contains(o);
/*     */           } } );
/*     */       }
/* 455 */       return result;
/*     */     }
/*     */ 
/*     */     public Collection<Map.Entry<K, V>> entries() {
/* 459 */       Collection result = this.entries;
/* 460 */       if (result == null) {
/* 461 */         this.entries = (result = MapConstraints.access$300(this.delegate.entries(), this.constraint));
/*     */       }
/* 463 */       return result;
/*     */     }
/*     */ 
/*     */     public Collection<V> get(K key) {
/* 467 */       return Constraints.constrainedTypePreservingCollection(this.delegate.get(key), new Constraint(key)
/*     */       {
/*     */         public V checkElement(V value) {
/* 470 */           MapConstraints.ConstrainedMultimap.this.constraint.checkKeyValue(this.val$key, value);
/* 471 */           return value;
/*     */         } } );
/*     */     }
/*     */ 
/*     */     public boolean put(K key, V value) {
/* 477 */       this.constraint.checkKeyValue(key, value);
/* 478 */       return this.delegate.put(key, value);
/*     */     }
/*     */ 
/*     */     public boolean putAll(K key, Iterable<? extends V> values) {
/* 482 */       return this.delegate.putAll(key, MapConstraints.access$400(key, values, this.constraint));
/*     */     }
/*     */ 
/*     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*     */     {
/* 487 */       boolean changed = false;
/* 488 */       for (Map.Entry entry : multimap.entries()) {
/* 489 */         changed |= put(entry.getKey(), entry.getValue());
/*     */       }
/* 491 */       return changed;
/*     */     }
/*     */ 
/*     */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*     */     {
/* 496 */       return this.delegate.replaceValues(key, MapConstraints.access$400(key, values, this.constraint));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InverseConstraint<K, V>
/*     */     implements MapConstraint<K, V>
/*     */   {
/*     */     final MapConstraint<? super V, ? super K> constraint;
/*     */ 
/*     */     public InverseConstraint(MapConstraint<? super V, ? super K> constraint)
/*     */     {
/* 384 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/*     */     }
/*     */     public void checkKeyValue(K key, V value) {
/* 387 */       this.constraint.checkKeyValue(value, key);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConstrainedBiMap<K, V> extends MapConstraints.ConstrainedMap<K, V>
/*     */     implements BiMap<K, V>
/*     */   {
/*     */     volatile transient BiMap<V, K> inverse;
/*     */ 
/*     */     ConstrainedBiMap(BiMap<K, V> delegate, @Nullable BiMap<V, K> inverse, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 353 */       super(constraint);
/* 354 */       this.inverse = inverse;
/*     */     }
/*     */ 
/*     */     protected BiMap<K, V> delegate() {
/* 358 */       return (BiMap)super.delegate();
/*     */     }
/*     */ 
/*     */     public V forcePut(K key, V value) {
/* 362 */       this.constraint.checkKeyValue(key, value);
/* 363 */       return delegate().forcePut(key, value);
/*     */     }
/*     */ 
/*     */     public BiMap<V, K> inverse() {
/* 367 */       if (this.inverse == null) {
/* 368 */         this.inverse = new ConstrainedBiMap(delegate().inverse(), this, new MapConstraints.InverseConstraint(this.constraint));
/*     */       }
/*     */ 
/* 371 */       return this.inverse;
/*     */     }
/*     */ 
/*     */     public Set<V> values() {
/* 375 */       return delegate().values();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ConstrainedMap<K, V> extends ForwardingMap<K, V>
/*     */   {
/*     */     private final Map<K, V> delegate;
/*     */     final MapConstraint<? super K, ? super V> constraint;
/*     */     private transient Set<Map.Entry<K, V>> entrySet;
/*     */ 
/*     */     ConstrainedMap(Map<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/*     */     {
/* 295 */       this.delegate = ((Map)Preconditions.checkNotNull(delegate));
/* 296 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/*     */     }
/*     */     protected Map<K, V> delegate() {
/* 299 */       return this.delegate;
/*     */     }
/*     */     public Set<Map.Entry<K, V>> entrySet() {
/* 302 */       Set result = this.entrySet;
/* 303 */       if (result == null) {
/* 304 */         this.entrySet = (result = MapConstraints.access$000(this.delegate.entrySet(), this.constraint));
/*     */       }
/*     */ 
/* 307 */       return result;
/*     */     }
/*     */     public V put(K key, V value) {
/* 310 */       this.constraint.checkKeyValue(key, value);
/* 311 */       return this.delegate.put(key, value);
/*     */     }
/*     */     public void putAll(Map<? extends K, ? extends V> map) {
/* 314 */       this.delegate.putAll(MapConstraints.access$100(map, this.constraint));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum NotNullMapConstraint
/*     */     implements MapConstraint<Object, Object>
/*     */   {
/*  58 */     INSTANCE;
/*     */ 
/*     */     public void checkKeyValue(Object key, Object value) {
/*  61 */       Preconditions.checkNotNull(key);
/*  62 */       Preconditions.checkNotNull(value);
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  66 */       return "Not null";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.MapConstraints
 * JD-Core Version:    0.6.0
 */