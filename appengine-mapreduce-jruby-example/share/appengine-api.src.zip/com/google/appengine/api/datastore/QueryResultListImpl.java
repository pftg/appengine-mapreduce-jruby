/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ class QueryResultListImpl<T>
/*     */   implements QueryResultList<T>
/*     */ {
/*     */   private final List<T> delegate;
/*     */   private final Cursor cursor;
/*     */ 
/*     */   public QueryResultListImpl(List<T> delegate, Cursor cursor)
/*     */   {
/*  22 */     this.delegate = delegate;
/*  23 */     this.cursor = cursor;
/*     */   }
/*     */ 
/*     */   public Cursor getCursor() {
/*  27 */     return this.cursor;
/*     */   }
/*     */ 
/*     */   public int size() {
/*  31 */     return this.delegate.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  35 */     return this.delegate.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean contains(Object o) {
/*  39 */     return this.delegate.contains(o);
/*     */   }
/*     */ 
/*     */   public Iterator<T> iterator() {
/*  43 */     return this.delegate.iterator();
/*     */   }
/*     */ 
/*     */   public Object[] toArray() {
/*  47 */     return this.delegate.toArray();
/*     */   }
/*     */ 
/*     */   public <T> T[] toArray(T[] ts) {
/*  51 */     return this.delegate.toArray(ts);
/*     */   }
/*     */ 
/*     */   public boolean add(T t) {
/*  55 */     return this.delegate.add(t);
/*     */   }
/*     */ 
/*     */   public boolean remove(Object o) {
/*  59 */     return this.delegate.remove(o);
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection<?> objects) {
/*  63 */     return this.delegate.containsAll(objects);
/*     */   }
/*     */ 
/*     */   public boolean addAll(Collection<? extends T> ts) {
/*  67 */     return this.delegate.addAll(ts);
/*     */   }
/*     */ 
/*     */   public boolean addAll(int i, Collection<? extends T> ts) {
/*  71 */     return this.delegate.addAll(i, ts);
/*     */   }
/*     */ 
/*     */   public boolean removeAll(Collection<?> objects) {
/*  75 */     return this.delegate.removeAll(objects);
/*     */   }
/*     */ 
/*     */   public boolean retainAll(Collection<?> objects) {
/*  79 */     return this.delegate.retainAll(objects);
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  83 */     this.delegate.clear();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  88 */     return this.delegate.equals(o);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  93 */     return this.delegate.hashCode();
/*     */   }
/*     */ 
/*     */   public T get(int i) {
/*  97 */     return this.delegate.get(i);
/*     */   }
/*     */ 
/*     */   public T set(int i, T t) {
/* 101 */     return this.delegate.set(i, t);
/*     */   }
/*     */ 
/*     */   public void add(int i, T t) {
/* 105 */     this.delegate.add(i, t);
/*     */   }
/*     */ 
/*     */   public T remove(int i) {
/* 109 */     return this.delegate.remove(i);
/*     */   }
/*     */ 
/*     */   public int indexOf(Object o) {
/* 113 */     return this.delegate.indexOf(o);
/*     */   }
/*     */ 
/*     */   public int lastIndexOf(Object o) {
/* 117 */     return this.delegate.lastIndexOf(o);
/*     */   }
/*     */ 
/*     */   public ListIterator<T> listIterator() {
/* 121 */     return this.delegate.listIterator();
/*     */   }
/*     */ 
/*     */   public ListIterator<T> listIterator(int i) {
/* 125 */     return this.delegate.listIterator(i);
/*     */   }
/*     */ 
/*     */   public List<T> subList(int i, int i1) {
/* 129 */     return this.delegate.subList(i, i1);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryResultListImpl
 * JD-Core Version:    0.6.0
 */