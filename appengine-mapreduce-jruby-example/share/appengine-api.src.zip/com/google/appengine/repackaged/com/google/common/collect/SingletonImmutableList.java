/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ final class SingletonImmutableList<E> extends ImmutableList<E>
/*     */ {
/*     */   final transient E element;
/*     */ 
/*     */   SingletonImmutableList(E element)
/*     */   {
/*  42 */     this.element = Preconditions.checkNotNull(element);
/*     */   }
/*     */ 
/*     */   public E get(int index) {
/*  46 */     Preconditions.checkElementIndex(index, 1);
/*  47 */     return this.element;
/*     */   }
/*     */ 
/*     */   public int indexOf(@Nullable Object object) {
/*  51 */     return this.element.equals(object) ? 0 : -1;
/*     */   }
/*     */ 
/*     */   public UnmodifiableIterator<E> iterator() {
/*  55 */     return Iterators.singletonIterator(this.element);
/*     */   }
/*     */ 
/*     */   public int lastIndexOf(@Nullable Object object) {
/*  59 */     return this.element.equals(object) ? 0 : -1;
/*     */   }
/*     */ 
/*     */   public ListIterator<E> listIterator() {
/*  63 */     return listIterator(0);
/*     */   }
/*     */ 
/*     */   public ListIterator<E> listIterator(int start)
/*     */   {
/*  68 */     return Collections.singletonList(this.element).listIterator(start);
/*     */   }
/*     */ 
/*     */   public int size() {
/*  72 */     return 1;
/*     */   }
/*     */ 
/*     */   public ImmutableList<E> subList(int fromIndex, int toIndex) {
/*  76 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, 1);
/*  77 */     return fromIndex == toIndex ? ImmutableList.of() : this;
/*     */   }
/*     */ 
/*     */   public boolean contains(@Nullable Object object) {
/*  81 */     return this.element.equals(object);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/*  85 */     if (object == this) {
/*  86 */       return true;
/*     */     }
/*  88 */     if ((object instanceof List)) {
/*  89 */       List that = (List)object;
/*  90 */       return (that.size() == 1) && (this.element.equals(that.get(0)));
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  98 */     return 31 + this.element.hashCode();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   public Object[] toArray() {
/* 106 */     return new Object[] { this.element };
/*     */   }
/*     */ 
/*     */   public <T> T[] toArray(T[] array) {
/* 110 */     if (array.length == 0)
/* 111 */       array = ObjectArrays.newArray(array, 1);
/* 112 */     else if (array.length > 1) {
/* 113 */       array[1] = null;
/*     */     }
/*     */ 
/* 116 */     Object[] objectArray = array;
/* 117 */     objectArray[0] = this.element;
/* 118 */     return array;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.SingletonImmutableList
 * JD-Core Version:    0.6.0
 */