/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class Defaults
/*    */ {
/* 28 */   private static final Map<Class<?>, Object> DEFAULTS = new HashMap(16);
/*    */ 
/*    */   private static <T> void put(Class<T> type, T value) {
/* 31 */     DEFAULTS.put(type, value);
/*    */   }
/*    */ 
/*    */   public static <T> T defaultValue(Class<T> type)
/*    */   {
/* 52 */     return DEFAULTS.get(type);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 35 */     put(Boolean.TYPE, Boolean.valueOf(false));
/* 36 */     put(Character.TYPE, Character.valueOf('\000'));
/* 37 */     put(Byte.TYPE, Byte.valueOf(0));
/* 38 */     put(Short.TYPE, Short.valueOf(0));
/* 39 */     put(Integer.TYPE, Integer.valueOf(0));
/* 40 */     put(Long.TYPE, Long.valueOf(0L));
/* 41 */     put(Float.TYPE, Float.valueOf(0.0F));
/* 42 */     put(Double.TYPE, Double.valueOf(0.0D));
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Defaults
 * JD-Core Version:    0.6.0
 */