/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ public final class Charsets
/*    */ {
/* 33 */   public static final Charset US_ASCII = Charset.forName("US-ASCII");
/*    */ 
/* 38 */   public static final Charset ISO_8859_1 = Charset.forName("ISO-8859-1");
/*    */ 
/* 43 */   public static final Charset UTF_8 = Charset.forName("UTF-8");
/*    */ 
/* 48 */   public static final Charset UTF_16BE = Charset.forName("UTF-16BE");
/*    */ 
/* 53 */   public static final Charset UTF_16LE = Charset.forName("UTF-16LE");
/*    */ 
/* 59 */   public static final Charset UTF_16 = Charset.forName("UTF-16");
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Charsets
 * JD-Core Version:    0.6.0
 */