/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public abstract class RangeFactory<C extends Comparable<?>, I extends Range<C>>
/*     */ {
/*     */   abstract I create(Cut<C> paramCut1, Cut<C> paramCut2);
/*     */ 
/*     */   public I open(C lower, C upper)
/*     */   {
/*  52 */     return create(new Cut.AboveValue(lower), new Cut.BelowValue(upper));
/*     */   }
/*     */ 
/*     */   public I closed(C lower, C upper)
/*     */   {
/*  65 */     return create(new Cut.BelowValue(lower), new Cut.AboveValue(upper));
/*     */   }
/*     */ 
/*     */   public I closedOpen(C lower, C upper)
/*     */   {
/*  78 */     return create(new Cut.BelowValue(lower), new Cut.BelowValue(upper));
/*     */   }
/*     */ 
/*     */   public I openClosed(C lower, C upper)
/*     */   {
/*  91 */     return create(new Cut.AboveValue(lower), new Cut.AboveValue(upper));
/*     */   }
/*     */ 
/*     */   public I range(C lowerEndpoint, Range.BoundType lowerType, C upperEndpoint, Range.BoundType upperType)
/*     */   {
/* 106 */     Preconditions.checkNotNull(lowerType);
/* 107 */     Preconditions.checkNotNull(upperType);
/*     */ 
/* 109 */     Cut lowerBound = lowerType == Range.BoundType.OPEN ? new Cut.AboveValue(lowerEndpoint) : new Cut.BelowValue(lowerEndpoint);
/*     */ 
/* 112 */     Cut upperBound = upperType == Range.BoundType.OPEN ? new Cut.BelowValue(upperEndpoint) : new Cut.AboveValue(upperEndpoint);
/*     */ 
/* 115 */     return create(lowerBound, upperBound);
/*     */   }
/*     */ 
/*     */   public I lessThan(C endpoint)
/*     */   {
/* 123 */     return create(noLowerBound(), new Cut.BelowValue(endpoint));
/*     */   }
/*     */ 
/*     */   public I atMost(C endpoint)
/*     */   {
/* 131 */     return create(noLowerBound(), new Cut.AboveValue(endpoint));
/*     */   }
/*     */ 
/*     */   public I greaterThan(C endpoint)
/*     */   {
/* 139 */     return create(new Cut.AboveValue(endpoint), noUpperBound());
/*     */   }
/*     */ 
/*     */   public I atLeast(C endpoint)
/*     */   {
/* 147 */     return create(new Cut.BelowValue(endpoint), noUpperBound());
/*     */   }
/*     */ 
/*     */   public I all()
/*     */   {
/* 154 */     return create(noLowerBound(), noUpperBound());
/*     */   }
/*     */ 
/*     */   private Cut<C> noLowerBound()
/*     */   {
/* 159 */     return Cut.BELOW_ALL;
/*     */   }
/*     */ 
/*     */   private Cut<C> noUpperBound()
/*     */   {
/* 164 */     return Cut.ABOVE_ALL;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.RangeFactory
 * JD-Core Version:    0.6.0
 */