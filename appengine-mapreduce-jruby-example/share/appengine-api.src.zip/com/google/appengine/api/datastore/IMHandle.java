/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ public final class IMHandle
/*     */   implements Serializable, Comparable<IMHandle>
/*     */ {
/*     */   public static final long serialVersionUID = 6963426833434504530L;
/*     */   private String protocol;
/*     */   private String address;
/*     */ 
/*     */   public IMHandle(Scheme scheme, String address)
/*     */   {
/*  35 */     if (scheme == null) {
/*  36 */       throw new NullPointerException("scheme must not be null");
/*     */     }
/*  38 */     validateAddress(address);
/*  39 */     this.protocol = scheme.name();
/*  40 */     this.address = address;
/*     */   }
/*     */ 
/*     */   public IMHandle(URL network, String address) {
/*  44 */     if (network == null) {
/*  45 */       throw new NullPointerException("network must not be null");
/*     */     }
/*  47 */     validateAddress(address);
/*  48 */     this.protocol = network.toString();
/*  49 */     this.address = address;
/*     */   }
/*     */ 
/*     */   private IMHandle()
/*     */   {
/*  59 */     this.protocol = null;
/*  60 */     this.address = null;
/*     */   }
/*     */ 
/*     */   static IMHandle fromDatastoreString(String datastoreString)
/*     */   {
/*  72 */     if (datastoreString == null) {
/*  73 */       throw new NullPointerException("datastoreString must not be null");
/*     */     }
/*  75 */     String[] split = datastoreString.split(" ");
/*  76 */     if (split.length != 2) {
/*  77 */       throw new IllegalArgumentException("Datastore string must have exactly one space: " + datastoreString);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  82 */       return new IMHandle(Scheme.valueOf(split[0]), split[1]);
/*     */     } catch (IllegalArgumentException iae) {
/*     */       try {
/*  85 */         return new IMHandle(new URL(split[0]), split[1]); } catch (MalformedURLException e) {
/*     */       }
/*     */     }
/*  87 */     throw new IllegalArgumentException("String in datastore could not be parsed into a valid IMHandle.  Protocol must either be a valid scheme or url: " + split[0]);
/*     */   }
/*     */ 
/*     */   private static void validateAddress(String address)
/*     */   {
/*  95 */     if (address == null)
/*  96 */       throw new NullPointerException("address must not be null");
/*     */   }
/*     */ 
/*     */   String toDatastoreString()
/*     */   {
/* 105 */     return String.format("%s %s", new Object[] { this.protocol, this.address });
/*     */   }
/*     */ 
/*     */   public String getProtocol() {
/* 109 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public String getAddress() {
/* 113 */     return this.address;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 118 */     if (this == o) {
/* 119 */       return true;
/*     */     }
/* 121 */     if ((o == null) || (getClass() != o.getClass())) {
/* 122 */       return false;
/*     */     }
/*     */ 
/* 125 */     IMHandle imHandle = (IMHandle)o;
/*     */ 
/* 127 */     if (!this.address.equals(imHandle.address)) {
/* 128 */       return false;
/*     */     }
/*     */ 
/* 131 */     return this.protocol.equals(imHandle.protocol);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 140 */     int result = this.protocol.hashCode();
/* 141 */     result = 31 * result + this.address.hashCode();
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */   public int compareTo(IMHandle o)
/*     */   {
/* 149 */     return toDatastoreString().compareTo(o.toDatastoreString());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 154 */     return toDatastoreString();
/*     */   }
/*     */ 
/*     */   public static enum Scheme
/*     */   {
/*  27 */     sip, unknown, xmpp;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.IMHandle
 * JD-Core Version:    0.6.0
 */