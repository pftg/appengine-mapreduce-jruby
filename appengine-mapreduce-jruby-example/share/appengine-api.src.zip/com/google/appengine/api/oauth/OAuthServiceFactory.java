/*    */ package com.google.appengine.api.oauth;
/*    */ 
/*    */ public final class OAuthServiceFactory
/*    */ {
/*    */   public static OAuthService getOAuthService()
/*    */   {
/* 15 */     return new OAuthServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.oauth.OAuthServiceFactory
 * JD-Core Version:    0.6.0
 */