/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class LogAndContinueErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/*    */   private final Level level;
/*    */   private final Logger logger;
/*    */ 
/*    */   public LogAndContinueErrorHandler(Level level)
/*    */   {
/* 25 */     this.level = level;
/* 26 */     this.logger = Logger.getLogger(LogAndContinueErrorHandler.class.getName());
/*    */   }
/*    */ 
/*    */   public void handleDeserializationError(InvalidValueException thrown)
/*    */   {
/* 36 */     this.logger.log(this.level, "Deserialization error in memcache", thrown);
/*    */   }
/*    */ 
/*    */   public void handleServiceError(MemcacheServiceException thrown)
/*    */   {
/* 46 */     this.logger.log(this.level, "Service error in memcache", thrown);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.LogAndContinueErrorHandler
 * JD-Core Version:    0.6.0
 */