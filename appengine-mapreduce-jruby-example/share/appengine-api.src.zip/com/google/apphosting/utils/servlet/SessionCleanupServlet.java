/*    */ package com.google.apphosting.utils.servlet;
/*    */ 
/*    */ import com.google.appengine.api.datastore.DatastoreService;
/*    */ import com.google.appengine.api.datastore.DatastoreServiceFactory;
/*    */ import com.google.appengine.api.datastore.Entity;
/*    */ import com.google.appengine.api.datastore.FetchOptions.Builder;
/*    */ import com.google.appengine.api.datastore.Key;
/*    */ import com.google.appengine.api.datastore.PreparedQuery;
/*    */ import com.google.appengine.api.datastore.Query;
/*    */ import com.google.appengine.api.datastore.Query.FilterOperator;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.ArrayList;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class SessionCleanupServlet extends HttpServlet
/*    */ {
/*    */   static final String SESSION_ENTITY_TYPE = "_ah_SESSION";
/*    */   static final String EXPIRES_PROP = "_expires";
/*    */   static final int MAX_SESSION_COUNT = 100;
/*    */   private DatastoreService datastore;
/*    */ 
/*    */   public void init()
/*    */   {
/* 41 */     this.datastore = DatastoreServiceFactory.getDatastoreService();
/*    */   }
/*    */ 
/*    */   public void service(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 46 */     if ("clear".equals(request.getQueryString()))
/* 47 */       clearAll(response);
/*    */     else
/* 49 */       sendForm(request.getRequestURI() + "?clear", response);
/*    */   }
/*    */ 
/*    */   private void clearAll(HttpServletResponse response)
/*    */   {
/* 54 */     Query query = new Query("_ah_SESSION");
/* 55 */     query.setKeysOnly();
/* 56 */     query.addFilter("_expires", Query.FilterOperator.LESS_THAN, Long.valueOf(System.currentTimeMillis()));
/*    */ 
/* 58 */     ArrayList killList = new ArrayList();
/* 59 */     Iterable entities = this.datastore.prepare(query).asIterable(FetchOptions.Builder.withLimit(100));
/*    */ 
/* 61 */     for (Entity expiredSession : entities) {
/* 62 */       Key key = expiredSession.getKey();
/* 63 */       killList.add(key);
/*    */     }
/* 65 */     this.datastore.delete(killList);
/* 66 */     response.setStatus(200);
/*    */     try {
/* 68 */       response.getWriter().println("Cleared " + killList.size() + " expired sessions.");
/*    */     }
/*    */     catch (IOException ex) {
/*    */     }
/*    */   }
/*    */ 
/*    */   private void sendForm(String actionUrl, HttpServletResponse response) {
/* 75 */     Query query = new Query("_ah_SESSION");
/* 76 */     query.setKeysOnly();
/* 77 */     query.addFilter("_expires", Query.FilterOperator.LESS_THAN, Long.valueOf(System.currentTimeMillis()));
/*    */ 
/* 79 */     int count = this.datastore.prepare(query).countEntities();
/*    */ 
/* 81 */     response.setContentType("text/html");
/* 82 */     response.setCharacterEncoding("utf-8");
/*    */     try {
/* 84 */       PrintWriter writer = response.getWriter();
/* 85 */       writer.println("<html><head><title>Session Cleanup</title></head>");
/* 86 */       writer.println("<body>There are currently " + count + " expired sessions.");
/* 87 */       writer.println("<p><form method=\"POST\" action=\"" + actionUrl + "\">");
/* 88 */       writer.println("<input type=\"submit\" value=\"Delete Next 100\" >");
/* 89 */       writer.println("</form></body></html>");
/*    */     } catch (IOException ex) {
/* 91 */       response.setStatus(500);
/*    */       try {
/* 93 */         response.getWriter().println(ex);
/*    */       }
/*    */       catch (IOException innerEx) {
/*    */       }
/*    */     }
/* 98 */     response.setStatus(200);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.utils.servlet.SessionCleanupServlet
 * JD-Core Version:    0.6.0
 */