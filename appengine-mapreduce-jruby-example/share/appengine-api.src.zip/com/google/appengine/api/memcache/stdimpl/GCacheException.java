/*    */ package com.google.appengine.api.memcache.stdimpl;
/*    */ 
/*    */ public class GCacheException extends RuntimeException
/*    */ {
/*    */   public GCacheException(String message, Throwable ex)
/*    */   {
/* 12 */     super(message, ex);
/*    */   }
/*    */   public GCacheException(String message) {
/* 15 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.stdimpl.GCacheException
 * JD-Core Version:    0.6.0
 */