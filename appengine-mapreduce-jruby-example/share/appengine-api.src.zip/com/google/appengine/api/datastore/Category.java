/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class Category
/*    */   implements Serializable, Comparable<Category>
/*    */ {
/*    */   public static final long serialVersionUID = 8556134984576082397L;
/*    */   private String category;
/*    */ 
/*    */   public Category(String category)
/*    */   {
/* 37 */     if (category == null) {
/* 38 */       throw new NullPointerException("category must not be null");
/*    */     }
/* 40 */     this.category = category;
/*    */   }
/*    */ 
/*    */   private Category()
/*    */   {
/* 50 */     this.category = null;
/*    */   }
/*    */ 
/*    */   public String getCategory() {
/* 54 */     return this.category;
/*    */   }
/*    */ 
/*    */   public int compareTo(Category o) {
/* 58 */     return this.category.compareTo(o.category);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 63 */     if (this == o) {
/* 64 */       return true;
/*    */     }
/* 66 */     if ((o == null) || (getClass() != o.getClass())) {
/* 67 */       return false;
/*    */     }
/*    */ 
/* 70 */     Category category1 = (Category)o;
/*    */ 
/* 73 */     return this.category.equals(category1.category);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 81 */     return this.category.hashCode();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Category
 * JD-Core Version:    0.6.0
 */