/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public final class ShortBlob
/*    */   implements Serializable, Comparable<ShortBlob>
/*    */ {
/*    */   public static final long serialVersionUID = -3427166602866836472L;
/*    */   private byte[] bytes;
/*    */ 
/*    */   private ShortBlob()
/*    */   {
/* 33 */     this.bytes = null;
/*    */   }
/*    */ 
/*    */   public ShortBlob(byte[] bytes)
/*    */   {
/* 45 */     this.bytes = new byte[bytes.length];
/* 46 */     System.arraycopy(bytes, 0, this.bytes, 0, bytes.length);
/*    */   }
/*    */ 
/*    */   public byte[] getBytes()
/*    */   {
/* 53 */     return this.bytes;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 58 */     return Arrays.hashCode(this.bytes);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 67 */     if ((object instanceof ShortBlob)) {
/* 68 */       ShortBlob other = (ShortBlob)object;
/* 69 */       return Arrays.equals(this.bytes, other.bytes);
/*    */     }
/* 71 */     return false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 81 */     return "<ShortBlob: " + this.bytes.length + " bytes>";
/*    */   }
/*    */ 
/*    */   public int compareTo(ShortBlob other) {
/* 85 */     DataTypeTranslator.ComparableByteArray cba1 = new DataTypeTranslator.ComparableByteArray(this.bytes);
/* 86 */     DataTypeTranslator.ComparableByteArray cba2 = new DataTypeTranslator.ComparableByteArray(other.bytes);
/*    */ 
/* 88 */     return cba1.compareTo(cba2);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.ShortBlob
 * JD-Core Version:    0.6.0
 */