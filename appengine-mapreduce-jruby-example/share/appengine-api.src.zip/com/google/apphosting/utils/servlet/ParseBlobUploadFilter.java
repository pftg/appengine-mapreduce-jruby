/*     */ package com.google.apphosting.utils.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ 
/*     */ public class ParseBlobUploadFilter
/*     */   implements Filter
/*     */ {
/*  44 */   private static final Logger logger = Logger.getLogger(ParseBlobUploadFilter.class.getName());
/*     */   static final String UPLOAD_HEADER = "X-AppEngine-BlobUpload";
/*     */   static final String UPLOADED_BLOBKEY_ATTR = "com.google.appengine.api.blobstore.upload.blobkeys";
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  63 */     HttpServletRequest req = (HttpServletRequest)request;
/*  64 */     if (req.getHeader("X-AppEngine-BlobUpload") != null) {
/*  65 */       Map blobKeys = new HashMap();
/*  66 */       Map otherParams = new HashMap();
/*     */       try
/*     */       {
/*  69 */         MimeMultipart multipart = MultipartMimeUtils.parseMultipartRequest(req);
/*     */ 
/*  71 */         int parts = multipart.getCount();
/*  72 */         for (int i = 0; i < parts; i++) {
/*  73 */           BodyPart part = multipart.getBodyPart(i);
/*  74 */           if (part.getFileName() != null) {
/*  75 */             ContentType contentType = new ContentType(part.getContentType());
/*  76 */             if ("message/external-body".equals(contentType.getBaseType())) {
/*  77 */               String blobKeyString = contentType.getParameter("blob-key");
/*  78 */               blobKeys.put(MultipartMimeUtils.getFieldName(part), blobKeyString);
/*     */             }
/*     */           } else {
/*  81 */             String fieldName = MultipartMimeUtils.getFieldName(part);
/*  82 */             List values = (List)otherParams.get(fieldName);
/*  83 */             if (values == null) {
/*  84 */               values = new ArrayList();
/*  85 */               otherParams.put(fieldName, values);
/*     */             }
/*  87 */             values.add(MultipartMimeUtils.getTextContent(part));
/*     */           }
/*     */         }
/*  90 */         req.setAttribute("com.google.appengine.api.blobstore.upload.blobkeys", blobKeys);
/*     */       } catch (MessagingException ex) {
/*  92 */         logger.log(Level.WARNING, "Could not parse multipart message:", ex);
/*     */       }
/*     */ 
/*  95 */       chain.doFilter(new ParameterServletWrapper(request, otherParams), response);
/*     */     } else {
/*  97 */       chain.doFilter(request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ParameterServletWrapper extends HttpServletRequestWrapper {
/*     */     private final Map<String, List<String>> otherParams;
/*     */ 
/*     */     ParameterServletWrapper(ServletRequest request, Map<String, List<String>> otherParams) {
/* 105 */       super();
/* 106 */       this.otherParams = otherParams;
/*     */     }
/*     */ 
/*     */     public Map getParameterMap()
/*     */     {
/* 113 */       Map map = super.getParameterMap();
/* 114 */       for (Map.Entry entry : this.otherParams.entrySet()) {
/* 115 */         map.put(entry.getKey(), ((List)entry.getValue()).toArray(new String[0]));
/*     */       }
/* 117 */       return map;
/*     */     }
/*     */ 
/*     */     public Enumeration getParameterNames()
/*     */     {
/* 123 */       List allNames = new ArrayList();
/*     */ 
/* 126 */       Enumeration names = super.getParameterNames();
/* 127 */       while (names.hasMoreElements()) {
/* 128 */         allNames.add(names.nextElement());
/*     */       }
/* 130 */       allNames.addAll(this.otherParams.keySet());
/* 131 */       return Collections.enumeration(allNames);
/*     */     }
/*     */ 
/*     */     public String[] getParameterValues(String name)
/*     */     {
/* 136 */       if (this.otherParams.containsKey(name)) {
/* 137 */         return (String[])((List)this.otherParams.get(name)).toArray(new String[0]);
/*     */       }
/* 139 */       return super.getParameterValues(name);
/*     */     }
/*     */ 
/*     */     public String getParameter(String name)
/*     */     {
/* 145 */       if (this.otherParams.containsKey(name)) {
/* 146 */         return (String)((List)this.otherParams.get(name)).get(0);
/*     */       }
/* 148 */       return super.getParameter(name);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.utils.servlet.ParseBlobUploadFilter
 * JD-Core Version:    0.6.0
 */