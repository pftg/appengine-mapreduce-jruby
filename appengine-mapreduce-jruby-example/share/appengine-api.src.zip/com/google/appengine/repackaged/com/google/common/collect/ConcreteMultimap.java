/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Objects;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ public class ConcreteMultimap<K, V, C extends Collection<V>>
/*     */   implements Multimap<K, V>, Serializable
/*     */ {
/*     */   private final Map<K, C> map;
/*     */   private final Supplier<? extends C> factory;
/*     */   private transient Set<K> keySet;
/*     */   private transient Multiset<K> keys;
/*     */   private transient Collection<V> valuesCollection;
/*     */   private transient Collection<Map.Entry<K, V>> entries;
/*     */   private transient Map<K, Collection<V>> asMap;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V, C extends Collection<V>> ConcreteMultimap<K, V, C> create(Map<K, C> map, Supplier<? extends C> factory)
/*     */   {
/* 137 */     Preconditions.checkArgument(map.isEmpty());
/* 138 */     return new ConcreteMultimap(map, (Supplier)Preconditions.checkNotNull(factory));
/*     */   }
/*     */ 
/*     */   private ConcreteMultimap(Map<K, C> map, Supplier<? extends C> factory)
/*     */   {
/* 145 */     this.map = map;
/* 146 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 152 */     int size = 0;
/* 153 */     for (Collection collection : this.map.values()) {
/* 154 */       size += collection.size();
/*     */     }
/* 156 */     return size;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 160 */     for (Collection collection : this.map.values()) {
/* 161 */       if (!collection.isEmpty()) {
/* 162 */         return false;
/*     */       }
/*     */     }
/* 165 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(@Nullable Object key) {
/* 169 */     Collection collection = (Collection)this.map.get(key);
/* 170 */     return (collection != null) && (!collection.isEmpty());
/*     */   }
/*     */ 
/*     */   public boolean containsValue(@Nullable Object value) {
/* 174 */     for (Collection collection : this.map.values()) {
/* 175 */       if (collection.contains(value)) {
/* 176 */         return true;
/*     */       }
/*     */     }
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean containsEntry(@Nullable Object key, @Nullable Object value) {
/* 183 */     Collection collection = (Collection)this.map.get(key);
/* 184 */     return (collection != null) && (collection.contains(value));
/*     */   }
/*     */ 
/*     */   public boolean put(K key, V value)
/*     */   {
/* 190 */     Collection collection = get(key);
/* 191 */     return collection.add(value);
/*     */   }
/*     */ 
/*     */   public boolean remove(@Nullable Object key, @Nullable Object value) {
/* 195 */     Collection collection = (Collection)this.map.get(key);
/* 196 */     return (collection != null) && (collection.remove(value));
/*     */   }
/*     */ 
/*     */   public boolean putAll(K key, Iterable<? extends V> values)
/*     */   {
/* 202 */     Collection collection = get(key);
/* 203 */     return Iterables.addAll(collection, values);
/*     */   }
/*     */ 
/*     */   public boolean putAll(Multimap<? extends K, ? extends V> multimap) {
/* 207 */     boolean changed = false;
/* 208 */     for (Map.Entry entry : multimap.entries()) {
/* 209 */       changed |= put(entry.getKey(), entry.getValue());
/*     */     }
/* 211 */     return changed;
/*     */   }
/*     */ 
/*     */   public C replaceValues(K key, Iterable<? extends V> values)
/*     */   {
/* 221 */     Collection collection = get(key);
/* 222 */     Collection oldValues = (Collection)this.factory.get();
/* 223 */     oldValues.addAll(collection);
/* 224 */     collection.clear();
/* 225 */     Iterables.addAll(collection, values);
/* 226 */     return oldValues;
/*     */   }
/*     */ 
/*     */   public C removeAll(Object key)
/*     */   {
/* 236 */     Collection collection = (Collection)this.map.get(key);
/* 237 */     Collection output = (Collection)this.factory.get();
/*     */ 
/* 239 */     if (collection != null) {
/* 240 */       output.addAll(collection);
/* 241 */       collection.clear();
/*     */     }
/*     */ 
/* 244 */     return output;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 249 */     for (Collection collection : this.map.values())
/* 250 */       collection.clear();
/*     */   }
/*     */ 
/*     */   public C get(K key)
/*     */   {
/* 263 */     Collection collection = (Collection)this.map.get(key);
/* 264 */     if (collection == null) {
/* 265 */       collection = (Collection)this.factory.get();
/* 266 */       this.map.put(key, collection);
/*     */     }
/* 268 */     return collection;
/*     */   }
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/* 274 */     Set result = this.keySet;
/* 275 */     return result == null ? (this.keySet = new KeySet(null)) : result;
/*     */   }
/*     */ 
/*     */   public Multiset<K> keys()
/*     */   {
/* 333 */     Multiset result = this.keys;
/* 334 */     return result == null ? (this.keys = new Keys(null)) : result;
/*     */   }
/*     */ 
/*     */   private int removeValuesForKey(Object key)
/*     */   {
/*     */     Collection collection;
/*     */     try
/*     */     {
/* 467 */       collection = (Collection)this.map.get(key);
/*     */     } catch (NullPointerException e) {
/* 469 */       return 0;
/*     */     } catch (ClassCastException e) {
/* 471 */       return 0;
/*     */     }
/*     */ 
/* 474 */     int count = 0;
/* 475 */     if (collection != null) {
/* 476 */       count = collection.size();
/* 477 */       collection.clear();
/*     */     }
/* 479 */     return count;
/*     */   }
/*     */ 
/*     */   public Collection<V> values()
/*     */   {
/* 536 */     Collection result = this.valuesCollection;
/* 537 */     return result == null ? (this.valuesCollection = new Values(null)) : result;
/*     */   }
/*     */ 
/*     */   public Collection<Map.Entry<K, V>> entries()
/*     */   {
/* 610 */     Collection result = this.entries;
/* 611 */     return result == null ? (this.entries = createEntries()) : result;
/*     */   }
/*     */ 
/*     */   private Collection<Map.Entry<K, V>> createEntries() {
/* 615 */     return (this.factory.get() instanceof Set) ? new EntrySet(null) : new Entries(null);
/*     */   }
/*     */ 
/*     */   public Map<K, Collection<V>> asMap()
/*     */   {
/* 714 */     Map result = this.asMap;
/* 715 */     return result == null ? (this.asMap = new AsMap(null)) : result;
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object object)
/*     */   {
/* 828 */     if (object == this) {
/* 829 */       return true;
/*     */     }
/* 831 */     if ((object instanceof Multimap)) {
/* 832 */       Multimap that = (Multimap)object;
/* 833 */       return asMap().equals(that.asMap());
/*     */     }
/* 835 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 845 */     return asMap().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 855 */     return asMap().toString();
/*     */   }
/*     */ 
/*     */   private class AsMapIterator
/*     */     implements Iterator<Map.Entry<K, Collection<V>>>
/*     */   {
/* 790 */     final Iterator<Map.Entry<K, C>> entryIterator = ConcreteMultimap.this.map.entrySet().iterator();
/*     */     Map.Entry<K, C> nextEntry;
/*     */     Map.Entry<K, C> lastEntry;
/*     */ 
/*     */     private AsMapIterator()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/*     */       while (true)
/*     */       {
/* 797 */         if ((this.nextEntry != null) && (!((Collection)this.nextEntry.getValue()).isEmpty())) {
/* 798 */           return true;
/*     */         }
/* 800 */         if (!this.entryIterator.hasNext()) {
/* 801 */           return false;
/*     */         }
/* 803 */         this.nextEntry = ((Map.Entry)this.entryIterator.next());
/*     */       }
/*     */     }
/*     */ 
/*     */     public Map.Entry<K, Collection<V>> next() {
/* 808 */       if (!hasNext()) {
/* 809 */         throw new NoSuchElementException();
/*     */       }
/*     */ 
/* 812 */       this.lastEntry = this.nextEntry;
/* 813 */       this.nextEntry = null;
/* 814 */       return Maps.immutableEntry(this.lastEntry.getKey(), (Collection)this.lastEntry.getValue());
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 819 */       Preconditions.checkState(this.lastEntry != null);
/* 820 */       ((Collection)this.lastEntry.getValue()).clear();
/* 821 */       this.lastEntry = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AsMapEntries extends AbstractSet<Map.Entry<K, Collection<V>>>
/*     */   {
/*     */     private AsMapEntries()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, Collection<V>>> iterator()
/*     */     {
/* 753 */       return new ConcreteMultimap.AsMapIterator(ConcreteMultimap.this, null);
/*     */     }
/*     */ 
/*     */     public int size() {
/* 757 */       return ConcreteMultimap.this.keySet().size();
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 763 */       ConcreteMultimap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 767 */       if (!(o instanceof Map.Entry)) {
/* 768 */         return false;
/*     */       }
/* 770 */       Map.Entry entry = (Map.Entry)o;
/* 771 */       if ((entry.getValue() instanceof Collection)) {
/* 772 */         Collection collection = (Collection)entry.getValue();
/* 773 */         return (!collection.isEmpty()) && (Objects.equal(ConcreteMultimap.this.map.get(entry.getKey()), collection));
/*     */       }
/*     */ 
/* 776 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 780 */       if (!(o instanceof Map.Entry)) {
/* 781 */         return false;
/*     */       }
/* 783 */       Map.Entry entry = (Map.Entry)o;
/* 784 */       return (contains(entry)) && (ConcreteMultimap.this.removeValuesForKey(entry.getKey()) > 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AsMap extends AbstractMap<K, Collection<V>>
/*     */   {
/*     */     transient Set<Map.Entry<K, Collection<V>>> entrySet;
/*     */ 
/*     */     private AsMap()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<K, Collection<V>>> entrySet()
/*     */     {
/* 722 */       Set result = this.entrySet;
/* 723 */       return result == null ? (this.entrySet = new ConcreteMultimap.AsMapEntries(ConcreteMultimap.this, null)) : result;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 729 */       ConcreteMultimap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object key) {
/* 733 */       return ConcreteMultimap.this.containsKey(key);
/*     */     }
/*     */ 
/*     */     public C get(Object key) {
/* 737 */       Collection collection = (Collection)ConcreteMultimap.this.map.get(key);
/* 738 */       return (collection == null) || (collection.isEmpty()) ? null : collection;
/*     */     }
/*     */ 
/*     */     public Set<K> keySet() {
/* 742 */       return ConcreteMultimap.this.keySet();
/*     */     }
/*     */ 
/*     */     public C remove(Object key) {
/* 746 */       Collection collection = ConcreteMultimap.this.removeAll(key);
/* 747 */       return collection.isEmpty() ? null : collection;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EntrySet extends ConcreteMultimap<K, V, C>.Entries
/*     */     implements Set<Map.Entry<K, V>>
/*     */   {
/*     */     private EntrySet()
/*     */     {
/* 696 */       super(null);
/*     */     }
/* 698 */     public boolean equals(@Nullable Object other) { return Collections2.setEquals(this, other); }
/*     */ 
/*     */     public int hashCode() {
/* 701 */       return Sets.hashCodeImpl(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<K, V>>
/*     */   {
/*     */     final Iterator<Map.Entry<K, C>> keyIterator;
/*     */     Map.Entry<K, C> nextEntry;
/* 658 */     Iterator<V> nextValueIterator = Iterators.emptyIterator();
/*     */     Iterator<V> removeIterator;
/*     */ 
/*     */     EntryIterator()
/*     */     {
/* 662 */       this.keyIterator = ConcreteMultimap.this.map.entrySet().iterator();
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/*     */       while (true) {
/* 667 */         if (this.nextValueIterator.hasNext()) {
/* 668 */           return true;
/*     */         }
/* 670 */         if (!this.keyIterator.hasNext()) {
/* 671 */           return false;
/*     */         }
/* 673 */         this.nextEntry = ((Map.Entry)this.keyIterator.next());
/* 674 */         this.nextValueIterator = ((Collection)this.nextEntry.getValue()).iterator();
/*     */       }
/*     */     }
/*     */ 
/*     */     public Map.Entry<K, V> next() {
/* 679 */       if (!hasNext()) {
/* 680 */         throw new NoSuchElementException();
/*     */       }
/*     */ 
/* 684 */       this.removeIterator = this.nextValueIterator;
/* 685 */       return Maps.immutableEntry(this.nextEntry.getKey(), this.nextValueIterator.next());
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 689 */       Preconditions.checkState(this.removeIterator != null);
/* 690 */       this.removeIterator.remove();
/* 691 */       this.removeIterator = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Entries extends AbstractCollection<Map.Entry<K, V>>
/*     */   {
/*     */     private Entries()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, V>> iterator()
/*     */     {
/* 621 */       return new ConcreteMultimap.EntryIterator(ConcreteMultimap.this);
/*     */     }
/*     */     public int size() {
/* 624 */       return ConcreteMultimap.this.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 630 */       if (!(o instanceof Map.Entry)) {
/* 631 */         return false;
/*     */       }
/* 633 */       Map.Entry entry = (Map.Entry)o;
/* 634 */       return ConcreteMultimap.this.containsEntry(entry.getKey(), entry.getValue());
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 638 */       ConcreteMultimap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 642 */       return ConcreteMultimap.this.isEmpty();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 646 */       if (!(o instanceof Map.Entry)) {
/* 647 */         return false;
/*     */       }
/* 649 */       Map.Entry entry = (Map.Entry)o;
/* 650 */       return ConcreteMultimap.this.remove(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ValueIterator
/*     */     implements Iterator<V>
/*     */   {
/* 581 */     final Iterator<Map.Entry<K, V>> entryIterator = new ConcreteMultimap.EntryIterator(ConcreteMultimap.this);
/*     */ 
/*     */     private ValueIterator() {  }
/*     */ 
/* 584 */     public boolean hasNext() { return this.entryIterator.hasNext(); }
/*     */ 
/*     */     public V next() {
/* 587 */       return ((Map.Entry)this.entryIterator.next()).getValue();
/*     */     }
/*     */     public void remove() {
/* 590 */       this.entryIterator.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Values extends AbstractCollection<V>
/*     */   {
/*     */     private Values()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<V> iterator()
/*     */     {
/* 542 */       return new ConcreteMultimap.ValueIterator(ConcreteMultimap.this, null);
/*     */     }
/*     */     public int size() {
/* 545 */       return ConcreteMultimap.this.size();
/*     */     }
/*     */     public boolean removeAll(Collection<?> c) {
/* 548 */       Preconditions.checkNotNull(c);
/* 549 */       boolean changed = false;
/* 550 */       for (Collection collection : ConcreteMultimap.this.map.values()) {
/* 551 */         changed |= collection.removeAll(c);
/*     */       }
/* 553 */       return changed;
/*     */     }
/*     */     public boolean retainAll(Collection<?> c) {
/* 556 */       Preconditions.checkNotNull(c);
/* 557 */       boolean changed = false;
/* 558 */       for (Collection collection : ConcreteMultimap.this.map.values()) {
/* 559 */         changed |= collection.retainAll(c);
/*     */       }
/* 561 */       return changed;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 567 */       ConcreteMultimap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object value) {
/* 571 */       return ConcreteMultimap.this.containsValue(value);
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 575 */       return ConcreteMultimap.this.isEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MultisetKeyIterator
/*     */     implements Iterator<K>
/*     */   {
/* 514 */     final Iterator<Map.Entry<K, V>> entryIterator = ConcreteMultimap.this.entries().iterator();
/*     */ 
/*     */     private MultisetKeyIterator() {  }
/*     */ 
/* 517 */     public boolean hasNext() { return this.entryIterator.hasNext(); }
/*     */ 
/*     */     public K next() {
/* 520 */       return ((Map.Entry)this.entryIterator.next()).getKey();
/*     */     }
/*     */     public void remove() {
/* 523 */       this.entryIterator.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MultisetEntry extends Multisets.AbstractEntry<K>
/*     */   {
/*     */     final Map.Entry<K, Collection<V>> entry;
/*     */ 
/*     */     public MultisetEntry()
/*     */     {
/* 502 */       this.entry = entry;
/*     */     }
/*     */     public K getElement() {
/* 505 */       return this.entry.getKey();
/*     */     }
/*     */     public int getCount() {
/* 508 */       return ((Collection)this.entry.getValue()).size();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MultisetEntryIterator
/*     */     implements Iterator<Multiset.Entry<K>>
/*     */   {
/* 484 */     final Iterator<Map.Entry<K, Collection<V>>> asMapIterator = ConcreteMultimap.this.asMap().entrySet().iterator();
/*     */ 
/*     */     private MultisetEntryIterator() {
/*     */     }
/* 488 */     public boolean hasNext() { return this.asMapIterator.hasNext(); }
/*     */ 
/*     */     public Multiset.Entry<K> next() {
/* 491 */       return new ConcreteMultimap.MultisetEntry(ConcreteMultimap.this, (Map.Entry)this.asMapIterator.next());
/*     */     }
/*     */     public void remove() {
/* 494 */       this.asMapIterator.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Keys extends AbstractMultiset<K>
/*     */   {
/*     */     transient Set<Multiset.Entry<K>> entrySet;
/*     */ 
/*     */     private Keys()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int remove(Object key, int occurrences)
/*     */     {
/* 341 */       if (occurrences == 0) {
/* 342 */         return count(key);
/* 344 */       }Preconditions.checkArgument(occurrences > 0);
/*     */       Collection collection;
/*     */       try {
/* 348 */         collection = (Collection)ConcreteMultimap.this.map.get(key);
/*     */       } catch (NullPointerException e) {
/* 350 */         return 0;
/*     */       } catch (ClassCastException e) {
/* 352 */         return 0;
/*     */       }
/*     */ 
/* 355 */       if (collection == null) {
/* 356 */         return 0;
/*     */       }
/* 358 */       int count = collection.size();
/*     */ 
/* 360 */       if (occurrences >= count) {
/* 361 */         collection.clear();
/* 362 */         return count;
/*     */       }
/*     */ 
/* 365 */       Iterator iterator = collection.iterator();
/* 366 */       for (int i = 0; i < occurrences; i++) {
/* 367 */         iterator.next();
/* 368 */         iterator.remove();
/*     */       }
/* 370 */       return count;
/*     */     }
/*     */ 
/*     */     public Set<K> elementSet() {
/* 374 */       return ConcreteMultimap.this.keySet();
/*     */     }
/*     */ 
/*     */     public Set<Multiset.Entry<K>> entrySet()
/*     */     {
/* 380 */       Set result = this.entrySet;
/* 381 */       return result == null ? (this.entrySet = new EntrySet(null)) : result;
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator()
/*     */     {
/* 431 */       return new ConcreteMultimap.MultisetKeyIterator(ConcreteMultimap.this, null);
/*     */     }
/*     */ 
/*     */     public int count(Object key)
/*     */     {
/*     */       try
/*     */       {
/* 438 */         Collection collection = (Collection)ConcreteMultimap.this.map.get(key);
/* 439 */         return collection == null ? 0 : collection.size();
/*     */       } catch (NullPointerException e) {
/* 441 */         return 0; } catch (ClassCastException e) {
/*     */       }
/* 443 */       return 0;
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 448 */       return ConcreteMultimap.this.size();
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 452 */       ConcreteMultimap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 456 */       return ConcreteMultimap.this.isEmpty();
/*     */     }
/*     */ 
/*     */     private class EntrySet extends AbstractSet<Multiset.Entry<K>>
/*     */     {
/*     */       private EntrySet()
/*     */       {
/*     */       }
/*     */ 
/*     */       public Iterator<Multiset.Entry<K>> iterator()
/*     */       {
/* 386 */         return new ConcreteMultimap.MultisetEntryIterator(ConcreteMultimap.this, null);
/*     */       }
/*     */       public int size() {
/* 389 */         return ConcreteMultimap.this.keySet().size();
/*     */       }
/*     */ 
/*     */       public boolean contains(Object o)
/*     */       {
/* 395 */         if (!(o instanceof Multiset.Entry)) {
/* 396 */           return false;
/*     */         }
/* 398 */         Multiset.Entry entry = (Multiset.Entry)o;
/* 399 */         if (entry.getCount() <= 0) {
/* 400 */           return false;
/*     */         }
/* 402 */         Collection collection = (Collection)ConcreteMultimap.this.map.get(entry.getElement());
/* 403 */         return (collection != null) && (collection.size() == entry.getCount());
/*     */       }
/*     */ 
/*     */       public void clear() {
/* 407 */         ConcreteMultimap.this.clear();
/*     */       }
/*     */       public boolean isEmpty() {
/* 410 */         return ConcreteMultimap.this.isEmpty();
/*     */       }
/*     */       public boolean remove(Object o) {
/* 413 */         if (!(o instanceof Multiset.Entry)) {
/* 414 */           return false;
/*     */         }
/* 416 */         Multiset.Entry entry = (Multiset.Entry)o;
/* 417 */         if (entry.getCount() <= 0) {
/* 418 */           return false;
/*     */         }
/* 420 */         Collection collection = (Collection)ConcreteMultimap.this.map.get(entry.getElement());
/* 421 */         if ((collection != null) && (collection.size() == entry.getCount()))
/*     */         {
/* 423 */           collection.clear();
/* 424 */           return true;
/*     */         }
/* 426 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class KeySet extends AbstractSet<K>
/*     */   {
/*     */     private KeySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 281 */       int size = 0;
/* 282 */       for (Collection collection : ConcreteMultimap.this.map.values()) {
/* 283 */         if (!collection.isEmpty()) {
/* 284 */           size++;
/*     */         }
/*     */       }
/* 287 */       return size;
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator() {
/* 291 */       Iterator asMapIterator = ConcreteMultimap.this.asMap().entrySet().iterator();
/*     */ 
/* 293 */       return new Iterator(asMapIterator) {
/*     */         public boolean hasNext() {
/* 295 */           return this.val$asMapIterator.hasNext();
/*     */         }
/*     */         public K next() {
/* 298 */           return ((Map.Entry)this.val$asMapIterator.next()).getKey();
/*     */         }
/*     */         public void remove() {
/* 301 */           this.val$asMapIterator.remove();
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 309 */       ConcreteMultimap.this.clear();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object key) {
/* 313 */       return ConcreteMultimap.this.containsKey(key);
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 317 */       return ConcreteMultimap.this.isEmpty();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object key) {
/* 321 */       Collection collection = (Collection)ConcreteMultimap.this.map.get(key);
/* 322 */       if ((collection != null) && (!collection.isEmpty())) {
/* 323 */         collection.clear();
/* 324 */         return true;
/*     */       }
/* 326 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ConcreteMultimap
 * JD-Core Version:    0.6.0
 */