/*    */ package com.google.appengine.api.memcache;
/*    */ 
/*    */ public class MemcacheServiceException extends RuntimeException
/*    */ {
/*    */   public MemcacheServiceException(String message, Throwable ex)
/*    */   {
/* 14 */     super(message, ex);
/*    */   }
/*    */   public MemcacheServiceException(String message) {
/* 17 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.MemcacheServiceException
 * JD-Core Version:    0.6.0
 */