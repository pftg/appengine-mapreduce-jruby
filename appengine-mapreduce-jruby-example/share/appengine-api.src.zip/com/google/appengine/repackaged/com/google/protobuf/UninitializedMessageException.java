/*    */ package com.google.appengine.repackaged.com.google.protobuf;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class UninitializedMessageException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -7466929953374883507L;
/*    */   private final List<String> missingFields;
/*    */ 
/*    */   public UninitializedMessageException(MessageLite message)
/*    */   {
/* 25 */     super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
/*    */ 
/* 27 */     this.missingFields = null;
/*    */   }
/*    */ 
/*    */   public UninitializedMessageException(List<String> missingFields) {
/* 31 */     super(buildDescription(missingFields));
/* 32 */     this.missingFields = missingFields;
/*    */   }
/*    */ 
/*    */   public List<String> getMissingFields()
/*    */   {
/* 44 */     return Collections.unmodifiableList(this.missingFields);
/*    */   }
/*    */ 
/*    */   public InvalidProtocolBufferException asInvalidProtocolBufferException()
/*    */   {
/* 53 */     return new InvalidProtocolBufferException(getMessage());
/*    */   }
/*    */ 
/*    */   private static String buildDescription(List<String> missingFields)
/*    */   {
/* 58 */     StringBuilder description = new StringBuilder("Message missing required fields: ");
/*    */ 
/* 60 */     boolean first = true;
/* 61 */     for (String field : missingFields) {
/* 62 */       if (first)
/* 63 */         first = false;
/*    */       else {
/* 65 */         description.append(", ");
/*    */       }
/* 67 */       description.append(field);
/*    */     }
/* 69 */     return description.toString();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException
 * JD-Core Version:    0.6.0
 */