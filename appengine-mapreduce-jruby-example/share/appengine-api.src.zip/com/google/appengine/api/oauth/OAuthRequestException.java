/*    */ package com.google.appengine.api.oauth;
/*    */ 
/*    */ public class OAuthRequestException extends Exception
/*    */ {
/*    */   public OAuthRequestException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.oauth.OAuthRequestException
 * JD-Core Version:    0.6.0
 */