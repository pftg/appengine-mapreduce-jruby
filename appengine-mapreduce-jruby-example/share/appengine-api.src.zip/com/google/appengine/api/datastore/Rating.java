/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class Rating
/*    */   implements Serializable, Comparable<Rating>
/*    */ {
/*    */   public static final long serialVersionUID = 362898405551261187L;
/*    */   public static final int MIN_VALUE = 0;
/*    */   public static final int MAX_VALUE = 100;
/*    */   private int rating;
/*    */ 
/*    */   public Rating(int rating)
/*    */   {
/* 37 */     if ((rating < 0) || (rating > 100)) {
/* 38 */       throw new IllegalArgumentException(String.format("rating must be no smaller than %d and no greater than %d (received %d)", new Object[] { Integer.valueOf(0), Integer.valueOf(100), Integer.valueOf(rating) }));
/*    */     }
/*    */ 
/* 42 */     this.rating = rating;
/*    */   }
/*    */ 
/*    */   private Rating()
/*    */   {
/* 52 */     this(0);
/*    */   }
/*    */ 
/*    */   public int getRating() {
/* 56 */     return this.rating;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 61 */     if (this == o) {
/* 62 */       return true;
/*    */     }
/* 64 */     if ((o == null) || (getClass() != o.getClass())) {
/* 65 */       return false;
/*    */     }
/*    */ 
/* 68 */     Rating rating1 = (Rating)o;
/*    */ 
/* 71 */     return this.rating == rating1.rating;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 79 */     return this.rating;
/*    */   }
/*    */ 
/*    */   public int compareTo(Rating o) {
/* 83 */     return Integer.valueOf(this.rating).compareTo(Integer.valueOf(o.rating));
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Rating
 * JD-Core Version:    0.6.0
 */