/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.DatastorePb.Query.Filter;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order;
/*     */ import com.google.apphosting.api.DatastorePb.Query.Order.Direction;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Property;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public final class EntityProtoComparators
/*     */ {
/*  28 */   public static final Comparator<Comparable<Object>> MULTI_TYPE_COMPARATOR = new MultiTypeComparator(null);
/*     */ 
/*  32 */   static final DatastorePb.Query.Order KEY_ASC_ORDER = new DatastorePb.Query.Order().setProperty("__key__").setDirection(DatastorePb.Query.Order.Direction.ASCENDING);
/*     */ 
/*     */   private static final class MultiTypeComparator
/*     */     implements Comparator<Comparable<Object>>
/*     */   {
/*     */     public int compare(Comparable<Object> o1, Comparable<Object> o2)
/*     */     {
/* 216 */       if (o1 == null) {
/* 217 */         if (o2 == null) {
/* 218 */           return 0;
/*     */         }
/*     */ 
/* 221 */         return -1;
/* 222 */       }if (o2 == null)
/*     */       {
/* 224 */         return 1;
/*     */       }
/* 226 */       Integer comp1TypeRank = Integer.valueOf(DataTypeTranslator.getTypeRank(o1.getClass()));
/* 227 */       Integer comp2TypeRank = Integer.valueOf(DataTypeTranslator.getTypeRank(o2.getClass()));
/* 228 */       if (comp1TypeRank.equals(comp2TypeRank))
/*     */       {
/* 230 */         return o1.compareTo(o2);
/*     */       }
/* 232 */       return comp1TypeRank.compareTo(comp2TypeRank);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class EntityProtoComparator
/*     */     implements Comparator<OnestoreEntity.EntityProto>
/*     */   {
/*     */     final List<DatastorePb.Query.Order> orders;
/*     */     final Map<String, FilterMatcher> filters;
/*     */ 
/*     */     public EntityProtoComparator(List<DatastorePb.Query.Order> orders)
/*     */     {
/*  42 */       this(orders, Collections.emptyList());
/*     */     }
/*     */ 
/*     */     public EntityProtoComparator(List<DatastorePb.Query.Order> orders, List<DatastorePb.Query.Filter> filters) {
/*  46 */       this.orders = makeAdjustedOrders(orders, filters);
/*  47 */       this.filters = makeFilterMatchers(orders, filters);
/*     */     }
/*     */ 
/*     */     private static List<DatastorePb.Query.Order> makeAdjustedOrders(List<DatastorePb.Query.Order> orders, List<DatastorePb.Query.Filter> filters) {
/*  51 */       List adjusted = new ArrayList(orders.size() + 1);
/*     */ 
/*  53 */       for (DatastorePb.Query.Order order : orders) {
/*  54 */         adjusted.add(order);
/*  55 */         if (order.getProperty().equals(EntityProtoComparators.KEY_ASC_ORDER.getProperty()))
/*     */         {
/*  57 */           return adjusted;
/*     */         }
/*     */       }
/*     */ 
/*  61 */       if (adjusted.isEmpty())
/*     */       {
/*  63 */         for (DatastorePb.Query.Filter filter : filters) {
/*  64 */           if (ValidatedQuery.INEQUALITY_OPERATORS.contains(filter.getOpEnum()))
/*     */           {
/*  66 */             adjusted.add(new DatastorePb.Query.Order().setProperty(filter.getProperty(0).getName()).setDirection(DatastorePb.Query.Order.Direction.ASCENDING));
/*     */ 
/*  69 */             break;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  75 */       adjusted.add(EntityProtoComparators.KEY_ASC_ORDER);
/*  76 */       return adjusted;
/*     */     }
/*     */ 
/*     */     private static Map<String, FilterMatcher> makeFilterMatchers(List<DatastorePb.Query.Order> orders, List<DatastorePb.Query.Filter> filters)
/*     */     {
/*  81 */       Map filterMatchers = new HashMap();
/*  82 */       for (DatastorePb.Query.Filter filter : filters) {
/*  83 */         String name = filter.getProperty(0).getName();
/*  84 */         FilterMatcher filterMatcher = (FilterMatcher)filterMatchers.get(name);
/*  85 */         if (filterMatcher == null) {
/*  86 */           filterMatcher = new FilterMatcher();
/*  87 */           filterMatchers.put(name, filterMatcher);
/*     */         }
/*  89 */         filterMatcher.addFilter(filter);
/*     */       }
/*     */ 
/*  93 */       for (DatastorePb.Query.Order order : orders) {
/*  94 */         if (!filterMatchers.containsKey(order.getProperty())) {
/*  95 */           filterMatchers.put(order.getProperty(), FilterMatcher.MATCH_ALL);
/*     */         }
/*  97 */         if (order.getProperty().equals(EntityProtoComparators.KEY_ASC_ORDER.getProperty()))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/* 103 */       return filterMatchers;
/*     */     }
/*     */ 
/*     */     public List<DatastorePb.Query.Order> getAdjustedOrders() {
/* 107 */       return Collections.unmodifiableList(this.orders);
/*     */     }
/*     */ 
/*     */     public boolean matches(OnestoreEntity.EntityProto proto) {
/* 111 */       for (String property : this.filters.keySet()) {
/* 112 */         List values = getComparablePropertyValues(proto, property);
/* 113 */         if ((values == null) || (!((FilterMatcher)this.filters.get(property)).matches(values))) {
/* 114 */           return false;
/*     */         }
/*     */       }
/* 117 */       return true;
/*     */     }
/*     */ 
/*     */     public int compare(OnestoreEntity.EntityProto protoA, OnestoreEntity.EntityProto protoB)
/*     */     {
/* 125 */       for (DatastorePb.Query.Order order : this.orders) {
/* 126 */         String property = order.getProperty();
/*     */ 
/* 128 */         Collection aValues = getComparablePropertyValues(protoA, property);
/* 129 */         Collection bValues = getComparablePropertyValues(protoB, property);
/* 130 */         if ((aValues == null) || (bValues == null))
/*     */         {
/* 133 */           throw new IllegalStateException("Trying to sort on a non-existent property.");
/*     */         }
/*     */ 
/* 140 */         boolean findMin = order.getDirectionEnum() == DatastorePb.Query.Order.Direction.ASCENDING;
/* 141 */         FilterMatcher matcher = (FilterMatcher)this.filters.get(property);
/* 142 */         if (matcher == null) {
/* 143 */           matcher = FilterMatcher.MATCH_ALL;
/*     */         }
/* 145 */         Comparable extremeA = multiTypeExtreme(aValues, findMin, matcher);
/* 146 */         Comparable extremeB = multiTypeExtreme(bValues, findMin, matcher);
/*     */ 
/* 150 */         int result = EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(extremeA, extremeB);
/*     */ 
/* 152 */         if (result != 0) {
/* 153 */           if (order.getDirectionEnum() == DatastorePb.Query.Order.Direction.DESCENDING) {
/* 154 */             result = -result;
/*     */           }
/* 156 */           return result;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 161 */       return 0;
/*     */     }
/*     */ 
/*     */     static List<Comparable<Object>> getComparablePropertyValues(OnestoreEntity.EntityProto entityProto, String propertyName)
/*     */     {
/* 173 */       Collection entityProperties = DataTypeTranslator.findIndexedPropertiesOnPb(entityProto, propertyName);
/*     */ 
/* 175 */       if (entityProperties.isEmpty()) {
/* 176 */         return null;
/*     */       }
/* 178 */       List values = new ArrayList(entityProperties.size());
/* 179 */       for (OnestoreEntity.Property prop : entityProperties) {
/* 180 */         values.add(DataTypeTranslator.getComparablePropertyValue(prop));
/*     */       }
/* 182 */       return values;
/*     */     }
/*     */ 
/*     */     static Comparable<Object> multiTypeExtreme(Collection<Comparable<Object>> comparables, boolean findMin, FilterMatcher matcher)
/*     */     {
/* 191 */       boolean findMax = !findMin;
/* 192 */       Comparable extreme = FilterMatcher.NoValue.INSTANCE;
/* 193 */       for (Comparable value : comparables) {
/* 194 */         if (!matcher.considerValueForOrder(value))
/*     */         {
/*     */           continue;
/*     */         }
/* 198 */         if (extreme == FilterMatcher.NoValue.INSTANCE)
/* 199 */           extreme = value;
/* 200 */         else if ((findMin) && (EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(value, extreme) < 0))
/* 201 */           extreme = value;
/* 202 */         else if ((findMax) && (EntityProtoComparators.MULTI_TYPE_COMPARATOR.compare(value, extreme) > 0)) {
/* 203 */           extreme = value;
/*     */         }
/*     */       }
/* 206 */       if (extreme == FilterMatcher.NoValue.INSTANCE)
/*     */       {
/* 208 */         throw new IllegalArgumentException("Entity contains no relevant values.");
/*     */       }
/* 210 */       return extreme;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.EntityProtoComparators
 * JD-Core Version:    0.6.0
 */