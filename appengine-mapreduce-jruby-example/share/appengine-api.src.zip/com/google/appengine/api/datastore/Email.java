/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public final class Email
/*    */   implements Serializable, Comparable<Email>
/*    */ {
/*    */   public static final long serialVersionUID = -4807513785819575482L;
/*    */   private String email;
/*    */ 
/*    */   public Email(String email)
/*    */   {
/* 33 */     if (email == null) {
/* 34 */       throw new NullPointerException("email must not be null");
/*    */     }
/* 36 */     this.email = email;
/*    */   }
/*    */ 
/*    */   private Email()
/*    */   {
/* 46 */     this.email = null;
/*    */   }
/*    */ 
/*    */   public String getEmail() {
/* 50 */     return this.email;
/*    */   }
/*    */ 
/*    */   public int compareTo(Email e) {
/* 54 */     return this.email.compareTo(e.email);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 59 */     if (this == o) {
/* 60 */       return true;
/*    */     }
/* 62 */     if ((o == null) || (getClass() != o.getClass())) {
/* 63 */       return false;
/*    */     }
/*    */ 
/* 66 */     Email email1 = (Email)o;
/*    */ 
/* 69 */     return this.email.equals(email1.email);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 77 */     return this.email.hashCode();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.Email
 * JD-Core Version:    0.6.0
 */