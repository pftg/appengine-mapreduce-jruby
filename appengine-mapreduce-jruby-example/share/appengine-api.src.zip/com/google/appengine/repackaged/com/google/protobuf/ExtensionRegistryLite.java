/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ExtensionRegistryLite
/*     */ {
/*     */   private final Map<ObjectIntPair, GeneratedMessageLite.GeneratedExtension<?, ?>> extensionsByNumber;
/* 115 */   private static final ExtensionRegistryLite EMPTY = new ExtensionRegistryLite(true);
/*     */ 
/*     */   public static ExtensionRegistryLite newInstance()
/*     */   {
/*  48 */     return new ExtensionRegistryLite();
/*     */   }
/*     */ 
/*     */   public static ExtensionRegistryLite getEmptyRegistry()
/*     */   {
/*  53 */     return EMPTY;
/*     */   }
/*     */ 
/*     */   public ExtensionRegistryLite getUnmodifiable()
/*     */   {
/*  58 */     return new ExtensionRegistryLite(this);
/*     */   }
/*     */ 
/*     */   public <ContainingType extends MessageLite> GeneratedMessageLite.GeneratedExtension<ContainingType, ?> findLiteExtensionByNumber(ContainingType containingTypeDefaultInstance, int fieldNumber)
/*     */   {
/*  73 */     return (GeneratedMessageLite.GeneratedExtension)this.extensionsByNumber.get(new ObjectIntPair(containingTypeDefaultInstance, fieldNumber));
/*     */   }
/*     */ 
/*     */   public final void add(GeneratedMessageLite.GeneratedExtension<?, ?> extension)
/*     */   {
/*  81 */     this.extensionsByNumber.put(new ObjectIntPair(extension.getContainingTypeDefaultInstance(), extension.getNumber()), extension);
/*     */   }
/*     */ 
/*     */   ExtensionRegistryLite()
/*     */   {
/*  94 */     this.extensionsByNumber = new HashMap();
/*     */   }
/*     */ 
/*     */   ExtensionRegistryLite(ExtensionRegistryLite other)
/*     */   {
/* 100 */     if (other == EMPTY)
/* 101 */       this.extensionsByNumber = Collections.emptyMap();
/*     */     else
/* 103 */       this.extensionsByNumber = Collections.unmodifiableMap(other.extensionsByNumber);
/*     */   }
/*     */ 
/*     */   private ExtensionRegistryLite(boolean empty)
/*     */   {
/* 113 */     this.extensionsByNumber = Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   private static final class ObjectIntPair
/*     */   {
/*     */     private final Object object;
/*     */     private final int number;
/*     */ 
/*     */     ObjectIntPair(Object object, int number) {
/* 124 */       this.object = object;
/* 125 */       this.number = number;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 130 */       return System.identityHashCode(this.object) * 65535 + this.number;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 134 */       if (!(obj instanceof ObjectIntPair)) {
/* 135 */         return false;
/*     */       }
/* 137 */       ObjectIntPair other = (ObjectIntPair)obj;
/* 138 */       return (this.object == other.object) && (this.number == other.number);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite
 * JD-Core Version:    0.6.0
 */