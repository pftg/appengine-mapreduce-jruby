/*    */ package com.google.appengine.api.users;
/*    */ 
/*    */ public class UserServiceFailureException extends RuntimeException
/*    */ {
/*    */   public UserServiceFailureException(String message)
/*    */   {
/* 12 */     super(message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.users.UserServiceFailureException
 * JD-Core Version:    0.6.0
 */