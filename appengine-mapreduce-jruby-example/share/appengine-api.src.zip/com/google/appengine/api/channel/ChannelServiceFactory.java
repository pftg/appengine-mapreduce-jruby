/*    */ package com.google.appengine.api.channel;
/*    */ 
/*    */ public final class ChannelServiceFactory
/*    */ {
/*    */   public static ChannelService getChannelService()
/*    */   {
/* 13 */     return new ChannelServiceImpl();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.channel.ChannelServiceFactory
 * JD-Core Version:    0.6.0
 */