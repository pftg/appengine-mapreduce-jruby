/*    */ package javax.mail;
/*    */ 
/*    */ public class FolderNotFoundException extends MessagingException
/*    */ {
/*    */   private transient Folder _folder;
/*    */ 
/*    */   public FolderNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FolderNotFoundException(Folder folder)
/*    */   {
/* 33 */     this(folder, "Folder not found: " + folder.getName());
/*    */   }
/*    */ 
/*    */   public FolderNotFoundException(Folder folder, String message) {
/* 37 */     super(message);
/* 38 */     this._folder = folder;
/*    */   }
/*    */ 
/*    */   public FolderNotFoundException(String message, Folder folder) {
/* 42 */     this(folder, message);
/*    */   }
/*    */ 
/*    */   public Folder getFolder() {
/* 46 */     return this._folder;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.FolderNotFoundException
 * JD-Core Version:    0.6.0
 */