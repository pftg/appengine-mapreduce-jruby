/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ public class EntityNotFoundException extends Exception
/*    */ {
/*    */   private final Key key;
/*    */ 
/*    */   public EntityNotFoundException(Key key)
/*    */   {
/* 15 */     super("No entity was found matching the key: " + key);
/* 16 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public Key getKey() {
/* 20 */     return this.key;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.EntityNotFoundException
 * JD-Core Version:    0.6.0
 */