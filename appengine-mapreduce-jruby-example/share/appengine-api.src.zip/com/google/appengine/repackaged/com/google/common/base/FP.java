/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class FP
/*     */ {
/*     */   public static long fingerprint(byte[] str, int start, int limit)
/*     */   {
/*  24 */     int hi = hash32(str, start, limit, 0);
/*  25 */     int lo = hash32(str, start, limit, 102072);
/*  26 */     if ((hi == 0) && ((lo == 0) || (lo == 1)))
/*     */     {
/*  28 */       hi ^= 319790063;
/*  29 */       lo ^= -1801410264;
/*     */     }
/*  31 */     return hi << 32 | lo & 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   public static long fingerprint(String str)
/*     */   {
/*     */     try
/*     */     {
/*  40 */       byte[] tmp = str.getBytes("UTF-8");
/*  41 */       return fingerprint(tmp, 0, tmp.length);
/*     */     } catch (UnsupportedEncodingException e) {
/*  43 */       X.assertTrue(false);
/*  44 */     }return 0L;
/*     */   }
/*     */ 
/*     */   private static int hash32(byte[] str, int start, int limit, int c)
/*     */   {
/*  50 */     int a = -1640531527;
/*  51 */     int b = -1640531527;
/*     */ 
/*  53 */     for (int i = start; i + 12 <= limit; i += 12) {
/*  54 */       a += ((str[(i + 0)] & 0xFF) << 0 | (str[(i + 1)] & 0xFF) << 8 | (str[(i + 2)] & 0xFF) << 16 | (str[(i + 3)] & 0xFF) << 24);
/*     */ 
/*  56 */       b += ((str[(i + 4)] & 0xFF) << 0 | (str[(i + 5)] & 0xFF) << 8 | (str[(i + 6)] & 0xFF) << 16 | (str[(i + 7)] & 0xFF) << 24);
/*     */ 
/*  58 */       c += ((str[(i + 8)] & 0xFF) << 0 | (str[(i + 9)] & 0xFF) << 8 | (str[(i + 10)] & 0xFF) << 16 | (str[(i + 11)] & 0xFF) << 24);
/*     */ 
/*  62 */       a -= b;
/*  63 */       a -= c;
/*  64 */       a ^= c >>> 13;
/*  65 */       b -= c;
/*  66 */       b -= a;
/*  67 */       b ^= a << 8;
/*  68 */       c -= a;
/*  69 */       c -= b;
/*  70 */       c ^= b >>> 13;
/*  71 */       a -= b;
/*  72 */       a -= c;
/*  73 */       a ^= c >>> 12;
/*  74 */       b -= c;
/*  75 */       b -= a;
/*  76 */       b ^= a << 16;
/*  77 */       c -= a;
/*  78 */       c -= b;
/*  79 */       c ^= b >>> 5;
/*  80 */       a -= b;
/*  81 */       a -= c;
/*  82 */       a ^= c >>> 3;
/*  83 */       b -= c;
/*  84 */       b -= a;
/*  85 */       b ^= a << 10;
/*  86 */       c -= a;
/*  87 */       c -= b;
/*  88 */       c ^= b >>> 15;
/*     */     }
/*     */ 
/*  91 */     c += limit - start;
/*  92 */     switch (limit - i) {
/*     */     case 11:
/*  94 */       c += ((str[(i + 10)] & 0xFF) << 24);
/*     */     case 10:
/*  96 */       c += ((str[(i + 9)] & 0xFF) << 16);
/*     */     case 9:
/*  98 */       c += ((str[(i + 8)] & 0xFF) << 8);
/*     */     case 8:
/* 101 */       b += ((str[(i + 7)] & 0xFF) << 24);
/*     */     case 7:
/* 103 */       b += ((str[(i + 6)] & 0xFF) << 16);
/*     */     case 6:
/* 105 */       b += ((str[(i + 5)] & 0xFF) << 8);
/*     */     case 5:
/* 107 */       b += (str[(i + 4)] & 0xFF);
/*     */     case 4:
/* 109 */       a += ((str[(i + 3)] & 0xFF) << 24);
/*     */     case 3:
/* 111 */       a += ((str[(i + 2)] & 0xFF) << 16);
/*     */     case 2:
/* 113 */       a += ((str[(i + 1)] & 0xFF) << 8);
/*     */     case 1:
/* 115 */       a += (str[(i + 0)] & 0xFF);
/*     */     }
/*     */ 
/* 120 */     a -= b;
/* 121 */     a -= c;
/* 122 */     a ^= c >>> 13;
/* 123 */     b -= c;
/* 124 */     b -= a;
/* 125 */     b ^= a << 8;
/* 126 */     c -= a;
/* 127 */     c -= b;
/* 128 */     c ^= b >>> 13;
/* 129 */     a -= b;
/* 130 */     a -= c;
/* 131 */     a ^= c >>> 12;
/* 132 */     b -= c;
/* 133 */     b -= a;
/* 134 */     b ^= a << 16;
/* 135 */     c -= a;
/* 136 */     c -= b;
/* 137 */     c ^= b >>> 5;
/* 138 */     a -= b;
/* 139 */     a -= c;
/* 140 */     a ^= c >>> 3;
/* 141 */     b -= c;
/* 142 */     b -= a;
/* 143 */     b ^= a << 10;
/* 144 */     c -= a;
/* 145 */     c -= b;
/* 146 */     c ^= b >>> 15;
/* 147 */     return c;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.FP
 * JD-Core Version:    0.6.0
 */