/*     */ package com.google.appengine.api.blobstore;
/*     */ 
/*     */ import com.google.appengine.api.NamespaceManager;
/*     */ import com.google.appengine.api.datastore.DatastoreService;
/*     */ import com.google.appengine.api.datastore.DatastoreServiceFactory;
/*     */ import com.google.appengine.api.datastore.Entity;
/*     */ import com.google.appengine.api.datastore.EntityNotFoundException;
/*     */ import com.google.appengine.api.datastore.Key;
/*     */ import com.google.appengine.api.datastore.KeyFactory;
/*     */ import com.google.appengine.api.datastore.PreparedQuery;
/*     */ import com.google.appengine.api.datastore.Query;
/*     */ import com.google.appengine.api.datastore.Query.FilterOperator;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class BlobInfoFactory
/*     */ {
/*     */   public static final String KIND = "__BlobInfo__";
/*     */   public static final String CONTENT_TYPE = "content_type";
/*     */   public static final String CREATION = "creation";
/*     */   public static final String FILENAME = "filename";
/*     */   public static final String SIZE = "size";
/*     */   private final DatastoreService datastoreService;
/*     */ 
/*     */   public BlobInfoFactory()
/*     */   {
/*  43 */     this(DatastoreServiceFactory.getDatastoreService());
/*     */   }
/*     */ 
/*     */   public BlobInfoFactory(DatastoreService datastoreService)
/*     */   {
/*  51 */     this.datastoreService = datastoreService;
/*     */   }
/*     */ 
/*     */   public BlobInfo loadBlobInfo(BlobKey blobKey)
/*     */   {
/*     */     try
/*     */     {
/*  60 */       return createBlobInfo(this.datastoreService.get(getMetadataKeyForBlobKey(blobKey))); } catch (EntityNotFoundException ex) {
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */   public Iterator<BlobInfo> queryBlobInfos()
/*     */   {
/*  71 */     return queryBlobInfosAfter(null);
/*     */   }
/*     */   public Iterator<BlobInfo> queryBlobInfosAfter(BlobKey previousBlob) {
/*  82 */     String origNamespace = NamespaceManager.get();
/*     */     Query query;
/*     */     try {
/*  85 */       NamespaceManager.set("");
/*  86 */       query = new Query("__BlobInfo__", null);
/*     */     } finally {
/*  88 */       NamespaceManager.set(origNamespace);
/*     */     }
/*     */ 
/*  91 */     if (previousBlob != null) {
/*  92 */       query.addFilter("__key__", Query.FilterOperator.GREATER_THAN, getMetadataKeyForBlobKey(previousBlob));
/*     */     }
/*     */ 
/*  97 */     Iterator parent = this.datastoreService.prepare(query).asIterator();
/*     */ 
/*  99 */     return new Iterator(parent) {
/*     */       public boolean hasNext() {
/* 101 */         return this.val$parent.hasNext();
/*     */       }
/*     */ 
/*     */       public BlobInfo next() {
/* 105 */         return BlobInfoFactory.this.createBlobInfo((Entity)this.val$parent.next());
/*     */       }
/*     */ 
/*     */       public void remove() {
/* 109 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public BlobInfo createBlobInfo(Entity entity)
/*     */   {
/* 119 */     return new BlobInfo(new BlobKey(entity.getKey().getName()), (String)entity.getProperty("content_type"), (Date)entity.getProperty("creation"), (String)entity.getProperty("filename"), ((Long)entity.getProperty("size")).longValue());
/*     */   }
/*     */ 
/*     */   private Key getMetadataKeyForBlobKey(BlobKey blobKey)
/*     */   {
/* 128 */     String origNamespace = NamespaceManager.get();
/*     */     try {
/* 130 */       NamespaceManager.set("");
/* 131 */       Key localKey = KeyFactory.createKey(null, "__BlobInfo__", blobKey.getKeyString());
/*     */       return localKey; } finally { NamespaceManager.set(origNamespace); } throw localObject;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobInfoFactory
 * JD-Core Version:    0.6.0
 */