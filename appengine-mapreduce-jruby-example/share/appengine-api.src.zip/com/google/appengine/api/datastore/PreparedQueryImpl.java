/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.ApiBasePb.Integer64Proto;
/*     */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*     */ import com.google.apphosting.api.DatastorePb.Query;
/*     */ import com.google.apphosting.api.DatastorePb.QueryResult;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Index;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ class PreparedQueryImpl extends BasePreparedQuery
/*     */ {
/*     */   private final DatastoreServiceConfig datastoreServiceConfig;
/*     */   private final ApiProxy.ApiConfig apiConfig;
/*     */   private final Query query;
/*     */   private final Transaction txn;
/*     */ 
/*     */   public PreparedQueryImpl(ApiProxy.ApiConfig apiConfig, DatastoreServiceConfig datastoreServiceConfig, Query query, Transaction txn)
/*     */   {
/*  32 */     this.apiConfig = apiConfig;
/*  33 */     this.datastoreServiceConfig = datastoreServiceConfig;
/*  34 */     this.query = query;
/*  35 */     this.txn = txn;
/*     */ 
/*  37 */     if ((query.getKind() == null) && ((!query.getFilterPredicates().isEmpty()) || (!query.getSortPredicates().isEmpty())))
/*     */     {
/*  39 */       throw new IllegalArgumentException("Kind is required for filters and sort orders.");
/*     */     }
/*     */ 
/*  42 */     if ((txn != null) && (query.getAncestor() == null)) {
/*  43 */       throw new IllegalArgumentException("Only ancestor queries are allowed inside transactions.");
/*     */     }
/*     */ 
/*  46 */     TransactionImpl.ensureTxnActive(txn);
/*     */   }
/*     */ 
/*     */   private int makeAsListFetchOptions(FetchOptions override)
/*     */   {
/*  57 */     int maximumSize = override.getLimit() != null ? override.getLimit().intValue() : 2147483647;
/*     */ 
/*  61 */     if (override.getPrefetchSize() == null) {
/*  62 */       override.prefetchSize(maximumSize);
/*     */     }
/*     */ 
/*  65 */     return maximumSize;
/*     */   }
/*     */ 
/*     */   public List<Entity> asList(FetchOptions fetchOptions) {
/*  69 */     FetchOptions override = new FetchOptions(fetchOptions);
/*  70 */     int numRequested = makeAsListFetchOptions(override);
/*  71 */     return runQuery(this.query, override).nextList(numRequested);
/*     */   }
/*     */ 
/*     */   public QueryResultList<Entity> asQueryResultList(FetchOptions fetchOptions) {
/*  75 */     FetchOptions override = new FetchOptions(fetchOptions);
/*  76 */     int numRequested = makeAsListFetchOptions(override);
/*  77 */     if (override.getCompile() == null)
/*     */     {
/*  79 */       override.compile(true);
/*     */     }
/*  81 */     QueryResultIteratorImpl itr = runQuery(this.query, override);
/*  82 */     return new QueryResultListImpl(itr.nextList(numRequested), itr.getCursor());
/*     */   }
/*     */ 
/*     */   public Iterator<Entity> asIterator(FetchOptions fetchOptions)
/*     */   {
/*  87 */     return runQuery(this.query, fetchOptions);
/*     */   }
/*     */ 
/*     */   public QueryResultIterator<Entity> asQueryResultIterator(FetchOptions fetchOptions) {
/*  91 */     if (fetchOptions.getCompile() == null)
/*     */     {
/*  93 */       fetchOptions = new FetchOptions(fetchOptions).compile(true);
/*     */     }
/*  95 */     return runQuery(this.query, fetchOptions);
/*     */   }
/*     */ 
/*     */   public Entity asSingleEntity() throws PreparedQuery.TooManyResultsException {
/*  99 */     List entities = asList(FetchOptions.Builder.withLimit(2));
/* 100 */     if (entities.isEmpty())
/* 101 */       return null;
/* 102 */     if (entities.size() != 1) {
/* 103 */       throw new PreparedQuery.TooManyResultsException();
/*     */     }
/* 105 */     return (Entity)entities.get(0);
/*     */   }
/*     */ 
/*     */   public int countEntities() {
/* 109 */     DatastorePb.Query queryProto = convertToPb(this.query, FetchOptions.Builder.withDefaults());
/* 110 */     ApiBasePb.Integer64Proto resp = new ApiBasePb.Integer64Proto();
/* 111 */     if (this.datastoreServiceConfig.getReadPolicy().getConsistency() == ReadPolicy.Consistency.EVENTUAL) {
/* 112 */       queryProto.setFailoverMs(-1L);
/*     */     }
/*     */ 
/* 115 */     DatastoreApiHelper.makeSyncCall(this.apiConfig, "Count", queryProto, resp);
/* 116 */     return (int)resp.getValue();
/*     */   }
/*     */ 
/*     */   private QueryResultIteratorImpl runQuery(Query q, FetchOptions fetchOptions) {
/* 120 */     DatastorePb.Query queryProto = convertToPb(q, fetchOptions);
/* 121 */     if (this.datastoreServiceConfig.getReadPolicy().getConsistency() == ReadPolicy.Consistency.EVENTUAL) {
/* 122 */       queryProto.setFailoverMs(-1L);
/*     */     }
/* 124 */     DatastorePb.QueryResult result = new DatastorePb.QueryResult();
/*     */     try
/*     */     {
/* 127 */       DatastoreApiHelper.makeSyncCall(this.apiConfig, "RunQuery", queryProto, result);
/*     */     }
/*     */     catch (DatastoreNeedIndexException e)
/*     */     {
/* 131 */       addMissingIndexData(queryProto, e);
/* 132 */       throw e;
/*     */     }
/*     */ 
/* 141 */     QueryResultsSourceImpl src = new QueryResultsSourceImpl(this.apiConfig, fetchOptions, this.txn);
/* 142 */     List prefetchedEntities = src.loadFromPb(result);
/*     */ 
/* 144 */     return new QueryResultIteratorImpl(this, prefetchedEntities, src, fetchOptions, this.txn);
/*     */   }
/*     */ 
/*     */   private void addMissingIndexData(DatastorePb.Query queryProto, DatastoreNeedIndexException e)
/*     */   {
/* 149 */     CompositeIndexManager.IndexComponentsOnlyQuery indexQuery = new CompositeIndexManager.IndexComponentsOnlyQuery(queryProto);
/* 150 */     CompositeIndexManager mgr = new CompositeIndexManager();
/* 151 */     OnestoreEntity.Index index = mgr.compositeIndexForQuery(indexQuery);
/* 152 */     if (index != null) {
/* 153 */       String xml = mgr.generateXmlForIndex(index, CompositeIndexManager.IndexSource.manual);
/* 154 */       e.setMissingIndexDefinitionXml(xml);
/*     */     }
/*     */   }
/*     */ 
/*     */   private DatastorePb.Query convertToPb(Query q, FetchOptions fetchOptions)
/*     */   {
/* 163 */     DatastorePb.Query queryProto = QueryTranslator.convertToPb(q, fetchOptions);
/* 164 */     if (this.txn != null) {
/* 165 */       TransactionImpl.ensureTxnActive(this.txn);
/* 166 */       queryProto.setTransaction(DatastoreServiceImpl.localTxnToRemoteTxn(this.txn));
/*     */     }
/* 168 */     return queryProto;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 173 */     return this.query.toString() + (this.txn != null ? " IN " + this.txn : "");
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.PreparedQueryImpl
 * JD-Core Version:    0.6.0
 */