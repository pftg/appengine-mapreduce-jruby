/*     */ package com.google.apphosting.api;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class ApiProxy
/*     */ {
/*     */   private static final String API_DEADLINE_KEY = "com.google.apphosting.api.ApiProxy.api_deadline_key";
/*  27 */   private static final ThreadLocal<Environment> environmentThreadLocal = new ThreadLocal();
/*     */   private static Delegate delegate;
/*     */ 
/*     */   public static byte[] makeSyncCall(String packageName, String methodName, byte[] request)
/*     */     throws ApiProxy.ApiProxyException
/*     */   {
/*  48 */     return makeSyncCall(packageName, methodName, request, null);
/*     */   }
/*     */ 
/*     */   public static byte[] makeSyncCall(String packageName, String methodName, byte[] request, ApiConfig apiConfig)
/*     */     throws ApiProxy.ApiProxyException
/*     */   {
/*  90 */     Environment env = getCurrentEnvironment();
/*  91 */     if ((delegate == null) || (env == null))
/*     */     {
/*  95 */       throw new CallNotFoundException(packageName, methodName);
/*     */     }
/*  97 */     if ((apiConfig == null) || (apiConfig.getDeadlineInSeconds() == null)) {
/*  98 */       return delegate.makeSyncCall(env, packageName, methodName, request);
/*     */     }
/* 100 */     Object oldValue = env.getAttributes().put("com.google.apphosting.api.ApiProxy.api_deadline_key", apiConfig.getDeadlineInSeconds());
/*     */     try {
/* 102 */       byte[] arrayOfByte = delegate.makeSyncCall(env, packageName, methodName, request);
/*     */       return arrayOfByte;
/*     */     }
/*     */     finally
/*     */     {
/* 105 */       if (oldValue == null)
/* 106 */         env.getAttributes().remove("com.google.apphosting.api.ApiProxy.api_deadline_key");
/*     */       else
/* 108 */         env.getAttributes().put("com.google.apphosting.api.ApiProxy.api_deadline_key", oldValue); 
/* 108 */     }throw localObject1;
/*     */   }
/*     */ 
/*     */   public static Future<byte[]> makeAsyncCall(String packageName, String methodName, byte[] request)
/*     */   {
/* 120 */     return makeAsyncCall(packageName, methodName, request, new ApiConfig());
/*     */   }
/*     */ 
/*     */   public static Future<byte[]> makeAsyncCall(String packageName, String methodName, byte[] request, ApiConfig apiConfig)
/*     */   {
/* 154 */     Environment env = getCurrentEnvironment();
/* 155 */     if ((delegate == null) || (env == null))
/*     */     {
/* 159 */       return new Future(packageName, methodName) {
/*     */         public byte[] get() {
/* 161 */           throw new ApiProxy.CallNotFoundException(this.val$packageName, this.val$methodName);
/*     */         }
/*     */ 
/*     */         public byte[] get(long deadline, TimeUnit unit) {
/* 165 */           throw new ApiProxy.CallNotFoundException(this.val$packageName, this.val$methodName);
/*     */         }
/*     */ 
/*     */         public boolean isDone() {
/* 169 */           return true;
/*     */         }
/*     */ 
/*     */         public boolean isCancelled() {
/* 173 */           return false;
/*     */         }
/*     */ 
/*     */         public boolean cancel(boolean shouldInterrupt) {
/* 177 */           return false;
/*     */         } } ;
/*     */     }
/* 181 */     return delegate.makeAsyncCall(env, packageName, methodName, request, apiConfig);
/*     */   }
/*     */ 
/*     */   public static void log(LogRecord record)
/*     */   {
/* 186 */     if (delegate != null)
/* 187 */       delegate.log(getCurrentEnvironment(), record);
/*     */   }
/*     */ 
/*     */   public static Environment getCurrentEnvironment()
/*     */   {
/* 196 */     return (Environment)environmentThreadLocal.get();
/*     */   }
/*     */ 
/*     */   public static void setDelegate(Delegate aDelegate)
/*     */   {
/* 204 */     delegate = aDelegate;
/*     */   }
/*     */ 
/*     */   public static Delegate getDelegate()
/*     */   {
/* 214 */     return delegate;
/*     */   }
/*     */ 
/*     */   public static void setEnvironmentForCurrentThread(Environment environment)
/*     */   {
/* 227 */     environmentThreadLocal.set(environment);
/*     */   }
/*     */ 
/*     */   public static void clearEnvironmentForCurrentThread()
/*     */   {
/* 235 */     environmentThreadLocal.set(null);
/*     */   }
/*     */ 
/*     */   public static class UnknownException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public UnknownException(String packageName, String methodName, Throwable nestedException)
/*     */     {
/* 574 */       super(packageName, methodName, nestedException, null);
/*     */     }
/*     */ 
/*     */     public UnknownException(String packageName, String methodName)
/*     */     {
/* 579 */       super(packageName, methodName);
/*     */     }
/*     */ 
/*     */     public UnknownException(String message)
/*     */     {
/* 584 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class RequestTooLargeException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public RequestTooLargeException(String packageName, String methodName)
/*     */     {
/* 563 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class OverQuotaException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public OverQuotaException(String packageName, String methodName)
/*     */     {
/* 556 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class FeatureNotEnabledException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public FeatureNotEnabledException(String message, String packageName, String methodName)
/*     */     {
/* 550 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CapabilityDisabledException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public CapabilityDisabledException(String packageName, String methodName)
/*     */     {
/* 541 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CancelledException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public CancelledException(String packageName, String methodName)
/*     */     {
/* 534 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ApiDeadlineExceededException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public ApiDeadlineExceededException(String packageName, String methodName)
/*     */     {
/* 527 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ArgumentException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public ArgumentException(String packageName, String methodName)
/*     */     {
/* 519 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CallNotFoundException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public CallNotFoundException(String packageName, String methodName)
/*     */     {
/* 512 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class RPCFailedException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     public RPCFailedException(String packageName, String methodName)
/*     */     {
/* 504 */       super(packageName, methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ApplicationException extends ApiProxy.ApiProxyException
/*     */   {
/*     */     private final int applicationError;
/*     */     private final String errorDetail;
/*     */ 
/*     */     public ApplicationException(int applicationError)
/*     */     {
/* 484 */       this(applicationError, "");
/*     */     }
/*     */ 
/*     */     public ApplicationException(int applicationError, String errorDetail) {
/* 488 */       super();
/* 489 */       this.applicationError = applicationError;
/* 490 */       this.errorDetail = errorDetail;
/*     */     }
/*     */ 
/*     */     public int getApplicationError() {
/* 494 */       return this.applicationError;
/*     */     }
/*     */ 
/*     */     public String getErrorDetail() {
/* 498 */       return this.errorDetail;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ApiProxyException extends RuntimeException
/*     */   {
/*     */     public ApiProxyException(String message, String packageName, String methodName)
/*     */     {
/* 466 */       this(String.format(message, new Object[] { packageName, methodName }));
/*     */     }
/*     */ 
/*     */     private ApiProxyException(String message, String packageName, String methodName, Throwable nestedException)
/*     */     {
/* 471 */       super(nestedException);
/*     */     }
/*     */ 
/*     */     public ApiProxyException(String message) {
/* 475 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface ApiResultFuture<T> extends Future<T>
/*     */   {
/*     */     public abstract long getCpuTimeInMegaCycles();
/*     */ 
/*     */     public abstract long getWallclockTimeInMillis();
/*     */   }
/*     */ 
/*     */   public static final class ApiConfig
/*     */   {
/*     */     private Double deadlineInSeconds;
/*     */ 
/*     */     public Double getDeadlineInSeconds()
/*     */     {
/* 419 */       return this.deadlineInSeconds;
/*     */     }
/*     */ 
/*     */     public void setDeadlineInSeconds(Double deadlineInSeconds)
/*     */     {
/* 427 */       this.deadlineInSeconds = deadlineInSeconds;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class LogRecord
/*     */   {
/*     */     private final Level level;
/*     */     private final long timestamp;
/*     */     private final String message;
/*     */ 
/*     */     public LogRecord(Level level, long timestamp, String message)
/*     */     {
/* 386 */       this.level = level;
/* 387 */       this.timestamp = timestamp;
/* 388 */       this.message = message;
/*     */     }
/*     */ 
/*     */     public Level getLevel() {
/* 392 */       return this.level;
/*     */     }
/*     */ 
/*     */     public long getTimestamp()
/*     */     {
/* 399 */       return this.timestamp;
/*     */     }
/*     */ 
/*     */     public String getMessage() {
/* 403 */       return this.message;
/*     */     }
/*     */ 
/*     */     public static enum Level
/*     */     {
/* 378 */       debug, 
/* 379 */       info, 
/* 380 */       warn, 
/* 381 */       error, 
/* 382 */       fatal;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface Delegate<E extends ApiProxy.Environment>
/*     */   {
/*     */     public abstract byte[] makeSyncCall(E paramE, String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */       throws ApiProxy.ApiProxyException;
/*     */ 
/*     */     public abstract Future<byte[]> makeAsyncCall(E paramE, String paramString1, String paramString2, byte[] paramArrayOfByte, ApiProxy.ApiConfig paramApiConfig);
/*     */ 
/*     */     public abstract void log(E paramE, ApiProxy.LogRecord paramLogRecord);
/*     */   }
/*     */ 
/*     */   public static abstract interface Environment
/*     */   {
/*     */     public abstract String getAppId();
/*     */ 
/*     */     public abstract String getVersionId();
/*     */ 
/*     */     public abstract String getEmail();
/*     */ 
/*     */     public abstract boolean isLoggedIn();
/*     */ 
/*     */     public abstract boolean isAdmin();
/*     */ 
/*     */     public abstract String getAuthDomain();
/*     */ 
/*     */     @Deprecated
/*     */     public abstract String getRequestNamespace();
/*     */ 
/*     */     public abstract Map<String, Object> getAttributes();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.api.ApiProxy
 * JD-Core Version:    0.6.0
 */