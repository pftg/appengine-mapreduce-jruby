/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*    */ import com.google.apphosting.api.DatastorePb.CompiledCursor;
/*    */ import com.google.apphosting.api.DatastorePb.Cursor;
/*    */ import com.google.apphosting.api.DatastorePb.NextRequest;
/*    */ import com.google.apphosting.api.DatastorePb.QueryResult;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ class QueryResultsSourceImpl
/*    */   implements QueryResultsSource
/*    */ {
/*    */   private DatastorePb.Cursor cursor;
/*    */   private DatastorePb.CompiledCursor compiledCursor;
/*    */   private transient boolean moreResults;
/*    */   private final ApiProxy.ApiConfig apiConfig;
/*    */   private final int chunkSize;
/*    */   private final Transaction txn;
/*    */   private static final int AT_LEAST_ONE = -1;
/*    */ 
/*    */   public QueryResultsSourceImpl(ApiProxy.ApiConfig apiConfig, FetchOptions fetchOptions, Transaction txn)
/*    */   {
/* 32 */     this.apiConfig = apiConfig;
/* 33 */     this.chunkSize = (fetchOptions.getChunkSize() != null ? fetchOptions.getChunkSize().intValue() : -1);
/*    */ 
/* 35 */     this.moreResults = false;
/* 36 */     this.txn = txn;
/*    */   }
/*    */ 
/*    */   public List<Entity> loadFromPb(DatastorePb.QueryResult queryResult) {
/* 40 */     this.cursor = queryResult.getCursor();
/* 41 */     return processQueryResult(queryResult);
/*    */   }
/*    */ 
/*    */   public boolean hasMoreEntities() {
/* 45 */     return this.moreResults;
/*    */   }
/*    */ 
/*    */   private List<Entity> processQueryResult(DatastorePb.QueryResult result) {
/* 49 */     this.moreResults = result.isMoreResults();
/* 50 */     this.compiledCursor = (result.hasCompiledCursor() ? result.getCompiledCursor() : null);
/*    */ 
/* 53 */     List loadedEntities = new ArrayList(result.resultSize());
/* 54 */     for (OnestoreEntity.EntityProto entityProto : result.results()) {
/* 55 */       loadedEntities.add(EntityTranslator.createFromPb(entityProto));
/*    */     }
/*    */ 
/* 58 */     return loadedEntities;
/*    */   }
/*    */ 
/*    */   public List<Entity> getMoreEntities() {
/* 62 */     return getMoreEntities(-1);
/*    */   }
/*    */ 
/*    */   public List<Entity> getMoreEntities(int numberToLoad) {
/* 66 */     TransactionImpl.ensureTxnActive(this.txn);
/* 67 */     if (this.moreResults) {
/* 68 */       DatastorePb.NextRequest req = new DatastorePb.NextRequest();
/* 69 */       req.getMutableCursor().copyFrom(this.cursor);
/*    */ 
/* 71 */       if (numberToLoad < this.chunkSize) {
/* 72 */         numberToLoad = this.chunkSize;
/*    */       }
/*    */ 
/* 75 */       if (numberToLoad != -1) {
/* 76 */         req.setCount(numberToLoad);
/*    */       }
/*    */ 
/* 79 */       if (this.compiledCursor != null)
/*    */       {
/* 81 */         req.setCompile(true);
/*    */       }
/*    */ 
/* 84 */       DatastorePb.QueryResult result = new DatastorePb.QueryResult();
/* 85 */       DatastoreApiHelper.makeSyncCall(this.apiConfig, "Next", req, result);
/* 86 */       return processQueryResult(result);
/*    */     }
/* 88 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   public Cursor getCursor() {
/* 92 */     if (this.compiledCursor != null) {
/* 93 */       return new Cursor(this.compiledCursor);
/*    */     }
/* 95 */     return null;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.QueryResultsSourceImpl
 * JD-Core Version:    0.6.0
 */