/*    */ package javax.mail;
/*    */ 
/*    */ public class StoreClosedException extends MessagingException
/*    */ {
/*    */   private transient Store _store;
/*    */ 
/*    */   public StoreClosedException(Store store)
/*    */   {
/* 30 */     this._store = store;
/*    */   }
/*    */ 
/*    */   public StoreClosedException(Store store, String message) {
/* 34 */     super(message);
/*    */   }
/*    */ 
/*    */   public Store getStore() {
/* 38 */     return this._store;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.StoreClosedException
 * JD-Core Version:    0.6.0
 */