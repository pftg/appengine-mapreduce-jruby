/*      */ package com.google.appengine.tools.appstats;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.Descriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.Builder;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet.Builder;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class StatsProtos
/*      */ {
/*      */   private static Descriptors.Descriptor internal_static_apphosting_AggregateRpcStatsProto_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_AggregateRpcStatsProto_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_KeyValProto_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_KeyValProto_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_StackFrameProto_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_StackFrameProto_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_IndividualRpcStatsProto_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_IndividualRpcStatsProto_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_RequestStatProto_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_RequestStatProto_fieldAccessorTable;
/*      */   private static Descriptors.FileDescriptor descriptor;
/*      */ 
/*      */   public static void registerAllExtensions(ExtensionRegistry registry)
/*      */   {
/*      */   }
/*      */ 
/*      */   public static Descriptors.FileDescriptor getDescriptor()
/*      */   {
/* 3178 */     return descriptor;
/*      */   }
/*      */   public static void internalForceInit() {
/*      */   }
/*      */   static {
/* 3183 */     String[] descriptorData = { "\n'apphosting/ext/appstats/datamodel.proto\022\napphosting\"R\n\026AggregateRpcStatsProto\022\031\n\021service_call_name\030\001 \002(\t\022\035\n\025total_amount_of_calls\030\003 \002(\003\")\n\013KeyValProto\022\013\n\003key\030\001 \002(\t\022\r\n\005value\030\002 \002(\t\"\001\n\017StackFrameProto\022\032\n\022class_or_file_name\030\001 \002(\t\022\023\n\013line_number\030\002 \001(\005\022\025\n\rfunction_name\030\003 \002(\t\022*\n\tvariables\030\004 \003(\0132\027.apphosting.KeyValProto\"¯\002\n\027IndividualRpcStatsProto\022\031\n\021service_call_name\030\001 \002(\t\022\034\n\024request_data_summary\030\003 \001(", "", "\030\006 \002(\003\022\023\n\013api_mcycles\030\007 \001(\003\022\031\n\021processor_mcycles\030\b \001(\003\0225\n\trpc_stats\030\t \003(\0132\".apphosting.AggregateRpcStatsProto\022(\n\007cgi_env\030e \003(\0132\027.apphosting.KeyValProto\022&\n\036overhead_walltime_milliseconds\030f \001(\003\022\022\n\nuser_email\030g \001(\t\022\020\n\bis_admin\030h \001(\b\022=\n\020individual_stats\030k \003(\0132#.apphosting.IndividualRpcStatsProtoB4\n#com.google.appengine.tools.appstatsB\013StatsProtosH\001" };
/*      */ 
/* 3214 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*      */     {
/*      */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*      */       {
/* 3218 */         StatsProtos.access$8202(root);
/* 3219 */         StatsProtos.access$002((Descriptors.Descriptor)StatsProtos.getDescriptor().getMessageTypes().get(0));
/*      */ 
/* 3221 */         StatsProtos.access$102(new GeneratedMessage.FieldAccessorTable(StatsProtos.internal_static_apphosting_AggregateRpcStatsProto_descriptor, new String[] { "ServiceCallName", "TotalAmountOfCalls" }, StatsProtos.AggregateRpcStatsProto.class, StatsProtos.AggregateRpcStatsProto.Builder.class));
/*      */ 
/* 3227 */         StatsProtos.access$902((Descriptors.Descriptor)StatsProtos.getDescriptor().getMessageTypes().get(1));
/*      */ 
/* 3229 */         StatsProtos.access$1002(new GeneratedMessage.FieldAccessorTable(StatsProtos.internal_static_apphosting_KeyValProto_descriptor, new String[] { "Key", "Value" }, StatsProtos.KeyValProto.class, StatsProtos.KeyValProto.Builder.class));
/*      */ 
/* 3235 */         StatsProtos.access$1802((Descriptors.Descriptor)StatsProtos.getDescriptor().getMessageTypes().get(2));
/*      */ 
/* 3237 */         StatsProtos.access$1902(new GeneratedMessage.FieldAccessorTable(StatsProtos.internal_static_apphosting_StackFrameProto_descriptor, new String[] { "ClassOrFileName", "LineNumber", "FunctionName", "Variables" }, StatsProtos.StackFrameProto.class, StatsProtos.StackFrameProto.Builder.class));
/*      */ 
/* 3243 */         StatsProtos.access$3002((Descriptors.Descriptor)StatsProtos.getDescriptor().getMessageTypes().get(3));
/*      */ 
/* 3245 */         StatsProtos.access$3102(new GeneratedMessage.FieldAccessorTable(StatsProtos.internal_static_apphosting_IndividualRpcStatsProto_descriptor, new String[] { "ServiceCallName", "RequestDataSummary", "ResponseDataSummary", "ApiMcycles", "StartOffsetMilliseconds", "DurationMilliseconds", "Namespace", "WasSuccessful", "CallStack" }, StatsProtos.IndividualRpcStatsProto.class, StatsProtos.IndividualRpcStatsProto.Builder.class));
/*      */ 
/* 3251 */         StatsProtos.access$5202((Descriptors.Descriptor)StatsProtos.getDescriptor().getMessageTypes().get(4));
/*      */ 
/* 3253 */         StatsProtos.access$5302(new GeneratedMessage.FieldAccessorTable(StatsProtos.internal_static_apphosting_RequestStatProto_descriptor, new String[] { "StartTimestampMilliseconds", "HttpMethod", "HttpPath", "HttpQuery", "HttpStatus", "DurationMilliseconds", "ApiMcycles", "ProcessorMcycles", "RpcStats", "CgiEnv", "OverheadWalltimeMilliseconds", "UserEmail", "IsAdmin", "IndividualStats" }, StatsProtos.RequestStatProto.class, StatsProtos.RequestStatProto.Builder.class));
/*      */ 
/* 3259 */         return null;
/*      */       }
/*      */     };
/* 3262 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/*      */   }
/*      */ 
/*      */   public static final class RequestStatProto extends GeneratedMessage
/*      */   {
/* 3142 */     private static final RequestStatProto defaultInstance = new RequestStatProto(true);
/*      */     public static final int START_TIMESTAMP_MILLISECONDS_FIELD_NUMBER = 1;
/*      */     private boolean hasStartTimestampMilliseconds;
/*      */     private long startTimestampMilliseconds_;
/*      */     public static final int HTTP_METHOD_FIELD_NUMBER = 2;
/*      */     private boolean hasHttpMethod;
/*      */     private String httpMethod_;
/*      */     public static final int HTTP_PATH_FIELD_NUMBER = 3;
/*      */     private boolean hasHttpPath;
/*      */     private String httpPath_;
/*      */     public static final int HTTP_QUERY_FIELD_NUMBER = 4;
/*      */     private boolean hasHttpQuery;
/*      */     private String httpQuery_;
/*      */     public static final int HTTP_STATUS_FIELD_NUMBER = 5;
/*      */     private boolean hasHttpStatus;
/*      */     private int httpStatus_;
/*      */     public static final int DURATION_MILLISECONDS_FIELD_NUMBER = 6;
/*      */     private boolean hasDurationMilliseconds;
/*      */     private long durationMilliseconds_;
/*      */     public static final int API_MCYCLES_FIELD_NUMBER = 7;
/*      */     private boolean hasApiMcycles;
/*      */     private long apiMcycles_;
/*      */     public static final int PROCESSOR_MCYCLES_FIELD_NUMBER = 8;
/*      */     private boolean hasProcessorMcycles;
/*      */     private long processorMcycles_;
/*      */     public static final int RPC_STATS_FIELD_NUMBER = 9;
/*      */     private List<StatsProtos.AggregateRpcStatsProto> rpcStats_;
/*      */     public static final int CGI_ENV_FIELD_NUMBER = 101;
/*      */     private List<StatsProtos.KeyValProto> cgiEnv_;
/*      */     public static final int OVERHEAD_WALLTIME_MILLISECONDS_FIELD_NUMBER = 102;
/*      */     private boolean hasOverheadWalltimeMilliseconds;
/*      */     private long overheadWalltimeMilliseconds_;
/*      */     public static final int USER_EMAIL_FIELD_NUMBER = 103;
/*      */     private boolean hasUserEmail;
/*      */     private String userEmail_;
/*      */     public static final int IS_ADMIN_FIELD_NUMBER = 104;
/*      */     private boolean hasIsAdmin;
/*      */     private boolean isAdmin_;
/*      */     public static final int INDIVIDUAL_STATS_FIELD_NUMBER = 107;
/*      */     private List<StatsProtos.IndividualRpcStatsProto> individualStats_;
/* 2276 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private RequestStatProto(Builder builder)
/*      */     {
/* 2014 */       super();
/*      */     }
/*      */     private RequestStatProto(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static RequestStatProto getDefaultInstance() {
/* 2020 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public RequestStatProto getDefaultInstanceForType() {
/* 2024 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 2029 */       return StatsProtos.internal_static_apphosting_RequestStatProto_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 2034 */       return StatsProtos.internal_static_apphosting_RequestStatProto_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasStartTimestampMilliseconds()
/*      */     {
/* 2042 */       return this.hasStartTimestampMilliseconds;
/*      */     }
/*      */     public long getStartTimestampMilliseconds() {
/* 2045 */       return this.startTimestampMilliseconds_;
/*      */     }
/*      */ 
/*      */     public boolean hasHttpMethod()
/*      */     {
/* 2053 */       return this.hasHttpMethod;
/*      */     }
/*      */     public String getHttpMethod() {
/* 2056 */       return this.httpMethod_;
/*      */     }
/*      */ 
/*      */     public boolean hasHttpPath()
/*      */     {
/* 2064 */       return this.hasHttpPath;
/*      */     }
/*      */     public String getHttpPath() {
/* 2067 */       return this.httpPath_;
/*      */     }
/*      */ 
/*      */     public boolean hasHttpQuery()
/*      */     {
/* 2075 */       return this.hasHttpQuery;
/*      */     }
/*      */     public String getHttpQuery() {
/* 2078 */       return this.httpQuery_;
/*      */     }
/*      */ 
/*      */     public boolean hasHttpStatus()
/*      */     {
/* 2086 */       return this.hasHttpStatus;
/*      */     }
/*      */     public int getHttpStatus() {
/* 2089 */       return this.httpStatus_;
/*      */     }
/*      */ 
/*      */     public boolean hasDurationMilliseconds()
/*      */     {
/* 2097 */       return this.hasDurationMilliseconds;
/*      */     }
/*      */     public long getDurationMilliseconds() {
/* 2100 */       return this.durationMilliseconds_;
/*      */     }
/*      */ 
/*      */     public boolean hasApiMcycles()
/*      */     {
/* 2108 */       return this.hasApiMcycles;
/*      */     }
/*      */     public long getApiMcycles() {
/* 2111 */       return this.apiMcycles_;
/*      */     }
/*      */ 
/*      */     public boolean hasProcessorMcycles()
/*      */     {
/* 2119 */       return this.hasProcessorMcycles;
/*      */     }
/*      */     public long getProcessorMcycles() {
/* 2122 */       return this.processorMcycles_;
/*      */     }
/*      */ 
/*      */     public List<StatsProtos.AggregateRpcStatsProto> getRpcStatsList()
/*      */     {
/* 2129 */       return this.rpcStats_;
/*      */     }
/*      */     public int getRpcStatsCount() {
/* 2132 */       return this.rpcStats_.size();
/*      */     }
/*      */     public StatsProtos.AggregateRpcStatsProto getRpcStats(int index) {
/* 2135 */       return (StatsProtos.AggregateRpcStatsProto)this.rpcStats_.get(index);
/*      */     }
/*      */ 
/*      */     public List<StatsProtos.KeyValProto> getCgiEnvList()
/*      */     {
/* 2142 */       return this.cgiEnv_;
/*      */     }
/*      */     public int getCgiEnvCount() {
/* 2145 */       return this.cgiEnv_.size();
/*      */     }
/*      */     public StatsProtos.KeyValProto getCgiEnv(int index) {
/* 2148 */       return (StatsProtos.KeyValProto)this.cgiEnv_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasOverheadWalltimeMilliseconds()
/*      */     {
/* 2156 */       return this.hasOverheadWalltimeMilliseconds;
/*      */     }
/*      */     public long getOverheadWalltimeMilliseconds() {
/* 2159 */       return this.overheadWalltimeMilliseconds_;
/*      */     }
/*      */ 
/*      */     public boolean hasUserEmail()
/*      */     {
/* 2167 */       return this.hasUserEmail;
/*      */     }
/*      */     public String getUserEmail() {
/* 2170 */       return this.userEmail_;
/*      */     }
/*      */ 
/*      */     public boolean hasIsAdmin()
/*      */     {
/* 2178 */       return this.hasIsAdmin;
/*      */     }
/*      */     public boolean getIsAdmin() {
/* 2181 */       return this.isAdmin_;
/*      */     }
/*      */ 
/*      */     public List<StatsProtos.IndividualRpcStatsProto> getIndividualStatsList()
/*      */     {
/* 2188 */       return this.individualStats_;
/*      */     }
/*      */     public int getIndividualStatsCount() {
/* 2191 */       return this.individualStats_.size();
/*      */     }
/*      */     public StatsProtos.IndividualRpcStatsProto getIndividualStats(int index) {
/* 2194 */       return (StatsProtos.IndividualRpcStatsProto)this.individualStats_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 2198 */       this.startTimestampMilliseconds_ = 0L;
/* 2199 */       this.httpMethod_ = "GET";
/* 2200 */       this.httpPath_ = "/";
/* 2201 */       this.httpQuery_ = "";
/* 2202 */       this.httpStatus_ = 200;
/* 2203 */       this.durationMilliseconds_ = 0L;
/* 2204 */       this.apiMcycles_ = 0L;
/* 2205 */       this.processorMcycles_ = 0L;
/* 2206 */       this.rpcStats_ = Collections.emptyList();
/* 2207 */       this.cgiEnv_ = Collections.emptyList();
/* 2208 */       this.overheadWalltimeMilliseconds_ = 0L;
/* 2209 */       this.userEmail_ = "";
/* 2210 */       this.isAdmin_ = false;
/* 2211 */       this.individualStats_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 2214 */       if (!this.hasStartTimestampMilliseconds) return false;
/* 2215 */       if (!this.hasDurationMilliseconds) return false;
/* 2216 */       for (StatsProtos.AggregateRpcStatsProto element : getRpcStatsList()) {
/* 2217 */         if (!element.isInitialized()) return false;
/*      */       }
/* 2219 */       for (StatsProtos.KeyValProto element : getCgiEnvList()) {
/* 2220 */         if (!element.isInitialized()) return false;
/*      */       }
/* 2222 */       for (StatsProtos.IndividualRpcStatsProto element : getIndividualStatsList()) {
/* 2223 */         if (!element.isInitialized()) return false;
/*      */       }
/* 2225 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 2230 */       getSerializedSize();
/* 2231 */       if (hasStartTimestampMilliseconds()) {
/* 2232 */         output.writeInt64(1, getStartTimestampMilliseconds());
/*      */       }
/* 2234 */       if (hasHttpMethod()) {
/* 2235 */         output.writeString(2, getHttpMethod());
/*      */       }
/* 2237 */       if (hasHttpPath()) {
/* 2238 */         output.writeString(3, getHttpPath());
/*      */       }
/* 2240 */       if (hasHttpQuery()) {
/* 2241 */         output.writeString(4, getHttpQuery());
/*      */       }
/* 2243 */       if (hasHttpStatus()) {
/* 2244 */         output.writeInt32(5, getHttpStatus());
/*      */       }
/* 2246 */       if (hasDurationMilliseconds()) {
/* 2247 */         output.writeInt64(6, getDurationMilliseconds());
/*      */       }
/* 2249 */       if (hasApiMcycles()) {
/* 2250 */         output.writeInt64(7, getApiMcycles());
/*      */       }
/* 2252 */       if (hasProcessorMcycles()) {
/* 2253 */         output.writeInt64(8, getProcessorMcycles());
/*      */       }
/* 2255 */       for (StatsProtos.AggregateRpcStatsProto element : getRpcStatsList()) {
/* 2256 */         output.writeMessage(9, element);
/*      */       }
/* 2258 */       for (StatsProtos.KeyValProto element : getCgiEnvList()) {
/* 2259 */         output.writeMessage(101, element);
/*      */       }
/* 2261 */       if (hasOverheadWalltimeMilliseconds()) {
/* 2262 */         output.writeInt64(102, getOverheadWalltimeMilliseconds());
/*      */       }
/* 2264 */       if (hasUserEmail()) {
/* 2265 */         output.writeString(103, getUserEmail());
/*      */       }
/* 2267 */       if (hasIsAdmin()) {
/* 2268 */         output.writeBool(104, getIsAdmin());
/*      */       }
/* 2270 */       for (StatsProtos.IndividualRpcStatsProto element : getIndividualStatsList()) {
/* 2271 */         output.writeMessage(107, element);
/*      */       }
/* 2273 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 2278 */       int size = this.memoizedSerializedSize;
/* 2279 */       if (size != -1) return size;
/*      */ 
/* 2281 */       size = 0;
/* 2282 */       if (hasStartTimestampMilliseconds()) {
/* 2283 */         size += CodedOutputStream.computeInt64Size(1, getStartTimestampMilliseconds());
/*      */       }
/*      */ 
/* 2286 */       if (hasHttpMethod()) {
/* 2287 */         size += CodedOutputStream.computeStringSize(2, getHttpMethod());
/*      */       }
/*      */ 
/* 2290 */       if (hasHttpPath()) {
/* 2291 */         size += CodedOutputStream.computeStringSize(3, getHttpPath());
/*      */       }
/*      */ 
/* 2294 */       if (hasHttpQuery()) {
/* 2295 */         size += CodedOutputStream.computeStringSize(4, getHttpQuery());
/*      */       }
/*      */ 
/* 2298 */       if (hasHttpStatus()) {
/* 2299 */         size += CodedOutputStream.computeInt32Size(5, getHttpStatus());
/*      */       }
/*      */ 
/* 2302 */       if (hasDurationMilliseconds()) {
/* 2303 */         size += CodedOutputStream.computeInt64Size(6, getDurationMilliseconds());
/*      */       }
/*      */ 
/* 2306 */       if (hasApiMcycles()) {
/* 2307 */         size += CodedOutputStream.computeInt64Size(7, getApiMcycles());
/*      */       }
/*      */ 
/* 2310 */       if (hasProcessorMcycles()) {
/* 2311 */         size += CodedOutputStream.computeInt64Size(8, getProcessorMcycles());
/*      */       }
/*      */ 
/* 2314 */       for (StatsProtos.AggregateRpcStatsProto element : getRpcStatsList()) {
/* 2315 */         size += CodedOutputStream.computeMessageSize(9, element);
/*      */       }
/*      */ 
/* 2318 */       for (StatsProtos.KeyValProto element : getCgiEnvList()) {
/* 2319 */         size += CodedOutputStream.computeMessageSize(101, element);
/*      */       }
/*      */ 
/* 2322 */       if (hasOverheadWalltimeMilliseconds()) {
/* 2323 */         size += CodedOutputStream.computeInt64Size(102, getOverheadWalltimeMilliseconds());
/*      */       }
/*      */ 
/* 2326 */       if (hasUserEmail()) {
/* 2327 */         size += CodedOutputStream.computeStringSize(103, getUserEmail());
/*      */       }
/*      */ 
/* 2330 */       if (hasIsAdmin()) {
/* 2331 */         size += CodedOutputStream.computeBoolSize(104, getIsAdmin());
/*      */       }
/*      */ 
/* 2334 */       for (StatsProtos.IndividualRpcStatsProto element : getIndividualStatsList()) {
/* 2335 */         size += CodedOutputStream.computeMessageSize(107, element);
/*      */       }
/*      */ 
/* 2338 */       size += getUnknownFields().getSerializedSize();
/* 2339 */       this.memoizedSerializedSize = size;
/* 2340 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 2345 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2351 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2357 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 2362 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 2368 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(InputStream input) throws IOException
/*      */     {
/* 2373 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2379 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 2384 */       Builder builder = newBuilder();
/* 2385 */       if (builder.mergeDelimitedFrom(input)) {
/* 2386 */         return builder.buildParsed();
/*      */       }
/* 2388 */       return null;
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2395 */       Builder builder = newBuilder();
/* 2396 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 2397 */         return builder.buildParsed();
/*      */       }
/* 2399 */       return null;
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 2405 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static RequestStatProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 2411 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 2415 */       return Builder.access$5500(); } 
/* 2416 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(RequestStatProto prototype) {
/* 2418 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 2420 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 3143 */       StatsProtos.internalForceInit();
/* 3144 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasStartTimestampMilliseconds;
/*      */       private long startTimestampMilliseconds_;
/*      */       private boolean hasHttpMethod;
/* 2748 */       private String httpMethod_ = "GET";
/*      */       private boolean hasHttpPath;
/* 2771 */       private String httpPath_ = "/";
/*      */       private boolean hasHttpQuery;
/* 2794 */       private String httpQuery_ = "";
/*      */       private boolean hasHttpStatus;
/* 2817 */       private int httpStatus_ = 200;
/*      */       private boolean hasDurationMilliseconds;
/*      */       private long durationMilliseconds_;
/*      */       private boolean hasApiMcycles;
/*      */       private long apiMcycles_;
/*      */       private boolean hasProcessorMcycles;
/*      */       private long processorMcycles_;
/* 2896 */       private List<StatsProtos.AggregateRpcStatsProto> rpcStats_ = Collections.emptyList();
/*      */       private boolean isRpcStatsMutable;
/* 2956 */       private List<StatsProtos.KeyValProto> cgiEnv_ = Collections.emptyList();
/*      */       private boolean isCgiEnvMutable;
/*      */       private boolean hasOverheadWalltimeMilliseconds;
/*      */       private long overheadWalltimeMilliseconds_;
/*      */       private boolean hasUserEmail;
/* 3037 */       private String userEmail_ = "";
/*      */       private boolean hasIsAdmin;
/*      */       private boolean isAdmin_;
/* 3079 */       private List<StatsProtos.IndividualRpcStatsProto> individualStats_ = Collections.emptyList();
/*      */       private boolean isIndividualStatsMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 2426 */         return StatsProtos.internal_static_apphosting_RequestStatProto_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 2431 */         return StatsProtos.internal_static_apphosting_RequestStatProto_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 2439 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 2443 */         super.clear();
/* 2444 */         this.startTimestampMilliseconds_ = 0L;
/* 2445 */         this.hasStartTimestampMilliseconds = false;
/* 2446 */         this.httpMethod_ = "GET";
/* 2447 */         this.hasHttpMethod = false;
/* 2448 */         this.httpPath_ = "/";
/* 2449 */         this.hasHttpPath = false;
/* 2450 */         this.httpQuery_ = "";
/* 2451 */         this.hasHttpQuery = false;
/* 2452 */         this.httpStatus_ = 200;
/* 2453 */         this.hasHttpStatus = false;
/* 2454 */         this.durationMilliseconds_ = 0L;
/* 2455 */         this.hasDurationMilliseconds = false;
/* 2456 */         this.apiMcycles_ = 0L;
/* 2457 */         this.hasApiMcycles = false;
/* 2458 */         this.processorMcycles_ = 0L;
/* 2459 */         this.hasProcessorMcycles = false;
/* 2460 */         this.rpcStats_ = Collections.emptyList();
/* 2461 */         this.isRpcStatsMutable = false;
/* 2462 */         this.cgiEnv_ = Collections.emptyList();
/* 2463 */         this.isCgiEnvMutable = false;
/* 2464 */         this.overheadWalltimeMilliseconds_ = 0L;
/* 2465 */         this.hasOverheadWalltimeMilliseconds = false;
/* 2466 */         this.userEmail_ = "";
/* 2467 */         this.hasUserEmail = false;
/* 2468 */         this.isAdmin_ = false;
/* 2469 */         this.hasIsAdmin = false;
/* 2470 */         this.individualStats_ = Collections.emptyList();
/* 2471 */         this.isIndividualStatsMutable = false;
/* 2472 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 2476 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 2481 */         return StatsProtos.RequestStatProto.getDescriptor();
/*      */       }
/*      */ 
/*      */       public StatsProtos.RequestStatProto getDefaultInstanceForType() {
/* 2485 */         return StatsProtos.RequestStatProto.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public StatsProtos.RequestStatProto build() {
/* 2489 */         StatsProtos.RequestStatProto result = buildPartial();
/* 2490 */         if (!result.isInitialized()) {
/* 2491 */           throw newUninitializedMessageException(result);
/*      */         }
/* 2493 */         return result;
/*      */       }
/*      */ 
/*      */       private StatsProtos.RequestStatProto buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 2498 */         StatsProtos.RequestStatProto result = buildPartial();
/* 2499 */         if (!result.isInitialized()) {
/* 2500 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 2503 */         return result;
/*      */       }
/*      */ 
/*      */       public StatsProtos.RequestStatProto buildPartial() {
/* 2507 */         StatsProtos.RequestStatProto result = new StatsProtos.RequestStatProto(this, null);
/* 2508 */         StatsProtos.RequestStatProto.access$5702(result, this.hasStartTimestampMilliseconds);
/* 2509 */         StatsProtos.RequestStatProto.access$5802(result, this.startTimestampMilliseconds_);
/* 2510 */         StatsProtos.RequestStatProto.access$5902(result, this.hasHttpMethod);
/* 2511 */         StatsProtos.RequestStatProto.access$6002(result, this.httpMethod_);
/* 2512 */         StatsProtos.RequestStatProto.access$6102(result, this.hasHttpPath);
/* 2513 */         StatsProtos.RequestStatProto.access$6202(result, this.httpPath_);
/* 2514 */         StatsProtos.RequestStatProto.access$6302(result, this.hasHttpQuery);
/* 2515 */         StatsProtos.RequestStatProto.access$6402(result, this.httpQuery_);
/* 2516 */         StatsProtos.RequestStatProto.access$6502(result, this.hasHttpStatus);
/* 2517 */         StatsProtos.RequestStatProto.access$6602(result, this.httpStatus_);
/* 2518 */         StatsProtos.RequestStatProto.access$6702(result, this.hasDurationMilliseconds);
/* 2519 */         StatsProtos.RequestStatProto.access$6802(result, this.durationMilliseconds_);
/* 2520 */         StatsProtos.RequestStatProto.access$6902(result, this.hasApiMcycles);
/* 2521 */         StatsProtos.RequestStatProto.access$7002(result, this.apiMcycles_);
/* 2522 */         StatsProtos.RequestStatProto.access$7102(result, this.hasProcessorMcycles);
/* 2523 */         StatsProtos.RequestStatProto.access$7202(result, this.processorMcycles_);
/* 2524 */         if (this.isRpcStatsMutable) {
/* 2525 */           this.rpcStats_ = Collections.unmodifiableList(this.rpcStats_);
/* 2526 */           this.isRpcStatsMutable = false;
/*      */         }
/* 2528 */         StatsProtos.RequestStatProto.access$7302(result, this.rpcStats_);
/* 2529 */         if (this.isCgiEnvMutable) {
/* 2530 */           this.cgiEnv_ = Collections.unmodifiableList(this.cgiEnv_);
/* 2531 */           this.isCgiEnvMutable = false;
/*      */         }
/* 2533 */         StatsProtos.RequestStatProto.access$7402(result, this.cgiEnv_);
/* 2534 */         StatsProtos.RequestStatProto.access$7502(result, this.hasOverheadWalltimeMilliseconds);
/* 2535 */         StatsProtos.RequestStatProto.access$7602(result, this.overheadWalltimeMilliseconds_);
/* 2536 */         StatsProtos.RequestStatProto.access$7702(result, this.hasUserEmail);
/* 2537 */         StatsProtos.RequestStatProto.access$7802(result, this.userEmail_);
/* 2538 */         StatsProtos.RequestStatProto.access$7902(result, this.hasIsAdmin);
/* 2539 */         StatsProtos.RequestStatProto.access$8002(result, this.isAdmin_);
/* 2540 */         if (this.isIndividualStatsMutable) {
/* 2541 */           this.individualStats_ = Collections.unmodifiableList(this.individualStats_);
/* 2542 */           this.isIndividualStatsMutable = false;
/*      */         }
/* 2544 */         StatsProtos.RequestStatProto.access$8102(result, this.individualStats_);
/* 2545 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 2549 */         if ((other instanceof StatsProtos.RequestStatProto)) {
/* 2550 */           return mergeFrom((StatsProtos.RequestStatProto)other);
/*      */         }
/* 2552 */         super.mergeFrom(other);
/* 2553 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(StatsProtos.RequestStatProto other)
/*      */       {
/* 2558 */         if (other == StatsProtos.RequestStatProto.getDefaultInstance()) return this;
/* 2559 */         if (other.hasStartTimestampMilliseconds()) {
/* 2560 */           setStartTimestampMilliseconds(other.getStartTimestampMilliseconds());
/*      */         }
/* 2562 */         if (other.hasHttpMethod()) {
/* 2563 */           setHttpMethod(other.getHttpMethod());
/*      */         }
/* 2565 */         if (other.hasHttpPath()) {
/* 2566 */           setHttpPath(other.getHttpPath());
/*      */         }
/* 2568 */         if (other.hasHttpQuery()) {
/* 2569 */           setHttpQuery(other.getHttpQuery());
/*      */         }
/* 2571 */         if (other.hasHttpStatus()) {
/* 2572 */           setHttpStatus(other.getHttpStatus());
/*      */         }
/* 2574 */         if (other.hasDurationMilliseconds()) {
/* 2575 */           setDurationMilliseconds(other.getDurationMilliseconds());
/*      */         }
/* 2577 */         if (other.hasApiMcycles()) {
/* 2578 */           setApiMcycles(other.getApiMcycles());
/*      */         }
/* 2580 */         if (other.hasProcessorMcycles()) {
/* 2581 */           setProcessorMcycles(other.getProcessorMcycles());
/*      */         }
/* 2583 */         if (!other.rpcStats_.isEmpty()) {
/* 2584 */           if (this.rpcStats_.isEmpty()) {
/* 2585 */             this.rpcStats_ = other.rpcStats_;
/* 2586 */             this.isRpcStatsMutable = false;
/*      */           } else {
/* 2588 */             ensureRpcStatsIsMutable();
/* 2589 */             this.rpcStats_.addAll(other.rpcStats_);
/*      */           }
/*      */         }
/* 2592 */         if (!other.cgiEnv_.isEmpty()) {
/* 2593 */           if (this.cgiEnv_.isEmpty()) {
/* 2594 */             this.cgiEnv_ = other.cgiEnv_;
/* 2595 */             this.isCgiEnvMutable = false;
/*      */           } else {
/* 2597 */             ensureCgiEnvIsMutable();
/* 2598 */             this.cgiEnv_.addAll(other.cgiEnv_);
/*      */           }
/*      */         }
/* 2601 */         if (other.hasOverheadWalltimeMilliseconds()) {
/* 2602 */           setOverheadWalltimeMilliseconds(other.getOverheadWalltimeMilliseconds());
/*      */         }
/* 2604 */         if (other.hasUserEmail()) {
/* 2605 */           setUserEmail(other.getUserEmail());
/*      */         }
/* 2607 */         if (other.hasIsAdmin()) {
/* 2608 */           setIsAdmin(other.getIsAdmin());
/*      */         }
/* 2610 */         if (!other.individualStats_.isEmpty()) {
/* 2611 */           if (this.individualStats_.isEmpty()) {
/* 2612 */             this.individualStats_ = other.individualStats_;
/* 2613 */             this.isIndividualStatsMutable = false;
/*      */           } else {
/* 2615 */             ensureIndividualStatsIsMutable();
/* 2616 */             this.individualStats_.addAll(other.individualStats_);
/*      */           }
/*      */         }
/* 2619 */         mergeUnknownFields(other.getUnknownFields());
/* 2620 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 2624 */         if (!this.hasStartTimestampMilliseconds) return false;
/* 2625 */         if (!this.hasDurationMilliseconds) return false;
/* 2626 */         for (StatsProtos.AggregateRpcStatsProto element : getRpcStatsList()) {
/* 2627 */           if (!element.isInitialized()) return false;
/*      */         }
/* 2629 */         for (StatsProtos.KeyValProto element : getCgiEnvList()) {
/* 2630 */           if (!element.isInitialized()) return false;
/*      */         }
/* 2632 */         for (StatsProtos.IndividualRpcStatsProto element : getIndividualStatsList()) {
/* 2633 */           if (!element.isInitialized()) return false;
/*      */         }
/* 2635 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 2642 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 2646 */           int tag = input.readTag();
/* 2647 */           switch (tag) {
/*      */           case 0:
/* 2649 */             setUnknownFields(unknownFields.build());
/* 2650 */             return this;
/*      */           default:
/* 2652 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 2654 */             setUnknownFields(unknownFields.build());
/* 2655 */             return this;
/*      */           case 8:
/* 2660 */             setStartTimestampMilliseconds(input.readInt64());
/* 2661 */             break;
/*      */           case 18:
/* 2664 */             setHttpMethod(input.readString());
/* 2665 */             break;
/*      */           case 26:
/* 2668 */             setHttpPath(input.readString());
/* 2669 */             break;
/*      */           case 34:
/* 2672 */             setHttpQuery(input.readString());
/* 2673 */             break;
/*      */           case 40:
/* 2676 */             setHttpStatus(input.readInt32());
/* 2677 */             break;
/*      */           case 48:
/* 2680 */             setDurationMilliseconds(input.readInt64());
/* 2681 */             break;
/*      */           case 56:
/* 2684 */             setApiMcycles(input.readInt64());
/* 2685 */             break;
/*      */           case 64:
/* 2688 */             setProcessorMcycles(input.readInt64());
/* 2689 */             break;
/*      */           case 74:
/* 2692 */             StatsProtos.AggregateRpcStatsProto.Builder subBuilder = StatsProtos.AggregateRpcStatsProto.newBuilder();
/* 2693 */             input.readMessage(subBuilder, extensionRegistry);
/* 2694 */             addRpcStats(subBuilder.buildPartial());
/* 2695 */             break;
/*      */           case 810:
/* 2698 */             StatsProtos.KeyValProto.Builder subBuilder = StatsProtos.KeyValProto.newBuilder();
/* 2699 */             input.readMessage(subBuilder, extensionRegistry);
/* 2700 */             addCgiEnv(subBuilder.buildPartial());
/* 2701 */             break;
/*      */           case 816:
/* 2704 */             setOverheadWalltimeMilliseconds(input.readInt64());
/* 2705 */             break;
/*      */           case 826:
/* 2708 */             setUserEmail(input.readString());
/* 2709 */             break;
/*      */           case 832:
/* 2712 */             setIsAdmin(input.readBool());
/* 2713 */             break;
/*      */           case 858:
/* 2716 */             StatsProtos.IndividualRpcStatsProto.Builder subBuilder = StatsProtos.IndividualRpcStatsProto.newBuilder();
/* 2717 */             input.readMessage(subBuilder, extensionRegistry);
/* 2718 */             addIndividualStats(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasStartTimestampMilliseconds()
/*      */       {
/* 2730 */         return this.hasStartTimestampMilliseconds;
/*      */       }
/*      */       public long getStartTimestampMilliseconds() {
/* 2733 */         return this.startTimestampMilliseconds_;
/*      */       }
/*      */       public Builder setStartTimestampMilliseconds(long value) {
/* 2736 */         this.hasStartTimestampMilliseconds = true;
/* 2737 */         this.startTimestampMilliseconds_ = value;
/* 2738 */         return this;
/*      */       }
/*      */       public Builder clearStartTimestampMilliseconds() {
/* 2741 */         this.hasStartTimestampMilliseconds = false;
/* 2742 */         this.startTimestampMilliseconds_ = 0L;
/* 2743 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasHttpMethod()
/*      */       {
/* 2750 */         return this.hasHttpMethod;
/*      */       }
/*      */       public String getHttpMethod() {
/* 2753 */         return this.httpMethod_;
/*      */       }
/*      */       public Builder setHttpMethod(String value) {
/* 2756 */         if (value == null) {
/* 2757 */           throw new NullPointerException();
/*      */         }
/* 2759 */         this.hasHttpMethod = true;
/* 2760 */         this.httpMethod_ = value;
/* 2761 */         return this;
/*      */       }
/*      */       public Builder clearHttpMethod() {
/* 2764 */         this.hasHttpMethod = false;
/* 2765 */         this.httpMethod_ = StatsProtos.RequestStatProto.getDefaultInstance().getHttpMethod();
/* 2766 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasHttpPath()
/*      */       {
/* 2773 */         return this.hasHttpPath;
/*      */       }
/*      */       public String getHttpPath() {
/* 2776 */         return this.httpPath_;
/*      */       }
/*      */       public Builder setHttpPath(String value) {
/* 2779 */         if (value == null) {
/* 2780 */           throw new NullPointerException();
/*      */         }
/* 2782 */         this.hasHttpPath = true;
/* 2783 */         this.httpPath_ = value;
/* 2784 */         return this;
/*      */       }
/*      */       public Builder clearHttpPath() {
/* 2787 */         this.hasHttpPath = false;
/* 2788 */         this.httpPath_ = StatsProtos.RequestStatProto.getDefaultInstance().getHttpPath();
/* 2789 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasHttpQuery()
/*      */       {
/* 2796 */         return this.hasHttpQuery;
/*      */       }
/*      */       public String getHttpQuery() {
/* 2799 */         return this.httpQuery_;
/*      */       }
/*      */       public Builder setHttpQuery(String value) {
/* 2802 */         if (value == null) {
/* 2803 */           throw new NullPointerException();
/*      */         }
/* 2805 */         this.hasHttpQuery = true;
/* 2806 */         this.httpQuery_ = value;
/* 2807 */         return this;
/*      */       }
/*      */       public Builder clearHttpQuery() {
/* 2810 */         this.hasHttpQuery = false;
/* 2811 */         this.httpQuery_ = StatsProtos.RequestStatProto.getDefaultInstance().getHttpQuery();
/* 2812 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasHttpStatus()
/*      */       {
/* 2819 */         return this.hasHttpStatus;
/*      */       }
/*      */       public int getHttpStatus() {
/* 2822 */         return this.httpStatus_;
/*      */       }
/*      */       public Builder setHttpStatus(int value) {
/* 2825 */         this.hasHttpStatus = true;
/* 2826 */         this.httpStatus_ = value;
/* 2827 */         return this;
/*      */       }
/*      */       public Builder clearHttpStatus() {
/* 2830 */         this.hasHttpStatus = false;
/* 2831 */         this.httpStatus_ = 200;
/* 2832 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasDurationMilliseconds()
/*      */       {
/* 2839 */         return this.hasDurationMilliseconds;
/*      */       }
/*      */       public long getDurationMilliseconds() {
/* 2842 */         return this.durationMilliseconds_;
/*      */       }
/*      */       public Builder setDurationMilliseconds(long value) {
/* 2845 */         this.hasDurationMilliseconds = true;
/* 2846 */         this.durationMilliseconds_ = value;
/* 2847 */         return this;
/*      */       }
/*      */       public Builder clearDurationMilliseconds() {
/* 2850 */         this.hasDurationMilliseconds = false;
/* 2851 */         this.durationMilliseconds_ = 0L;
/* 2852 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasApiMcycles()
/*      */       {
/* 2859 */         return this.hasApiMcycles;
/*      */       }
/*      */       public long getApiMcycles() {
/* 2862 */         return this.apiMcycles_;
/*      */       }
/*      */       public Builder setApiMcycles(long value) {
/* 2865 */         this.hasApiMcycles = true;
/* 2866 */         this.apiMcycles_ = value;
/* 2867 */         return this;
/*      */       }
/*      */       public Builder clearApiMcycles() {
/* 2870 */         this.hasApiMcycles = false;
/* 2871 */         this.apiMcycles_ = 0L;
/* 2872 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasProcessorMcycles()
/*      */       {
/* 2879 */         return this.hasProcessorMcycles;
/*      */       }
/*      */       public long getProcessorMcycles() {
/* 2882 */         return this.processorMcycles_;
/*      */       }
/*      */       public Builder setProcessorMcycles(long value) {
/* 2885 */         this.hasProcessorMcycles = true;
/* 2886 */         this.processorMcycles_ = value;
/* 2887 */         return this;
/*      */       }
/*      */       public Builder clearProcessorMcycles() {
/* 2890 */         this.hasProcessorMcycles = false;
/* 2891 */         this.processorMcycles_ = 0L;
/* 2892 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureRpcStatsIsMutable()
/*      */       {
/* 2900 */         if (!this.isRpcStatsMutable) {
/* 2901 */           this.rpcStats_ = new ArrayList(this.rpcStats_);
/* 2902 */           this.isRpcStatsMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<StatsProtos.AggregateRpcStatsProto> getRpcStatsList() {
/* 2906 */         return Collections.unmodifiableList(this.rpcStats_);
/*      */       }
/*      */       public int getRpcStatsCount() {
/* 2909 */         return this.rpcStats_.size();
/*      */       }
/*      */       public StatsProtos.AggregateRpcStatsProto getRpcStats(int index) {
/* 2912 */         return (StatsProtos.AggregateRpcStatsProto)this.rpcStats_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setRpcStats(int index, StatsProtos.AggregateRpcStatsProto value) {
/* 2916 */         if (value == null) {
/* 2917 */           throw new NullPointerException();
/*      */         }
/* 2919 */         ensureRpcStatsIsMutable();
/* 2920 */         this.rpcStats_.set(index, value);
/* 2921 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setRpcStats(int index, StatsProtos.AggregateRpcStatsProto.Builder builderForValue) {
/* 2925 */         ensureRpcStatsIsMutable();
/* 2926 */         this.rpcStats_.set(index, builderForValue.build());
/* 2927 */         return this;
/*      */       }
/*      */       public Builder addRpcStats(StatsProtos.AggregateRpcStatsProto value) {
/* 2930 */         if (value == null) {
/* 2931 */           throw new NullPointerException();
/*      */         }
/* 2933 */         ensureRpcStatsIsMutable();
/* 2934 */         this.rpcStats_.add(value);
/* 2935 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addRpcStats(StatsProtos.AggregateRpcStatsProto.Builder builderForValue) {
/* 2939 */         ensureRpcStatsIsMutable();
/* 2940 */         this.rpcStats_.add(builderForValue.build());
/* 2941 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllRpcStats(Iterable<? extends StatsProtos.AggregateRpcStatsProto> values) {
/* 2945 */         ensureRpcStatsIsMutable();
/* 2946 */         GeneratedMessage.Builder.addAll(values, this.rpcStats_);
/* 2947 */         return this;
/*      */       }
/*      */       public Builder clearRpcStats() {
/* 2950 */         this.rpcStats_ = Collections.emptyList();
/* 2951 */         this.isRpcStatsMutable = false;
/* 2952 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureCgiEnvIsMutable()
/*      */       {
/* 2960 */         if (!this.isCgiEnvMutable) {
/* 2961 */           this.cgiEnv_ = new ArrayList(this.cgiEnv_);
/* 2962 */           this.isCgiEnvMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<StatsProtos.KeyValProto> getCgiEnvList() {
/* 2966 */         return Collections.unmodifiableList(this.cgiEnv_);
/*      */       }
/*      */       public int getCgiEnvCount() {
/* 2969 */         return this.cgiEnv_.size();
/*      */       }
/*      */       public StatsProtos.KeyValProto getCgiEnv(int index) {
/* 2972 */         return (StatsProtos.KeyValProto)this.cgiEnv_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setCgiEnv(int index, StatsProtos.KeyValProto value) {
/* 2976 */         if (value == null) {
/* 2977 */           throw new NullPointerException();
/*      */         }
/* 2979 */         ensureCgiEnvIsMutable();
/* 2980 */         this.cgiEnv_.set(index, value);
/* 2981 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setCgiEnv(int index, StatsProtos.KeyValProto.Builder builderForValue) {
/* 2985 */         ensureCgiEnvIsMutable();
/* 2986 */         this.cgiEnv_.set(index, builderForValue.build());
/* 2987 */         return this;
/*      */       }
/*      */       public Builder addCgiEnv(StatsProtos.KeyValProto value) {
/* 2990 */         if (value == null) {
/* 2991 */           throw new NullPointerException();
/*      */         }
/* 2993 */         ensureCgiEnvIsMutable();
/* 2994 */         this.cgiEnv_.add(value);
/* 2995 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addCgiEnv(StatsProtos.KeyValProto.Builder builderForValue) {
/* 2999 */         ensureCgiEnvIsMutable();
/* 3000 */         this.cgiEnv_.add(builderForValue.build());
/* 3001 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllCgiEnv(Iterable<? extends StatsProtos.KeyValProto> values) {
/* 3005 */         ensureCgiEnvIsMutable();
/* 3006 */         GeneratedMessage.Builder.addAll(values, this.cgiEnv_);
/* 3007 */         return this;
/*      */       }
/*      */       public Builder clearCgiEnv() {
/* 3010 */         this.cgiEnv_ = Collections.emptyList();
/* 3011 */         this.isCgiEnvMutable = false;
/* 3012 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasOverheadWalltimeMilliseconds()
/*      */       {
/* 3019 */         return this.hasOverheadWalltimeMilliseconds;
/*      */       }
/*      */       public long getOverheadWalltimeMilliseconds() {
/* 3022 */         return this.overheadWalltimeMilliseconds_;
/*      */       }
/*      */       public Builder setOverheadWalltimeMilliseconds(long value) {
/* 3025 */         this.hasOverheadWalltimeMilliseconds = true;
/* 3026 */         this.overheadWalltimeMilliseconds_ = value;
/* 3027 */         return this;
/*      */       }
/*      */       public Builder clearOverheadWalltimeMilliseconds() {
/* 3030 */         this.hasOverheadWalltimeMilliseconds = false;
/* 3031 */         this.overheadWalltimeMilliseconds_ = 0L;
/* 3032 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasUserEmail()
/*      */       {
/* 3039 */         return this.hasUserEmail;
/*      */       }
/*      */       public String getUserEmail() {
/* 3042 */         return this.userEmail_;
/*      */       }
/*      */       public Builder setUserEmail(String value) {
/* 3045 */         if (value == null) {
/* 3046 */           throw new NullPointerException();
/*      */         }
/* 3048 */         this.hasUserEmail = true;
/* 3049 */         this.userEmail_ = value;
/* 3050 */         return this;
/*      */       }
/*      */       public Builder clearUserEmail() {
/* 3053 */         this.hasUserEmail = false;
/* 3054 */         this.userEmail_ = StatsProtos.RequestStatProto.getDefaultInstance().getUserEmail();
/* 3055 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasIsAdmin()
/*      */       {
/* 3062 */         return this.hasIsAdmin;
/*      */       }
/*      */       public boolean getIsAdmin() {
/* 3065 */         return this.isAdmin_;
/*      */       }
/*      */       public Builder setIsAdmin(boolean value) {
/* 3068 */         this.hasIsAdmin = true;
/* 3069 */         this.isAdmin_ = value;
/* 3070 */         return this;
/*      */       }
/*      */       public Builder clearIsAdmin() {
/* 3073 */         this.hasIsAdmin = false;
/* 3074 */         this.isAdmin_ = false;
/* 3075 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureIndividualStatsIsMutable()
/*      */       {
/* 3083 */         if (!this.isIndividualStatsMutable) {
/* 3084 */           this.individualStats_ = new ArrayList(this.individualStats_);
/* 3085 */           this.isIndividualStatsMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<StatsProtos.IndividualRpcStatsProto> getIndividualStatsList() {
/* 3089 */         return Collections.unmodifiableList(this.individualStats_);
/*      */       }
/*      */       public int getIndividualStatsCount() {
/* 3092 */         return this.individualStats_.size();
/*      */       }
/*      */       public StatsProtos.IndividualRpcStatsProto getIndividualStats(int index) {
/* 3095 */         return (StatsProtos.IndividualRpcStatsProto)this.individualStats_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setIndividualStats(int index, StatsProtos.IndividualRpcStatsProto value) {
/* 3099 */         if (value == null) {
/* 3100 */           throw new NullPointerException();
/*      */         }
/* 3102 */         ensureIndividualStatsIsMutable();
/* 3103 */         this.individualStats_.set(index, value);
/* 3104 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setIndividualStats(int index, StatsProtos.IndividualRpcStatsProto.Builder builderForValue) {
/* 3108 */         ensureIndividualStatsIsMutable();
/* 3109 */         this.individualStats_.set(index, builderForValue.build());
/* 3110 */         return this;
/*      */       }
/*      */       public Builder addIndividualStats(StatsProtos.IndividualRpcStatsProto value) {
/* 3113 */         if (value == null) {
/* 3114 */           throw new NullPointerException();
/*      */         }
/* 3116 */         ensureIndividualStatsIsMutable();
/* 3117 */         this.individualStats_.add(value);
/* 3118 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addIndividualStats(StatsProtos.IndividualRpcStatsProto.Builder builderForValue) {
/* 3122 */         ensureIndividualStatsIsMutable();
/* 3123 */         this.individualStats_.add(builderForValue.build());
/* 3124 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllIndividualStats(Iterable<? extends StatsProtos.IndividualRpcStatsProto> values) {
/* 3128 */         ensureIndividualStatsIsMutable();
/* 3129 */         GeneratedMessage.Builder.addAll(values, this.individualStats_);
/* 3130 */         return this;
/*      */       }
/*      */       public Builder clearIndividualStats() {
/* 3133 */         this.individualStats_ = Collections.emptyList();
/* 3134 */         this.isIndividualStatsMutable = false;
/* 3135 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class IndividualRpcStatsProto extends GeneratedMessage
/*      */   {
/* 2002 */     private static final IndividualRpcStatsProto defaultInstance = new IndividualRpcStatsProto(true);
/*      */     public static final int SERVICE_CALL_NAME_FIELD_NUMBER = 1;
/*      */     private boolean hasServiceCallName;
/*      */     private String serviceCallName_;
/*      */     public static final int REQUEST_DATA_SUMMARY_FIELD_NUMBER = 3;
/*      */     private boolean hasRequestDataSummary;
/*      */     private String requestDataSummary_;
/*      */     public static final int RESPONSE_DATA_SUMMARY_FIELD_NUMBER = 4;
/*      */     private boolean hasResponseDataSummary;
/*      */     private String responseDataSummary_;
/*      */     public static final int API_MCYCLES_FIELD_NUMBER = 5;
/*      */     private boolean hasApiMcycles;
/*      */     private long apiMcycles_;
/*      */     public static final int START_OFFSET_MILLISECONDS_FIELD_NUMBER = 6;
/*      */     private boolean hasStartOffsetMilliseconds;
/*      */     private long startOffsetMilliseconds_;
/*      */     public static final int DURATION_MILLISECONDS_FIELD_NUMBER = 7;
/*      */     private boolean hasDurationMilliseconds;
/*      */     private long durationMilliseconds_;
/*      */     public static final int NAMESPACE_FIELD_NUMBER = 8;
/*      */     private boolean hasNamespace;
/*      */     private String namespace_;
/*      */     public static final int WAS_SUCCESSFUL_FIELD_NUMBER = 9;
/*      */     private boolean hasWasSuccessful;
/*      */     private boolean wasSuccessful_;
/*      */     public static final int CALL_STACK_FIELD_NUMBER = 10;
/*      */     private List<StatsProtos.StackFrameProto> callStack_;
/* 1419 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private IndividualRpcStatsProto(Builder builder)
/*      */     {
/* 1242 */       super();
/*      */     }
/*      */     private IndividualRpcStatsProto(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto getDefaultInstance() {
/* 1248 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public IndividualRpcStatsProto getDefaultInstanceForType() {
/* 1252 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/* 1257 */       return StatsProtos.internal_static_apphosting_IndividualRpcStatsProto_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/* 1262 */       return StatsProtos.internal_static_apphosting_IndividualRpcStatsProto_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasServiceCallName()
/*      */     {
/* 1270 */       return this.hasServiceCallName;
/*      */     }
/*      */     public String getServiceCallName() {
/* 1273 */       return this.serviceCallName_;
/*      */     }
/*      */ 
/*      */     public boolean hasRequestDataSummary()
/*      */     {
/* 1281 */       return this.hasRequestDataSummary;
/*      */     }
/*      */     public String getRequestDataSummary() {
/* 1284 */       return this.requestDataSummary_;
/*      */     }
/*      */ 
/*      */     public boolean hasResponseDataSummary()
/*      */     {
/* 1292 */       return this.hasResponseDataSummary;
/*      */     }
/*      */     public String getResponseDataSummary() {
/* 1295 */       return this.responseDataSummary_;
/*      */     }
/*      */ 
/*      */     public boolean hasApiMcycles()
/*      */     {
/* 1303 */       return this.hasApiMcycles;
/*      */     }
/*      */     public long getApiMcycles() {
/* 1306 */       return this.apiMcycles_;
/*      */     }
/*      */ 
/*      */     public boolean hasStartOffsetMilliseconds()
/*      */     {
/* 1314 */       return this.hasStartOffsetMilliseconds;
/*      */     }
/*      */     public long getStartOffsetMilliseconds() {
/* 1317 */       return this.startOffsetMilliseconds_;
/*      */     }
/*      */ 
/*      */     public boolean hasDurationMilliseconds()
/*      */     {
/* 1325 */       return this.hasDurationMilliseconds;
/*      */     }
/*      */     public long getDurationMilliseconds() {
/* 1328 */       return this.durationMilliseconds_;
/*      */     }
/*      */ 
/*      */     public boolean hasNamespace()
/*      */     {
/* 1336 */       return this.hasNamespace;
/*      */     }
/*      */     public String getNamespace() {
/* 1339 */       return this.namespace_;
/*      */     }
/*      */ 
/*      */     public boolean hasWasSuccessful()
/*      */     {
/* 1347 */       return this.hasWasSuccessful;
/*      */     }
/*      */     public boolean getWasSuccessful() {
/* 1350 */       return this.wasSuccessful_;
/*      */     }
/*      */ 
/*      */     public List<StatsProtos.StackFrameProto> getCallStackList()
/*      */     {
/* 1357 */       return this.callStack_;
/*      */     }
/*      */     public int getCallStackCount() {
/* 1360 */       return this.callStack_.size();
/*      */     }
/*      */     public StatsProtos.StackFrameProto getCallStack(int index) {
/* 1363 */       return (StatsProtos.StackFrameProto)this.callStack_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/* 1367 */       this.serviceCallName_ = "";
/* 1368 */       this.requestDataSummary_ = "";
/* 1369 */       this.responseDataSummary_ = "";
/* 1370 */       this.apiMcycles_ = 0L;
/* 1371 */       this.startOffsetMilliseconds_ = 0L;
/* 1372 */       this.durationMilliseconds_ = 0L;
/* 1373 */       this.namespace_ = "";
/* 1374 */       this.wasSuccessful_ = true;
/* 1375 */       this.callStack_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/* 1378 */       if (!this.hasServiceCallName) return false;
/* 1379 */       if (!this.hasStartOffsetMilliseconds) return false;
/* 1380 */       for (StatsProtos.StackFrameProto element : getCallStackList()) {
/* 1381 */         if (!element.isInitialized()) return false;
/*      */       }
/* 1383 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/* 1388 */       getSerializedSize();
/* 1389 */       if (hasServiceCallName()) {
/* 1390 */         output.writeString(1, getServiceCallName());
/*      */       }
/* 1392 */       if (hasRequestDataSummary()) {
/* 1393 */         output.writeString(3, getRequestDataSummary());
/*      */       }
/* 1395 */       if (hasResponseDataSummary()) {
/* 1396 */         output.writeString(4, getResponseDataSummary());
/*      */       }
/* 1398 */       if (hasApiMcycles()) {
/* 1399 */         output.writeInt64(5, getApiMcycles());
/*      */       }
/* 1401 */       if (hasStartOffsetMilliseconds()) {
/* 1402 */         output.writeInt64(6, getStartOffsetMilliseconds());
/*      */       }
/* 1404 */       if (hasDurationMilliseconds()) {
/* 1405 */         output.writeInt64(7, getDurationMilliseconds());
/*      */       }
/* 1407 */       if (hasNamespace()) {
/* 1408 */         output.writeString(8, getNamespace());
/*      */       }
/* 1410 */       if (hasWasSuccessful()) {
/* 1411 */         output.writeBool(9, getWasSuccessful());
/*      */       }
/* 1413 */       for (StatsProtos.StackFrameProto element : getCallStackList()) {
/* 1414 */         output.writeMessage(10, element);
/*      */       }
/* 1416 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/* 1421 */       int size = this.memoizedSerializedSize;
/* 1422 */       if (size != -1) return size;
/*      */ 
/* 1424 */       size = 0;
/* 1425 */       if (hasServiceCallName()) {
/* 1426 */         size += CodedOutputStream.computeStringSize(1, getServiceCallName());
/*      */       }
/*      */ 
/* 1429 */       if (hasRequestDataSummary()) {
/* 1430 */         size += CodedOutputStream.computeStringSize(3, getRequestDataSummary());
/*      */       }
/*      */ 
/* 1433 */       if (hasResponseDataSummary()) {
/* 1434 */         size += CodedOutputStream.computeStringSize(4, getResponseDataSummary());
/*      */       }
/*      */ 
/* 1437 */       if (hasApiMcycles()) {
/* 1438 */         size += CodedOutputStream.computeInt64Size(5, getApiMcycles());
/*      */       }
/*      */ 
/* 1441 */       if (hasStartOffsetMilliseconds()) {
/* 1442 */         size += CodedOutputStream.computeInt64Size(6, getStartOffsetMilliseconds());
/*      */       }
/*      */ 
/* 1445 */       if (hasDurationMilliseconds()) {
/* 1446 */         size += CodedOutputStream.computeInt64Size(7, getDurationMilliseconds());
/*      */       }
/*      */ 
/* 1449 */       if (hasNamespace()) {
/* 1450 */         size += CodedOutputStream.computeStringSize(8, getNamespace());
/*      */       }
/*      */ 
/* 1453 */       if (hasWasSuccessful()) {
/* 1454 */         size += CodedOutputStream.computeBoolSize(9, getWasSuccessful());
/*      */       }
/*      */ 
/* 1457 */       for (StatsProtos.StackFrameProto element : getCallStackList()) {
/* 1458 */         size += CodedOutputStream.computeMessageSize(10, element);
/*      */       }
/*      */ 
/* 1461 */       size += getUnknownFields().getSerializedSize();
/* 1462 */       this.memoizedSerializedSize = size;
/* 1463 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/* 1468 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 1474 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 1480 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/* 1485 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/* 1491 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(InputStream input) throws IOException
/*      */     {
/* 1496 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1502 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/* 1507 */       Builder builder = newBuilder();
/* 1508 */       if (builder.mergeDelimitedFrom(input)) {
/* 1509 */         return builder.buildParsed();
/*      */       }
/* 1511 */       return null;
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1518 */       Builder builder = newBuilder();
/* 1519 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/* 1520 */         return builder.buildParsed();
/*      */       }
/* 1522 */       return null;
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/* 1528 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static IndividualRpcStatsProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/* 1534 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/* 1538 */       return Builder.access$3300(); } 
/* 1539 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(IndividualRpcStatsProto prototype) {
/* 1541 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/* 1543 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 2003 */       StatsProtos.internalForceInit();
/* 2004 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasServiceCallName;
/* 1768 */       private String serviceCallName_ = "";
/*      */       private boolean hasRequestDataSummary;
/* 1791 */       private String requestDataSummary_ = "";
/*      */       private boolean hasResponseDataSummary;
/* 1814 */       private String responseDataSummary_ = "";
/*      */       private boolean hasApiMcycles;
/*      */       private long apiMcycles_;
/*      */       private boolean hasStartOffsetMilliseconds;
/*      */       private long startOffsetMilliseconds_;
/*      */       private boolean hasDurationMilliseconds;
/*      */       private long durationMilliseconds_;
/*      */       private boolean hasNamespace;
/* 1897 */       private String namespace_ = "";
/*      */       private boolean hasWasSuccessful;
/* 1920 */       private boolean wasSuccessful_ = true;
/*      */ 
/* 1939 */       private List<StatsProtos.StackFrameProto> callStack_ = Collections.emptyList();
/*      */       private boolean isCallStackMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/* 1549 */         return StatsProtos.internal_static_apphosting_IndividualRpcStatsProto_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/* 1554 */         return StatsProtos.internal_static_apphosting_IndividualRpcStatsProto_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/* 1562 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/* 1566 */         super.clear();
/* 1567 */         this.serviceCallName_ = "";
/* 1568 */         this.hasServiceCallName = false;
/* 1569 */         this.requestDataSummary_ = "";
/* 1570 */         this.hasRequestDataSummary = false;
/* 1571 */         this.responseDataSummary_ = "";
/* 1572 */         this.hasResponseDataSummary = false;
/* 1573 */         this.apiMcycles_ = 0L;
/* 1574 */         this.hasApiMcycles = false;
/* 1575 */         this.startOffsetMilliseconds_ = 0L;
/* 1576 */         this.hasStartOffsetMilliseconds = false;
/* 1577 */         this.durationMilliseconds_ = 0L;
/* 1578 */         this.hasDurationMilliseconds = false;
/* 1579 */         this.namespace_ = "";
/* 1580 */         this.hasNamespace = false;
/* 1581 */         this.wasSuccessful_ = true;
/* 1582 */         this.hasWasSuccessful = false;
/* 1583 */         this.callStack_ = Collections.emptyList();
/* 1584 */         this.isCallStackMutable = false;
/* 1585 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/* 1589 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/* 1594 */         return StatsProtos.IndividualRpcStatsProto.getDescriptor();
/*      */       }
/*      */ 
/*      */       public StatsProtos.IndividualRpcStatsProto getDefaultInstanceForType() {
/* 1598 */         return StatsProtos.IndividualRpcStatsProto.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public StatsProtos.IndividualRpcStatsProto build() {
/* 1602 */         StatsProtos.IndividualRpcStatsProto result = buildPartial();
/* 1603 */         if (!result.isInitialized()) {
/* 1604 */           throw newUninitializedMessageException(result);
/*      */         }
/* 1606 */         return result;
/*      */       }
/*      */ 
/*      */       private StatsProtos.IndividualRpcStatsProto buildParsed() throws InvalidProtocolBufferException
/*      */       {
/* 1611 */         StatsProtos.IndividualRpcStatsProto result = buildPartial();
/* 1612 */         if (!result.isInitialized()) {
/* 1613 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/* 1616 */         return result;
/*      */       }
/*      */ 
/*      */       public StatsProtos.IndividualRpcStatsProto buildPartial() {
/* 1620 */         StatsProtos.IndividualRpcStatsProto result = new StatsProtos.IndividualRpcStatsProto(this, null);
/* 1621 */         StatsProtos.IndividualRpcStatsProto.access$3502(result, this.hasServiceCallName);
/* 1622 */         StatsProtos.IndividualRpcStatsProto.access$3602(result, this.serviceCallName_);
/* 1623 */         StatsProtos.IndividualRpcStatsProto.access$3702(result, this.hasRequestDataSummary);
/* 1624 */         StatsProtos.IndividualRpcStatsProto.access$3802(result, this.requestDataSummary_);
/* 1625 */         StatsProtos.IndividualRpcStatsProto.access$3902(result, this.hasResponseDataSummary);
/* 1626 */         StatsProtos.IndividualRpcStatsProto.access$4002(result, this.responseDataSummary_);
/* 1627 */         StatsProtos.IndividualRpcStatsProto.access$4102(result, this.hasApiMcycles);
/* 1628 */         StatsProtos.IndividualRpcStatsProto.access$4202(result, this.apiMcycles_);
/* 1629 */         StatsProtos.IndividualRpcStatsProto.access$4302(result, this.hasStartOffsetMilliseconds);
/* 1630 */         StatsProtos.IndividualRpcStatsProto.access$4402(result, this.startOffsetMilliseconds_);
/* 1631 */         StatsProtos.IndividualRpcStatsProto.access$4502(result, this.hasDurationMilliseconds);
/* 1632 */         StatsProtos.IndividualRpcStatsProto.access$4602(result, this.durationMilliseconds_);
/* 1633 */         StatsProtos.IndividualRpcStatsProto.access$4702(result, this.hasNamespace);
/* 1634 */         StatsProtos.IndividualRpcStatsProto.access$4802(result, this.namespace_);
/* 1635 */         StatsProtos.IndividualRpcStatsProto.access$4902(result, this.hasWasSuccessful);
/* 1636 */         StatsProtos.IndividualRpcStatsProto.access$5002(result, this.wasSuccessful_);
/* 1637 */         if (this.isCallStackMutable) {
/* 1638 */           this.callStack_ = Collections.unmodifiableList(this.callStack_);
/* 1639 */           this.isCallStackMutable = false;
/*      */         }
/* 1641 */         StatsProtos.IndividualRpcStatsProto.access$5102(result, this.callStack_);
/* 1642 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 1646 */         if ((other instanceof StatsProtos.IndividualRpcStatsProto)) {
/* 1647 */           return mergeFrom((StatsProtos.IndividualRpcStatsProto)other);
/*      */         }
/* 1649 */         super.mergeFrom(other);
/* 1650 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(StatsProtos.IndividualRpcStatsProto other)
/*      */       {
/* 1655 */         if (other == StatsProtos.IndividualRpcStatsProto.getDefaultInstance()) return this;
/* 1656 */         if (other.hasServiceCallName()) {
/* 1657 */           setServiceCallName(other.getServiceCallName());
/*      */         }
/* 1659 */         if (other.hasRequestDataSummary()) {
/* 1660 */           setRequestDataSummary(other.getRequestDataSummary());
/*      */         }
/* 1662 */         if (other.hasResponseDataSummary()) {
/* 1663 */           setResponseDataSummary(other.getResponseDataSummary());
/*      */         }
/* 1665 */         if (other.hasApiMcycles()) {
/* 1666 */           setApiMcycles(other.getApiMcycles());
/*      */         }
/* 1668 */         if (other.hasStartOffsetMilliseconds()) {
/* 1669 */           setStartOffsetMilliseconds(other.getStartOffsetMilliseconds());
/*      */         }
/* 1671 */         if (other.hasDurationMilliseconds()) {
/* 1672 */           setDurationMilliseconds(other.getDurationMilliseconds());
/*      */         }
/* 1674 */         if (other.hasNamespace()) {
/* 1675 */           setNamespace(other.getNamespace());
/*      */         }
/* 1677 */         if (other.hasWasSuccessful()) {
/* 1678 */           setWasSuccessful(other.getWasSuccessful());
/*      */         }
/* 1680 */         if (!other.callStack_.isEmpty()) {
/* 1681 */           if (this.callStack_.isEmpty()) {
/* 1682 */             this.callStack_ = other.callStack_;
/* 1683 */             this.isCallStackMutable = false;
/*      */           } else {
/* 1685 */             ensureCallStackIsMutable();
/* 1686 */             this.callStack_.addAll(other.callStack_);
/*      */           }
/*      */         }
/* 1689 */         mergeUnknownFields(other.getUnknownFields());
/* 1690 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 1694 */         if (!this.hasServiceCallName) return false;
/* 1695 */         if (!this.hasStartOffsetMilliseconds) return false;
/* 1696 */         for (StatsProtos.StackFrameProto element : getCallStackList()) {
/* 1697 */           if (!element.isInitialized()) return false;
/*      */         }
/* 1699 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1706 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 1710 */           int tag = input.readTag();
/* 1711 */           switch (tag) {
/*      */           case 0:
/* 1713 */             setUnknownFields(unknownFields.build());
/* 1714 */             return this;
/*      */           default:
/* 1716 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 1718 */             setUnknownFields(unknownFields.build());
/* 1719 */             return this;
/*      */           case 10:
/* 1724 */             setServiceCallName(input.readString());
/* 1725 */             break;
/*      */           case 26:
/* 1728 */             setRequestDataSummary(input.readString());
/* 1729 */             break;
/*      */           case 34:
/* 1732 */             setResponseDataSummary(input.readString());
/* 1733 */             break;
/*      */           case 40:
/* 1736 */             setApiMcycles(input.readInt64());
/* 1737 */             break;
/*      */           case 48:
/* 1740 */             setStartOffsetMilliseconds(input.readInt64());
/* 1741 */             break;
/*      */           case 56:
/* 1744 */             setDurationMilliseconds(input.readInt64());
/* 1745 */             break;
/*      */           case 66:
/* 1748 */             setNamespace(input.readString());
/* 1749 */             break;
/*      */           case 72:
/* 1752 */             setWasSuccessful(input.readBool());
/* 1753 */             break;
/*      */           case 82:
/* 1756 */             StatsProtos.StackFrameProto.Builder subBuilder = StatsProtos.StackFrameProto.newBuilder();
/* 1757 */             input.readMessage(subBuilder, extensionRegistry);
/* 1758 */             addCallStack(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasServiceCallName()
/*      */       {
/* 1770 */         return this.hasServiceCallName;
/*      */       }
/*      */       public String getServiceCallName() {
/* 1773 */         return this.serviceCallName_;
/*      */       }
/*      */       public Builder setServiceCallName(String value) {
/* 1776 */         if (value == null) {
/* 1777 */           throw new NullPointerException();
/*      */         }
/* 1779 */         this.hasServiceCallName = true;
/* 1780 */         this.serviceCallName_ = value;
/* 1781 */         return this;
/*      */       }
/*      */       public Builder clearServiceCallName() {
/* 1784 */         this.hasServiceCallName = false;
/* 1785 */         this.serviceCallName_ = StatsProtos.IndividualRpcStatsProto.getDefaultInstance().getServiceCallName();
/* 1786 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasRequestDataSummary()
/*      */       {
/* 1793 */         return this.hasRequestDataSummary;
/*      */       }
/*      */       public String getRequestDataSummary() {
/* 1796 */         return this.requestDataSummary_;
/*      */       }
/*      */       public Builder setRequestDataSummary(String value) {
/* 1799 */         if (value == null) {
/* 1800 */           throw new NullPointerException();
/*      */         }
/* 1802 */         this.hasRequestDataSummary = true;
/* 1803 */         this.requestDataSummary_ = value;
/* 1804 */         return this;
/*      */       }
/*      */       public Builder clearRequestDataSummary() {
/* 1807 */         this.hasRequestDataSummary = false;
/* 1808 */         this.requestDataSummary_ = StatsProtos.IndividualRpcStatsProto.getDefaultInstance().getRequestDataSummary();
/* 1809 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasResponseDataSummary()
/*      */       {
/* 1816 */         return this.hasResponseDataSummary;
/*      */       }
/*      */       public String getResponseDataSummary() {
/* 1819 */         return this.responseDataSummary_;
/*      */       }
/*      */       public Builder setResponseDataSummary(String value) {
/* 1822 */         if (value == null) {
/* 1823 */           throw new NullPointerException();
/*      */         }
/* 1825 */         this.hasResponseDataSummary = true;
/* 1826 */         this.responseDataSummary_ = value;
/* 1827 */         return this;
/*      */       }
/*      */       public Builder clearResponseDataSummary() {
/* 1830 */         this.hasResponseDataSummary = false;
/* 1831 */         this.responseDataSummary_ = StatsProtos.IndividualRpcStatsProto.getDefaultInstance().getResponseDataSummary();
/* 1832 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasApiMcycles()
/*      */       {
/* 1839 */         return this.hasApiMcycles;
/*      */       }
/*      */       public long getApiMcycles() {
/* 1842 */         return this.apiMcycles_;
/*      */       }
/*      */       public Builder setApiMcycles(long value) {
/* 1845 */         this.hasApiMcycles = true;
/* 1846 */         this.apiMcycles_ = value;
/* 1847 */         return this;
/*      */       }
/*      */       public Builder clearApiMcycles() {
/* 1850 */         this.hasApiMcycles = false;
/* 1851 */         this.apiMcycles_ = 0L;
/* 1852 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasStartOffsetMilliseconds()
/*      */       {
/* 1859 */         return this.hasStartOffsetMilliseconds;
/*      */       }
/*      */       public long getStartOffsetMilliseconds() {
/* 1862 */         return this.startOffsetMilliseconds_;
/*      */       }
/*      */       public Builder setStartOffsetMilliseconds(long value) {
/* 1865 */         this.hasStartOffsetMilliseconds = true;
/* 1866 */         this.startOffsetMilliseconds_ = value;
/* 1867 */         return this;
/*      */       }
/*      */       public Builder clearStartOffsetMilliseconds() {
/* 1870 */         this.hasStartOffsetMilliseconds = false;
/* 1871 */         this.startOffsetMilliseconds_ = 0L;
/* 1872 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasDurationMilliseconds()
/*      */       {
/* 1879 */         return this.hasDurationMilliseconds;
/*      */       }
/*      */       public long getDurationMilliseconds() {
/* 1882 */         return this.durationMilliseconds_;
/*      */       }
/*      */       public Builder setDurationMilliseconds(long value) {
/* 1885 */         this.hasDurationMilliseconds = true;
/* 1886 */         this.durationMilliseconds_ = value;
/* 1887 */         return this;
/*      */       }
/*      */       public Builder clearDurationMilliseconds() {
/* 1890 */         this.hasDurationMilliseconds = false;
/* 1891 */         this.durationMilliseconds_ = 0L;
/* 1892 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasNamespace()
/*      */       {
/* 1899 */         return this.hasNamespace;
/*      */       }
/*      */       public String getNamespace() {
/* 1902 */         return this.namespace_;
/*      */       }
/*      */       public Builder setNamespace(String value) {
/* 1905 */         if (value == null) {
/* 1906 */           throw new NullPointerException();
/*      */         }
/* 1908 */         this.hasNamespace = true;
/* 1909 */         this.namespace_ = value;
/* 1910 */         return this;
/*      */       }
/*      */       public Builder clearNamespace() {
/* 1913 */         this.hasNamespace = false;
/* 1914 */         this.namespace_ = StatsProtos.IndividualRpcStatsProto.getDefaultInstance().getNamespace();
/* 1915 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasWasSuccessful()
/*      */       {
/* 1922 */         return this.hasWasSuccessful;
/*      */       }
/*      */       public boolean getWasSuccessful() {
/* 1925 */         return this.wasSuccessful_;
/*      */       }
/*      */       public Builder setWasSuccessful(boolean value) {
/* 1928 */         this.hasWasSuccessful = true;
/* 1929 */         this.wasSuccessful_ = value;
/* 1930 */         return this;
/*      */       }
/*      */       public Builder clearWasSuccessful() {
/* 1933 */         this.hasWasSuccessful = false;
/* 1934 */         this.wasSuccessful_ = true;
/* 1935 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureCallStackIsMutable()
/*      */       {
/* 1943 */         if (!this.isCallStackMutable) {
/* 1944 */           this.callStack_ = new ArrayList(this.callStack_);
/* 1945 */           this.isCallStackMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<StatsProtos.StackFrameProto> getCallStackList() {
/* 1949 */         return Collections.unmodifiableList(this.callStack_);
/*      */       }
/*      */       public int getCallStackCount() {
/* 1952 */         return this.callStack_.size();
/*      */       }
/*      */       public StatsProtos.StackFrameProto getCallStack(int index) {
/* 1955 */         return (StatsProtos.StackFrameProto)this.callStack_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setCallStack(int index, StatsProtos.StackFrameProto value) {
/* 1959 */         if (value == null) {
/* 1960 */           throw new NullPointerException();
/*      */         }
/* 1962 */         ensureCallStackIsMutable();
/* 1963 */         this.callStack_.set(index, value);
/* 1964 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setCallStack(int index, StatsProtos.StackFrameProto.Builder builderForValue) {
/* 1968 */         ensureCallStackIsMutable();
/* 1969 */         this.callStack_.set(index, builderForValue.build());
/* 1970 */         return this;
/*      */       }
/*      */       public Builder addCallStack(StatsProtos.StackFrameProto value) {
/* 1973 */         if (value == null) {
/* 1974 */           throw new NullPointerException();
/*      */         }
/* 1976 */         ensureCallStackIsMutable();
/* 1977 */         this.callStack_.add(value);
/* 1978 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addCallStack(StatsProtos.StackFrameProto.Builder builderForValue) {
/* 1982 */         ensureCallStackIsMutable();
/* 1983 */         this.callStack_.add(builderForValue.build());
/* 1984 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllCallStack(Iterable<? extends StatsProtos.StackFrameProto> values) {
/* 1988 */         ensureCallStackIsMutable();
/* 1989 */         GeneratedMessage.Builder.addAll(values, this.callStack_);
/* 1990 */         return this;
/*      */       }
/*      */       public Builder clearCallStack() {
/* 1993 */         this.callStack_ = Collections.emptyList();
/* 1994 */         this.isCallStackMutable = false;
/* 1995 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class StackFrameProto extends GeneratedMessage
/*      */   {
/* 1230 */     private static final StackFrameProto defaultInstance = new StackFrameProto(true);
/*      */     public static final int CLASS_OR_FILE_NAME_FIELD_NUMBER = 1;
/*      */     private boolean hasClassOrFileName;
/*      */     private String classOrFileName_;
/*      */     public static final int LINE_NUMBER_FIELD_NUMBER = 2;
/*      */     private boolean hasLineNumber;
/*      */     private int lineNumber_;
/*      */     public static final int FUNCTION_NAME_FIELD_NUMBER = 3;
/*      */     private boolean hasFunctionName;
/*      */     private String functionName_;
/*      */     public static final int VARIABLES_FIELD_NUMBER = 4;
/*      */     private List<StatsProtos.KeyValProto> variables_;
/*  828 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private StackFrameProto(Builder builder)
/*      */     {
/*  726 */       super();
/*      */     }
/*      */     private StackFrameProto(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static StackFrameProto getDefaultInstance() {
/*  732 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public StackFrameProto getDefaultInstanceForType() {
/*  736 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  741 */       return StatsProtos.internal_static_apphosting_StackFrameProto_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  746 */       return StatsProtos.internal_static_apphosting_StackFrameProto_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasClassOrFileName()
/*      */     {
/*  754 */       return this.hasClassOrFileName;
/*      */     }
/*      */     public String getClassOrFileName() {
/*  757 */       return this.classOrFileName_;
/*      */     }
/*      */ 
/*      */     public boolean hasLineNumber()
/*      */     {
/*  765 */       return this.hasLineNumber;
/*      */     }
/*      */     public int getLineNumber() {
/*  768 */       return this.lineNumber_;
/*      */     }
/*      */ 
/*      */     public boolean hasFunctionName()
/*      */     {
/*  776 */       return this.hasFunctionName;
/*      */     }
/*      */     public String getFunctionName() {
/*  779 */       return this.functionName_;
/*      */     }
/*      */ 
/*      */     public List<StatsProtos.KeyValProto> getVariablesList()
/*      */     {
/*  786 */       return this.variables_;
/*      */     }
/*      */     public int getVariablesCount() {
/*  789 */       return this.variables_.size();
/*      */     }
/*      */     public StatsProtos.KeyValProto getVariables(int index) {
/*  792 */       return (StatsProtos.KeyValProto)this.variables_.get(index);
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*  796 */       this.classOrFileName_ = "";
/*  797 */       this.lineNumber_ = 0;
/*  798 */       this.functionName_ = "";
/*  799 */       this.variables_ = Collections.emptyList();
/*      */     }
/*      */     public final boolean isInitialized() {
/*  802 */       if (!this.hasClassOrFileName) return false;
/*  803 */       if (!this.hasFunctionName) return false;
/*  804 */       for (StatsProtos.KeyValProto element : getVariablesList()) {
/*  805 */         if (!element.isInitialized()) return false;
/*      */       }
/*  807 */       return true;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output) throws IOException
/*      */     {
/*  812 */       getSerializedSize();
/*  813 */       if (hasClassOrFileName()) {
/*  814 */         output.writeString(1, getClassOrFileName());
/*      */       }
/*  816 */       if (hasLineNumber()) {
/*  817 */         output.writeInt32(2, getLineNumber());
/*      */       }
/*  819 */       if (hasFunctionName()) {
/*  820 */         output.writeString(3, getFunctionName());
/*      */       }
/*  822 */       for (StatsProtos.KeyValProto element : getVariablesList()) {
/*  823 */         output.writeMessage(4, element);
/*      */       }
/*  825 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  830 */       int size = this.memoizedSerializedSize;
/*  831 */       if (size != -1) return size;
/*      */ 
/*  833 */       size = 0;
/*  834 */       if (hasClassOrFileName()) {
/*  835 */         size += CodedOutputStream.computeStringSize(1, getClassOrFileName());
/*      */       }
/*      */ 
/*  838 */       if (hasLineNumber()) {
/*  839 */         size += CodedOutputStream.computeInt32Size(2, getLineNumber());
/*      */       }
/*      */ 
/*  842 */       if (hasFunctionName()) {
/*  843 */         size += CodedOutputStream.computeStringSize(3, getFunctionName());
/*      */       }
/*      */ 
/*  846 */       for (StatsProtos.KeyValProto element : getVariablesList()) {
/*  847 */         size += CodedOutputStream.computeMessageSize(4, element);
/*      */       }
/*      */ 
/*  850 */       size += getUnknownFields().getSerializedSize();
/*  851 */       this.memoizedSerializedSize = size;
/*  852 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  857 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  863 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  869 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  874 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  880 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(InputStream input) throws IOException
/*      */     {
/*  885 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  891 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  896 */       Builder builder = newBuilder();
/*  897 */       if (builder.mergeDelimitedFrom(input)) {
/*  898 */         return builder.buildParsed();
/*      */       }
/*  900 */       return null;
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  907 */       Builder builder = newBuilder();
/*  908 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  909 */         return builder.buildParsed();
/*      */       }
/*  911 */       return null;
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  917 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static StackFrameProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  923 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  927 */       return Builder.access$2100(); } 
/*  928 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(StackFrameProto prototype) {
/*  930 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  932 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1231 */       StatsProtos.internalForceInit();
/* 1232 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasClassOrFileName;
/* 1102 */       private String classOrFileName_ = "";
/*      */       private boolean hasLineNumber;
/*      */       private int lineNumber_;
/*      */       private boolean hasFunctionName;
/* 1145 */       private String functionName_ = "";
/*      */ 
/* 1167 */       private List<StatsProtos.KeyValProto> variables_ = Collections.emptyList();
/*      */       private boolean isVariablesMutable;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  938 */         return StatsProtos.internal_static_apphosting_StackFrameProto_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  943 */         return StatsProtos.internal_static_apphosting_StackFrameProto_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  951 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  955 */         super.clear();
/*  956 */         this.classOrFileName_ = "";
/*  957 */         this.hasClassOrFileName = false;
/*  958 */         this.lineNumber_ = 0;
/*  959 */         this.hasLineNumber = false;
/*  960 */         this.functionName_ = "";
/*  961 */         this.hasFunctionName = false;
/*  962 */         this.variables_ = Collections.emptyList();
/*  963 */         this.isVariablesMutable = false;
/*  964 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  968 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  973 */         return StatsProtos.StackFrameProto.getDescriptor();
/*      */       }
/*      */ 
/*      */       public StatsProtos.StackFrameProto getDefaultInstanceForType() {
/*  977 */         return StatsProtos.StackFrameProto.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public StatsProtos.StackFrameProto build() {
/*  981 */         StatsProtos.StackFrameProto result = buildPartial();
/*  982 */         if (!result.isInitialized()) {
/*  983 */           throw newUninitializedMessageException(result);
/*      */         }
/*  985 */         return result;
/*      */       }
/*      */ 
/*      */       private StatsProtos.StackFrameProto buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  990 */         StatsProtos.StackFrameProto result = buildPartial();
/*  991 */         if (!result.isInitialized()) {
/*  992 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  995 */         return result;
/*      */       }
/*      */ 
/*      */       public StatsProtos.StackFrameProto buildPartial() {
/*  999 */         StatsProtos.StackFrameProto result = new StatsProtos.StackFrameProto(this, null);
/* 1000 */         StatsProtos.StackFrameProto.access$2302(result, this.hasClassOrFileName);
/* 1001 */         StatsProtos.StackFrameProto.access$2402(result, this.classOrFileName_);
/* 1002 */         StatsProtos.StackFrameProto.access$2502(result, this.hasLineNumber);
/* 1003 */         StatsProtos.StackFrameProto.access$2602(result, this.lineNumber_);
/* 1004 */         StatsProtos.StackFrameProto.access$2702(result, this.hasFunctionName);
/* 1005 */         StatsProtos.StackFrameProto.access$2802(result, this.functionName_);
/* 1006 */         if (this.isVariablesMutable) {
/* 1007 */           this.variables_ = Collections.unmodifiableList(this.variables_);
/* 1008 */           this.isVariablesMutable = false;
/*      */         }
/* 1010 */         StatsProtos.StackFrameProto.access$2902(result, this.variables_);
/* 1011 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/* 1015 */         if ((other instanceof StatsProtos.StackFrameProto)) {
/* 1016 */           return mergeFrom((StatsProtos.StackFrameProto)other);
/*      */         }
/* 1018 */         super.mergeFrom(other);
/* 1019 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(StatsProtos.StackFrameProto other)
/*      */       {
/* 1024 */         if (other == StatsProtos.StackFrameProto.getDefaultInstance()) return this;
/* 1025 */         if (other.hasClassOrFileName()) {
/* 1026 */           setClassOrFileName(other.getClassOrFileName());
/*      */         }
/* 1028 */         if (other.hasLineNumber()) {
/* 1029 */           setLineNumber(other.getLineNumber());
/*      */         }
/* 1031 */         if (other.hasFunctionName()) {
/* 1032 */           setFunctionName(other.getFunctionName());
/*      */         }
/* 1034 */         if (!other.variables_.isEmpty()) {
/* 1035 */           if (this.variables_.isEmpty()) {
/* 1036 */             this.variables_ = other.variables_;
/* 1037 */             this.isVariablesMutable = false;
/*      */           } else {
/* 1039 */             ensureVariablesIsMutable();
/* 1040 */             this.variables_.addAll(other.variables_);
/*      */           }
/*      */         }
/* 1043 */         mergeUnknownFields(other.getUnknownFields());
/* 1044 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/* 1048 */         if (!this.hasClassOrFileName) return false;
/* 1049 */         if (!this.hasFunctionName) return false;
/* 1050 */         for (StatsProtos.KeyValProto element : getVariablesList()) {
/* 1051 */           if (!element.isInitialized()) return false;
/*      */         }
/* 1053 */         return true;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/* 1060 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/* 1064 */           int tag = input.readTag();
/* 1065 */           switch (tag) {
/*      */           case 0:
/* 1067 */             setUnknownFields(unknownFields.build());
/* 1068 */             return this;
/*      */           default:
/* 1070 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/* 1072 */             setUnknownFields(unknownFields.build());
/* 1073 */             return this;
/*      */           case 10:
/* 1078 */             setClassOrFileName(input.readString());
/* 1079 */             break;
/*      */           case 16:
/* 1082 */             setLineNumber(input.readInt32());
/* 1083 */             break;
/*      */           case 26:
/* 1086 */             setFunctionName(input.readString());
/* 1087 */             break;
/*      */           case 34:
/* 1090 */             StatsProtos.KeyValProto.Builder subBuilder = StatsProtos.KeyValProto.newBuilder();
/* 1091 */             input.readMessage(subBuilder, extensionRegistry);
/* 1092 */             addVariables(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasClassOrFileName()
/*      */       {
/* 1104 */         return this.hasClassOrFileName;
/*      */       }
/*      */       public String getClassOrFileName() {
/* 1107 */         return this.classOrFileName_;
/*      */       }
/*      */       public Builder setClassOrFileName(String value) {
/* 1110 */         if (value == null) {
/* 1111 */           throw new NullPointerException();
/*      */         }
/* 1113 */         this.hasClassOrFileName = true;
/* 1114 */         this.classOrFileName_ = value;
/* 1115 */         return this;
/*      */       }
/*      */       public Builder clearClassOrFileName() {
/* 1118 */         this.hasClassOrFileName = false;
/* 1119 */         this.classOrFileName_ = StatsProtos.StackFrameProto.getDefaultInstance().getClassOrFileName();
/* 1120 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasLineNumber()
/*      */       {
/* 1127 */         return this.hasLineNumber;
/*      */       }
/*      */       public int getLineNumber() {
/* 1130 */         return this.lineNumber_;
/*      */       }
/*      */       public Builder setLineNumber(int value) {
/* 1133 */         this.hasLineNumber = true;
/* 1134 */         this.lineNumber_ = value;
/* 1135 */         return this;
/*      */       }
/*      */       public Builder clearLineNumber() {
/* 1138 */         this.hasLineNumber = false;
/* 1139 */         this.lineNumber_ = 0;
/* 1140 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasFunctionName()
/*      */       {
/* 1147 */         return this.hasFunctionName;
/*      */       }
/*      */       public String getFunctionName() {
/* 1150 */         return this.functionName_;
/*      */       }
/*      */       public Builder setFunctionName(String value) {
/* 1153 */         if (value == null) {
/* 1154 */           throw new NullPointerException();
/*      */         }
/* 1156 */         this.hasFunctionName = true;
/* 1157 */         this.functionName_ = value;
/* 1158 */         return this;
/*      */       }
/*      */       public Builder clearFunctionName() {
/* 1161 */         this.hasFunctionName = false;
/* 1162 */         this.functionName_ = StatsProtos.StackFrameProto.getDefaultInstance().getFunctionName();
/* 1163 */         return this;
/*      */       }
/*      */ 
/*      */       private void ensureVariablesIsMutable()
/*      */       {
/* 1171 */         if (!this.isVariablesMutable) {
/* 1172 */           this.variables_ = new ArrayList(this.variables_);
/* 1173 */           this.isVariablesMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<StatsProtos.KeyValProto> getVariablesList() {
/* 1177 */         return Collections.unmodifiableList(this.variables_);
/*      */       }
/*      */       public int getVariablesCount() {
/* 1180 */         return this.variables_.size();
/*      */       }
/*      */       public StatsProtos.KeyValProto getVariables(int index) {
/* 1183 */         return (StatsProtos.KeyValProto)this.variables_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setVariables(int index, StatsProtos.KeyValProto value) {
/* 1187 */         if (value == null) {
/* 1188 */           throw new NullPointerException();
/*      */         }
/* 1190 */         ensureVariablesIsMutable();
/* 1191 */         this.variables_.set(index, value);
/* 1192 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setVariables(int index, StatsProtos.KeyValProto.Builder builderForValue) {
/* 1196 */         ensureVariablesIsMutable();
/* 1197 */         this.variables_.set(index, builderForValue.build());
/* 1198 */         return this;
/*      */       }
/*      */       public Builder addVariables(StatsProtos.KeyValProto value) {
/* 1201 */         if (value == null) {
/* 1202 */           throw new NullPointerException();
/*      */         }
/* 1204 */         ensureVariablesIsMutable();
/* 1205 */         this.variables_.add(value);
/* 1206 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addVariables(StatsProtos.KeyValProto.Builder builderForValue) {
/* 1210 */         ensureVariablesIsMutable();
/* 1211 */         this.variables_.add(builderForValue.build());
/* 1212 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllVariables(Iterable<? extends StatsProtos.KeyValProto> values) {
/* 1216 */         ensureVariablesIsMutable();
/* 1217 */         GeneratedMessage.Builder.addAll(values, this.variables_);
/* 1218 */         return this;
/*      */       }
/*      */       public Builder clearVariables() {
/* 1221 */         this.variables_ = Collections.emptyList();
/* 1222 */         this.isVariablesMutable = false;
/* 1223 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class KeyValProto extends GeneratedMessage
/*      */   {
/*  714 */     private static final KeyValProto defaultInstance = new KeyValProto(true);
/*      */     public static final int KEY_FIELD_NUMBER = 1;
/*      */     private boolean hasKey;
/*      */     private String key_;
/*      */     public static final int VALUE_FIELD_NUMBER = 2;
/*      */     private boolean hasValue;
/*      */     private String value_;
/*  436 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private KeyValProto(Builder builder)
/*      */     {
/*  369 */       super();
/*      */     }
/*      */     private KeyValProto(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static KeyValProto getDefaultInstance() {
/*  375 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public KeyValProto getDefaultInstanceForType() {
/*  379 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  384 */       return StatsProtos.internal_static_apphosting_KeyValProto_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  389 */       return StatsProtos.internal_static_apphosting_KeyValProto_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasKey()
/*      */     {
/*  397 */       return this.hasKey;
/*      */     }
/*      */     public String getKey() {
/*  400 */       return this.key_;
/*      */     }
/*      */ 
/*      */     public boolean hasValue()
/*      */     {
/*  408 */       return this.hasValue;
/*      */     }
/*      */     public String getValue() {
/*  411 */       return this.value_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*  415 */       this.key_ = "";
/*  416 */       this.value_ = "";
/*      */     }
/*      */     public final boolean isInitialized() {
/*  419 */       if (!this.hasKey) return false;
/*  420 */       return this.hasValue;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/*  426 */       getSerializedSize();
/*  427 */       if (hasKey()) {
/*  428 */         output.writeString(1, getKey());
/*      */       }
/*  430 */       if (hasValue()) {
/*  431 */         output.writeString(2, getValue());
/*      */       }
/*  433 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  438 */       int size = this.memoizedSerializedSize;
/*  439 */       if (size != -1) return size;
/*      */ 
/*  441 */       size = 0;
/*  442 */       if (hasKey()) {
/*  443 */         size += CodedOutputStream.computeStringSize(1, getKey());
/*      */       }
/*      */ 
/*  446 */       if (hasValue()) {
/*  447 */         size += CodedOutputStream.computeStringSize(2, getValue());
/*      */       }
/*      */ 
/*  450 */       size += getUnknownFields().getSerializedSize();
/*  451 */       this.memoizedSerializedSize = size;
/*  452 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  457 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  463 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  469 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  474 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  480 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(InputStream input) throws IOException
/*      */     {
/*  485 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  491 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  496 */       Builder builder = newBuilder();
/*  497 */       if (builder.mergeDelimitedFrom(input)) {
/*  498 */         return builder.buildParsed();
/*      */       }
/*  500 */       return null;
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  507 */       Builder builder = newBuilder();
/*  508 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  509 */         return builder.buildParsed();
/*      */       }
/*  511 */       return null;
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  517 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static KeyValProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  523 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  527 */       return Builder.access$1200(); } 
/*  528 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(KeyValProto prototype) {
/*  530 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  532 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  715 */       StatsProtos.internalForceInit();
/*  716 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasKey;
/*  666 */       private String key_ = "";
/*      */       private boolean hasValue;
/*  689 */       private String value_ = "";
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  538 */         return StatsProtos.internal_static_apphosting_KeyValProto_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  543 */         return StatsProtos.internal_static_apphosting_KeyValProto_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  551 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  555 */         super.clear();
/*  556 */         this.key_ = "";
/*  557 */         this.hasKey = false;
/*  558 */         this.value_ = "";
/*  559 */         this.hasValue = false;
/*  560 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  564 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  569 */         return StatsProtos.KeyValProto.getDescriptor();
/*      */       }
/*      */ 
/*      */       public StatsProtos.KeyValProto getDefaultInstanceForType() {
/*  573 */         return StatsProtos.KeyValProto.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public StatsProtos.KeyValProto build() {
/*  577 */         StatsProtos.KeyValProto result = buildPartial();
/*  578 */         if (!result.isInitialized()) {
/*  579 */           throw newUninitializedMessageException(result);
/*      */         }
/*  581 */         return result;
/*      */       }
/*      */ 
/*      */       private StatsProtos.KeyValProto buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  586 */         StatsProtos.KeyValProto result = buildPartial();
/*  587 */         if (!result.isInitialized()) {
/*  588 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  591 */         return result;
/*      */       }
/*      */ 
/*      */       public StatsProtos.KeyValProto buildPartial() {
/*  595 */         StatsProtos.KeyValProto result = new StatsProtos.KeyValProto(this, null);
/*  596 */         StatsProtos.KeyValProto.access$1402(result, this.hasKey);
/*  597 */         StatsProtos.KeyValProto.access$1502(result, this.key_);
/*  598 */         StatsProtos.KeyValProto.access$1602(result, this.hasValue);
/*  599 */         StatsProtos.KeyValProto.access$1702(result, this.value_);
/*  600 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  604 */         if ((other instanceof StatsProtos.KeyValProto)) {
/*  605 */           return mergeFrom((StatsProtos.KeyValProto)other);
/*      */         }
/*  607 */         super.mergeFrom(other);
/*  608 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(StatsProtos.KeyValProto other)
/*      */       {
/*  613 */         if (other == StatsProtos.KeyValProto.getDefaultInstance()) return this;
/*  614 */         if (other.hasKey()) {
/*  615 */           setKey(other.getKey());
/*      */         }
/*  617 */         if (other.hasValue()) {
/*  618 */           setValue(other.getValue());
/*      */         }
/*  620 */         mergeUnknownFields(other.getUnknownFields());
/*  621 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  625 */         if (!this.hasKey) return false;
/*  626 */         return this.hasValue;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  634 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  638 */           int tag = input.readTag();
/*  639 */           switch (tag) {
/*      */           case 0:
/*  641 */             setUnknownFields(unknownFields.build());
/*  642 */             return this;
/*      */           default:
/*  644 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  646 */             setUnknownFields(unknownFields.build());
/*  647 */             return this;
/*      */           case 10:
/*  652 */             setKey(input.readString());
/*  653 */             break;
/*      */           case 18:
/*  656 */             setValue(input.readString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasKey()
/*      */       {
/*  668 */         return this.hasKey;
/*      */       }
/*      */       public String getKey() {
/*  671 */         return this.key_;
/*      */       }
/*      */       public Builder setKey(String value) {
/*  674 */         if (value == null) {
/*  675 */           throw new NullPointerException();
/*      */         }
/*  677 */         this.hasKey = true;
/*  678 */         this.key_ = value;
/*  679 */         return this;
/*      */       }
/*      */       public Builder clearKey() {
/*  682 */         this.hasKey = false;
/*  683 */         this.key_ = StatsProtos.KeyValProto.getDefaultInstance().getKey();
/*  684 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasValue()
/*      */       {
/*  691 */         return this.hasValue;
/*      */       }
/*      */       public String getValue() {
/*  694 */         return this.value_;
/*      */       }
/*      */       public Builder setValue(String value) {
/*  697 */         if (value == null) {
/*  698 */           throw new NullPointerException();
/*      */         }
/*  700 */         this.hasValue = true;
/*  701 */         this.value_ = value;
/*  702 */         return this;
/*      */       }
/*      */       public Builder clearValue() {
/*  705 */         this.hasValue = false;
/*  706 */         this.value_ = StatsProtos.KeyValProto.getDefaultInstance().getValue();
/*  707 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class AggregateRpcStatsProto extends GeneratedMessage
/*      */   {
/*  357 */     private static final AggregateRpcStatsProto defaultInstance = new AggregateRpcStatsProto(true);
/*      */     public static final int SERVICE_CALL_NAME_FIELD_NUMBER = 1;
/*      */     private boolean hasServiceCallName;
/*      */     private String serviceCallName_;
/*      */     public static final int TOTAL_AMOUNT_OF_CALLS_FIELD_NUMBER = 3;
/*      */     private boolean hasTotalAmountOfCalls;
/*      */     private long totalAmountOfCalls_;
/*   82 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private AggregateRpcStatsProto(Builder builder)
/*      */     {
/*   15 */       super();
/*      */     }
/*      */     private AggregateRpcStatsProto(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto getDefaultInstance() {
/*   21 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public AggregateRpcStatsProto getDefaultInstanceForType() {
/*   25 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*   30 */       return StatsProtos.internal_static_apphosting_AggregateRpcStatsProto_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*   35 */       return StatsProtos.internal_static_apphosting_AggregateRpcStatsProto_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasServiceCallName()
/*      */     {
/*   43 */       return this.hasServiceCallName;
/*      */     }
/*      */     public String getServiceCallName() {
/*   46 */       return this.serviceCallName_;
/*      */     }
/*      */ 
/*      */     public boolean hasTotalAmountOfCalls()
/*      */     {
/*   54 */       return this.hasTotalAmountOfCalls;
/*      */     }
/*      */     public long getTotalAmountOfCalls() {
/*   57 */       return this.totalAmountOfCalls_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*   61 */       this.serviceCallName_ = "";
/*   62 */       this.totalAmountOfCalls_ = 0L;
/*      */     }
/*      */     public final boolean isInitialized() {
/*   65 */       if (!this.hasServiceCallName) return false;
/*   66 */       return this.hasTotalAmountOfCalls;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/*   72 */       getSerializedSize();
/*   73 */       if (hasServiceCallName()) {
/*   74 */         output.writeString(1, getServiceCallName());
/*      */       }
/*   76 */       if (hasTotalAmountOfCalls()) {
/*   77 */         output.writeInt64(3, getTotalAmountOfCalls());
/*      */       }
/*   79 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*   84 */       int size = this.memoizedSerializedSize;
/*   85 */       if (size != -1) return size;
/*      */ 
/*   87 */       size = 0;
/*   88 */       if (hasServiceCallName()) {
/*   89 */         size += CodedOutputStream.computeStringSize(1, getServiceCallName());
/*      */       }
/*      */ 
/*   92 */       if (hasTotalAmountOfCalls()) {
/*   93 */         size += CodedOutputStream.computeInt64Size(3, getTotalAmountOfCalls());
/*      */       }
/*      */ 
/*   96 */       size += getUnknownFields().getSerializedSize();
/*   97 */       this.memoizedSerializedSize = size;
/*   98 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  103 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  109 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  115 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  120 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  126 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(InputStream input) throws IOException
/*      */     {
/*  131 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  137 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  142 */       Builder builder = newBuilder();
/*  143 */       if (builder.mergeDelimitedFrom(input)) {
/*  144 */         return builder.buildParsed();
/*      */       }
/*  146 */       return null;
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  153 */       Builder builder = newBuilder();
/*  154 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  155 */         return builder.buildParsed();
/*      */       }
/*  157 */       return null;
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  163 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static AggregateRpcStatsProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  169 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  173 */       return Builder.access$300(); } 
/*  174 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(AggregateRpcStatsProto prototype) {
/*  176 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  178 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  358 */       StatsProtos.internalForceInit();
/*  359 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasServiceCallName;
/*  312 */       private String serviceCallName_ = "";
/*      */       private boolean hasTotalAmountOfCalls;
/*      */       private long totalAmountOfCalls_;
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  184 */         return StatsProtos.internal_static_apphosting_AggregateRpcStatsProto_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  189 */         return StatsProtos.internal_static_apphosting_AggregateRpcStatsProto_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  197 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  201 */         super.clear();
/*  202 */         this.serviceCallName_ = "";
/*  203 */         this.hasServiceCallName = false;
/*  204 */         this.totalAmountOfCalls_ = 0L;
/*  205 */         this.hasTotalAmountOfCalls = false;
/*  206 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  210 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  215 */         return StatsProtos.AggregateRpcStatsProto.getDescriptor();
/*      */       }
/*      */ 
/*      */       public StatsProtos.AggregateRpcStatsProto getDefaultInstanceForType() {
/*  219 */         return StatsProtos.AggregateRpcStatsProto.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public StatsProtos.AggregateRpcStatsProto build() {
/*  223 */         StatsProtos.AggregateRpcStatsProto result = buildPartial();
/*  224 */         if (!result.isInitialized()) {
/*  225 */           throw newUninitializedMessageException(result);
/*      */         }
/*  227 */         return result;
/*      */       }
/*      */ 
/*      */       private StatsProtos.AggregateRpcStatsProto buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  232 */         StatsProtos.AggregateRpcStatsProto result = buildPartial();
/*  233 */         if (!result.isInitialized()) {
/*  234 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  237 */         return result;
/*      */       }
/*      */ 
/*      */       public StatsProtos.AggregateRpcStatsProto buildPartial() {
/*  241 */         StatsProtos.AggregateRpcStatsProto result = new StatsProtos.AggregateRpcStatsProto(this, null);
/*  242 */         StatsProtos.AggregateRpcStatsProto.access$502(result, this.hasServiceCallName);
/*  243 */         StatsProtos.AggregateRpcStatsProto.access$602(result, this.serviceCallName_);
/*  244 */         StatsProtos.AggregateRpcStatsProto.access$702(result, this.hasTotalAmountOfCalls);
/*  245 */         StatsProtos.AggregateRpcStatsProto.access$802(result, this.totalAmountOfCalls_);
/*  246 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  250 */         if ((other instanceof StatsProtos.AggregateRpcStatsProto)) {
/*  251 */           return mergeFrom((StatsProtos.AggregateRpcStatsProto)other);
/*      */         }
/*  253 */         super.mergeFrom(other);
/*  254 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(StatsProtos.AggregateRpcStatsProto other)
/*      */       {
/*  259 */         if (other == StatsProtos.AggregateRpcStatsProto.getDefaultInstance()) return this;
/*  260 */         if (other.hasServiceCallName()) {
/*  261 */           setServiceCallName(other.getServiceCallName());
/*      */         }
/*  263 */         if (other.hasTotalAmountOfCalls()) {
/*  264 */           setTotalAmountOfCalls(other.getTotalAmountOfCalls());
/*      */         }
/*  266 */         mergeUnknownFields(other.getUnknownFields());
/*  267 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  271 */         if (!this.hasServiceCallName) return false;
/*  272 */         return this.hasTotalAmountOfCalls;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  280 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  284 */           int tag = input.readTag();
/*  285 */           switch (tag) {
/*      */           case 0:
/*  287 */             setUnknownFields(unknownFields.build());
/*  288 */             return this;
/*      */           default:
/*  290 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  292 */             setUnknownFields(unknownFields.build());
/*  293 */             return this;
/*      */           case 10:
/*  298 */             setServiceCallName(input.readString());
/*  299 */             break;
/*      */           case 24:
/*  302 */             setTotalAmountOfCalls(input.readInt64());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasServiceCallName()
/*      */       {
/*  314 */         return this.hasServiceCallName;
/*      */       }
/*      */       public String getServiceCallName() {
/*  317 */         return this.serviceCallName_;
/*      */       }
/*      */       public Builder setServiceCallName(String value) {
/*  320 */         if (value == null) {
/*  321 */           throw new NullPointerException();
/*      */         }
/*  323 */         this.hasServiceCallName = true;
/*  324 */         this.serviceCallName_ = value;
/*  325 */         return this;
/*      */       }
/*      */       public Builder clearServiceCallName() {
/*  328 */         this.hasServiceCallName = false;
/*  329 */         this.serviceCallName_ = StatsProtos.AggregateRpcStatsProto.getDefaultInstance().getServiceCallName();
/*  330 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasTotalAmountOfCalls()
/*      */       {
/*  337 */         return this.hasTotalAmountOfCalls;
/*      */       }
/*      */       public long getTotalAmountOfCalls() {
/*  340 */         return this.totalAmountOfCalls_;
/*      */       }
/*      */       public Builder setTotalAmountOfCalls(long value) {
/*  343 */         this.hasTotalAmountOfCalls = true;
/*  344 */         this.totalAmountOfCalls_ = value;
/*  345 */         return this;
/*      */       }
/*      */       public Builder clearTotalAmountOfCalls() {
/*  348 */         this.hasTotalAmountOfCalls = false;
/*  349 */         this.totalAmountOfCalls_ = 0L;
/*  350 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.tools.appstats.StatsProtos
 * JD-Core Version:    0.6.0
 */