/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class CodedInputStream
/*     */ {
/*     */   private final byte[] buffer;
/*     */   private int bufferSize;
/*     */   private int bufferSizeAfterLimit;
/*     */   private int bufferPos;
/*     */   private final InputStream input;
/*     */   private int lastTag;
/*     */   private int totalBytesRetired;
/* 486 */   private int currentLimit = 2147483647;
/*     */   private int recursionDepth;
/* 490 */   private int recursionLimit = 64;
/*     */ 
/* 493 */   private int sizeLimit = 67108864;
/*     */   private static final int DEFAULT_RECURSION_LIMIT = 64;
/*     */   private static final int DEFAULT_SIZE_LIMIT = 67108864;
/*     */   private static final int BUFFER_SIZE = 4096;
/*     */ 
/*     */   public static CodedInputStream newInstance(InputStream input)
/*     */   {
/*  27 */     return new CodedInputStream(input);
/*     */   }
/*     */ 
/*     */   public static CodedInputStream newInstance(byte[] buf)
/*     */   {
/*  34 */     return newInstance(buf, 0, buf.length);
/*     */   }
/*     */ 
/*     */   public static CodedInputStream newInstance(byte[] buf, int off, int len)
/*     */   {
/*  42 */     CodedInputStream result = new CodedInputStream(buf, off, len);
/*     */     try
/*     */     {
/*  49 */       result.pushLimit(len);
/*     */     }
/*     */     catch (InvalidProtocolBufferException ex)
/*     */     {
/*  58 */       throw new IllegalArgumentException(ex);
/*     */     }
/*  60 */     return result;
/*     */   }
/*     */ 
/*     */   public int readTag()
/*     */     throws IOException
/*     */   {
/*  71 */     if (isAtEnd()) {
/*  72 */       this.lastTag = 0;
/*  73 */       return 0;
/*     */     }
/*     */ 
/*  76 */     this.lastTag = readRawVarint32();
/*  77 */     if (WireFormat.getTagFieldNumber(this.lastTag) == 0)
/*     */     {
/*  80 */       throw InvalidProtocolBufferException.invalidTag();
/*     */     }
/*  82 */     return this.lastTag;
/*     */   }
/*     */ 
/*     */   public void checkLastTagWas(int value)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/*  95 */     if (this.lastTag != value)
/*  96 */       throw InvalidProtocolBufferException.invalidEndTag();
/*     */   }
/*     */ 
/*     */   public boolean skipField(int tag)
/*     */     throws IOException
/*     */   {
/* 107 */     switch (WireFormat.getTagWireType(tag)) {
/*     */     case 0:
/* 109 */       readInt32();
/* 110 */       return true;
/*     */     case 1:
/* 112 */       readRawLittleEndian64();
/* 113 */       return true;
/*     */     case 2:
/* 115 */       skipRawBytes(readRawVarint32());
/* 116 */       return true;
/*     */     case 3:
/* 118 */       skipMessage();
/* 119 */       checkLastTagWas(WireFormat.makeTag(WireFormat.getTagFieldNumber(tag), 4));
/*     */ 
/* 122 */       return true;
/*     */     case 4:
/* 124 */       return false;
/*     */     case 5:
/* 126 */       readRawLittleEndian32();
/* 127 */       return true;
/*     */     }
/* 129 */     throw InvalidProtocolBufferException.invalidWireType();
/*     */   }
/*     */ 
/*     */   public void skipMessage()
/*     */     throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/* 139 */       int tag = readTag();
/* 140 */       if ((tag == 0) || (!skipField(tag)))
/* 141 */         return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public double readDouble()
/*     */     throws IOException
/*     */   {
/* 150 */     return Double.longBitsToDouble(readRawLittleEndian64());
/*     */   }
/*     */ 
/*     */   public float readFloat() throws IOException
/*     */   {
/* 155 */     return Float.intBitsToFloat(readRawLittleEndian32());
/*     */   }
/*     */ 
/*     */   public long readUInt64() throws IOException
/*     */   {
/* 160 */     return readRawVarint64();
/*     */   }
/*     */ 
/*     */   public long readInt64() throws IOException
/*     */   {
/* 165 */     return readRawVarint64();
/*     */   }
/*     */ 
/*     */   public int readInt32() throws IOException
/*     */   {
/* 170 */     return readRawVarint32();
/*     */   }
/*     */ 
/*     */   public long readFixed64() throws IOException
/*     */   {
/* 175 */     return readRawLittleEndian64();
/*     */   }
/*     */ 
/*     */   public int readFixed32() throws IOException
/*     */   {
/* 180 */     return readRawLittleEndian32();
/*     */   }
/*     */ 
/*     */   public boolean readBool() throws IOException
/*     */   {
/* 185 */     return readRawVarint32() != 0;
/*     */   }
/*     */ 
/*     */   public String readString() throws IOException
/*     */   {
/* 190 */     int size = readRawVarint32();
/* 191 */     if ((size <= this.bufferSize - this.bufferPos) && (size > 0))
/*     */     {
/* 194 */       String result = new String(this.buffer, this.bufferPos, size, "UTF-8");
/* 195 */       this.bufferPos += size;
/* 196 */       return result;
/*     */     }
/*     */ 
/* 199 */     return new String(readRawBytes(size), "UTF-8");
/*     */   }
/*     */ 
/*     */   public void readGroup(int fieldNumber, MessageLite.Builder builder, ExtensionRegistryLite extensionRegistry)
/*     */     throws IOException
/*     */   {
/* 208 */     if (this.recursionDepth >= this.recursionLimit) {
/* 209 */       throw InvalidProtocolBufferException.recursionLimitExceeded();
/*     */     }
/* 211 */     this.recursionDepth += 1;
/* 212 */     builder.mergeFrom(this, extensionRegistry);
/* 213 */     checkLastTagWas(WireFormat.makeTag(fieldNumber, 4));
/*     */ 
/* 215 */     this.recursionDepth -= 1;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void readUnknownGroup(int fieldNumber, MessageLite.Builder builder)
/*     */     throws IOException
/*     */   {
/* 234 */     readGroup(fieldNumber, builder, null);
/*     */   }
/*     */ 
/*     */   public void readMessage(MessageLite.Builder builder, ExtensionRegistryLite extensionRegistry)
/*     */     throws IOException
/*     */   {
/* 241 */     int length = readRawVarint32();
/* 242 */     if (this.recursionDepth >= this.recursionLimit) {
/* 243 */       throw InvalidProtocolBufferException.recursionLimitExceeded();
/*     */     }
/* 245 */     int oldLimit = pushLimit(length);
/* 246 */     this.recursionDepth += 1;
/* 247 */     builder.mergeFrom(this, extensionRegistry);
/* 248 */     checkLastTagWas(0);
/* 249 */     this.recursionDepth -= 1;
/* 250 */     popLimit(oldLimit);
/*     */   }
/*     */ 
/*     */   public ByteString readBytes() throws IOException
/*     */   {
/* 255 */     int size = readRawVarint32();
/* 256 */     if ((size <= this.bufferSize - this.bufferPos) && (size > 0))
/*     */     {
/* 259 */       ByteString result = ByteString.copyFrom(this.buffer, this.bufferPos, size);
/* 260 */       this.bufferPos += size;
/* 261 */       return result;
/*     */     }
/*     */ 
/* 264 */     return ByteString.copyFrom(readRawBytes(size));
/*     */   }
/*     */ 
/*     */   public int readUInt32()
/*     */     throws IOException
/*     */   {
/* 270 */     return readRawVarint32();
/*     */   }
/*     */ 
/*     */   public int readEnum()
/*     */     throws IOException
/*     */   {
/* 278 */     return readRawVarint32();
/*     */   }
/*     */ 
/*     */   public int readSFixed32() throws IOException
/*     */   {
/* 283 */     return readRawLittleEndian32();
/*     */   }
/*     */ 
/*     */   public long readSFixed64() throws IOException
/*     */   {
/* 288 */     return readRawLittleEndian64();
/*     */   }
/*     */ 
/*     */   public int readSInt32() throws IOException
/*     */   {
/* 293 */     return decodeZigZag32(readRawVarint32());
/*     */   }
/*     */ 
/*     */   public long readSInt64() throws IOException
/*     */   {
/* 298 */     return decodeZigZag64(readRawVarint64());
/*     */   }
/*     */ 
/*     */   public int readRawVarint32()
/*     */     throws IOException
/*     */   {
/* 308 */     byte tmp = readRawByte();
/* 309 */     if (tmp >= 0) {
/* 310 */       return tmp;
/*     */     }
/* 312 */     int result = tmp & 0x7F;
/* 313 */     if ((tmp = readRawByte()) >= 0) {
/* 314 */       result |= tmp << 7;
/*     */     } else {
/* 316 */       result |= (tmp & 0x7F) << 7;
/* 317 */       if ((tmp = readRawByte()) >= 0) {
/* 318 */         result |= tmp << 14;
/*     */       } else {
/* 320 */         result |= (tmp & 0x7F) << 14;
/* 321 */         if ((tmp = readRawByte()) >= 0) {
/* 322 */           result |= tmp << 21;
/*     */         } else {
/* 324 */           result |= (tmp & 0x7F) << 21;
/* 325 */           result |= (tmp = readRawByte()) << 28;
/* 326 */           if (tmp < 0)
/*     */           {
/* 328 */             for (int i = 0; i < 5; i++) {
/* 329 */               if (readRawByte() >= 0) {
/* 330 */                 return result;
/*     */               }
/*     */             }
/* 333 */             throw InvalidProtocolBufferException.malformedVarint();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 338 */     return result;
/*     */   }
/*     */ 
/*     */   static int readRawVarint32(InputStream input)
/*     */     throws IOException
/*     */   {
/* 349 */     int firstByte = input.read();
/* 350 */     if (firstByte == -1) {
/* 351 */       throw InvalidProtocolBufferException.truncatedMessage();
/*     */     }
/* 353 */     return readRawVarint32(firstByte, input);
/*     */   }
/*     */ 
/*     */   public static int readRawVarint32(int firstByte, InputStream input)
/*     */     throws IOException
/*     */   {
/* 363 */     if ((firstByte & 0x80) == 0) {
/* 364 */       return firstByte;
/*     */     }
/*     */ 
/* 367 */     int result = firstByte & 0x7F;
/* 368 */     int offset = 7;
/* 369 */     for (; offset < 32; offset += 7) {
/* 370 */       int b = input.read();
/* 371 */       if (b == -1) {
/* 372 */         throw InvalidProtocolBufferException.truncatedMessage();
/*     */       }
/* 374 */       result |= (b & 0x7F) << offset;
/* 375 */       if ((b & 0x80) == 0) {
/* 376 */         return result;
/*     */       }
/*     */     }
/*     */ 
/* 380 */     for (; offset < 64; offset += 7) {
/* 381 */       int b = input.read();
/* 382 */       if (b == -1) {
/* 383 */         throw InvalidProtocolBufferException.truncatedMessage();
/*     */       }
/* 385 */       if ((b & 0x80) == 0) {
/* 386 */         return result;
/*     */       }
/*     */     }
/* 389 */     throw InvalidProtocolBufferException.malformedVarint();
/*     */   }
/*     */ 
/*     */   public long readRawVarint64() throws IOException
/*     */   {
/* 394 */     int shift = 0;
/* 395 */     long result = 0L;
/* 396 */     while (shift < 64) {
/* 397 */       byte b = readRawByte();
/* 398 */       result |= (b & 0x7F) << shift;
/* 399 */       if ((b & 0x80) == 0) {
/* 400 */         return result;
/*     */       }
/* 402 */       shift += 7;
/*     */     }
/* 404 */     throw InvalidProtocolBufferException.malformedVarint();
/*     */   }
/*     */ 
/*     */   public int readRawLittleEndian32() throws IOException
/*     */   {
/* 409 */     byte b1 = readRawByte();
/* 410 */     byte b2 = readRawByte();
/* 411 */     byte b3 = readRawByte();
/* 412 */     byte b4 = readRawByte();
/* 413 */     return b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24;
/*     */   }
/*     */ 
/*     */   public long readRawLittleEndian64()
/*     */     throws IOException
/*     */   {
/* 421 */     byte b1 = readRawByte();
/* 422 */     byte b2 = readRawByte();
/* 423 */     byte b3 = readRawByte();
/* 424 */     byte b4 = readRawByte();
/* 425 */     byte b5 = readRawByte();
/* 426 */     byte b6 = readRawByte();
/* 427 */     byte b7 = readRawByte();
/* 428 */     byte b8 = readRawByte();
/* 429 */     return b1 & 0xFF | (b2 & 0xFF) << 8 | (b3 & 0xFF) << 16 | (b4 & 0xFF) << 24 | (b5 & 0xFF) << 32 | (b6 & 0xFF) << 40 | (b7 & 0xFF) << 48 | (b8 & 0xFF) << 56;
/*     */   }
/*     */ 
/*     */   public static int decodeZigZag32(int n)
/*     */   {
/* 450 */     return n >>> 1 ^ -(n & 0x1);
/*     */   }
/*     */ 
/*     */   public static long decodeZigZag64(long n)
/*     */   {
/* 464 */     return n >>> 1 ^ -(n & 1L);
/*     */   }
/*     */ 
/*     */   private CodedInputStream(byte[] buffer, int off, int len)
/*     */   {
/* 500 */     this.buffer = buffer;
/* 501 */     this.bufferSize = (off + len);
/* 502 */     this.bufferPos = off;
/* 503 */     this.totalBytesRetired = (-off);
/* 504 */     this.input = null;
/*     */   }
/*     */ 
/*     */   private CodedInputStream(InputStream input) {
/* 508 */     this.buffer = new byte[4096];
/* 509 */     this.bufferSize = 0;
/* 510 */     this.bufferPos = 0;
/* 511 */     this.totalBytesRetired = 0;
/* 512 */     this.input = input;
/*     */   }
/*     */ 
/*     */   public int setRecursionLimit(int limit)
/*     */   {
/* 523 */     if (limit < 0) {
/* 524 */       throw new IllegalArgumentException("Recursion limit cannot be negative: " + limit);
/*     */     }
/*     */ 
/* 527 */     int oldLimit = this.recursionLimit;
/* 528 */     this.recursionLimit = limit;
/* 529 */     return oldLimit;
/*     */   }
/*     */ 
/*     */   public int setSizeLimit(int limit)
/*     */   {
/* 549 */     if (limit < 0) {
/* 550 */       throw new IllegalArgumentException("Size limit cannot be negative: " + limit);
/*     */     }
/*     */ 
/* 553 */     int oldLimit = this.sizeLimit;
/* 554 */     this.sizeLimit = limit;
/* 555 */     return oldLimit;
/*     */   }
/*     */ 
/*     */   public void resetSizeCounter()
/*     */   {
/* 562 */     this.totalBytesRetired = (-this.bufferPos);
/*     */   }
/*     */ 
/*     */   public int pushLimit(int byteLimit)
/*     */     throws InvalidProtocolBufferException
/*     */   {
/* 580 */     if (byteLimit < 0) {
/* 581 */       throw InvalidProtocolBufferException.negativeSize();
/*     */     }
/* 583 */     byteLimit += this.totalBytesRetired + this.bufferPos;
/* 584 */     int oldLimit = this.currentLimit;
/* 585 */     if (byteLimit > oldLimit) {
/* 586 */       throw InvalidProtocolBufferException.truncatedMessage();
/*     */     }
/* 588 */     this.currentLimit = byteLimit;
/*     */ 
/* 590 */     recomputeBufferSizeAfterLimit();
/*     */ 
/* 592 */     return oldLimit;
/*     */   }
/*     */ 
/*     */   private void recomputeBufferSizeAfterLimit() {
/* 596 */     this.bufferSize += this.bufferSizeAfterLimit;
/* 597 */     int bufferEnd = this.totalBytesRetired + this.bufferSize;
/* 598 */     if (bufferEnd > this.currentLimit)
/*     */     {
/* 600 */       this.bufferSizeAfterLimit = (bufferEnd - this.currentLimit);
/* 601 */       this.bufferSize -= this.bufferSizeAfterLimit;
/*     */     } else {
/* 603 */       this.bufferSizeAfterLimit = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void popLimit(int oldLimit)
/*     */   {
/* 613 */     this.currentLimit = oldLimit;
/* 614 */     recomputeBufferSizeAfterLimit();
/*     */   }
/*     */ 
/*     */   public int getBytesUntilLimit()
/*     */   {
/* 622 */     if (this.currentLimit == 2147483647) {
/* 623 */       return -1;
/*     */     }
/*     */ 
/* 626 */     int currentAbsolutePosition = this.totalBytesRetired + this.bufferPos;
/* 627 */     return this.currentLimit - currentAbsolutePosition;
/*     */   }
/*     */ 
/*     */   public boolean isAtEnd()
/*     */     throws IOException
/*     */   {
/* 636 */     return (this.bufferPos == this.bufferSize) && (!refillBuffer(false));
/*     */   }
/*     */ 
/*     */   public int getTotalBytesRead()
/*     */   {
/* 644 */     return this.totalBytesRetired + this.bufferPos;
/*     */   }
/*     */ 
/*     */   private boolean refillBuffer(boolean mustSucceed)
/*     */     throws IOException
/*     */   {
/* 655 */     if (this.bufferPos < this.bufferSize) {
/* 656 */       throw new IllegalStateException("refillBuffer() called when buffer wasn't empty.");
/*     */     }
/*     */ 
/* 660 */     if (this.totalBytesRetired + this.bufferSize == this.currentLimit)
/*     */     {
/* 662 */       if (mustSucceed) {
/* 663 */         throw InvalidProtocolBufferException.truncatedMessage();
/*     */       }
/* 665 */       return false;
/*     */     }
/*     */ 
/* 669 */     this.totalBytesRetired += this.bufferSize;
/*     */ 
/* 671 */     this.bufferPos = 0;
/* 672 */     this.bufferSize = (this.input == null ? -1 : this.input.read(this.buffer));
/* 673 */     if ((this.bufferSize == 0) || (this.bufferSize < -1)) {
/* 674 */       throw new IllegalStateException("InputStream#read(byte[]) returned invalid result: " + this.bufferSize + "\nThe InputStream implementation is buggy.");
/*     */     }
/*     */ 
/* 678 */     if (this.bufferSize == -1) {
/* 679 */       this.bufferSize = 0;
/* 680 */       if (mustSucceed) {
/* 681 */         throw InvalidProtocolBufferException.truncatedMessage();
/*     */       }
/* 683 */       return false;
/*     */     }
/*     */ 
/* 686 */     recomputeBufferSizeAfterLimit();
/* 687 */     int totalBytesRead = this.totalBytesRetired + this.bufferSize + this.bufferSizeAfterLimit;
/*     */ 
/* 689 */     if ((totalBytesRead > this.sizeLimit) || (totalBytesRead < 0)) {
/* 690 */       throw InvalidProtocolBufferException.sizeLimitExceeded();
/*     */     }
/* 692 */     return true;
/*     */   }
/*     */ 
/*     */   public byte readRawByte()
/*     */     throws IOException
/*     */   {
/* 703 */     if (this.bufferPos == this.bufferSize) {
/* 704 */       refillBuffer(true);
/*     */     }
/* 706 */     return this.buffer[(this.bufferPos++)];
/*     */   }
/*     */ 
/*     */   public byte[] readRawBytes(int size)
/*     */     throws IOException
/*     */   {
/* 716 */     if (size < 0) {
/* 717 */       throw InvalidProtocolBufferException.negativeSize();
/*     */     }
/*     */ 
/* 720 */     if (this.totalBytesRetired + this.bufferPos + size > this.currentLimit)
/*     */     {
/* 722 */       skipRawBytes(this.currentLimit - this.totalBytesRetired - this.bufferPos);
/*     */ 
/* 724 */       throw InvalidProtocolBufferException.truncatedMessage();
/*     */     }
/*     */ 
/* 727 */     if (size <= this.bufferSize - this.bufferPos)
/*     */     {
/* 729 */       byte[] bytes = new byte[size];
/* 730 */       System.arraycopy(this.buffer, this.bufferPos, bytes, 0, size);
/* 731 */       this.bufferPos += size;
/* 732 */       return bytes;
/* 733 */     }if (size < 4096)
/*     */     {
/* 738 */       byte[] bytes = new byte[size];
/* 739 */       int pos = this.bufferSize - this.bufferPos;
/* 740 */       System.arraycopy(this.buffer, this.bufferPos, bytes, 0, pos);
/* 741 */       this.bufferPos = this.bufferSize;
/*     */ 
/* 746 */       refillBuffer(true);
/*     */ 
/* 748 */       while (size - pos > this.bufferSize) {
/* 749 */         System.arraycopy(this.buffer, 0, bytes, pos, this.bufferSize);
/* 750 */         pos += this.bufferSize;
/* 751 */         this.bufferPos = this.bufferSize;
/* 752 */         refillBuffer(true);
/*     */       }
/*     */ 
/* 755 */       System.arraycopy(this.buffer, 0, bytes, pos, size - pos);
/* 756 */       this.bufferPos = (size - pos);
/*     */ 
/* 758 */       return bytes;
/*     */     }
/*     */ 
/* 770 */     int originalBufferPos = this.bufferPos;
/* 771 */     int originalBufferSize = this.bufferSize;
/*     */ 
/* 774 */     this.totalBytesRetired += this.bufferSize;
/* 775 */     this.bufferPos = 0;
/* 776 */     this.bufferSize = 0;
/*     */ 
/* 779 */     int sizeLeft = size - (originalBufferSize - originalBufferPos);
/* 780 */     List chunks = new ArrayList();
/*     */ 
/* 782 */     while (sizeLeft > 0) {
/* 783 */       byte[] chunk = new byte[Math.min(sizeLeft, 4096)];
/* 784 */       int pos = 0;
/* 785 */       while (pos < chunk.length) {
/* 786 */         int n = this.input == null ? -1 : this.input.read(chunk, pos, chunk.length - pos);
/*     */ 
/* 788 */         if (n == -1) {
/* 789 */           throw InvalidProtocolBufferException.truncatedMessage();
/*     */         }
/* 791 */         this.totalBytesRetired += n;
/* 792 */         pos += n;
/*     */       }
/* 794 */       sizeLeft -= chunk.length;
/* 795 */       chunks.add(chunk);
/*     */     }
/*     */ 
/* 799 */     byte[] bytes = new byte[size];
/*     */ 
/* 802 */     int pos = originalBufferSize - originalBufferPos;
/* 803 */     System.arraycopy(this.buffer, originalBufferPos, bytes, 0, pos);
/*     */ 
/* 806 */     for (byte[] chunk : chunks) {
/* 807 */       System.arraycopy(chunk, 0, bytes, pos, chunk.length);
/* 808 */       pos += chunk.length;
/*     */     }
/*     */ 
/* 812 */     return bytes;
/*     */   }
/*     */ 
/*     */   public void skipRawBytes(int size)
/*     */     throws IOException
/*     */   {
/* 823 */     if (size < 0) {
/* 824 */       throw InvalidProtocolBufferException.negativeSize();
/*     */     }
/*     */ 
/* 827 */     if (this.totalBytesRetired + this.bufferPos + size > this.currentLimit)
/*     */     {
/* 829 */       skipRawBytes(this.currentLimit - this.totalBytesRetired - this.bufferPos);
/*     */ 
/* 831 */       throw InvalidProtocolBufferException.truncatedMessage();
/*     */     }
/*     */ 
/* 834 */     if (size <= this.bufferSize - this.bufferPos)
/*     */     {
/* 836 */       this.bufferPos += size;
/*     */     }
/*     */     else {
/* 839 */       int pos = this.bufferSize - this.bufferPos;
/* 840 */       this.totalBytesRetired += pos;
/* 841 */       this.bufferPos = 0;
/* 842 */       this.bufferSize = 0;
/*     */ 
/* 845 */       while (pos < size) {
/* 846 */         int n = this.input == null ? -1 : (int)this.input.skip(size - pos);
/* 847 */         if (n <= 0) {
/* 848 */           throw InvalidProtocolBufferException.truncatedMessage();
/*     */         }
/* 850 */         pos += n;
/* 851 */         this.totalBytesRetired += n;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.CodedInputStream
 * JD-Core Version:    0.6.0
 */