/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Iterator;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public abstract class Converter<A, B>
/*     */ {
/* 236 */   private static final Converter<?, ?> IDENTITY_CONVERTER = new IdentityConverter(null);
/*     */ 
/*     */   public abstract B convert(@Nullable A paramA);
/*     */ 
/*     */   public abstract A reverse(@Nullable B paramB);
/*     */ 
/*     */   public Converter<B, A> inverse()
/*     */   {
/*  44 */     return new InverseConverter(this);
/*     */   }
/*     */ 
/*     */   public <C> Converter<A, C> chain(Converter<B, C> otherConverter)
/*     */   {
/*  89 */     return ChainedConverter.of(this, (Converter)Preconditions.checkNotNull(otherConverter, "otherConverter"));
/*     */   }
/*     */ 
/*     */   public Function<A, B> asFunction()
/*     */   {
/* 140 */     return new Function() {
/*     */       public B apply(@Nullable A from) {
/* 142 */         return Converter.this.convert(from);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Iterable<B> convertAll(Iterable<? extends A> iterable)
/*     */   {
/* 152 */     Preconditions.checkNotNull(iterable, "iterable");
/*     */ 
/* 154 */     return new Iterable(iterable) {
/*     */       public Iterator<B> iterator() {
/* 156 */         return Converter.this.convertAll(this.val$iterable.iterator());
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Iterator<B> convertAll(Iterator<? extends A> iterator)
/*     */   {
/* 166 */     Preconditions.checkNotNull(iterator, "iterator");
/*     */ 
/* 168 */     return new Iterator(iterator) {
/*     */       public boolean hasNext() {
/* 170 */         return this.val$iterator.hasNext();
/*     */       }
/*     */ 
/*     */       public B next() {
/* 174 */         return Converter.this.convert(this.val$iterator.next());
/*     */       }
/*     */ 
/*     */       public void remove() {
/* 178 */         this.val$iterator.remove();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Converter<A, B> nullPreserving()
/*     */   {
/* 189 */     return new NullPreservingConverter(this);
/*     */   }
/*     */ 
/*     */   public static <T> Converter<T, T> identity()
/*     */   {
/* 233 */     return IDENTITY_CONVERTER;
/*     */   }
/*     */ 
/*     */   private static class IdentityConverter extends Converter<Object, Object>
/*     */   {
/*     */     public Object convert(@Nullable Object object)
/*     */     {
/* 243 */       return object;
/*     */     }
/*     */ 
/*     */     public Object reverse(@Nullable Object object) {
/* 247 */       return object;
/*     */     }
/*     */ 
/*     */     public Converter<Object, Object> inverse() {
/* 251 */       return this;
/*     */     }
/*     */ 
/*     */     public <C> Converter<Object, C> chain(Converter<Object, C> otherConverter) {
/* 255 */       return (Converter)Preconditions.checkNotNull(otherConverter, "otherConverter");
/*     */     }
/*     */ 
/*     */     public Iterable<Object> convertAll(Iterable<?> iterable)
/*     */     {
/* 261 */       return (Iterable)Preconditions.checkNotNull(iterable, "iterable");
/*     */     }
/*     */ 
/*     */     public Iterator<Object> convertAll(Iterator<?> iterator)
/*     */     {
/* 267 */       return (Iterator)Preconditions.checkNotNull(iterator, "iterator");
/*     */     }
/*     */ 
/*     */     public Converter<Object, Object> nullPreserving() {
/* 271 */       return this;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 275 */       return "IdentityConverter";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class NullPreservingConverter<A, B> extends Converter<A, B>
/*     */   {
/*     */     private final Converter<A, B> converter;
/*     */ 
/*     */     NullPreservingConverter(Converter<A, B> converter)
/*     */     {
/* 196 */       this.converter = converter;
/*     */     }
/*     */ 
/*     */     public B convert(A object) {
/* 200 */       return object == null ? null : this.converter.convert(object);
/*     */     }
/*     */ 
/*     */     public A reverse(B object) {
/* 204 */       return object == null ? null : this.converter.reverse(object);
/*     */     }
/*     */ 
/*     */     public Converter<A, B> nullPreserving() {
/* 208 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 212 */       if ((obj instanceof NullPreservingConverter)) {
/* 213 */         NullPreservingConverter that = (NullPreservingConverter)obj;
/* 214 */         return this.converter.equals(that.converter);
/*     */       }
/* 216 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 220 */       return this.converter.hashCode() ^ 0x55555555;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 224 */       return "NullPreservingConverter(" + this.converter + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class ChainedConverter<A, B, C> extends Converter<A, C>
/*     */   {
/*     */     final Converter<A, B> first;
/*     */     final Converter<B, C> second;
/*     */ 
/*     */     ChainedConverter(Converter<A, B> first, Converter<B, C> second)
/*     */     {
/*  97 */       this.first = first;
/*  98 */       this.second = second;
/*     */     }
/*     */ 
/*     */     public C convert(@Nullable A object) {
/* 102 */       return this.second.convert(this.first.convert(object));
/*     */     }
/*     */ 
/*     */     public A reverse(@Nullable C object) {
/* 106 */       return this.first.reverse(this.second.reverse(object));
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object o) {
/* 110 */       if (this == o) {
/* 111 */         return true;
/*     */       }
/*     */ 
/* 114 */       return ((o instanceof ChainedConverter)) && (this.first.equals(((ChainedConverter)o).first)) && (this.second.equals(((ChainedConverter)o).second));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 120 */       return 31 * this.first.hashCode() + this.second.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 124 */       return "ChainedConverter(" + this.first + "," + this.second + ")";
/*     */     }
/*     */ 
/*     */     static <A, B, C> Converter<A, C> of(Converter<A, B> first, Converter<B, C> second)
/*     */     {
/* 130 */       return second == Converter.IDENTITY_CONVERTER ? first : new ChainedConverter(first, second);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class InverseConverter<A, B> extends Converter<B, A>
/*     */   {
/*     */     final Converter<A, B> original;
/*     */ 
/*     */     InverseConverter(Converter<A, B> original)
/*     */     {
/*  51 */       this.original = original;
/*     */     }
/*     */ 
/*     */     public A convert(@Nullable B object) {
/*  55 */       return this.original.reverse(object);
/*     */     }
/*     */ 
/*     */     public B reverse(@Nullable A object) {
/*  59 */       return this.original.convert(object);
/*     */     }
/*     */ 
/*     */     public Converter<A, B> inverse() {
/*  63 */       return this.original;
/*     */     }
/*     */ 
/*     */     public boolean equals(@Nullable Object o) {
/*  67 */       if (this == o) {
/*  68 */         return true;
/*     */       }
/*     */ 
/*  71 */       return ((o instanceof InverseConverter)) && (this.original.equals(((InverseConverter)o).original));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/*  76 */       return this.original.hashCode() ^ 0xFFFFFFFF;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  80 */       return "InverseConverter(" + this.original + ")";
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.Converter
 * JD-Core Version:    0.6.0
 */