/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.EmptyStackException;
/*     */ 
/*     */ public final class ProtocolSource
/*     */ {
/*     */   private final byte[] buf;
/*     */   private int pos;
/*     */   private int limit;
/*     */   private IntStack lengthStack;
/*     */ 
/*     */   public ProtocolSource(byte[] array, int offset, int length)
/*     */   {
/*  33 */     this.buf = array;
/*  34 */     this.pos = offset;
/*  35 */     this.limit = (offset + length);
/*     */   }
/*     */ 
/*     */   public ProtocolSource(byte[] array)
/*     */   {
/*  46 */     this(array, 0, array.length);
/*     */   }
/*     */ 
/*     */   public ProtocolSource(ByteBuffer buffer, int offset, int length)
/*     */   {
/*  62 */     if (buffer.hasArray()) {
/*  63 */       if (offset + length > buffer.limit()) {
/*  64 */         throw new BufferUnderflowException();
/*     */       }
/*  66 */       this.buf = buffer.array();
/*  67 */       this.pos = (buffer.arrayOffset() + offset);
/*  68 */       this.limit = (this.pos + length);
/*     */     } else {
/*  70 */       this.limit = length;
/*  71 */       this.pos = 0;
/*  72 */       this.buf = new byte[this.limit];
/*  73 */       int oldPosition = buffer.position();
/*  74 */       buffer.position(offset);
/*  75 */       buffer.get(this.buf);
/*  76 */       buffer.position(oldPosition);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ProtocolSource(ByteBuffer buffer)
/*     */   {
/*  90 */     this(buffer, buffer.position(), buffer.remaining());
/*     */   }
/*     */ 
/*     */   public final ProtocolSource push(int length)
/*     */   {
/* 101 */     if (this.pos + length > this.limit) {
/* 102 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 104 */     getLengthStack().push(this.limit);
/* 105 */     this.limit = (this.pos + length);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   public final ProtocolSource pop()
/*     */   {
/* 117 */     if (this.pos > this.limit) {
/* 118 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 120 */     this.pos = this.limit;
/* 121 */     this.limit = getLengthStack().pop();
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   private IntStack getLengthStack()
/*     */   {
/* 131 */     if (this.lengthStack == null) {
/* 132 */       return this.lengthStack = new IntStack();
/*     */     }
/* 134 */     return this.lengthStack;
/*     */   }
/*     */ 
/*     */   final void reset()
/*     */   {
/* 142 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   public final int position()
/*     */   {
/* 149 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public final byte[] array()
/*     */   {
/* 158 */     return this.buf;
/*     */   }
/*     */ 
/*     */   public final void getBytes(byte[] dst, int offset, int length)
/*     */   {
/* 170 */     if (this.pos + length > this.limit) {
/* 171 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 173 */     System.arraycopy(this.buf, this.pos, dst, offset, length);
/* 174 */     this.pos += length;
/*     */   }
/*     */ 
/*     */   public final byte getByteUnmasked()
/*     */   {
/* 181 */     return this.buf[(this.pos++)];
/*     */   }
/*     */ 
/*     */   public final int getByte()
/*     */   {
/* 188 */     return getByteUnmasked() & 0xFF;
/*     */   }
/*     */ 
/*     */   public final int getShort()
/*     */   {
/* 195 */     if (this.pos + 2 > this.limit) {
/* 196 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 198 */     return this.buf[(this.pos++)] & 0xFF | this.buf[(this.pos++)] << 8;
/*     */   }
/*     */ 
/*     */   public final int getInt()
/*     */   {
/* 205 */     if (this.pos + 4 > this.limit) {
/* 206 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 208 */     return this.buf[(this.pos++)] & 0xFF | (this.buf[(this.pos++)] & 0xFF) << 8 | (this.buf[(this.pos++)] & 0xFF) << 16 | this.buf[(this.pos++)] << 24;
/*     */   }
/*     */ 
/*     */   public final long getLong()
/*     */   {
/* 218 */     if (this.pos + 8 > this.limit) {
/* 219 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 221 */     long b1 = this.buf[(this.pos++)] & 0xFF;
/* 222 */     long b2 = this.buf[(this.pos++)] & 0xFF;
/* 223 */     long b3 = this.buf[(this.pos++)] & 0xFF;
/* 224 */     long b4 = this.buf[(this.pos++)] & 0xFF;
/* 225 */     long b5 = this.buf[(this.pos++)] & 0xFF;
/* 226 */     long b6 = this.buf[(this.pos++)] & 0xFF;
/* 227 */     long b7 = this.buf[(this.pos++)] & 0xFF;
/* 228 */     long b8 = this.buf[(this.pos++)];
/* 229 */     return b8 << 56 | b7 << 48 | b6 << 40 | b5 << 32 | b4 << 24 | b3 << 16 | b2 << 8 | b1;
/*     */   }
/*     */ 
/*     */   public final int remaining()
/*     */   {
/* 243 */     return this.limit - this.pos;
/*     */   }
/*     */ 
/*     */   public final boolean hasRemaining()
/*     */   {
/* 250 */     return this.pos != this.limit;
/*     */   }
/*     */ 
/*     */   public final void skip(int n)
/*     */   {
/* 259 */     if (this.pos + n > this.limit) {
/* 260 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 262 */     this.pos += n;
/*     */   }
/*     */ 
/*     */   public final int getVarInt()
/*     */   {
/*     */     int tmp;
/* 276 */     if ((tmp = getByteUnmasked()) >= 0) {
/* 277 */       return tmp;
/*     */     }
/* 279 */     int result = tmp & 0x7F;
/* 280 */     if ((tmp = getByteUnmasked()) >= 0) {
/* 281 */       result |= tmp << 7;
/*     */     } else {
/* 283 */       result |= (tmp & 0x7F) << 7;
/* 284 */       if ((tmp = getByteUnmasked()) >= 0) {
/* 285 */         result |= tmp << 14;
/*     */       } else {
/* 287 */         result |= (tmp & 0x7F) << 14;
/* 288 */         if ((tmp = getByteUnmasked()) >= 0) {
/* 289 */           result |= tmp << 21;
/*     */         } else {
/* 291 */           result |= (tmp & 0x7F) << 21;
/* 292 */           result |= (tmp = getByteUnmasked()) << 28;
/* 293 */           while (tmp < 0)
/*     */           {
/* 297 */             tmp = getByteUnmasked();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 302 */     if (this.pos > this.limit) {
/* 303 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 305 */     return result;
/*     */   }
/*     */ 
/*     */   public final long getVarLong()
/*     */   {
/*     */   }
/*     */ 
/*     */   public final boolean getBoolean()
/*     */   {
/* 373 */     return getVarInt() != 0;
/*     */   }
/*     */ 
/*     */   public final float getFloat()
/*     */   {
/* 384 */     return Float.intBitsToFloat(getInt());
/*     */   }
/*     */ 
/*     */   public final double getDouble()
/*     */   {
/* 395 */     return Double.longBitsToDouble(getLong());
/*     */   }
/*     */ 
/*     */   public final byte[] getPrefixedData()
/*     */   {
/* 405 */     int len = getVarInt();
/* 406 */     byte[] b = newByteArray(len);
/* 407 */     getBytes(b, 0, len);
/* 408 */     return b;
/*     */   }
/*     */ 
/*     */   private static int getTagFormat(int tagWord)
/*     */   {
/* 415 */     return tagWord & 0x7;
/*     */   }
/*     */ 
/*     */   private static int getTag(int tagWord)
/*     */   {
/* 422 */     return tagWord >>> 3;
/*     */   }
/*     */ 
/*     */   private static int makeTagWord(int tag, int tagFormat)
/*     */   {
/* 429 */     assert ((tagFormat & 0x7) == tagFormat);
/* 430 */     return tag << 3 | tagFormat;
/*     */   }
/*     */ 
/*     */   private static int endTag(int tag)
/*     */   {
/* 437 */     return makeTagWord(tag, 4);
/*     */   }
/*     */ 
/*     */   public final void skipData(int tagWord)
/*     */   {
/* 448 */     switch (getTagFormat(tagWord)) { case 0:
/*     */     case 5:
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/* 450 */     case 4: } while (getByteUnmasked() < 0) { continue;
/*     */ 
/* 454 */       skip(4);
/* 455 */       break;
/*     */ 
/* 457 */       skip(8);
/* 458 */       break;
/*     */ 
/* 460 */       skip(getVarInt());
/* 461 */       break;
/*     */ 
/* 464 */       int endWord = endTag(getTag(tagWord));
/*     */       int nextTagWord;
/* 465 */       while ((nextTagWord = getVarInt()) != endWord) {
/* 466 */         skipData(nextTagWord); continue;
/*     */ 
/* 470 */         throw new IllegalArgumentException("unexpected ENDGROUP " + tagWord);
/*     */ 
/* 472 */         throw new IllegalArgumentException("unexpected type code in " + tagWord);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public final byte[] getUninterpreted(int tagWord)
/*     */   {
/* 485 */     int startPosition = this.pos;
/* 486 */     skipData(tagWord);
/* 487 */     int length = this.pos - startPosition;
/* 488 */     byte[] b = newByteArray(length);
/* 489 */     System.arraycopy(this.buf, startPosition, b, 0, length);
/* 490 */     return b;
/*     */   }
/*     */ 
/*     */   private static byte[] newByteArray(int length) {
/*     */     try {
/* 495 */       return new byte[length];
/*     */     } catch (NegativeArraySizeException e) {
/* 497 */       throw new IllegalArgumentException(e);
/*     */     } catch (OutOfMemoryError e) {
/*     */     }
/* 500 */     throw new IllegalArgumentException(e);
/*     */   }
/*     */ 
/*     */   private static class IntStack
/*     */   {
/*     */     int[] stack;
/*     */     int topPos;
/*     */ 
/*     */     IntStack()
/*     */     {
/* 515 */       this.stack = new int[1];
/* 516 */       this.topPos = 0;
/*     */     }
/*     */ 
/*     */     void push(int i) {
/* 520 */       if (this.topPos == this.stack.length) {
/* 521 */         int newLength = this.stack.length * 2;
/* 522 */         int[] copy = new int[newLength];
/* 523 */         System.arraycopy(this.stack, 0, copy, 0, this.stack.length);
/* 524 */         this.stack = copy;
/*     */       }
/* 526 */       this.stack[this.topPos] = i;
/* 527 */       this.topPos += 1;
/*     */     }
/*     */ 
/*     */     int pop() {
/* 531 */       if (this.topPos == 0) {
/* 532 */         throw new EmptyStackException();
/*     */       }
/* 534 */       return this.stack[(--this.topPos)];
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource
 * JD-Core Version:    0.6.0
 */