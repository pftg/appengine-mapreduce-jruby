/*    */ package javax.mail;
/*    */ 
/*    */ public class SendFailedException extends MessagingException
/*    */ {
/*    */   protected transient Address[] invalid;
/*    */   protected transient Address[] validSent;
/*    */   protected transient Address[] validUnsent;
/*    */ 
/*    */   public SendFailedException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SendFailedException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ 
/*    */   public SendFailedException(String message, Exception cause) {
/* 39 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public SendFailedException(String message, Exception cause, Address[] validSent, Address[] validUnsent, Address[] invalid)
/*    */   {
/* 47 */     this(message, cause);
/* 48 */     this.invalid = invalid;
/* 49 */     this.validSent = validSent;
/* 50 */     this.validUnsent = validUnsent;
/*    */   }
/*    */ 
/*    */   public Address[] getValidSentAddresses() {
/* 54 */     return this.validSent;
/*    */   }
/*    */ 
/*    */   public Address[] getValidUnsentAddresses() {
/* 58 */     return this.validUnsent;
/*    */   }
/*    */ 
/*    */   public Address[] getInvalidAddresses() {
/* 62 */     return this.invalid;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.SendFailedException
 * JD-Core Version:    0.6.0
 */