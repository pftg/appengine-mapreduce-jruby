/*    */ package com.google.appengine.api.images;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class CompositeTransform extends Transform
/*    */ {
/*    */   private final List<Transform> transforms;
/*    */ 
/*    */   CompositeTransform()
/*    */   {
/* 22 */     this.transforms = new LinkedList();
/*    */   }
/*    */ 
/*    */   CompositeTransform(Collection<Transform> transformsToAdd)
/*    */   {
/* 31 */     this();
/* 32 */     this.transforms.addAll(transformsToAdd);
/*    */   }
/*    */ 
/*    */   public CompositeTransform concatenate(Transform other)
/*    */   {
/* 41 */     this.transforms.add(other);
/* 42 */     return this;
/*    */   }
/*    */ 
/*    */   public CompositeTransform preConcatenate(Transform other)
/*    */   {
/* 51 */     this.transforms.add(0, other);
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */   void apply(ImagesServicePb.ImagesTransformRequest request)
/*    */   {
/* 57 */     for (Transform transform : this.transforms)
/* 58 */       transform.apply(request);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.images.CompositeTransform
 * JD-Core Version:    0.6.0
 */