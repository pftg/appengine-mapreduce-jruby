/*     */ package com.google.appengine.api;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.Environment;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public final class NamespaceManager
/*     */ {
/*     */   private static final int NAMESPACE_MAX_LENGTH = 100;
/*     */   private static final String NAMESPACE_REGEX = "[0-9A-Za-z._-]{0,100}";
/*  72 */   private static final Pattern NAMESPACE_PATTERN = Pattern.compile("[0-9A-Za-z._-]{0,100}");
/*     */ 
/*  79 */   private static final String CURRENT_NAMESPACE_KEY = NamespaceManager.class.getName() + ".currentNamespace";
/*     */ 
/*  81 */   private static final String APPS_NAMESPACE_KEY = NamespaceManager.class.getName() + ".appsNamespace";
/*     */ 
/*     */   public static void set(String newNamespace)
/*     */   {
/*  91 */     if (newNamespace == null) {
/*  92 */       ApiProxy.getCurrentEnvironment().getAttributes().remove(CURRENT_NAMESPACE_KEY);
/*     */     } else {
/*  94 */       validateNamespace(newNamespace);
/*  95 */       ApiProxy.Environment environment = ApiProxy.getCurrentEnvironment();
/*     */ 
/*  97 */       environment.getAttributes().put(CURRENT_NAMESPACE_KEY, newNamespace);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String get()
/*     */   {
/* 108 */     Map attributes = ApiProxy.getCurrentEnvironment().getAttributes();
/* 109 */     return (String)attributes.get(CURRENT_NAMESPACE_KEY);
/*     */   }
/*     */ 
/*     */   public static String getGoogleAppsNamespace()
/*     */   {
/* 117 */     Map attributes = ApiProxy.getCurrentEnvironment().getAttributes();
/* 118 */     String appsNamespace = (String)attributes.get(APPS_NAMESPACE_KEY);
/* 119 */     return appsNamespace == null ? "" : appsNamespace;
/*     */   }
/*     */ 
/*     */   public static void validateNamespace(String namespace)
/*     */   {
/* 128 */     if (!NAMESPACE_PATTERN.matcher(namespace).matches())
/* 129 */       throw new IllegalArgumentException("Namespace '" + namespace + "' does not match pattern '" + NAMESPACE_PATTERN + "'.");
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.NamespaceManager
 * JD-Core Version:    0.6.0
 */