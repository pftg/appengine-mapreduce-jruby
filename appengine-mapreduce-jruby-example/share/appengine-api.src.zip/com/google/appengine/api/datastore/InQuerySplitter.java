/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ class InQuerySplitter extends BaseQuerySplitter
/*    */ {
/*    */   public List<QuerySplitComponent> split(List<Query.FilterPredicate> remainingFilters, List<Query.SortPredicate> sorts)
/*    */   {
/* 41 */     List result = new ArrayList();
/* 42 */     Iterator itr = remainingFilters.iterator();
/* 43 */     while (itr.hasNext()) {
/* 44 */       Query.FilterPredicate filter = (Query.FilterPredicate)itr.next();
/* 45 */       if (filter.getOperator() == Query.FilterOperator.IN) {
/* 46 */         QuerySplitComponent component = new QuerySplitComponent(filter.getPropertyName(), sorts);
/*    */ 
/* 48 */         List comparableValues = new ArrayList();
/* 49 */         for (Iterator i$ = ((Iterable)filter.getValue()).iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 50 */           comparableValues.add(new BaseQuerySplitter.ComparableValue(value));
/*    */         }
/* 52 */         if (comparableValues.size() <= 1)
/*    */         {
/*    */           continue;
/*    */         }
/* 56 */         if (component.getDirection() != null)
/*    */         {
/* 59 */           Collections.sort(comparableValues, getValueComparator(component.getDirection()));
/*    */         }
/*    */ 
/* 62 */         for (BaseQuerySplitter.ComparableValue value : comparableValues) {
/* 63 */           component.addFilters(new Query.FilterPredicate[] { new Query.FilterPredicate(filter.getPropertyName(), Query.FilterOperator.EQUAL, value.getValue()) });
/*    */         }
/*    */ 
/* 66 */         result.add(component);
/* 67 */         itr.remove();
/*    */       }
/*    */     }
/*    */ 
/* 71 */     return result;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.InQuerySplitter
 * JD-Core Version:    0.6.0
 */