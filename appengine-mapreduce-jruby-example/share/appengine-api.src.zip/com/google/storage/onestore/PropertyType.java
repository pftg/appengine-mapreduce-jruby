/*     */ package com.google.storage.onestore;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.collect.Lists;
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*     */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.PointValue;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.ReferenceValue;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.ReferenceValuePathElement;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.PropertyValue.UserValue;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public enum PropertyType
/*     */ {
/*  27 */   NULL(new OnestoreEntity.PropertyValue(), new OnestoreEntity.PropertyValue()), 
/*     */ 
/*  30 */   INT64(new OnestoreEntity.PropertyValue().setInt64Value(-9223372036854775808L), new OnestoreEntity.PropertyValue().setInt64Value(0L)), 
/*     */ 
/*  33 */   BOOLEAN(new OnestoreEntity.PropertyValue().setBooleanValue(false), new OnestoreEntity.PropertyValue().setBooleanValue(false)), 
/*     */ 
/*  36 */   STRING(new OnestoreEntity.PropertyValue().setStringValue(""), new OnestoreEntity.PropertyValue().setStringValue("none")), 
/*     */ 
/*  39 */   DOUBLE(new OnestoreEntity.PropertyValue().setDoubleValue((-1.0D / 0.0D)), new OnestoreEntity.PropertyValue().setDoubleValue(0.0D)), 
/*     */ 
/*  42 */   POINT(new OnestoreEntity.PropertyValue().setPointValue(new OnestoreEntity.PropertyValue.PointValue().setX((-1.0D / 0.0D)).setY((-1.0D / 0.0D))), new OnestoreEntity.PropertyValue().setPointValue(new OnestoreEntity.PropertyValue.PointValue().setX(0.0D).setY(0.0D))), 
/*     */ 
/*  48 */   USER(new OnestoreEntity.PropertyValue().setUserValue(new OnestoreEntity.PropertyValue.UserValue().setEmail("").setAuthDomain("").setGaiaid(-9223372036854775808L)), new OnestoreEntity.PropertyValue().setUserValue(new OnestoreEntity.PropertyValue.UserValue().setEmail("none").setAuthDomain("none").setGaiaid(0L))), 
/*     */ 
/*  58 */   REFERENCE(new OnestoreEntity.PropertyValue().setReferenceValue(new OnestoreEntity.PropertyValue.ReferenceValue()), new OnestoreEntity.PropertyValue().setReferenceValue(new OnestoreEntity.PropertyValue.ReferenceValue()));
/*     */ 
/*     */   private static SortedMap<Integer, PropertyType> types;
/*     */   public final OnestoreEntity.PropertyValue minValue;
/*     */   public final OnestoreEntity.PropertyValue placeholderValue;
/*     */   public final int tag;
/*     */ 
/*     */   private PropertyType(OnestoreEntity.PropertyValue minValue, OnestoreEntity.PropertyValue placeholderValue)
/*     */   {
/* 101 */     this.minValue = minValue;
/* 102 */     this.placeholderValue = placeholderValue;
/*     */ 
/* 104 */     this.tag = findOnlyTag(minValue);
/* 105 */     Preconditions.checkArgument(this.tag == findOnlyTag(placeholderValue));
/*     */   }
/*     */ 
/*     */   public static PropertyType getType(OnestoreEntity.PropertyValue value)
/*     */   {
/* 113 */     return (PropertyType)types.get(Integer.valueOf(findOnlyTag(value)));
/*     */   }
/*     */ 
/*     */   public static List<PropertyType> getTypes(OnestoreEntity.PropertyValue value)
/*     */   {
/* 120 */     List foundTypes = Lists.newArrayList();
/*     */ 
/* 122 */     for (Iterator i$ = findTags(value).iterator(); i$.hasNext(); ) { int tag = ((Integer)i$.next()).intValue();
/* 123 */       foundTypes.add(types.get(Integer.valueOf(tag)));
/*     */     }
/* 125 */     return foundTypes;
/*     */   }
/*     */ 
/*     */   public PropertyType next()
/*     */   {
/* 133 */     SortedMap rest = types.tailMap(Integer.valueOf(this.tag + 1));
/*     */ 
/* 135 */     if (rest.isEmpty()) {
/* 136 */       return null;
/*     */     }
/* 138 */     return (PropertyType)rest.get(rest.firstKey());
/*     */   }
/*     */ 
/*     */   private static int findOnlyTag(OnestoreEntity.PropertyValue value)
/*     */   {
/* 149 */     List tags = findTags(value);
/*     */ 
/* 151 */     if (tags.isEmpty()) {
/* 152 */       return -1;
/*     */     }
/* 154 */     Preconditions.checkArgument(tags.size() == 1);
/* 155 */     return ((Integer)tags.get(0)).intValue();
/*     */   }
/*     */ 
/*     */   private static List<Integer> findTags(OnestoreEntity.PropertyValue value)
/*     */   {
/* 163 */     List tags = Lists.newArrayList();
/*     */ 
/* 165 */     for (ProtocolType.FieldType field : ProtocolType.getTags(value)) {
/* 166 */       if (field.size(value) == 1) {
/* 167 */         tags.add(Integer.valueOf(field.getTag()));
/*     */       }
/*     */     }
/*     */ 
/* 171 */     return tags;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  65 */     types = new TreeMap();
/*     */ 
/*  68 */     for (PropertyType type : EnumSet.allOf(PropertyType.class)) {
/*  69 */       types.put(Integer.valueOf(type.tag), type);
/*     */     }
/*     */ 
/*  73 */     REFERENCE.minValue.getMutableReferenceValue().setApp("");
/*  74 */     REFERENCE.placeholderValue.getMutableReferenceValue().setApp("none").addPathElement().setType("none").setName("none");
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.storage.onestore.PropertyType
 * JD-Core Version:    0.6.0
 */