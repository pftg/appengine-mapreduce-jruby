/*      */ package com.google.appengine.repackaged.com.google.io.protocol;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.collect.Maps;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.proto.ProtocolDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.proto.ProtocolDescriptor.DeclaredType;
/*      */ import com.google.appengine.repackaged.com.google.io.protocol.proto.ProtocolDescriptor.Tag;
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.IndexedPropertyDescriptor;
/*      */ import java.beans.IntrospectionException;
/*      */ import java.beans.Introspector;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class ProtocolType
/*      */ {
/*      */   private final Class<? extends ProtocolMessage> clazz;
/*      */   private final FieldType[] fields;
/*  858 */   private final SortedMap<Integer, FieldType> tagsByNumber = new TreeMap();
/*      */ 
/*  862 */   private final SortedMap<String, FieldType> tagsByPrintName = new TreeMap();
/*      */   private final String protocolDescriptorString;
/*      */   private ProtocolDescriptor protocolDescriptor;
/*      */   private PropertyDescriptor[] propertyDescriptors;
/*      */   private boolean havePropertyDescriptors;
/*      */ 
/*      */   public ProtocolType(Class<? extends ProtocolMessage> myClass, String encodedProtocolDescriptor, FieldType[] fields)
/*      */   {
/*  813 */     this.clazz = myClass;
/*  814 */     this.fields = fields;
/*  815 */     for (FieldType ti : fields) {
/*  816 */       this.tagsByNumber.put(Integer.valueOf(ti.tag), ti);
/*  817 */       this.tagsByPrintName.put(ti.printName, ti);
/*      */     }
/*  819 */     for (FieldType ti : fields) {
/*      */       try {
/*  821 */         String base = ti.internalName + "_";
/*  822 */         FieldType.access$302(ti, myClass.getDeclaredField(base));
/*  823 */         ti.dataField.setAccessible(true);
/*  824 */         switch (1.$SwitchMap$com$google$io$protocol$ProtocolType$Presence[ti.presence.ordinal()]) {
/*      */         case 1:
/*      */         case 2:
/*  827 */           if (ti.bitTag == -2147483648)
/*      */           {
/*  829 */             FieldType.access$602(ti, myClass.getDeclaredField("has_" + base));
/*      */           } else {
/*  831 */             String varName = "optional_" + (ti.bitTag >> 5) + "_";
/*  832 */             FieldType.access$602(ti, myClass.getDeclaredField(varName));
/*      */           }
/*  834 */           ti.sizeField.setAccessible(true);
/*  835 */           break;
/*      */         case 3:
/*  837 */           if (!ti.baseType.isScalar())
/*      */             break;
/*  839 */           FieldType.access$602(ti, myClass.getDeclaredField(base + "elts_"));
/*  840 */           ti.sizeField.setAccessible(true);
/*      */         }
/*      */       }
/*      */       catch (NoSuchFieldException e)
/*      */       {
/*  845 */         throw new AssertionError("Error on field: " + ti);
/*      */       }
/*      */     }
/*  848 */     this.protocolDescriptorString = encodedProtocolDescriptor;
/*      */   }
/*      */ 
/*      */   public static void visit(ProtocolMessage message, Visitor visitor)
/*      */   {
/*  879 */     ProtocolType protocolType = message.getProtocolType();
/*  880 */     List fields = Arrays.asList(protocolType.fields);
/*  881 */     protocolType.visitInternal(message, visitor, fields);
/*      */   }
/*      */ 
/*      */   public static void visitInTagOrder(ProtocolMessage message, Visitor visitor)
/*      */   {
/*  892 */     ProtocolType protocolType = message.getProtocolType();
/*  893 */     Collection fields = protocolType.tagsByNumber.values();
/*  894 */     protocolType.visitInternal(message, visitor, fields);
/*      */   }
/*      */ 
/*      */   public static void visit(ProtocolMessage message, MessageVisitor visitor)
/*      */   {
/*  906 */     ProtocolType protocolType = message.getProtocolType();
/*  907 */     List fields = Arrays.asList(protocolType.fields);
/*  908 */     protocolType.visitInternal(message, visitor, fields);
/*      */   }
/*      */ 
/*      */   public static void visitInTagOrder(ProtocolMessage message, MessageVisitor visitor)
/*      */   {
/*  919 */     ProtocolType protocolType = message.getProtocolType();
/*  920 */     Collection fields = protocolType.tagsByNumber.values();
/*  921 */     protocolType.visitInternal(message, visitor, fields);
/*      */   }
/*      */ 
/*      */   public static List<FieldType> getTags(ProtocolMessage message)
/*      */   {
/*  931 */     ProtocolType protocolType = message.getProtocolType();
/*  932 */     return Collections.unmodifiableList(Arrays.asList(protocolType.fields));
/*      */   }
/*      */ 
/*      */   public static List<FieldType> getTags(Class<? extends ProtocolMessage> clazz)
/*      */   {
/*  942 */     while ((clazz.getSuperclass() != ProtocolMessage.class) && (clazz.getSuperclass() != ExtendableProtocolMessage.class))
/*      */     {
/*  944 */       clazz = clazz.getSuperclass();
/*      */     }
/*      */ 
/*  947 */     ProtocolType protocolType = ProtocolSupport.newInstance(clazz).getProtocolType();
/*      */ 
/*  949 */     return Collections.unmodifiableList(Arrays.asList(protocolType.fields));
/*      */   }
/*      */ 
/*      */   protected void visitInternal(ProtocolMessage message, Visitor visitor, Iterable<FieldType> fields)
/*      */   {
/*  962 */     for (FieldType fieldType : fields)
/*  963 */       fieldType.visit(message, visitor);
/*      */   }
/*      */ 
/*      */   protected void visitInternal(ProtocolMessage message, MessageVisitor visitor, Iterable<FieldType> fields)
/*      */   {
/*  977 */     for (FieldType fieldType : fields)
/*  978 */       fieldType.visit(message, visitor);
/*      */   }
/*      */ 
/*      */   public FieldType getTagInfo(int tag)
/*      */   {
/*  988 */     return (FieldType)this.tagsByNumber.get(Integer.valueOf(tag));
/*      */   }
/*      */ 
/*      */   public FieldType getTagInfo(String name)
/*      */   {
/*  997 */     return (FieldType)this.tagsByPrintName.get(name);
/*      */   }
/*      */ 
/*      */   public Class<? extends ProtocolMessage> getProtocolMessageClass()
/*      */   {
/* 1006 */     return this.clazz;
/*      */   }
/*      */ 
/*      */   synchronized PropertyDescriptor[] getPropertyDescriptors()
/*      */   {
/* 1019 */     if (!this.havePropertyDescriptors) {
/* 1020 */       this.propertyDescriptors = createPropertyDescriptors(this.clazz);
/* 1021 */       this.havePropertyDescriptors = true;
/*      */     }
/* 1023 */     return (PropertyDescriptor[])this.propertyDescriptors.clone();
/*      */   }
/*      */ 
/*      */   private static PropertyDescriptor[] createPropertyDescriptors(Class cls)
/*      */   {
/*      */     try
/*      */     {
/* 1037 */       BeanInfo beanInfo = Introspector.getBeanInfo(cls, 2);
/*      */ 
/* 1039 */       Map propertiesByName = Maps.newHashMap();
/* 1040 */       PropertyDescriptor[] properties = beanInfo.getPropertyDescriptors();
/* 1041 */       if (properties != null) {
/* 1042 */         for (PropertyDescriptor property : properties) {
/* 1043 */           propertiesByName.put(property.getName(), property);
/*      */         }
/*      */       }
/* 1046 */       for (Method method : cls.getMethods()) {
/* 1047 */         if ((!method.getName().startsWith("set")) || (!method.getReturnType().equals(cls)))
/*      */           continue;
/* 1049 */         String propertyName = Introspector.decapitalize(method.getName().substring(3));
/*      */ 
/* 1051 */         PropertyDescriptor existing = (PropertyDescriptor)propertiesByName.get(propertyName);
/* 1052 */         Method readMethod = null;
/* 1053 */         if (existing != null) {
/* 1054 */           if (existing.getWriteMethod() != null) {
/*      */             continue;
/*      */           }
/* 1057 */           readMethod = existing.getReadMethod();
/*      */         }
/* 1059 */         Class[] argTypes = method.getParameterTypes();
/* 1060 */         int argCount = argTypes.length;
/*      */         PropertyDescriptor descriptor;
/*      */         PropertyDescriptor descriptor;
/* 1062 */         if (argCount == 1) {
/* 1063 */           descriptor = new PropertyDescriptor(propertyName, readMethod, method);
/*      */         } else {
/* 1065 */           if ((argCount != 2) || (argTypes[0] != Integer.TYPE)) continue;
/* 1066 */           descriptor = new IndexedPropertyDescriptor(propertyName, null, null, readMethod, method);
/*      */         }
/*      */ 
/* 1071 */         propertiesByName.put(propertyName, descriptor);
/*      */       }
/*      */ 
/* 1074 */       return (PropertyDescriptor[])propertiesByName.values().toArray(new PropertyDescriptor[propertiesByName.size()]);
/*      */     } catch (IntrospectionException exception) {
/*      */     }
/* 1077 */     throw new IllegalStateException(exception);
/*      */   }
/*      */ 
/*      */   public synchronized ProtocolDescriptor getProtocolDescriptor()
/*      */   {
/* 1086 */     if (this.protocolDescriptor == null) {
/* 1087 */       if (this.protocolDescriptorString == null) {
/* 1088 */         throw new IllegalStateException("No protocol descriptor");
/*      */       }
/* 1090 */       this.protocolDescriptor = decodeProtocolDescriptor(this.protocolDescriptorString);
/*      */     }
/* 1092 */     return this.protocolDescriptor;
/*      */   }
/*      */ 
/*      */   private ProtocolDescriptor decodeProtocolDescriptor(String encoding)
/*      */   {
/* 1103 */     int size = encoding.length();
/* 1104 */     byte[] bytes = new byte[size];
/*      */ 
/* 1106 */     encoding.getBytes(0, size, bytes, 0);
/* 1107 */     ProtocolDescriptor result = new ProtocolDescriptor();
/* 1108 */     if (!result.mergeFrom(bytes)) {
/* 1109 */       throw new AssertionError("Bad ProtocolDescriptor");
/*      */     }
/*      */ 
/* 1119 */     result.setProtoName(result.getName());
/* 1120 */     result.setName(this.clazz.getName());
/* 1121 */     Map tagMap = Maps.newHashMap();
/* 1122 */     tagMap.put(Integer.valueOf(-1), this);
/* 1123 */     for (int tagIndex = 0; tagIndex < result.tagSize(); tagIndex++) {
/* 1124 */       ProtocolDescriptor.Tag tag = result.getMutableTag(tagIndex);
/* 1125 */       ProtocolDescriptor.DeclaredType declaredType = ProtocolDescriptor.DeclaredType.valueOf(tag.getDeclaredType());
/*      */ 
/* 1127 */       if ((declaredType != ProtocolDescriptor.DeclaredType.TYPE_GROUP) && (declaredType != ProtocolDescriptor.DeclaredType.TYPE_FOREIGN))
/*      */         continue;
/* 1129 */       int parentIndex = tag.hasParent() ? tag.getParent() : -1;
/* 1130 */       ProtocolType parent = (ProtocolType)tagMap.get(Integer.valueOf(parentIndex));
/* 1131 */       FieldType tagInfo = parent.getTagInfo(tag.getNumber());
/* 1132 */       if (declaredType == ProtocolDescriptor.DeclaredType.TYPE_GROUP) {
/* 1133 */         Class groupClass = tagInfo.getSubclass();
/* 1134 */         ProtocolType subProtocolType = ProtocolSupport.newInstance(groupClass).getProtocolType();
/*      */ 
/* 1136 */         tagMap.put(Integer.valueOf(tagIndex), subProtocolType);
/*      */       } else {
/* 1138 */         tag.setForeignProtoName(tag.getForeign());
/* 1139 */         tag.setForeign(tagInfo.getSubclass().getName());
/*      */       }
/*      */     }
/*      */ 
/* 1143 */     return result;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1149 */     return "<ProtocolType: " + this.clazz.getSimpleName() + ">";
/*      */   }
/*      */ 
/*      */   public static class FieldType
/*      */   {
/*      */     private static final int MISSING_BIT_INDEX = -2147483648;
/*      */     private final String internalName;
/*      */     private final String printName;
/*      */     private final int tag;
/*      */     private final ProtocolType.FieldBaseType baseType;
/*      */     private final ProtocolType.Presence presence;
/*      */     private final Class<? extends ProtocolMessage> subclass;
/*      */     private Class<? extends Enum> enumType;
/*      */     private Field dataField;
/*      */     private Field sizeField;
/*      */     private final int bitTag;
/*      */ 
/*      */     public FieldType(String externalName, String internalName, int wireTag, ProtocolType.FieldBaseType declareType, ProtocolType.Presence presence)
/*      */     {
/*  301 */       this(externalName, internalName, wireTag, -2147483648, declareType, presence, null);
/*      */     }
/*      */ 
/*      */     public FieldType(String externalName, String internalName, int wireTag, ProtocolType.FieldBaseType declareType, ProtocolType.Presence presence, Class<? extends ProtocolMessage> subclass)
/*      */     {
/*  309 */       this(externalName, internalName, wireTag, -2147483648, declareType, presence, subclass);
/*      */     }
/*      */ 
/*      */     public FieldType(String externalName, String internalName, int wireTag, ProtocolType.Presence presence, Class<? extends Enum> enumType)
/*      */     {
/*  317 */       this(externalName, internalName, wireTag, -2147483648, ProtocolType.FieldBaseType.INT32, presence, null);
/*      */ 
/*  319 */       this.enumType = enumType;
/*      */     }
/*      */ 
/*      */     public FieldType(String externalName, String internalName, int wireTag, int bitTag, ProtocolType.FieldBaseType declareType, ProtocolType.Presence presence)
/*      */     {
/*  325 */       this(externalName, internalName, wireTag, bitTag, declareType, presence, null);
/*      */     }
/*      */ 
/*      */     public FieldType(String externalName, String internalName, int wireTag, int bitTag, ProtocolType.FieldBaseType declareType, ProtocolType.Presence presence, Class<? extends ProtocolMessage> subclass)
/*      */     {
/*  333 */       this.internalName = internalName;
/*  334 */       this.printName = externalName;
/*  335 */       this.tag = wireTag;
/*  336 */       this.baseType = declareType;
/*  337 */       this.presence = presence;
/*  338 */       this.subclass = subclass;
/*  339 */       this.bitTag = bitTag;
/*      */     }
/*      */ 
/*      */     public FieldType(String externalName, String internalName, int wireTag, int bitTab, ProtocolType.Presence presence, Class<? extends Enum> enumType)
/*      */     {
/*  346 */       this(externalName, internalName, wireTag, bitTab, ProtocolType.FieldBaseType.INT32, presence, null);
/*      */ 
/*  348 */       this.enumType = enumType;
/*      */     }
/*      */ 
/*      */     protected Class<?> getParentClass()
/*      */     {
/*  357 */       return this.dataField.getDeclaringClass();
/*      */     }
/*      */ 
/*      */     public String getCName()
/*      */     {
/*  362 */       return this.internalName;
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/*  367 */       return this.printName;
/*      */     }
/*      */ 
/*      */     public int getTag()
/*      */     {
/*  372 */       return this.tag;
/*      */     }
/*      */ 
/*      */     public int getWireTag()
/*      */     {
/*  377 */       return (this.tag << 3) + this.baseType.getWireType().getValue();
/*      */     }
/*      */ 
/*      */     public ProtocolType.FieldBaseType getBaseType()
/*      */     {
/*  382 */       return this.baseType;
/*      */     }
/*      */ 
/*      */     public ProtocolType.Presence getPresence()
/*      */     {
/*  387 */       return this.presence;
/*      */     }
/*      */ 
/*      */     public Class<? extends ProtocolMessage> getSubclass()
/*      */     {
/*  392 */       return this.subclass;
/*      */     }
/*      */ 
/*      */     public Class<? extends Enum> getEnumType()
/*      */     {
/*  397 */       return this.enumType;
/*      */     }
/*      */ 
/*      */     public int size(ProtocolMessage object)
/*      */     {
/*      */       try {
/*  403 */         switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$Presence[this.presence.ordinal()]) {
/*      */         case 1:
/*      */         case 2:
/*  406 */           if (this.bitTag == -2147483648)
/*      */           {
/*  408 */             return this.sizeField.getBoolean(object) ? 1 : 0;
/*      */           }
/*      */ 
/*  411 */           int value = this.sizeField.getInt(object);
/*  412 */           return (value & 1 << this.bitTag) != 0 ? 1 : 0;
/*      */         case 3:
/*  415 */           if (this.sizeField != null)
/*      */           {
/*  417 */             return this.sizeField.getInt(object);
/*      */           }
/*      */ 
/*  420 */           List value = (List)this.dataField.get(object);
/*  421 */           return value != null ? value.size() : 0;
/*      */         }
/*      */ 
/*  424 */         throw new AssertionError("Should not reach here");
/*      */       } catch (IllegalAccessException e) {
/*      */       }
/*  427 */       throw new AssertionError("Should not reach here");
/*      */     }
/*      */ 
/*      */     public void visit(ProtocolMessage message, ProtocolType.Visitor visitor)
/*      */     {
/*  439 */       int size = size(message);
/*  440 */       if (!visitor.shouldVisitField(this, size)) {
/*  441 */         return;
/*      */       }
/*      */ 
/*  444 */       for (int index = 0; index < size; index++) {
/*  445 */         Object value = this.presence == ProtocolType.Presence.REPEATED ? getNthValue(message, index) : getSingleValue(message);
/*      */ 
/*  449 */         switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[this.baseType.ordinal()]) {
/*      */         case 4:
/*  451 */           visitor.visitBoolean(this, index, ((Boolean)value).booleanValue());
/*  452 */           break;
/*      */         case 3:
/*      */         case 5:
/*  456 */           visitor.visitInteger(this, index, ((Integer)value).intValue());
/*  457 */           break;
/*      */         case 1:
/*      */         case 2:
/*      */         case 7:
/*  462 */           visitor.visitLong(this, index, ((Long)value).longValue());
/*  463 */           break;
/*      */         case 11:
/*  466 */           visitor.visitString(this, index, Protocol.toStringUtf8((byte[])(byte[])value));
/*      */ 
/*  468 */           break;
/*      */         case 6:
/*  471 */           visitor.visitFloat(this, index, ((Float)value).floatValue());
/*  472 */           break;
/*      */         case 8:
/*  475 */           visitor.visitDouble(this, index, ((Double)value).doubleValue());
/*  476 */           break;
/*      */         case 9:
/*  479 */           visitor.visitGroup(this, index, (ProtocolMessage)value);
/*  480 */           break;
/*      */         case 10:
/*  483 */           visitor.visitForeign(this, index, (ProtocolMessage)value);
/*  484 */           break;
/*      */         default:
/*  487 */           throw new AssertionError("Cannot reach here");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void visit(ProtocolMessage message, MessageVisitor visitor)
/*      */     {
/*  500 */       int size = size(message);
/*  501 */       if (!visitor.shouldVisitField(this, size)) {
/*  502 */         return;
/*      */       }
/*      */ 
/*  505 */       for (int index = 0; index < size; index++) {
/*  506 */         Object value = this.presence == ProtocolType.Presence.REPEATED ? getNthValue(message, index) : getSingleValue(message);
/*      */ 
/*  510 */         switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[this.baseType.ordinal()]) {
/*      */         case 4:
/*  512 */           visitor.visitBoolean(this, index, ((Boolean)value).booleanValue());
/*  513 */           break;
/*      */         case 3:
/*      */         case 5:
/*  517 */           visitor.visitInteger(this, index, ((Integer)value).intValue());
/*  518 */           break;
/*      */         case 1:
/*      */         case 2:
/*      */         case 7:
/*  523 */           visitor.visitLong(this, index, ((Long)value).longValue());
/*  524 */           break;
/*      */         case 11:
/*  527 */           if ((value instanceof String))
/*  528 */             visitor.visitString(this, index, (String)value);
/*      */           else {
/*  530 */             visitor.visitByteArray(this, index, (byte[])(byte[])value);
/*      */           }
/*  532 */           break;
/*      */         case 6:
/*  535 */           visitor.visitFloat(this, index, ((Float)value).floatValue());
/*  536 */           break;
/*      */         case 8:
/*  539 */           visitor.visitDouble(this, index, ((Double)value).doubleValue());
/*  540 */           break;
/*      */         case 9:
/*  543 */           visitor.visitGroup(this, index, (ProtocolMessage)value);
/*  544 */           break;
/*      */         case 10:
/*  547 */           visitor.visitForeign(this, index, (ProtocolMessage)value);
/*  548 */           break;
/*      */         default:
/*  551 */           throw new AssertionError("Cannot reach here");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public Object getSingleValue(ProtocolMessage message)
/*      */     {
/*      */       try {
/*  559 */         return this.dataField.get(message); } catch (IllegalAccessException e) {
/*      */       }
/*  561 */       throw new AssertionError("ProtocolMessage must have field");
/*      */     }
/*      */ 
/*      */     public Object getNthValue(ProtocolMessage message, int index)
/*      */     {
/*      */       try
/*      */       {
/*  571 */         Object value = this.dataField.get(message);
/*  572 */         if (this.baseType.isCompound())
/*      */         {
/*  574 */           return ((List)value).get(index);
/*      */         }
/*      */ 
/*  577 */         return Array.get(value, index);
/*      */       } catch (IllegalAccessException e) {
/*      */       }
/*  580 */       throw new AssertionError("ProtocolMessage must have field");
/*      */     }
/*      */ 
/*      */     private void checkRepeatedType(Object elem)
/*      */     {
/*  585 */       Preconditions.checkNotNull(elem);
/*  586 */       switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[this.baseType.ordinal()]) {
/*      */       case 3:
/*      */       case 5:
/*  589 */         int[] testIntArray = new int[1];
/*  590 */         Array.set(testIntArray, 0, elem);
/*  591 */         break;
/*      */       case 1:
/*      */       case 2:
/*      */       case 7:
/*  595 */         long[] testLongArray = new long[1];
/*  596 */         Array.set(testLongArray, 0, elem);
/*  597 */         break;
/*      */       case 4:
/*  599 */         boolean[] testBoolArray = new boolean[1];
/*  600 */         Array.set(testBoolArray, 0, elem);
/*  601 */         break;
/*      */       case 6:
/*  603 */         float[] testFloatArray = new float[1];
/*  604 */         Array.set(testFloatArray, 0, elem);
/*  605 */         break;
/*      */       case 8:
/*  607 */         double[] testDoubleArray = new double[1];
/*  608 */         Array.set(testDoubleArray, 0, elem);
/*  609 */         break;
/*      */       case 11:
/*  611 */         byte[][] testStringArray = new byte[1][];
/*  612 */         Array.set(testStringArray, 0, elem);
/*  613 */         break;
/*      */       case 9:
/*      */       case 10:
/*  616 */         if (elem.getClass().equals(getSubclass())) break;
/*  617 */         throw new IllegalArgumentException(getSubclass().getSimpleName() + " expected, " + elem.getClass().getSimpleName() + " found");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void setNthValue(ProtocolMessage message, int index, Object elem)
/*      */     {
/*  635 */       if (this.presence != ProtocolType.Presence.REPEATED) {
/*  636 */         throw new IllegalStateException("Can only add to repeated fields.");
/*      */       }
/*  638 */       checkRepeatedType(elem);
/*      */       try {
/*  640 */         Object value = this.dataField.get(message);
/*  641 */         if (this.baseType.isCompound())
/*      */         {
/*  643 */           if (value == null) {
/*  644 */             throw new ArrayIndexOutOfBoundsException(index);
/*      */           }
/*  646 */           ((List)value).set(index, elem);
/*      */         } else {
/*  648 */           if (index >= this.sizeField.getInt(message)) {
/*  649 */             throw new ArrayIndexOutOfBoundsException(index);
/*      */           }
/*  651 */           Array.set(value, index, elem);
/*      */         }
/*      */       } catch (IllegalAccessException e) {
/*  654 */         throw new AssertionError("ProtocolMessage must have field");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void clear(ProtocolMessage message)
/*      */     {
/*  660 */       if (this.presence != ProtocolType.Presence.REPEATED)
/*  661 */         throw new IllegalStateException("Can only clear repeated fields.");
/*      */       try
/*      */       {
/*  664 */         if (this.sizeField != null)
/*      */         {
/*  666 */           switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[this.baseType.ordinal()]) {
/*      */           case 3:
/*      */           case 5:
/*  669 */             this.dataField.set(message, new int[0]);
/*  670 */             break;
/*      */           case 1:
/*      */           case 2:
/*      */           case 7:
/*  674 */             this.dataField.set(message, new long[0]);
/*  675 */             break;
/*      */           case 4:
/*  677 */             this.dataField.set(message, new boolean[0]);
/*  678 */             break;
/*      */           case 6:
/*  680 */             this.dataField.set(message, new float[0]);
/*  681 */             break;
/*      */           case 8:
/*  683 */             this.dataField.set(message, new double[0]);
/*  684 */             break;
/*      */           default:
/*  686 */             this.dataField.set(message, new ProtocolMessage[0]);
/*      */           }
/*      */ 
/*  689 */           this.sizeField.setInt(message, 0);
/*      */         }
/*      */         else {
/*  692 */           List value = (List)this.dataField.get(message);
/*  693 */           value.clear();
/*      */         }
/*      */       } catch (IllegalAccessException e) {
/*  696 */         throw new AssertionError("ProtocolMessage must have field");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void setSingleValue(ProtocolMessage message, Object value)
/*      */     {
/*  702 */       if (this.presence == ProtocolType.Presence.REPEATED)
/*  703 */         throw new IllegalStateException("Field is repeated, not single value.");
/*      */       try
/*      */       {
/*  706 */         this.dataField.set(message, value);
/*  707 */         if (this.bitTag == -2147483648)
/*      */         {
/*  709 */           this.sizeField.setBoolean(message, true);
/*      */         }
/*      */         else
/*  712 */           this.sizeField.setInt(message, this.sizeField.getInt(message) | 1 << this.bitTag);
/*      */       }
/*      */       catch (IllegalAccessException e) {
/*  715 */         throw new AssertionError("ProtocolMessage must have field");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addValue(ProtocolMessage message, Object elem)
/*      */     {
/*  721 */       if (this.presence != ProtocolType.Presence.REPEATED)
/*  722 */         throw new IllegalStateException("Can only add to repeated fields.");
/*      */       try
/*      */       {
/*  725 */         Object value = this.dataField.get(message);
/*  726 */         if (this.baseType.isCompound())
/*      */         {
/*  728 */           if (value == null) {
/*  729 */             value = new ArrayList(4);
/*  730 */             this.dataField.set(message, value);
/*      */           }
/*  732 */           ((List)value).add(elem);
/*      */         }
/*      */         else {
/*  735 */           int size = this.sizeField.getInt(message);
/*  736 */           int len = Array.getLength(value);
/*  737 */           if (size == len) {
/*  738 */             switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[this.baseType.ordinal()]) {
/*      */             case 3:
/*      */             case 5:
/*  741 */               value = ProtocolSupport.growArray((int[])(int[])value);
/*  742 */               break;
/*      */             case 1:
/*      */             case 2:
/*      */             case 7:
/*  746 */               value = ProtocolSupport.growArray((long[])(long[])value);
/*  747 */               break;
/*      */             case 4:
/*  749 */               value = ProtocolSupport.growArray((boolean[])(boolean[])value);
/*  750 */               break;
/*      */             case 6:
/*  752 */               value = ProtocolSupport.growArray((float[])(float[])value);
/*  753 */               break;
/*      */             case 8:
/*  755 */               value = ProtocolSupport.growArray((double[])(double[])value);
/*      */             }
/*      */ 
/*  758 */             this.dataField.set(message, value);
/*      */           }
/*  760 */           Array.set(value, size, elem);
/*  761 */           this.sizeField.setInt(message, size + 1);
/*      */         }
/*      */       } catch (IllegalAccessException e) {
/*  764 */         throw new AssertionError("ProtocolMessage must have field");
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean groupsGenerateOwnEndTag()
/*      */     {
/*  774 */       return this.bitTag != -2147483648;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  779 */       StringBuilder sb = new StringBuilder("<FieldType: ");
/*  780 */       sb.append(this.presence).append(' ');
/*  781 */       if (this.baseType == ProtocolType.FieldBaseType.FOREIGN)
/*  782 */         sb.append(this.subclass.getSimpleName());
/*      */       else {
/*  784 */         sb.append(this.baseType);
/*      */       }
/*  786 */       sb.append(' ').append(this.printName).append(" = ").append(this.tag).append(">");
/*      */ 
/*  788 */       return sb.toString();
/*      */     }
/*      */ 
/*      */     public byte[] getRawByteArray(ProtocolMessage protocolMessage, int index)
/*      */     {
/*  793 */       if (this.baseType != ProtocolType.FieldBaseType.STRING) {
/*  794 */         throw new IllegalArgumentException("Must be String");
/*      */       }
/*  796 */       if (getPresence() == ProtocolType.Presence.REPEATED) {
/*  797 */         return (byte[])(byte[])getNthValue(protocolMessage, index);
/*      */       }
/*  799 */       return (byte[])(byte[])getSingleValue(protocolMessage);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum WireType
/*      */   {
/*  237 */     NUMERIC(0), 
/*      */ 
/*  239 */     DOUBLE(1), 
/*      */ 
/*  241 */     STRING(2), 
/*      */ 
/*  243 */     STARTGROUP(3), 
/*      */ 
/*  245 */     ENDGROUP(4), 
/*      */ 
/*  247 */     FLOAT(5), 
/*      */ 
/*  249 */     ERROR(6);
/*      */ 
/*      */     private final byte value;
/*      */ 
/*      */     private WireType(int i) {
/*  255 */       this.value = (byte)i;
/*      */     }
/*      */     public byte getValue() {
/*  258 */       return this.value;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum Presence
/*      */   {
/*  228 */     OPTIONAL, REQUIRED, REPEATED;
/*      */   }
/*      */ 
/*      */   public static enum FieldBaseType
/*      */   {
/*  155 */     INT32, 
/*      */ 
/*  157 */     FIXED32, 
/*      */ 
/*  159 */     INT64, 
/*      */ 
/*  161 */     UINT64, 
/*      */ 
/*  163 */     FIXED64, 
/*      */ 
/*  165 */     BOOL, 
/*      */ 
/*  167 */     FLOAT, 
/*      */ 
/*  169 */     DOUBLE, 
/*      */ 
/*  171 */     STRING, 
/*      */ 
/*  173 */     GROUP, 
/*      */ 
/*  175 */     FOREIGN;
/*      */ 
/*      */     boolean isCompound()
/*      */     {
/*  179 */       return (this == STRING) || (this == GROUP) || (this == FOREIGN);
/*      */     }
/*      */ 
/*      */     boolean isScalar()
/*      */     {
/*  184 */       return !isCompound();
/*      */     }
/*      */ 
/*      */     public boolean isFixed()
/*      */     {
/*  189 */       return (this == FIXED32) || (this == FIXED64) || (this == BOOL);
/*      */     }
/*      */ 
/*      */     public ProtocolType.WireType getWireType()
/*      */     {
/*  194 */       switch (ProtocolType.1.$SwitchMap$com$google$io$protocol$ProtocolType$FieldBaseType[ordinal()]) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*  199 */         return ProtocolType.WireType.NUMERIC;
/*      */       case 5:
/*      */       case 6:
/*  203 */         return ProtocolType.WireType.FLOAT;
/*      */       case 7:
/*      */       case 8:
/*  207 */         return ProtocolType.WireType.DOUBLE;
/*      */       case 9:
/*  210 */         return ProtocolType.WireType.STARTGROUP;
/*      */       case 10:
/*  213 */         return ProtocolType.WireType.STRING;
/*      */       case 11:
/*  216 */         return ProtocolType.WireType.STRING;
/*      */       }
/*      */ 
/*  219 */       return ProtocolType.WireType.ERROR;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract interface Visitor
/*      */   {
/*      */     public abstract boolean shouldVisitField(ProtocolType.FieldType paramFieldType, int paramInt);
/*      */ 
/*      */     public abstract void visitBoolean(ProtocolType.FieldType paramFieldType, int paramInt, boolean paramBoolean);
/*      */ 
/*      */     public abstract void visitInteger(ProtocolType.FieldType paramFieldType, int paramInt1, int paramInt2);
/*      */ 
/*      */     public abstract void visitLong(ProtocolType.FieldType paramFieldType, int paramInt, long paramLong);
/*      */ 
/*      */     public abstract void visitString(ProtocolType.FieldType paramFieldType, int paramInt, String paramString);
/*      */ 
/*      */     public abstract void visitFloat(ProtocolType.FieldType paramFieldType, int paramInt, float paramFloat);
/*      */ 
/*      */     public abstract void visitDouble(ProtocolType.FieldType paramFieldType, int paramInt, double paramDouble);
/*      */ 
/*      */     public abstract void visitGroup(ProtocolType.FieldType paramFieldType, int paramInt, ProtocolMessage paramProtocolMessage);
/*      */ 
/*      */     public abstract void visitForeign(ProtocolType.FieldType paramFieldType, int paramInt, ProtocolMessage paramProtocolMessage);
/*      */ 
/*      */     public abstract void visitRawMessage(ByteBuffer paramByteBuffer);
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolType
 * JD-Core Version:    0.6.0
 */