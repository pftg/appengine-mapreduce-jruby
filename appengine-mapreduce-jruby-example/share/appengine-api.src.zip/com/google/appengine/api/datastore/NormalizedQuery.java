/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import com.google.apphosting.api.DatastorePb.Query;
/*    */ import com.google.apphosting.api.DatastorePb.Query.Filter;
/*    */ import com.google.apphosting.api.DatastorePb.Query.Filter.Operator;
/*    */ import com.google.apphosting.api.DatastorePb.Query.Order;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Property;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ class NormalizedQuery
/*    */ {
/* 15 */   static final Set<DatastorePb.Query.Filter.Operator> INEQUALITY_OPERATORS = makeImmutableSet(new DatastorePb.Query.Filter.Operator[] { DatastorePb.Query.Filter.Operator.GREATER_THAN, DatastorePb.Query.Filter.Operator.GREATER_THAN_OR_EQUAL, DatastorePb.Query.Filter.Operator.LESS_THAN, DatastorePb.Query.Filter.Operator.LESS_THAN_OR_EQUAL });
/*    */   protected final DatastorePb.Query query;
/*    */ 
/*    */   public NormalizedQuery(DatastorePb.Query query)
/*    */   {
/* 24 */     this.query = ((DatastorePb.Query)query.clone());
/* 25 */     normalizeQuery();
/*    */   }
/*    */ 
/*    */   public DatastorePb.Query getQuery() {
/* 29 */     return this.query;
/*    */   }
/*    */ 
/*    */   private void normalizeQuery()
/*    */   {
/* 37 */     Set equalityProperties = new HashSet();
/* 38 */     Set inequalityProperties = new HashSet();
/* 39 */     for (DatastorePb.Query.Filter f : this.query.filters())
/*    */     {
/* 41 */       if ((f.propertySize() == 1) && (f.getOpEnum() == DatastorePb.Query.Filter.Operator.IN)) {
/* 42 */         f.setOp(DatastorePb.Query.Filter.Operator.EQUAL);
/*    */       }
/* 44 */       if (f.propertySize() >= 1) {
/* 45 */         if (f.getOpEnum() == DatastorePb.Query.Filter.Operator.EQUAL)
/* 46 */           equalityProperties.add(f.getProperty(0).getName());
/* 47 */         else if (INEQUALITY_OPERATORS.contains(f.getOpEnum())) {
/* 48 */           inequalityProperties.add(f.getProperty(0).getName());
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 53 */     equalityProperties.removeAll(inequalityProperties);
/*    */ 
/* 56 */     for (Iterator i = this.query.orderIterator(); i.hasNext(); ) {
/* 57 */       if (!equalityProperties.add(((DatastorePb.Query.Order)i.next()).getProperty())) {
/* 58 */         i.remove();
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 65 */     for (DatastorePb.Query.Filter f : this.query.filters()) {
/* 66 */       if ((f.getOpEnum() == DatastorePb.Query.Filter.Operator.EQUAL) && (f.propertySize() >= 1) && (f.getProperty(0).getName().equals("__key__")))
/*    */       {
/* 68 */         this.query.clearOrder();
/* 69 */         break;
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 75 */     boolean foundKeyOrder = false;
/* 76 */     for (Iterator i = this.query.orderIterator(); i.hasNext(); ) {
/* 77 */       String property = ((DatastorePb.Query.Order)i.next()).getProperty();
/* 78 */       if (foundKeyOrder)
/* 79 */         i.remove();
/* 80 */       else if (property.equals("__key__"))
/* 81 */         foundKeyOrder = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   static <T> Set<T> makeImmutableSet(T[] of)
/*    */   {
/* 87 */     return Collections.unmodifiableSet(new HashSet(Arrays.asList(of)));
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.NormalizedQuery
 * JD-Core Version:    0.6.0
 */