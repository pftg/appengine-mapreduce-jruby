/*      */ package com.google.appengine.repackaged.com.google.common.base;
/*      */ 
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.VisibleForTesting;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GoogleInternal
/*      */ public final class StringUtil
/*      */ {
/*      */ 
/*      */   @Deprecated
/*      */   public static final String WHITE_SPACES = " \r\n\t　   ";
/*      */   public static final String LINE_BREAKS = "\r\n";
/*  417 */   private static final Splitter NEWLINE_SPLITTER = Splitter.on('\n').omitEmptyStrings();
/*      */ 
/*  471 */   private static final Splitter TO_WORDS = Splitter.on(CharMatcher.BREAKING_WHITESPACE).omitEmptyStrings();
/*      */ 
/*  742 */   private static final CharMatcher FANCY_SINGLE_QUOTE = CharMatcher.anyOf("‘’");
/*      */ 
/*  744 */   private static final CharMatcher FANCY_DOUBLE_QUOTE = CharMatcher.anyOf("“”");
/*      */ 
/* 1018 */   static final Map<String, Character> ESCAPE_STRINGS = new HashMap(252);
/*      */   static final Set<Character> HEX_LETTERS;
/*      */   private static final CharEscaper LT_GT_ESCAPE;
/*      */   private static final Pattern htmlTagPattern;
/*      */   private static final CharMatcher CONTROL_MATCHER;
/*      */   private static final CharEscaper JAVA_ESCAPE;
/*      */   private static final CharEscaper REGEX_ESCAPE;
/*      */   private static final Pattern characterReferencePattern;
/*      */   private static final Set<Character.UnicodeBlock> CJK_BLOCKS;
/*      */   private static final char[] HEX_CHARS;
/*      */   private static final char[] OCTAL_CHARS;
/*      */   private static final Pattern dbSpecPattern;
/*      */   private static final Set<Integer> JS_ESCAPE_CHARS;
/*      */   private static final Set<Integer> JSON_ESCAPE_CHARS;
/*      */ 
/*      */   public static boolean isEmpty(@Nullable String string)
/*      */   {
/*   60 */     return Strings.isNullOrEmpty(string);
/*      */   }
/*      */ 
/*      */   public static boolean isEmptyOrWhitespace(@Nullable String string)
/*      */   {
/*   76 */     return (string == null) || (CharMatcher.WHITESPACE.matchesAllOf(string));
/*      */   }
/*      */ 
/*      */   public static String makeSafe(@Nullable String string)
/*      */   {
/*   84 */     return Strings.nullToEmpty(string);
/*      */   }
/*      */ 
/*      */   @Nullable
/*      */   public static String toNullIfEmpty(@Nullable String string)
/*      */   {
/*   92 */     return Strings.emptyToNull(string);
/*      */   }
/*      */ 
/*      */   @Nullable
/*      */   public static String toNullIfEmptyOrWhitespace(@Nullable String string)
/*      */   {
/*  106 */     return isEmptyOrWhitespace(string) ? null : string;
/*      */   }
/*      */ 
/*      */   public static String repeat(String string, int count)
/*      */   {
/*  114 */     return Strings.repeat(string, count);
/*      */   }
/*      */ 
/*      */   public static int indexOfChars(CharSequence string, CharSequence chars, int fromIndex)
/*      */   {
/*  138 */     if (fromIndex >= string.length()) {
/*  139 */       return -1;
/*      */     }
/*      */ 
/*  147 */     Set charSet = Collections.emptySet();
/*  148 */     boolean[] charArray = new boolean[''];
/*  149 */     for (int i = 0; i < chars.length(); i++) {
/*  150 */       char c = chars.charAt(i);
/*  151 */       if (c < '') {
/*  152 */         charArray[c] = true;
/*      */       } else {
/*  154 */         if (charSet.isEmpty()) {
/*  155 */           charSet = new HashSet();
/*      */         }
/*  157 */         charSet.add(Character.valueOf(c));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  162 */     for (int i = Math.max(fromIndex, 0); i < string.length(); i++) {
/*  163 */       char c = string.charAt(i);
/*  164 */       if (c < '') {
/*  165 */         if (charArray[c] != 0)
/*  166 */           return i;
/*      */       }
/*  168 */       else if (charSet.contains(Character.valueOf(c))) {
/*  169 */         return i;
/*      */       }
/*      */     }
/*  172 */     return -1;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String[] split(String str, String delims)
/*      */   {
/*  196 */     return split(str, delims, false);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String[] split(String str, String delims, boolean trimTokens)
/*      */   {
/*  234 */     StringTokenizer tokenizer = new StringTokenizer(str, delims);
/*  235 */     int n = tokenizer.countTokens();
/*  236 */     String[] list = new String[n];
/*  237 */     for (int i = 0; i < n; i++) {
/*  238 */       if (trimTokens)
/*  239 */         list[i] = tokenizer.nextToken().trim();
/*      */       else {
/*  241 */         list[i] = tokenizer.nextToken();
/*      */       }
/*      */     }
/*  244 */     return list;
/*      */   }
/*      */ 
/*      */   public static String trimStart(String s)
/*      */   {
/*  255 */     return trimStart(s, null);
/*      */   }
/*      */ 
/*      */   public static String trimStart(String s, @Nullable String extraChars)
/*      */   {
/*  271 */     int trimCount = 0;
/*  272 */     while (trimCount < s.length()) {
/*  273 */       char ch = s.charAt(trimCount);
/*  274 */       if ((!Character.isWhitespace(ch)) && ((extraChars == null) || (extraChars.indexOf(ch) < 0)))
/*      */         break;
/*  276 */       trimCount++;
/*      */     }
/*      */ 
/*  282 */     if (trimCount == 0) {
/*  283 */       return s;
/*      */     }
/*  285 */     return s.substring(trimCount);
/*      */   }
/*      */ 
/*      */   public static String trimEnd(String s)
/*      */   {
/*  296 */     return trimEnd(s, null);
/*      */   }
/*      */ 
/*      */   public static String trimEnd(String s, @Nullable String extraChars)
/*      */   {
/*  312 */     int trimCount = 0;
/*  313 */     while (trimCount < s.length()) {
/*  314 */       char ch = s.charAt(s.length() - trimCount - 1);
/*  315 */       if ((!Character.isWhitespace(ch)) && ((extraChars == null) || (extraChars.indexOf(ch) < 0)))
/*      */         break;
/*  317 */       trimCount++;
/*      */     }
/*      */ 
/*  323 */     if (trimCount == 0) {
/*  324 */       return s;
/*      */     }
/*  326 */     return s.substring(0, s.length() - trimCount);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String[] splitAndTrim(String str, String delims)
/*      */   {
/*  340 */     return split(str, delims, true);
/*      */   }
/*      */ 
/*      */   public static int[] splitInts(String str) throws IllegalArgumentException
/*      */   {
/*  345 */     StringTokenizer tokenizer = new StringTokenizer(str, ",");
/*  346 */     int n = tokenizer.countTokens();
/*  347 */     int[] list = new int[n];
/*  348 */     for (int i = 0; i < n; i++) {
/*  349 */       String token = tokenizer.nextToken();
/*  350 */       list[i] = Integer.parseInt(token);
/*      */     }
/*  352 */     return list;
/*      */   }
/*      */ 
/*      */   public static long[] splitLongs(String str) throws IllegalArgumentException
/*      */   {
/*  357 */     StringTokenizer tokenizer = new StringTokenizer(str, ",");
/*  358 */     int n = tokenizer.countTokens();
/*  359 */     long[] list = new long[n];
/*  360 */     for (int i = 0; i < n; i++) {
/*  361 */       String token = tokenizer.nextToken();
/*  362 */       list[i] = Long.parseLong(token);
/*      */     }
/*  364 */     return list;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String join(Object[] tokens, String delimiter)
/*      */   {
/*  380 */     if (tokens == null) {
/*  381 */       return "";
/*      */     }
/*  383 */     return Joiner.on(delimiter).useForNull("").join(tokens);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String join(Collection<?> tokens, String delimiter)
/*      */   {
/*  395 */     return Joiner.on(delimiter).useForNull("").join(tokens);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String replace(String str, CharSequence what, CharSequence with)
/*      */   {
/*  413 */     Preconditions.checkArgument(what.length() > 0);
/*  414 */     return str.replace(what, with);
/*      */   }
/*      */ 
/*      */   public static String fixedWidth(String str, int width)
/*      */   {
/*  433 */     List lines = new ArrayList();
/*      */ 
/*  435 */     for (String line : NEWLINE_SPLITTER.split(str)) {
/*  436 */       lines.add(line);
/*      */     }
/*      */ 
/*  439 */     String[] lineArray = (String[])lines.toArray(new String[0]);
/*  440 */     return fixedWidth(lineArray, width);
/*      */   }
/*      */ 
/*      */   public static String fixedWidth(String[] lines, int width)
/*      */   {
/*  462 */     List formattedLines = new ArrayList();
/*      */ 
/*  464 */     for (String line : lines) {
/*  465 */       formattedLines.add(formatLineToFixedWidth(line, width));
/*      */     }
/*      */ 
/*  468 */     return Joiner.on('\n').join(formattedLines);
/*      */   }
/*      */ 
/*      */   private static String formatLineToFixedWidth(String line, int width)
/*      */   {
/*  478 */     if (line.length() <= width) {
/*  479 */       return line;
/*      */     }
/*      */ 
/*  482 */     StringBuilder builder = new StringBuilder();
/*  483 */     int col = 0;
/*      */ 
/*  485 */     for (String word : TO_WORDS.split(line)) {
/*  486 */       if (col == 0) {
/*  487 */         col = word.length();
/*      */       } else {
/*  489 */         int newCol = col + word.length() + 1;
/*      */ 
/*  491 */         if (newCol <= width) {
/*  492 */           builder.append(' ');
/*  493 */           col = newCol;
/*      */         } else {
/*  495 */           builder.append('\n');
/*  496 */           col = word.length();
/*      */         }
/*      */       }
/*      */ 
/*  500 */       builder.append(word);
/*      */     }
/*      */ 
/*  503 */     return builder.toString();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static List<String> fixedSplit(String original, int lineLen)
/*      */   {
/*  521 */     List output = new ArrayList();
/*  522 */     for (String elem : Splitter.fixedLength(lineLen).split(original)) {
/*  523 */       output.add(elem);
/*      */     }
/*  525 */     return output;
/*      */   }
/*      */ 
/*      */   public static String indent(String iString, int iIndentDepth)
/*      */   {
/*  535 */     StringBuilder spacer = new StringBuilder();
/*  536 */     spacer.append("\n");
/*  537 */     for (int i = 0; i < iIndentDepth; i++) {
/*  538 */       spacer.append("  ");
/*      */     }
/*  540 */     return iString.replace("\n", spacer.toString());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String megastrip(String str, boolean left, boolean right, String what)
/*      */   {
/*  565 */     if (str == null) {
/*  566 */       return null;
/*      */     }
/*      */ 
/*  569 */     CharMatcher matcher = CharMatcher.anyOf(what);
/*  570 */     if (left) {
/*  571 */       if (right) {
/*  572 */         return matcher.trimFrom(str);
/*      */       }
/*  574 */       return matcher.trimLeadingFrom(str);
/*      */     }
/*  576 */     if (right) {
/*  577 */       return matcher.trimTrailingFrom(str);
/*      */     }
/*  579 */     return str;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String strip(String str)
/*      */   {
/*  593 */     return str == null ? null : CharMatcher.LEGACY_WHITESPACE.trimFrom(str);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String stripAndCollapse(String str)
/*      */   {
/*  608 */     return str == null ? null : CharMatcher.LEGACY_WHITESPACE.trimAndCollapseFrom(str, ' ');
/*      */   }
/*      */ 
/*      */   @Nullable
/*      */   public static String stripPrefix(String str, String prefix)
/*      */   {
/*  623 */     return str.startsWith(prefix) ? str.substring(prefix.length()) : null;
/*      */   }
/*      */ 
/*      */   @Nullable
/*      */   public static String stripPrefixIgnoreCase(String str, String prefix)
/*      */   {
/*  639 */     return startsWithIgnoreCase(str, prefix) ? str.substring(prefix.length()) : null;
/*      */   }
/*      */ 
/*      */   @Nullable
/*      */   public static String stripSuffix(String str, String suffix)
/*      */   {
/*  655 */     return str.endsWith(suffix) ? str.substring(0, str.length() - suffix.length()) : null;
/*      */   }
/*      */ 
/*      */   @Nullable
/*      */   public static String stripSuffixIgnoreCase(String str, String suffix)
/*      */   {
/*  672 */     return endsWithIgnoreCase(str, suffix) ? str.substring(0, str.length() - suffix.length()) : null;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String stripNonDigits(String str)
/*      */   {
/*  690 */     return CharMatcher.JAVA_DIGIT.retainFrom(str);
/*      */   }
/*      */ 
/*      */   public static int lastIndexNotOf(String str, String chars, int fromIndex)
/*      */   {
/*  705 */     fromIndex = Math.min(fromIndex, str.length() - 1);
/*      */ 
/*  707 */     for (int pos = fromIndex; pos >= 0; pos--) {
/*  708 */       if (chars.indexOf(str.charAt(pos)) < 0) {
/*  709 */         return pos;
/*      */       }
/*      */     }
/*      */ 
/*  713 */     return -1;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String replaceChars(String str, CharSequence oldchars, char newchar)
/*      */   {
/*  726 */     return CharMatcher.anyOf(oldchars).replaceFrom(str, newchar);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String removeChars(String str, CharSequence oldchars)
/*      */   {
/*  738 */     return CharMatcher.anyOf(oldchars).removeFrom(str);
/*      */   }
/*      */ 
/*      */   public static String replaceSmartQuotes(String str)
/*      */   {
/*  752 */     String tmp = FANCY_SINGLE_QUOTE.replaceFrom(str, '\'');
/*  753 */     return FANCY_DOUBLE_QUOTE.replaceFrom(tmp, '"');
/*      */   }
/*      */ 
/*      */   public static byte[] hexToBytes(CharSequence str)
/*      */   {
/*  778 */     byte[] bytes = new byte[(str.length() + 1) / 2];
/*  779 */     if (str.length() == 0) {
/*  780 */       return bytes;
/*      */     }
/*  782 */     bytes[0] = 0;
/*  783 */     int nibbleIdx = str.length() % 2;
/*  784 */     for (int i = 0; i < str.length(); i++) {
/*  785 */       char c = str.charAt(i);
/*  786 */       if (!isHex(c)) {
/*  787 */         throw new IllegalArgumentException("string contains non-hex chars");
/*      */       }
/*  789 */       if (nibbleIdx % 2 == 0) {
/*  790 */         bytes[(nibbleIdx >> 1)] = (byte)(hexValue(c) << 4);
/*      */       }
/*      */       else
/*      */       {
/*      */         int tmp103_102 = (nibbleIdx >> 1);
/*      */         byte[] tmp103_99 = bytes; tmp103_99[tmp103_102] = (byte)(tmp103_99[tmp103_102] + (byte)hexValue(c));
/*      */       }
/*  794 */       nibbleIdx++;
/*      */     }
/*  796 */     return bytes;
/*      */   }
/*      */ 
/*      */   public static String convertEOLToLF(String input)
/*      */   {
/*  803 */     StringBuilder res = new StringBuilder(input.length());
/*  804 */     char[] s = input.toCharArray();
/*  805 */     int from = 0;
/*  806 */     int end = s.length;
/*  807 */     for (int i = 0; i < end; i++) {
/*  808 */       if (s[i] == '\r') {
/*  809 */         res.append(s, from, i - from);
/*  810 */         res.append('\n');
/*  811 */         if ((i + 1 < end) && (s[(i + 1)] == '\n')) {
/*  812 */           i++;
/*      */         }
/*      */ 
/*  815 */         from = i + 1;
/*      */       }
/*      */     }
/*      */ 
/*  819 */     if (from == 0) {
/*  820 */       return input;
/*      */     }
/*      */ 
/*  823 */     res.append(s, from, end - from);
/*  824 */     return res.toString();
/*      */   }
/*      */ 
/*      */   public static String padLeft(String s, int len, char padChar)
/*      */   {
/*  832 */     return Strings.padStart(s, len, padChar);
/*      */   }
/*      */ 
/*      */   public static String padRight(String s, int len, char padChar)
/*      */   {
/*  840 */     return Strings.padEnd(s, len, padChar);
/*      */   }
/*      */ 
/*      */   public static String maskLeft(String s, int len, char maskChar)
/*      */   {
/*  848 */     if (len <= 0) {
/*  849 */       return s;
/*      */     }
/*  851 */     len = Math.min(len, s.length());
/*  852 */     StringBuilder sb = new StringBuilder();
/*  853 */     for (int i = 0; i < len; i++) {
/*  854 */       sb.append(maskChar);
/*      */     }
/*  856 */     sb.append(s.substring(len));
/*  857 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private static boolean isOctal(char c) {
/*  861 */     return (c >= '0') && (c <= '7');
/*      */   }
/*      */ 
/*      */   private static boolean isHex(char c) {
/*  865 */     return ((c >= '0') && (c <= '9')) || ((c >= 'a') && (c <= 'f')) || ((c >= 'A') && (c <= 'F'));
/*      */   }
/*      */ 
/*      */   private static int hexValue(char c)
/*      */   {
/*  871 */     if ((c >= '0') && (c <= '9'))
/*  872 */       return c - '0';
/*  873 */     if ((c >= 'a') && (c <= 'f')) {
/*  874 */       return c - 'a' + 10;
/*      */     }
/*  876 */     return c - 'A' + 10;
/*      */   }
/*      */ 
/*      */   public static String unescapeCString(String s)
/*      */   {
/*  885 */     if (s.indexOf('\\') < 0)
/*      */     {
/*  887 */       return s;
/*      */     }
/*      */ 
/*  890 */     StringBuilder sb = new StringBuilder();
/*  891 */     int len = s.length();
/*  892 */     for (int i = 0; i < len; ) {
/*  893 */       char c = s.charAt(i++);
/*  894 */       if ((c == '\\') && (i < len)) {
/*  895 */         c = s.charAt(i++);
/*  896 */         switch (c) { case 'a':
/*  897 */           c = '\007'; break;
/*      */         case 'b':
/*  898 */           c = '\b'; break;
/*      */         case 'f':
/*  899 */           c = '\f'; break;
/*      */         case 'n':
/*  900 */           c = '\n'; break;
/*      */         case 'r':
/*  901 */           c = '\r'; break;
/*      */         case 't':
/*  902 */           c = '\t'; break;
/*      */         case 'v':
/*  903 */           c = '\013'; break;
/*      */         case '\\':
/*  904 */           c = '\\'; break;
/*      */         case '?':
/*  905 */           c = '?'; break;
/*      */         case '\'':
/*  906 */           c = '\''; break;
/*      */         case '"':
/*  907 */           c = '"'; break;
/*      */         default:
/*  910 */           if ((c == 'x') && (i < len) && (isHex(s.charAt(i))))
/*      */           {
/*  912 */             int v = hexValue(s.charAt(i++));
/*  913 */             if ((i < len) && (isHex(s.charAt(i)))) {
/*  914 */               v = v * 16 + hexValue(s.charAt(i++));
/*      */             }
/*  916 */             c = (char)v;
/*  917 */           } else if (isOctal(c))
/*      */           {
/*  919 */             int v = c - '0';
/*  920 */             if ((i < len) && (isOctal(s.charAt(i)))) {
/*  921 */               v = v * 8 + (s.charAt(i++) - '0');
/*      */             }
/*  923 */             if ((i < len) && (isOctal(s.charAt(i)))) {
/*  924 */               v = v * 8 + (s.charAt(i++) - '0');
/*      */             }
/*  926 */             c = (char)v;
/*      */           }
/*      */           else {
/*  929 */             sb.append('\\');
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  935 */       sb.append(c);
/*      */     }
/*  937 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String unescapeMySQLString(String s)
/*      */     throws IllegalArgumentException
/*      */   {
/*  954 */     char[] chars = s.toCharArray();
/*      */ 
/*  957 */     if ((chars.length < 2) || (chars[0] != chars[(chars.length - 1)]) || ((chars[0] != '\'') && (chars[0] != '"')))
/*      */     {
/*  959 */       throw new IllegalArgumentException("not a valid MySQL string: " + s);
/*      */     }
/*      */ 
/*  964 */     int j = 1;
/*  965 */     int f = 0;
/*  966 */     for (int i = 1; i < chars.length - 1; i++) {
/*  967 */       if (f == 0) {
/*  968 */         if (chars[i] == '\\')
/*  969 */           f = 1;
/*  970 */         else if (chars[i] == chars[0])
/*  971 */           f = 2;
/*      */         else
/*  973 */           chars[(j++)] = chars[i];
/*      */       }
/*  975 */       else if (f == 1) {
/*  976 */         switch (chars[i]) { case '0':
/*  977 */           chars[(j++)] = '\000'; break;
/*      */         case '\'':
/*  978 */           chars[(j++)] = '\''; break;
/*      */         case '"':
/*  979 */           chars[(j++)] = '"'; break;
/*      */         case 'b':
/*  980 */           chars[(j++)] = '\b'; break;
/*      */         case 'n':
/*  981 */           chars[(j++)] = '\n'; break;
/*      */         case 'r':
/*  982 */           chars[(j++)] = '\r'; break;
/*      */         case 't':
/*  983 */           chars[(j++)] = '\t'; break;
/*      */         case 'z':
/*  984 */           chars[(j++)] = '\032'; break;
/*      */         case '\\':
/*  985 */           chars[(j++)] = '\\'; break;
/*      */         default:
/*  988 */           chars[(j++)] = chars[i];
/*      */         }
/*      */ 
/*  991 */         f = 0;
/*      */       }
/*      */       else {
/*  994 */         if (chars[i] != chars[0]) {
/*  995 */           throw new IllegalArgumentException("not a valid MySQL string: " + s);
/*      */         }
/*  997 */         chars[(j++)] = chars[0];
/*  998 */         f = 0;
/*      */       }
/*      */     }
/*      */ 
/* 1002 */     if (f != 0) {
/* 1003 */       throw new IllegalArgumentException("not a valid MySQL string: " + s);
/*      */     }
/*      */ 
/* 1007 */     return new String(chars, 1, j - 1);
/*      */   }
/*      */ 
/*      */   public static final String unescapeHTML(String s)
/*      */   {
/* 1303 */     return unescapeHTML(s, false);
/*      */   }
/*      */ 
/*      */   public static final String unescapeHTML(String s, boolean emulateBrowsers)
/*      */   {
/* 1324 */     int index = s.indexOf('&');
/* 1325 */     if (index == -1)
/*      */     {
/* 1327 */       return s;
/*      */     }
/*      */ 
/* 1331 */     char[] chars = s.toCharArray();
/* 1332 */     char[] escaped = new char[chars.length];
/* 1333 */     System.arraycopy(chars, 0, escaped, 0, index);
/*      */ 
/* 1336 */     int pos = index;
/*      */ 
/* 1338 */     for (int i = index; i < chars.length; ) {
/* 1339 */       if (chars[i] != '&') {
/* 1340 */         escaped[(pos++)] = chars[(i++)];
/* 1341 */         continue;
/*      */       }
/*      */ 
/* 1345 */       int j = i + 1;
/* 1346 */       boolean isNumericEntity = false;
/* 1347 */       if ((j < chars.length) && (chars[j] == '#')) {
/* 1348 */         j++;
/* 1349 */         isNumericEntity = true;
/*      */       }
/*      */ 
/* 1353 */       boolean isHexEntity = false;
/* 1354 */       if ((j < chars.length) && ((chars[j] == 'x') || (chars[j] == 'X'))) {
/* 1355 */         j++;
/* 1356 */         isHexEntity = true;
/*      */       }
/*      */ 
/* 1360 */       for (; j < chars.length; j++) {
/* 1361 */         char ch = chars[j];
/* 1362 */         boolean isDigit = Character.isDigit(ch);
/* 1363 */         if (isNumericEntity)
/*      */         {
/* 1365 */           if ((!isHexEntity) && (!isDigit))
/*      */           {
/*      */             break;
/*      */           }
/* 1369 */           if ((isHexEntity) && (!isDigit) && (!HEX_LETTERS.contains(Character.valueOf(ch))))
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/* 1374 */         if ((!isDigit) && (!Character.isLetter(ch)))
/*      */         {
/*      */           break;
/*      */         }
/*      */       }
/* 1379 */       boolean replaced = false;
/* 1380 */       if (((j <= chars.length) && (emulateBrowsers)) || ((j < chars.length) && (chars[j] == ';')))
/*      */       {
/* 1383 */         if ((i + 2 < chars.length) && (s.charAt(i + 1) == '#')) {
/*      */           try {
/* 1385 */             long charcode = 0L;
/* 1386 */             char ch = s.charAt(i + 2);
/* 1387 */             if (isHexEntity) {
/* 1388 */               charcode = Long.parseLong(new String(chars, i + 3, j - i - 3), 16);
/*      */             }
/* 1390 */             else if (Character.isDigit(ch)) {
/* 1391 */               charcode = Long.parseLong(new String(chars, i + 2, j - i - 2));
/*      */             }
/*      */ 
/* 1394 */             if ((charcode > 0L) && (charcode < 65536L)) {
/* 1395 */               escaped[(pos++)] = (char)(int)charcode;
/* 1396 */               replaced = true;
/*      */             }
/*      */           } catch (NumberFormatException ex) {
/*      */           }
/*      */         }
/*      */         else {
/* 1402 */           String key = new String(chars, i, j - i);
/* 1403 */           Character repl = (Character)ESCAPE_STRINGS.get(key);
/* 1404 */           if (repl != null) {
/* 1405 */             escaped[(pos++)] = repl.charValue();
/* 1406 */             replaced = true;
/*      */           }
/*      */         }
/*      */ 
/* 1410 */         if ((j < chars.length) && (chars[j] == ';')) {
/* 1411 */           j++;
/*      */         }
/*      */       }
/*      */ 
/* 1415 */       if (!replaced)
/*      */       {
/* 1417 */         System.arraycopy(chars, i, escaped, pos, j - i);
/* 1418 */         pos += j - i;
/*      */       }
/* 1420 */       i = j;
/*      */     }
/* 1422 */     return new String(escaped, 0, pos);
/*      */   }
/*      */ 
/*      */   public static String stripHtmlTags(String string)
/*      */   {
/* 1441 */     if ((string == null) || ("".equals(string))) {
/* 1442 */       return string;
/*      */     }
/* 1444 */     String stripped = htmlTagPattern.matcher(string).replaceAll("");
/*      */ 
/* 1451 */     return LT_GT_ESCAPE.escape(stripped);
/*      */   }
/*      */ 
/*      */   public static String javaScriptEscape(CharSequence s)
/*      */   {
/* 1461 */     return javaScriptEscapeHelper(s, false);
/*      */   }
/*      */ 
/*      */   public static String javaScriptEscapeToAscii(CharSequence s)
/*      */   {
/* 1473 */     return javaScriptEscapeHelper(s, true);
/*      */   }
/*      */ 
/*      */   private static String javaScriptEscapeHelper(CharSequence s, boolean escapeToAscii)
/*      */   {
/* 1496 */     StringBuilder sb = new StringBuilder(s.length() * 9 / 8);
/*      */     try {
/* 1498 */       escapeStringBody(s, escapeToAscii, JsEscapingMode.EMBEDDABLE_JS, sb);
/*      */     }
/*      */     catch (IOException ex) {
/* 1501 */       throw new RuntimeException(ex);
/*      */     }
/* 1503 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static void escapeStringBody(CharSequence plainText, boolean escapeToAscii, JsEscapingMode jsEscapingMode, Appendable out)
/*      */     throws IOException
/*      */   {
/* 1535 */     int pos = 0;
/* 1536 */     int len = plainText.length();
/*      */     int charCount;
/* 1537 */     for (int i = 0; i < len; i += charCount) {
/* 1538 */       int codePoint = Character.codePointAt(plainText, i);
/* 1539 */       charCount = Character.charCount(codePoint);
/*      */ 
/* 1541 */       if (!shouldEscapeChar(codePoint, escapeToAscii, jsEscapingMode))
/*      */       {
/*      */         continue;
/*      */       }
/* 1545 */       out.append(plainText, pos, i);
/* 1546 */       pos = i + charCount;
/* 1547 */       switch (codePoint) { case 8:
/* 1548 */         out.append("\\b"); break;
/*      */       case 9:
/* 1549 */         out.append("\\t"); break;
/*      */       case 10:
/* 1550 */         out.append("\\n"); break;
/*      */       case 12:
/* 1551 */         out.append("\\f"); break;
/*      */       case 13:
/* 1552 */         out.append("\\r"); break;
/*      */       case 92:
/* 1553 */         out.append("\\\\"); break;
/*      */       case 34:
/*      */       case 39:
/* 1555 */         if ((jsEscapingMode == JsEscapingMode.JSON) && (39 == codePoint))
/*      */         {
/* 1558 */           out.append((char)codePoint);
/* 1559 */           continue;
/* 1560 */         }if (jsEscapingMode == JsEscapingMode.EMBEDDABLE_JS) break;
/* 1561 */         out.append('\\').append((char)codePoint);
/* 1562 */         break;
/*      */       }
/*      */ 
/* 1566 */       if ((codePoint >= 256) || (jsEscapingMode == JsEscapingMode.JSON)) {
/* 1567 */         appendHexJavaScriptRepresentation(codePoint, out);
/*      */       }
/*      */       else
/*      */       {
/* 1572 */         boolean pad = (i + charCount >= len) || (isOctal(plainText.charAt(i + charCount)));
/*      */ 
/* 1574 */         appendOctalJavaScriptRepresentation((char)codePoint, pad, out);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1579 */     out.append(plainText, pos, len);
/*      */   }
/*      */ 
/*      */   private static boolean shouldEscapeChar(int codePoint, boolean escapeToAscii, JsEscapingMode jsEscapingMode)
/*      */   {
/* 1588 */     if ((escapeToAscii) && ((codePoint < 32) || (codePoint > 126))) {
/* 1589 */       return true;
/*      */     }
/*      */ 
/* 1597 */     if (jsEscapingMode == JsEscapingMode.JSON) {
/* 1598 */       return (mustEscapeCharInJsonString(codePoint)) || (mustEscapeCharInJsString(codePoint));
/*      */     }
/*      */ 
/* 1603 */     return mustEscapeCharInJsString(codePoint);
/*      */   }
/*      */ 
/*      */   private static void appendHexJavaScriptRepresentation(int codePoint, Appendable out)
/*      */     throws IOException
/*      */   {
/* 1616 */     if (Character.isSupplementaryCodePoint(codePoint))
/*      */     {
/* 1621 */       char[] surrogates = Character.toChars(codePoint);
/* 1622 */       appendHexJavaScriptRepresentation(surrogates[0], out);
/* 1623 */       appendHexJavaScriptRepresentation(surrogates[1], out);
/* 1624 */       return;
/*      */     }
/* 1626 */     out.append("\\u").append(HEX_CHARS[(codePoint >>> 12 & 0xF)]).append(HEX_CHARS[(codePoint >>> 8 & 0xF)]).append(HEX_CHARS[(codePoint >>> 4 & 0xF)]).append(HEX_CHARS[(codePoint & 0xF)]);
/*      */   }
/*      */ 
/*      */   private static void appendOctalJavaScriptRepresentation(char ch, boolean pad, Appendable out)
/*      */     throws IOException
/*      */   {
/* 1644 */     if ((ch >= '@') || (pad))
/*      */     {
/* 1648 */       out.append('\\').append(OCTAL_CHARS[(ch >>> '\006' & 0x7)]).append(OCTAL_CHARS[(ch >>> '\003' & 0x7)]).append(OCTAL_CHARS[(ch & 0x7)]);
/*      */     }
/* 1652 */     else if (ch >= '\b') {
/* 1653 */       out.append('\\').append(OCTAL_CHARS[(ch >>> '\003' & 0x7)]).append(OCTAL_CHARS[(ch & 0x7)]);
/*      */     }
/*      */     else
/*      */     {
/* 1657 */       out.append('\\').append(OCTAL_CHARS[(ch & 0x7)]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void appendHexJavaScriptRepresentation(StringBuilder sb, char c)
/*      */   {
/*      */     try
/*      */     {
/* 1671 */       appendHexJavaScriptRepresentation(c, sb);
/*      */     }
/*      */     catch (IOException ex) {
/* 1674 */       throw new RuntimeException(ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String javaScriptUnescape(String s)
/*      */   {
/* 1684 */     StringBuilder sb = new StringBuilder(s.length());
/* 1685 */     for (int i = 0; i < s.length(); ) {
/* 1686 */       char c = s.charAt(i);
/* 1687 */       if (c == '\\') {
/* 1688 */         i = javaScriptUnescapeHelper(s, i + 1, sb);
/*      */       } else {
/* 1690 */         sb.append(c);
/* 1691 */         i++;
/*      */       }
/*      */     }
/* 1694 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private static int javaScriptUnescapeHelper(String s, int i, StringBuilder sb)
/*      */   {
/* 1707 */     if (i >= s.length()) {
/* 1708 */       throw new IllegalArgumentException("End-of-string after escape character in [" + s + "]");
/*      */     }
/*      */ 
/* 1712 */     char c = s.charAt(i++);
/* 1713 */     switch (c) { case 'n':
/* 1714 */       sb.append('\n'); break;
/*      */     case 'r':
/* 1715 */       sb.append('\r'); break;
/*      */     case 't':
/* 1716 */       sb.append('\t'); break;
/*      */     case 'b':
/* 1717 */       sb.append('\b'); break;
/*      */     case 'f':
/* 1718 */       sb.append('\f'); break;
/*      */     case '"':
/*      */     case '\'':
/*      */     case '>':
/*      */     case '\\':
/* 1723 */       sb.append(c);
/* 1724 */       break;
/*      */     case '0':
/*      */     case '1':
/*      */     case '2':
/*      */     case '3':
/*      */     case '4':
/*      */     case '5':
/*      */     case '6':
/*      */     case '7':
/* 1727 */       i--;
/* 1728 */       int nOctalDigits = 1;
/* 1729 */       int digitLimit = c < '4' ? 3 : 2;
/*      */ 
/* 1731 */       while ((nOctalDigits < digitLimit) && (i + nOctalDigits < s.length()) && (isOctal(s.charAt(i + nOctalDigits)))) {
/* 1732 */         nOctalDigits++;
/*      */       }
/* 1734 */       sb.append((char)Integer.parseInt(s.substring(i, i + nOctalDigits), 8));
/*      */ 
/* 1736 */       i += nOctalDigits;
/* 1737 */       break;
/*      */     case 'u':
/*      */     case 'x':
/* 1741 */       int nHexDigits = c == 'u' ? 4 : 2;
/*      */       String hexCode;
/*      */       try { hexCode = s.substring(i, i + nHexDigits);
/*      */       } catch (IndexOutOfBoundsException ioobe) {
/* 1745 */         throw new IllegalArgumentException("Invalid unicode sequence [" + s.substring(i) + "] at index " + i + " in [" + s + "]");
/*      */       }
/*      */       int unicodeValue;
/*      */       try
/*      */       {
/* 1751 */         unicodeValue = Integer.parseInt(hexCode, 16);
/*      */       } catch (NumberFormatException nfe) {
/* 1753 */         throw new IllegalArgumentException("Invalid unicode sequence [" + hexCode + "] at index " + i + " in [" + s + "]");
/*      */       }
/*      */ 
/* 1757 */       sb.append((char)unicodeValue);
/* 1758 */       i += nHexDigits;
/* 1759 */       break;
/*      */     default:
/* 1761 */       throw new IllegalArgumentException("Unknown escape code [" + c + "] at index " + i + " in [" + s + "]");
/*      */     }
/*      */ 
/* 1766 */     return i;
/*      */   }
/*      */ 
/*      */   public static String xmlCDataEscape(String s)
/*      */   {
/* 1791 */     s = CONTROL_MATCHER.removeFrom(s);
/*      */ 
/* 1793 */     int found = s.indexOf("]]>");
/* 1794 */     if (found == -1) {
/* 1795 */       return s;
/*      */     }
/*      */ 
/* 1800 */     StringBuilder sb = new StringBuilder();
/* 1801 */     int prev = 0;
/*      */     do {
/* 1803 */       sb.append(s.substring(prev, found + 3));
/* 1804 */       sb.append("]]&gt;<![CDATA[");
/* 1805 */       prev = found + 3;
/* 1806 */     }while ((found = s.indexOf("]]>", prev)) != -1);
/* 1807 */     sb.append(s.substring(prev));
/* 1808 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String javaEscape(String s)
/*      */   {
/* 1821 */     return JAVA_ESCAPE.escape(s);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String regexEscape(String s)
/*      */   {
/* 1848 */     return REGEX_ESCAPE.escape(s);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static LinkedList<String> string2List(String in, String delimiter, boolean doStrip)
/*      */   {
/* 1885 */     if (in == null) {
/* 1886 */       return null;
/*      */     }
/*      */ 
/* 1889 */     LinkedList out = new LinkedList();
/* 1890 */     string2Collection(in, delimiter, doStrip, out);
/* 1891 */     return out;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static Set<String> string2Set(String in, @Nullable String delimiter, boolean doStrip)
/*      */   {
/* 1913 */     if (in == null) {
/* 1914 */       return null;
/*      */     }
/*      */ 
/* 1917 */     HashSet out = new HashSet();
/* 1918 */     string2Collection(in, delimiter, doStrip, out);
/* 1919 */     return out;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static Collection<String> string2Collection(String in, @Nullable String delimiter, boolean doStrip, Collection<String> collection)
/*      */   {
/* 1946 */     if (in == null) {
/* 1947 */       return null;
/*      */     }
/* 1949 */     if (collection == null) {
/* 1950 */       collection = new ArrayList();
/*      */     }
/* 1952 */     if ((delimiter == null) || (delimiter.length() == 0)) {
/* 1953 */       collection.add(in);
/* 1954 */       return collection;
/*      */     }
/*      */ 
/* 1957 */     int fromIndex = 0;
/*      */     int pos;
/* 1959 */     while ((pos = in.indexOf(delimiter, fromIndex)) >= 0) {
/* 1960 */       String interim = in.substring(fromIndex, pos);
/* 1961 */       if (doStrip) {
/* 1962 */         interim = strip(interim);
/*      */       }
/* 1964 */       if ((!doStrip) || (interim.length() > 0)) {
/* 1965 */         collection.add(interim);
/*      */       }
/*      */ 
/* 1968 */       fromIndex = pos + delimiter.length();
/*      */     }
/*      */ 
/* 1971 */     String interim = in.substring(fromIndex);
/* 1972 */     if (doStrip) {
/* 1973 */       interim = strip(interim);
/*      */     }
/* 1975 */     if ((!doStrip) || (interim.length() > 0)) {
/* 1976 */       collection.add(interim);
/*      */     }
/*      */ 
/* 1979 */     return collection;
/*      */   }
/*      */ 
/*      */   public static HashMap<String, String> string2Map(String in, @Nullable String delimEntry, @Nullable String delimKey, boolean doStripEntry)
/*      */   {
/* 2001 */     if (in == null) {
/* 2002 */       return null;
/*      */     }
/*      */ 
/* 2005 */     return (HashMap)stringToMapImpl(new HashMap(), in, delimEntry, delimKey, doStripEntry);
/*      */   }
/*      */ 
/*      */   public static Map<String, String> stringToOrderedMap(String in, @Nullable String delimEntry, @Nullable String delimKey, boolean doStripEntry)
/*      */   {
/* 2026 */     if (in == null) {
/* 2027 */       return null;
/*      */     }
/*      */ 
/* 2030 */     return stringToMapImpl(new LinkedHashMap(), in, delimEntry, delimKey, doStripEntry);
/*      */   }
/*      */ 
/*      */   private static <T extends Map<String, String>> T stringToMapImpl(T out, String in, String delimEntry, String delimKey, boolean doStripEntry)
/*      */   {
/* 2050 */     if ((isEmpty(delimEntry)) || (isEmpty(delimKey))) {
/* 2051 */       out.put(strip(in), "");
/* 2052 */       return out;
/*      */     }
/*      */ 
/* 2055 */     Iterator it = string2List(in, delimEntry, false).iterator();
/* 2056 */     int len = delimKey.length();
/* 2057 */     while (it.hasNext()) {
/* 2058 */       String entry = (String)it.next();
/* 2059 */       int pos = entry.indexOf(delimKey);
/* 2060 */       if (pos > 0) {
/* 2061 */         String value = entry.substring(pos + len);
/* 2062 */         if (doStripEntry) {
/* 2063 */           value = strip(value);
/*      */         }
/* 2065 */         out.put(strip(entry.substring(0, pos)), value);
/*      */       } else {
/* 2067 */         out.put(strip(entry), "");
/*      */       }
/*      */     }
/*      */ 
/* 2071 */     return out;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static <K, V> String map2String(Map<K, V> in, String sepKey, String sepEntry)
/*      */   {
/* 2089 */     return in == null ? null : Joiner.on(sepEntry).useForNull("null").withKeyValueSeparator(sepKey).join(in);
/*      */   }
/*      */ 
/*      */   public static <V> Map<String, V> lowercaseKeys(Map<String, V> map)
/*      */   {
/* 2105 */     Map result = new HashMap(map.size());
/* 2106 */     for (Map.Entry entry : map.entrySet()) {
/* 2107 */       String key = (String)entry.getKey();
/* 2108 */       if (result.containsKey(key.toLowerCase())) {
/* 2109 */         throw new IllegalArgumentException("Duplicate string key in map when lower casing");
/*      */       }
/*      */ 
/* 2112 */       result.put(key.toLowerCase(), entry.getValue());
/*      */     }
/* 2114 */     return result;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String collapseWhitespace(String str)
/*      */   {
/* 2129 */     return str == null ? null : CharMatcher.LEGACY_WHITESPACE.collapseFrom(str, ' ');
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String collapse(String str, String chars, String replacement)
/*      */   {
/* 2157 */     if (str == null) {
/* 2158 */       return null;
/*      */     }
/*      */ 
/* 2161 */     StringBuilder newStr = new StringBuilder();
/*      */ 
/* 2163 */     boolean prevCharMatched = false;
/*      */ 
/* 2165 */     for (int i = 0; i < str.length(); i++) {
/* 2166 */       char c = str.charAt(i);
/* 2167 */       if (chars.indexOf(c) != -1)
/*      */       {
/* 2169 */         if (prevCharMatched)
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 2174 */         prevCharMatched = true;
/* 2175 */         newStr.append(replacement);
/*      */       } else {
/* 2177 */         prevCharMatched = false;
/* 2178 */         newStr.append(c);
/*      */       }
/*      */     }
/*      */ 
/* 2182 */     return newStr.toString();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String collapseControlChars(String str, String replacement)
/*      */   {
/* 2209 */     if (str == null) {
/* 2210 */       return null;
/*      */     }
/*      */ 
/* 2213 */     StringBuilder newStr = new StringBuilder();
/*      */ 
/* 2215 */     boolean prevCharMatched = false;
/*      */ 
/* 2217 */     for (int i = 0; i < str.length(); i++) {
/* 2218 */       char c = str.charAt(i);
/* 2219 */       if (Character.isISOControl(c))
/*      */       {
/* 2221 */         if (prevCharMatched)
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 2226 */         prevCharMatched = true;
/* 2227 */         newStr.append(replacement);
/*      */       } else {
/* 2229 */         prevCharMatched = false;
/* 2230 */         newStr.append(c);
/*      */       }
/*      */     }
/*      */ 
/* 2234 */     return newStr.toString();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String stream2String(InputStream is, int maxLength)
/*      */     throws IOException
/*      */   {
/* 2266 */     byte[] buffer = new byte[4096];
/* 2267 */     StringWriter sw = new StringWriter();
/* 2268 */     int totalRead = 0;
/* 2269 */     int read = 0;
/*      */     do
/*      */     {
/* 2272 */       sw.write(new String(buffer, 0, read));
/* 2273 */       totalRead += read;
/* 2274 */       read = is.read(buffer, 0, buffer.length);
/* 2275 */     }while (((-1 == maxLength) || (totalRead < maxLength)) && (read != -1));
/*      */ 
/* 2277 */     return sw.toString();
/*      */   }
/*      */ 
/*      */   public static String[] parseDelimitedList(String list, char delimiter)
/*      */   {
/* 2294 */     String delim = "" + delimiter;
/*      */ 
/* 2297 */     StringTokenizer st = new StringTokenizer(list + delim + " ", delim, true);
/*      */ 
/* 2300 */     ArrayList v = new ArrayList();
/* 2301 */     String lastToken = "";
/* 2302 */     StringBuilder word = new StringBuilder();
/*      */ 
/* 2316 */     while (st.hasMoreTokens()) {
/* 2317 */       String tok = st.nextToken();
/* 2318 */       if (lastToken != null) {
/* 2319 */         if (tok.equals(delim)) {
/* 2320 */           word.append(lastToken);
/* 2321 */           if (lastToken.equals(delim)) tok = null; 
/*      */         }
/*      */         else {
/* 2323 */           if (word.length() != 0) {
/* 2324 */             v.add(word.toString());
/*      */           }
/* 2326 */           word.setLength(0);
/*      */         }
/*      */       }
/* 2329 */       lastToken = tok;
/*      */     }
/*      */ 
/* 2332 */     return (String[])v.toArray(new String[0]);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static int compareToIgnoreCase(String s1, String s2, boolean nullsAreGreater)
/*      */   {
/* 2347 */     if (s1 == s2) {
/* 2348 */       return 0;
/*      */     }
/* 2350 */     if (s1 == null) {
/* 2351 */       return nullsAreGreater ? 1 : -1;
/*      */     }
/* 2353 */     if (s2 == null) {
/* 2354 */       return nullsAreGreater ? -1 : 1;
/*      */     }
/* 2356 */     return s1.compareToIgnoreCase(s2);
/*      */   }
/*      */ 
/*      */   public static String lastToken(String s, String delimiter)
/*      */   {
/* 2363 */     return s.substring(CharMatcher.anyOf(delimiter).lastIndexIn(s) + 1);
/*      */   }
/*      */ 
/*      */   public static boolean containsCharRef(String s)
/*      */   {
/* 2374 */     return characterReferencePattern.matcher(s).find();
/*      */   }
/*      */ 
/*      */   public static boolean isHebrew(String s)
/*      */   {
/* 2382 */     int len = s.length();
/* 2383 */     for (int i = 0; i < len; i++) {
/* 2384 */       if (isHebrew(s.codePointAt(i))) {
/* 2385 */         return true;
/*      */       }
/*      */     }
/* 2388 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isHebrew(int codePoint)
/*      */   {
/* 2395 */     return Character.UnicodeBlock.HEBREW.equals(Character.UnicodeBlock.of(codePoint));
/*      */   }
/*      */ 
/*      */   public static boolean isCjk(String s)
/*      */   {
/* 2404 */     int len = s.length();
/* 2405 */     for (int i = 0; i < len; i++) {
/* 2406 */       if (isCjk(s.codePointAt(i))) {
/* 2407 */         return true;
/*      */       }
/*      */     }
/* 2410 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isCjk(char ch)
/*      */   {
/* 2452 */     return isCjk(ch);
/*      */   }
/*      */ 
/*      */   public static boolean isCjk(int codePoint)
/*      */   {
/* 2461 */     if ((codePoint & 0xFFFFFF00) == 0) {
/* 2462 */       return false;
/*      */     }
/*      */ 
/* 2465 */     return CJK_BLOCKS.contains(Character.UnicodeBlock.of(codePoint));
/*      */   }
/*      */ 
/*      */   public static int displayWidth(String s)
/*      */   {
/* 2477 */     int width = 0;
/* 2478 */     int len = s.length();
/* 2479 */     for (int i = 0; i < len; i++) {
/* 2480 */       width += displayWidth(s.charAt(i));
/*      */     }
/* 2482 */     return width;
/*      */   }
/*      */ 
/*      */   public static int displayWidth(char ch)
/*      */   {
/* 2509 */     if ((ch <= 'ӹ') || (ch == '־') || ((ch >= 'א') && (ch <= 'ת')) || (ch == '׳') || (ch == '״') || ((ch >= '؀') && (ch <= 'ۿ')) || ((ch >= 'ݐ') && (ch <= 'ݿ')) || ((ch >= 64336) && (ch <= 65023)) || ((ch >= 65136) && (ch <= 65279)) || ((ch >= 'Ḁ') && (ch <= '₯')) || ((ch >= '℀') && (ch <= '℺')) || ((ch >= '฀') && (ch <= '๿')) || ((ch >= 65377) && (ch <= 65500)))
/*      */     {
/* 2524 */       return 1;
/*      */     }
/* 2526 */     return 2;
/*      */   }
/*      */ 
/*      */   public static String toString(float[] iArray)
/*      */   {
/* 2533 */     if (iArray == null) {
/* 2534 */       return "NULL";
/*      */     }
/*      */ 
/* 2537 */     StringBuilder buffer = new StringBuilder();
/* 2538 */     buffer.append("[");
/* 2539 */     for (int i = 0; i < iArray.length; i++) {
/* 2540 */       buffer.append(iArray[i]);
/* 2541 */       if (i != iArray.length - 1) {
/* 2542 */         buffer.append(", ");
/*      */       }
/*      */     }
/* 2545 */     buffer.append("]");
/* 2546 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static String toString(long[] iArray)
/*      */   {
/* 2553 */     if (iArray == null) {
/* 2554 */       return "NULL";
/*      */     }
/*      */ 
/* 2557 */     StringBuilder buffer = new StringBuilder();
/* 2558 */     buffer.append("[");
/* 2559 */     for (int i = 0; i < iArray.length; i++) {
/* 2560 */       buffer.append(iArray[i]);
/* 2561 */       if (i != iArray.length - 1) {
/* 2562 */         buffer.append(", ");
/*      */       }
/*      */     }
/* 2565 */     buffer.append("]");
/* 2566 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static String toString(int[] iArray)
/*      */   {
/* 2573 */     if (iArray == null) {
/* 2574 */       return "NULL";
/*      */     }
/*      */ 
/* 2577 */     StringBuilder buffer = new StringBuilder();
/* 2578 */     buffer.append("[");
/* 2579 */     for (int i = 0; i < iArray.length; i++) {
/* 2580 */       buffer.append(iArray[i]);
/* 2581 */       if (i != iArray.length - 1) {
/* 2582 */         buffer.append(", ");
/*      */       }
/*      */     }
/* 2585 */     buffer.append("]");
/* 2586 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static String toString(String[] iArray)
/*      */   {
/* 2593 */     if (iArray == null) return "NULL";
/*      */ 
/* 2595 */     StringBuilder buffer = new StringBuilder();
/* 2596 */     buffer.append("[");
/* 2597 */     for (int i = 0; i < iArray.length; i++) {
/* 2598 */       buffer.append("'").append(iArray[i]).append("'");
/* 2599 */       if (i != iArray.length - 1) {
/* 2600 */         buffer.append(", ");
/*      */       }
/*      */     }
/* 2603 */     buffer.append("]");
/*      */ 
/* 2605 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static String toString(String s)
/*      */   {
/* 2616 */     if (s == null) {
/* 2617 */       return "NULL";
/*      */     }
/* 2619 */     return s.length() + 2 + "'" + s + "'";
/*      */   }
/*      */ 
/*      */   public static String toString(int[][] iArray)
/*      */   {
/* 2628 */     if (iArray == null) {
/* 2629 */       return "NULL";
/*      */     }
/*      */ 
/* 2632 */     StringBuilder buffer = new StringBuilder();
/* 2633 */     buffer.append("[");
/* 2634 */     for (int i = 0; i < iArray.length; i++) {
/* 2635 */       buffer.append("[");
/* 2636 */       for (int j = 0; j < iArray[i].length; j++) {
/* 2637 */         buffer.append(iArray[i][j]);
/* 2638 */         if (j != iArray[i].length - 1) {
/* 2639 */           buffer.append(", ");
/*      */         }
/*      */       }
/* 2642 */       buffer.append("]");
/* 2643 */       if (i != iArray.length - 1) {
/* 2644 */         buffer.append(" ");
/*      */       }
/*      */     }
/* 2647 */     buffer.append("]");
/* 2648 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static String toString(long[][] iArray)
/*      */   {
/* 2655 */     if (iArray == null) return "NULL";
/*      */ 
/* 2657 */     StringBuilder buffer = new StringBuilder();
/* 2658 */     buffer.append("[");
/* 2659 */     for (int i = 0; i < iArray.length; i++) {
/* 2660 */       buffer.append("[");
/* 2661 */       for (int j = 0; j < iArray[i].length; j++) {
/* 2662 */         buffer.append(iArray[i][j]);
/* 2663 */         if (j != iArray[i].length - 1) {
/* 2664 */           buffer.append(", ");
/*      */         }
/*      */       }
/* 2667 */       buffer.append("]");
/* 2668 */       if (i != iArray.length - 1) {
/* 2669 */         buffer.append(" ");
/*      */       }
/*      */     }
/* 2672 */     buffer.append("]");
/* 2673 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   public static String toString(Object[] obj)
/*      */   {
/* 2682 */     if (obj == null) return "NULL";
/* 2683 */     StringBuilder tmp = new StringBuilder();
/* 2684 */     tmp.append("[");
/* 2685 */     for (int i = 0; i < obj.length; i++) {
/* 2686 */       tmp.append(obj[i].toString());
/* 2687 */       if (i != obj.length - 1) {
/* 2688 */         tmp.append(",");
/*      */       }
/*      */     }
/* 2691 */     tmp.append("]");
/* 2692 */     return tmp.toString();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String bytesToHexString(byte[] bytes)
/*      */   {
/* 2706 */     return ByteArrays.toHexString(bytes);
/*      */   }
/*      */ 
/*      */   public static String bytesToHexString(byte[] bytes, Character delimiter)
/*      */   {
/* 2715 */     StringBuilder hex = new StringBuilder(bytes.length * (delimiter == null ? 2 : 3));
/*      */ 
/* 2718 */     for (int i = 0; i < bytes.length; i++) {
/* 2719 */       int nibble1 = bytes[i] >>> 4 & 0xF;
/* 2720 */       int nibble2 = bytes[i] & 0xF;
/* 2721 */       if ((i > 0) && (delimiter != null)) hex.append(delimiter.charValue());
/* 2722 */       hex.append(HEX_CHARS[nibble1]);
/* 2723 */       hex.append(HEX_CHARS[nibble2]);
/*      */     }
/* 2725 */     return hex.toString();
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static String bytesToUtf8(byte[] ba)
/*      */   {
/* 2738 */     return ba == null ? null : new String(ba, Charsets.UTF_8);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public static byte[] utf8ToBytes(String str)
/*      */   {
/* 2751 */     return str == null ? null : str.getBytes(Charsets.UTF_8);
/*      */   }
/*      */ 
/*      */   public static String toUpperCase(String src)
/*      */   {
/* 2760 */     if (src == null) {
/* 2761 */       return null;
/*      */     }
/* 2763 */     return src.toUpperCase();
/*      */   }
/*      */ 
/*      */   public static String toLowerCase(String src)
/*      */   {
/* 2773 */     if (src == null) {
/* 2774 */       return null;
/*      */     }
/* 2776 */     return src.toLowerCase();
/*      */   }
/*      */ 
/*      */   public static String expandShardNames(String dbSpecComponent)
/*      */     throws IllegalArgumentException, IllegalStateException
/*      */   {
/* 2800 */     Matcher matcher = dbSpecPattern.matcher(dbSpecComponent);
/* 2801 */     if (matcher.find()) {
/*      */       try {
/* 2803 */         String prefix = dbSpecComponent.substring(matcher.start(1), matcher.end(1));
/*      */ 
/* 2805 */         int minShard = Integer.parseInt(dbSpecComponent.substring(matcher.start(2), matcher.end(2)));
/*      */ 
/* 2809 */         int maxShard = Integer.parseInt(dbSpecComponent.substring(matcher.start(3), matcher.end(3)));
/*      */ 
/* 2813 */         String suffix = dbSpecComponent.substring(matcher.start(4), matcher.end(4));
/*      */ 
/* 2816 */         if (minShard > maxShard) {
/* 2817 */           throw new IllegalArgumentException("Maximum shard must be greater than or equal to the minimum shard");
/*      */         }
/*      */ 
/* 2821 */         StringBuilder tmp = new StringBuilder();
/* 2822 */         for (int shard = minShard; shard <= maxShard; shard++) {
/* 2823 */           tmp.append(prefix).append(shard).append(suffix);
/* 2824 */           if (shard != maxShard) {
/* 2825 */             tmp.append(",");
/*      */           }
/*      */         }
/* 2828 */         return tmp.toString();
/*      */       } catch (NumberFormatException nfex) {
/* 2830 */         throw new IllegalArgumentException("Malformed DB specification component: " + dbSpecComponent);
/*      */       }
/*      */     }
/*      */ 
/* 2834 */     return dbSpecComponent;
/*      */   }
/*      */ 
/*      */   public static String capitalize(String s)
/*      */   {
/* 2860 */     if (s.isEmpty()) {
/* 2861 */       return s;
/*      */     }
/* 2863 */     char first = s.charAt(0);
/* 2864 */     char capitalized = Character.toUpperCase(first);
/* 2865 */     return capitalized + s.substring(1);
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String str, String prefix)
/*      */   {
/* 2881 */     return str.regionMatches(true, 0, prefix, 0, prefix.length());
/*      */   }
/*      */ 
/*      */   public static boolean endsWithIgnoreCase(String str, String suffix)
/*      */   {
/* 2895 */     int len = suffix.length();
/* 2896 */     return str.regionMatches(true, str.length() - len, suffix, 0, len);
/*      */   }
/*      */ 
/*      */   private static int bytesUtf8(int c)
/*      */   {
/* 2904 */     if (c < 128)
/* 2905 */       return 1;
/* 2906 */     if (c < 2048)
/* 2907 */       return 2;
/* 2908 */     if (c < 65536)
/* 2909 */       return 3;
/* 2910 */     if (c < 2097152) {
/* 2911 */       return 4;
/*      */     }
/*      */ 
/* 2915 */     if (c < 67108864) {
/* 2916 */       return 5;
/*      */     }
/* 2918 */     return 6;
/*      */   }
/*      */ 
/*      */   public static int bytesStorage(String str)
/*      */   {
/* 2930 */     String s = new String(str);
/*      */ 
/* 2932 */     int len = 0;
/* 2933 */     for (int i = 0; i < s.length(); i = s.offsetByCodePoints(i, 1)) {
/* 2934 */       len += bytesUtf8(s.codePointAt(i));
/*      */     }
/* 2936 */     return len;
/*      */   }
/*      */ 
/*      */   public static String truncateStringForUtf8Storage(String str, int maxbytes)
/*      */   {
/* 2947 */     if (maxbytes < 0) {
/* 2948 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */ 
/* 2955 */     String s = new String(str);
/*      */ 
/* 2957 */     int codepoints = 0;
/* 2958 */     int bytesUsed = 0;
/* 2959 */     for (codepoints = 0; codepoints < s.length(); )
/*      */     {
/* 2961 */       int glyphBytes = bytesUtf8(s.codePointAt(codepoints));
/* 2962 */       if (bytesUsed + glyphBytes > maxbytes) {
/*      */         break;
/*      */       }
/* 2965 */       bytesUsed += glyphBytes;
/*      */ 
/* 2960 */       codepoints = s.offsetByCodePoints(codepoints, 1);
/*      */     }
/*      */ 
/* 2967 */     return s.substring(0, codepoints);
/*      */   }
/*      */ 
/*      */   public static String truncateIfNecessary(String source, int maxLength)
/*      */   {
/* 2984 */     if (source.length() <= maxLength) {
/* 2985 */       return source;
/*      */     }
/* 2987 */     String str = unicodePreservingSubstring(source, 0, maxLength);
/*      */ 
/* 2990 */     CharMatcher whitespaceMatcher = CharMatcher.LEGACY_WHITESPACE;
/* 2991 */     String truncated = whitespaceMatcher.trimTrailingFrom(str);
/*      */ 
/* 2994 */     if (truncated.length() < maxLength) {
/* 2995 */       return truncated;
/*      */     }
/*      */ 
/* 2999 */     if (Character.isSpaceChar(source.charAt(maxLength))) {
/* 3000 */       return truncated;
/*      */     }
/*      */ 
/* 3004 */     for (int i = truncated.length() - 1; i >= 0; i--) {
/* 3005 */       if (Character.isSpaceChar(truncated.charAt(i))) {
/* 3006 */         String substr = truncated.substring(0, i);
/* 3007 */         return whitespaceMatcher.trimTrailingFrom(substr);
/*      */       }
/*      */     }
/* 3010 */     return truncated;
/*      */   }
/*      */ 
/*      */   public static String truncateAtMaxLength(String source, int maxLength, boolean addEllipsis)
/*      */   {
/* 3033 */     if (source.length() <= maxLength) {
/* 3034 */       return source;
/*      */     }
/* 3036 */     if ((addEllipsis) && (maxLength > 3)) {
/* 3037 */       return unicodePreservingSubstring(source, 0, maxLength - 3) + "...";
/*      */     }
/* 3039 */     return unicodePreservingSubstring(source, 0, maxLength);
/*      */   }
/*      */ 
/*      */   public static int unicodePreservingIndex(String str, int index)
/*      */   {
/* 3060 */     if ((index > 0) && (index < str.length()) && 
/* 3061 */       (Character.isHighSurrogate(str.charAt(index - 1))) && (Character.isLowSurrogate(str.charAt(index))))
/*      */     {
/* 3063 */       return index - 1;
/*      */     }
/*      */ 
/* 3066 */     return index;
/*      */   }
/*      */ 
/*      */   public static String unicodePreservingSubstring(String str, int begin, int end)
/*      */   {
/* 3101 */     return str.substring(unicodePreservingIndex(str, begin), unicodePreservingIndex(str, end));
/*      */   }
/*      */ 
/*      */   public static String unicodePreservingSubstring(String str, int begin)
/*      */   {
/* 3114 */     return unicodePreservingSubstring(str, begin, str.length());
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static boolean mustEscapeCharInJsString(int codepoint)
/*      */   {
/* 3157 */     return JS_ESCAPE_CHARS.contains(Integer.valueOf(codepoint));
/*      */   }
/*      */ 
/*      */   @VisibleForTesting
/*      */   static boolean mustEscapeCharInJsonString(int codepoint)
/*      */   {
/* 3173 */     return JSON_ESCAPE_CHARS.contains(Integer.valueOf(codepoint));
/*      */   }
/*      */ 
/*      */   public static String xmlEscape(String s)
/*      */   {
/* 3244 */     return CharEscapers.xmlEscaper().escape(s);
/*      */   }
/*      */ 
/*      */   public static String htmlEscape(String s)
/*      */   {
/* 3251 */     return CharEscapers.asciiHtmlEscaper().escape(s);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 1020 */     ESCAPE_STRINGS.put("&nbsp", Character.valueOf(' '));
/* 1021 */     ESCAPE_STRINGS.put("&iexcl", Character.valueOf('¡'));
/* 1022 */     ESCAPE_STRINGS.put("&cent", Character.valueOf('¢'));
/* 1023 */     ESCAPE_STRINGS.put("&pound", Character.valueOf('£'));
/* 1024 */     ESCAPE_STRINGS.put("&curren", Character.valueOf('¤'));
/* 1025 */     ESCAPE_STRINGS.put("&yen", Character.valueOf('¥'));
/* 1026 */     ESCAPE_STRINGS.put("&brvbar", Character.valueOf('¦'));
/* 1027 */     ESCAPE_STRINGS.put("&sect", Character.valueOf('§'));
/* 1028 */     ESCAPE_STRINGS.put("&uml", Character.valueOf('¨'));
/* 1029 */     ESCAPE_STRINGS.put("&copy", Character.valueOf('©'));
/* 1030 */     ESCAPE_STRINGS.put("&ordf", Character.valueOf('ª'));
/* 1031 */     ESCAPE_STRINGS.put("&laquo", Character.valueOf('«'));
/* 1032 */     ESCAPE_STRINGS.put("&not", Character.valueOf('¬'));
/* 1033 */     ESCAPE_STRINGS.put("&shy", Character.valueOf('­'));
/* 1034 */     ESCAPE_STRINGS.put("&reg", Character.valueOf('®'));
/* 1035 */     ESCAPE_STRINGS.put("&macr", Character.valueOf('¯'));
/* 1036 */     ESCAPE_STRINGS.put("&deg", Character.valueOf('°'));
/* 1037 */     ESCAPE_STRINGS.put("&plusmn", Character.valueOf('±'));
/* 1038 */     ESCAPE_STRINGS.put("&sup2", Character.valueOf('²'));
/* 1039 */     ESCAPE_STRINGS.put("&sup3", Character.valueOf('³'));
/* 1040 */     ESCAPE_STRINGS.put("&acute", Character.valueOf('´'));
/* 1041 */     ESCAPE_STRINGS.put("&micro", Character.valueOf('µ'));
/* 1042 */     ESCAPE_STRINGS.put("&para", Character.valueOf('¶'));
/* 1043 */     ESCAPE_STRINGS.put("&middot", Character.valueOf('·'));
/* 1044 */     ESCAPE_STRINGS.put("&cedil", Character.valueOf('¸'));
/* 1045 */     ESCAPE_STRINGS.put("&sup1", Character.valueOf('¹'));
/* 1046 */     ESCAPE_STRINGS.put("&ordm", Character.valueOf('º'));
/* 1047 */     ESCAPE_STRINGS.put("&raquo", Character.valueOf('»'));
/* 1048 */     ESCAPE_STRINGS.put("&frac14", Character.valueOf('¼'));
/* 1049 */     ESCAPE_STRINGS.put("&frac12", Character.valueOf('½'));
/* 1050 */     ESCAPE_STRINGS.put("&frac34", Character.valueOf('¾'));
/* 1051 */     ESCAPE_STRINGS.put("&iquest", Character.valueOf('¿'));
/* 1052 */     ESCAPE_STRINGS.put("&Agrave", Character.valueOf('À'));
/* 1053 */     ESCAPE_STRINGS.put("&Aacute", Character.valueOf('Á'));
/* 1054 */     ESCAPE_STRINGS.put("&Acirc", Character.valueOf('Â'));
/* 1055 */     ESCAPE_STRINGS.put("&Atilde", Character.valueOf('Ã'));
/* 1056 */     ESCAPE_STRINGS.put("&Auml", Character.valueOf('Ä'));
/* 1057 */     ESCAPE_STRINGS.put("&Aring", Character.valueOf('Å'));
/* 1058 */     ESCAPE_STRINGS.put("&AElig", Character.valueOf('Æ'));
/* 1059 */     ESCAPE_STRINGS.put("&Ccedil", Character.valueOf('Ç'));
/* 1060 */     ESCAPE_STRINGS.put("&Egrave", Character.valueOf('È'));
/* 1061 */     ESCAPE_STRINGS.put("&Eacute", Character.valueOf('É'));
/* 1062 */     ESCAPE_STRINGS.put("&Ecirc", Character.valueOf('Ê'));
/* 1063 */     ESCAPE_STRINGS.put("&Euml", Character.valueOf('Ë'));
/* 1064 */     ESCAPE_STRINGS.put("&Igrave", Character.valueOf('Ì'));
/* 1065 */     ESCAPE_STRINGS.put("&Iacute", Character.valueOf('Í'));
/* 1066 */     ESCAPE_STRINGS.put("&Icirc", Character.valueOf('Î'));
/* 1067 */     ESCAPE_STRINGS.put("&Iuml", Character.valueOf('Ï'));
/* 1068 */     ESCAPE_STRINGS.put("&ETH", Character.valueOf('Ð'));
/* 1069 */     ESCAPE_STRINGS.put("&Ntilde", Character.valueOf('Ñ'));
/* 1070 */     ESCAPE_STRINGS.put("&Ograve", Character.valueOf('Ò'));
/* 1071 */     ESCAPE_STRINGS.put("&Oacute", Character.valueOf('Ó'));
/* 1072 */     ESCAPE_STRINGS.put("&Ocirc", Character.valueOf('Ô'));
/* 1073 */     ESCAPE_STRINGS.put("&Otilde", Character.valueOf('Õ'));
/* 1074 */     ESCAPE_STRINGS.put("&Ouml", Character.valueOf('Ö'));
/* 1075 */     ESCAPE_STRINGS.put("&times", Character.valueOf('×'));
/* 1076 */     ESCAPE_STRINGS.put("&Oslash", Character.valueOf('Ø'));
/* 1077 */     ESCAPE_STRINGS.put("&Ugrave", Character.valueOf('Ù'));
/* 1078 */     ESCAPE_STRINGS.put("&Uacute", Character.valueOf('Ú'));
/* 1079 */     ESCAPE_STRINGS.put("&Ucirc", Character.valueOf('Û'));
/* 1080 */     ESCAPE_STRINGS.put("&Uuml", Character.valueOf('Ü'));
/* 1081 */     ESCAPE_STRINGS.put("&Yacute", Character.valueOf('Ý'));
/* 1082 */     ESCAPE_STRINGS.put("&THORN", Character.valueOf('Þ'));
/* 1083 */     ESCAPE_STRINGS.put("&szlig", Character.valueOf('ß'));
/* 1084 */     ESCAPE_STRINGS.put("&agrave", Character.valueOf('à'));
/* 1085 */     ESCAPE_STRINGS.put("&aacute", Character.valueOf('á'));
/* 1086 */     ESCAPE_STRINGS.put("&acirc", Character.valueOf('â'));
/* 1087 */     ESCAPE_STRINGS.put("&atilde", Character.valueOf('ã'));
/* 1088 */     ESCAPE_STRINGS.put("&auml", Character.valueOf('ä'));
/* 1089 */     ESCAPE_STRINGS.put("&aring", Character.valueOf('å'));
/* 1090 */     ESCAPE_STRINGS.put("&aelig", Character.valueOf('æ'));
/* 1091 */     ESCAPE_STRINGS.put("&ccedil", Character.valueOf('ç'));
/* 1092 */     ESCAPE_STRINGS.put("&egrave", Character.valueOf('è'));
/* 1093 */     ESCAPE_STRINGS.put("&eacute", Character.valueOf('é'));
/* 1094 */     ESCAPE_STRINGS.put("&ecirc", Character.valueOf('ê'));
/* 1095 */     ESCAPE_STRINGS.put("&euml", Character.valueOf('ë'));
/* 1096 */     ESCAPE_STRINGS.put("&igrave", Character.valueOf('ì'));
/* 1097 */     ESCAPE_STRINGS.put("&iacute", Character.valueOf('í'));
/* 1098 */     ESCAPE_STRINGS.put("&icirc", Character.valueOf('î'));
/* 1099 */     ESCAPE_STRINGS.put("&iuml", Character.valueOf('ï'));
/* 1100 */     ESCAPE_STRINGS.put("&eth", Character.valueOf('ð'));
/* 1101 */     ESCAPE_STRINGS.put("&ntilde", Character.valueOf('ñ'));
/* 1102 */     ESCAPE_STRINGS.put("&ograve", Character.valueOf('ò'));
/* 1103 */     ESCAPE_STRINGS.put("&oacute", Character.valueOf('ó'));
/* 1104 */     ESCAPE_STRINGS.put("&ocirc", Character.valueOf('ô'));
/* 1105 */     ESCAPE_STRINGS.put("&otilde", Character.valueOf('õ'));
/* 1106 */     ESCAPE_STRINGS.put("&ouml", Character.valueOf('ö'));
/* 1107 */     ESCAPE_STRINGS.put("&divide", Character.valueOf('÷'));
/* 1108 */     ESCAPE_STRINGS.put("&oslash", Character.valueOf('ø'));
/* 1109 */     ESCAPE_STRINGS.put("&ugrave", Character.valueOf('ù'));
/* 1110 */     ESCAPE_STRINGS.put("&uacute", Character.valueOf('ú'));
/* 1111 */     ESCAPE_STRINGS.put("&ucirc", Character.valueOf('û'));
/* 1112 */     ESCAPE_STRINGS.put("&uuml", Character.valueOf('ü'));
/* 1113 */     ESCAPE_STRINGS.put("&yacute", Character.valueOf('ý'));
/* 1114 */     ESCAPE_STRINGS.put("&thorn", Character.valueOf('þ'));
/* 1115 */     ESCAPE_STRINGS.put("&yuml", Character.valueOf('ÿ'));
/* 1116 */     ESCAPE_STRINGS.put("&fnof", Character.valueOf('ƒ'));
/* 1117 */     ESCAPE_STRINGS.put("&Alpha", Character.valueOf('Α'));
/* 1118 */     ESCAPE_STRINGS.put("&Beta", Character.valueOf('Β'));
/* 1119 */     ESCAPE_STRINGS.put("&Gamma", Character.valueOf('Γ'));
/* 1120 */     ESCAPE_STRINGS.put("&Delta", Character.valueOf('Δ'));
/* 1121 */     ESCAPE_STRINGS.put("&Epsilon", Character.valueOf('Ε'));
/* 1122 */     ESCAPE_STRINGS.put("&Zeta", Character.valueOf('Ζ'));
/* 1123 */     ESCAPE_STRINGS.put("&Eta", Character.valueOf('Η'));
/* 1124 */     ESCAPE_STRINGS.put("&Theta", Character.valueOf('Θ'));
/* 1125 */     ESCAPE_STRINGS.put("&Iota", Character.valueOf('Ι'));
/* 1126 */     ESCAPE_STRINGS.put("&Kappa", Character.valueOf('Κ'));
/* 1127 */     ESCAPE_STRINGS.put("&Lambda", Character.valueOf('Λ'));
/* 1128 */     ESCAPE_STRINGS.put("&Mu", Character.valueOf('Μ'));
/* 1129 */     ESCAPE_STRINGS.put("&Nu", Character.valueOf('Ν'));
/* 1130 */     ESCAPE_STRINGS.put("&Xi", Character.valueOf('Ξ'));
/* 1131 */     ESCAPE_STRINGS.put("&Omicron", Character.valueOf('Ο'));
/* 1132 */     ESCAPE_STRINGS.put("&Pi", Character.valueOf('Π'));
/* 1133 */     ESCAPE_STRINGS.put("&Rho", Character.valueOf('Ρ'));
/* 1134 */     ESCAPE_STRINGS.put("&Sigma", Character.valueOf('Σ'));
/* 1135 */     ESCAPE_STRINGS.put("&Tau", Character.valueOf('Τ'));
/* 1136 */     ESCAPE_STRINGS.put("&Upsilon", Character.valueOf('Υ'));
/* 1137 */     ESCAPE_STRINGS.put("&Phi", Character.valueOf('Φ'));
/* 1138 */     ESCAPE_STRINGS.put("&Chi", Character.valueOf('Χ'));
/* 1139 */     ESCAPE_STRINGS.put("&Psi", Character.valueOf('Ψ'));
/* 1140 */     ESCAPE_STRINGS.put("&Omega", Character.valueOf('Ω'));
/* 1141 */     ESCAPE_STRINGS.put("&alpha", Character.valueOf('α'));
/* 1142 */     ESCAPE_STRINGS.put("&beta", Character.valueOf('β'));
/* 1143 */     ESCAPE_STRINGS.put("&gamma", Character.valueOf('γ'));
/* 1144 */     ESCAPE_STRINGS.put("&delta", Character.valueOf('δ'));
/* 1145 */     ESCAPE_STRINGS.put("&epsilon", Character.valueOf('ε'));
/* 1146 */     ESCAPE_STRINGS.put("&zeta", Character.valueOf('ζ'));
/* 1147 */     ESCAPE_STRINGS.put("&eta", Character.valueOf('η'));
/* 1148 */     ESCAPE_STRINGS.put("&theta", Character.valueOf('θ'));
/* 1149 */     ESCAPE_STRINGS.put("&iota", Character.valueOf('ι'));
/* 1150 */     ESCAPE_STRINGS.put("&kappa", Character.valueOf('κ'));
/* 1151 */     ESCAPE_STRINGS.put("&lambda", Character.valueOf('λ'));
/* 1152 */     ESCAPE_STRINGS.put("&mu", Character.valueOf('μ'));
/* 1153 */     ESCAPE_STRINGS.put("&nu", Character.valueOf('ν'));
/* 1154 */     ESCAPE_STRINGS.put("&xi", Character.valueOf('ξ'));
/* 1155 */     ESCAPE_STRINGS.put("&omicron", Character.valueOf('ο'));
/* 1156 */     ESCAPE_STRINGS.put("&pi", Character.valueOf('π'));
/* 1157 */     ESCAPE_STRINGS.put("&rho", Character.valueOf('ρ'));
/* 1158 */     ESCAPE_STRINGS.put("&sigmaf", Character.valueOf('ς'));
/* 1159 */     ESCAPE_STRINGS.put("&sigma", Character.valueOf('σ'));
/* 1160 */     ESCAPE_STRINGS.put("&tau", Character.valueOf('τ'));
/* 1161 */     ESCAPE_STRINGS.put("&upsilon", Character.valueOf('υ'));
/* 1162 */     ESCAPE_STRINGS.put("&phi", Character.valueOf('φ'));
/* 1163 */     ESCAPE_STRINGS.put("&chi", Character.valueOf('χ'));
/* 1164 */     ESCAPE_STRINGS.put("&psi", Character.valueOf('ψ'));
/* 1165 */     ESCAPE_STRINGS.put("&omega", Character.valueOf('ω'));
/* 1166 */     ESCAPE_STRINGS.put("&thetasym", Character.valueOf('ϑ'));
/* 1167 */     ESCAPE_STRINGS.put("&upsih", Character.valueOf('ϒ'));
/* 1168 */     ESCAPE_STRINGS.put("&piv", Character.valueOf('ϖ'));
/* 1169 */     ESCAPE_STRINGS.put("&bull", Character.valueOf('•'));
/* 1170 */     ESCAPE_STRINGS.put("&hellip", Character.valueOf('…'));
/* 1171 */     ESCAPE_STRINGS.put("&prime", Character.valueOf('′'));
/* 1172 */     ESCAPE_STRINGS.put("&Prime", Character.valueOf('″'));
/* 1173 */     ESCAPE_STRINGS.put("&oline", Character.valueOf('‾'));
/* 1174 */     ESCAPE_STRINGS.put("&frasl", Character.valueOf('⁄'));
/* 1175 */     ESCAPE_STRINGS.put("&weierp", Character.valueOf('℘'));
/* 1176 */     ESCAPE_STRINGS.put("&image", Character.valueOf('ℑ'));
/* 1177 */     ESCAPE_STRINGS.put("&real", Character.valueOf('ℜ'));
/* 1178 */     ESCAPE_STRINGS.put("&trade", Character.valueOf('™'));
/* 1179 */     ESCAPE_STRINGS.put("&alefsym", Character.valueOf('ℵ'));
/* 1180 */     ESCAPE_STRINGS.put("&larr", Character.valueOf('←'));
/* 1181 */     ESCAPE_STRINGS.put("&uarr", Character.valueOf('↑'));
/* 1182 */     ESCAPE_STRINGS.put("&rarr", Character.valueOf('→'));
/* 1183 */     ESCAPE_STRINGS.put("&darr", Character.valueOf('↓'));
/* 1184 */     ESCAPE_STRINGS.put("&harr", Character.valueOf('↔'));
/* 1185 */     ESCAPE_STRINGS.put("&crarr", Character.valueOf('↵'));
/* 1186 */     ESCAPE_STRINGS.put("&lArr", Character.valueOf('⇐'));
/* 1187 */     ESCAPE_STRINGS.put("&uArr", Character.valueOf('⇑'));
/* 1188 */     ESCAPE_STRINGS.put("&rArr", Character.valueOf('⇒'));
/* 1189 */     ESCAPE_STRINGS.put("&dArr", Character.valueOf('⇓'));
/* 1190 */     ESCAPE_STRINGS.put("&hArr", Character.valueOf('⇔'));
/* 1191 */     ESCAPE_STRINGS.put("&forall", Character.valueOf('∀'));
/* 1192 */     ESCAPE_STRINGS.put("&part", Character.valueOf('∂'));
/* 1193 */     ESCAPE_STRINGS.put("&exist", Character.valueOf('∃'));
/* 1194 */     ESCAPE_STRINGS.put("&empty", Character.valueOf('∅'));
/* 1195 */     ESCAPE_STRINGS.put("&nabla", Character.valueOf('∇'));
/* 1196 */     ESCAPE_STRINGS.put("&isin", Character.valueOf('∈'));
/* 1197 */     ESCAPE_STRINGS.put("&notin", Character.valueOf('∉'));
/* 1198 */     ESCAPE_STRINGS.put("&ni", Character.valueOf('∋'));
/* 1199 */     ESCAPE_STRINGS.put("&prod", Character.valueOf('∏'));
/* 1200 */     ESCAPE_STRINGS.put("&sum", Character.valueOf('∑'));
/* 1201 */     ESCAPE_STRINGS.put("&minus", Character.valueOf('−'));
/* 1202 */     ESCAPE_STRINGS.put("&lowast", Character.valueOf('∗'));
/* 1203 */     ESCAPE_STRINGS.put("&radic", Character.valueOf('√'));
/* 1204 */     ESCAPE_STRINGS.put("&prop", Character.valueOf('∝'));
/* 1205 */     ESCAPE_STRINGS.put("&infin", Character.valueOf('∞'));
/* 1206 */     ESCAPE_STRINGS.put("&ang", Character.valueOf('∠'));
/* 1207 */     ESCAPE_STRINGS.put("&and", Character.valueOf('∧'));
/* 1208 */     ESCAPE_STRINGS.put("&or", Character.valueOf('∨'));
/* 1209 */     ESCAPE_STRINGS.put("&cap", Character.valueOf('∩'));
/* 1210 */     ESCAPE_STRINGS.put("&cup", Character.valueOf('∪'));
/* 1211 */     ESCAPE_STRINGS.put("&int", Character.valueOf('∫'));
/* 1212 */     ESCAPE_STRINGS.put("&there4", Character.valueOf('∴'));
/* 1213 */     ESCAPE_STRINGS.put("&sim", Character.valueOf('∼'));
/* 1214 */     ESCAPE_STRINGS.put("&cong", Character.valueOf('≅'));
/* 1215 */     ESCAPE_STRINGS.put("&asymp", Character.valueOf('≈'));
/* 1216 */     ESCAPE_STRINGS.put("&ne", Character.valueOf('≠'));
/* 1217 */     ESCAPE_STRINGS.put("&equiv", Character.valueOf('≡'));
/* 1218 */     ESCAPE_STRINGS.put("&le", Character.valueOf('≤'));
/* 1219 */     ESCAPE_STRINGS.put("&ge", Character.valueOf('≥'));
/* 1220 */     ESCAPE_STRINGS.put("&sub", Character.valueOf('⊂'));
/* 1221 */     ESCAPE_STRINGS.put("&sup", Character.valueOf('⊃'));
/* 1222 */     ESCAPE_STRINGS.put("&nsub", Character.valueOf('⊄'));
/* 1223 */     ESCAPE_STRINGS.put("&sube", Character.valueOf('⊆'));
/* 1224 */     ESCAPE_STRINGS.put("&supe", Character.valueOf('⊇'));
/* 1225 */     ESCAPE_STRINGS.put("&oplus", Character.valueOf('⊕'));
/* 1226 */     ESCAPE_STRINGS.put("&otimes", Character.valueOf('⊗'));
/* 1227 */     ESCAPE_STRINGS.put("&perp", Character.valueOf('⊥'));
/* 1228 */     ESCAPE_STRINGS.put("&sdot", Character.valueOf('⋅'));
/* 1229 */     ESCAPE_STRINGS.put("&lceil", Character.valueOf('⌈'));
/* 1230 */     ESCAPE_STRINGS.put("&rceil", Character.valueOf('⌉'));
/* 1231 */     ESCAPE_STRINGS.put("&lfloor", Character.valueOf('⌊'));
/* 1232 */     ESCAPE_STRINGS.put("&rfloor", Character.valueOf('⌋'));
/* 1233 */     ESCAPE_STRINGS.put("&lang", Character.valueOf('〈'));
/* 1234 */     ESCAPE_STRINGS.put("&rang", Character.valueOf('〉'));
/* 1235 */     ESCAPE_STRINGS.put("&loz", Character.valueOf('◊'));
/* 1236 */     ESCAPE_STRINGS.put("&spades", Character.valueOf('♠'));
/* 1237 */     ESCAPE_STRINGS.put("&clubs", Character.valueOf('♣'));
/* 1238 */     ESCAPE_STRINGS.put("&hearts", Character.valueOf('♥'));
/* 1239 */     ESCAPE_STRINGS.put("&diams", Character.valueOf('♦'));
/* 1240 */     ESCAPE_STRINGS.put("&quot", Character.valueOf('"'));
/* 1241 */     ESCAPE_STRINGS.put("&amp", Character.valueOf('&'));
/* 1242 */     ESCAPE_STRINGS.put("&lt", Character.valueOf('<'));
/* 1243 */     ESCAPE_STRINGS.put("&gt", Character.valueOf('>'));
/* 1244 */     ESCAPE_STRINGS.put("&OElig", Character.valueOf('Œ'));
/* 1245 */     ESCAPE_STRINGS.put("&oelig", Character.valueOf('œ'));
/* 1246 */     ESCAPE_STRINGS.put("&Scaron", Character.valueOf('Š'));
/* 1247 */     ESCAPE_STRINGS.put("&scaron", Character.valueOf('š'));
/* 1248 */     ESCAPE_STRINGS.put("&Yuml", Character.valueOf('Ÿ'));
/* 1249 */     ESCAPE_STRINGS.put("&circ", Character.valueOf('ˆ'));
/* 1250 */     ESCAPE_STRINGS.put("&tilde", Character.valueOf('˜'));
/* 1251 */     ESCAPE_STRINGS.put("&ensp", Character.valueOf(' '));
/* 1252 */     ESCAPE_STRINGS.put("&emsp", Character.valueOf(' '));
/* 1253 */     ESCAPE_STRINGS.put("&thinsp", Character.valueOf(' '));
/* 1254 */     ESCAPE_STRINGS.put("&zwnj", Character.valueOf('‌'));
/* 1255 */     ESCAPE_STRINGS.put("&zwj", Character.valueOf('‍'));
/* 1256 */     ESCAPE_STRINGS.put("&lrm", Character.valueOf('‎'));
/* 1257 */     ESCAPE_STRINGS.put("&rlm", Character.valueOf('‏'));
/* 1258 */     ESCAPE_STRINGS.put("&ndash", Character.valueOf('–'));
/* 1259 */     ESCAPE_STRINGS.put("&mdash", Character.valueOf('—'));
/* 1260 */     ESCAPE_STRINGS.put("&lsquo", Character.valueOf('‘'));
/* 1261 */     ESCAPE_STRINGS.put("&rsquo", Character.valueOf('’'));
/* 1262 */     ESCAPE_STRINGS.put("&sbquo", Character.valueOf('‚'));
/* 1263 */     ESCAPE_STRINGS.put("&ldquo", Character.valueOf('“'));
/* 1264 */     ESCAPE_STRINGS.put("&rdquo", Character.valueOf('”'));
/* 1265 */     ESCAPE_STRINGS.put("&bdquo", Character.valueOf('„'));
/* 1266 */     ESCAPE_STRINGS.put("&dagger", Character.valueOf('†'));
/* 1267 */     ESCAPE_STRINGS.put("&Dagger", Character.valueOf('‡'));
/* 1268 */     ESCAPE_STRINGS.put("&permil", Character.valueOf('‰'));
/* 1269 */     ESCAPE_STRINGS.put("&lsaquo", Character.valueOf('‹'));
/* 1270 */     ESCAPE_STRINGS.put("&rsaquo", Character.valueOf('›'));
/* 1271 */     ESCAPE_STRINGS.put("&euro", Character.valueOf('€'));
/*      */ 
/* 1273 */     HEX_LETTERS = new HashSet(12);
/*      */ 
/* 1275 */     HEX_LETTERS.add(Character.valueOf('a'));
/* 1276 */     HEX_LETTERS.add(Character.valueOf('A'));
/* 1277 */     HEX_LETTERS.add(Character.valueOf('b'));
/* 1278 */     HEX_LETTERS.add(Character.valueOf('B'));
/* 1279 */     HEX_LETTERS.add(Character.valueOf('c'));
/* 1280 */     HEX_LETTERS.add(Character.valueOf('C'));
/* 1281 */     HEX_LETTERS.add(Character.valueOf('d'));
/* 1282 */     HEX_LETTERS.add(Character.valueOf('D'));
/* 1283 */     HEX_LETTERS.add(Character.valueOf('e'));
/* 1284 */     HEX_LETTERS.add(Character.valueOf('E'));
/* 1285 */     HEX_LETTERS.add(Character.valueOf('f'));
/* 1286 */     HEX_LETTERS.add(Character.valueOf('F'));
/*      */ 
/* 1426 */     LT_GT_ESCAPE = new CharEscaperBuilder().addEscape('<', "&lt;").addEscape('>', "&gt;").toEscaper();
/*      */ 
/* 1432 */     htmlTagPattern = Pattern.compile("</?[a-zA-Z][^>]*>");
/*      */ 
/* 1770 */     CONTROL_MATCHER = CharMatcher.anyOf("");
/*      */ 
/* 1825 */     JAVA_ESCAPE = new CharEscaperBuilder().addEscape('\n', "\\n").addEscape('\r', "\\r").addEscape('\t', "\\t").addEscape('\\', "\\\\").addEscape('"', "\\\"").addEscape('&', "&amp;").addEscape('<', "&lt;").addEscape('>', "&gt;").addEscape('\'', "\\'").toEscaper();
/*      */ 
/* 1852 */     REGEX_ESCAPE = new CharEscaperBuilder().addEscape('(', "\\(").addEscape(')', "\\)").addEscape('|', "\\|").addEscape('*', "\\*").addEscape('+', "\\+").addEscape('?', "\\?").addEscape('.', "\\.").addEscape('{', "\\{").addEscape('}', "\\}").addEscape('[', "\\[").addEscape(']', "\\]").addEscape('$', "\\$").addEscape('^', "\\^").addEscape('\\', "\\\\").toEscaper();
/*      */ 
/* 2366 */     characterReferencePattern = Pattern.compile("&#?[a-zA-Z0-9]{1,8};");
/*      */ 
/* 2418 */     Set set = new HashSet();
/* 2419 */     set.add(Character.UnicodeBlock.HANGUL_JAMO);
/* 2420 */     set.add(Character.UnicodeBlock.CJK_RADICALS_SUPPLEMENT);
/* 2421 */     set.add(Character.UnicodeBlock.KANGXI_RADICALS);
/* 2422 */     set.add(Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION);
/* 2423 */     set.add(Character.UnicodeBlock.HIRAGANA);
/* 2424 */     set.add(Character.UnicodeBlock.KATAKANA);
/* 2425 */     set.add(Character.UnicodeBlock.BOPOMOFO);
/* 2426 */     set.add(Character.UnicodeBlock.HANGUL_COMPATIBILITY_JAMO);
/* 2427 */     set.add(Character.UnicodeBlock.KANBUN);
/* 2428 */     set.add(Character.UnicodeBlock.BOPOMOFO_EXTENDED);
/* 2429 */     set.add(Character.UnicodeBlock.KATAKANA_PHONETIC_EXTENSIONS);
/* 2430 */     set.add(Character.UnicodeBlock.ENCLOSED_CJK_LETTERS_AND_MONTHS);
/* 2431 */     set.add(Character.UnicodeBlock.CJK_COMPATIBILITY);
/* 2432 */     set.add(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A);
/* 2433 */     set.add(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS);
/* 2434 */     set.add(Character.UnicodeBlock.HANGUL_SYLLABLES);
/* 2435 */     set.add(Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS);
/* 2436 */     set.add(Character.UnicodeBlock.CJK_COMPATIBILITY_FORMS);
/* 2437 */     set.add(Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS);
/* 2438 */     set.add(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B);
/* 2439 */     set.add(Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT);
/* 2440 */     CJK_BLOCKS = Collections.unmodifiableSet(set);
/*      */ 
/* 2695 */     HEX_CHARS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*      */ 
/* 2698 */     OCTAL_CHARS = HEX_CHARS;
/*      */ 
/* 2780 */     dbSpecPattern = Pattern.compile("(.*)\\{(\\d+),(\\d+)\\}(.*)");
/*      */ 
/* 3202 */     JS_ESCAPE_CHARS = new UnicodeSetBuilder(null).addCodePoint(173).addRange(1536, 1539).addCodePoint(1757).addCodePoint(1807).addRange(6068, 6069).addRange(8203, 8207).addRange(8234, 8238).addRange(8288, 8292).addRange(8298, 8303).addCodePoint(65279).addRange(65529, 65531).addRange(119155, 119162).addCodePoint(917505).addRange(917536, 917631).addCodePoint(0).addCodePoint(10).addCodePoint(13).addRange(8232, 8233).addCodePoint(133).addCodePoint(Character.codePointAt("'", 0)).addCodePoint(Character.codePointAt("\"", 0)).addCodePoint(Character.codePointAt("&", 0)).addCodePoint(Character.codePointAt("<", 0)).addCodePoint(Character.codePointAt(">", 0)).addCodePoint(Character.codePointAt("=", 0)).addCodePoint(Character.codePointAt("\\", 0)).create();
/*      */ 
/* 3234 */     JSON_ESCAPE_CHARS = new UnicodeSetBuilder(null).addCodePoint(Character.codePointAt("\"", 0)).addCodePoint(Character.codePointAt("\\", 0)).addRange(0, 31).create();
/*      */   }
/*      */ 
/*      */   private static class UnicodeSetBuilder
/*      */   {
/* 3183 */     Set<Integer> codePointSet = new HashSet();
/*      */ 
/*      */     UnicodeSetBuilder addCodePoint(int c) {
/* 3186 */       this.codePointSet.add(Integer.valueOf(c));
/* 3187 */       return this;
/*      */     }
/*      */ 
/*      */     UnicodeSetBuilder addRange(int from, int to) {
/* 3191 */       for (int i = from; i <= to; i++) {
/* 3192 */         this.codePointSet.add(Integer.valueOf(i));
/*      */       }
/* 3194 */       return this;
/*      */     }
/*      */ 
/*      */     Set<Integer> create() {
/* 3198 */       return this.codePointSet;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static enum JsEscapingMode
/*      */   {
/* 1482 */     JSON, 
/*      */ 
/* 1485 */     EMBEDDABLE_JS, 
/*      */ 
/* 1488 */     MINIMAL_JS;
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.StringUtil
 * JD-Core Version:    0.6.0
 */