/*     */ package com.google.appengine.repackaged.com.google.io.protocol;
/*     */ 
/*     */ public final class ProtocolSink
/*     */ {
/*     */   private final byte[] buf;
/*     */   private int pos;
/*     */ 
/*     */   public ProtocolSink(byte[] array, int offset)
/*     */   {
/*  25 */     this.buf = array;
/*  26 */     this.pos = offset;
/*     */   }
/*     */ 
/*     */   public ProtocolSink(byte[] array)
/*     */   {
/*  35 */     this(array, 0);
/*     */   }
/*     */ 
/*     */   public ProtocolSink(int size)
/*     */   {
/*  44 */     this(new byte[size], 0);
/*     */   }
/*     */ 
/*     */   final void reset()
/*     */   {
/*  52 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   public final int position()
/*     */   {
/*  59 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public final void skip(int n)
/*     */   {
/*  68 */     this.pos += n;
/*     */   }
/*     */ 
/*     */   public final byte[] array()
/*     */   {
/*  77 */     return this.buf;
/*     */   }
/*     */ 
/*     */   public final byte[] toArray()
/*     */   {
/*  85 */     byte[] copy = new byte[this.pos];
/*  86 */     System.arraycopy(this.buf, 0, copy, 0, this.pos);
/*  87 */     return copy;
/*     */   }
/*     */ 
/*     */   public final void putBytes(byte[] src, int offset, int length)
/*     */   {
/* 101 */     System.arraycopy(src, offset, this.buf, this.pos, length);
/* 102 */     this.pos += length;
/*     */   }
/*     */ 
/*     */   public final void putBytes(byte[] src)
/*     */   {
/* 114 */     putBytes(src, 0, src.length);
/*     */   }
/*     */ 
/*     */   public final void putByte(byte v)
/*     */   {
/* 126 */     this.buf[(this.pos++)] = v;
/*     */   }
/*     */ 
/*     */   public final void putShort(short v)
/*     */   {
/* 138 */     this.buf[(this.pos++)] = (byte)v;
/* 139 */     this.buf[(this.pos++)] = (byte)(v >> 8);
/*     */   }
/*     */ 
/*     */   public final void putInt(int v)
/*     */   {
/* 151 */     this.buf[(this.pos++)] = (byte)v;
/* 152 */     this.buf[(this.pos++)] = (byte)(v >> 8);
/* 153 */     this.buf[(this.pos++)] = (byte)(v >> 16);
/* 154 */     this.buf[(this.pos++)] = (byte)(v >> 24);
/*     */   }
/*     */ 
/*     */   public final void putLong(long v)
/*     */   {
/* 166 */     this.buf[(this.pos++)] = (byte)(int)v;
/* 167 */     this.buf[(this.pos++)] = (byte)(int)(v >> 8);
/* 168 */     this.buf[(this.pos++)] = (byte)(int)(v >> 16);
/* 169 */     this.buf[(this.pos++)] = (byte)(int)(v >> 24);
/* 170 */     this.buf[(this.pos++)] = (byte)(int)(v >> 32);
/* 171 */     this.buf[(this.pos++)] = (byte)(int)(v >> 40);
/* 172 */     this.buf[(this.pos++)] = (byte)(int)(v >> 48);
/* 173 */     this.buf[(this.pos++)] = (byte)(int)(v >> 56);
/*     */   }
/*     */ 
/*     */   public final void putVarInt(int v)
/*     */   {
/*     */     while (true)
/*     */     {
/* 187 */       int bits = v & 0x7F;
/* 188 */       v >>>= 7;
/* 189 */       if (v == 0) {
/* 190 */         putByte((byte)bits);
/* 191 */         return;
/*     */       }
/* 193 */       putByte((byte)(bits | 0x80));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void putVarLong(long v)
/*     */   {
/*     */     while (true)
/*     */     {
/* 208 */       int bits = (int)v & 0x7F;
/* 209 */       v >>>= 7;
/* 210 */       if (v == 0L) {
/* 211 */         putByte((byte)bits);
/* 212 */         return;
/*     */       }
/* 214 */       putByte((byte)(bits | 0x80));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void putVarLong(int v)
/*     */   {
/* 226 */     for (int i = 0; i < 4; i++) {
/* 227 */       int bits = v & 0x7F;
/* 228 */       v >>= 7;
/* 229 */       if (v == 0) {
/* 230 */         putByte((byte)bits);
/* 231 */         return;
/*     */       }
/* 233 */       putByte((byte)(bits | 0x80));
/*     */     }
/*     */ 
/* 237 */     assert ((-128 <= v) && (v <= 15));
/* 238 */     if (v >= 0) {
/* 239 */       putByte((byte)v);
/*     */     } else {
/* 241 */       putByte((byte)(v | 0xF0));
/* 242 */       putByte(-1);
/* 243 */       putByte(-1);
/* 244 */       putByte(-1);
/* 245 */       putByte(-1);
/* 246 */       putByte(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void putBoolean(boolean v)
/*     */   {
/* 259 */     if (v)
/* 260 */       putByte(1);
/*     */     else
/* 262 */       putByte(0);
/*     */   }
/*     */ 
/*     */   public final void putFloat(float v)
/*     */   {
/* 276 */     putInt(Float.floatToIntBits(v));
/*     */   }
/*     */ 
/*     */   public final void putDouble(double v)
/*     */   {
/* 289 */     putLong(Double.doubleToLongBits(v));
/*     */   }
/*     */ 
/*     */   public final void putPrefixedData(byte[] v)
/*     */   {
/* 301 */     putVarInt(v.length);
/* 302 */     putBytes(v, 0, v.length);
/*     */   }
/*     */ 
/*     */   public final void putForeign(ProtocolMessage message)
/*     */   {
/* 328 */     int lengthPosition = this.pos;
/* 329 */     int startPosition = ++this.pos;
/* 330 */     message.outputTo(this);
/* 331 */     int endPosition = this.pos;
/* 332 */     int length = endPosition - startPosition;
/* 333 */     if (length < 128)
/*     */     {
/* 335 */       this.buf[lengthPosition] = (byte)length;
/*     */     }
/*     */     else {
/* 338 */       int extra = Protocol.varIntSize(length >> 7);
/* 339 */       System.arraycopy(this.buf, startPosition, this.buf, startPosition + extra, length);
/*     */ 
/* 341 */       this.pos = lengthPosition;
/* 342 */       putVarInt(length);
/*     */ 
/* 344 */       this.pos = (endPosition + extra);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink
 * JD-Core Version:    0.6.0
 */