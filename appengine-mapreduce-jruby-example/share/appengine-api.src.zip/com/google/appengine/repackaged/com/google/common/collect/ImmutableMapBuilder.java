/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public class ImmutableMapBuilder<K, V>
/*     */ {
/*     */   private ImmutableHashMap<K, V> map;
/*     */ 
/*     */   public static <K, V> ImmutableMapBuilder<K, V> fromMap(Map<K, V> map)
/*     */   {
/*  70 */     ImmutableMapBuilder builder = new ImmutableMapBuilder(map.size() * 3 / 2);
/*     */ 
/*  72 */     for (Map.Entry entry : map.entrySet()) {
/*  73 */       builder.put(entry.getKey(), entry.getValue());
/*     */     }
/*     */ 
/*  76 */     return builder;
/*     */   }
/*     */ 
/*     */   public ImmutableMapBuilder()
/*     */   {
/*  81 */     this(8);
/*     */   }
/*     */ 
/*     */   public ImmutableMapBuilder(int expectedSize)
/*     */   {
/*  91 */     this.map = new ImmutableHashMap(expectedSize);
/*     */   }
/*     */ 
/*     */   public ImmutableMapBuilder<K, V> put(@Nullable K key, @Nullable V value)
/*     */   {
/* 104 */     Preconditions.checkState(this.map != null, "map has already been created");
/* 105 */     this.map.secretPut(key, value);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   public Map<K, V> getMap()
/*     */   {
/* 117 */     Preconditions.checkState(this.map != null, "map has already been created");
/*     */     try {
/* 119 */       ImmutableHashMap localImmutableHashMap = this.map;
/*     */       return localImmutableHashMap; } finally { this.map = null; } throw localObject; } 
/*     */   private static class ImmutableHashMap<K, V> extends HashMap<K, V> { volatile transient Set<K> keySet;
/*     */     volatile transient Collection<V> values;
/*     */     volatile transient Set<Map.Entry<K, V>> entrySet;
/*     */     transient Integer cachedHashCode;
/*     */     private static final long serialVersionUID = -5187626034923451074L;
/*     */ 
/* 128 */     ImmutableHashMap(int expectedSize) { super();
/*     */     }
/*     */ 
/*     */     public Set<K> keySet()
/*     */     {
/* 134 */       if (this.keySet == null) {
/* 135 */         this.keySet = Collections.unmodifiableSet(super.keySet());
/*     */       }
/* 137 */       return this.keySet;
/*     */     }
/*     */ 
/*     */     public Collection<V> values()
/*     */     {
/* 143 */       if (this.values == null) {
/* 144 */         this.values = Collections.unmodifiableCollection(super.values());
/*     */       }
/* 146 */       return this.values;
/*     */     }
/*     */ 
/*     */     public Set<Map.Entry<K, V>> entrySet()
/*     */     {
/* 152 */       if (this.entrySet == null) {
/* 153 */         this.entrySet = Maps.unmodifiableEntrySet(super.entrySet());
/*     */       }
/* 155 */       return this.entrySet;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 171 */       Integer code = this.cachedHashCode;
/* 172 */       if (code == null) {
/* 173 */         int computed = super.hashCode();
/* 174 */         this.cachedHashCode = Integer.valueOf(computed);
/* 175 */         return computed;
/*     */       }
/* 177 */       return code.intValue();
/*     */     }
/*     */ 
/*     */     private void secretPut(K key, V value) {
/* 181 */       super.put(key, value);
/*     */     }
/*     */ 
/*     */     public V put(K key, V value) {
/* 185 */       throw up();
/*     */     }
/*     */     public void putAll(Map<? extends K, ? extends V> m) {
/* 188 */       throw up();
/*     */     }
/*     */     public V remove(Object key) {
/* 191 */       throw up();
/*     */     }
/*     */     public void clear() {
/* 194 */       throw up();
/*     */     }
/*     */ 
/*     */     static UnsupportedOperationException up() {
/* 198 */       return new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableMapBuilder
 * JD-Core Version:    0.6.0
 */