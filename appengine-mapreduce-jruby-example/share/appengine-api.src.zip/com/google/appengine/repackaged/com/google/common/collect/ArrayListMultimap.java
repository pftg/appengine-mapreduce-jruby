/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import com.google.common.annotations.GwtIncompatible;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ @GwtCompatible(serializable=true)
/*     */ public final class ArrayListMultimap<K, V> extends AbstractListMultimap<K, V>
/*     */ {
/*     */   private static final int DEFAULT_VALUES_PER_KEY = 10;
/*     */ 
/*     */   @VisibleForTesting
/*     */   transient int expectedValuesPerKey;
/*     */ 
/*     */   @GwtIncompatible("Not needed in emulated source.")
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   public static <K, V> ArrayListMultimap<K, V> create()
/*     */   {
/*  74 */     return new ArrayListMultimap();
/*     */   }
/*     */ 
/*     */   public static <K, V> ArrayListMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*     */   {
/*  88 */     return new ArrayListMultimap(expectedKeys, expectedValuesPerKey);
/*     */   }
/*     */ 
/*     */   public static <K, V> ArrayListMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*     */   {
/*  99 */     return new ArrayListMultimap(multimap);
/*     */   }
/*     */ 
/*     */   private ArrayListMultimap() {
/* 103 */     super(new HashMap());
/* 104 */     this.expectedValuesPerKey = 10;
/*     */   }
/*     */ 
/*     */   private ArrayListMultimap(int expectedKeys, int expectedValuesPerKey) {
/* 108 */     super(Maps.newHashMapWithExpectedSize(expectedKeys));
/* 109 */     Preconditions.checkArgument(expectedValuesPerKey >= 0);
/* 110 */     this.expectedValuesPerKey = expectedValuesPerKey;
/*     */   }
/*     */ 
/*     */   private ArrayListMultimap(Multimap<? extends K, ? extends V> multimap) {
/* 114 */     this(multimap.keySet().size(), (multimap instanceof ArrayListMultimap) ? ((ArrayListMultimap)multimap).expectedValuesPerKey : 10);
/*     */ 
/* 118 */     putAll(multimap);
/*     */   }
/*     */ 
/*     */   List<V> createCollection()
/*     */   {
/* 126 */     return new ArrayList(this.expectedValuesPerKey);
/*     */   }
/*     */ 
/*     */   public void trimToSize()
/*     */   {
/* 133 */     for (Collection collection : backingMap().values()) {
/* 134 */       ArrayList arrayList = (ArrayList)collection;
/* 135 */       arrayList.trimToSize();
/*     */     }
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 146 */     stream.defaultWriteObject();
/* 147 */     stream.writeInt(this.expectedValuesPerKey);
/* 148 */     Serialization.writeMultimap(this, stream);
/*     */   }
/*     */ 
/*     */   @GwtIncompatible("java.io.ObjectOutputStream")
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 154 */     stream.defaultReadObject();
/* 155 */     this.expectedValuesPerKey = stream.readInt();
/* 156 */     int distinctKeys = Serialization.readCount(stream);
/* 157 */     Map map = Maps.newHashMapWithExpectedSize(distinctKeys);
/* 158 */     setMap(map);
/* 159 */     Serialization.populateMultimap(this, stream, distinctKeys);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ArrayListMultimap
 * JD-Core Version:    0.6.0
 */