/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ abstract class TransactionRunner
/*    */ {
/*    */   private final Transaction txn;
/*    */   private final boolean finishTxn;
/*    */ 
/*    */   protected TransactionRunner(Transaction txn, boolean finishTxn)
/*    */   {
/* 16 */     if ((txn == null) && (finishTxn)) {
/* 17 */       throw new IllegalArgumentException("Cannot have a null txn when finishTxn is true.  This almost certainly represents a programming error on the part of the App Engine team.  Please report this via standard support channels and accept our humblest apologies.");
/*    */     }
/*    */ 
/* 21 */     TransactionImpl.ensureTxnActive(txn);
/* 22 */     this.txn = txn;
/* 23 */     this.finishTxn = finishTxn;
/*    */   }
/*    */ 
/*    */   public void runInTransaction()
/*    */   {
/* 28 */     boolean success = false;
/*    */     try {
/* 30 */       run();
/* 31 */       success = true;
/*    */     } finally {
/* 33 */       if (this.finishTxn)
/* 34 */         if (success) {
/* 35 */           this.txn.commit();
/*    */         }
/*    */         else
/*    */         {
/* 39 */           this.txn.rollback();
/*    */         }
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract void run();
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.TransactionRunner
 * JD-Core Version:    0.6.0
 */