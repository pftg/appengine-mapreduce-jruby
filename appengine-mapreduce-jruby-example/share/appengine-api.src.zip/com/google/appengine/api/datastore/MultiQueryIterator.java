/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Stack;
/*     */ 
/*     */ class MultiQueryIterator
/*     */   implements Iterator<List<Query>>
/*     */ {
/*     */   private final MultiQueryBuilder multiQueryBuilder;
/*     */   private final List<Integer> componentSubIndex;
/*  25 */   private final Stack<List<Query.FilterPredicate>> filtersStack = new Stack();
/*  26 */   private int componentIndex = 0;
/*  27 */   private int parallelCount = 0;
/*     */ 
/*  29 */   private boolean moreResults = true;
/*     */ 
/*     */   public MultiQueryIterator(MultiQueryBuilder multiQueryBuilder) {
/*  32 */     this.componentSubIndex = new ArrayList(multiQueryBuilder.components.size());
/*  33 */     for (MultiQueryComponent component : multiQueryBuilder.components) {
/*  34 */       this.componentSubIndex.add(Integer.valueOf(0));
/*     */     }
/*  36 */     this.filtersStack.push(multiQueryBuilder.baseQuery.getFilterPredicates());
/*  37 */     this.multiQueryBuilder = multiQueryBuilder;
/*     */   }
/*     */ 
/*     */   private void pushFilters(List<Query.FilterPredicate> componentFilters)
/*     */   {
/*  47 */     List baseFilters = (List)this.filtersStack.peek();
/*  48 */     List filters = new ArrayList(baseFilters.size() + componentFilters.size());
/*     */ 
/*  50 */     filters.addAll(baseFilters);
/*  51 */     filters.addAll(componentFilters);
/*  52 */     this.filtersStack.push(filters);
/*     */   }
/*     */ 
/*     */   private boolean advanceSerialComponents()
/*     */   {
/*  62 */     for (int i = this.multiQueryBuilder.components.size() - 1; i >= 0; i--) {
/*  63 */       MultiQueryComponent component = (MultiQueryComponent)this.multiQueryBuilder.components.get(i);
/*  64 */       if (component.getOrder() != MultiQueryComponent.Order.PARALLEL) {
/*  65 */         boolean isLastFilter = ((Integer)this.componentSubIndex.get(i)).intValue() + 1 == component.getFilters().size();
/*  66 */         if (isLastFilter) {
/*  67 */           this.componentSubIndex.set(i, Integer.valueOf(0));
/*     */         } else {
/*  69 */           this.componentSubIndex.set(i, Integer.valueOf(((Integer)this.componentSubIndex.get(i)).intValue() + 1));
/*  70 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   private void buildNextResult(List<Query> result, int minIndex)
/*     */   {
/*  85 */     while (this.componentIndex >= minIndex) {
/*  86 */       if (this.componentIndex >= this.multiQueryBuilder.components.size())
/*     */       {
/*  88 */         result.add(MultiQueryBuilder.cloneQueryWithFilters(this.multiQueryBuilder.baseQuery, (List)this.filtersStack.peek()));
/*     */ 
/*  91 */         this.componentIndex -= 1;
/*  92 */         continue;
/*     */       }
/*     */ 
/*  95 */       MultiQueryComponent component = (MultiQueryComponent)this.multiQueryBuilder.components.get(this.componentIndex);
/*  96 */       if (component.getOrder() == MultiQueryComponent.Order.PARALLEL)
/*     */       {
/*  99 */         this.parallelCount += 1;
/* 100 */         this.componentIndex += 1;
/*     */ 
/* 102 */         for (List componentFilters : component.getFilters())
/*     */         {
/* 105 */           pushFilters(componentFilters);
/* 106 */           buildNextResult(result, this.componentIndex);
/* 107 */           this.filtersStack.pop();
/*     */         }
/*     */ 
/* 111 */         this.parallelCount -= 1;
/* 112 */         this.componentIndex -= 2;
/*     */       }
/* 114 */       else if (this.filtersStack.size() <= this.componentIndex + 1)
/*     */       {
/* 116 */         pushFilters((List)component.getFilters().get(((Integer)this.componentSubIndex.get(this.componentIndex)).intValue()));
/* 117 */         this.componentIndex += 1;
/*     */       }
/*     */       else {
/* 120 */         this.filtersStack.pop();
/* 121 */         boolean isLastFilter = ((Integer)this.componentSubIndex.get(this.componentIndex)).intValue() + 1 == component.getFilters().size();
/*     */ 
/* 124 */         this.componentIndex -= 1;
/*     */ 
/* 128 */         if ((this.parallelCount == 0) && (!isLastFilter))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 135 */     this.componentIndex += 1;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 140 */     return this.moreResults;
/*     */   }
/*     */ 
/*     */   public List<Query> next()
/*     */   {
/* 145 */     if (!this.moreResults) {
/* 146 */       throw new NoSuchElementException();
/*     */     }
/* 148 */     List result = new ArrayList();
/* 149 */     buildNextResult(result, 0);
/* 150 */     this.moreResults = advanceSerialComponents();
/* 151 */     return result;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */   {
/* 156 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.MultiQueryIterator
 * JD-Core Version:    0.6.0
 */