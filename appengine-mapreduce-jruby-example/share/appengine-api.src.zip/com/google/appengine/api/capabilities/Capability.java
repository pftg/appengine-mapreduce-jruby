/*    */ package com.google.appengine.api.capabilities;
/*    */ 
/*    */ public class Capability
/*    */ {
/* 17 */   public static final Capability BLOBSTORE = new Capability("blobstore");
/*    */ 
/* 21 */   public static final Capability DATASTORE = new Capability("datastore_v3");
/*    */ 
/* 25 */   public static final Capability DATASTORE_WRITE = new Capability("datastore_v3", "write");
/*    */ 
/* 29 */   public static final Capability IMAGES = new Capability("images");
/*    */ 
/* 33 */   public static final Capability MAIL = new Capability("mail");
/*    */ 
/* 37 */   public static final Capability MEMCACHE = new Capability("memcache");
/*    */ 
/* 41 */   public static final Capability TASKQUEUE = new Capability("taskqueue");
/*    */ 
/* 45 */   public static final Capability URL_FETCH = new Capability("urlfetch");
/*    */ 
/* 49 */   public static final Capability XMPP = new Capability("xmpp");
/*    */   private final String packageName;
/*    */   private final String name;
/*    */ 
/*    */   public Capability(String packageName)
/*    */   {
/* 62 */     this(packageName, "*");
/*    */   }
/*    */ 
/*    */   public Capability(String packageName, String name)
/*    */   {
/* 72 */     this.packageName = packageName;
/* 73 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getPackageName()
/*    */   {
/* 82 */     return this.packageName;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 91 */     return this.name;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.Capability
 * JD-Core Version:    0.6.0
 */