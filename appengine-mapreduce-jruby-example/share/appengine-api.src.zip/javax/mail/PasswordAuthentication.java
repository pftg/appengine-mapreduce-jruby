/*    */ package javax.mail;
/*    */ 
/*    */ public final class PasswordAuthentication
/*    */ {
/*    */   private final String user;
/*    */   private final String password;
/*    */ 
/*    */   public PasswordAuthentication(String user, String password)
/*    */   {
/* 32 */     this.user = user;
/* 33 */     this.password = password;
/*    */   }
/*    */ 
/*    */   public String getUserName() {
/* 37 */     return this.user;
/*    */   }
/*    */ 
/*    */   public String getPassword() {
/* 41 */     return this.password;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.PasswordAuthentication
 * JD-Core Version:    0.6.0
 */