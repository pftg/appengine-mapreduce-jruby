/*     */ package com.google.appengine.api.memcache;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.util.Base64;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class MemcacheSerialization
/*     */ {
/*     */   private static final String ASCII_CHARSET = "US-ASCII";
/*     */   private static final String UTF8_CHARSET = "UTF-8";
/*     */   private static final byte FALSE_VALUE = 48;
/*     */   private static final byte TRUE_VALUE = 49;
/*     */   private static final String MYCLASSNAME;
/*     */   private static final MessageDigest SHA1;
/*     */ 
/*     */   public static Object deserialize(byte[] value, int flags)
/*     */     throws ClassNotFoundException, IOException
/*     */   {
/* 118 */     Flag flagval = Flag.fromInt(flags);
/*     */ 
/* 120 */     switch (1.$SwitchMap$com$google$appengine$api$memcache$MemcacheSerialization$Flag[flagval.ordinal()]) {
/*     */     case 5:
/* 122 */       return value;
/*     */     case 6:
/* 125 */       if (value.length != 1) {
/* 126 */         throw new InvalidValueException("Cannot deserialize Boolean: bad length", null);
/*     */       }
/* 128 */       switch (value[0]) {
/*     */       case 49:
/* 130 */         return Boolean.TRUE;
/*     */       case 48:
/* 132 */         return Boolean.FALSE;
/*     */       }
/* 134 */       throw new InvalidValueException("Cannot deserialize Boolean: bad contents", null);
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/* 140 */       long val = Long.parseLong(new String(value, "US-ASCII"));
/* 141 */       switch (1.$SwitchMap$com$google$appengine$api$memcache$MemcacheSerialization$Flag[flagval.ordinal()]) {
/*     */       case 1:
/* 143 */         return Byte.valueOf((byte)(int)val);
/*     */       case 2:
/* 145 */         return Short.valueOf((short)(int)val);
/*     */       case 3:
/* 147 */         return Integer.valueOf((int)val);
/*     */       case 4:
/* 149 */         return Long.valueOf(val);
/*     */       }
/* 151 */       throw new InvalidValueException("Cannot deserialize number: bad contents", null);
/*     */     case 7:
/* 155 */       return new String(value, "UTF-8");
/*     */     case 8:
/* 158 */       if (value.length == 0) {
/* 159 */         return null;
/*     */       }
/* 161 */       ByteArrayInputStream baos = new ByteArrayInputStream(value);
/* 162 */       ObjectInputStream objIn = new ObjectInputStream(baos);
/* 163 */       Object response = objIn.readObject();
/* 164 */       objIn.close();
/* 165 */       return response;
/*     */     }
/*     */ 
/* 168 */     if (!$assertionsDisabled) throw new AssertionError();
/*     */ 
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] makePbKey(Object key)
/*     */     throws IOException
/*     */   {
/* 185 */     if (key == null) {
/* 186 */       return new byte[0];
/*     */     }
/* 188 */     if (((key instanceof String)) && (((String)key).length() < 250)) {
/* 189 */       return ("\"" + key + "\"").getBytes("UTF-8");
/*     */     }
/* 191 */     if (((key instanceof Long)) || ((key instanceof Integer)) || ((key instanceof Short)) || ((key instanceof Byte)))
/*     */     {
/* 193 */       return (key.getClass().getName() + ":" + key).getBytes("UTF-8");
/*     */     }
/* 195 */     if ((key instanceof Boolean)) {
/* 196 */       return (((Boolean)key).booleanValue() ? "true" : "false").getBytes("UTF-8");
/*     */     }
/*     */ 
/* 199 */     ValueAndFlags vaf = serialize(key);
/*     */     byte[] sha1hash;
/* 201 */     synchronized (SHA1) {
/* 202 */       SHA1.update(vaf.value);
/* 203 */       sha1hash = SHA1.digest();
/*     */     }
/*     */ 
/* 207 */     return Base64.encode(sha1hash).getBytes("UTF-8");
/*     */   }
/*     */ 
/*     */   public static ValueAndFlags serialize(Object value)
/*     */     throws IOException
/*     */   {
/*     */     Flag flags;
/* 223 */     if (value == null) {
/* 224 */       byte[] bytes = new byte[0];
/* 225 */       flags = Flag.OBJECT;
/*     */     }
/*     */     else
/*     */     {
/*     */       byte[] bytes;
/* 227 */       if ((value instanceof byte[])) {
/* 228 */         Flag flags = Flag.BYTES;
/* 229 */         bytes = (byte[])(byte[])value;
/*     */       }
/* 231 */       else if ((value instanceof Boolean)) {
/* 232 */         Flag flags = Flag.BOOLEAN;
/* 233 */         byte[] bytes = new byte[1];
/* 234 */         bytes[0] = (((Boolean)value).booleanValue() ? 49 : 48);
/*     */       }
/*     */       else
/*     */       {
/*     */         Flag flags;
/* 236 */         if (((value instanceof Integer)) || ((value instanceof Long)) || ((value instanceof Byte)) || ((value instanceof Short)))
/*     */         {
/* 238 */           byte[] bytes = value.toString().getBytes("US-ASCII");
/*     */           Flag flags;
/* 239 */           if ((value instanceof Integer)) {
/* 240 */             flags = Flag.INTEGER;
/*     */           }
/*     */           else
/*     */           {
/*     */             Flag flags;
/* 241 */             if ((value instanceof Long)) {
/* 242 */               flags = Flag.LONG;
/*     */             }
/*     */             else
/*     */             {
/*     */               Flag flags;
/* 243 */               if ((value instanceof Byte))
/* 244 */                 flags = Flag.BYTE;
/*     */               else
/* 246 */                 flags = Flag.SHORT;
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*     */           byte[] bytes;
/* 249 */           if ((value instanceof String)) {
/* 250 */             Flag flags = Flag.UTF8;
/* 251 */             bytes = ((String)value).getBytes("UTF-8");
/*     */           }
/*     */           else
/*     */           {
/*     */             byte[] bytes;
/* 253 */             if ((value instanceof Serializable)) {
/* 254 */               Flag flags = Flag.OBJECT;
/* 255 */               ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 256 */               ObjectOutputStream objOut = new ObjectOutputStream(baos);
/* 257 */               objOut.writeObject(value);
/* 258 */               objOut.close();
/* 259 */               bytes = baos.toByteArray();
/*     */             }
/*     */             else {
/* 262 */               throw new IllegalArgumentException("can't accept " + value.getClass() + " as a memcache entity");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     Flag flags;
/*     */     byte[] bytes;
/* 265 */     return new ValueAndFlags(bytes, flags, null);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  80 */     MYCLASSNAME = MemcacheSerialization.class.getName();
/*     */     try
/*     */     {
/*  91 */       SHA1 = MessageDigest.getInstance("SHA-1");
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  93 */       Logger.getLogger(MYCLASSNAME).log(Level.SEVERE, "Can't load SHA-1 MessageDigest!", ex);
/*     */ 
/*  95 */       throw new MemcacheServiceException("No SHA-1 algorithm, cannot hash keys for memcache", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ValueAndFlags
/*     */   {
/*     */     public final byte[] value;
/*     */     public final MemcacheSerialization.Flag flags;
/*     */ 
/*     */     private ValueAndFlags(byte[] value, MemcacheSerialization.Flag flags)
/*     */     {
/*  65 */       this.value = value;
/*  66 */       this.flags = flags;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum Flag
/*     */   {
/*  35 */     BYTES, 
/*  36 */     UTF8, 
/*  37 */     OBJECT, 
/*  38 */     INTEGER, 
/*  39 */     LONG, 
/*  40 */     BOOLEAN, 
/*  41 */     BYTE, 
/*  42 */     SHORT;
/*     */ 
/*     */     public static Flag fromInt(int i)
/*     */     {
/*  49 */       if ((i < 0) || (i >= values().length)) {
/*  50 */         throw new IllegalArgumentException();
/*     */       }
/*  52 */       return values()[i];
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.memcache.MemcacheSerialization
 * JD-Core Version:    0.6.0
 */