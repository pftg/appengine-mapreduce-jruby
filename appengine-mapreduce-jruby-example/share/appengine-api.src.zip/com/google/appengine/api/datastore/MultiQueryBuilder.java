/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ class MultiQueryBuilder
/*     */   implements Iterable<List<Query>>
/*     */ {
/*     */   final Query baseQuery;
/*     */   final List<MultiQueryComponent> components;
/*     */   final boolean hasParallelQueries;
/*     */ 
/*     */   public MultiQueryBuilder(Query query, List<Query.FilterPredicate> remainingFilters, List<MultiQueryComponent> components)
/*     */   {
/*  64 */     if (components == null) {
/*  65 */       throw new NullPointerException();
/*     */     }
/*  67 */     this.baseQuery = cloneQueryWithFilters(query, remainingFilters);
/*  68 */     this.components = components;
/*     */ 
/*  70 */     boolean hasParallelComponents = false;
/*  71 */     for (MultiQueryComponent c : components) {
/*  72 */       if (c.getOrder() == MultiQueryComponent.Order.PARALLEL) {
/*  73 */         hasParallelComponents = true;
/*  74 */         break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  79 */     this.hasParallelQueries = hasParallelComponents;
/*     */   }
/*     */ 
/*     */   static Query cloneQueryWithFilters(Query query, List<Query.FilterPredicate> filters) {
/*  83 */     return new Query(query.getKind(), query.getAncestor(), new ArrayList(query.getSortPredicates()), new ArrayList(filters), query.isKeysOnly(), query.getAppIdNamespace(), query.getFullTextSearch());
/*     */   }
/*     */ 
/*     */   public Iterator<List<Query>> iterator()
/*     */   {
/*  91 */     return new MultiQueryIterator(this);
/*     */   }
/*     */ 
/*     */   public List<Query.SortPredicate> getSortPredicates() {
/*  95 */     return this.baseQuery.getSortPredicates();
/*     */   }
/*     */ 
/*     */   public boolean isKeysOnly() {
/*  99 */     return this.baseQuery.isKeysOnly();
/*     */   }
/*     */ 
/*     */   public boolean hasParallelQueries() {
/* 103 */     return this.hasParallelQueries;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.MultiQueryBuilder
 * JD-Core Version:    0.6.0
 */