/*      */ package com.google.appengine.api.capabilities;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedInputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.CodedOutputStream;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.Descriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.EnumValueDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistry;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ExtensionRegistryLite;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.Builder;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Internal.EnumLiteMap;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.Message;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.ProtocolMessageEnum;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UninitializedMessageException;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet;
/*      */ import com.google.appengine.repackaged.com.google.protobuf.UnknownFieldSet.Builder;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class CapabilitiesPb
/*      */ {
/*      */   private static Descriptors.Descriptor internal_static_apphosting_CapabilityConfigList_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_CapabilityConfigList_fieldAccessorTable;
/*      */   private static Descriptors.Descriptor internal_static_apphosting_CapabilityConfig_descriptor;
/*      */   private static GeneratedMessage.FieldAccessorTable internal_static_apphosting_CapabilityConfig_fieldAccessorTable;
/*      */   private static Descriptors.FileDescriptor descriptor;
/*      */ 
/*      */   public static void registerAllExtensions(ExtensionRegistry registry)
/*      */   {
/*      */   }
/*      */ 
/*      */   public static Descriptors.FileDescriptor getDescriptor()
/*      */   {
/* 1165 */     return descriptor;
/*      */   }
/*      */   public static void internalForceInit() {
/*      */   }
/*      */   static {
/* 1170 */     String[] descriptorData = { "\n\"apphosting/base/capabilities.proto\022\napphosting\"z\n\024CapabilityConfigList\022,\n\006config\030\001 \003(\0132\034.apphosting.CapabilityConfig\0224\n\016default_config\030\002 \001(\0132\034.apphosting.CapabilityConfig\"\002\n\020CapabilityConfig\022\017\n\007package\030\001 \002(\t\022\022\n\ncapability\030\002 \002(\t\022<\n\006status\030\003 \001(\0162#.apphosting.CapabilityConfig.Status:\007UNKNOWN\022\026\n\016scheduled_time\030\007 \001(\t\022\030\n\020internal_message\030\004 \001(\t\022\025\n\radmin_message\030\005 \001(\t\022\025\n\rerror_message\030\006 \001(\t\"?\n\006Status\022\013", "\n\007ENABLED\020\001\022\r\n\tSCHEDULED\020\002\022\f\n\bDISABLED\020\003\022\013\n\007UNKNOWN\020\004B=\n%com.google.appengine.api.capabilities\020\001 \001(\002B\016CapabilitiesPb" };
/*      */ 
/* 1185 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/*      */     {
/*      */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/*      */       {
/* 1189 */         CapabilitiesPb.access$2702(root);
/* 1190 */         CapabilitiesPb.access$002((Descriptors.Descriptor)CapabilitiesPb.getDescriptor().getMessageTypes().get(0));
/*      */ 
/* 1192 */         CapabilitiesPb.access$102(new GeneratedMessage.FieldAccessorTable(CapabilitiesPb.internal_static_apphosting_CapabilityConfigList_descriptor, new String[] { "Config", "DefaultConfig" }, CapabilitiesPb.CapabilityConfigList.class, CapabilitiesPb.CapabilityConfigList.Builder.class));
/*      */ 
/* 1198 */         CapabilitiesPb.access$802((Descriptors.Descriptor)CapabilitiesPb.getDescriptor().getMessageTypes().get(1));
/*      */ 
/* 1200 */         CapabilitiesPb.access$902(new GeneratedMessage.FieldAccessorTable(CapabilitiesPb.internal_static_apphosting_CapabilityConfig_descriptor, new String[] { "Package", "Capability", "Status", "ScheduledTime", "InternalMessage", "AdminMessage", "ErrorMessage" }, CapabilitiesPb.CapabilityConfig.class, CapabilitiesPb.CapabilityConfig.Builder.class));
/*      */ 
/* 1206 */         return null;
/*      */       }
/*      */     };
/* 1209 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/*      */   }
/*      */ 
/*      */   public static final class CapabilityConfig extends GeneratedMessage
/*      */   {
/* 1144 */     private static final CapabilityConfig defaultInstance = new CapabilityConfig(true);
/*      */     public static final int PACKAGE_FIELD_NUMBER = 1;
/*      */     private boolean hasPackage;
/*      */     private String package_;
/*      */     public static final int CAPABILITY_FIELD_NUMBER = 2;
/*      */     private boolean hasCapability;
/*      */     private String capability_;
/*      */     public static final int STATUS_FIELD_NUMBER = 3;
/*      */     private boolean hasStatus;
/*      */     private Status status_;
/*      */     public static final int SCHEDULED_TIME_FIELD_NUMBER = 7;
/*      */     private boolean hasScheduledTime;
/*      */     private String scheduledTime_;
/*      */     public static final int INTERNAL_MESSAGE_FIELD_NUMBER = 4;
/*      */     private boolean hasInternalMessage;
/*      */     private String internalMessage_;
/*      */     public static final int ADMIN_MESSAGE_FIELD_NUMBER = 5;
/*      */     private boolean hasAdminMessage;
/*      */     private String adminMessage_;
/*      */     public static final int ERROR_MESSAGE_FIELD_NUMBER = 6;
/*      */     private boolean hasErrorMessage;
/*      */     private String errorMessage_;
/*  670 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private CapabilityConfig(Builder builder)
/*      */     {
/*  452 */       super();
/*      */     }
/*      */     private CapabilityConfig(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig getDefaultInstance() {
/*  458 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public CapabilityConfig getDefaultInstanceForType() {
/*  462 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*  467 */       return CapabilitiesPb.internal_static_apphosting_CapabilityConfig_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*  472 */       return CapabilitiesPb.internal_static_apphosting_CapabilityConfig_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public boolean hasPackage()
/*      */     {
/*  556 */       return this.hasPackage;
/*      */     }
/*      */     public String getPackage() {
/*  559 */       return this.package_;
/*      */     }
/*      */ 
/*      */     public boolean hasCapability()
/*      */     {
/*  567 */       return this.hasCapability;
/*      */     }
/*      */     public String getCapability() {
/*  570 */       return this.capability_;
/*      */     }
/*      */ 
/*      */     public boolean hasStatus()
/*      */     {
/*  578 */       return this.hasStatus;
/*      */     }
/*      */     public Status getStatus() {
/*  581 */       return this.status_;
/*      */     }
/*      */ 
/*      */     public boolean hasScheduledTime()
/*      */     {
/*  589 */       return this.hasScheduledTime;
/*      */     }
/*      */     public String getScheduledTime() {
/*  592 */       return this.scheduledTime_;
/*      */     }
/*      */ 
/*      */     public boolean hasInternalMessage()
/*      */     {
/*  600 */       return this.hasInternalMessage;
/*      */     }
/*      */     public String getInternalMessage() {
/*  603 */       return this.internalMessage_;
/*      */     }
/*      */ 
/*      */     public boolean hasAdminMessage()
/*      */     {
/*  611 */       return this.hasAdminMessage;
/*      */     }
/*      */     public String getAdminMessage() {
/*  614 */       return this.adminMessage_;
/*      */     }
/*      */ 
/*      */     public boolean hasErrorMessage()
/*      */     {
/*  622 */       return this.hasErrorMessage;
/*      */     }
/*      */     public String getErrorMessage() {
/*  625 */       return this.errorMessage_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*  629 */       this.package_ = "";
/*  630 */       this.capability_ = "";
/*  631 */       this.status_ = Status.UNKNOWN;
/*  632 */       this.scheduledTime_ = "";
/*  633 */       this.internalMessage_ = "";
/*  634 */       this.adminMessage_ = "";
/*  635 */       this.errorMessage_ = "";
/*      */     }
/*      */     public final boolean isInitialized() {
/*  638 */       if (!this.hasPackage) return false;
/*  639 */       return this.hasCapability;
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/*  645 */       getSerializedSize();
/*  646 */       if (hasPackage()) {
/*  647 */         output.writeString(1, getPackage());
/*      */       }
/*  649 */       if (hasCapability()) {
/*  650 */         output.writeString(2, getCapability());
/*      */       }
/*  652 */       if (hasStatus()) {
/*  653 */         output.writeEnum(3, getStatus().getNumber());
/*      */       }
/*  655 */       if (hasInternalMessage()) {
/*  656 */         output.writeString(4, getInternalMessage());
/*      */       }
/*  658 */       if (hasAdminMessage()) {
/*  659 */         output.writeString(5, getAdminMessage());
/*      */       }
/*  661 */       if (hasErrorMessage()) {
/*  662 */         output.writeString(6, getErrorMessage());
/*      */       }
/*  664 */       if (hasScheduledTime()) {
/*  665 */         output.writeString(7, getScheduledTime());
/*      */       }
/*  667 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*  672 */       int size = this.memoizedSerializedSize;
/*  673 */       if (size != -1) return size;
/*      */ 
/*  675 */       size = 0;
/*  676 */       if (hasPackage()) {
/*  677 */         size += CodedOutputStream.computeStringSize(1, getPackage());
/*      */       }
/*      */ 
/*  680 */       if (hasCapability()) {
/*  681 */         size += CodedOutputStream.computeStringSize(2, getCapability());
/*      */       }
/*      */ 
/*  684 */       if (hasStatus()) {
/*  685 */         size += CodedOutputStream.computeEnumSize(3, getStatus().getNumber());
/*      */       }
/*      */ 
/*  688 */       if (hasInternalMessage()) {
/*  689 */         size += CodedOutputStream.computeStringSize(4, getInternalMessage());
/*      */       }
/*      */ 
/*  692 */       if (hasAdminMessage()) {
/*  693 */         size += CodedOutputStream.computeStringSize(5, getAdminMessage());
/*      */       }
/*      */ 
/*  696 */       if (hasErrorMessage()) {
/*  697 */         size += CodedOutputStream.computeStringSize(6, getErrorMessage());
/*      */       }
/*      */ 
/*  700 */       if (hasScheduledTime()) {
/*  701 */         size += CodedOutputStream.computeStringSize(7, getScheduledTime());
/*      */       }
/*      */ 
/*  704 */       size += getUnknownFields().getSerializedSize();
/*  705 */       this.memoizedSerializedSize = size;
/*  706 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  711 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  717 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  723 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  728 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  734 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(InputStream input) throws IOException
/*      */     {
/*  739 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  745 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  750 */       Builder builder = newBuilder();
/*  751 */       if (builder.mergeDelimitedFrom(input)) {
/*  752 */         return builder.buildParsed();
/*      */       }
/*  754 */       return null;
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  761 */       Builder builder = newBuilder();
/*  762 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  763 */         return builder.buildParsed();
/*      */       }
/*  765 */       return null;
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  771 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfig parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  777 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  781 */       return Builder.access$1100(); } 
/*  782 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(CapabilityConfig prototype) {
/*  784 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  786 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/* 1145 */       CapabilitiesPb.internalForceInit();
/* 1146 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*      */       private boolean hasPackage;
/*  981 */       private String package_ = "";
/*      */       private boolean hasCapability;
/* 1004 */       private String capability_ = "";
/*      */       private boolean hasStatus;
/* 1027 */       private CapabilitiesPb.CapabilityConfig.Status status_ = CapabilitiesPb.CapabilityConfig.Status.UNKNOWN;
/*      */       private boolean hasScheduledTime;
/* 1050 */       private String scheduledTime_ = "";
/*      */       private boolean hasInternalMessage;
/* 1073 */       private String internalMessage_ = "";
/*      */       private boolean hasAdminMessage;
/* 1096 */       private String adminMessage_ = "";
/*      */       private boolean hasErrorMessage;
/* 1119 */       private String errorMessage_ = "";
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  792 */         return CapabilitiesPb.internal_static_apphosting_CapabilityConfig_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  797 */         return CapabilitiesPb.internal_static_apphosting_CapabilityConfig_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  805 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  809 */         super.clear();
/*  810 */         this.package_ = "";
/*  811 */         this.hasPackage = false;
/*  812 */         this.capability_ = "";
/*  813 */         this.hasCapability = false;
/*  814 */         this.status_ = CapabilitiesPb.CapabilityConfig.Status.UNKNOWN;
/*  815 */         this.hasStatus = false;
/*  816 */         this.scheduledTime_ = "";
/*  817 */         this.hasScheduledTime = false;
/*  818 */         this.internalMessage_ = "";
/*  819 */         this.hasInternalMessage = false;
/*  820 */         this.adminMessage_ = "";
/*  821 */         this.hasAdminMessage = false;
/*  822 */         this.errorMessage_ = "";
/*  823 */         this.hasErrorMessage = false;
/*  824 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  828 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  833 */         return CapabilitiesPb.CapabilityConfig.getDescriptor();
/*      */       }
/*      */ 
/*      */       public CapabilitiesPb.CapabilityConfig getDefaultInstanceForType() {
/*  837 */         return CapabilitiesPb.CapabilityConfig.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public CapabilitiesPb.CapabilityConfig build() {
/*  841 */         CapabilitiesPb.CapabilityConfig result = buildPartial();
/*  842 */         if (!result.isInitialized()) {
/*  843 */           throw newUninitializedMessageException(result);
/*      */         }
/*  845 */         return result;
/*      */       }
/*      */ 
/*      */       private CapabilitiesPb.CapabilityConfig buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  850 */         CapabilitiesPb.CapabilityConfig result = buildPartial();
/*  851 */         if (!result.isInitialized()) {
/*  852 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  855 */         return result;
/*      */       }
/*      */ 
/*      */       public CapabilitiesPb.CapabilityConfig buildPartial() {
/*  859 */         CapabilitiesPb.CapabilityConfig result = new CapabilitiesPb.CapabilityConfig(this, null);
/*  860 */         CapabilitiesPb.CapabilityConfig.access$1302(result, this.hasPackage);
/*  861 */         CapabilitiesPb.CapabilityConfig.access$1402(result, this.package_);
/*  862 */         CapabilitiesPb.CapabilityConfig.access$1502(result, this.hasCapability);
/*  863 */         CapabilitiesPb.CapabilityConfig.access$1602(result, this.capability_);
/*  864 */         CapabilitiesPb.CapabilityConfig.access$1702(result, this.hasStatus);
/*  865 */         CapabilitiesPb.CapabilityConfig.access$1802(result, this.status_);
/*  866 */         CapabilitiesPb.CapabilityConfig.access$1902(result, this.hasScheduledTime);
/*  867 */         CapabilitiesPb.CapabilityConfig.access$2002(result, this.scheduledTime_);
/*  868 */         CapabilitiesPb.CapabilityConfig.access$2102(result, this.hasInternalMessage);
/*  869 */         CapabilitiesPb.CapabilityConfig.access$2202(result, this.internalMessage_);
/*  870 */         CapabilitiesPb.CapabilityConfig.access$2302(result, this.hasAdminMessage);
/*  871 */         CapabilitiesPb.CapabilityConfig.access$2402(result, this.adminMessage_);
/*  872 */         CapabilitiesPb.CapabilityConfig.access$2502(result, this.hasErrorMessage);
/*  873 */         CapabilitiesPb.CapabilityConfig.access$2602(result, this.errorMessage_);
/*  874 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  878 */         if ((other instanceof CapabilitiesPb.CapabilityConfig)) {
/*  879 */           return mergeFrom((CapabilitiesPb.CapabilityConfig)other);
/*      */         }
/*  881 */         super.mergeFrom(other);
/*  882 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CapabilitiesPb.CapabilityConfig other)
/*      */       {
/*  887 */         if (other == CapabilitiesPb.CapabilityConfig.getDefaultInstance()) return this;
/*  888 */         if (other.hasPackage()) {
/*  889 */           setPackage(other.getPackage());
/*      */         }
/*  891 */         if (other.hasCapability()) {
/*  892 */           setCapability(other.getCapability());
/*      */         }
/*  894 */         if (other.hasStatus()) {
/*  895 */           setStatus(other.getStatus());
/*      */         }
/*  897 */         if (other.hasScheduledTime()) {
/*  898 */           setScheduledTime(other.getScheduledTime());
/*      */         }
/*  900 */         if (other.hasInternalMessage()) {
/*  901 */           setInternalMessage(other.getInternalMessage());
/*      */         }
/*  903 */         if (other.hasAdminMessage()) {
/*  904 */           setAdminMessage(other.getAdminMessage());
/*      */         }
/*  906 */         if (other.hasErrorMessage()) {
/*  907 */           setErrorMessage(other.getErrorMessage());
/*      */         }
/*  909 */         mergeUnknownFields(other.getUnknownFields());
/*  910 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  914 */         if (!this.hasPackage) return false;
/*  915 */         return this.hasCapability;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  923 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  927 */           int tag = input.readTag();
/*  928 */           switch (tag) {
/*      */           case 0:
/*  930 */             setUnknownFields(unknownFields.build());
/*  931 */             return this;
/*      */           default:
/*  933 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  935 */             setUnknownFields(unknownFields.build());
/*  936 */             return this;
/*      */           case 10:
/*  941 */             setPackage(input.readString());
/*  942 */             break;
/*      */           case 18:
/*  945 */             setCapability(input.readString());
/*  946 */             break;
/*      */           case 24:
/*  949 */             int rawValue = input.readEnum();
/*  950 */             CapabilitiesPb.CapabilityConfig.Status value = CapabilitiesPb.CapabilityConfig.Status.valueOf(rawValue);
/*  951 */             if (value == null)
/*  952 */               unknownFields.mergeVarintField(3, rawValue);
/*      */             else {
/*  954 */               setStatus(value);
/*      */             }
/*  956 */             break;
/*      */           case 34:
/*  959 */             setInternalMessage(input.readString());
/*  960 */             break;
/*      */           case 42:
/*  963 */             setAdminMessage(input.readString());
/*  964 */             break;
/*      */           case 50:
/*  967 */             setErrorMessage(input.readString());
/*  968 */             break;
/*      */           case 58:
/*  971 */             setScheduledTime(input.readString());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       public boolean hasPackage()
/*      */       {
/*  983 */         return this.hasPackage;
/*      */       }
/*      */       public String getPackage() {
/*  986 */         return this.package_;
/*      */       }
/*      */       public Builder setPackage(String value) {
/*  989 */         if (value == null) {
/*  990 */           throw new NullPointerException();
/*      */         }
/*  992 */         this.hasPackage = true;
/*  993 */         this.package_ = value;
/*  994 */         return this;
/*      */       }
/*      */       public Builder clearPackage() {
/*  997 */         this.hasPackage = false;
/*  998 */         this.package_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance().getPackage();
/*  999 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasCapability()
/*      */       {
/* 1006 */         return this.hasCapability;
/*      */       }
/*      */       public String getCapability() {
/* 1009 */         return this.capability_;
/*      */       }
/*      */       public Builder setCapability(String value) {
/* 1012 */         if (value == null) {
/* 1013 */           throw new NullPointerException();
/*      */         }
/* 1015 */         this.hasCapability = true;
/* 1016 */         this.capability_ = value;
/* 1017 */         return this;
/*      */       }
/*      */       public Builder clearCapability() {
/* 1020 */         this.hasCapability = false;
/* 1021 */         this.capability_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance().getCapability();
/* 1022 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasStatus()
/*      */       {
/* 1029 */         return this.hasStatus;
/*      */       }
/*      */       public CapabilitiesPb.CapabilityConfig.Status getStatus() {
/* 1032 */         return this.status_;
/*      */       }
/*      */       public Builder setStatus(CapabilitiesPb.CapabilityConfig.Status value) {
/* 1035 */         if (value == null) {
/* 1036 */           throw new NullPointerException();
/*      */         }
/* 1038 */         this.hasStatus = true;
/* 1039 */         this.status_ = value;
/* 1040 */         return this;
/*      */       }
/*      */       public Builder clearStatus() {
/* 1043 */         this.hasStatus = false;
/* 1044 */         this.status_ = CapabilitiesPb.CapabilityConfig.Status.UNKNOWN;
/* 1045 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasScheduledTime()
/*      */       {
/* 1052 */         return this.hasScheduledTime;
/*      */       }
/*      */       public String getScheduledTime() {
/* 1055 */         return this.scheduledTime_;
/*      */       }
/*      */       public Builder setScheduledTime(String value) {
/* 1058 */         if (value == null) {
/* 1059 */           throw new NullPointerException();
/*      */         }
/* 1061 */         this.hasScheduledTime = true;
/* 1062 */         this.scheduledTime_ = value;
/* 1063 */         return this;
/*      */       }
/*      */       public Builder clearScheduledTime() {
/* 1066 */         this.hasScheduledTime = false;
/* 1067 */         this.scheduledTime_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance().getScheduledTime();
/* 1068 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasInternalMessage()
/*      */       {
/* 1075 */         return this.hasInternalMessage;
/*      */       }
/*      */       public String getInternalMessage() {
/* 1078 */         return this.internalMessage_;
/*      */       }
/*      */       public Builder setInternalMessage(String value) {
/* 1081 */         if (value == null) {
/* 1082 */           throw new NullPointerException();
/*      */         }
/* 1084 */         this.hasInternalMessage = true;
/* 1085 */         this.internalMessage_ = value;
/* 1086 */         return this;
/*      */       }
/*      */       public Builder clearInternalMessage() {
/* 1089 */         this.hasInternalMessage = false;
/* 1090 */         this.internalMessage_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance().getInternalMessage();
/* 1091 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasAdminMessage()
/*      */       {
/* 1098 */         return this.hasAdminMessage;
/*      */       }
/*      */       public String getAdminMessage() {
/* 1101 */         return this.adminMessage_;
/*      */       }
/*      */       public Builder setAdminMessage(String value) {
/* 1104 */         if (value == null) {
/* 1105 */           throw new NullPointerException();
/*      */         }
/* 1107 */         this.hasAdminMessage = true;
/* 1108 */         this.adminMessage_ = value;
/* 1109 */         return this;
/*      */       }
/*      */       public Builder clearAdminMessage() {
/* 1112 */         this.hasAdminMessage = false;
/* 1113 */         this.adminMessage_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance().getAdminMessage();
/* 1114 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasErrorMessage()
/*      */       {
/* 1121 */         return this.hasErrorMessage;
/*      */       }
/*      */       public String getErrorMessage() {
/* 1124 */         return this.errorMessage_;
/*      */       }
/*      */       public Builder setErrorMessage(String value) {
/* 1127 */         if (value == null) {
/* 1128 */           throw new NullPointerException();
/*      */         }
/* 1130 */         this.hasErrorMessage = true;
/* 1131 */         this.errorMessage_ = value;
/* 1132 */         return this;
/*      */       }
/*      */       public Builder clearErrorMessage() {
/* 1135 */         this.hasErrorMessage = false;
/* 1136 */         this.errorMessage_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance().getErrorMessage();
/* 1137 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum Status
/*      */       implements ProtocolMessageEnum
/*      */     {
/*  477 */       ENABLED(0, 1), 
/*  478 */       SCHEDULED(1, 2), 
/*  479 */       DISABLED(2, 3), 
/*  480 */       UNKNOWN(3, 4);
/*      */ 
/*      */       public static final int ENABLED_VALUE = 1;
/*      */       public static final int SCHEDULED_VALUE = 2;
/*      */       public static final int DISABLED_VALUE = 3;
/*      */       public static final int UNKNOWN_VALUE = 4;
/*      */       private static Internal.EnumLiteMap<Status> internalValueMap;
/*      */       private static final Status[] VALUES;
/*      */       private final int index;
/*      */       private final int value;
/*      */ 
/*  489 */       public final int getNumber() { return this.value; }
/*      */ 
/*      */       public static Status valueOf(int value) {
/*  492 */         switch (value) { case 1:
/*  493 */           return ENABLED;
/*      */         case 2:
/*  494 */           return SCHEDULED;
/*      */         case 3:
/*  495 */           return DISABLED;
/*      */         case 4:
/*  496 */           return UNKNOWN; }
/*  497 */         return null;
/*      */       }
/*      */ 
/*      */       public static Internal.EnumLiteMap<Status> internalGetValueMap()
/*      */       {
/*  503 */         return internalValueMap;
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumValueDescriptor getValueDescriptor()
/*      */       {
/*  515 */         return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
/*      */       }
/*      */ 
/*      */       public final Descriptors.EnumDescriptor getDescriptorForType() {
/*  519 */         return getDescriptor();
/*      */       }
/*      */ 
/*      */       public static final Descriptors.EnumDescriptor getDescriptor() {
/*  523 */         return (Descriptors.EnumDescriptor)CapabilitiesPb.CapabilityConfig.getDescriptor().getEnumTypes().get(0);
/*      */       }
/*      */ 
/*      */       public static Status valueOf(Descriptors.EnumValueDescriptor desc)
/*      */       {
/*  531 */         if (desc.getType() != getDescriptor()) {
/*  532 */           throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
/*      */         }
/*      */ 
/*  535 */         return VALUES[desc.getIndex()];
/*      */       }
/*      */ 
/*      */       private Status(int index, int value)
/*      */       {
/*  540 */         this.index = index;
/*  541 */         this.value = value;
/*      */       }
/*      */ 
/*      */       static
/*      */       {
/*  506 */         internalValueMap = new Internal.EnumLiteMap()
/*      */         {
/*      */           public CapabilitiesPb.CapabilityConfig.Status findValueByNumber(int number) {
/*  509 */             return CapabilitiesPb.CapabilityConfig.Status.valueOf(number);
/*      */           }
/*      */         };
/*  526 */         VALUES = new Status[] { ENABLED, SCHEDULED, DISABLED, UNKNOWN };
/*      */ 
/*  545 */         CapabilitiesPb.getDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final class CapabilityConfigList extends GeneratedMessage
/*      */   {
/*  440 */     private static final CapabilityConfigList defaultInstance = new CapabilityConfigList(true);
/*      */     public static final int CONFIG_FIELD_NUMBER = 1;
/*      */     private List<CapabilitiesPb.CapabilityConfig> config_;
/*      */     public static final int DEFAULT_CONFIG_FIELD_NUMBER = 2;
/*      */     private boolean hasDefaultConfig;
/*      */     private CapabilitiesPb.CapabilityConfig defaultConfig_;
/*   88 */     private int memoizedSerializedSize = -1;
/*      */ 
/*      */     private CapabilityConfigList(Builder builder)
/*      */     {
/*   15 */       super();
/*      */     }
/*      */     private CapabilityConfigList(boolean noInit) {
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList getDefaultInstance() {
/*   21 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public CapabilityConfigList getDefaultInstanceForType() {
/*   25 */       return defaultInstance;
/*      */     }
/*      */ 
/*      */     public static final Descriptors.Descriptor getDescriptor()
/*      */     {
/*   30 */       return CapabilitiesPb.internal_static_apphosting_CapabilityConfigList_descriptor;
/*      */     }
/*      */ 
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */     {
/*   35 */       return CapabilitiesPb.internal_static_apphosting_CapabilityConfigList_fieldAccessorTable;
/*      */     }
/*      */ 
/*      */     public List<CapabilitiesPb.CapabilityConfig> getConfigList()
/*      */     {
/*   42 */       return this.config_;
/*      */     }
/*      */     public int getConfigCount() {
/*   45 */       return this.config_.size();
/*      */     }
/*      */     public CapabilitiesPb.CapabilityConfig getConfig(int index) {
/*   48 */       return (CapabilitiesPb.CapabilityConfig)this.config_.get(index);
/*      */     }
/*      */ 
/*      */     public boolean hasDefaultConfig()
/*      */     {
/*   56 */       return this.hasDefaultConfig;
/*      */     }
/*      */     public CapabilitiesPb.CapabilityConfig getDefaultConfig() {
/*   59 */       return this.defaultConfig_;
/*      */     }
/*      */ 
/*      */     private void initFields() {
/*   63 */       this.config_ = Collections.emptyList();
/*   64 */       this.defaultConfig_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance();
/*      */     }
/*      */     public final boolean isInitialized() {
/*   67 */       for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*   68 */         if (!element.isInitialized()) return false;
/*      */       }
/*      */ 
/*   71 */       return (!hasDefaultConfig()) || 
/*   71 */         (getDefaultConfig().isInitialized());
/*      */     }
/*      */ 
/*      */     public void writeTo(CodedOutputStream output)
/*      */       throws IOException
/*      */     {
/*   78 */       getSerializedSize();
/*   79 */       for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*   80 */         output.writeMessage(1, element);
/*      */       }
/*   82 */       if (hasDefaultConfig()) {
/*   83 */         output.writeMessage(2, getDefaultConfig());
/*      */       }
/*   85 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     public int getSerializedSize()
/*      */     {
/*   90 */       int size = this.memoizedSerializedSize;
/*   91 */       if (size != -1) return size;
/*      */ 
/*   93 */       size = 0;
/*   94 */       for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*   95 */         size += CodedOutputStream.computeMessageSize(1, element);
/*      */       }
/*      */ 
/*   98 */       if (hasDefaultConfig()) {
/*   99 */         size += CodedOutputStream.computeMessageSize(2, getDefaultConfig());
/*      */       }
/*      */ 
/*  102 */       size += getUnknownFields().getSerializedSize();
/*  103 */       this.memoizedSerializedSize = size;
/*  104 */       return size;
/*      */     }
/*      */ 
/*      */     protected Object writeReplace() throws ObjectStreamException
/*      */     {
/*  109 */       return super.writeReplace();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(ByteString data)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  115 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  121 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(byte[] data) throws InvalidProtocolBufferException
/*      */     {
/*  126 */       return ((Builder)newBuilder().mergeFrom(data)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/*      */       throws InvalidProtocolBufferException
/*      */     {
/*  132 */       return ((Builder)newBuilder().mergeFrom(data, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(InputStream input) throws IOException
/*      */     {
/*  137 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  143 */       return ((Builder)newBuilder().mergeFrom(input, extensionRegistry)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseDelimitedFrom(InputStream input) throws IOException
/*      */     {
/*  148 */       Builder builder = newBuilder();
/*  149 */       if (builder.mergeDelimitedFrom(input)) {
/*  150 */         return builder.buildParsed();
/*      */       }
/*  152 */       return null;
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  159 */       Builder builder = newBuilder();
/*  160 */       if (builder.mergeDelimitedFrom(input, extensionRegistry)) {
/*  161 */         return builder.buildParsed();
/*      */       }
/*  163 */       return null;
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(CodedInputStream input)
/*      */       throws IOException
/*      */     {
/*  169 */       return ((Builder)newBuilder().mergeFrom(input)).buildParsed();
/*      */     }
/*      */ 
/*      */     public static CapabilityConfigList parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */       throws IOException
/*      */     {
/*  175 */       return newBuilder().mergeFrom(input, extensionRegistry).buildParsed();
/*      */     }
/*      */ 
/*      */     public static Builder newBuilder() {
/*  179 */       return Builder.access$300(); } 
/*  180 */     public Builder newBuilderForType() { return newBuilder(); } 
/*      */     public static Builder newBuilder(CapabilityConfigList prototype) {
/*  182 */       return newBuilder().mergeFrom(prototype);
/*      */     }
/*  184 */     public Builder toBuilder() { return newBuilder(this);
/*      */     }
/*      */ 
/*      */     static
/*      */     {
/*  441 */       CapabilitiesPb.internalForceInit();
/*  442 */       defaultInstance.initFields();
/*      */     }
/*      */ 
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder>
/*      */     {
/*  337 */       private List<CapabilitiesPb.CapabilityConfig> config_ = Collections.emptyList();
/*      */       private boolean isConfigMutable;
/*      */       private boolean hasDefaultConfig;
/*  398 */       private CapabilitiesPb.CapabilityConfig defaultConfig_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance();
/*      */ 
/*      */       public static final Descriptors.Descriptor getDescriptor()
/*      */       {
/*  190 */         return CapabilitiesPb.internal_static_apphosting_CapabilityConfigList_descriptor;
/*      */       }
/*      */ 
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/*      */       {
/*  195 */         return CapabilitiesPb.internal_static_apphosting_CapabilityConfigList_fieldAccessorTable;
/*      */       }
/*      */ 
/*      */       private static Builder create()
/*      */       {
/*  203 */         return new Builder();
/*      */       }
/*      */ 
/*      */       public Builder clear() {
/*  207 */         super.clear();
/*  208 */         this.config_ = Collections.emptyList();
/*  209 */         this.isConfigMutable = false;
/*  210 */         this.defaultConfig_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance();
/*  211 */         this.hasDefaultConfig = false;
/*  212 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder clone() {
/*  216 */         return create().mergeFrom(buildPartial());
/*      */       }
/*      */ 
/*      */       public Descriptors.Descriptor getDescriptorForType()
/*      */       {
/*  221 */         return CapabilitiesPb.CapabilityConfigList.getDescriptor();
/*      */       }
/*      */ 
/*      */       public CapabilitiesPb.CapabilityConfigList getDefaultInstanceForType() {
/*  225 */         return CapabilitiesPb.CapabilityConfigList.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       public CapabilitiesPb.CapabilityConfigList build() {
/*  229 */         CapabilitiesPb.CapabilityConfigList result = buildPartial();
/*  230 */         if (!result.isInitialized()) {
/*  231 */           throw newUninitializedMessageException(result);
/*      */         }
/*  233 */         return result;
/*      */       }
/*      */ 
/*      */       private CapabilitiesPb.CapabilityConfigList buildParsed() throws InvalidProtocolBufferException
/*      */       {
/*  238 */         CapabilitiesPb.CapabilityConfigList result = buildPartial();
/*  239 */         if (!result.isInitialized()) {
/*  240 */           throw newUninitializedMessageException(result).asInvalidProtocolBufferException();
/*      */         }
/*      */ 
/*  243 */         return result;
/*      */       }
/*      */ 
/*      */       public CapabilitiesPb.CapabilityConfigList buildPartial() {
/*  247 */         CapabilitiesPb.CapabilityConfigList result = new CapabilitiesPb.CapabilityConfigList(this, null);
/*  248 */         if (this.isConfigMutable) {
/*  249 */           this.config_ = Collections.unmodifiableList(this.config_);
/*  250 */           this.isConfigMutable = false;
/*      */         }
/*  252 */         CapabilitiesPb.CapabilityConfigList.access$502(result, this.config_);
/*  253 */         CapabilitiesPb.CapabilityConfigList.access$602(result, this.hasDefaultConfig);
/*  254 */         CapabilitiesPb.CapabilityConfigList.access$702(result, this.defaultConfig_);
/*  255 */         return result;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(Message other) {
/*  259 */         if ((other instanceof CapabilitiesPb.CapabilityConfigList)) {
/*  260 */           return mergeFrom((CapabilitiesPb.CapabilityConfigList)other);
/*      */         }
/*  262 */         super.mergeFrom(other);
/*  263 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CapabilitiesPb.CapabilityConfigList other)
/*      */       {
/*  268 */         if (other == CapabilitiesPb.CapabilityConfigList.getDefaultInstance()) return this;
/*  269 */         if (!other.config_.isEmpty()) {
/*  270 */           if (this.config_.isEmpty()) {
/*  271 */             this.config_ = other.config_;
/*  272 */             this.isConfigMutable = false;
/*      */           } else {
/*  274 */             ensureConfigIsMutable();
/*  275 */             this.config_.addAll(other.config_);
/*      */           }
/*      */         }
/*  278 */         if (other.hasDefaultConfig()) {
/*  279 */           mergeDefaultConfig(other.getDefaultConfig());
/*      */         }
/*  281 */         mergeUnknownFields(other.getUnknownFields());
/*  282 */         return this;
/*      */       }
/*      */ 
/*      */       public final boolean isInitialized() {
/*  286 */         for (CapabilitiesPb.CapabilityConfig element : getConfigList()) {
/*  287 */           if (!element.isInitialized()) return false;
/*      */         }
/*      */ 
/*  290 */         return (!hasDefaultConfig()) || 
/*  290 */           (getDefaultConfig().isInitialized());
/*      */       }
/*      */ 
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*      */         throws IOException
/*      */       {
/*  299 */         UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder(getUnknownFields());
/*      */         while (true)
/*      */         {
/*  303 */           int tag = input.readTag();
/*  304 */           switch (tag) {
/*      */           case 0:
/*  306 */             setUnknownFields(unknownFields.build());
/*  307 */             return this;
/*      */           default:
/*  309 */             if (parseUnknownField(input, unknownFields, extensionRegistry, tag))
/*      */               break;
/*  311 */             setUnknownFields(unknownFields.build());
/*  312 */             return this;
/*      */           case 10:
/*  317 */             CapabilitiesPb.CapabilityConfig.Builder subBuilder = CapabilitiesPb.CapabilityConfig.newBuilder();
/*  318 */             input.readMessage(subBuilder, extensionRegistry);
/*  319 */             addConfig(subBuilder.buildPartial());
/*  320 */             break;
/*      */           case 18:
/*  323 */             CapabilitiesPb.CapabilityConfig.Builder subBuilder = CapabilitiesPb.CapabilityConfig.newBuilder();
/*  324 */             if (hasDefaultConfig()) {
/*  325 */               subBuilder.mergeFrom(getDefaultConfig());
/*      */             }
/*  327 */             input.readMessage(subBuilder, extensionRegistry);
/*  328 */             setDefaultConfig(subBuilder.buildPartial());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       private void ensureConfigIsMutable()
/*      */       {
/*  341 */         if (!this.isConfigMutable) {
/*  342 */           this.config_ = new ArrayList(this.config_);
/*  343 */           this.isConfigMutable = true;
/*      */         }
/*      */       }
/*      */ 
/*      */       public List<CapabilitiesPb.CapabilityConfig> getConfigList() {
/*  347 */         return Collections.unmodifiableList(this.config_);
/*      */       }
/*      */       public int getConfigCount() {
/*  350 */         return this.config_.size();
/*      */       }
/*      */       public CapabilitiesPb.CapabilityConfig getConfig(int index) {
/*  353 */         return (CapabilitiesPb.CapabilityConfig)this.config_.get(index);
/*      */       }
/*      */ 
/*      */       public Builder setConfig(int index, CapabilitiesPb.CapabilityConfig value) {
/*  357 */         if (value == null) {
/*  358 */           throw new NullPointerException();
/*      */         }
/*  360 */         ensureConfigIsMutable();
/*  361 */         this.config_.set(index, value);
/*  362 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setConfig(int index, CapabilitiesPb.CapabilityConfig.Builder builderForValue) {
/*  366 */         ensureConfigIsMutable();
/*  367 */         this.config_.set(index, builderForValue.build());
/*  368 */         return this;
/*      */       }
/*      */       public Builder addConfig(CapabilitiesPb.CapabilityConfig value) {
/*  371 */         if (value == null) {
/*  372 */           throw new NullPointerException();
/*      */         }
/*  374 */         ensureConfigIsMutable();
/*  375 */         this.config_.add(value);
/*  376 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addConfig(CapabilitiesPb.CapabilityConfig.Builder builderForValue) {
/*  380 */         ensureConfigIsMutable();
/*  381 */         this.config_.add(builderForValue.build());
/*  382 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder addAllConfig(Iterable<? extends CapabilitiesPb.CapabilityConfig> values) {
/*  386 */         ensureConfigIsMutable();
/*  387 */         GeneratedMessage.Builder.addAll(values, this.config_);
/*  388 */         return this;
/*      */       }
/*      */       public Builder clearConfig() {
/*  391 */         this.config_ = Collections.emptyList();
/*  392 */         this.isConfigMutable = false;
/*  393 */         return this;
/*      */       }
/*      */ 
/*      */       public boolean hasDefaultConfig()
/*      */       {
/*  400 */         return this.hasDefaultConfig;
/*      */       }
/*      */       public CapabilitiesPb.CapabilityConfig getDefaultConfig() {
/*  403 */         return this.defaultConfig_;
/*      */       }
/*      */       public Builder setDefaultConfig(CapabilitiesPb.CapabilityConfig value) {
/*  406 */         if (value == null) {
/*  407 */           throw new NullPointerException();
/*      */         }
/*  409 */         this.hasDefaultConfig = true;
/*  410 */         this.defaultConfig_ = value;
/*  411 */         return this;
/*      */       }
/*      */ 
/*      */       public Builder setDefaultConfig(CapabilitiesPb.CapabilityConfig.Builder builderForValue) {
/*  415 */         this.hasDefaultConfig = true;
/*  416 */         this.defaultConfig_ = builderForValue.build();
/*  417 */         return this;
/*      */       }
/*      */       public Builder mergeDefaultConfig(CapabilitiesPb.CapabilityConfig value) {
/*  420 */         if ((this.hasDefaultConfig) && (this.defaultConfig_ != CapabilitiesPb.CapabilityConfig.getDefaultInstance()))
/*      */         {
/*  422 */           this.defaultConfig_ = CapabilitiesPb.CapabilityConfig.newBuilder(this.defaultConfig_).mergeFrom(value).buildPartial();
/*      */         }
/*      */         else {
/*  425 */           this.defaultConfig_ = value;
/*      */         }
/*  427 */         this.hasDefaultConfig = true;
/*  428 */         return this;
/*      */       }
/*      */       public Builder clearDefaultConfig() {
/*  431 */         this.hasDefaultConfig = false;
/*  432 */         this.defaultConfig_ = CapabilitiesPb.CapabilityConfig.getDefaultInstance();
/*  433 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.CapabilitiesPb
 * JD-Core Version:    0.6.0
 */