/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ class AppIdNamespace
/*     */   implements Serializable, Comparable<AppIdNamespace>
/*     */ {
/*     */   private final String appId;
/*     */   private final String namespace;
/*     */   private static final String BAD_APP_ID_MESSAGE = "appId or namespace cannot contain '!'";
/*     */ 
/*     */   public AppIdNamespace(String appId, String namespace)
/*     */   {
/*  32 */     if ((appId == null) || (namespace == null)) {
/*  33 */       throw new IllegalArgumentException("appId or namespace may not be null");
/*     */     }
/*  35 */     if ((appId.indexOf('!') != -1) || (namespace.indexOf('!') != -1))
/*     */     {
/*  37 */       throw new IllegalArgumentException("appId or namespace cannot contain '!'");
/*     */     }
/*     */ 
/*  43 */     this.appId = appId;
/*  44 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public static AppIdNamespace parseEncodedAppIdNamespace(String encodedAppIdNamespace)
/*     */   {
/*  63 */     if (encodedAppIdNamespace == null) {
/*  64 */       throw new IllegalArgumentException("appIdNamespaceString may not be null");
/*     */     }
/*  66 */     int index = encodedAppIdNamespace.indexOf('!');
/*  67 */     if (index == -1) {
/*  68 */       return new AppIdNamespace(encodedAppIdNamespace, "");
/*     */     }
/*  70 */     String appId = encodedAppIdNamespace.substring(0, index);
/*  71 */     String namespace = encodedAppIdNamespace.substring(index + 1);
/*  72 */     if (namespace.length() == 0) {
/*  73 */       throw new IllegalArgumentException("encodedAppIdNamespace with empty namespace may not contain a '!'");
/*     */     }
/*     */ 
/*  77 */     return new AppIdNamespace(appId, namespace);
/*     */   }
/*     */ 
/*     */   public int compareTo(AppIdNamespace other)
/*     */   {
/*  86 */     int appidCompare = this.appId.compareTo(other.appId);
/*  87 */     if (appidCompare == 0) {
/*  88 */       return this.namespace.compareTo(other.namespace);
/*     */     }
/*  90 */     return appidCompare;
/*     */   }
/*     */ 
/*     */   public String getAppId() {
/*  94 */     return this.appId;
/*     */   }
/*     */ 
/*     */   public String getNamespace() {
/*  98 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public String toEncodedString()
/*     */   {
/* 107 */     if (this.namespace.equals("")) {
/* 108 */       return this.appId;
/*     */     }
/* 110 */     return this.appId + '!' + this.namespace;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 117 */     int prime = 31;
/* 118 */     int result = 1;
/* 119 */     result = 31 * result + (this.appId == null ? 0 : this.appId.hashCode());
/* 120 */     result = 31 * result + (this.namespace == null ? 0 : this.namespace.hashCode());
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 126 */     if (this == obj) {
/* 127 */       return true;
/*     */     }
/* 129 */     if (obj == null) {
/* 130 */       return false;
/*     */     }
/* 132 */     if (getClass() != obj.getClass()) {
/* 133 */       return false;
/*     */     }
/* 135 */     AppIdNamespace other = (AppIdNamespace)obj;
/* 136 */     if (this.appId == null) {
/* 137 */       if (other.appId != null)
/* 138 */         return false;
/*     */     }
/* 140 */     else if (!this.appId.equals(other.appId)) {
/* 141 */       return false;
/*     */     }
/* 143 */     if (this.namespace == null) {
/* 144 */       if (other.namespace != null)
/* 145 */         return false;
/*     */     }
/* 147 */     else if (!this.namespace.equals(other.namespace)) {
/* 148 */       return false;
/*     */     }
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 155 */     return toEncodedString();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.AppIdNamespace
 * JD-Core Version:    0.6.0
 */