/*    */ package com.google.appengine.api.channel;
/*    */ 
/*    */ import com.google.apphosting.api.ApiProxy;
/*    */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ class ChannelServiceImpl
/*    */   implements ChannelService
/*    */ {
/*    */   public static final String PACKAGE = "channel";
/*    */   public static final String APPLICATION_KEY_PARAM = "key";
/*    */   public static final String MESSAGE_PARAM = "msg";
/*    */ 
/*    */   public String createChannel(String applicationKey)
/*    */   {
/* 25 */     ChannelServicePb.CreateChannelRequest request = new ChannelServicePb.CreateChannelRequest().setApplicationKey(applicationKey);
/*    */     byte[] responseBytes;
/*    */     try
/*    */     {
/* 30 */       responseBytes = ApiProxy.makeSyncCall("channel", "CreateChannel", request.toByteArray());
/*    */     } catch (ApiProxy.ApplicationException e) {
/* 32 */       switch (1.$SwitchMap$com$google$appengine$api$channel$ChannelServicePb$ChannelServiceError$ErrorCode[ChannelServicePb.ChannelServiceError.ErrorCode.valueOf(e.getApplicationError()).ordinal()]) {
/*    */       case 1:
/* 34 */         throw new ChannelFailureException("An internal channel error occured.");
/*    */       }
/*    */     }
/* 36 */     throw new ChannelFailureException("An unexpected error occurred.", e);
/*    */ 
/* 40 */     ChannelServicePb.CreateChannelResponse response = new ChannelServicePb.CreateChannelResponse();
/* 41 */     response.mergeFrom(responseBytes);
/* 42 */     return response.getClientId();
/*    */   }
/*    */ 
/*    */   public void sendMessage(ChannelMessage message)
/*    */   {
/* 47 */     ChannelServicePb.SendMessageRequest request = new ChannelServicePb.SendMessageRequest().setApplicationKey(message.getApplicationKey()).setMessage(message.getMessage());
/*    */     try
/*    */     {
/* 53 */       responseBytes = ApiProxy.makeSyncCall("channel", "SendChannelMessage", request.toByteArray());
/*    */     }
/*    */     catch (ApiProxy.ApplicationException e)
/*    */     {
/*    */       byte[] responseBytes;
/* 55 */       switch (1.$SwitchMap$com$google$appengine$api$channel$ChannelServicePb$ChannelServiceError$ErrorCode[ChannelServicePb.ChannelServiceError.ErrorCode.valueOf(e.getApplicationError()).ordinal()]) {
/*    */       case 1:
/* 57 */         throw new ChannelFailureException("An internal channel error occured.");
/*    */       }
/*    */     }
/* 59 */     throw new ChannelFailureException("An unexpected error occurred.", e);
/*    */   }
/*    */ 
/*    */   public ChannelMessage parseMessage(HttpServletRequest request)
/*    */   {
/* 66 */     String channelId = request.getParameter("key");
/* 67 */     String message = request.getParameter("msg");
/*    */ 
/* 69 */     if (channelId == null) {
/* 70 */       throw new IllegalStateException("Application key parameter not found in HTTP request.");
/*    */     }
/*    */ 
/* 73 */     if (message == null) {
/* 74 */       throw new IllegalStateException("Message parameter not found in HTTP request.");
/*    */     }
/*    */ 
/* 77 */     return new ChannelMessage(channelId, message);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.channel.ChannelServiceImpl
 * JD-Core Version:    0.6.0
 */