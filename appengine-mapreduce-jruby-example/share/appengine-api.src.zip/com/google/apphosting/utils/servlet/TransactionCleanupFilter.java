/*    */ package com.google.apphosting.utils.servlet;
/*    */ 
/*    */ import com.google.appengine.api.datastore.DatastoreService;
/*    */ import com.google.appengine.api.datastore.DatastoreServiceFactory;
/*    */ import com.google.appengine.api.datastore.Transaction;
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ public class TransactionCleanupFilter
/*    */   implements Filter
/*    */ {
/* 32 */   private static final Logger logger = Logger.getLogger(TransactionCleanupFilter.class.getName());
/*    */   private DatastoreService datastoreService;
/*    */ 
/*    */   public void init(FilterConfig filterConfig)
/*    */   {
/* 37 */     this.datastoreService = getDatastoreService();
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
/*    */   {
/*    */     try {
/* 43 */       chain.doFilter(request, response);
/*    */     }
/*    */     finally
/*    */     {
/*    */       Collection txns;
/* 45 */       Collection txns = this.datastoreService.getActiveTransactions();
/* 46 */       if (!txns.isEmpty())
/* 47 */         handleAbandonedTxns(txns);
/*    */     }
/*    */   }
/*    */ 
/*    */   void handleAbandonedTxns(Collection<Transaction> txns)
/*    */   {
/* 55 */     for (Transaction txn : txns)
/*    */       try {
/* 57 */         logger.warning("Request completed without committing or rolling back transaction with id " + txn.getId() + ".  Transaction will be rolled back.");
/*    */ 
/* 59 */         txn.rollback();
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 63 */         logger.log(Level.SEVERE, "Swallowing an exception we received while trying to rollback abandoned transaction with id " + txn.getId(), e);
/*    */       }
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 70 */     this.datastoreService = null;
/*    */   }
/*    */ 
/*    */   DatastoreService getDatastoreService()
/*    */   {
/* 77 */     return DatastoreServiceFactory.getDatastoreService();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.utils.servlet.TransactionCleanupFilter
 * JD-Core Version:    0.6.0
 */