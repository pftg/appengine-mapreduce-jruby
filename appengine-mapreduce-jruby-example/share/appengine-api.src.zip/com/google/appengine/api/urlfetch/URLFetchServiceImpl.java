/*     */ package com.google.appengine.api.urlfetch;
/*     */ 
/*     */ import com.google.appengine.api.utils.FutureWrapper;
/*     */ import com.google.appengine.repackaged.com.google.protobuf.ByteString;
/*     */ import com.google.apphosting.api.ApiProxy;
/*     */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*     */ import com.google.apphosting.api.ApiProxy.ApplicationException;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ class URLFetchServiceImpl
/*     */   implements URLFetchService
/*     */ {
/*     */   static final String PACKAGE = "urlfetch";
/*  23 */   private static final Logger logger = Logger.getLogger(URLFetchServiceImpl.class.getName());
/*     */ 
/*     */   public HTTPResponse fetch(URL url) throws IOException {
/*  26 */     return fetch(new HTTPRequest(url));
/*     */   }
/*     */ 
/*  30 */   public HTTPResponse fetch(HTTPRequest request) throws IOException { URLFetchServicePb.URLFetchRequest requestProto = convertToPb(request);
/*     */     byte[] responseBytes;
/*     */     try {
/*  34 */       responseBytes = ApiProxy.makeSyncCall("urlfetch", "Fetch", requestProto.toByteArray(), createApiConfig(request.getFetchOptions()));
/*     */     }
/*     */     catch (ApiProxy.ApplicationException ex)
/*     */     {
/*  39 */       Throwable cause = convertApplicationException(requestProto, ex);
/*  40 */       if ((cause instanceof RuntimeException))
/*  41 */         throw ((RuntimeException)cause);
/*  42 */       if ((cause instanceof IOException)) {
/*  43 */         throw ((IOException)cause);
/*     */       }
/*  45 */       throw new RuntimeException(cause);
/*     */     }
/*     */ 
/*  49 */     URLFetchServicePb.URLFetchResponse responseProto = ((URLFetchServicePb.URLFetchResponse.Builder)URLFetchServicePb.URLFetchResponse.newBuilder().mergeFrom(responseBytes)).build();
/*  50 */     if ((!request.getFetchOptions().getAllowTruncate()) && (responseProto.getContentWasTruncated())) {
/*  51 */       throw new ResponseTooLargeException(request.getURL().toString());
/*     */     }
/*  53 */     return convertFromPb(responseProto); }
/*     */ 
/*     */   public Future<HTTPResponse> fetchAsync(URL url)
/*     */   {
/*  57 */     return fetchAsync(new HTTPRequest(url));
/*     */   }
/*     */ 
/*     */   public Future<HTTPResponse> fetchAsync(HTTPRequest request) {
/*  61 */     URLFetchServicePb.URLFetchRequest requestProto = convertToPb(request);
/*     */ 
/*  63 */     Future response = ApiProxy.makeAsyncCall("urlfetch", "Fetch", requestProto.toByteArray(), createApiConfig(request.getFetchOptions()));
/*     */ 
/*  67 */     return new FutureWrapper(response, request, requestProto) {
/*     */       protected HTTPResponse wrap(byte[] responseBytes) throws IOException {
/*  69 */         URLFetchServicePb.URLFetchResponse responseProto = ((URLFetchServicePb.URLFetchResponse.Builder)URLFetchServicePb.URLFetchResponse.newBuilder().mergeFrom(responseBytes)).build();
/*     */ 
/*  73 */         if ((!this.val$request.getFetchOptions().getAllowTruncate()) && (responseProto.getContentWasTruncated()))
/*     */         {
/*  75 */           throw new ResponseTooLargeException(this.val$request.getURL().toString());
/*     */         }
/*  77 */         return URLFetchServiceImpl.this.convertFromPb(responseProto);
/*     */       }
/*     */ 
/*     */       protected Throwable convertException(Throwable cause) {
/*  81 */         if ((cause instanceof ApiProxy.ApplicationException)) {
/*  82 */           return URLFetchServiceImpl.this.convertApplicationException(this.val$requestProto, (ApiProxy.ApplicationException)cause);
/*     */         }
/*  84 */         return cause;
/*     */       } } ;
/*     */   }
/*     */ 
/*     */   private ApiProxy.ApiConfig createApiConfig(FetchOptions options) {
/*  90 */     ApiProxy.ApiConfig apiConfig = new ApiProxy.ApiConfig();
/*  91 */     apiConfig.setDeadlineInSeconds(options.getDeadline());
/*  92 */     return apiConfig;
/*     */   }
/*     */ 
/*     */   private Throwable convertApplicationException(URLFetchServicePb.URLFetchRequest request, ApiProxy.ApplicationException ex)
/*     */   {
/*  99 */     URLFetchServicePb.URLFetchServiceError.ErrorCode errorCode = URLFetchServicePb.URLFetchServiceError.ErrorCode.valueOf(ex.getApplicationError());
/* 100 */     switch (2.$SwitchMap$com$google$appengine$api$urlfetch$URLFetchServicePb$URLFetchServiceError$ErrorCode[errorCode.ordinal()]) {
/*     */     case 1:
/* 102 */       return new MalformedURLException("Invalid URL: " + request.getUrl());
/*     */     case 2:
/* 104 */       return new ResponseTooLargeException(request.getUrl());
/*     */     case 3:
/* 106 */       return new IOException("Could not fetch URL: " + request.getUrl());
/*     */     case 4:
/* 108 */       return new IOException("Timeout while fetching: " + request.getUrl());
/*     */     case 5:
/*     */     }
/* 111 */     return new IOException(ex.getErrorDetail());
/*     */   }
/*     */ 
/*     */   private URLFetchServicePb.URLFetchRequest convertToPb(HTTPRequest request)
/*     */   {
/* 116 */     URLFetchServicePb.URLFetchRequest.Builder requestProto = URLFetchServicePb.URLFetchRequest.newBuilder();
/* 117 */     requestProto.setUrl(request.getURL().toExternalForm());
/*     */ 
/* 119 */     byte[] payload = request.getPayload();
/* 120 */     if (payload != null) {
/* 121 */       requestProto.setPayload(ByteString.copyFrom(payload));
/*     */     }
/*     */ 
/* 124 */     switch (2.$SwitchMap$com$google$appengine$api$urlfetch$HTTPMethod[request.getMethod().ordinal()]) {
/*     */     case 1:
/* 126 */       requestProto.setMethod(URLFetchServicePb.URLFetchRequest.RequestMethod.GET);
/* 127 */       break;
/*     */     case 2:
/* 129 */       requestProto.setMethod(URLFetchServicePb.URLFetchRequest.RequestMethod.POST);
/* 130 */       break;
/*     */     case 3:
/* 132 */       requestProto.setMethod(URLFetchServicePb.URLFetchRequest.RequestMethod.HEAD);
/* 133 */       break;
/*     */     case 4:
/* 135 */       requestProto.setMethod(URLFetchServicePb.URLFetchRequest.RequestMethod.PUT);
/* 136 */       break;
/*     */     case 5:
/* 138 */       requestProto.setMethod(URLFetchServicePb.URLFetchRequest.RequestMethod.DELETE);
/* 139 */       break;
/*     */     default:
/* 141 */       throw new IllegalArgumentException("unknown method: " + request.getMethod());
/*     */     }
/*     */ 
/* 144 */     for (HTTPHeader header : request.getHeaders()) {
/* 145 */       URLFetchServicePb.URLFetchRequest.Header.Builder headerProto = URLFetchServicePb.URLFetchRequest.Header.newBuilder();
/* 146 */       headerProto.setKey(header.getName());
/* 147 */       headerProto.setValue(header.getValue());
/* 148 */       requestProto.addHeader(headerProto);
/*     */     }
/*     */ 
/* 151 */     requestProto.setFollowRedirects(request.getFetchOptions().getFollowRedirects());
/*     */ 
/* 154 */     return requestProto.build();
/*     */   }
/*     */ 
/*     */   private HTTPResponse convertFromPb(URLFetchServicePb.URLFetchResponse responseProto) {
/* 158 */     HTTPResponse response = new HTTPResponse(responseProto.getStatusCode());
/* 159 */     if (responseProto.hasContent()) {
/* 160 */       response.setContent(responseProto.getContent().toByteArray());
/*     */     }
/*     */ 
/* 163 */     for (URLFetchServicePb.URLFetchResponse.Header header : responseProto.getHeaderList()) {
/* 164 */       response.addHeader(header.getKey(), header.getValue());
/*     */     }
/*     */ 
/* 167 */     if ((responseProto.hasFinalUrl()) && (responseProto.getFinalUrl().length() > 0)) {
/*     */       try
/*     */       {
/* 170 */         response.setFinalUrl(new URL(responseProto.getFinalUrl()));
/*     */       } catch (MalformedURLException e) {
/* 172 */         logger.severe("malformed final URL: " + e);
/*     */       }
/*     */     }
/*     */ 
/* 176 */     return response;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.urlfetch.URLFetchServiceImpl
 * JD-Core Version:    0.6.0
 */