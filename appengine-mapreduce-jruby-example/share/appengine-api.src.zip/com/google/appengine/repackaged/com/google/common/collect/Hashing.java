/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ 
/*    */ @GwtCompatible
/*    */ final class Hashing
/*    */ {
/*    */   private static final int MAX_TABLE_SIZE = 1073741824;
/*    */   private static final int CUTOFF = 536870912;
/*    */ 
/*    */   static int smear(int hashCode)
/*    */   {
/* 42 */     hashCode ^= hashCode >>> 20 ^ hashCode >>> 12;
/* 43 */     return hashCode ^ hashCode >>> 7 ^ hashCode >>> 4;
/*    */   }
/*    */ 
/*    */   static int chooseTableSize(int setSize)
/*    */   {
/* 59 */     if (setSize < 536870912) {
/* 60 */       return Integer.highestOneBit(setSize) << 2;
/*    */     }
/*    */ 
/* 64 */     Preconditions.checkArgument(setSize < 1073741824, "collection too large");
/* 65 */     return 1073741824;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Hashing
 * JD-Core Version:    0.6.0
 */