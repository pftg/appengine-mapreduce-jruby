/*    */ package com.google.appengine.repackaged.com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import com.google.common.annotations.GwtIncompatible;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ @GwtCompatible(serializable=true, emulated=true)
/*    */ public final class HashMultiset<E> extends AbstractMapBasedMultiset<E>
/*    */ {
/*    */ 
/*    */   @GwtIncompatible("Not needed in emulated source.")
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public static <E> HashMultiset<E> create()
/*    */   {
/* 43 */     return new HashMultiset();
/*    */   }
/*    */ 
/*    */   public static <E> HashMultiset<E> create(int distinctElements)
/*    */   {
/* 54 */     return new HashMultiset(distinctElements);
/*    */   }
/*    */ 
/*    */   public static <E> HashMultiset<E> create(Iterable<? extends E> elements)
/*    */   {
/* 63 */     HashMultiset multiset = create(Multisets.inferDistinctElements(elements));
/*    */ 
/* 65 */     Iterables.addAll(multiset, elements);
/* 66 */     return multiset;
/*    */   }
/*    */ 
/*    */   private HashMultiset() {
/* 70 */     super(new HashMap());
/*    */   }
/*    */ 
/*    */   private HashMultiset(int distinctElements) {
/* 74 */     super(new HashMap(Maps.capacity(distinctElements)));
/*    */   }
/*    */ 
/*    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*    */   private void writeObject(ObjectOutputStream stream)
/*    */     throws IOException
/*    */   {
/* 83 */     stream.defaultWriteObject();
/* 84 */     Serialization.writeMultiset(this, stream);
/*    */   }
/*    */ 
/*    */   @GwtIncompatible("java.io.ObjectInputStream")
/*    */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 90 */     stream.defaultReadObject();
/* 91 */     int distinctElements = Serialization.readCount(stream);
/* 92 */     setBackingMap(Maps.newHashMapWithExpectedSize(distinctElements));
/*    */ 
/* 94 */     Serialization.populateMultiset(this, stream, distinctElements);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.HashMultiset
 * JD-Core Version:    0.6.0
 */