/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.flags.Flag;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import com.google.common.flags.FlagSpec;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ public class RotatingLogStream extends OutputStream
/*     */ {
/*     */   private final String basename_;
/*     */   private final String linkname_;
/*     */   private final String extension_;
/*     */   private final DateFormat dateFormat_;
/*     */   private OutputStream output_;
/*     */   private long currentSize_;
/*     */   private long rotateSize_;
/*  66 */   private final List<Listener> listeners_ = Collections.synchronizedList(new ArrayList());
/*     */   private long currentCombinedLogSize_;
/*     */   private long maxCombinedLogSize_;
/*     */   private ArrayList<File> files_;
/*     */   private File currentFile_;
/*     */   private FileDescriptor currentFileDescriptor_;
/*     */   public static final long kDefaultRotateSize = 1887436800L;
/*  85 */   public static final SimpleDateFormat kDefaultDateFormat = new SimpleDateFormat("-yyyy_MM_dd_HH_mm_ss");
/*     */ 
/*     */   @FlagSpec(help="If enabled, then rotating logs will not create symbolic links from the base filename to the current log.  This is provided to avoid the Runtime.exec() call in RotatingLogStream that can cause OutOfMemoryError due to fork() temporarily doubling memory footprint.")
/*  93 */   private static final Flag<Boolean> skipLogSymLinkCreation = Flag.value(false);
/*     */ 
/* 118 */   private static volatile SymbolicLinkProvider symlinker = new SymbolicLinkProvider()
/*     */   {
/*     */     public void createSymbolicLink(String targetPath, String linkPath)
/*     */       throws IOException
/*     */     {
/* 127 */       Runtime.getRuntime().exec(new String[] { "/bin/ln", "-sf", targetPath, linkPath });
/*     */     }
/* 118 */   };
/*     */ 
/*     */   public static void setSymbolicLinkProvider(SymbolicLinkProvider p)
/*     */   {
/* 140 */     symlinker = p;
/*     */   }
/*     */ 
/*     */   RotatingLogStream(String basename, @Nullable String linkname, @Nullable String extension, @Nullable DateFormat dateFormat, boolean allowSymLinkCreation)
/*     */     throws IOException
/*     */   {
/* 162 */     this.dateFormat_ = dateFormat;
/* 163 */     this.basename_ = basename;
/* 164 */     this.linkname_ = (allowSymLinkCreation ? linkname : null);
/* 165 */     this.extension_ = extension;
/* 166 */     this.rotateSize_ = 1887436800L;
/* 167 */     openNewFile();
/*     */   }
/*     */ 
/*     */   public RotatingLogStream(String basename, @Nullable String linkname, @Nullable String extension, @Nullable DateFormat dateFormat)
/*     */     throws IOException
/*     */   {
/* 186 */     this(basename, linkname, extension, dateFormat, !((Boolean)skipLogSymLinkCreation.get()).booleanValue());
/*     */   }
/*     */ 
/*     */   public RotatingLogStream(String basename, @Nullable String linkname, @Nullable DateFormat dateFormat)
/*     */     throws IOException
/*     */   {
/* 201 */     this(basename, linkname, null, dateFormat);
/*     */   }
/*     */ 
/*     */   public RotatingLogStream(String basename) throws IOException
/*     */   {
/* 206 */     this(basename, basename, kDefaultDateFormat);
/*     */   }
/*     */ 
/*     */   public synchronized void rotate()
/*     */     throws IOException
/*     */   {
/* 216 */     flush();
/* 217 */     close();
/* 218 */     openNewFile();
/*     */   }
/*     */ 
/*     */   public synchronized void setRotateSize(long rotateSize)
/*     */   {
/* 223 */     this.rotateSize_ = rotateSize;
/*     */   }
/*     */ 
/*     */   public synchronized void setMaxCombinedLogSize(long maxCombinedLogSize)
/*     */   {
/* 233 */     if (maxCombinedLogSize < this.rotateSize_) {
/* 234 */       throw new IllegalArgumentException("Max combined log size should be >= single log rotate size");
/*     */     }
/*     */ 
/* 238 */     this.maxCombinedLogSize_ = maxCombinedLogSize;
/* 239 */     if (this.files_ == null)
/*     */     {
/* 241 */       this.files_ = findAllFilesWithBasenameAndExtension(this.basename_, this.extension_);
/* 242 */       long length = 0L;
/* 243 */       for (File file : this.files_) {
/* 244 */         length += file.length();
/*     */       }
/* 246 */       this.currentCombinedLogSize_ = length;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */     throws IOException
/*     */   {
/* 255 */     this.output_.close();
/* 256 */     this.output_ = null;
/*     */   }
/*     */ 
/*     */   public synchronized void flush() throws IOException
/*     */   {
/* 261 */     this.output_.flush();
/*     */   }
/*     */ 
/*     */   public synchronized void write(byte[] b) throws IOException
/*     */   {
/* 266 */     checkRotate(b.length);
/* 267 */     this.output_.write(b);
/*     */   }
/*     */ 
/*     */   public synchronized void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 274 */     checkRotate(len);
/* 275 */     this.output_.write(b, off, len);
/*     */   }
/*     */ 
/*     */   public synchronized void write(int b) throws IOException
/*     */   {
/* 280 */     checkRotate(1);
/* 281 */     this.output_.write(b);
/*     */   }
/*     */ 
/*     */   public File getCurrentFile()
/*     */   {
/* 288 */     return this.currentFile_;
/*     */   }
/*     */ 
/*     */   public FileDescriptor getCurrentFileDescriptor()
/*     */   {
/* 295 */     return this.currentFileDescriptor_;
/*     */   }
/*     */ 
/*     */   protected OutputStream wrapFileOutputStream(FileOutputStream fileOutputStream)
/*     */     throws IOException
/*     */   {
/* 308 */     return new BufferedOutputStream(fileOutputStream);
/*     */   }
/*     */ 
/*     */   private void openNewFile() throws IOException {
/* 312 */     String fn = getNextFilename();
/* 313 */     this.currentFile_ = new File(fn);
/* 314 */     if (this.files_ != null) {
/* 315 */       this.files_.add(this.currentFile_);
/*     */     }
/* 317 */     String absFn = this.currentFile_.getAbsolutePath();
/* 318 */     this.currentSize_ = this.currentFile_.length();
/*     */ 
/* 323 */     if ((this.rotateSize_ != 0L) && (this.currentSize_ >= this.rotateSize_)) {
/* 324 */       System.err.println("Current log files size >= rotate size for " + absFn);
/*     */     }
/*     */ 
/* 328 */     File parentFile = this.currentFile_.getParentFile();
/* 329 */     if (parentFile != null)
/*     */     {
/* 331 */       parentFile.mkdirs();
/*     */     }
/*     */ 
/* 334 */     FileOutputStream fileOutputStream = new FileOutputStream(fn, true);
/* 335 */     this.currentFileDescriptor_ = fileOutputStream.getFD();
/* 336 */     this.output_ = wrapFileOutputStream(fileOutputStream);
/*     */ 
/* 340 */     if (this.linkname_ != null)
/*     */     {
/* 344 */       String linkSrc = fn;
/* 345 */       int lastSlash = this.linkname_.lastIndexOf('/');
/* 346 */       if ((lastSlash != -1) && (linkSrc.startsWith(this.linkname_.substring(0, lastSlash + 1))))
/*     */       {
/* 348 */         linkSrc = linkSrc.substring(lastSlash + 1);
/*     */       }
/*     */ 
/* 351 */       symlinker.createSymbolicLink(linkSrc, this.linkname_);
/*     */     }
/*     */ 
/* 355 */     for (Listener listener : this.listeners_)
/* 356 */       listener.logFileCreated(this.output_);
/*     */   }
/*     */ 
/*     */   String getNextFilename()
/*     */   {
/* 365 */     if (this.extension_ == null) {
/* 366 */       return this.basename_ + this.dateFormat_.format(new Date());
/*     */     }
/* 368 */     return this.basename_ + this.dateFormat_.format(new Date()) + this.extension_;
/*     */   }
/*     */ 
/*     */   void checkRotate(int lenToWrite) throws IOException
/*     */   {
/* 373 */     if (this.files_ == null)
/*     */     {
/* 378 */       if ((this.currentSize_ + lenToWrite >= this.rotateSize_) && (new File(getNextFilename()).length() + lenToWrite < this.rotateSize_))
/*     */       {
/* 380 */         rotate();
/*     */       }
/*     */     }
/* 383 */     else if (this.currentSize_ + lenToWrite >= this.rotateSize_) {
/* 384 */       updateCombinedLogSizeForRotate(lenToWrite);
/* 385 */       rotate();
/*     */     }
/*     */ 
/* 392 */     this.currentSize_ += lenToWrite;
/*     */   }
/*     */ 
/*     */   void updateCombinedLogSizeForRotate(int lenToWrite) {
/* 396 */     if (this.files_ != null) {
/* 397 */       this.currentCombinedLogSize_ += this.currentSize_;
/* 398 */       long totalExpectedSize = this.currentCombinedLogSize_ + lenToWrite;
/* 399 */       if (totalExpectedSize >= this.maxCombinedLogSize_)
/*     */       {
/* 401 */         deleteOldestLogFiles(totalExpectedSize);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @VisibleForTesting
/*     */   long getCurrentCombinedLogSize() {
/* 408 */     return this.currentCombinedLogSize_;
/*     */   }
/*     */   @VisibleForTesting
/*     */   long getCurrentLogSize() {
/* 413 */     return this.currentSize_;
/*     */   }
/*     */ 
/*     */   private void deleteOldestLogFiles(long totalExpectedLogsSize) {
/* 417 */     while (totalExpectedLogsSize >= this.maxCombinedLogSize_) {
/* 418 */       if (this.files_.isEmpty()) {
/* 419 */         return;
/*     */       }
/* 421 */       int oldestFileIdx = 0;
/* 422 */       long oldestFileTimestamp = ((File)this.files_.get(oldestFileIdx)).lastModified();
/* 423 */       for (int i = 0; i < this.files_.size(); i++) {
/* 424 */         long timestamp = ((File)this.files_.get(i)).lastModified();
/* 425 */         if (timestamp < oldestFileTimestamp) {
/* 426 */           oldestFileTimestamp = timestamp;
/* 427 */           oldestFileIdx = i;
/*     */         }
/*     */       }
/*     */ 
/* 431 */       File f = (File)this.files_.remove(oldestFileIdx);
/* 432 */       long fLength = f.length();
/* 433 */       this.currentCombinedLogSize_ -= fLength;
/* 434 */       totalExpectedLogsSize -= fLength;
/*     */ 
/* 437 */       f.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addListener(Listener listener) {
/* 442 */     this.listeners_.add(listener);
/*     */   }
/*     */ 
/*     */   private ArrayList<File> findAllFilesWithBasenameAndExtension(String basename, @Nullable String extension)
/*     */   {
/* 447 */     String dir = ".";
/* 448 */     int dirSeparatorIdx = basename.lastIndexOf(File.separatorChar);
/* 449 */     if (dirSeparatorIdx != -1) {
/* 450 */       dir = basename.substring(0, dirSeparatorIdx);
/* 451 */       basename = basename.substring(dirSeparatorIdx + 1);
/*     */     }
/* 453 */     String relativeBaseName = basename;
/*     */ 
/* 455 */     File[] files = new File(dir).listFiles(new FilenameFilter(relativeBaseName, extension)
/*     */     {
/*     */       public boolean accept(File directory, String name) {
/* 458 */         if (name.equals(RotatingLogStream.this.linkname_)) {
/* 459 */           return false;
/*     */         }
/* 461 */         if (name.startsWith(this.val$relativeBaseName)) {
/* 462 */           if (this.val$extension != null) {
/* 463 */             return name.endsWith(this.val$extension);
/*     */           }
/*     */ 
/* 466 */           return true;
/*     */         }
/*     */ 
/* 469 */         return false;
/*     */       }
/*     */     });
/* 474 */     ArrayList result = new ArrayList();
/* 475 */     for (File file : files) {
/* 476 */       result.add(file);
/*     */     }
/* 478 */     return result;
/*     */   }
/*     */ 
/*     */   public static abstract interface SymbolicLinkProvider
/*     */   {
/*     */     public abstract void createSymbolicLink(String paramString1, String paramString2)
/*     */       throws IOException;
/*     */   }
/*     */ 
/*     */   public static abstract interface Listener
/*     */   {
/*     */     public abstract void logFileCreated(OutputStream paramOutputStream);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.RotatingLogStream
 * JD-Core Version:    0.6.0
 */