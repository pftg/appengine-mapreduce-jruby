/*    */ package com.google.appengine.repackaged.com.google.io.protocol;
/*    */ 
/*    */ import com.google.appengine.repackaged.com.google.common.base.Joiner;
/*    */ import com.google.appengine.repackaged.com.google.common.collect.ImmutableList;
/*    */ import java.util.ArrayDeque;
/*    */ import java.util.Deque;
/*    */ 
/*    */ public class MissingFieldVisitor extends BaseMessageVisitor
/*    */ {
/* 18 */   private String missingFieldName = null;
/* 19 */   private final Deque<String> stack = new ArrayDeque();
/*    */ 
/* 21 */   private static final Joiner FIELD_JOINER = Joiner.on('/');
/*    */ 
/*    */   public String getMissingFieldName()
/*    */   {
/* 33 */     return this.missingFieldName;
/*    */   }
/*    */ 
/*    */   public boolean shouldVisitField(ProtocolType.FieldType fieldType, int count)
/*    */   {
/* 38 */     if (this.missingFieldName != null) {
/* 39 */       return false;
/*    */     }
/*    */ 
/* 42 */     switch (1.$SwitchMap$com$google$io$protocol$ProtocolType$Presence[fieldType.getPresence().ordinal()]) {
/*    */     case 1:
/* 44 */       if (count == 0) {
/* 45 */         this.stack.push(fieldType.getName());
/* 46 */         this.missingFieldName = FIELD_JOINER.join(ImmutableList.copyOf(this.stack.descendingIterator()));
/*    */ 
/* 48 */         this.stack.pop();
/* 49 */         return false;
/*    */       }
/* 51 */       return true;
/*    */     case 2:
/*    */     case 3:
/* 55 */       return count > 0;
/*    */     }
/*    */ 
/* 58 */     throw new IllegalArgumentException("invalid presence on field: " + fieldType.getPresence());
/*    */   }
/*    */ 
/*    */   public void visitGroup(ProtocolType.FieldType fieldType, int index, ProtocolMessage value)
/*    */   {
/* 66 */     addHierarchy(fieldType, index);
/* 67 */     ProtocolType.visit(value, this);
/* 68 */     removeHierarchy();
/*    */   }
/*    */ 
/*    */   public void visitForeign(ProtocolType.FieldType fieldType, int index, ProtocolMessage value)
/*    */   {
/* 74 */     addHierarchy(fieldType, index);
/* 75 */     ProtocolType.visit(value, this);
/* 76 */     removeHierarchy();
/*    */   }
/*    */ 
/*    */   private void addHierarchy(ProtocolType.FieldType fieldType, int index) {
/* 80 */     String name = fieldType.getName();
/* 81 */     if (fieldType.getPresence() == ProtocolType.Presence.REPEATED) {
/* 82 */       name = name + "[" + index + "]";
/*    */     }
/* 84 */     this.stack.push(name);
/*    */   }
/*    */ 
/*    */   private void removeHierarchy() {
/* 88 */     this.stack.pop();
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.io.protocol.MissingFieldVisitor
 * JD-Core Version:    0.6.0
 */