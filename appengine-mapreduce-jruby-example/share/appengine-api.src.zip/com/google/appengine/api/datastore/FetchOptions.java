/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class FetchOptions
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final int DEFAULT_CHUNK_SIZE = 20;
/*     */   private Integer limit;
/*     */   private Integer offset;
/*     */   private Integer prefetchSize;
/*     */   private Integer chunkSize;
/*     */   private Cursor startCursor;
/*     */   private Cursor endCursor;
/*     */   private Boolean compile;
/*     */ 
/*     */   private FetchOptions()
/*     */   {
/*     */   }
/*     */ 
/*     */   FetchOptions(FetchOptions original)
/*     */   {
/*  77 */     this.limit = original.limit;
/*  78 */     this.offset = original.offset;
/*  79 */     this.prefetchSize = original.prefetchSize;
/*  80 */     this.chunkSize = original.chunkSize;
/*  81 */     this.startCursor = original.startCursor;
/*  82 */     this.endCursor = original.endCursor;
/*  83 */     this.compile = original.compile;
/*     */   }
/*     */ 
/*     */   public FetchOptions limit(int limit)
/*     */   {
/*  93 */     if (limit < 1) {
/*  94 */       throw new IllegalArgumentException("Limit must be greater than 0.");
/*     */     }
/*  96 */     this.limit = Integer.valueOf(limit);
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearLimit() {
/* 101 */     this.limit = null;
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions offset(int offset)
/*     */   {
/* 112 */     if (offset < 0)
/*     */     {
/* 115 */       throw new IllegalArgumentException("Offset must be 0 or greater.");
/*     */     }
/* 117 */     this.offset = Integer.valueOf(offset);
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearOffset() {
/* 122 */     this.offset = null;
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions chunkSize(int chunkSize)
/*     */   {
/* 133 */     if (chunkSize < 1) {
/* 134 */       throw new IllegalArgumentException("Chunk size must be greater than 0.");
/*     */     }
/* 136 */     this.chunkSize = Integer.valueOf(chunkSize);
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearChunkSize() {
/* 141 */     this.chunkSize = null;
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions prefetchSize(int prefetchSize)
/*     */   {
/* 151 */     if (prefetchSize < 0) {
/* 152 */       throw new IllegalArgumentException("Prefetch size must be 0 or greater.");
/*     */     }
/* 154 */     this.prefetchSize = Integer.valueOf(prefetchSize);
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearPrefetchSize() {
/* 159 */     this.prefetchSize = null;
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public FetchOptions cursor(Cursor cursor)
/*     */   {
/* 171 */     return startCursor(cursor);
/*     */   }
/*     */ 
/*     */   public FetchOptions startCursor(Cursor startCursor)
/*     */   {
/* 181 */     if (startCursor == null) {
/* 182 */       throw new NullPointerException("start cursor cannot be null.");
/*     */     }
/* 184 */     this.startCursor = startCursor;
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */   public FetchOptions endCursor(Cursor endCursor)
/*     */   {
/* 195 */     if (endCursor == null) {
/* 196 */       throw new NullPointerException("end cursor cannot be null.");
/*     */     }
/* 198 */     this.endCursor = endCursor;
/* 199 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearStartCursor() {
/* 203 */     this.startCursor = null;
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearEndCursor() {
/* 208 */     this.endCursor = null;
/* 209 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions compile(boolean compile) {
/* 213 */     this.compile = Boolean.valueOf(compile);
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   FetchOptions clearCompile() {
/* 218 */     this.compile = null;
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   public Integer getLimit()
/*     */   {
/* 226 */     return this.limit;
/*     */   }
/*     */ 
/*     */   public Integer getOffset()
/*     */   {
/* 233 */     return this.offset;
/*     */   }
/*     */ 
/*     */   public Integer getChunkSize()
/*     */   {
/* 240 */     return this.chunkSize;
/*     */   }
/*     */ 
/*     */   public Integer getPrefetchSize()
/*     */   {
/* 248 */     return this.prefetchSize;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Cursor getCursor()
/*     */   {
/* 257 */     return getStartCursor();
/*     */   }
/*     */ 
/*     */   public Cursor getStartCursor()
/*     */   {
/* 264 */     return this.startCursor;
/*     */   }
/*     */ 
/*     */   public Cursor getEndCursor()
/*     */   {
/* 271 */     return this.endCursor;
/*     */   }
/*     */ 
/*     */   Boolean getCompile() {
/* 275 */     return this.compile;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 280 */     int result = 0;
/*     */ 
/* 282 */     if (this.prefetchSize != null) {
/* 283 */       result = result * 31 + this.prefetchSize.hashCode();
/*     */     }
/*     */ 
/* 286 */     if (this.chunkSize != null) {
/* 287 */       result = result * 31 + this.chunkSize.hashCode();
/*     */     }
/*     */ 
/* 290 */     if (this.limit != null) {
/* 291 */       result = result * 31 + this.limit.hashCode();
/*     */     }
/*     */ 
/* 294 */     if (this.offset != null) {
/* 295 */       result = result * 31 + this.offset.hashCode();
/*     */     }
/*     */ 
/* 298 */     if (this.startCursor != null) {
/* 299 */       result = result * 31 + this.startCursor.hashCode();
/*     */     }
/*     */ 
/* 302 */     if (this.endCursor != null) {
/* 303 */       result = result * 31 + this.endCursor.hashCode();
/*     */     }
/*     */ 
/* 306 */     if (this.compile != null) {
/* 307 */       result = result * 31 + this.compile.hashCode();
/*     */     }
/*     */ 
/* 310 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 315 */     if (obj == null) {
/* 316 */       return false;
/*     */     }
/*     */ 
/* 319 */     if (obj.getClass() != getClass()) {
/* 320 */       return false;
/*     */     }
/*     */ 
/* 323 */     FetchOptions that = (FetchOptions)obj;
/*     */ 
/* 325 */     if (this.prefetchSize != null) {
/* 326 */       if (!this.prefetchSize.equals(that.prefetchSize))
/* 327 */         return false;
/*     */     }
/* 329 */     else if (that.prefetchSize != null) {
/* 330 */       return false;
/*     */     }
/*     */ 
/* 333 */     if (this.chunkSize != null) {
/* 334 */       if (!this.chunkSize.equals(that.chunkSize))
/* 335 */         return false;
/*     */     }
/* 337 */     else if (that.chunkSize != null) {
/* 338 */       return false;
/*     */     }
/*     */ 
/* 341 */     if (this.limit != null) {
/* 342 */       if (!this.limit.equals(that.limit))
/* 343 */         return false;
/*     */     }
/* 345 */     else if (that.limit != null) {
/* 346 */       return false;
/*     */     }
/*     */ 
/* 349 */     if (this.offset != null) {
/* 350 */       if (!this.offset.equals(that.offset))
/* 351 */         return false;
/*     */     }
/* 353 */     else if (that.offset != null) {
/* 354 */       return false;
/*     */     }
/*     */ 
/* 357 */     if (this.startCursor != null) {
/* 358 */       if (!this.startCursor.equals(that.startCursor))
/* 359 */         return false;
/*     */     }
/* 361 */     else if (that.startCursor != null) {
/* 362 */       return false;
/*     */     }
/*     */ 
/* 365 */     if (this.endCursor != null) {
/* 366 */       if (!this.endCursor.equals(that.endCursor))
/* 367 */         return false;
/*     */     }
/* 369 */     else if (that.endCursor != null) {
/* 370 */       return false;
/*     */     }
/*     */ 
/* 373 */     if (this.compile != null) {
/* 374 */       if (!this.compile.equals(that.compile))
/* 375 */         return false;
/*     */     }
/* 377 */     else if (that.compile != null) {
/* 378 */       return false;
/*     */     }
/*     */ 
/* 381 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 386 */     List result = new ArrayList();
/*     */ 
/* 388 */     if (this.prefetchSize != null) {
/* 389 */       result.add("prefetchSize=" + this.prefetchSize);
/*     */     }
/*     */ 
/* 392 */     if (this.chunkSize != null) {
/* 393 */       result.add("chunkSize=" + this.chunkSize);
/*     */     }
/*     */ 
/* 396 */     if (this.limit != null) {
/* 397 */       result.add("limit=" + this.limit);
/*     */     }
/*     */ 
/* 400 */     if (this.offset != null) {
/* 401 */       result.add("offset=" + this.offset);
/*     */     }
/*     */ 
/* 404 */     if (this.startCursor != null) {
/* 405 */       result.add("startCursor=" + this.startCursor);
/*     */     }
/*     */ 
/* 408 */     if (this.endCursor != null) {
/* 409 */       result.add("endCursor=" + this.endCursor);
/*     */     }
/*     */ 
/* 412 */     if (this.compile != null) {
/* 413 */       result.add("compile=" + this.compile);
/*     */     }
/* 415 */     return "FetchOptions" + result;
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*     */     public static FetchOptions withLimit(int limit)
/*     */     {
/* 432 */       return withDefaults().limit(limit);
/*     */     }
/*     */ 
/*     */     public static FetchOptions withOffset(int offset)
/*     */     {
/* 444 */       return withDefaults().offset(offset);
/*     */     }
/*     */ 
/*     */     public static FetchOptions withChunkSize(int chunkSize)
/*     */     {
/* 456 */       return withDefaults().chunkSize(chunkSize);
/*     */     }
/*     */ 
/*     */     public static FetchOptions withPrefetchSize(int prefetchSize)
/*     */     {
/* 468 */       return withDefaults().prefetchSize(prefetchSize);
/*     */     }
/*     */ 
/*     */     @Deprecated
/*     */     public static FetchOptions withCursor(Cursor cursor)
/*     */     {
/* 482 */       return withStartCursor(cursor);
/*     */     }
/*     */ 
/*     */     public static FetchOptions withStartCursor(Cursor startCursor)
/*     */     {
/* 494 */       return withDefaults().startCursor(startCursor);
/*     */     }
/*     */ 
/*     */     public static FetchOptions withEndCursor(Cursor endCursor)
/*     */     {
/* 506 */       return withDefaults().endCursor(endCursor);
/*     */     }
/*     */ 
/*     */     public static FetchOptions withDefaults()
/*     */     {
/* 514 */       return new FetchOptions(null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.FetchOptions
 * JD-Core Version:    0.6.0
 */