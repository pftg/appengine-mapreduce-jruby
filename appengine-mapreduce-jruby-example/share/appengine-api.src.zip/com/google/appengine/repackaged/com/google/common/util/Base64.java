/*     */ package com.google.appengine.repackaged.com.google.common.util;
/*     */ 
/*     */ public final class Base64
/*     */ {
/*     */   private static final byte PADDING_BYTE = 61;
/*     */   private static final byte NEW_LINE = 10;
/*     */   public static final byte[] ALPHABET;
/*     */   public static final byte[] WEBSAFE_ALPHABET;
/*     */   private static final byte[] DECODABET;
/*     */   private static final byte[] WEBSAFE_DECODABET;
/*     */   private static final byte WHITE_SPACE_ENC = -5;
/*     */   private static final byte EQUALS_SIGN_ENC = -1;
/*     */ 
/*     */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset, byte[] alphabet)
/*     */   {
/* 211 */     int inBuff = (numSigBytes > 0 ? source[srcOffset] << 24 >>> 8 : 0) | (numSigBytes > 1 ? source[(srcOffset + 1)] << 24 >>> 16 : 0) | (numSigBytes > 2 ? source[(srcOffset + 2)] << 24 >>> 24 : 0);
/*     */ 
/* 216 */     switch (numSigBytes) {
/*     */     case 3:
/* 218 */       destination[destOffset] = alphabet[(inBuff >>> 18)];
/* 219 */       destination[(destOffset + 1)] = alphabet[(inBuff >>> 12 & 0x3F)];
/* 220 */       destination[(destOffset + 2)] = alphabet[(inBuff >>> 6 & 0x3F)];
/* 221 */       destination[(destOffset + 3)] = alphabet[(inBuff & 0x3F)];
/* 222 */       return destination;
/*     */     case 2:
/* 224 */       destination[destOffset] = alphabet[(inBuff >>> 18)];
/* 225 */       destination[(destOffset + 1)] = alphabet[(inBuff >>> 12 & 0x3F)];
/* 226 */       destination[(destOffset + 2)] = alphabet[(inBuff >>> 6 & 0x3F)];
/* 227 */       destination[(destOffset + 3)] = 61;
/* 228 */       return destination;
/*     */     case 1:
/* 230 */       destination[destOffset] = alphabet[(inBuff >>> 18)];
/* 231 */       destination[(destOffset + 1)] = alphabet[(inBuff >>> 12 & 0x3F)];
/* 232 */       destination[(destOffset + 2)] = 61;
/* 233 */       destination[(destOffset + 3)] = 61;
/* 234 */       return destination;
/*     */     }
/* 236 */     return destination;
/*     */   }
/*     */ 
/*     */   public static String encode(byte[] source)
/*     */   {
/* 249 */     return encode(source, 0, source.length, ALPHABET, true);
/*     */   }
/*     */ 
/*     */   public static String encodeWebSafe(byte[] source, boolean doPadding)
/*     */   {
/* 260 */     return encode(source, 0, source.length, WEBSAFE_ALPHABET, doPadding);
/*     */   }
/*     */ 
/*     */   public static String encode(byte[] source, int off, int len, byte[] alphabet, boolean doPadding)
/*     */   {
/* 276 */     byte[] outBuff = encode(source, off, len, alphabet, 2147483647);
/* 277 */     int outLen = outBuff.length;
/*     */ 
/* 281 */     while ((!doPadding) && (outLen > 0) && 
/* 282 */       (outBuff[(outLen - 1)] == 61))
/*     */     {
/* 285 */       outLen--;
/*     */     }
/*     */ 
/* 288 */     return new String(outBuff, 0, outLen);
/*     */   }
/*     */ 
/*     */   public static byte[] encode(byte[] source, int off, int len, byte[] alphabet, int maxLineLength)
/*     */   {
/* 303 */     int lenDiv3 = (len + 2) / 3;
/* 304 */     int len43 = lenDiv3 * 4;
/* 305 */     byte[] outBuff = new byte[len43 + len43 / maxLineLength];
/*     */ 
/* 308 */     int d = 0;
/* 309 */     int e = 0;
/* 310 */     int len2 = len - 2;
/* 311 */     int lineLength = 0;
/* 312 */     for (; d < len2; e += 4)
/*     */     {
/* 317 */       int inBuff = source[(d + off)] << 24 >>> 8 | source[(d + 1 + off)] << 24 >>> 16 | source[(d + 2 + off)] << 24 >>> 24;
/*     */ 
/* 321 */       outBuff[e] = alphabet[(inBuff >>> 18)];
/* 322 */       outBuff[(e + 1)] = alphabet[(inBuff >>> 12 & 0x3F)];
/* 323 */       outBuff[(e + 2)] = alphabet[(inBuff >>> 6 & 0x3F)];
/* 324 */       outBuff[(e + 3)] = alphabet[(inBuff & 0x3F)];
/*     */ 
/* 326 */       lineLength += 4;
/* 327 */       if (lineLength == maxLineLength) {
/* 328 */         outBuff[(e + 4)] = 10;
/* 329 */         e++;
/* 330 */         lineLength = 0;
/*     */       }
/* 312 */       d += 3;
/*     */     }
/*     */ 
/* 334 */     if (d < len) {
/* 335 */       encode3to4(source, d + off, len - d, outBuff, e, alphabet);
/*     */ 
/* 337 */       lineLength += 4;
/* 338 */       if (lineLength == maxLineLength)
/*     */       {
/* 340 */         outBuff[(e + 4)] = 10;
/* 341 */         e++;
/*     */       }
/* 343 */       e += 4;
/*     */     }
/*     */ 
/* 346 */     assert (e == outBuff.length);
/* 347 */     return outBuff;
/*     */   }
/*     */ 
/*     */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset, byte[] decodabet)
/*     */   {
/* 380 */     if (source[(srcOffset + 2)] == 61) {
/* 381 */       int outBuff = decodabet[source[srcOffset]] << 24 >>> 6 | decodabet[source[(srcOffset + 1)]] << 24 >>> 12;
/*     */ 
/* 385 */       destination[destOffset] = (byte)(outBuff >>> 16);
/* 386 */       return 1;
/* 387 */     }if (source[(srcOffset + 3)] == 61)
/*     */     {
/* 389 */       int outBuff = decodabet[source[srcOffset]] << 24 >>> 6 | decodabet[source[(srcOffset + 1)]] << 24 >>> 12 | decodabet[source[(srcOffset + 2)]] << 24 >>> 18;
/*     */ 
/* 394 */       destination[destOffset] = (byte)(outBuff >>> 16);
/* 395 */       destination[(destOffset + 1)] = (byte)(outBuff >>> 8);
/* 396 */       return 2;
/*     */     }
/*     */ 
/* 399 */     int outBuff = decodabet[source[srcOffset]] << 24 >>> 6 | decodabet[source[(srcOffset + 1)]] << 24 >>> 12 | decodabet[source[(srcOffset + 2)]] << 24 >>> 18 | decodabet[source[(srcOffset + 3)]] << 24 >>> 24;
/*     */ 
/* 405 */     destination[destOffset] = (byte)(outBuff >> 16);
/* 406 */     destination[(destOffset + 1)] = (byte)(outBuff >> 8);
/* 407 */     destination[(destOffset + 2)] = (byte)outBuff;
/* 408 */     return 3;
/*     */   }
/*     */ 
/*     */   public static byte[] decode(String s)
/*     */     throws Base64DecoderException
/*     */   {
/* 423 */     byte[] bytes = s.getBytes();
/* 424 */     return decode(bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   public static byte[] decodeWebSafe(String s)
/*     */     throws Base64DecoderException
/*     */   {
/* 435 */     byte[] bytes = s.getBytes();
/* 436 */     return decodeWebSafe(bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   public static byte[] decode(byte[] source)
/*     */     throws Base64DecoderException
/*     */   {
/* 449 */     return decode(source, 0, source.length);
/*     */   }
/*     */ 
/*     */   public static byte[] decodeWebSafe(byte[] source)
/*     */     throws Base64DecoderException
/*     */   {
/* 462 */     return decodeWebSafe(source, 0, source.length);
/*     */   }
/*     */ 
/*     */   public static byte[] decode(byte[] source, int off, int len)
/*     */     throws Base64DecoderException
/*     */   {
/* 478 */     return decode(source, off, len, DECODABET);
/*     */   }
/*     */ 
/*     */   public static byte[] decodeWebSafe(byte[] source, int off, int len)
/*     */     throws Base64DecoderException
/*     */   {
/* 493 */     return decode(source, off, len, WEBSAFE_DECODABET);
/*     */   }
/*     */ 
/*     */   public static byte[] decode(byte[] source, int off, int len, byte[] decodabet)
/*     */     throws Base64DecoderException
/*     */   {
/* 508 */     int len34 = len * 3 / 4;
/* 509 */     byte[] outBuff = new byte[2 + len34];
/* 510 */     int outBuffPosn = 0;
/*     */ 
/* 512 */     byte[] b4 = new byte[4];
/* 513 */     int b4Posn = 0;
/* 514 */     int i = 0;
/* 515 */     byte sbiCrop = 0;
/* 516 */     byte sbiDecode = 0;
/* 517 */     boolean paddingByteSeen = false;
/* 518 */     for (i = 0; i < len; i++) {
/* 519 */       sbiCrop = (byte)(source[(i + off)] & 0x7F);
/* 520 */       sbiDecode = decodabet[sbiCrop];
/*     */ 
/* 522 */       if (sbiDecode < -5) {
/* 523 */         throw new Base64DecoderException("Bad Base64 input character at " + i + ": " + source[(i + off)] + "(decimal)");
/*     */       }
/*     */ 
/* 527 */       if (sbiDecode < -1)
/*     */         continue;
/* 529 */       if (sbiCrop == 61) {
/* 530 */         if (paddingByteSeen)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 535 */         if (i < 2) {
/* 536 */           throw new Base64DecoderException("Invalid padding byte found in position " + i);
/*     */         }
/*     */ 
/* 539 */         paddingByteSeen = true;
/* 540 */         byte lastByte = (byte)(source[(len - 1 + off)] & 0x7F);
/* 541 */         if ((lastByte != 61) && (lastByte != 10))
/* 542 */           throw new Base64DecoderException("encoded value has invalid trailing byte");
/*     */       }
/*     */       else
/*     */       {
/* 546 */         if (paddingByteSeen) {
/* 547 */           throw new Base64DecoderException("Data found after trailing padding byte at index " + i);
/*     */         }
/*     */ 
/* 551 */         b4[(b4Posn++)] = sbiCrop;
/* 552 */         if (b4Posn == 4) {
/* 553 */           outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn, decodabet);
/* 554 */           b4Posn = 0;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 566 */     if (b4Posn != 0) {
/* 567 */       if (b4Posn == 1) {
/* 568 */         throw new Base64DecoderException("single trailing character at offset " + (len - 1));
/*     */       }
/*     */ 
/* 571 */       b4[b4Posn] = 61;
/* 572 */       outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn, decodabet);
/*     */     }
/*     */ 
/* 575 */     byte[] out = new byte[outBuffPosn];
/* 576 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/* 577 */     return out;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  57 */     ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */ 
/*  77 */     WEBSAFE_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
/*     */ 
/*  96 */     DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9 };
/*     */ 
/* 130 */     WEBSAFE_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, 63, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9 };
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.util.Base64
 * JD-Core Version:    0.6.0
 */