/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.Serializable;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible(serializable=true)
/*     */ final class RangeClosed<V extends Comparable<? super V>>
/*     */   implements Range<V>, Serializable
/*     */ {
/*     */   private final V min;
/*     */   private final V max;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   RangeClosed(V min, V max)
/*     */   {
/*  33 */     if (min == null) {
/*  34 */       throw new NullPointerException("Parameter 'min' is null.");
/*     */     }
/*  36 */     if (max == null) {
/*  37 */       throw new NullPointerException("Parameter 'max' is null.");
/*     */     }
/*  39 */     if (min.compareTo(max) > 0) {
/*  40 */       throw new IllegalArgumentException("Parameter 'min' cannot be greater than Parameter 'max'.");
/*     */     }
/*     */ 
/*  43 */     this.min = min;
/*  44 */     this.max = max;
/*     */   }
/*     */ 
/*     */   public boolean contains(V value) {
/*  48 */     return (value != null) && (this.min.compareTo(value) < 1) && (this.max.compareTo(value) > -1);
/*     */   }
/*     */ 
/*     */   public Range<V> enclose(V value)
/*     */   {
/*  53 */     if (value == null) {
/*  54 */       return this;
/*     */     }
/*  56 */     if (isEmpty()) {
/*  57 */       return new RangeClosed(value, value);
/*     */     }
/*  59 */     return this.max.compareTo(value) < 0 ? new RangeClosed(this.min, value) : this.min.compareTo(value) > 0 ? new RangeClosed(value, this.max) : this;
/*     */   }
/*     */ 
/*     */   public Range<V> enclosure(Range<V> range)
/*     */   {
/*  64 */     if (range.isEmpty()) {
/*  65 */       return this;
/*     */     }
/*  67 */     if (isEmpty()) {
/*  68 */       return range;
/*     */     }
/*  70 */     Comparable oMin = range.min();
/*  71 */     Comparable oMax = range.max();
/*  72 */     return new RangeClosed(oMin.compareTo(this.min) < 0 ? oMin : this.min, oMax.compareTo(this.max) > 0 ? oMax : this.max);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  80 */     return "[Range:" + this.min + ", " + this.max + "]";
/*     */   }
/*     */ 
/*     */   public boolean equals(@Nullable Object o) {
/*  84 */     if ((o instanceof Range)) {
/*  85 */       Range c = (Range)o;
/*     */       try {
/*  87 */         if (c.isEmpty()) {
/*  88 */           return false;
/*     */         }
/*  90 */         return (c.min().equals(this.min)) && (c.max().equals(this.max));
/*     */       }
/*     */       catch (ClassCastException e) {
/*  93 */         return false;
/*     */       }
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 101 */     return this.min.hashCode() * 555557 + this.max.hashCode();
/*     */   }
/*     */ 
/*     */   public Range<V> intersection(Range<V> range) {
/* 105 */     if (!intersects(range)) {
/* 106 */       return Ranges.emptyRange();
/*     */     }
/* 108 */     Comparable oMin = range.min();
/* 109 */     Comparable oMax = range.max();
/* 110 */     return new RangeClosed(oMin.compareTo(this.min) > 0 ? oMin : this.min, oMax.compareTo(this.max) < 0 ? oMax : this.max);
/*     */   }
/*     */ 
/*     */   public boolean intersects(Range<V> range)
/*     */   {
/* 116 */     if (range.isEmpty()) {
/* 117 */       return false;
/*     */     }
/* 119 */     return (this.max.compareTo(range.min()) > -1) && (this.min.compareTo(range.max()) < 1);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   public V max() {
/* 129 */     return this.max;
/*     */   }
/*     */ 
/*     */   public V min() {
/* 133 */     return this.min;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.RangeClosed
 * JD-Core Version:    0.6.0
 */