/*    */ package com.google.appengine.api.datastore;
/*    */ 
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Path;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Path.Element;
/*    */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*    */ import java.util.List;
/*    */ 
/*    */ public class EntityTranslator
/*    */ {
/*    */   public static Entity createFromPb(OnestoreEntity.EntityProto proto)
/*    */   {
/* 25 */     Key key = KeyTranslator.createFromPb(proto.getKey());
/*    */ 
/* 27 */     Entity entity = new Entity(key);
/* 28 */     entity.setEntityProto(proto);
/* 29 */     DataTypeTranslator.extractPropertiesFromPb(proto, entity.getPropertyMap());
/* 30 */     return entity;
/*    */   }
/*    */ 
/*    */   public static OnestoreEntity.EntityProto convertToPb(Entity entity) {
/* 34 */     OnestoreEntity.Reference reference = KeyTranslator.convertToPb(entity.getKey());
/*    */ 
/* 36 */     OnestoreEntity.EntityProto proto = new OnestoreEntity.EntityProto();
/* 37 */     proto.getMutableKey().mergeFrom(reference);
/*    */ 
/* 41 */     OnestoreEntity.Path entityGroup = proto.getMutableEntityGroup();
/* 42 */     Key key = entity.getKey();
/* 43 */     if (key.isComplete()) {
/* 44 */       entityGroup.addElement((OnestoreEntity.Path.Element)reference.getPath().elements().get(0));
/*    */     }
/*    */ 
/* 47 */     DataTypeTranslator.addPropertiesToPb(entity.getPropertyMap(), proto);
/* 48 */     return proto;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.EntityTranslator
 * JD-Core Version:    0.6.0
 */