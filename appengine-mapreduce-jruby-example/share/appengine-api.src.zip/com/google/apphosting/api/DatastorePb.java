/*       */ package com.google.apphosting.api;
/*       */ 
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.MessageAppender;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.Protocol;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessage;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolMessageEnum;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSink;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSource;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolSupport;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldBaseType;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.FieldType;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.ProtocolType.Presence;
/*       */ import com.google.appengine.repackaged.com.google.io.protocol.UninterpretedTags;
/*       */ import com.google.net.rpc.DefaultStubCreationFilter;
/*       */ import com.google.net.rpc.RPC;
/*       */ import com.google.net.rpc.RpcCallback;
/*       */ import com.google.net.rpc.RpcCancelCallback;
/*       */ import com.google.net.rpc.RpcException;
/*       */ import com.google.net.rpc.RpcInterface;
/*       */ import com.google.net.rpc.RpcServerParameters;
/*       */ import com.google.net.rpc.RpcService;
/*       */ import com.google.net.rpc.RpcStub;
/*       */ import com.google.net.rpc.RpcStubFactory;
/*       */ import com.google.net.rpc.RpcStubParameters;
/*       */ import com.google.net.rpc.StubCreationFilter;
/*       */ import com.google.net.rpc.impl.ApplicationHandler;
/*       */ import com.google.net.rpc.impl.BlockingApplicationHandler;
/*       */ import com.google.net.rpc.impl.RpcHandlerRegistry;
/*       */ import com.google.net.rpc.impl.RpcServerConfig;
/*       */ import com.google.net.rpc3.impl.compatibility.Rpc1CompatibilityStub;
/*       */ import com.google.net.rpc3.impl.compatibility.Rpc1HandlerRegistry;
/*       */ import com.google.net.rpc3.server.RpcServer.Builder;
/*       */ import com.google.net.ssl.SslSecurityLevel;
/*       */ import com.google.storage.onestore.v3.OnestoreAction.Action;
/*       */ import com.google.storage.onestore.v3.OnestoreEntity.CompositeIndex;
/*       */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*       */ import com.google.storage.onestore.v3.OnestoreEntity.Property;
/*       */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*       */ import java.nio.charset.Charset;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Arrays;
/*       */ import java.util.Iterator;
/*       */ import java.util.List;
/*       */ import java.util.concurrent.Executor;
/*       */ 
/*       */ public class DatastorePb
/*       */ {
/*       */   public static final class DatastoreService
/*       */   {
/* 16921 */     private static volatile StubCreationFilter stubCreationFilter_ = new DefaultStubCreationFilter();
/*       */ 
/* 16927 */     private static final RpcStubFactory stubFactory_ = new RpcStubFactory() {
/*       */       public RpcStub newRpcStub(RpcStubParameters params) {
/* 16929 */         return new DatastorePb.DatastoreService.SimpleStub(DatastorePb.DatastoreService.stubCreationFilter_.filterStubParameters("DatastoreService", params));
/*       */       }
/* 16927 */     };
/*       */ 
/*       */     public static void setStubCreationFilter(StubCreationFilter filter)
/*       */     {
/* 16924 */       stubCreationFilter_ = filter == null ? new DefaultStubCreationFilter() : filter;
/*       */     }
/*       */ 
/*       */     public static RpcStubFactory stubFactory()
/*       */     {
/* 16933 */       return stubFactory_;
/*       */     }
/*       */ 
/*       */     public static BlockingStub newBlockingStub(RpcStubParameters params)
/*       */     {
/* 17156 */       return new BlockingStub(stubCreationFilter_.filterStubParameters("DatastoreService", params));
/*       */     }
/*       */ 
/*       */     public static Stub newStub(RpcStubParameters params)
/*       */     {
/* 17269 */       return new Stub(stubCreationFilter_.filterStubParameters("DatastoreService", params));
/*       */     }
/*       */ 
/*       */     public static ServerConfig exportService(Interface service, RpcHandlerRegistry registry)
/*       */     {
/* 17570 */       ServerConfig config = new ServerConfig();
/* 17571 */       exportServiceUsingConfig(service, registry, config);
/* 17572 */       return config;
/*       */     }
/*       */ 
/*       */     public static void exportServiceUsingConfig(Interface service, RpcHandlerRegistry registry, ServerConfig config)
/*       */     {
/* 17578 */       registry.registerHandler(config.serviceName(), "Get", new DatastorePb.GetRequest(), new DatastorePb.GetResponse(), null, config.Get_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17582 */           this.val$service.get(rpc, (DatastorePb.GetRequest)rpc.internalRequest(), (DatastorePb.GetResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17586 */       registry.registerHandler(config.serviceName(), "Put", new DatastorePb.PutRequest(), new DatastorePb.PutResponse(), null, config.Put_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17590 */           this.val$service.put(rpc, (DatastorePb.PutRequest)rpc.internalRequest(), (DatastorePb.PutResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17594 */       registry.registerHandler(config.serviceName(), "Touch", new DatastorePb.TouchRequest(), new DatastorePb.TouchResponse(), null, config.Touch_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17598 */           this.val$service.touch(rpc, (DatastorePb.TouchRequest)rpc.internalRequest(), (DatastorePb.TouchResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17602 */       registry.registerHandler(config.serviceName(), "Delete", new DatastorePb.DeleteRequest(), new DatastorePb.DeleteResponse(), null, config.Delete_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17606 */           this.val$service.delete(rpc, (DatastorePb.DeleteRequest)rpc.internalRequest(), (DatastorePb.DeleteResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17610 */       registry.registerHandler(config.serviceName(), "RunQuery", new DatastorePb.Query(), new DatastorePb.QueryResult(), null, config.RunQuery_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17614 */           this.val$service.runQuery(rpc, (DatastorePb.Query)rpc.internalRequest(), (DatastorePb.QueryResult)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17618 */       registry.registerHandler(config.serviceName(), "RunCompiledQuery", new DatastorePb.RunCompiledQueryRequest(), new DatastorePb.QueryResult(), null, config.RunCompiledQuery_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17622 */           this.val$service.runCompiledQuery(rpc, (DatastorePb.RunCompiledQueryRequest)rpc.internalRequest(), (DatastorePb.QueryResult)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17626 */       registry.registerHandler(config.serviceName(), "AddAction", new DatastorePb.AddActionsRequest(), new DatastorePb.AddActionsResponse(), null, config.AddAction_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17630 */           this.val$service.addAction(rpc, (DatastorePb.AddActionsRequest)rpc.internalRequest(), (DatastorePb.AddActionsResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17634 */       registry.registerHandler(config.serviceName(), "AddActions", new DatastorePb.AddActionsRequest(), new DatastorePb.AddActionsResponse(), null, config.AddActions_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17638 */           this.val$service.addActions(rpc, (DatastorePb.AddActionsRequest)rpc.internalRequest(), (DatastorePb.AddActionsResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17642 */       registry.registerHandler(config.serviceName(), "Next", new DatastorePb.NextRequest(), new DatastorePb.QueryResult(), null, config.Next_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17646 */           this.val$service.next(rpc, (DatastorePb.NextRequest)rpc.internalRequest(), (DatastorePb.QueryResult)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17650 */       registry.registerHandler(config.serviceName(), "Count", new DatastorePb.Query(), new ApiBasePb.Integer64Proto(), null, config.Count_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17654 */           this.val$service.count(rpc, (DatastorePb.Query)rpc.internalRequest(), (ApiBasePb.Integer64Proto)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17658 */       registry.registerHandler(config.serviceName(), "DeleteCursor", new DatastorePb.Cursor(), new ApiBasePb.VoidProto(), null, config.DeleteCursor_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17662 */           this.val$service.deleteCursor(rpc, (DatastorePb.Cursor)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17666 */       registry.registerHandler(config.serviceName(), "BeginTransaction", new DatastorePb.BeginTransactionRequest(), new DatastorePb.Transaction(), null, config.BeginTransaction_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17670 */           this.val$service.beginTransaction(rpc, (DatastorePb.BeginTransactionRequest)rpc.internalRequest(), (DatastorePb.Transaction)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17674 */       registry.registerHandler(config.serviceName(), "Commit", new DatastorePb.Transaction(), new DatastorePb.CommitResponse(), null, config.Commit_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17678 */           this.val$service.commit(rpc, (DatastorePb.Transaction)rpc.internalRequest(), (DatastorePb.CommitResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17682 */       registry.registerHandler(config.serviceName(), "Rollback", new DatastorePb.Transaction(), new ApiBasePb.VoidProto(), null, config.Rollback_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17686 */           this.val$service.rollback(rpc, (DatastorePb.Transaction)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17690 */       registry.registerHandler(config.serviceName(), "GetSchema", new DatastorePb.GetSchemaRequest(), new DatastorePb.Schema(), null, config.GetSchema_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17694 */           this.val$service.getSchema(rpc, (DatastorePb.GetSchemaRequest)rpc.internalRequest(), (DatastorePb.Schema)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17698 */       registry.registerHandler(config.serviceName(), "AllocateIds", new DatastorePb.AllocateIdsRequest(), new DatastorePb.AllocateIdsResponse(), null, config.AllocateIds_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17702 */           this.val$service.allocateIds(rpc, (DatastorePb.AllocateIdsRequest)rpc.internalRequest(), (DatastorePb.AllocateIdsResponse)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17706 */       registry.registerHandler(config.serviceName(), "CreateIndex", new OnestoreEntity.CompositeIndex(), new ApiBasePb.Integer64Proto(), null, config.CreateIndex_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17710 */           this.val$service.createIndex(rpc, (OnestoreEntity.CompositeIndex)rpc.internalRequest(), (ApiBasePb.Integer64Proto)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17714 */       registry.registerHandler(config.serviceName(), "UpdateIndex", new OnestoreEntity.CompositeIndex(), new ApiBasePb.VoidProto(), null, config.UpdateIndex_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17718 */           this.val$service.updateIndex(rpc, (OnestoreEntity.CompositeIndex)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17722 */       registry.registerHandler(config.serviceName(), "GetIndices", new ApiBasePb.StringProto(), new DatastorePb.CompositeIndices(), null, config.GetIndices_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17726 */           this.val$service.getIndices(rpc, (ApiBasePb.StringProto)rpc.internalRequest(), (DatastorePb.CompositeIndices)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/* 17730 */       registry.registerHandler(config.serviceName(), "DeleteIndex", new OnestoreEntity.CompositeIndex(), new ApiBasePb.VoidProto(), null, config.DeleteIndex_parameters_, new ApplicationHandler(service)
/*       */       {
/*       */         public void handleRequest(RPC rpc)
/*       */         {
/* 17734 */           this.val$service.deleteIndex(rpc, (OnestoreEntity.CompositeIndex)rpc.internalRequest(), (ApiBasePb.VoidProto)rpc.internalResponse(), rpc.internalCallback());
/*       */         }
/*       */       });
/*       */     }
/*       */ 
/*       */     public static RpcService newService(Interface impl) {
/* 17741 */       return new RpcService(impl) {
/*       */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 17743 */           return DatastorePb.DatastoreService.exportService(this.val$impl, registry);
/*       */         }
/*       */       };
/*       */     }
/*       */ 
/*       */     public static ServerConfig exportService(Interface service, RpcServer.Builder builder) {
/* 17750 */       ServerConfig config = new ServerConfig();
/* 17751 */       exportServiceUsingConfig(service, builder, config);
/* 17752 */       return config;
/*       */     }
/*       */ 
/*       */     public static void exportServiceUsingConfig(Interface service, RpcServer.Builder builder, ServerConfig config)
/*       */     {
/* 17758 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 17759 */       exportServiceUsingConfig(service, registry, config);
/* 17760 */       builder.addService(registry);
/*       */     }
/*       */ 
/*       */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcHandlerRegistry registry)
/*       */     {
/* 17765 */       ServerConfig config = new ServerConfig();
/* 17766 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 17767 */       return config;
/*       */     }
/*       */ 
/*       */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcHandlerRegistry registry, ServerConfig config)
/*       */     {
/* 17773 */       registry.registerHandler(config.serviceName(), "Get", new DatastorePb.GetRequest(), new DatastorePb.GetResponse(), null, config.Get_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.GetResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17777 */           return this.val$service.get(rpc, (DatastorePb.GetRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17780 */       registry.registerHandler(config.serviceName(), "Put", new DatastorePb.PutRequest(), new DatastorePb.PutResponse(), null, config.Put_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.PutResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17784 */           return this.val$service.put(rpc, (DatastorePb.PutRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17787 */       registry.registerHandler(config.serviceName(), "Touch", new DatastorePb.TouchRequest(), new DatastorePb.TouchResponse(), null, config.Touch_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.TouchResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17791 */           return this.val$service.touch(rpc, (DatastorePb.TouchRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17794 */       registry.registerHandler(config.serviceName(), "Delete", new DatastorePb.DeleteRequest(), new DatastorePb.DeleteResponse(), null, config.Delete_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.DeleteResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17798 */           return this.val$service.delete(rpc, (DatastorePb.DeleteRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17801 */       registry.registerHandler(config.serviceName(), "RunQuery", new DatastorePb.Query(), new DatastorePb.QueryResult(), null, config.RunQuery_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.QueryResult handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17805 */           return this.val$service.runQuery(rpc, (DatastorePb.Query)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17808 */       registry.registerHandler(config.serviceName(), "RunCompiledQuery", new DatastorePb.RunCompiledQueryRequest(), new DatastorePb.QueryResult(), null, config.RunCompiledQuery_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.QueryResult handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17812 */           return this.val$service.runCompiledQuery(rpc, (DatastorePb.RunCompiledQueryRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17815 */       registry.registerHandler(config.serviceName(), "AddAction", new DatastorePb.AddActionsRequest(), new DatastorePb.AddActionsResponse(), null, config.AddAction_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.AddActionsResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17819 */           return this.val$service.addAction(rpc, (DatastorePb.AddActionsRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17822 */       registry.registerHandler(config.serviceName(), "AddActions", new DatastorePb.AddActionsRequest(), new DatastorePb.AddActionsResponse(), null, config.AddActions_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.AddActionsResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17826 */           return this.val$service.addActions(rpc, (DatastorePb.AddActionsRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17829 */       registry.registerHandler(config.serviceName(), "Next", new DatastorePb.NextRequest(), new DatastorePb.QueryResult(), null, config.Next_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.QueryResult handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17833 */           return this.val$service.next(rpc, (DatastorePb.NextRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17836 */       registry.registerHandler(config.serviceName(), "Count", new DatastorePb.Query(), new ApiBasePb.Integer64Proto(), null, config.Count_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public ApiBasePb.Integer64Proto handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17840 */           return this.val$service.count(rpc, (DatastorePb.Query)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17843 */       registry.registerHandler(config.serviceName(), "DeleteCursor", new DatastorePb.Cursor(), new ApiBasePb.VoidProto(), null, config.DeleteCursor_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17847 */           return this.val$service.deleteCursor(rpc, (DatastorePb.Cursor)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17850 */       registry.registerHandler(config.serviceName(), "BeginTransaction", new DatastorePb.BeginTransactionRequest(), new DatastorePb.Transaction(), null, config.BeginTransaction_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.Transaction handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17854 */           return this.val$service.beginTransaction(rpc, (DatastorePb.BeginTransactionRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17857 */       registry.registerHandler(config.serviceName(), "Commit", new DatastorePb.Transaction(), new DatastorePb.CommitResponse(), null, config.Commit_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.CommitResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17861 */           return this.val$service.commit(rpc, (DatastorePb.Transaction)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17864 */       registry.registerHandler(config.serviceName(), "Rollback", new DatastorePb.Transaction(), new ApiBasePb.VoidProto(), null, config.Rollback_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17868 */           return this.val$service.rollback(rpc, (DatastorePb.Transaction)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17871 */       registry.registerHandler(config.serviceName(), "GetSchema", new DatastorePb.GetSchemaRequest(), new DatastorePb.Schema(), null, config.GetSchema_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.Schema handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17875 */           return this.val$service.getSchema(rpc, (DatastorePb.GetSchemaRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17878 */       registry.registerHandler(config.serviceName(), "AllocateIds", new DatastorePb.AllocateIdsRequest(), new DatastorePb.AllocateIdsResponse(), null, config.AllocateIds_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.AllocateIdsResponse handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17882 */           return this.val$service.allocateIds(rpc, (DatastorePb.AllocateIdsRequest)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17885 */       registry.registerHandler(config.serviceName(), "CreateIndex", new OnestoreEntity.CompositeIndex(), new ApiBasePb.Integer64Proto(), null, config.CreateIndex_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public ApiBasePb.Integer64Proto handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17889 */           return this.val$service.createIndex(rpc, (OnestoreEntity.CompositeIndex)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17892 */       registry.registerHandler(config.serviceName(), "UpdateIndex", new OnestoreEntity.CompositeIndex(), new ApiBasePb.VoidProto(), null, config.UpdateIndex_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17896 */           return this.val$service.updateIndex(rpc, (OnestoreEntity.CompositeIndex)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17899 */       registry.registerHandler(config.serviceName(), "GetIndices", new ApiBasePb.StringProto(), new DatastorePb.CompositeIndices(), null, config.GetIndices_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public DatastorePb.CompositeIndices handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17903 */           return this.val$service.getIndices(rpc, (ApiBasePb.StringProto)rpc.internalRequest());
/*       */         }
/*       */       });
/* 17906 */       registry.registerHandler(config.serviceName(), "DeleteIndex", new OnestoreEntity.CompositeIndex(), new ApiBasePb.VoidProto(), null, config.DeleteIndex_parameters_, new BlockingApplicationHandler(service)
/*       */       {
/*       */         public ApiBasePb.VoidProto handleBlockingRequest(RPC rpc) throws RpcException
/*       */         {
/* 17910 */           return this.val$service.deleteIndex(rpc, (OnestoreEntity.CompositeIndex)rpc.internalRequest());
/*       */         } } );
/*       */     }
/*       */ 
/*       */     public static RpcService newBlockingService(BlockingInterface impl) {
/* 17916 */       return new RpcService(impl) {
/*       */         protected RpcServerConfig export(RpcHandlerRegistry registry) {
/* 17918 */           return DatastorePb.DatastoreService.exportBlockingService(this.val$impl, registry);
/*       */         }
/*       */       };
/*       */     }
/*       */ 
/*       */     public static ServerConfig exportBlockingService(BlockingInterface service, RpcServer.Builder builder) {
/* 17925 */       ServerConfig config = new ServerConfig();
/* 17926 */       exportBlockingServiceUsingConfig(service, builder, config);
/* 17927 */       return config;
/*       */     }
/*       */ 
/*       */     public static void exportBlockingServiceUsingConfig(BlockingInterface service, RpcServer.Builder builder, ServerConfig config)
/*       */     {
/* 17933 */       Rpc1HandlerRegistry registry = new Rpc1HandlerRegistry(config.serviceName());
/* 17934 */       exportBlockingServiceUsingConfig(service, registry, config);
/* 17935 */       builder.addService(registry);
/*       */     }
/*       */ 
/*       */     public static void unexport(RpcHandlerRegistry registry) {
/* 17939 */       registry.unregisterService("DatastoreService");
/*       */     }
/*       */ 
/*       */     public static class ServerConfig extends RpcServerConfig
/*       */     {
/* 17273 */       final RpcServerParameters Get_parameters_ = new RpcServerParameters();
/* 17274 */       final RpcServerParameters Put_parameters_ = new RpcServerParameters();
/* 17275 */       final RpcServerParameters Touch_parameters_ = new RpcServerParameters();
/* 17276 */       final RpcServerParameters Delete_parameters_ = new RpcServerParameters();
/* 17277 */       final RpcServerParameters RunQuery_parameters_ = new RpcServerParameters();
/* 17278 */       final RpcServerParameters RunCompiledQuery_parameters_ = new RpcServerParameters();
/* 17279 */       final RpcServerParameters AddAction_parameters_ = new RpcServerParameters();
/* 17280 */       final RpcServerParameters AddActions_parameters_ = new RpcServerParameters();
/* 17281 */       final RpcServerParameters Next_parameters_ = new RpcServerParameters();
/* 17282 */       final RpcServerParameters Count_parameters_ = new RpcServerParameters();
/* 17283 */       final RpcServerParameters DeleteCursor_parameters_ = new RpcServerParameters();
/* 17284 */       final RpcServerParameters BeginTransaction_parameters_ = new RpcServerParameters();
/* 17285 */       final RpcServerParameters Commit_parameters_ = new RpcServerParameters();
/* 17286 */       final RpcServerParameters Rollback_parameters_ = new RpcServerParameters();
/* 17287 */       final RpcServerParameters GetSchema_parameters_ = new RpcServerParameters();
/* 17288 */       final RpcServerParameters AllocateIds_parameters_ = new RpcServerParameters();
/* 17289 */       final RpcServerParameters CreateIndex_parameters_ = new RpcServerParameters();
/* 17290 */       final RpcServerParameters UpdateIndex_parameters_ = new RpcServerParameters();
/* 17291 */       final RpcServerParameters GetIndices_parameters_ = new RpcServerParameters();
/* 17292 */       final RpcServerParameters DeleteIndex_parameters_ = new RpcServerParameters();
/*       */ 
/*       */       public ServerConfig() {
/* 17295 */         this("DatastoreService");
/*       */       }
/*       */       public ServerConfig(String serviceName) {
/* 17298 */         super();
/*       */       }
/*       */       public void setRpcRunner(Executor t) {
/* 17301 */         setRpcRunner_Get(t);
/* 17302 */         setRpcRunner_Put(t);
/* 17303 */         setRpcRunner_Touch(t);
/* 17304 */         setRpcRunner_Delete(t);
/* 17305 */         setRpcRunner_RunQuery(t);
/* 17306 */         setRpcRunner_RunCompiledQuery(t);
/* 17307 */         setRpcRunner_AddAction(t);
/* 17308 */         setRpcRunner_AddActions(t);
/* 17309 */         setRpcRunner_Next(t);
/* 17310 */         setRpcRunner_Count(t);
/* 17311 */         setRpcRunner_DeleteCursor(t);
/* 17312 */         setRpcRunner_BeginTransaction(t);
/* 17313 */         setRpcRunner_Commit(t);
/* 17314 */         setRpcRunner_Rollback(t);
/* 17315 */         setRpcRunner_GetSchema(t);
/* 17316 */         setRpcRunner_AllocateIds(t);
/* 17317 */         setRpcRunner_CreateIndex(t);
/* 17318 */         setRpcRunner_UpdateIndex(t);
/* 17319 */         setRpcRunner_GetIndices(t);
/* 17320 */         setRpcRunner_DeleteIndex(t);
/*       */       }
/*       */ 
/*       */       public void setRpcRunner_Get(Executor t) {
/* 17324 */         this.Get_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Put(Executor t) {
/* 17327 */         this.Put_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Touch(Executor t) {
/* 17330 */         this.Touch_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Delete(Executor t) {
/* 17333 */         this.Delete_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_RunQuery(Executor t) {
/* 17336 */         this.RunQuery_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_RunCompiledQuery(Executor t) {
/* 17339 */         this.RunCompiledQuery_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_AddAction(Executor t) {
/* 17342 */         this.AddAction_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_AddActions(Executor t) {
/* 17345 */         this.AddActions_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Next(Executor t) {
/* 17348 */         this.Next_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Count(Executor t) {
/* 17351 */         this.Count_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_DeleteCursor(Executor t) {
/* 17354 */         this.DeleteCursor_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_BeginTransaction(Executor t) {
/* 17357 */         this.BeginTransaction_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Commit(Executor t) {
/* 17360 */         this.Commit_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_Rollback(Executor t) {
/* 17363 */         this.Rollback_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_GetSchema(Executor t) {
/* 17366 */         this.GetSchema_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_AllocateIds(Executor t) {
/* 17369 */         this.AllocateIds_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_CreateIndex(Executor t) {
/* 17372 */         this.CreateIndex_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_UpdateIndex(Executor t) {
/* 17375 */         this.UpdateIndex_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_GetIndices(Executor t) {
/* 17378 */         this.GetIndices_parameters_.setRpcRunner(t);
/*       */       }
/*       */       public void setRpcRunner_DeleteIndex(Executor t) {
/* 17381 */         this.DeleteIndex_parameters_.setRpcRunner(t);
/*       */       }
/*       */ 
/*       */       public void setServerLogging_Get(int t) {
/* 17385 */         this.Get_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Put(int t) {
/* 17388 */         this.Put_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Touch(int t) {
/* 17391 */         this.Touch_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Delete(int t) {
/* 17394 */         this.Delete_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_RunQuery(int t) {
/* 17397 */         this.RunQuery_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_RunCompiledQuery(int t) {
/* 17400 */         this.RunCompiledQuery_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_AddAction(int t) {
/* 17403 */         this.AddAction_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_AddActions(int t) {
/* 17406 */         this.AddActions_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Next(int t) {
/* 17409 */         this.Next_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Count(int t) {
/* 17412 */         this.Count_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_DeleteCursor(int t) {
/* 17415 */         this.DeleteCursor_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_BeginTransaction(int t) {
/* 17418 */         this.BeginTransaction_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Commit(int t) {
/* 17421 */         this.Commit_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_Rollback(int t) {
/* 17424 */         this.Rollback_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_GetSchema(int t) {
/* 17427 */         this.GetSchema_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_AllocateIds(int t) {
/* 17430 */         this.AllocateIds_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_CreateIndex(int t) {
/* 17433 */         this.CreateIndex_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_UpdateIndex(int t) {
/* 17436 */         this.UpdateIndex_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_GetIndices(int t) {
/* 17439 */         this.GetIndices_parameters_.setServerLogging(t);
/*       */       }
/*       */       public void setServerLogging_DeleteIndex(int t) {
/* 17442 */         this.DeleteIndex_parameters_.setServerLogging(t);
/*       */       }
/*       */ 
/*       */       public void setSecurityLevel_Get(SslSecurityLevel t) {
/* 17446 */         this.Get_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Put(SslSecurityLevel t) {
/* 17449 */         this.Put_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Touch(SslSecurityLevel t) {
/* 17452 */         this.Touch_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Delete(SslSecurityLevel t) {
/* 17455 */         this.Delete_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_RunQuery(SslSecurityLevel t) {
/* 17458 */         this.RunQuery_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_RunCompiledQuery(SslSecurityLevel t) {
/* 17461 */         this.RunCompiledQuery_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_AddAction(SslSecurityLevel t) {
/* 17464 */         this.AddAction_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_AddActions(SslSecurityLevel t) {
/* 17467 */         this.AddActions_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Next(SslSecurityLevel t) {
/* 17470 */         this.Next_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Count(SslSecurityLevel t) {
/* 17473 */         this.Count_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_DeleteCursor(SslSecurityLevel t) {
/* 17476 */         this.DeleteCursor_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_BeginTransaction(SslSecurityLevel t) {
/* 17479 */         this.BeginTransaction_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Commit(SslSecurityLevel t) {
/* 17482 */         this.Commit_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_Rollback(SslSecurityLevel t) {
/* 17485 */         this.Rollback_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_GetSchema(SslSecurityLevel t) {
/* 17488 */         this.GetSchema_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_AllocateIds(SslSecurityLevel t) {
/* 17491 */         this.AllocateIds_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_CreateIndex(SslSecurityLevel t) {
/* 17494 */         this.CreateIndex_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_UpdateIndex(SslSecurityLevel t) {
/* 17497 */         this.UpdateIndex_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_GetIndices(SslSecurityLevel t) {
/* 17500 */         this.GetIndices_parameters_.setSecurityLevel(t);
/*       */       }
/*       */       public void setSecurityLevel_DeleteIndex(SslSecurityLevel t) {
/* 17503 */         this.DeleteIndex_parameters_.setSecurityLevel(t);
/*       */       }
/*       */ 
/*       */       public void setRpcCancelCallback_Get(RpcCancelCallback t) {
/* 17507 */         this.Get_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Put(RpcCancelCallback t) {
/* 17510 */         this.Put_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Touch(RpcCancelCallback t) {
/* 17513 */         this.Touch_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Delete(RpcCancelCallback t) {
/* 17516 */         this.Delete_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_RunQuery(RpcCancelCallback t) {
/* 17519 */         this.RunQuery_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_RunCompiledQuery(RpcCancelCallback t) {
/* 17522 */         this.RunCompiledQuery_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_AddAction(RpcCancelCallback t) {
/* 17525 */         this.AddAction_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_AddActions(RpcCancelCallback t) {
/* 17528 */         this.AddActions_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Next(RpcCancelCallback t) {
/* 17531 */         this.Next_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Count(RpcCancelCallback t) {
/* 17534 */         this.Count_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_DeleteCursor(RpcCancelCallback t) {
/* 17537 */         this.DeleteCursor_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_BeginTransaction(RpcCancelCallback t) {
/* 17540 */         this.BeginTransaction_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Commit(RpcCancelCallback t) {
/* 17543 */         this.Commit_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_Rollback(RpcCancelCallback t) {
/* 17546 */         this.Rollback_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_GetSchema(RpcCancelCallback t) {
/* 17549 */         this.GetSchema_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_AllocateIds(RpcCancelCallback t) {
/* 17552 */         this.AllocateIds_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_CreateIndex(RpcCancelCallback t) {
/* 17555 */         this.CreateIndex_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_UpdateIndex(RpcCancelCallback t) {
/* 17558 */         this.UpdateIndex_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_GetIndices(RpcCancelCallback t) {
/* 17561 */         this.GetIndices_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */       public void setRpcCancelCallback_DeleteIndex(RpcCancelCallback t) {
/* 17564 */         this.DeleteIndex_parameters_.setRpcCancelCallback(t);
/*       */       }
/*       */     }
/*       */ 
/*       */     public static class Stub extends DatastorePb.DatastoreService.BlockingStub
/*       */       implements DatastorePb.DatastoreService.Interface
/*       */     {
/*       */       Stub(RpcStubParameters params)
/*       */       {
/* 17184 */         super();
/*       */       }
/*       */       public void get(RPC rpc, DatastorePb.GetRequest req, DatastorePb.GetResponse reply, RpcCallback cb) {
/* 17187 */         startNonBlockingRpc(rpc, this.Get_method_, "Get", req, reply, cb, this.Get_parameters_);
/*       */       }
/*       */ 
/*       */       public void put(RPC rpc, DatastorePb.PutRequest req, DatastorePb.PutResponse reply, RpcCallback cb) {
/* 17191 */         startNonBlockingRpc(rpc, this.Put_method_, "Put", req, reply, cb, this.Put_parameters_);
/*       */       }
/*       */ 
/*       */       public void touch(RPC rpc, DatastorePb.TouchRequest req, DatastorePb.TouchResponse reply, RpcCallback cb) {
/* 17195 */         startNonBlockingRpc(rpc, this.Touch_method_, "Touch", req, reply, cb, this.Touch_parameters_);
/*       */       }
/*       */ 
/*       */       public void delete(RPC rpc, DatastorePb.DeleteRequest req, DatastorePb.DeleteResponse reply, RpcCallback cb) {
/* 17199 */         startNonBlockingRpc(rpc, this.Delete_method_, "Delete", req, reply, cb, this.Delete_parameters_);
/*       */       }
/*       */ 
/*       */       public void runQuery(RPC rpc, DatastorePb.Query req, DatastorePb.QueryResult reply, RpcCallback cb) {
/* 17203 */         startNonBlockingRpc(rpc, this.RunQuery_method_, "RunQuery", req, reply, cb, this.RunQuery_parameters_);
/*       */       }
/*       */ 
/*       */       public void runCompiledQuery(RPC rpc, DatastorePb.RunCompiledQueryRequest req, DatastorePb.QueryResult reply, RpcCallback cb) {
/* 17207 */         startNonBlockingRpc(rpc, this.RunCompiledQuery_method_, "RunCompiledQuery", req, reply, cb, this.RunCompiledQuery_parameters_);
/*       */       }
/*       */ 
/*       */       public void addAction(RPC rpc, DatastorePb.AddActionsRequest req, DatastorePb.AddActionsResponse reply, RpcCallback cb) {
/* 17211 */         startNonBlockingRpc(rpc, this.AddAction_method_, "AddAction", req, reply, cb, this.AddAction_parameters_);
/*       */       }
/*       */ 
/*       */       public void addActions(RPC rpc, DatastorePb.AddActionsRequest req, DatastorePb.AddActionsResponse reply, RpcCallback cb) {
/* 17215 */         startNonBlockingRpc(rpc, this.AddActions_method_, "AddActions", req, reply, cb, this.AddActions_parameters_);
/*       */       }
/*       */ 
/*       */       public void next(RPC rpc, DatastorePb.NextRequest req, DatastorePb.QueryResult reply, RpcCallback cb) {
/* 17219 */         startNonBlockingRpc(rpc, this.Next_method_, "Next", req, reply, cb, this.Next_parameters_);
/*       */       }
/*       */ 
/*       */       public void count(RPC rpc, DatastorePb.Query req, ApiBasePb.Integer64Proto reply, RpcCallback cb) {
/* 17223 */         startNonBlockingRpc(rpc, this.Count_method_, "Count", req, reply, cb, this.Count_parameters_);
/*       */       }
/*       */ 
/*       */       public void deleteCursor(RPC rpc, DatastorePb.Cursor req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 17227 */         startNonBlockingRpc(rpc, this.DeleteCursor_method_, "DeleteCursor", req, reply, cb, this.DeleteCursor_parameters_);
/*       */       }
/*       */ 
/*       */       public void beginTransaction(RPC rpc, DatastorePb.BeginTransactionRequest req, DatastorePb.Transaction reply, RpcCallback cb) {
/* 17231 */         startNonBlockingRpc(rpc, this.BeginTransaction_method_, "BeginTransaction", req, reply, cb, this.BeginTransaction_parameters_);
/*       */       }
/*       */ 
/*       */       public void commit(RPC rpc, DatastorePb.Transaction req, DatastorePb.CommitResponse reply, RpcCallback cb) {
/* 17235 */         startNonBlockingRpc(rpc, this.Commit_method_, "Commit", req, reply, cb, this.Commit_parameters_);
/*       */       }
/*       */ 
/*       */       public void rollback(RPC rpc, DatastorePb.Transaction req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 17239 */         startNonBlockingRpc(rpc, this.Rollback_method_, "Rollback", req, reply, cb, this.Rollback_parameters_);
/*       */       }
/*       */ 
/*       */       public void getSchema(RPC rpc, DatastorePb.GetSchemaRequest req, DatastorePb.Schema reply, RpcCallback cb) {
/* 17243 */         startNonBlockingRpc(rpc, this.GetSchema_method_, "GetSchema", req, reply, cb, this.GetSchema_parameters_);
/*       */       }
/*       */ 
/*       */       public void allocateIds(RPC rpc, DatastorePb.AllocateIdsRequest req, DatastorePb.AllocateIdsResponse reply, RpcCallback cb) {
/* 17247 */         startNonBlockingRpc(rpc, this.AllocateIds_method_, "AllocateIds", req, reply, cb, this.AllocateIds_parameters_);
/*       */       }
/*       */ 
/*       */       public void createIndex(RPC rpc, OnestoreEntity.CompositeIndex req, ApiBasePb.Integer64Proto reply, RpcCallback cb) {
/* 17251 */         startNonBlockingRpc(rpc, this.CreateIndex_method_, "CreateIndex", req, reply, cb, this.CreateIndex_parameters_);
/*       */       }
/*       */ 
/*       */       public void updateIndex(RPC rpc, OnestoreEntity.CompositeIndex req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 17255 */         startNonBlockingRpc(rpc, this.UpdateIndex_method_, "UpdateIndex", req, reply, cb, this.UpdateIndex_parameters_);
/*       */       }
/*       */ 
/*       */       public void getIndices(RPC rpc, ApiBasePb.StringProto req, DatastorePb.CompositeIndices reply, RpcCallback cb) {
/* 17259 */         startNonBlockingRpc(rpc, this.GetIndices_method_, "GetIndices", req, reply, cb, this.GetIndices_parameters_);
/*       */       }
/*       */ 
/*       */       public void deleteIndex(RPC rpc, OnestoreEntity.CompositeIndex req, ApiBasePb.VoidProto reply, RpcCallback cb) {
/* 17263 */         startNonBlockingRpc(rpc, this.DeleteIndex_method_, "DeleteIndex", req, reply, cb, this.DeleteIndex_parameters_);
/*       */       }
/*       */     }
/*       */ 
/*       */     public static abstract interface Interface extends RpcInterface
/*       */     {
/*       */       public abstract void get(RPC paramRPC, DatastorePb.GetRequest paramGetRequest, DatastorePb.GetResponse paramGetResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void put(RPC paramRPC, DatastorePb.PutRequest paramPutRequest, DatastorePb.PutResponse paramPutResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void touch(RPC paramRPC, DatastorePb.TouchRequest paramTouchRequest, DatastorePb.TouchResponse paramTouchResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void delete(RPC paramRPC, DatastorePb.DeleteRequest paramDeleteRequest, DatastorePb.DeleteResponse paramDeleteResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void runQuery(RPC paramRPC, DatastorePb.Query paramQuery, DatastorePb.QueryResult paramQueryResult, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void runCompiledQuery(RPC paramRPC, DatastorePb.RunCompiledQueryRequest paramRunCompiledQueryRequest, DatastorePb.QueryResult paramQueryResult, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void addAction(RPC paramRPC, DatastorePb.AddActionsRequest paramAddActionsRequest, DatastorePb.AddActionsResponse paramAddActionsResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void addActions(RPC paramRPC, DatastorePb.AddActionsRequest paramAddActionsRequest, DatastorePb.AddActionsResponse paramAddActionsResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void next(RPC paramRPC, DatastorePb.NextRequest paramNextRequest, DatastorePb.QueryResult paramQueryResult, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void count(RPC paramRPC, DatastorePb.Query paramQuery, ApiBasePb.Integer64Proto paramInteger64Proto, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void deleteCursor(RPC paramRPC, DatastorePb.Cursor paramCursor, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void beginTransaction(RPC paramRPC, DatastorePb.BeginTransactionRequest paramBeginTransactionRequest, DatastorePb.Transaction paramTransaction, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void commit(RPC paramRPC, DatastorePb.Transaction paramTransaction, DatastorePb.CommitResponse paramCommitResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void rollback(RPC paramRPC, DatastorePb.Transaction paramTransaction, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void getSchema(RPC paramRPC, DatastorePb.GetSchemaRequest paramGetSchemaRequest, DatastorePb.Schema paramSchema, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void allocateIds(RPC paramRPC, DatastorePb.AllocateIdsRequest paramAllocateIdsRequest, DatastorePb.AllocateIdsResponse paramAllocateIdsResponse, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void createIndex(RPC paramRPC, OnestoreEntity.CompositeIndex paramCompositeIndex, ApiBasePb.Integer64Proto paramInteger64Proto, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void updateIndex(RPC paramRPC, OnestoreEntity.CompositeIndex paramCompositeIndex, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void getIndices(RPC paramRPC, ApiBasePb.StringProto paramStringProto, DatastorePb.CompositeIndices paramCompositeIndices, RpcCallback paramRpcCallback);
/*       */ 
/*       */       public abstract void deleteIndex(RPC paramRPC, OnestoreEntity.CompositeIndex paramCompositeIndex, ApiBasePb.VoidProto paramVoidProto, RpcCallback paramRpcCallback);
/*       */     }
/*       */ 
/*       */     public static class BlockingStub extends DatastorePb.DatastoreService.BaseStub
/*       */       implements DatastorePb.DatastoreService.BlockingInterface
/*       */     {
/*       */       BlockingStub(RpcStubParameters params)
/*       */       {
/* 17031 */         super();
/*       */       }
/*       */       public DatastorePb.GetResponse get(RPC rpc, DatastorePb.GetRequest req) throws RpcException {
/* 17034 */         DatastorePb.GetResponse reply = new DatastorePb.GetResponse();
/* 17035 */         startBlockingRpc(rpc, this.Get_method_, "Get", req, reply, this.Get_parameters_);
/*       */ 
/* 17037 */         return reply;
/*       */       }
/*       */       public DatastorePb.PutResponse put(RPC rpc, DatastorePb.PutRequest req) throws RpcException {
/* 17040 */         DatastorePb.PutResponse reply = new DatastorePb.PutResponse();
/* 17041 */         startBlockingRpc(rpc, this.Put_method_, "Put", req, reply, this.Put_parameters_);
/*       */ 
/* 17043 */         return reply;
/*       */       }
/*       */       public DatastorePb.TouchResponse touch(RPC rpc, DatastorePb.TouchRequest req) throws RpcException {
/* 17046 */         DatastorePb.TouchResponse reply = new DatastorePb.TouchResponse();
/* 17047 */         startBlockingRpc(rpc, this.Touch_method_, "Touch", req, reply, this.Touch_parameters_);
/*       */ 
/* 17049 */         return reply;
/*       */       }
/*       */       public DatastorePb.DeleteResponse delete(RPC rpc, DatastorePb.DeleteRequest req) throws RpcException {
/* 17052 */         DatastorePb.DeleteResponse reply = new DatastorePb.DeleteResponse();
/* 17053 */         startBlockingRpc(rpc, this.Delete_method_, "Delete", req, reply, this.Delete_parameters_);
/*       */ 
/* 17055 */         return reply;
/*       */       }
/*       */       public DatastorePb.QueryResult runQuery(RPC rpc, DatastorePb.Query req) throws RpcException {
/* 17058 */         DatastorePb.QueryResult reply = new DatastorePb.QueryResult();
/* 17059 */         startBlockingRpc(rpc, this.RunQuery_method_, "RunQuery", req, reply, this.RunQuery_parameters_);
/*       */ 
/* 17061 */         return reply;
/*       */       }
/*       */       public DatastorePb.QueryResult runCompiledQuery(RPC rpc, DatastorePb.RunCompiledQueryRequest req) throws RpcException {
/* 17064 */         DatastorePb.QueryResult reply = new DatastorePb.QueryResult();
/* 17065 */         startBlockingRpc(rpc, this.RunCompiledQuery_method_, "RunCompiledQuery", req, reply, this.RunCompiledQuery_parameters_);
/*       */ 
/* 17067 */         return reply;
/*       */       }
/*       */       public DatastorePb.AddActionsResponse addAction(RPC rpc, DatastorePb.AddActionsRequest req) throws RpcException {
/* 17070 */         DatastorePb.AddActionsResponse reply = new DatastorePb.AddActionsResponse();
/* 17071 */         startBlockingRpc(rpc, this.AddAction_method_, "AddAction", req, reply, this.AddAction_parameters_);
/*       */ 
/* 17073 */         return reply;
/*       */       }
/*       */       public DatastorePb.AddActionsResponse addActions(RPC rpc, DatastorePb.AddActionsRequest req) throws RpcException {
/* 17076 */         DatastorePb.AddActionsResponse reply = new DatastorePb.AddActionsResponse();
/* 17077 */         startBlockingRpc(rpc, this.AddActions_method_, "AddActions", req, reply, this.AddActions_parameters_);
/*       */ 
/* 17079 */         return reply;
/*       */       }
/*       */       public DatastorePb.QueryResult next(RPC rpc, DatastorePb.NextRequest req) throws RpcException {
/* 17082 */         DatastorePb.QueryResult reply = new DatastorePb.QueryResult();
/* 17083 */         startBlockingRpc(rpc, this.Next_method_, "Next", req, reply, this.Next_parameters_);
/*       */ 
/* 17085 */         return reply;
/*       */       }
/*       */       public ApiBasePb.Integer64Proto count(RPC rpc, DatastorePb.Query req) throws RpcException {
/* 17088 */         ApiBasePb.Integer64Proto reply = new ApiBasePb.Integer64Proto();
/* 17089 */         startBlockingRpc(rpc, this.Count_method_, "Count", req, reply, this.Count_parameters_);
/*       */ 
/* 17091 */         return reply;
/*       */       }
/*       */       public ApiBasePb.VoidProto deleteCursor(RPC rpc, DatastorePb.Cursor req) throws RpcException {
/* 17094 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 17095 */         startBlockingRpc(rpc, this.DeleteCursor_method_, "DeleteCursor", req, reply, this.DeleteCursor_parameters_);
/*       */ 
/* 17097 */         return reply;
/*       */       }
/*       */       public DatastorePb.Transaction beginTransaction(RPC rpc, DatastorePb.BeginTransactionRequest req) throws RpcException {
/* 17100 */         DatastorePb.Transaction reply = new DatastorePb.Transaction();
/* 17101 */         startBlockingRpc(rpc, this.BeginTransaction_method_, "BeginTransaction", req, reply, this.BeginTransaction_parameters_);
/*       */ 
/* 17103 */         return reply;
/*       */       }
/*       */       public DatastorePb.CommitResponse commit(RPC rpc, DatastorePb.Transaction req) throws RpcException {
/* 17106 */         DatastorePb.CommitResponse reply = new DatastorePb.CommitResponse();
/* 17107 */         startBlockingRpc(rpc, this.Commit_method_, "Commit", req, reply, this.Commit_parameters_);
/*       */ 
/* 17109 */         return reply;
/*       */       }
/*       */       public ApiBasePb.VoidProto rollback(RPC rpc, DatastorePb.Transaction req) throws RpcException {
/* 17112 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 17113 */         startBlockingRpc(rpc, this.Rollback_method_, "Rollback", req, reply, this.Rollback_parameters_);
/*       */ 
/* 17115 */         return reply;
/*       */       }
/*       */       public DatastorePb.Schema getSchema(RPC rpc, DatastorePb.GetSchemaRequest req) throws RpcException {
/* 17118 */         DatastorePb.Schema reply = new DatastorePb.Schema();
/* 17119 */         startBlockingRpc(rpc, this.GetSchema_method_, "GetSchema", req, reply, this.GetSchema_parameters_);
/*       */ 
/* 17121 */         return reply;
/*       */       }
/*       */       public DatastorePb.AllocateIdsResponse allocateIds(RPC rpc, DatastorePb.AllocateIdsRequest req) throws RpcException {
/* 17124 */         DatastorePb.AllocateIdsResponse reply = new DatastorePb.AllocateIdsResponse();
/* 17125 */         startBlockingRpc(rpc, this.AllocateIds_method_, "AllocateIds", req, reply, this.AllocateIds_parameters_);
/*       */ 
/* 17127 */         return reply;
/*       */       }
/*       */       public ApiBasePb.Integer64Proto createIndex(RPC rpc, OnestoreEntity.CompositeIndex req) throws RpcException {
/* 17130 */         ApiBasePb.Integer64Proto reply = new ApiBasePb.Integer64Proto();
/* 17131 */         startBlockingRpc(rpc, this.CreateIndex_method_, "CreateIndex", req, reply, this.CreateIndex_parameters_);
/*       */ 
/* 17133 */         return reply;
/*       */       }
/*       */       public ApiBasePb.VoidProto updateIndex(RPC rpc, OnestoreEntity.CompositeIndex req) throws RpcException {
/* 17136 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 17137 */         startBlockingRpc(rpc, this.UpdateIndex_method_, "UpdateIndex", req, reply, this.UpdateIndex_parameters_);
/*       */ 
/* 17139 */         return reply;
/*       */       }
/*       */       public DatastorePb.CompositeIndices getIndices(RPC rpc, ApiBasePb.StringProto req) throws RpcException {
/* 17142 */         DatastorePb.CompositeIndices reply = new DatastorePb.CompositeIndices();
/* 17143 */         startBlockingRpc(rpc, this.GetIndices_method_, "GetIndices", req, reply, this.GetIndices_parameters_);
/*       */ 
/* 17145 */         return reply;
/*       */       }
/*       */       public ApiBasePb.VoidProto deleteIndex(RPC rpc, OnestoreEntity.CompositeIndex req) throws RpcException {
/* 17148 */         ApiBasePb.VoidProto reply = new ApiBasePb.VoidProto();
/* 17149 */         startBlockingRpc(rpc, this.DeleteIndex_method_, "DeleteIndex", req, reply, this.DeleteIndex_parameters_);
/*       */ 
/* 17151 */         return reply;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static abstract interface BlockingInterface extends RpcInterface
/*       */     {
/*       */       public abstract DatastorePb.GetResponse get(RPC paramRPC, DatastorePb.GetRequest paramGetRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.PutResponse put(RPC paramRPC, DatastorePb.PutRequest paramPutRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.TouchResponse touch(RPC paramRPC, DatastorePb.TouchRequest paramTouchRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.DeleteResponse delete(RPC paramRPC, DatastorePb.DeleteRequest paramDeleteRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.QueryResult runQuery(RPC paramRPC, DatastorePb.Query paramQuery)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.QueryResult runCompiledQuery(RPC paramRPC, DatastorePb.RunCompiledQueryRequest paramRunCompiledQueryRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.AddActionsResponse addAction(RPC paramRPC, DatastorePb.AddActionsRequest paramAddActionsRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.AddActionsResponse addActions(RPC paramRPC, DatastorePb.AddActionsRequest paramAddActionsRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.QueryResult next(RPC paramRPC, DatastorePb.NextRequest paramNextRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract ApiBasePb.Integer64Proto count(RPC paramRPC, DatastorePb.Query paramQuery)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract ApiBasePb.VoidProto deleteCursor(RPC paramRPC, DatastorePb.Cursor paramCursor)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.Transaction beginTransaction(RPC paramRPC, DatastorePb.BeginTransactionRequest paramBeginTransactionRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.CommitResponse commit(RPC paramRPC, DatastorePb.Transaction paramTransaction)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract ApiBasePb.VoidProto rollback(RPC paramRPC, DatastorePb.Transaction paramTransaction)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.Schema getSchema(RPC paramRPC, DatastorePb.GetSchemaRequest paramGetSchemaRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.AllocateIdsResponse allocateIds(RPC paramRPC, DatastorePb.AllocateIdsRequest paramAllocateIdsRequest)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract ApiBasePb.Integer64Proto createIndex(RPC paramRPC, OnestoreEntity.CompositeIndex paramCompositeIndex)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract ApiBasePb.VoidProto updateIndex(RPC paramRPC, OnestoreEntity.CompositeIndex paramCompositeIndex)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract DatastorePb.CompositeIndices getIndices(RPC paramRPC, ApiBasePb.StringProto paramStringProto)
/*       */         throws RpcException;
/*       */ 
/*       */       public abstract ApiBasePb.VoidProto deleteIndex(RPC paramRPC, OnestoreEntity.CompositeIndex paramCompositeIndex)
/*       */         throws RpcException;
/*       */     }
/*       */ 
/*       */     private static class BaseStub extends Rpc1CompatibilityStub
/*       */     {
/*       */       protected final String Get_method_;
/* 16965 */       protected final RPC Get_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Get);
/*       */       protected final String Put_method_;
/* 16967 */       protected final RPC Put_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Put);
/*       */       protected final String Touch_method_;
/* 16969 */       protected final RPC Touch_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Touch);
/*       */       protected final String Delete_method_;
/* 16971 */       protected final RPC Delete_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Delete);
/*       */       protected final String RunQuery_method_;
/* 16973 */       protected final RPC RunQuery_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.RunQuery);
/*       */       protected final String RunCompiledQuery_method_;
/* 16975 */       protected final RPC RunCompiledQuery_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.RunCompiledQuery);
/*       */       protected final String AddAction_method_;
/* 16977 */       protected final RPC AddAction_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.AddAction);
/*       */       protected final String AddActions_method_;
/* 16979 */       protected final RPC AddActions_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.AddActions);
/*       */       protected final String Next_method_;
/* 16981 */       protected final RPC Next_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Next);
/*       */       protected final String Count_method_;
/* 16983 */       protected final RPC Count_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Count);
/*       */       protected final String DeleteCursor_method_;
/* 16985 */       protected final RPC DeleteCursor_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.DeleteCursor);
/*       */       protected final String BeginTransaction_method_;
/* 16987 */       protected final RPC BeginTransaction_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.BeginTransaction);
/*       */       protected final String Commit_method_;
/* 16989 */       protected final RPC Commit_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Commit);
/*       */       protected final String Rollback_method_;
/* 16991 */       protected final RPC Rollback_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.Rollback);
/*       */       protected final String GetSchema_method_;
/* 16993 */       protected final RPC GetSchema_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.GetSchema);
/*       */       protected final String AllocateIds_method_;
/* 16995 */       protected final RPC AllocateIds_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.AllocateIds);
/*       */       protected final String CreateIndex_method_;
/* 16997 */       protected final RPC CreateIndex_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.CreateIndex);
/*       */       protected final String UpdateIndex_method_;
/* 16999 */       protected final RPC UpdateIndex_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.UpdateIndex);
/*       */       protected final String GetIndices_method_;
/* 17001 */       protected final RPC GetIndices_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.GetIndices);
/*       */       protected final String DeleteIndex_method_;
/* 17003 */       protected final RPC DeleteIndex_parameters_ = newRpcPrototype(DatastorePb.DatastoreService.Method.DeleteIndex);
/*       */ 
/*       */       protected BaseStub(RpcStubParameters params)
/*       */       {
/* 16941 */         super(params, DatastorePb.DatastoreService.Method.class);
/* 16942 */         this.Get_method_ = makeFullMethodName("Get");
/* 16943 */         this.Put_method_ = makeFullMethodName("Put");
/* 16944 */         this.Touch_method_ = makeFullMethodName("Touch");
/* 16945 */         this.Delete_method_ = makeFullMethodName("Delete");
/* 16946 */         this.RunQuery_method_ = makeFullMethodName("RunQuery");
/* 16947 */         this.RunCompiledQuery_method_ = makeFullMethodName("RunCompiledQuery");
/* 16948 */         this.AddAction_method_ = makeFullMethodName("AddAction");
/* 16949 */         this.AddActions_method_ = makeFullMethodName("AddActions");
/* 16950 */         this.Next_method_ = makeFullMethodName("Next");
/* 16951 */         this.Count_method_ = makeFullMethodName("Count");
/* 16952 */         this.DeleteCursor_method_ = makeFullMethodName("DeleteCursor");
/* 16953 */         this.BeginTransaction_method_ = makeFullMethodName("BeginTransaction");
/* 16954 */         this.Commit_method_ = makeFullMethodName("Commit");
/* 16955 */         this.Rollback_method_ = makeFullMethodName("Rollback");
/* 16956 */         this.GetSchema_method_ = makeFullMethodName("GetSchema");
/* 16957 */         this.AllocateIds_method_ = makeFullMethodName("AllocateIds");
/* 16958 */         this.CreateIndex_method_ = makeFullMethodName("CreateIndex");
/* 16959 */         this.UpdateIndex_method_ = makeFullMethodName("UpdateIndex");
/* 16960 */         this.GetIndices_method_ = makeFullMethodName("GetIndices");
/* 16961 */         this.DeleteIndex_method_ = makeFullMethodName("DeleteIndex");
/*       */       }
/*       */     }
/*       */ 
/*       */     private static class SimpleStub extends Rpc1CompatibilityStub
/*       */     {
/*       */       public SimpleStub(RpcStubParameters params)
/*       */       {
/* 16936 */         super(params, DatastorePb.DatastoreService.Method.class);
/*       */       }
/*       */     }
/*       */ 
/*       */     public static enum Method
/*       */     {
/* 16899 */       Get, 
/* 16900 */       Put, 
/* 16901 */       Touch, 
/* 16902 */       Delete, 
/* 16903 */       RunQuery, 
/* 16904 */       RunCompiledQuery, 
/* 16905 */       AddAction, 
/* 16906 */       AddActions, 
/* 16907 */       Next, 
/* 16908 */       Count, 
/* 16909 */       DeleteCursor, 
/* 16910 */       BeginTransaction, 
/* 16911 */       Commit, 
/* 16912 */       Rollback, 
/* 16913 */       GetSchema, 
/* 16914 */       AllocateIds, 
/* 16915 */       CreateIndex, 
/* 16916 */       UpdateIndex, 
/* 16917 */       GetIndices, 
/* 16918 */       DeleteIndex;
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class CommitResponse extends ProtocolMessage<CommitResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 16603 */     private DatastorePb.Cost cost_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final CommitResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kcost = 1;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final DatastorePb.Cost getCost()
/*       */     {
/* 16609 */       if (this.cost_ == null) {
/* 16610 */         return DatastorePb.Cost.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 16612 */       return this.cost_;
/*       */     }
/*       */     public final boolean hasCost() {
/* 16615 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public CommitResponse clearCost() {
/* 16618 */       this.optional_0_ &= -2;
/* 16619 */       if (this.cost_ != null) this.cost_.clear();
/* 16620 */       return this;
/*       */     }
/*       */     public CommitResponse setCost(DatastorePb.Cost x) {
/* 16623 */       if (x == null) throw new NullPointerException();
/* 16624 */       this.optional_0_ |= 1;
/* 16625 */       this.cost_ = x;
/* 16626 */       return this;
/*       */     }
/*       */     public DatastorePb.Cost getMutableCost() {
/* 16629 */       this.optional_0_ |= 1;
/* 16630 */       if (this.cost_ == null) this.cost_ = new DatastorePb.Cost();
/* 16631 */       return this.cost_;
/*       */     }
/*       */ 
/*       */     public CommitResponse mergeFrom(CommitResponse that)
/*       */     {
/* 16638 */       assert (that != this);
/* 16639 */       int this_t0 = this.optional_0_;
/* 16640 */       int that_t0 = that.optional_0_;
/*       */ 
/* 16642 */       if ((that_t0 & 0x1) != 0) {
/* 16643 */         this_t0 |= 1;
/* 16644 */         DatastorePb.Cost v = this.cost_;
/* 16645 */         if (v == null) this.cost_ = (v = new DatastorePb.Cost());
/* 16646 */         v.mergeFrom(that.cost_);
/*       */       }
/*       */ 
/* 16649 */       if (that.uninterpreted != null) {
/* 16650 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 16652 */       this.optional_0_ = this_t0;
/* 16653 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(CommitResponse that) {
/* 16657 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(CommitResponse that) {
/* 16661 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(CommitResponse that, boolean ignoreUninterpreted) {
/* 16665 */       if (that == null) return false;
/* 16666 */       if (that == this) return true;
/* 16667 */       int this_t0 = this.optional_0_;
/* 16668 */       int that_t0 = that.optional_0_;
/* 16669 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 16671 */       if (((this_t0 & 0x1) != 0) && 
/* 16672 */         (!this.cost_.equals(that.cost_, ignoreUninterpreted))) return false;
/*       */ 
/* 16675 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 16680 */       return ((that instanceof CommitResponse)) && (equals((CommitResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 16684 */       int hash = 1599213495;
/*       */ 
/* 16686 */       int this_t0 = this.optional_0_;
/* 16687 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.cost_.hashCode() : -113);
/* 16688 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 16689 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 16691 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 16696 */       int this_t0 = this.optional_0_;
/*       */ 
/* 16699 */       return ((this_t0 & 0x1) == 0) || 
/* 16698 */         (this.cost_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 16706 */       int n = 0;
/* 16707 */       int this_t0 = this.optional_0_;
/* 16708 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 16710 */         n += 1 + Protocol.stringSize(this.cost_.encodingSize());
/*       */       }
/*       */ 
/* 16713 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 16718 */       int n = 0;
/* 16719 */       int this_t0 = this.optional_0_;
/* 16720 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 16722 */         n += 6 + this.cost_.maxEncodingSize();
/*       */       }
/*       */ 
/* 16725 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 16730 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 16734 */       this.optional_0_ = 0;
/* 16735 */       if (this.cost_ != null) this.cost_.clear();
/* 16736 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public CommitResponse newInstance() {
/* 16740 */       return new CommitResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 16744 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 16765 */       int this_t0 = this.optional_0_;
/* 16766 */       if ((this_t0 & 0x1) != 0) {
/* 16767 */         sink.putByte(10);
/* 16768 */         sink.putForeign(this.cost_);
/*       */       }
/*       */ 
/* 16771 */       if (this.uninterpreted != null)
/* 16772 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 16777 */       boolean result = true;
/* 16778 */       int this_t0 = this.optional_0_;
/*       */ 
/* 16780 */       while (source.hasRemaining()) {
/* 16781 */         int tt = source.getVarInt();
/* 16782 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 16786 */           result = false;
/* 16787 */           break;
/*       */         case 10:
/* 16790 */           source.push(source.getVarInt());
/* 16791 */           DatastorePb.Cost v1 = this.cost_;
/* 16792 */           if (v1 == null) this.cost_ = (v1 = new DatastorePb.Cost());
/* 16793 */           if (!v1.merge(source)) { result = false; break label134; }
/* 16794 */           source.pop();
/* 16795 */           this_t0 |= 1;
/* 16796 */           break;
/*       */         default:
/* 16798 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 16803 */       label134: this.optional_0_ = this_t0;
/* 16804 */       return result;
/*       */     }
/*       */ 
/*       */     public CommitResponse getDefaultInstanceForType()
/*       */     {
/* 16809 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final CommitResponse getDefaultInstance() {
/* 16813 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public CommitResponse freeze()
/*       */     {
/* 16856 */       if (this.cost_ != null) this.cost_.freeze();
/* 16857 */       return this;
/*       */     }
/*       */ 
/*       */     public CommitResponse unfreeze() {
/* 16861 */       if (this.cost_ != null) this.cost_.unfreeze();
/* 16862 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 16866 */       return (this.cost_ != null) && (this.cost_.isFrozen());
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 16869 */       if (this.uninterpreted == null) {
/* 16870 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 16872 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 16817 */       IMMUTABLE_DEFAULT_INSTANCE = new CommitResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.CommitResponse clearCost()
/*       */         {
/* 16825 */           return this;
/*       */         }
/*       */         public DatastorePb.CommitResponse setCost(DatastorePb.Cost x) {
/* 16828 */           ProtocolSupport.unsupportedOperation();
/* 16829 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost getMutableCost() {
/* 16832 */           return (DatastorePb.Cost)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.CommitResponse mergeFrom(DatastorePb.CommitResponse that) {
/* 16836 */           ProtocolSupport.unsupportedOperation();
/* 16837 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 16840 */           ProtocolSupport.unsupportedOperation();
/* 16841 */           return false;
/*       */         }
/*       */         public DatastorePb.CommitResponse freeze() {
/* 16844 */           return this;
/*       */         }
/*       */         public DatastorePb.CommitResponse unfreeze() {
/* 16847 */           ProtocolSupport.unsupportedOperation();
/* 16848 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 16851 */           return true;
/*       */         }
/*       */       };
/* 16877 */       text = new String[2];
/*       */ 
/* 16879 */       text[0] = "ErrorCode";
/* 16880 */       text[1] = "cost";
/*       */ 
/* 16883 */       types = new int[2];
/*       */ 
/* 16885 */       Arrays.fill(types, 6);
/* 16886 */       types[0] = 0;
/* 16887 */       types[1] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 16748 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CommitResponse.class, "Z'apphosting/datastore/datastore_v3.proto\n&apphosting_datastore_v3.CommitResponse\023\032\004cost \001(\0020\0138\001J\034apphosting_datastore_v3.Cost\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("cost", "cost", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Cost.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class BeginTransactionRequest extends ProtocolMessage<BeginTransactionRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 16317 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final BeginTransactionRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kapp = 1;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/* 16323 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/* 16326 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public BeginTransactionRequest clearApp() {
/* 16329 */       this.optional_0_ &= -2;
/* 16330 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 16331 */       return this;
/*       */     }
/*       */     public BeginTransactionRequest setAppAsBytes(byte[] x) {
/* 16334 */       this.optional_0_ |= 1;
/* 16335 */       this.app_ = x;
/* 16336 */       return this;
/*       */     }
/*       */     public final String getApp() {
/* 16339 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public BeginTransactionRequest setApp(String v) {
/* 16342 */       if (v == null) throw new NullPointerException();
/* 16343 */       this.optional_0_ |= 1;
/* 16344 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/* 16345 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/* 16348 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public BeginTransactionRequest setApp(String v, Charset cs) {
/* 16351 */       if (v == null) throw new NullPointerException();
/* 16352 */       this.optional_0_ |= 1;
/* 16353 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/* 16354 */       return this;
/*       */     }
/*       */ 
/*       */     public BeginTransactionRequest mergeFrom(BeginTransactionRequest that)
/*       */     {
/* 16361 */       assert (that != this);
/* 16362 */       int this_t0 = this.optional_0_;
/* 16363 */       int that_t0 = that.optional_0_;
/*       */ 
/* 16365 */       if ((that_t0 & 0x1) != 0) {
/* 16366 */         this_t0 |= 1;
/* 16367 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/* 16370 */       if (that.uninterpreted != null) {
/* 16371 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 16373 */       this.optional_0_ = this_t0;
/* 16374 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(BeginTransactionRequest that) {
/* 16378 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(BeginTransactionRequest that) {
/* 16382 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(BeginTransactionRequest that, boolean ignoreUninterpreted) {
/* 16386 */       if (that == null) return false;
/* 16387 */       if (that == this) return true;
/* 16388 */       int this_t0 = this.optional_0_;
/* 16389 */       int that_t0 = that.optional_0_;
/* 16390 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 16392 */       if (((this_t0 & 0x1) != 0) && 
/* 16393 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/* 16396 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 16401 */       return ((that instanceof BeginTransactionRequest)) && (equals((BeginTransactionRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 16405 */       int hash = 949989369;
/*       */ 
/* 16407 */       int this_t0 = this.optional_0_;
/* 16408 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/* 16409 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 16410 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 16412 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 16416 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/* 16420 */       int n = 0;
/* 16421 */       int this_t0 = this.optional_0_;
/* 16422 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 16424 */         n += 1 + Protocol.stringSize(this.app_.length);
/*       */       }
/*       */ 
/* 16427 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 16432 */       int n = 0;
/* 16433 */       int this_t0 = this.optional_0_;
/* 16434 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 16436 */         n += 6 + this.app_.length;
/*       */       }
/*       */ 
/* 16439 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 16444 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 16448 */       this.optional_0_ = 0;
/* 16449 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 16450 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public BeginTransactionRequest newInstance() {
/* 16454 */       return new BeginTransactionRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 16458 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 16477 */       int this_t0 = this.optional_0_;
/* 16478 */       if ((this_t0 & 0x1) != 0) {
/* 16479 */         sink.putByte(10);
/* 16480 */         sink.putPrefixedData(this.app_);
/*       */       }
/*       */ 
/* 16483 */       if (this.uninterpreted != null)
/* 16484 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 16489 */       boolean result = true;
/* 16490 */       int this_t0 = this.optional_0_;
/*       */ 
/* 16492 */       while (source.hasRemaining()) {
/* 16493 */         int tt = source.getVarInt();
/* 16494 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 16498 */           result = false;
/* 16499 */           break;
/*       */         case 10:
/* 16502 */           this.app_ = source.getPrefixedData();
/* 16503 */           this_t0 |= 1;
/* 16504 */           break;
/*       */         default:
/* 16506 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 16511 */       this.optional_0_ = this_t0;
/* 16512 */       return result;
/*       */     }
/*       */ 
/*       */     public BeginTransactionRequest getDefaultInstanceForType()
/*       */     {
/* 16517 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final BeginTransactionRequest getDefaultInstance() {
/* 16521 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public BeginTransactionRequest freeze()
/*       */     {
/* 16569 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/* 16570 */       return this;
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 16573 */       if (this.uninterpreted == null) {
/* 16574 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 16576 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 16525 */       IMMUTABLE_DEFAULT_INSTANCE = new BeginTransactionRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.BeginTransactionRequest clearApp()
/*       */         {
/* 16533 */           return this;
/*       */         }
/*       */         public DatastorePb.BeginTransactionRequest setAppAsBytes(byte[] x) {
/* 16536 */           ProtocolSupport.unsupportedOperation();
/* 16537 */           return this;
/*       */         }
/*       */         public DatastorePb.BeginTransactionRequest setApp(String v) {
/* 16540 */           ProtocolSupport.unsupportedOperation();
/* 16541 */           return this;
/*       */         }
/*       */         public DatastorePb.BeginTransactionRequest setApp(String v, Charset cs) {
/* 16544 */           ProtocolSupport.unsupportedOperation();
/* 16545 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.BeginTransactionRequest mergeFrom(DatastorePb.BeginTransactionRequest that) {
/* 16549 */           ProtocolSupport.unsupportedOperation();
/* 16550 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 16553 */           ProtocolSupport.unsupportedOperation();
/* 16554 */           return false;
/*       */         }
/*       */         public DatastorePb.BeginTransactionRequest freeze() {
/* 16557 */           return this;
/*       */         }
/*       */         public DatastorePb.BeginTransactionRequest unfreeze() {
/* 16560 */           ProtocolSupport.unsupportedOperation();
/* 16561 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 16564 */           return true;
/*       */         }
/*       */       };
/* 16581 */       text = new String[2];
/*       */ 
/* 16583 */       text[0] = "ErrorCode";
/* 16584 */       text[1] = "app";
/*       */ 
/* 16587 */       types = new int[2];
/*       */ 
/* 16589 */       Arrays.fill(types, 6);
/* 16590 */       types[0] = 0;
/* 16591 */       types[1] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 16462 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.BeginTransactionRequest.class, "Z'apphosting/datastore/datastore_v3.proto\n/apphosting_datastore_v3.BeginTransactionRequest\023\032\003app \001(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class AddActionsResponse extends ProtocolMessage<AddActionsResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*       */     private UninterpretedTags uninterpreted;
/*       */     public static final AddActionsResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public AddActionsResponse mergeFrom(AddActionsResponse that)
/*       */     {
/* 16146 */       assert (that != this);
/*       */ 
/* 16148 */       if (that.uninterpreted != null) {
/* 16149 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 16151 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(AddActionsResponse that) {
/* 16155 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(AddActionsResponse that) {
/* 16159 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(AddActionsResponse that, boolean ignoreUninterpreted) {
/* 16163 */       if (that == null) return false;
/* 16164 */       if (that == this) return true;
/*       */ 
/* 16166 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 16171 */       return ((that instanceof AddActionsResponse)) && (equals((AddActionsResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 16175 */       int hash = 416477314;
/* 16176 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 16177 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 16179 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 16183 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/* 16187 */       int n = 0;
/*       */ 
/* 16189 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 16194 */       int n = 0;
/*       */ 
/* 16196 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 16201 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 16205 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public AddActionsResponse newInstance() {
/* 16209 */       return new AddActionsResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 16213 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 16229 */       if (this.uninterpreted != null)
/* 16230 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 16235 */       boolean result = true;
/*       */ 
/* 16237 */       while (source.hasRemaining()) {
/* 16238 */         int tt = source.getVarInt();
/* 16239 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 16243 */           result = false;
/* 16244 */           break;
/*       */         default:
/* 16246 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 16251 */       return result;
/*       */     }
/*       */ 
/*       */     public AddActionsResponse getDefaultInstanceForType()
/*       */     {
/* 16256 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final AddActionsResponse getDefaultInstance() {
/* 16260 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/* 16290 */       if (this.uninterpreted == null) {
/* 16291 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 16293 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 16264 */       IMMUTABLE_DEFAULT_INSTANCE = new AddActionsResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.AddActionsResponse mergeFrom(DatastorePb.AddActionsResponse that)
/*       */         {
/* 16271 */           ProtocolSupport.unsupportedOperation();
/* 16272 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 16275 */           ProtocolSupport.unsupportedOperation();
/* 16276 */           return false;
/*       */         }
/*       */         public DatastorePb.AddActionsResponse freeze() {
/* 16279 */           return this;
/*       */         }
/*       */         public DatastorePb.AddActionsResponse unfreeze() {
/* 16282 */           ProtocolSupport.unsupportedOperation();
/* 16283 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 16286 */           return true;
/*       */         }
/*       */       };
/* 16297 */       text = new String[1];
/*       */ 
/* 16299 */       text[0] = "ErrorCode";
/*       */ 
/* 16302 */       types = new int[1];
/*       */ 
/* 16304 */       Arrays.fill(types, 6);
/* 16305 */       types[0] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 16217 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.AddActionsResponse.class, "Z'apphosting/datastore/datastore_v3.proto\n*apphosting_datastore_v3.AddActionsResponse", new ProtocolType.FieldType[0]);
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class AddActionsRequest extends ProtocolMessage<AddActionsRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 15730 */     private DatastorePb.Transaction transaction_ = new DatastorePb.Transaction();
/* 15731 */     private List<OnestoreAction.Action> action_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final AddActionsRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int ktransaction = 1;
/*       */     public static final int kaction = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final DatastorePb.Transaction getTransaction()
/*       */     {
/* 15737 */       return this.transaction_;
/*       */     }
/*       */     public final boolean hasTransaction() {
/* 15740 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public AddActionsRequest clearTransaction() {
/* 15743 */       this.optional_0_ &= -2;
/* 15744 */       this.transaction_.clear();
/* 15745 */       return this;
/*       */     }
/*       */     public AddActionsRequest setTransaction(DatastorePb.Transaction x) {
/* 15748 */       if (x == null) throw new NullPointerException();
/* 15749 */       this.optional_0_ |= 1;
/* 15750 */       this.transaction_ = x;
/* 15751 */       return this;
/*       */     }
/*       */     public DatastorePb.Transaction getMutableTransaction() {
/* 15754 */       this.optional_0_ |= 1;
/* 15755 */       return this.transaction_;
/*       */     }
/*       */ 
/*       */     public final int actionSize()
/*       */     {
/* 15760 */       return this.action_ != null ? this.action_.size() : 0;
/*       */     }
/*       */     public final OnestoreAction.Action getAction(int i) {
/* 15763 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.action_ != null ? this.action_.size() : 0)); } else throw new AssertionError();
/* 15764 */       return (OnestoreAction.Action)this.action_.get(i);
/*       */     }
/*       */     public AddActionsRequest clearAction() {
/* 15767 */       if (this.action_ != null) this.action_.clear();
/* 15768 */       return this;
/*       */     }
/*       */     public OnestoreAction.Action getMutableAction(int i) {
/* 15771 */       assert ((i >= 0) && (this.action_ != null) && (i < this.action_.size()));
/* 15772 */       return (OnestoreAction.Action)this.action_.get(i);
/*       */     }
/*       */     public OnestoreAction.Action addAction() {
/* 15775 */       OnestoreAction.Action v = new OnestoreAction.Action();
/* 15776 */       if (this.action_ == null) this.action_ = new ArrayList(4);
/* 15777 */       this.action_.add(v);
/* 15778 */       return v;
/*       */     }
/*       */     public OnestoreAction.Action addAction(OnestoreAction.Action v) {
/* 15781 */       if (this.action_ == null) this.action_ = new ArrayList(4);
/* 15782 */       this.action_.add(v);
/* 15783 */       return v;
/*       */     }
/*       */     public OnestoreAction.Action insertAction(int i, OnestoreAction.Action v) {
/* 15786 */       if (this.action_ == null) this.action_ = new ArrayList(4);
/* 15787 */       this.action_.add(i, v);
/* 15788 */       return v;
/*       */     }
/*       */     public OnestoreAction.Action removeAction(int i) {
/* 15791 */       return (OnestoreAction.Action)this.action_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreAction.Action> actionIterator() {
/* 15794 */       if (this.action_ == null) {
/* 15795 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 15797 */       return this.action_.iterator();
/*       */     }
/*       */     public final List<OnestoreAction.Action> actions() {
/* 15800 */       return ProtocolSupport.unmodifiableList(this.action_);
/*       */     }
/*       */     public final List<OnestoreAction.Action> mutableActions() {
/* 15803 */       if (this.action_ == null) this.action_ = new ArrayList(4);
/* 15804 */       return this.action_;
/*       */     }
/*       */ 
/*       */     public AddActionsRequest mergeFrom(AddActionsRequest that)
/*       */     {
/* 15811 */       assert (that != this);
/* 15812 */       int this_t0 = this.optional_0_;
/* 15813 */       int that_t0 = that.optional_0_;
/*       */ 
/* 15815 */       if ((that_t0 & 0x1) != 0) {
/* 15816 */         this_t0 |= 1;
/* 15817 */         DatastorePb.Transaction v = this.transaction_;
/* 15818 */         v.mergeFrom(that.transaction_);
/*       */       }
/*       */ 
/* 15821 */       if (that.action_ != null) {
/* 15822 */         for (OnestoreAction.Action v : that.action_) {
/* 15823 */           addAction().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 15827 */       if (that.uninterpreted != null) {
/* 15828 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 15830 */       this.optional_0_ = this_t0;
/* 15831 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(AddActionsRequest that) {
/* 15835 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(AddActionsRequest that) {
/* 15839 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(AddActionsRequest that, boolean ignoreUninterpreted) {
/* 15843 */       if (that == null) return false;
/* 15844 */       if (that == this) return true;
/* 15845 */       int this_t0 = this.optional_0_;
/* 15846 */       int that_t0 = that.optional_0_;
/* 15847 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 15849 */       if (((this_t0 & 0x1) != 0) && 
/* 15850 */         (!this.transaction_.equals(that.transaction_, ignoreUninterpreted))) return false;
/* 15854 */       int n;
/* 15854 */       if ((n = this.action_ != null ? this.action_.size() : 0) != (that.action_ != null ? that.action_.size() : 0)) return false;
/* 15855 */       for (int i = 0; i < n; i++) {
/* 15856 */         if (!((OnestoreAction.Action)this.action_.get(i)).equals((OnestoreAction.Action)that.action_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 15859 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 15864 */       return ((that instanceof AddActionsRequest)) && (equals((AddActionsRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 15868 */       int hash = 401159748;
/*       */ 
/* 15870 */       int this_t0 = this.optional_0_;
/* 15871 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.transaction_.hashCode() : -113);
/*       */ 
/* 15873 */       hash *= 31;
/* 15874 */       int i = 0; for (int n = this.action_ != null ? this.action_.size() : 0; i < n; i++) {
/* 15875 */         hash = hash * 31 + ((OnestoreAction.Action)this.action_.get(i)).hashCode();
/*       */       }
/* 15877 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 15878 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 15880 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 15884 */       int this_t0 = this.optional_0_;
/* 15885 */       if ((this_t0 & 0x1) != 1) {
/* 15886 */         return false;
/*       */       }
/*       */ 
/* 15889 */       if (!this.transaction_.isInitialized()) {
/* 15890 */         return false;
/*       */       }
/*       */ 
/* 15893 */       if (this.action_ != null) {
/* 15894 */         for (OnestoreAction.Action v : this.action_) {
/* 15895 */           if (!v.isInitialized()) {
/* 15896 */             return false;
/*       */           }
/*       */         }
/*       */       }
/* 15900 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 15905 */       int n = 1 + Protocol.stringSize(this.transaction_.encodingSize());
/*       */       int m;
/* 15908 */       n += (m = this.action_ != null ? this.action_.size() : 0);
/* 15909 */       for (int i = 0; i < m; i++) {
/* 15910 */         n += Protocol.stringSize(((OnestoreAction.Action)this.action_.get(i)).encodingSize());
/*       */       }
/*       */ 
/* 15913 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 15919 */       int n = 6 + this.transaction_.maxEncodingSize();
/*       */       int m;
/* 15922 */       n += 6 * (m = this.action_ != null ? this.action_.size() : 0);
/* 15923 */       for (int i = 0; i < m; i++) {
/* 15924 */         n += ((OnestoreAction.Action)this.action_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/* 15927 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 15932 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 15936 */       this.optional_0_ = 0;
/* 15937 */       this.transaction_.clear();
/* 15938 */       if (this.action_ != null) this.action_.clear();
/* 15939 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public AddActionsRequest newInstance() {
/* 15943 */       return new AddActionsRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 15947 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 15974 */       sink.putByte(10);
/* 15975 */       sink.putForeign(this.transaction_);
/*       */ 
/* 15977 */       int i = 0; for (int m = this.action_ != null ? this.action_.size() : 0; i < m; i++) {
/* 15978 */         OnestoreAction.Action v = (OnestoreAction.Action)this.action_.get(i);
/* 15979 */         sink.putByte(18);
/* 15980 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 15983 */       if (this.uninterpreted != null)
/* 15984 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 15989 */       boolean result = true;
/* 15990 */       int this_t0 = this.optional_0_;
/*       */ 
/* 15992 */       while (source.hasRemaining()) {
/* 15993 */         int tt = source.getVarInt();
/* 15994 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 15998 */           result = false;
/* 15999 */           break;
/*       */         case 10:
/* 16002 */           source.push(source.getVarInt());
/* 16003 */           if (!this.transaction_.merge(source)) { result = false; break label152; }
/* 16004 */           source.pop();
/* 16005 */           this_t0 |= 1;
/* 16006 */           break;
/*       */         case 18:
/* 16009 */           source.push(source.getVarInt());
/* 16010 */           if (!addAction().merge(source)) { result = false; break label152; }
/* 16011 */           source.pop();
/* 16012 */           break;
/*       */         default:
/* 16014 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 16019 */       label152: this.optional_0_ = this_t0;
/* 16020 */       return result;
/*       */     }
/*       */ 
/*       */     public AddActionsRequest getDefaultInstanceForType()
/*       */     {
/* 16025 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final AddActionsRequest getDefaultInstance() {
/* 16029 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public AddActionsRequest freeze()
/*       */     {
/* 16092 */       this.transaction_.freeze();
/* 16093 */       this.action_ = ProtocolSupport.freezeMessages(this.action_);
/* 16094 */       return this;
/*       */     }
/*       */ 
/*       */     public AddActionsRequest unfreeze() {
/* 16098 */       this.transaction_.unfreeze();
/* 16099 */       this.action_ = ProtocolSupport.unfreezeMessages(this.action_);
/* 16100 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 16104 */       return (this.transaction_.isFrozen()) || (ProtocolSupport.isFrozenMessages(this.action_));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 16108 */       if (this.uninterpreted == null) {
/* 16109 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 16111 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 16033 */       IMMUTABLE_DEFAULT_INSTANCE = new AddActionsRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.AddActionsRequest clearTransaction()
/*       */         {
/* 16041 */           return this;
/*       */         }
/*       */         public DatastorePb.AddActionsRequest setTransaction(DatastorePb.Transaction x) {
/* 16044 */           ProtocolSupport.unsupportedOperation();
/* 16045 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction getMutableTransaction() {
/* 16048 */           return (DatastorePb.Transaction)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.AddActionsRequest clearAction()
/*       */         {
/* 16053 */           return this;
/*       */         }
/*       */         public OnestoreAction.Action getMutableAction(int i) {
/* 16056 */           return (OnestoreAction.Action)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreAction.Action addAction() {
/* 16059 */           return (OnestoreAction.Action)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreAction.Action addAction(OnestoreAction.Action v) {
/* 16062 */           return (OnestoreAction.Action)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreAction.Action insertAction(int i, OnestoreAction.Action v) {
/* 16065 */           return (OnestoreAction.Action)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreAction.Action removeAction(int i) {
/* 16068 */           return (OnestoreAction.Action)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.AddActionsRequest mergeFrom(DatastorePb.AddActionsRequest that) {
/* 16072 */           ProtocolSupport.unsupportedOperation();
/* 16073 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 16076 */           ProtocolSupport.unsupportedOperation();
/* 16077 */           return false;
/*       */         }
/*       */         public DatastorePb.AddActionsRequest freeze() {
/* 16080 */           return this;
/*       */         }
/*       */         public DatastorePb.AddActionsRequest unfreeze() {
/* 16083 */           ProtocolSupport.unsupportedOperation();
/* 16084 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 16087 */           return true;
/*       */         }
/*       */       };
/* 16117 */       text = new String[3];
/*       */ 
/* 16119 */       text[0] = "ErrorCode";
/* 16120 */       text[1] = "transaction";
/* 16121 */       text[2] = "action";
/*       */ 
/* 16124 */       types = new int[3];
/*       */ 
/* 16126 */       Arrays.fill(types, 6);
/* 16127 */       types[0] = 0;
/* 16128 */       types[1] = 2;
/* 16129 */       types[2] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 15951 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.AddActionsRequest.class, "Z'apphosting/datastore/datastore_v3.proto\n)apphosting_datastore_v3.AddActionsRequest\023\032\013transaction \001(\0020\0138\002J#apphosting_datastore_v3.Transaction\024\023\032\006action \002(\0020\0138\003J\032storage_onestore_v3.Action\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("transaction", "transaction", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, DatastorePb.Transaction.class), new ProtocolType.FieldType("action", "action", 2, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreAction.Action.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class CompositeIndices extends ProtocolMessage<CompositeIndices>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 15410 */     private List<OnestoreEntity.CompositeIndex> index_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     public static final CompositeIndices IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kindex = 1;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int indexSize()
/*       */     {
/* 15415 */       return this.index_ != null ? this.index_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.CompositeIndex getIndex(int i) {
/* 15418 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.index_ != null ? this.index_.size() : 0)); } else throw new AssertionError();
/* 15419 */       return (OnestoreEntity.CompositeIndex)this.index_.get(i);
/*       */     }
/*       */     public CompositeIndices clearIndex() {
/* 15422 */       if (this.index_ != null) this.index_.clear();
/* 15423 */       return this;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex getMutableIndex(int i) {
/* 15426 */       assert ((i >= 0) && (this.index_ != null) && (i < this.index_.size()));
/* 15427 */       return (OnestoreEntity.CompositeIndex)this.index_.get(i);
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addIndex() {
/* 15430 */       OnestoreEntity.CompositeIndex v = new OnestoreEntity.CompositeIndex();
/* 15431 */       if (this.index_ == null) this.index_ = new ArrayList(4);
/* 15432 */       this.index_.add(v);
/* 15433 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addIndex(OnestoreEntity.CompositeIndex v) {
/* 15436 */       if (this.index_ == null) this.index_ = new ArrayList(4);
/* 15437 */       this.index_.add(v);
/* 15438 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex insertIndex(int i, OnestoreEntity.CompositeIndex v) {
/* 15441 */       if (this.index_ == null) this.index_ = new ArrayList(4);
/* 15442 */       this.index_.add(i, v);
/* 15443 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex removeIndex(int i) {
/* 15446 */       return (OnestoreEntity.CompositeIndex)this.index_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.CompositeIndex> indexIterator() {
/* 15449 */       if (this.index_ == null) {
/* 15450 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 15452 */       return this.index_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> indexs() {
/* 15455 */       return ProtocolSupport.unmodifiableList(this.index_);
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> mutableIndexs() {
/* 15458 */       if (this.index_ == null) this.index_ = new ArrayList(4);
/* 15459 */       return this.index_;
/*       */     }
/*       */ 
/*       */     public CompositeIndices mergeFrom(CompositeIndices that)
/*       */     {
/* 15466 */       assert (that != this);
/*       */ 
/* 15468 */       if (that.index_ != null) {
/* 15469 */         for (OnestoreEntity.CompositeIndex v : that.index_) {
/* 15470 */           addIndex().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 15474 */       if (that.uninterpreted != null) {
/* 15475 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 15477 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(CompositeIndices that) {
/* 15481 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(CompositeIndices that) {
/* 15485 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(CompositeIndices that, boolean ignoreUninterpreted) {
/* 15489 */       if (that == null) return false;
/* 15490 */       if (that == this) return true;
/* 15493 */       int n;
/* 15493 */       if ((n = this.index_ != null ? this.index_.size() : 0) != (that.index_ != null ? that.index_.size() : 0)) return false;
/* 15494 */       for (int i = 0; i < n; i++) {
/* 15495 */         if (!((OnestoreEntity.CompositeIndex)this.index_.get(i)).equals((OnestoreEntity.CompositeIndex)that.index_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 15498 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 15503 */       return ((that instanceof CompositeIndices)) && (equals((CompositeIndices)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 15507 */       int hash = -647753241;
/*       */ 
/* 15509 */       hash *= 31;
/* 15510 */       int i = 0; for (int n = this.index_ != null ? this.index_.size() : 0; i < n; i++) {
/* 15511 */         hash = hash * 31 + ((OnestoreEntity.CompositeIndex)this.index_.get(i)).hashCode();
/*       */       }
/* 15513 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 15514 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 15516 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 15521 */       if (this.index_ != null) {
/* 15522 */         for (OnestoreEntity.CompositeIndex v : this.index_) {
/* 15523 */           if (!v.isInitialized()) {
/* 15524 */             return false;
/*       */           }
/*       */         }
/*       */       }
/* 15528 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/* 15532 */       int n = 0;
/*       */       int m;
/* 15535 */       n += (m = this.index_ != null ? this.index_.size() : 0);
/* 15536 */       for (int i = 0; i < m; i++) {
/* 15537 */         n += Protocol.stringSize(((OnestoreEntity.CompositeIndex)this.index_.get(i)).encodingSize());
/*       */       }
/*       */ 
/* 15540 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 15545 */       int n = 0;
/*       */       int m;
/* 15548 */       n += 6 * (m = this.index_ != null ? this.index_.size() : 0);
/* 15549 */       for (int i = 0; i < m; i++) {
/* 15550 */         n += ((OnestoreEntity.CompositeIndex)this.index_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/* 15553 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 15558 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 15562 */       if (this.index_ != null) this.index_.clear();
/* 15563 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public CompositeIndices newInstance() {
/* 15567 */       return new CompositeIndices();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 15571 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 15593 */       int i = 0; for (int m = this.index_ != null ? this.index_.size() : 0; i < m; i++) {
/* 15594 */         OnestoreEntity.CompositeIndex v = (OnestoreEntity.CompositeIndex)this.index_.get(i);
/* 15595 */         sink.putByte(10);
/* 15596 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 15599 */       if (this.uninterpreted != null)
/* 15600 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 15605 */       boolean result = true;
/*       */ 
/* 15607 */       while (source.hasRemaining()) {
/* 15608 */         int tt = source.getVarInt();
/* 15609 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 15613 */           result = false;
/* 15614 */           break;
/*       */         case 10:
/* 15617 */           source.push(source.getVarInt());
/* 15618 */           if (!addIndex().merge(source)) { result = false; break label97; }
/* 15619 */           source.pop();
/* 15620 */           break;
/*       */         default:
/* 15622 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 15627 */       label97: return result;
/*       */     }
/*       */ 
/*       */     public CompositeIndices getDefaultInstanceForType()
/*       */     {
/* 15632 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final CompositeIndices getDefaultInstance() {
/* 15636 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public CompositeIndices freeze()
/*       */     {
/* 15687 */       this.index_ = ProtocolSupport.freezeMessages(this.index_);
/* 15688 */       return this;
/*       */     }
/*       */ 
/*       */     public CompositeIndices unfreeze() {
/* 15692 */       this.index_ = ProtocolSupport.unfreezeMessages(this.index_);
/* 15693 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 15697 */       return ProtocolSupport.isFrozenMessages(this.index_);
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 15700 */       if (this.uninterpreted == null) {
/* 15701 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 15703 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 15640 */       IMMUTABLE_DEFAULT_INSTANCE = new CompositeIndices()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.CompositeIndices clearIndex()
/*       */         {
/* 15648 */           return this;
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex getMutableIndex(int i) {
/* 15651 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addIndex() {
/* 15654 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addIndex(OnestoreEntity.CompositeIndex v) {
/* 15657 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex insertIndex(int i, OnestoreEntity.CompositeIndex v) {
/* 15660 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex removeIndex(int i) {
/* 15663 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompositeIndices mergeFrom(DatastorePb.CompositeIndices that) {
/* 15667 */           ProtocolSupport.unsupportedOperation();
/* 15668 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 15671 */           ProtocolSupport.unsupportedOperation();
/* 15672 */           return false;
/*       */         }
/*       */         public DatastorePb.CompositeIndices freeze() {
/* 15675 */           return this;
/*       */         }
/*       */         public DatastorePb.CompositeIndices unfreeze() {
/* 15678 */           ProtocolSupport.unsupportedOperation();
/* 15679 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 15682 */           return true;
/*       */         }
/*       */       };
/* 15708 */       text = new String[2];
/*       */ 
/* 15710 */       text[0] = "ErrorCode";
/* 15711 */       text[1] = "index";
/*       */ 
/* 15714 */       types = new int[2];
/*       */ 
/* 15716 */       Arrays.fill(types, 6);
/* 15717 */       types[0] = 0;
/* 15718 */       types[1] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 15575 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompositeIndices.class, "Z'apphosting/datastore/datastore_v3.proto\n(apphosting_datastore_v3.CompositeIndices\023\032\005index \001(\0020\0138\003J\"storage_onestore_v3.CompositeIndex\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("index", "index", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.CompositeIndex.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class AllocateIdsResponse extends ProtocolMessage<AllocateIdsResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 15103 */     private long start_ = 0L;
/* 15104 */     private long end_ = 0L;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final AllocateIdsResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kstart = 1;
/*       */     public static final int kend = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final long getStart()
/*       */     {
/* 15110 */       return this.start_;
/*       */     }
/*       */     public final boolean hasStart() {
/* 15113 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public AllocateIdsResponse clearStart() {
/* 15116 */       this.optional_0_ &= -2;
/* 15117 */       this.start_ = 0L;
/* 15118 */       return this;
/*       */     }
/*       */     public AllocateIdsResponse setStart(long x) {
/* 15121 */       this.optional_0_ |= 1;
/* 15122 */       this.start_ = x;
/* 15123 */       return this;
/*       */     }
/*       */ 
/*       */     public final long getEnd()
/*       */     {
/* 15128 */       return this.end_;
/*       */     }
/*       */     public final boolean hasEnd() {
/* 15131 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public AllocateIdsResponse clearEnd() {
/* 15134 */       this.optional_0_ &= -3;
/* 15135 */       this.end_ = 0L;
/* 15136 */       return this;
/*       */     }
/*       */     public AllocateIdsResponse setEnd(long x) {
/* 15139 */       this.optional_0_ |= 2;
/* 15140 */       this.end_ = x;
/* 15141 */       return this;
/*       */     }
/*       */ 
/*       */     public AllocateIdsResponse mergeFrom(AllocateIdsResponse that)
/*       */     {
/* 15148 */       assert (that != this);
/* 15149 */       int this_t0 = this.optional_0_;
/* 15150 */       int that_t0 = that.optional_0_;
/*       */ 
/* 15152 */       if ((that_t0 & 0x1) != 0) {
/* 15153 */         this_t0 |= 1;
/* 15154 */         this.start_ = that.start_;
/*       */       }
/*       */ 
/* 15157 */       if ((that_t0 & 0x2) != 0) {
/* 15158 */         this_t0 |= 2;
/* 15159 */         this.end_ = that.end_;
/*       */       }
/*       */ 
/* 15162 */       if (that.uninterpreted != null) {
/* 15163 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 15165 */       this.optional_0_ = this_t0;
/* 15166 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(AllocateIdsResponse that) {
/* 15170 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(AllocateIdsResponse that) {
/* 15174 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(AllocateIdsResponse that, boolean ignoreUninterpreted) {
/* 15178 */       if (that == null) return false;
/* 15179 */       if (that == this) return true;
/* 15180 */       int this_t0 = this.optional_0_;
/* 15181 */       int that_t0 = that.optional_0_;
/* 15182 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 15184 */       if (((this_t0 & 0x1) != 0) && 
/* 15185 */         (this.start_ != that.start_)) return false;
/*       */ 
/* 15188 */       if (((this_t0 & 0x2) != 0) && 
/* 15189 */         (this.end_ != that.end_)) return false;
/*       */ 
/* 15192 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 15197 */       return ((that instanceof AllocateIdsResponse)) && (equals((AllocateIdsResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 15201 */       int hash = 1676765166;
/*       */ 
/* 15203 */       int this_t0 = this.optional_0_;
/* 15204 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.start_) : -113);
/*       */ 
/* 15206 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.end_) : -113);
/* 15207 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 15208 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 15210 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 15214 */       int this_t0 = this.optional_0_;
/* 15215 */       if ((this_t0 & 0x3) != 3)
/*       */       {
/* 15217 */         return (this_t0 & 0x1) != 0;
/*       */       }
/*       */ 
/* 15221 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 15227 */       int n = 2 + Protocol.varLongSize(this.start_) + Protocol.varLongSize(this.end_);
/*       */ 
/* 15229 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 15236 */       int n = 22;
/*       */ 
/* 15238 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 15243 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 15247 */       this.optional_0_ = 0;
/* 15248 */       this.start_ = 0L;
/* 15249 */       this.end_ = 0L;
/* 15250 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public AllocateIdsResponse newInstance() {
/* 15254 */       return new AllocateIdsResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 15258 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 15280 */       sink.putByte(8);
/* 15281 */       sink.putVarLong(this.start_);
/*       */ 
/* 15283 */       sink.putByte(16);
/* 15284 */       sink.putVarLong(this.end_);
/*       */ 
/* 15286 */       if (this.uninterpreted != null)
/* 15287 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 15292 */       boolean result = true;
/* 15293 */       int this_t0 = this.optional_0_;
/*       */ 
/* 15295 */       while (source.hasRemaining()) {
/* 15296 */         int tt = source.getVarInt();
/* 15297 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 15301 */           result = false;
/* 15302 */           break;
/*       */         case 8:
/* 15305 */           this.start_ = source.getVarLong();
/* 15306 */           this_t0 |= 1;
/* 15307 */           break;
/*       */         case 16:
/* 15310 */           this.end_ = source.getVarLong();
/* 15311 */           this_t0 |= 2;
/* 15312 */           break;
/*       */         default:
/* 15314 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 15319 */       this.optional_0_ = this_t0;
/* 15320 */       return result;
/*       */     }
/*       */ 
/*       */     public AllocateIdsResponse getDefaultInstanceForType()
/*       */     {
/* 15325 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final AllocateIdsResponse getDefaultInstance() {
/* 15329 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/* 15377 */       if (this.uninterpreted == null) {
/* 15378 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 15380 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 15333 */       IMMUTABLE_DEFAULT_INSTANCE = new AllocateIdsResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.AllocateIdsResponse clearStart()
/*       */         {
/* 15341 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsResponse setStart(long x) {
/* 15344 */           ProtocolSupport.unsupportedOperation();
/* 15345 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.AllocateIdsResponse clearEnd()
/*       */         {
/* 15350 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsResponse setEnd(long x) {
/* 15353 */           ProtocolSupport.unsupportedOperation();
/* 15354 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.AllocateIdsResponse mergeFrom(DatastorePb.AllocateIdsResponse that) {
/* 15358 */           ProtocolSupport.unsupportedOperation();
/* 15359 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 15362 */           ProtocolSupport.unsupportedOperation();
/* 15363 */           return false;
/*       */         }
/*       */         public DatastorePb.AllocateIdsResponse freeze() {
/* 15366 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsResponse unfreeze() {
/* 15369 */           ProtocolSupport.unsupportedOperation();
/* 15370 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 15373 */           return true;
/*       */         }
/*       */       };
/* 15386 */       text = new String[3];
/*       */ 
/* 15388 */       text[0] = "ErrorCode";
/* 15389 */       text[1] = "start";
/* 15390 */       text[2] = "end";
/*       */ 
/* 15393 */       types = new int[3];
/*       */ 
/* 15395 */       Arrays.fill(types, 6);
/* 15396 */       types[0] = 0;
/* 15397 */       types[1] = 0;
/* 15398 */       types[2] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 15262 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.AllocateIdsResponse.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("start", "start", 1, 0, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("end", "end", 2, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.REQUIRED) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class AllocateIdsRequest extends ProtocolMessage<AllocateIdsRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 14697 */     private OnestoreEntity.Reference model_key_ = new OnestoreEntity.Reference();
/* 14698 */     private long size_ = 0L;
/* 14699 */     private long max_ = 0L;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final AllocateIdsRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kmodel_key = 1;
/*       */     public static final int ksize = 2;
/*       */     public static final int kmax = 3;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final OnestoreEntity.Reference getModelKey()
/*       */     {
/* 14705 */       return this.model_key_;
/*       */     }
/*       */     public final boolean hasModelKey() {
/* 14708 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public AllocateIdsRequest clearModelKey() {
/* 14711 */       this.optional_0_ &= -2;
/* 14712 */       this.model_key_.clear();
/* 14713 */       return this;
/*       */     }
/*       */     public AllocateIdsRequest setModelKey(OnestoreEntity.Reference x) {
/* 14716 */       if (x == null) throw new NullPointerException();
/* 14717 */       this.optional_0_ |= 1;
/* 14718 */       this.model_key_ = x;
/* 14719 */       return this;
/*       */     }
/*       */     public OnestoreEntity.Reference getMutableModelKey() {
/* 14722 */       this.optional_0_ |= 1;
/* 14723 */       return this.model_key_;
/*       */     }
/*       */ 
/*       */     public final long getSize()
/*       */     {
/* 14728 */       return this.size_;
/*       */     }
/*       */     public final boolean hasSize() {
/* 14731 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public AllocateIdsRequest clearSize() {
/* 14734 */       this.optional_0_ &= -3;
/* 14735 */       this.size_ = 0L;
/* 14736 */       return this;
/*       */     }
/*       */     public AllocateIdsRequest setSize(long x) {
/* 14739 */       this.optional_0_ |= 2;
/* 14740 */       this.size_ = x;
/* 14741 */       return this;
/*       */     }
/*       */ 
/*       */     public final long getMax()
/*       */     {
/* 14746 */       return this.max_;
/*       */     }
/*       */     public final boolean hasMax() {
/* 14749 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public AllocateIdsRequest clearMax() {
/* 14752 */       this.optional_0_ &= -5;
/* 14753 */       this.max_ = 0L;
/* 14754 */       return this;
/*       */     }
/*       */     public AllocateIdsRequest setMax(long x) {
/* 14757 */       this.optional_0_ |= 4;
/* 14758 */       this.max_ = x;
/* 14759 */       return this;
/*       */     }
/*       */ 
/*       */     public AllocateIdsRequest mergeFrom(AllocateIdsRequest that)
/*       */     {
/* 14766 */       assert (that != this);
/* 14767 */       int this_t0 = this.optional_0_;
/* 14768 */       int that_t0 = that.optional_0_;
/*       */ 
/* 14770 */       if ((that_t0 & 0x1) != 0) {
/* 14771 */         this_t0 |= 1;
/* 14772 */         OnestoreEntity.Reference v = this.model_key_;
/* 14773 */         v.mergeFrom(that.model_key_);
/*       */       }
/*       */ 
/* 14776 */       if ((that_t0 & 0x2) != 0) {
/* 14777 */         this_t0 |= 2;
/* 14778 */         this.size_ = that.size_;
/*       */       }
/*       */ 
/* 14781 */       if ((that_t0 & 0x4) != 0) {
/* 14782 */         this_t0 |= 4;
/* 14783 */         this.max_ = that.max_;
/*       */       }
/*       */ 
/* 14786 */       if (that.uninterpreted != null) {
/* 14787 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 14789 */       this.optional_0_ = this_t0;
/* 14790 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(AllocateIdsRequest that) {
/* 14794 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(AllocateIdsRequest that) {
/* 14798 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(AllocateIdsRequest that, boolean ignoreUninterpreted) {
/* 14802 */       if (that == null) return false;
/* 14803 */       if (that == this) return true;
/* 14804 */       int this_t0 = this.optional_0_;
/* 14805 */       int that_t0 = that.optional_0_;
/* 14806 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 14808 */       if (((this_t0 & 0x1) != 0) && 
/* 14809 */         (!this.model_key_.equals(that.model_key_, ignoreUninterpreted))) return false;
/*       */ 
/* 14812 */       if (((this_t0 & 0x2) != 0) && 
/* 14813 */         (this.size_ != that.size_)) return false;
/*       */ 
/* 14816 */       if (((this_t0 & 0x4) != 0) && 
/* 14817 */         (this.max_ != that.max_)) return false;
/*       */ 
/* 14820 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 14825 */       return ((that instanceof AllocateIdsRequest)) && (equals((AllocateIdsRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 14829 */       int hash = -268543430;
/*       */ 
/* 14831 */       int this_t0 = this.optional_0_;
/* 14832 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.model_key_.hashCode() : -113);
/*       */ 
/* 14834 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.size_) : -113);
/*       */ 
/* 14836 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? ProtocolSupport.hashCode(this.max_) : -113);
/* 14837 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 14838 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 14840 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 14844 */       int this_t0 = this.optional_0_;
/* 14845 */       if ((this_t0 & 0x1) != 1) {
/* 14846 */         return false;
/*       */       }
/*       */ 
/* 14850 */       return this.model_key_.isInitialized();
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 14857 */       int n = 1 + Protocol.stringSize(this.model_key_.encodingSize());
/* 14858 */       int this_t0 = this.optional_0_;
/* 14859 */       if ((this_t0 & 0x6) != 0) {
/* 14860 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 14862 */           n += 1 + Protocol.varLongSize(this.size_);
/*       */         }
/* 14864 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/* 14866 */           n += 1 + Protocol.varLongSize(this.max_);
/*       */         }
/*       */       }
/*       */ 
/* 14870 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 14878 */       int n = 28 + this.model_key_.maxEncodingSize();
/*       */ 
/* 14880 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 14885 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 14889 */       this.optional_0_ = 0;
/* 14890 */       this.model_key_.clear();
/* 14891 */       this.size_ = 0L;
/* 14892 */       this.max_ = 0L;
/* 14893 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public AllocateIdsRequest newInstance() {
/* 14897 */       return new AllocateIdsRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 14901 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 14929 */       sink.putByte(10);
/* 14930 */       sink.putForeign(this.model_key_);
/*       */ 
/* 14932 */       int this_t0 = this.optional_0_;
/* 14933 */       if ((this_t0 & 0x2) != 0) {
/* 14934 */         sink.putByte(16);
/* 14935 */         sink.putVarLong(this.size_);
/*       */       }
/*       */ 
/* 14938 */       if ((this_t0 & 0x4) != 0) {
/* 14939 */         sink.putByte(24);
/* 14940 */         sink.putVarLong(this.max_);
/*       */       }
/*       */ 
/* 14943 */       if (this.uninterpreted != null)
/* 14944 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 14949 */       boolean result = true;
/* 14950 */       int this_t0 = this.optional_0_;
/*       */ 
/* 14952 */       while (source.hasRemaining()) {
/* 14953 */         int tt = source.getVarInt();
/* 14954 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 14958 */           result = false;
/* 14959 */           break;
/*       */         case 10:
/* 14962 */           source.push(source.getVarInt());
/* 14963 */           if (!this.model_key_.merge(source)) { result = false; break label157; }
/* 14964 */           source.pop();
/* 14965 */           this_t0 |= 1;
/* 14966 */           break;
/*       */         case 16:
/* 14969 */           this.size_ = source.getVarLong();
/* 14970 */           this_t0 |= 2;
/* 14971 */           break;
/*       */         case 24:
/* 14974 */           this.max_ = source.getVarLong();
/* 14975 */           this_t0 |= 4;
/* 14976 */           break;
/*       */         default:
/* 14978 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 14983 */       label157: this.optional_0_ = this_t0;
/* 14984 */       return result;
/*       */     }
/*       */ 
/*       */     public AllocateIdsRequest getDefaultInstanceForType()
/*       */     {
/* 14989 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final AllocateIdsRequest getDefaultInstance() {
/* 14993 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public AllocateIdsRequest freeze()
/*       */     {
/* 15054 */       this.model_key_.freeze();
/* 15055 */       return this;
/*       */     }
/*       */ 
/*       */     public AllocateIdsRequest unfreeze() {
/* 15059 */       this.model_key_.unfreeze();
/* 15060 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 15064 */       return this.model_key_.isFrozen();
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 15067 */       if (this.uninterpreted == null) {
/* 15068 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 15070 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 14997 */       IMMUTABLE_DEFAULT_INSTANCE = new AllocateIdsRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.AllocateIdsRequest clearModelKey()
/*       */         {
/* 15005 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsRequest setModelKey(OnestoreEntity.Reference x) {
/* 15008 */           ProtocolSupport.unsupportedOperation();
/* 15009 */           return this;
/*       */         }
/*       */         public OnestoreEntity.Reference getMutableModelKey() {
/* 15012 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.AllocateIdsRequest clearSize()
/*       */         {
/* 15017 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsRequest setSize(long x) {
/* 15020 */           ProtocolSupport.unsupportedOperation();
/* 15021 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.AllocateIdsRequest clearMax()
/*       */         {
/* 15026 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsRequest setMax(long x) {
/* 15029 */           ProtocolSupport.unsupportedOperation();
/* 15030 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.AllocateIdsRequest mergeFrom(DatastorePb.AllocateIdsRequest that) {
/* 15034 */           ProtocolSupport.unsupportedOperation();
/* 15035 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 15038 */           ProtocolSupport.unsupportedOperation();
/* 15039 */           return false;
/*       */         }
/*       */         public DatastorePb.AllocateIdsRequest freeze() {
/* 15042 */           return this;
/*       */         }
/*       */         public DatastorePb.AllocateIdsRequest unfreeze() {
/* 15045 */           ProtocolSupport.unsupportedOperation();
/* 15046 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 15049 */           return true;
/*       */         }
/*       */       };
/* 15077 */       text = new String[4];
/*       */ 
/* 15079 */       text[0] = "ErrorCode";
/* 15080 */       text[1] = "model_key";
/* 15081 */       text[2] = "size";
/* 15082 */       text[3] = "max";
/*       */ 
/* 15085 */       types = new int[4];
/*       */ 
/* 15087 */       Arrays.fill(types, 6);
/* 15088 */       types[0] = 0;
/* 15089 */       types[1] = 2;
/* 15090 */       types[2] = 0;
/* 15091 */       types[3] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 14905 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.AllocateIdsRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("model_key", "model_key", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, OnestoreEntity.Reference.class), new ProtocolType.FieldType("size", "size", 2, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("max", "max", 3, 2, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class GetNamespacesResponse extends ProtocolMessage<GetNamespacesResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 14271 */     private List<byte[]> namespace_ = null;
/* 14272 */     private boolean more_results_ = false;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final GetNamespacesResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int knamespace = 1;
/*       */     public static final int kmore_results = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int namespaceSize()
/*       */     {
/* 14278 */       return this.namespace_ != null ? this.namespace_.size() : 0;
/*       */     }
/*       */     public final byte[] getNamespaceAsBytes(int i) {
/* 14281 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.namespace_ != null ? this.namespace_.size() : 0)); } else throw new AssertionError();
/* 14282 */       return (byte[])this.namespace_.get(i);
/*       */     }
/*       */     public GetNamespacesResponse clearNamespace() {
/* 14285 */       if (this.namespace_ != null) this.namespace_.clear();
/* 14286 */       return this;
/*       */     }
/*       */     public final String getNamespace(int i) {
/* 14289 */       return ProtocolSupport.toStringUtf8((byte[])this.namespace_.get(i));
/*       */     }
/*       */     public GetNamespacesResponse setNamespaceAsBytes(int i, byte[] v) {
/* 14292 */       this.namespace_.set(i, v);
/* 14293 */       return this;
/*       */     }
/*       */     public GetNamespacesResponse setNamespace(int i, String v) {
/* 14296 */       if (v == null) throw new NullPointerException();
/* 14297 */       this.namespace_.set(i, ProtocolSupport.toBytesUtf8(v));
/* 14298 */       return this;
/*       */     }
/*       */     public GetNamespacesResponse addNamespaceAsBytes(byte[] v) {
/* 14301 */       if (this.namespace_ == null) this.namespace_ = new ArrayList(4);
/* 14302 */       this.namespace_.add(v);
/* 14303 */       return this;
/*       */     }
/*       */     public GetNamespacesResponse addNamespace(String v) {
/* 14306 */       if (v == null) throw new NullPointerException();
/* 14307 */       if (this.namespace_ == null) this.namespace_ = new ArrayList(4);
/* 14308 */       this.namespace_.add(ProtocolSupport.toBytesUtf8(v));
/* 14309 */       return this;
/*       */     }
/*       */     public final Iterator<String> namespaceIterator() {
/* 14312 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.namespace_);
/*       */     }
/*       */     public final List<String> namespaces() {
/* 14315 */       return ProtocolSupport.byteArrayToUnicodeList(this.namespace_);
/*       */     }
/*       */     public final Iterator<byte[]> namespaceAsBytesIterator() {
/* 14318 */       return this.namespace_ == null ? ProtocolSupport.emptyIterator() : this.namespace_.iterator();
/*       */     }
/*       */ 
/*       */     public final List<byte[]> namespacesAsBytes()
/*       */     {
/* 14323 */       return ProtocolSupport.unmodifiableList(this.namespace_);
/*       */     }
/*       */     public final List<byte[]> mutableNamespacesAsBytes() {
/* 14326 */       if (this.namespace_ == null) this.namespace_ = new ArrayList(4);
/* 14327 */       return this.namespace_;
/*       */     }
/*       */     public final String getNamespace(int i, Charset cs) {
/* 14330 */       return ProtocolSupport.toString((byte[])this.namespace_.get(i), cs);
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse setNamespace(int i, String v, Charset cs) {
/* 14334 */       if (v == null) throw new NullPointerException();
/* 14335 */       this.namespace_.set(i, ProtocolSupport.toBytes(v, cs));
/* 14336 */       return this;
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse addNamespace(String v, Charset cs) {
/* 14340 */       if (v == null) throw new NullPointerException();
/* 14341 */       if (this.namespace_ == null) this.namespace_ = new ArrayList(4);
/* 14342 */       this.namespace_.add(ProtocolSupport.toBytes(v, cs));
/* 14343 */       return this;
/*       */     }
/*       */ 
/*       */     public final Iterator<String> namespaceIterator(Charset cs) {
/* 14347 */       return ProtocolSupport.byteArrayToUnicodeIterator(this.namespace_, cs);
/*       */     }
/*       */ 
/*       */     public final List<String> namespaces(Charset cs) {
/* 14351 */       return ProtocolSupport.byteArrayToUnicodeList(this.namespace_, cs);
/*       */     }
/*       */ 
/*       */     public final boolean isMoreResults()
/*       */     {
/* 14356 */       return this.more_results_;
/*       */     }
/*       */     public final boolean hasMoreResults() {
/* 14359 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public GetNamespacesResponse clearMoreResults() {
/* 14362 */       this.optional_0_ &= -2;
/* 14363 */       this.more_results_ = false;
/* 14364 */       return this;
/*       */     }
/*       */     public GetNamespacesResponse setMoreResults(boolean x) {
/* 14367 */       this.optional_0_ |= 1;
/* 14368 */       this.more_results_ = x;
/* 14369 */       return this;
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse mergeFrom(GetNamespacesResponse that)
/*       */     {
/* 14376 */       assert (that != this);
/* 14377 */       int this_t0 = this.optional_0_;
/* 14378 */       int that_t0 = that.optional_0_;
/*       */ 
/* 14380 */       if ((that.namespace_ != null) && (that.namespace_.size() > 0)) {
/* 14381 */         if (this.namespace_ == null)
/* 14382 */           this.namespace_ = new ArrayList(that.namespace_);
/*       */         else {
/* 14384 */           this.namespace_.addAll(that.namespace_);
/*       */         }
/*       */       }
/*       */ 
/* 14388 */       if ((that_t0 & 0x1) != 0) {
/* 14389 */         this_t0 |= 1;
/* 14390 */         this.more_results_ = that.more_results_;
/*       */       }
/*       */ 
/* 14393 */       if (that.uninterpreted != null) {
/* 14394 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 14396 */       this.optional_0_ = this_t0;
/* 14397 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(GetNamespacesResponse that) {
/* 14401 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetNamespacesResponse that) {
/* 14405 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetNamespacesResponse that, boolean ignoreUninterpreted) {
/* 14409 */       if (that == null) return false;
/* 14410 */       if (that == this) return true;
/* 14411 */       int this_t0 = this.optional_0_;
/* 14412 */       int that_t0 = that.optional_0_;
/* 14413 */       if (this_t0 != that_t0) return false;
/* 14416 */       int n;
/* 14416 */       if ((n = this.namespace_ != null ? this.namespace_.size() : 0) != (that.namespace_ != null ? that.namespace_.size() : 0)) return false;
/* 14417 */       for (int i = 0; i < n; i++) {
/* 14418 */         if (!Arrays.equals((byte[])this.namespace_.get(i), (byte[])that.namespace_.get(i))) return false;
/*       */       }
/*       */ 
/* 14421 */       if (((this_t0 & 0x1) != 0) && 
/* 14422 */         (this.more_results_ != that.more_results_)) return false;
/*       */ 
/* 14425 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 14430 */       return ((that instanceof GetNamespacesResponse)) && (equals((GetNamespacesResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 14434 */       int hash = -1015004396;
/*       */ 
/* 14436 */       hash *= 31;
/* 14437 */       int i = 0; for (int n = this.namespace_ != null ? this.namespace_.size() : 0; i < n; i++) {
/* 14438 */         hash = hash * 31 + Arrays.hashCode((byte[])this.namespace_.get(i));
/*       */       }
/*       */ 
/* 14441 */       int this_t0 = this.optional_0_;
/* 14442 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? 1237 : this.more_results_ ? 1231 : -113);
/* 14443 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 14444 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 14446 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 14450 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/* 14454 */       int n = 0;
/*       */       int m;
/* 14457 */       n += (m = this.namespace_ != null ? this.namespace_.size() : 0);
/* 14458 */       for (int i = 0; i < m; i++) {
/* 14459 */         n += Protocol.stringSize(((byte[])this.namespace_.get(i)).length);
/*       */       }
/* 14461 */       int this_t0 = this.optional_0_;
/* 14462 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 14464 */         n += 2;
/*       */       }
/*       */ 
/* 14467 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 14473 */       int n = 2;
/*       */       int m;
/* 14476 */       n += 6 * (m = this.namespace_ != null ? this.namespace_.size() : 0);
/* 14477 */       for (int i = 0; i < m; i++) {
/* 14478 */         n += ((byte[])this.namespace_.get(i)).length;
/*       */       }
/*       */ 
/* 14481 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 14486 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 14490 */       this.optional_0_ = 0;
/* 14491 */       if (this.namespace_ != null) this.namespace_.clear();
/* 14492 */       this.more_results_ = false;
/* 14493 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse newInstance() {
/* 14497 */       return new GetNamespacesResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 14501 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 14526 */       int i = 0; for (int m = this.namespace_ != null ? this.namespace_.size() : 0; i < m; i++) {
/* 14527 */         byte[] v = (byte[])this.namespace_.get(i);
/* 14528 */         sink.putByte(10);
/* 14529 */         sink.putPrefixedData(v);
/*       */       }
/*       */ 
/* 14532 */       int this_t0 = this.optional_0_;
/* 14533 */       if ((this_t0 & 0x1) != 0) {
/* 14534 */         sink.putByte(16);
/* 14535 */         sink.putBoolean(this.more_results_);
/*       */       }
/*       */ 
/* 14538 */       if (this.uninterpreted != null)
/* 14539 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 14544 */       boolean result = true;
/* 14545 */       int this_t0 = this.optional_0_;
/*       */ 
/* 14547 */       while (source.hasRemaining()) {
/* 14548 */         int tt = source.getVarInt();
/* 14549 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 14553 */           result = false;
/* 14554 */           break;
/*       */         case 10:
/* 14557 */           addNamespaceAsBytes(source.getPrefixedData());
/* 14558 */           break;
/*       */         case 16:
/* 14561 */           this.more_results_ = source.getBoolean();
/* 14562 */           this_t0 |= 1;
/* 14563 */           break;
/*       */         default:
/* 14565 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 14570 */       this.optional_0_ = this_t0;
/* 14571 */       return result;
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse getDefaultInstanceForType()
/*       */     {
/* 14576 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final GetNamespacesResponse getDefaultInstance() {
/* 14580 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse freeze()
/*       */     {
/* 14651 */       this.namespace_ = ProtocolSupport.freezeStrings(this.namespace_);
/* 14652 */       return this;
/*       */     }
/*       */ 
/*       */     public GetNamespacesResponse unfreeze() {
/* 14656 */       this.namespace_ = ProtocolSupport.unfreezeStrings(this.namespace_);
/* 14657 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 14661 */       return ProtocolSupport.isFrozenStrings(this.namespace_);
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 14664 */       if (this.uninterpreted == null) {
/* 14665 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 14667 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 14584 */       IMMUTABLE_DEFAULT_INSTANCE = new GetNamespacesResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.GetNamespacesResponse clearNamespace()
/*       */         {
/* 14592 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse setNamespaceAsBytes(int i, byte[] v) {
/* 14595 */           ProtocolSupport.unsupportedOperation();
/* 14596 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse setNamespace(int i, String v) {
/* 14599 */           ProtocolSupport.unsupportedOperation();
/* 14600 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse addNamespaceAsBytes(byte[] v) {
/* 14603 */           ProtocolSupport.unsupportedOperation();
/* 14604 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse addNamespace(String v) {
/* 14607 */           ProtocolSupport.unsupportedOperation();
/* 14608 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesResponse setNamespace(int i, String v, Charset cs) {
/* 14612 */           ProtocolSupport.unsupportedOperation();
/* 14613 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesResponse addNamespace(String v, Charset cs) {
/* 14617 */           ProtocolSupport.unsupportedOperation();
/* 14618 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesResponse clearMoreResults()
/*       */         {
/* 14623 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse setMoreResults(boolean x) {
/* 14626 */           ProtocolSupport.unsupportedOperation();
/* 14627 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesResponse mergeFrom(DatastorePb.GetNamespacesResponse that) {
/* 14631 */           ProtocolSupport.unsupportedOperation();
/* 14632 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 14635 */           ProtocolSupport.unsupportedOperation();
/* 14636 */           return false;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse freeze() {
/* 14639 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesResponse unfreeze() {
/* 14642 */           ProtocolSupport.unsupportedOperation();
/* 14643 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 14646 */           return true;
/*       */         }
/*       */       };
/* 14673 */       text = new String[3];
/*       */ 
/* 14675 */       text[0] = "ErrorCode";
/* 14676 */       text[1] = "namespace";
/* 14677 */       text[2] = "more_results";
/*       */ 
/* 14680 */       types = new int[3];
/*       */ 
/* 14682 */       Arrays.fill(types, 6);
/* 14683 */       types[0] = 0;
/* 14684 */       types[1] = 2;
/* 14685 */       types[2] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 14505 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.GetNamespacesResponse.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("namespace", "namespace", 1, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED), new ProtocolType.FieldType("more_results", "more_results", 2, 0, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class GetNamespacesRequest extends ProtocolMessage<GetNamespacesRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 13801 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13802 */     private byte[] start_namespace_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13803 */     private byte[] end_namespace_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final GetNamespacesRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kapp = 1;
/*       */     public static final int kstart_namespace = 2;
/*       */     public static final int kend_namespace = 3;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/* 13809 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/* 13812 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public GetNamespacesRequest clearApp() {
/* 13815 */       this.optional_0_ &= -2;
/* 13816 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13817 */       return this;
/*       */     }
/*       */     public GetNamespacesRequest setAppAsBytes(byte[] x) {
/* 13820 */       this.optional_0_ |= 1;
/* 13821 */       this.app_ = x;
/* 13822 */       return this;
/*       */     }
/*       */     public final String getApp() {
/* 13825 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public GetNamespacesRequest setApp(String v) {
/* 13828 */       if (v == null) throw new NullPointerException();
/* 13829 */       this.optional_0_ |= 1;
/* 13830 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/* 13831 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/* 13834 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public GetNamespacesRequest setApp(String v, Charset cs) {
/* 13837 */       if (v == null) throw new NullPointerException();
/* 13838 */       this.optional_0_ |= 1;
/* 13839 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/* 13840 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getStartNamespaceAsBytes()
/*       */     {
/* 13845 */       return this.start_namespace_;
/*       */     }
/*       */     public final boolean hasStartNamespace() {
/* 13848 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public GetNamespacesRequest clearStartNamespace() {
/* 13851 */       this.optional_0_ &= -3;
/* 13852 */       this.start_namespace_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13853 */       return this;
/*       */     }
/*       */     public GetNamespacesRequest setStartNamespaceAsBytes(byte[] x) {
/* 13856 */       this.optional_0_ |= 2;
/* 13857 */       this.start_namespace_ = x;
/* 13858 */       return this;
/*       */     }
/*       */     public final String getStartNamespace() {
/* 13861 */       return ProtocolSupport.toStringUtf8(this.start_namespace_);
/*       */     }
/*       */     public GetNamespacesRequest setStartNamespace(String v) {
/* 13864 */       if (v == null) throw new NullPointerException();
/* 13865 */       this.optional_0_ |= 2;
/* 13866 */       this.start_namespace_ = ProtocolSupport.toBytesUtf8(v);
/* 13867 */       return this;
/*       */     }
/*       */     public final String getStartNamespace(Charset cs) {
/* 13870 */       return ProtocolSupport.toString(this.start_namespace_, cs);
/*       */     }
/*       */     public GetNamespacesRequest setStartNamespace(String v, Charset cs) {
/* 13873 */       if (v == null) throw new NullPointerException();
/* 13874 */       this.optional_0_ |= 2;
/* 13875 */       this.start_namespace_ = ProtocolSupport.toBytes(v, cs);
/* 13876 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getEndNamespaceAsBytes()
/*       */     {
/* 13881 */       return this.end_namespace_;
/*       */     }
/*       */     public final boolean hasEndNamespace() {
/* 13884 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public GetNamespacesRequest clearEndNamespace() {
/* 13887 */       this.optional_0_ &= -5;
/* 13888 */       this.end_namespace_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13889 */       return this;
/*       */     }
/*       */     public GetNamespacesRequest setEndNamespaceAsBytes(byte[] x) {
/* 13892 */       this.optional_0_ |= 4;
/* 13893 */       this.end_namespace_ = x;
/* 13894 */       return this;
/*       */     }
/*       */     public final String getEndNamespace() {
/* 13897 */       return ProtocolSupport.toStringUtf8(this.end_namespace_);
/*       */     }
/*       */     public GetNamespacesRequest setEndNamespace(String v) {
/* 13900 */       if (v == null) throw new NullPointerException();
/* 13901 */       this.optional_0_ |= 4;
/* 13902 */       this.end_namespace_ = ProtocolSupport.toBytesUtf8(v);
/* 13903 */       return this;
/*       */     }
/*       */     public final String getEndNamespace(Charset cs) {
/* 13906 */       return ProtocolSupport.toString(this.end_namespace_, cs);
/*       */     }
/*       */     public GetNamespacesRequest setEndNamespace(String v, Charset cs) {
/* 13909 */       if (v == null) throw new NullPointerException();
/* 13910 */       this.optional_0_ |= 4;
/* 13911 */       this.end_namespace_ = ProtocolSupport.toBytes(v, cs);
/* 13912 */       return this;
/*       */     }
/*       */ 
/*       */     public GetNamespacesRequest mergeFrom(GetNamespacesRequest that)
/*       */     {
/* 13919 */       assert (that != this);
/* 13920 */       int this_t0 = this.optional_0_;
/* 13921 */       int that_t0 = that.optional_0_;
/*       */ 
/* 13923 */       if ((that_t0 & 0x1) != 0) {
/* 13924 */         this_t0 |= 1;
/* 13925 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/* 13928 */       if ((that_t0 & 0x2) != 0) {
/* 13929 */         this_t0 |= 2;
/* 13930 */         this.start_namespace_ = that.start_namespace_;
/*       */       }
/*       */ 
/* 13933 */       if ((that_t0 & 0x4) != 0) {
/* 13934 */         this_t0 |= 4;
/* 13935 */         this.end_namespace_ = that.end_namespace_;
/*       */       }
/*       */ 
/* 13938 */       if (that.uninterpreted != null) {
/* 13939 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 13941 */       this.optional_0_ = this_t0;
/* 13942 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(GetNamespacesRequest that) {
/* 13946 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetNamespacesRequest that) {
/* 13950 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetNamespacesRequest that, boolean ignoreUninterpreted) {
/* 13954 */       if (that == null) return false;
/* 13955 */       if (that == this) return true;
/* 13956 */       int this_t0 = this.optional_0_;
/* 13957 */       int that_t0 = that.optional_0_;
/* 13958 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 13960 */       if (((this_t0 & 0x1) != 0) && 
/* 13961 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/* 13964 */       if (((this_t0 & 0x2) != 0) && 
/* 13965 */         (!Arrays.equals(this.start_namespace_, that.start_namespace_))) return false;
/*       */ 
/* 13968 */       if (((this_t0 & 0x4) != 0) && 
/* 13969 */         (!Arrays.equals(this.end_namespace_, that.end_namespace_))) return false;
/*       */ 
/* 13972 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 13977 */       return ((that instanceof GetNamespacesRequest)) && (equals((GetNamespacesRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 13981 */       int hash = -1440134899;
/*       */ 
/* 13983 */       int this_t0 = this.optional_0_;
/* 13984 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/*       */ 
/* 13986 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.start_namespace_) : -113);
/*       */ 
/* 13988 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.end_namespace_) : -113);
/* 13989 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 13990 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 13992 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 13996 */       int this_t0 = this.optional_0_;
/*       */ 
/* 13998 */       return (this_t0 & 0x1) == 1;
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 14005 */       int n = 1 + Protocol.stringSize(this.app_.length);
/* 14006 */       int this_t0 = this.optional_0_;
/* 14007 */       if ((this_t0 & 0x6) != 0) {
/* 14008 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 14010 */           n += 1 + Protocol.stringSize(this.start_namespace_.length);
/*       */         }
/* 14012 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/* 14014 */           n += 1 + Protocol.stringSize(this.end_namespace_.length);
/*       */         }
/*       */       }
/*       */ 
/* 14018 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 14024 */       int n = 6 + this.app_.length;
/* 14025 */       int this_t0 = this.optional_0_;
/* 14026 */       if ((this_t0 & 0x6) != 0) {
/* 14027 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 14029 */           n += 6 + this.start_namespace_.length;
/*       */         }
/* 14031 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/* 14033 */           n += 6 + this.end_namespace_.length;
/*       */         }
/*       */       }
/*       */ 
/* 14037 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 14042 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 14046 */       this.optional_0_ = 0;
/* 14047 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 14048 */       this.start_namespace_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 14049 */       this.end_namespace_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 14050 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public GetNamespacesRequest newInstance() {
/* 14054 */       return new GetNamespacesRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 14058 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 14085 */       sink.putByte(10);
/* 14086 */       sink.putPrefixedData(this.app_);
/*       */ 
/* 14088 */       int this_t0 = this.optional_0_;
/* 14089 */       if ((this_t0 & 0x2) != 0) {
/* 14090 */         sink.putByte(18);
/* 14091 */         sink.putPrefixedData(this.start_namespace_);
/*       */       }
/*       */ 
/* 14094 */       if ((this_t0 & 0x4) != 0) {
/* 14095 */         sink.putByte(26);
/* 14096 */         sink.putPrefixedData(this.end_namespace_);
/*       */       }
/*       */ 
/* 14099 */       if (this.uninterpreted != null)
/* 14100 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 14105 */       boolean result = true;
/* 14106 */       int this_t0 = this.optional_0_;
/*       */ 
/* 14108 */       while (source.hasRemaining()) {
/* 14109 */         int tt = source.getVarInt();
/* 14110 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 14114 */           result = false;
/* 14115 */           break;
/*       */         case 10:
/* 14118 */           this.app_ = source.getPrefixedData();
/* 14119 */           this_t0 |= 1;
/* 14120 */           break;
/*       */         case 18:
/* 14123 */           this.start_namespace_ = source.getPrefixedData();
/* 14124 */           this_t0 |= 2;
/* 14125 */           break;
/*       */         case 26:
/* 14128 */           this.end_namespace_ = source.getPrefixedData();
/* 14129 */           this_t0 |= 4;
/* 14130 */           break;
/*       */         default:
/* 14132 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 14137 */       this.optional_0_ = this_t0;
/* 14138 */       return result;
/*       */     }
/*       */ 
/*       */     public GetNamespacesRequest getDefaultInstanceForType()
/*       */     {
/* 14143 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final GetNamespacesRequest getDefaultInstance() {
/* 14147 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public GetNamespacesRequest freeze()
/*       */     {
/* 14229 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/* 14230 */       this.start_namespace_ = ProtocolSupport.freezeString(this.start_namespace_);
/* 14231 */       this.end_namespace_ = ProtocolSupport.freezeString(this.end_namespace_);
/* 14232 */       return this;
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 14235 */       if (this.uninterpreted == null) {
/* 14236 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 14238 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 14151 */       IMMUTABLE_DEFAULT_INSTANCE = new GetNamespacesRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.GetNamespacesRequest clearApp()
/*       */         {
/* 14159 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setAppAsBytes(byte[] x) {
/* 14162 */           ProtocolSupport.unsupportedOperation();
/* 14163 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setApp(String v) {
/* 14166 */           ProtocolSupport.unsupportedOperation();
/* 14167 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setApp(String v, Charset cs) {
/* 14170 */           ProtocolSupport.unsupportedOperation();
/* 14171 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesRequest clearStartNamespace()
/*       */         {
/* 14176 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setStartNamespaceAsBytes(byte[] x) {
/* 14179 */           ProtocolSupport.unsupportedOperation();
/* 14180 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setStartNamespace(String v) {
/* 14183 */           ProtocolSupport.unsupportedOperation();
/* 14184 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setStartNamespace(String v, Charset cs) {
/* 14187 */           ProtocolSupport.unsupportedOperation();
/* 14188 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesRequest clearEndNamespace()
/*       */         {
/* 14193 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setEndNamespaceAsBytes(byte[] x) {
/* 14196 */           ProtocolSupport.unsupportedOperation();
/* 14197 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setEndNamespace(String v) {
/* 14200 */           ProtocolSupport.unsupportedOperation();
/* 14201 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest setEndNamespace(String v, Charset cs) {
/* 14204 */           ProtocolSupport.unsupportedOperation();
/* 14205 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetNamespacesRequest mergeFrom(DatastorePb.GetNamespacesRequest that) {
/* 14209 */           ProtocolSupport.unsupportedOperation();
/* 14210 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 14213 */           ProtocolSupport.unsupportedOperation();
/* 14214 */           return false;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest freeze() {
/* 14217 */           return this;
/*       */         }
/*       */         public DatastorePb.GetNamespacesRequest unfreeze() {
/* 14220 */           ProtocolSupport.unsupportedOperation();
/* 14221 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 14224 */           return true;
/*       */         }
/*       */       };
/* 14245 */       text = new String[4];
/*       */ 
/* 14247 */       text[0] = "ErrorCode";
/* 14248 */       text[1] = "app";
/* 14249 */       text[2] = "start_namespace";
/* 14250 */       text[3] = "end_namespace";
/*       */ 
/* 14253 */       types = new int[4];
/*       */ 
/* 14255 */       Arrays.fill(types, 6);
/* 14256 */       types[0] = 0;
/* 14257 */       types[1] = 2;
/* 14258 */       types[2] = 2;
/* 14259 */       types[3] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 14062 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.GetNamespacesRequest.class, "Z'apphosting/datastore/datastore_v3.proto\n,apphosting_datastore_v3.GetNamespacesRequest\023\032\003app \001(\0020\t8\002\024\023\032\017start_namespace \002(\0020\t8\001\024\023\032\rend_namespace \003(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("start_namespace", "start_namespace", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("end_namespace", "end_namespace", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class Schema extends ProtocolMessage<Schema>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 13406 */     private List<OnestoreEntity.EntityProto> kind_ = null;
/* 13407 */     private boolean more_results_ = false;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final Schema IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kkind = 1;
/*       */     public static final int kmore_results = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int kindSize()
/*       */     {
/* 13413 */       return this.kind_ != null ? this.kind_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.EntityProto getKind(int i) {
/* 13416 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.kind_ != null ? this.kind_.size() : 0)); } else throw new AssertionError();
/* 13417 */       return (OnestoreEntity.EntityProto)this.kind_.get(i);
/*       */     }
/*       */     public Schema clearKind() {
/* 13420 */       if (this.kind_ != null) this.kind_.clear();
/* 13421 */       return this;
/*       */     }
/*       */     public OnestoreEntity.EntityProto getMutableKind(int i) {
/* 13424 */       assert ((i >= 0) && (this.kind_ != null) && (i < this.kind_.size()));
/* 13425 */       return (OnestoreEntity.EntityProto)this.kind_.get(i);
/*       */     }
/*       */     public OnestoreEntity.EntityProto addKind() {
/* 13428 */       OnestoreEntity.EntityProto v = new OnestoreEntity.EntityProto();
/* 13429 */       if (this.kind_ == null) this.kind_ = new ArrayList(4);
/* 13430 */       this.kind_.add(v);
/* 13431 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto addKind(OnestoreEntity.EntityProto v) {
/* 13434 */       if (this.kind_ == null) this.kind_ = new ArrayList(4);
/* 13435 */       this.kind_.add(v);
/* 13436 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto insertKind(int i, OnestoreEntity.EntityProto v) {
/* 13439 */       if (this.kind_ == null) this.kind_ = new ArrayList(4);
/* 13440 */       this.kind_.add(i, v);
/* 13441 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto removeKind(int i) {
/* 13444 */       return (OnestoreEntity.EntityProto)this.kind_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.EntityProto> kindIterator() {
/* 13447 */       if (this.kind_ == null) {
/* 13448 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 13450 */       return this.kind_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.EntityProto> kinds() {
/* 13453 */       return ProtocolSupport.unmodifiableList(this.kind_);
/*       */     }
/*       */     public final List<OnestoreEntity.EntityProto> mutableKinds() {
/* 13456 */       if (this.kind_ == null) this.kind_ = new ArrayList(4);
/* 13457 */       return this.kind_;
/*       */     }
/*       */ 
/*       */     public final boolean isMoreResults()
/*       */     {
/* 13462 */       return this.more_results_;
/*       */     }
/*       */     public final boolean hasMoreResults() {
/* 13465 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public Schema clearMoreResults() {
/* 13468 */       this.optional_0_ &= -2;
/* 13469 */       this.more_results_ = false;
/* 13470 */       return this;
/*       */     }
/*       */     public Schema setMoreResults(boolean x) {
/* 13473 */       this.optional_0_ |= 1;
/* 13474 */       this.more_results_ = x;
/* 13475 */       return this;
/*       */     }
/*       */ 
/*       */     public Schema mergeFrom(Schema that)
/*       */     {
/* 13482 */       assert (that != this);
/* 13483 */       int this_t0 = this.optional_0_;
/* 13484 */       int that_t0 = that.optional_0_;
/*       */ 
/* 13486 */       if (that.kind_ != null) {
/* 13487 */         for (OnestoreEntity.EntityProto v : that.kind_) {
/* 13488 */           addKind().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 13492 */       if ((that_t0 & 0x1) != 0) {
/* 13493 */         this_t0 |= 1;
/* 13494 */         this.more_results_ = that.more_results_;
/*       */       }
/*       */ 
/* 13497 */       if (that.uninterpreted != null) {
/* 13498 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 13500 */       this.optional_0_ = this_t0;
/* 13501 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(Schema that) {
/* 13505 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(Schema that) {
/* 13509 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(Schema that, boolean ignoreUninterpreted) {
/* 13513 */       if (that == null) return false;
/* 13514 */       if (that == this) return true;
/* 13515 */       int this_t0 = this.optional_0_;
/* 13516 */       int that_t0 = that.optional_0_;
/* 13517 */       if (this_t0 != that_t0) return false;
/* 13520 */       int n;
/* 13520 */       if ((n = this.kind_ != null ? this.kind_.size() : 0) != (that.kind_ != null ? that.kind_.size() : 0)) return false;
/* 13521 */       for (int i = 0; i < n; i++) {
/* 13522 */         if (!((OnestoreEntity.EntityProto)this.kind_.get(i)).equals((OnestoreEntity.EntityProto)that.kind_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 13525 */       if (((this_t0 & 0x1) != 0) && 
/* 13526 */         (this.more_results_ != that.more_results_)) return false;
/*       */ 
/* 13529 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 13534 */       return ((that instanceof Schema)) && (equals((Schema)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 13538 */       int hash = 1963788789;
/*       */ 
/* 13540 */       hash *= 31;
/* 13541 */       int i = 0; for (int n = this.kind_ != null ? this.kind_.size() : 0; i < n; i++) {
/* 13542 */         hash = hash * 31 + ((OnestoreEntity.EntityProto)this.kind_.get(i)).hashCode();
/*       */       }
/*       */ 
/* 13545 */       int this_t0 = this.optional_0_;
/* 13546 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? 1237 : this.more_results_ ? 1231 : -113);
/* 13547 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 13548 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 13550 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 13555 */       if (this.kind_ != null) {
/* 13556 */         for (OnestoreEntity.EntityProto v : this.kind_) {
/* 13557 */           if (!v.isInitialized()) {
/* 13558 */             return false;
/*       */           }
/*       */         }
/*       */       }
/* 13562 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/* 13566 */       int n = 0;
/*       */       int m;
/* 13569 */       n += (m = this.kind_ != null ? this.kind_.size() : 0);
/* 13570 */       for (int i = 0; i < m; i++) {
/* 13571 */         n += Protocol.stringSize(((OnestoreEntity.EntityProto)this.kind_.get(i)).encodingSize());
/*       */       }
/* 13573 */       int this_t0 = this.optional_0_;
/* 13574 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 13576 */         n += 2;
/*       */       }
/*       */ 
/* 13579 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 13585 */       int n = 2;
/*       */       int m;
/* 13588 */       n += 6 * (m = this.kind_ != null ? this.kind_.size() : 0);
/* 13589 */       for (int i = 0; i < m; i++) {
/* 13590 */         n += ((OnestoreEntity.EntityProto)this.kind_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/* 13593 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 13598 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 13602 */       this.optional_0_ = 0;
/* 13603 */       if (this.kind_ != null) this.kind_.clear();
/* 13604 */       this.more_results_ = false;
/* 13605 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public Schema newInstance() {
/* 13609 */       return new Schema();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 13613 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 13639 */       int i = 0; for (int m = this.kind_ != null ? this.kind_.size() : 0; i < m; i++) {
/* 13640 */         OnestoreEntity.EntityProto v = (OnestoreEntity.EntityProto)this.kind_.get(i);
/* 13641 */         sink.putByte(10);
/* 13642 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 13645 */       int this_t0 = this.optional_0_;
/* 13646 */       if ((this_t0 & 0x1) != 0) {
/* 13647 */         sink.putByte(16);
/* 13648 */         sink.putBoolean(this.more_results_);
/*       */       }
/*       */ 
/* 13651 */       if (this.uninterpreted != null)
/* 13652 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 13657 */       boolean result = true;
/* 13658 */       int this_t0 = this.optional_0_;
/*       */ 
/* 13660 */       while (source.hasRemaining()) {
/* 13661 */         int tt = source.getVarInt();
/* 13662 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 13666 */           result = false;
/* 13667 */           break;
/*       */         case 10:
/* 13670 */           source.push(source.getVarInt());
/* 13671 */           if (!addKind().merge(source)) { result = false; break label130; }
/* 13672 */           source.pop();
/* 13673 */           break;
/*       */         case 16:
/* 13676 */           this.more_results_ = source.getBoolean();
/* 13677 */           this_t0 |= 1;
/* 13678 */           break;
/*       */         default:
/* 13680 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 13685 */       label130: this.optional_0_ = this_t0;
/* 13686 */       return result;
/*       */     }
/*       */ 
/*       */     public Schema getDefaultInstanceForType()
/*       */     {
/* 13691 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final Schema getDefaultInstance() {
/* 13695 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public Schema freeze()
/*       */     {
/* 13755 */       this.kind_ = ProtocolSupport.freezeMessages(this.kind_);
/* 13756 */       return this;
/*       */     }
/*       */ 
/*       */     public Schema unfreeze() {
/* 13760 */       this.kind_ = ProtocolSupport.unfreezeMessages(this.kind_);
/* 13761 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 13765 */       return ProtocolSupport.isFrozenMessages(this.kind_);
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 13768 */       if (this.uninterpreted == null) {
/* 13769 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 13771 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 13699 */       IMMUTABLE_DEFAULT_INSTANCE = new Schema()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.Schema clearKind()
/*       */         {
/* 13707 */           return this;
/*       */         }
/*       */         public OnestoreEntity.EntityProto getMutableKind(int i) {
/* 13710 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto addKind() {
/* 13713 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto addKind(OnestoreEntity.EntityProto v) {
/* 13716 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto insertKind(int i, OnestoreEntity.EntityProto v) {
/* 13719 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto removeKind(int i) {
/* 13722 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Schema clearMoreResults()
/*       */         {
/* 13727 */           return this;
/*       */         }
/*       */         public DatastorePb.Schema setMoreResults(boolean x) {
/* 13730 */           ProtocolSupport.unsupportedOperation();
/* 13731 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Schema mergeFrom(DatastorePb.Schema that) {
/* 13735 */           ProtocolSupport.unsupportedOperation();
/* 13736 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 13739 */           ProtocolSupport.unsupportedOperation();
/* 13740 */           return false;
/*       */         }
/*       */         public DatastorePb.Schema freeze() {
/* 13743 */           return this;
/*       */         }
/*       */         public DatastorePb.Schema unfreeze() {
/* 13746 */           ProtocolSupport.unsupportedOperation();
/* 13747 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 13750 */           return true;
/*       */         }
/*       */       };
/* 13777 */       text = new String[3];
/*       */ 
/* 13779 */       text[0] = "ErrorCode";
/* 13780 */       text[1] = "kind";
/* 13781 */       text[2] = "more_results";
/*       */ 
/* 13784 */       types = new int[3];
/*       */ 
/* 13786 */       Arrays.fill(types, 6);
/* 13787 */       types[0] = 0;
/* 13788 */       types[1] = 2;
/* 13789 */       types[2] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 13617 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Schema.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("kind", "kind", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.EntityProto.class), new ProtocolType.FieldType("more_results", "more_results", 2, 0, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class GetSchemaRequest extends ProtocolMessage<GetSchemaRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 12782 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12783 */     private byte[] name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12784 */     private byte[] start_kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12785 */     private byte[] end_kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12786 */     private boolean properties_ = true;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final GetSchemaRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kapp = 1;
/*       */     public static final int kname_space = 5;
/*       */     public static final int kstart_kind = 2;
/*       */     public static final int kend_kind = 3;
/*       */     public static final int kproperties = 4;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/* 12792 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/* 12795 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public GetSchemaRequest clearApp() {
/* 12798 */       this.optional_0_ &= -2;
/* 12799 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12800 */       return this;
/*       */     }
/*       */     public GetSchemaRequest setAppAsBytes(byte[] x) {
/* 12803 */       this.optional_0_ |= 1;
/* 12804 */       this.app_ = x;
/* 12805 */       return this;
/*       */     }
/*       */     public final String getApp() {
/* 12808 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public GetSchemaRequest setApp(String v) {
/* 12811 */       if (v == null) throw new NullPointerException();
/* 12812 */       this.optional_0_ |= 1;
/* 12813 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/* 12814 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/* 12817 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public GetSchemaRequest setApp(String v, Charset cs) {
/* 12820 */       if (v == null) throw new NullPointerException();
/* 12821 */       this.optional_0_ |= 1;
/* 12822 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/* 12823 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getNameSpaceAsBytes()
/*       */     {
/* 12828 */       return this.name_space_;
/*       */     }
/*       */     public final boolean hasNameSpace() {
/* 12831 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public GetSchemaRequest clearNameSpace() {
/* 12834 */       this.optional_0_ &= -3;
/* 12835 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12836 */       return this;
/*       */     }
/*       */     public GetSchemaRequest setNameSpaceAsBytes(byte[] x) {
/* 12839 */       this.optional_0_ |= 2;
/* 12840 */       this.name_space_ = x;
/* 12841 */       return this;
/*       */     }
/*       */     public final String getNameSpace() {
/* 12844 */       return ProtocolSupport.toStringUtf8(this.name_space_);
/*       */     }
/*       */     public GetSchemaRequest setNameSpace(String v) {
/* 12847 */       if (v == null) throw new NullPointerException();
/* 12848 */       this.optional_0_ |= 2;
/* 12849 */       this.name_space_ = ProtocolSupport.toBytesUtf8(v);
/* 12850 */       return this;
/*       */     }
/*       */     public final String getNameSpace(Charset cs) {
/* 12853 */       return ProtocolSupport.toString(this.name_space_, cs);
/*       */     }
/*       */     public GetSchemaRequest setNameSpace(String v, Charset cs) {
/* 12856 */       if (v == null) throw new NullPointerException();
/* 12857 */       this.optional_0_ |= 2;
/* 12858 */       this.name_space_ = ProtocolSupport.toBytes(v, cs);
/* 12859 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getStartKindAsBytes()
/*       */     {
/* 12864 */       return this.start_kind_;
/*       */     }
/*       */     public final boolean hasStartKind() {
/* 12867 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public GetSchemaRequest clearStartKind() {
/* 12870 */       this.optional_0_ &= -5;
/* 12871 */       this.start_kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12872 */       return this;
/*       */     }
/*       */     public GetSchemaRequest setStartKindAsBytes(byte[] x) {
/* 12875 */       this.optional_0_ |= 4;
/* 12876 */       this.start_kind_ = x;
/* 12877 */       return this;
/*       */     }
/*       */     public final String getStartKind() {
/* 12880 */       return ProtocolSupport.toStringUtf8(this.start_kind_);
/*       */     }
/*       */     public GetSchemaRequest setStartKind(String v) {
/* 12883 */       if (v == null) throw new NullPointerException();
/* 12884 */       this.optional_0_ |= 4;
/* 12885 */       this.start_kind_ = ProtocolSupport.toBytesUtf8(v);
/* 12886 */       return this;
/*       */     }
/*       */     public final String getStartKind(Charset cs) {
/* 12889 */       return ProtocolSupport.toString(this.start_kind_, cs);
/*       */     }
/*       */     public GetSchemaRequest setStartKind(String v, Charset cs) {
/* 12892 */       if (v == null) throw new NullPointerException();
/* 12893 */       this.optional_0_ |= 4;
/* 12894 */       this.start_kind_ = ProtocolSupport.toBytes(v, cs);
/* 12895 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getEndKindAsBytes()
/*       */     {
/* 12900 */       return this.end_kind_;
/*       */     }
/*       */     public final boolean hasEndKind() {
/* 12903 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public GetSchemaRequest clearEndKind() {
/* 12906 */       this.optional_0_ &= -9;
/* 12907 */       this.end_kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 12908 */       return this;
/*       */     }
/*       */     public GetSchemaRequest setEndKindAsBytes(byte[] x) {
/* 12911 */       this.optional_0_ |= 8;
/* 12912 */       this.end_kind_ = x;
/* 12913 */       return this;
/*       */     }
/*       */     public final String getEndKind() {
/* 12916 */       return ProtocolSupport.toStringUtf8(this.end_kind_);
/*       */     }
/*       */     public GetSchemaRequest setEndKind(String v) {
/* 12919 */       if (v == null) throw new NullPointerException();
/* 12920 */       this.optional_0_ |= 8;
/* 12921 */       this.end_kind_ = ProtocolSupport.toBytesUtf8(v);
/* 12922 */       return this;
/*       */     }
/*       */     public final String getEndKind(Charset cs) {
/* 12925 */       return ProtocolSupport.toString(this.end_kind_, cs);
/*       */     }
/*       */     public GetSchemaRequest setEndKind(String v, Charset cs) {
/* 12928 */       if (v == null) throw new NullPointerException();
/* 12929 */       this.optional_0_ |= 8;
/* 12930 */       this.end_kind_ = ProtocolSupport.toBytes(v, cs);
/* 12931 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isProperties()
/*       */     {
/* 12936 */       return this.properties_;
/*       */     }
/*       */     public final boolean hasProperties() {
/* 12939 */       return (this.optional_0_ & 0x10) != 0;
/*       */     }
/*       */     public GetSchemaRequest clearProperties() {
/* 12942 */       this.optional_0_ &= -17;
/* 12943 */       this.properties_ = true;
/* 12944 */       return this;
/*       */     }
/*       */     public GetSchemaRequest setProperties(boolean x) {
/* 12947 */       this.optional_0_ |= 16;
/* 12948 */       this.properties_ = x;
/* 12949 */       return this;
/*       */     }
/*       */ 
/*       */     public GetSchemaRequest mergeFrom(GetSchemaRequest that)
/*       */     {
/* 12956 */       assert (that != this);
/* 12957 */       int this_t0 = this.optional_0_;
/* 12958 */       int that_t0 = that.optional_0_;
/*       */ 
/* 12960 */       if ((that_t0 & 0x1) != 0) {
/* 12961 */         this_t0 |= 1;
/* 12962 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/* 12965 */       if ((that_t0 & 0x2) != 0) {
/* 12966 */         this_t0 |= 2;
/* 12967 */         this.name_space_ = that.name_space_;
/*       */       }
/*       */ 
/* 12970 */       if ((that_t0 & 0x4) != 0) {
/* 12971 */         this_t0 |= 4;
/* 12972 */         this.start_kind_ = that.start_kind_;
/*       */       }
/*       */ 
/* 12975 */       if ((that_t0 & 0x8) != 0) {
/* 12976 */         this_t0 |= 8;
/* 12977 */         this.end_kind_ = that.end_kind_;
/*       */       }
/*       */ 
/* 12980 */       if ((that_t0 & 0x10) != 0) {
/* 12981 */         this_t0 |= 16;
/* 12982 */         this.properties_ = that.properties_;
/*       */       }
/*       */ 
/* 12985 */       if (that.uninterpreted != null) {
/* 12986 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 12988 */       this.optional_0_ = this_t0;
/* 12989 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(GetSchemaRequest that) {
/* 12993 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetSchemaRequest that) {
/* 12997 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetSchemaRequest that, boolean ignoreUninterpreted) {
/* 13001 */       if (that == null) return false;
/* 13002 */       if (that == this) return true;
/* 13003 */       int this_t0 = this.optional_0_;
/* 13004 */       int that_t0 = that.optional_0_;
/* 13005 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 13007 */       if (((this_t0 & 0x1) != 0) && 
/* 13008 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/* 13011 */       if (((this_t0 & 0x2) != 0) && 
/* 13012 */         (!Arrays.equals(this.name_space_, that.name_space_))) return false;
/*       */ 
/* 13015 */       if (((this_t0 & 0x4) != 0) && 
/* 13016 */         (!Arrays.equals(this.start_kind_, that.start_kind_))) return false;
/*       */ 
/* 13019 */       if (((this_t0 & 0x8) != 0) && 
/* 13020 */         (!Arrays.equals(this.end_kind_, that.end_kind_))) return false;
/*       */ 
/* 13023 */       if (((this_t0 & 0x10) != 0) && 
/* 13024 */         (this.properties_ != that.properties_)) return false;
/*       */ 
/* 13027 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 13032 */       return ((that instanceof GetSchemaRequest)) && (equals((GetSchemaRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 13036 */       int hash = -1220555972;
/*       */ 
/* 13038 */       int this_t0 = this.optional_0_;
/* 13039 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/*       */ 
/* 13041 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.start_kind_) : -113);
/*       */ 
/* 13043 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Arrays.hashCode(this.end_kind_) : -113);
/*       */ 
/* 13045 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? 1237 : this.properties_ ? 1231 : -113);
/*       */ 
/* 13047 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.name_space_) : -113);
/* 13048 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 13049 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 13051 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 13055 */       int this_t0 = this.optional_0_;
/*       */ 
/* 13057 */       return (this_t0 & 0x1) == 1;
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 13064 */       int n = 1 + Protocol.stringSize(this.app_.length);
/* 13065 */       int this_t0 = this.optional_0_;
/* 13066 */       if ((this_t0 & 0x1E) != 0) {
/* 13067 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 13069 */           n += 1 + Protocol.stringSize(this.name_space_.length);
/*       */         }
/* 13071 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/* 13073 */           n += 1 + Protocol.stringSize(this.start_kind_.length);
/*       */         }
/* 13075 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/* 13077 */           n += 1 + Protocol.stringSize(this.end_kind_.length);
/*       */         }
/* 13079 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/* 13081 */           n += 2;
/*       */         }
/*       */       }
/*       */ 
/* 13085 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 13092 */       int n = 8 + this.app_.length;
/* 13093 */       int this_t0 = this.optional_0_;
/* 13094 */       if ((this_t0 & 0xE) != 0) {
/* 13095 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 13097 */           n += 6 + this.name_space_.length;
/*       */         }
/* 13099 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/* 13101 */           n += 6 + this.start_kind_.length;
/*       */         }
/* 13103 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/* 13105 */           n += 6 + this.end_kind_.length;
/*       */         }
/*       */       }
/*       */ 
/* 13109 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 13114 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 13118 */       this.optional_0_ = 0;
/* 13119 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13120 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13121 */       this.start_kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13122 */       this.end_kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/* 13123 */       this.properties_ = true;
/* 13124 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public GetSchemaRequest newInstance() {
/* 13128 */       return new GetSchemaRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 13132 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 13167 */       sink.putByte(10);
/* 13168 */       sink.putPrefixedData(this.app_);
/*       */ 
/* 13170 */       int this_t0 = this.optional_0_;
/* 13171 */       if ((this_t0 & 0x4) != 0) {
/* 13172 */         sink.putByte(18);
/* 13173 */         sink.putPrefixedData(this.start_kind_);
/*       */       }
/*       */ 
/* 13176 */       if ((this_t0 & 0x8) != 0) {
/* 13177 */         sink.putByte(26);
/* 13178 */         sink.putPrefixedData(this.end_kind_);
/*       */       }
/*       */ 
/* 13181 */       if ((this_t0 & 0x10) != 0) {
/* 13182 */         sink.putByte(32);
/* 13183 */         sink.putBoolean(this.properties_);
/*       */       }
/*       */ 
/* 13186 */       if ((this_t0 & 0x2) != 0) {
/* 13187 */         sink.putByte(42);
/* 13188 */         sink.putPrefixedData(this.name_space_);
/*       */       }
/*       */ 
/* 13191 */       if (this.uninterpreted != null)
/* 13192 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 13197 */       boolean result = true;
/* 13198 */       int this_t0 = this.optional_0_;
/*       */ 
/* 13200 */       while (source.hasRemaining()) {
/* 13201 */         int tt = source.getVarInt();
/* 13202 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 13206 */           result = false;
/* 13207 */           break;
/*       */         case 10:
/* 13210 */           this.app_ = source.getPrefixedData();
/* 13211 */           this_t0 |= 1;
/* 13212 */           break;
/*       */         case 18:
/* 13215 */           this.start_kind_ = source.getPrefixedData();
/* 13216 */           this_t0 |= 4;
/* 13217 */           break;
/*       */         case 26:
/* 13220 */           this.end_kind_ = source.getPrefixedData();
/* 13221 */           this_t0 |= 8;
/* 13222 */           break;
/*       */         case 32:
/* 13225 */           this.properties_ = source.getBoolean();
/* 13226 */           this_t0 |= 16;
/* 13227 */           break;
/*       */         case 42:
/* 13230 */           this.name_space_ = source.getPrefixedData();
/* 13231 */           this_t0 |= 2;
/* 13232 */           break;
/*       */         default:
/* 13234 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 13239 */       this.optional_0_ = this_t0;
/* 13240 */       return result;
/*       */     }
/*       */ 
/*       */     public GetSchemaRequest getDefaultInstanceForType()
/*       */     {
/* 13245 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final GetSchemaRequest getDefaultInstance() {
/* 13249 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public GetSchemaRequest freeze()
/*       */     {
/* 13357 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/* 13358 */       this.name_space_ = ProtocolSupport.freezeString(this.name_space_);
/* 13359 */       this.start_kind_ = ProtocolSupport.freezeString(this.start_kind_);
/* 13360 */       this.end_kind_ = ProtocolSupport.freezeString(this.end_kind_);
/* 13361 */       return this;
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 13364 */       if (this.uninterpreted == null) {
/* 13365 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 13367 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 13253 */       IMMUTABLE_DEFAULT_INSTANCE = new GetSchemaRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.GetSchemaRequest clearApp()
/*       */         {
/* 13261 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setAppAsBytes(byte[] x) {
/* 13264 */           ProtocolSupport.unsupportedOperation();
/* 13265 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setApp(String v) {
/* 13268 */           ProtocolSupport.unsupportedOperation();
/* 13269 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setApp(String v, Charset cs) {
/* 13272 */           ProtocolSupport.unsupportedOperation();
/* 13273 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetSchemaRequest clearNameSpace()
/*       */         {
/* 13278 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setNameSpaceAsBytes(byte[] x) {
/* 13281 */           ProtocolSupport.unsupportedOperation();
/* 13282 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setNameSpace(String v) {
/* 13285 */           ProtocolSupport.unsupportedOperation();
/* 13286 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setNameSpace(String v, Charset cs) {
/* 13289 */           ProtocolSupport.unsupportedOperation();
/* 13290 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetSchemaRequest clearStartKind()
/*       */         {
/* 13295 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setStartKindAsBytes(byte[] x) {
/* 13298 */           ProtocolSupport.unsupportedOperation();
/* 13299 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setStartKind(String v) {
/* 13302 */           ProtocolSupport.unsupportedOperation();
/* 13303 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setStartKind(String v, Charset cs) {
/* 13306 */           ProtocolSupport.unsupportedOperation();
/* 13307 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetSchemaRequest clearEndKind()
/*       */         {
/* 13312 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setEndKindAsBytes(byte[] x) {
/* 13315 */           ProtocolSupport.unsupportedOperation();
/* 13316 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setEndKind(String v) {
/* 13319 */           ProtocolSupport.unsupportedOperation();
/* 13320 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setEndKind(String v, Charset cs) {
/* 13323 */           ProtocolSupport.unsupportedOperation();
/* 13324 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetSchemaRequest clearProperties()
/*       */         {
/* 13329 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest setProperties(boolean x) {
/* 13332 */           ProtocolSupport.unsupportedOperation();
/* 13333 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetSchemaRequest mergeFrom(DatastorePb.GetSchemaRequest that) {
/* 13337 */           ProtocolSupport.unsupportedOperation();
/* 13338 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 13341 */           ProtocolSupport.unsupportedOperation();
/* 13342 */           return false;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest freeze() {
/* 13345 */           return this;
/*       */         }
/*       */         public DatastorePb.GetSchemaRequest unfreeze() {
/* 13348 */           ProtocolSupport.unsupportedOperation();
/* 13349 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 13352 */           return true;
/*       */         }
/*       */       };
/* 13376 */       text = new String[6];
/*       */ 
/* 13378 */       text[0] = "ErrorCode";
/* 13379 */       text[1] = "app";
/* 13380 */       text[2] = "start_kind";
/* 13381 */       text[3] = "end_kind";
/* 13382 */       text[4] = "properties";
/* 13383 */       text[5] = "name_space";
/*       */ 
/* 13386 */       types = new int[6];
/*       */ 
/* 13388 */       Arrays.fill(types, 6);
/* 13389 */       types[0] = 0;
/* 13390 */       types[1] = 2;
/* 13391 */       types[2] = 2;
/* 13392 */       types[3] = 2;
/* 13393 */       types[4] = 0;
/* 13394 */       types[5] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 13136 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.GetSchemaRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("name_space", "name_space", 5, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("start_kind", "start_kind", 2, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("end_kind", "end_kind", 3, 3, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("properties", "properties", 4, 4, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class QueryResult extends ProtocolMessage<QueryResult>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 11979 */     private DatastorePb.Cursor cursor_ = null;
/* 11980 */     private List<OnestoreEntity.EntityProto> result_ = null;
/* 11981 */     private int skipped_results_ = 0;
/* 11982 */     private boolean more_results_ = false;
/* 11983 */     private boolean keys_only_ = false;
/* 11984 */     private DatastorePb.CompiledQuery compiled_query_ = null;
/* 11985 */     private DatastorePb.CompiledCursor compiled_cursor_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final QueryResult IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kcursor = 1;
/*       */     public static final int kresult = 2;
/*       */     public static final int kskipped_results = 7;
/*       */     public static final int kmore_results = 3;
/*       */     public static final int kkeys_only = 4;
/*       */     public static final int kcompiled_query = 5;
/*       */     public static final int kcompiled_cursor = 6;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final DatastorePb.Cursor getCursor()
/*       */     {
/* 11991 */       if (this.cursor_ == null) {
/* 11992 */         return DatastorePb.Cursor.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 11994 */       return this.cursor_;
/*       */     }
/*       */     public final boolean hasCursor() {
/* 11997 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public QueryResult clearCursor() {
/* 12000 */       this.optional_0_ &= -2;
/* 12001 */       if (this.cursor_ != null) this.cursor_.clear();
/* 12002 */       return this;
/*       */     }
/*       */     public QueryResult setCursor(DatastorePb.Cursor x) {
/* 12005 */       if (x == null) throw new NullPointerException();
/* 12006 */       this.optional_0_ |= 1;
/* 12007 */       this.cursor_ = x;
/* 12008 */       return this;
/*       */     }
/*       */     public DatastorePb.Cursor getMutableCursor() {
/* 12011 */       this.optional_0_ |= 1;
/* 12012 */       if (this.cursor_ == null) this.cursor_ = new DatastorePb.Cursor();
/* 12013 */       return this.cursor_;
/*       */     }
/*       */ 
/*       */     public final int resultSize()
/*       */     {
/* 12018 */       return this.result_ != null ? this.result_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.EntityProto getResult(int i) {
/* 12021 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.result_ != null ? this.result_.size() : 0)); } else throw new AssertionError();
/* 12022 */       return (OnestoreEntity.EntityProto)this.result_.get(i);
/*       */     }
/*       */     public QueryResult clearResult() {
/* 12025 */       if (this.result_ != null) this.result_.clear();
/* 12026 */       return this;
/*       */     }
/*       */     public OnestoreEntity.EntityProto getMutableResult(int i) {
/* 12029 */       assert ((i >= 0) && (this.result_ != null) && (i < this.result_.size()));
/* 12030 */       return (OnestoreEntity.EntityProto)this.result_.get(i);
/*       */     }
/*       */     public OnestoreEntity.EntityProto addResult() {
/* 12033 */       OnestoreEntity.EntityProto v = new OnestoreEntity.EntityProto();
/* 12034 */       if (this.result_ == null) this.result_ = new ArrayList(4);
/* 12035 */       this.result_.add(v);
/* 12036 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto addResult(OnestoreEntity.EntityProto v) {
/* 12039 */       if (this.result_ == null) this.result_ = new ArrayList(4);
/* 12040 */       this.result_.add(v);
/* 12041 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto insertResult(int i, OnestoreEntity.EntityProto v) {
/* 12044 */       if (this.result_ == null) this.result_ = new ArrayList(4);
/* 12045 */       this.result_.add(i, v);
/* 12046 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto removeResult(int i) {
/* 12049 */       return (OnestoreEntity.EntityProto)this.result_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.EntityProto> resultIterator() {
/* 12052 */       if (this.result_ == null) {
/* 12053 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 12055 */       return this.result_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.EntityProto> results() {
/* 12058 */       return ProtocolSupport.unmodifiableList(this.result_);
/*       */     }
/*       */     public final List<OnestoreEntity.EntityProto> mutableResults() {
/* 12061 */       if (this.result_ == null) this.result_ = new ArrayList(4);
/* 12062 */       return this.result_;
/*       */     }
/*       */ 
/*       */     public final int getSkippedResults()
/*       */     {
/* 12067 */       return this.skipped_results_;
/*       */     }
/*       */     public final boolean hasSkippedResults() {
/* 12070 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public QueryResult clearSkippedResults() {
/* 12073 */       this.optional_0_ &= -3;
/* 12074 */       this.skipped_results_ = 0;
/* 12075 */       return this;
/*       */     }
/*       */     public QueryResult setSkippedResults(int x) {
/* 12078 */       this.optional_0_ |= 2;
/* 12079 */       this.skipped_results_ = x;
/* 12080 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isMoreResults()
/*       */     {
/* 12085 */       return this.more_results_;
/*       */     }
/*       */     public final boolean hasMoreResults() {
/* 12088 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public QueryResult clearMoreResults() {
/* 12091 */       this.optional_0_ &= -5;
/* 12092 */       this.more_results_ = false;
/* 12093 */       return this;
/*       */     }
/*       */     public QueryResult setMoreResults(boolean x) {
/* 12096 */       this.optional_0_ |= 4;
/* 12097 */       this.more_results_ = x;
/* 12098 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isKeysOnly()
/*       */     {
/* 12103 */       return this.keys_only_;
/*       */     }
/*       */     public final boolean hasKeysOnly() {
/* 12106 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public QueryResult clearKeysOnly() {
/* 12109 */       this.optional_0_ &= -9;
/* 12110 */       this.keys_only_ = false;
/* 12111 */       return this;
/*       */     }
/*       */     public QueryResult setKeysOnly(boolean x) {
/* 12114 */       this.optional_0_ |= 8;
/* 12115 */       this.keys_only_ = x;
/* 12116 */       return this;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.CompiledQuery getCompiledQuery()
/*       */     {
/* 12121 */       if (this.compiled_query_ == null) {
/* 12122 */         return DatastorePb.CompiledQuery.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 12124 */       return this.compiled_query_;
/*       */     }
/*       */     public final boolean hasCompiledQuery() {
/* 12127 */       return (this.optional_0_ & 0x10) != 0;
/*       */     }
/*       */     public QueryResult clearCompiledQuery() {
/* 12130 */       this.optional_0_ &= -17;
/* 12131 */       if (this.compiled_query_ != null) this.compiled_query_.clear();
/* 12132 */       return this;
/*       */     }
/*       */     public QueryResult setCompiledQuery(DatastorePb.CompiledQuery x) {
/* 12135 */       if (x == null) throw new NullPointerException();
/* 12136 */       this.optional_0_ |= 16;
/* 12137 */       this.compiled_query_ = x;
/* 12138 */       return this;
/*       */     }
/*       */     public DatastorePb.CompiledQuery getMutableCompiledQuery() {
/* 12141 */       this.optional_0_ |= 16;
/* 12142 */       if (this.compiled_query_ == null) this.compiled_query_ = new DatastorePb.CompiledQuery();
/* 12143 */       return this.compiled_query_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.CompiledCursor getCompiledCursor()
/*       */     {
/* 12148 */       if (this.compiled_cursor_ == null) {
/* 12149 */         return DatastorePb.CompiledCursor.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 12151 */       return this.compiled_cursor_;
/*       */     }
/*       */     public final boolean hasCompiledCursor() {
/* 12154 */       return (this.optional_0_ & 0x20) != 0;
/*       */     }
/*       */     public QueryResult clearCompiledCursor() {
/* 12157 */       this.optional_0_ &= -33;
/* 12158 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.clear();
/* 12159 */       return this;
/*       */     }
/*       */     public QueryResult setCompiledCursor(DatastorePb.CompiledCursor x) {
/* 12162 */       if (x == null) throw new NullPointerException();
/* 12163 */       this.optional_0_ |= 32;
/* 12164 */       this.compiled_cursor_ = x;
/* 12165 */       return this;
/*       */     }
/*       */     public DatastorePb.CompiledCursor getMutableCompiledCursor() {
/* 12168 */       this.optional_0_ |= 32;
/* 12169 */       if (this.compiled_cursor_ == null) this.compiled_cursor_ = new DatastorePb.CompiledCursor();
/* 12170 */       return this.compiled_cursor_;
/*       */     }
/*       */ 
/*       */     public QueryResult mergeFrom(QueryResult that)
/*       */     {
/* 12177 */       assert (that != this);
/* 12178 */       int this_t0 = this.optional_0_;
/* 12179 */       int that_t0 = that.optional_0_;
/*       */ 
/* 12181 */       if ((that_t0 & 0x1) != 0) {
/* 12182 */         this_t0 |= 1;
/* 12183 */         DatastorePb.Cursor v = this.cursor_;
/* 12184 */         if (v == null) this.cursor_ = (v = new DatastorePb.Cursor());
/* 12185 */         v.mergeFrom(that.cursor_);
/*       */       }
/*       */ 
/* 12188 */       if (that.result_ != null) {
/* 12189 */         for (OnestoreEntity.EntityProto v : that.result_) {
/* 12190 */           addResult().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 12194 */       if ((that_t0 & 0x2) != 0) {
/* 12195 */         this_t0 |= 2;
/* 12196 */         this.skipped_results_ = that.skipped_results_;
/*       */       }
/*       */ 
/* 12199 */       if ((that_t0 & 0x4) != 0) {
/* 12200 */         this_t0 |= 4;
/* 12201 */         this.more_results_ = that.more_results_;
/*       */       }
/*       */ 
/* 12204 */       if ((that_t0 & 0x8) != 0) {
/* 12205 */         this_t0 |= 8;
/* 12206 */         this.keys_only_ = that.keys_only_;
/*       */       }
/*       */ 
/* 12209 */       if ((that_t0 & 0x10) != 0) {
/* 12210 */         this_t0 |= 16;
/* 12211 */         DatastorePb.CompiledQuery v = this.compiled_query_;
/* 12212 */         if (v == null) this.compiled_query_ = (v = new DatastorePb.CompiledQuery());
/* 12213 */         v.mergeFrom(that.compiled_query_);
/*       */       }
/*       */ 
/* 12216 */       if ((that_t0 & 0x20) != 0) {
/* 12217 */         this_t0 |= 32;
/* 12218 */         DatastorePb.CompiledCursor v = this.compiled_cursor_;
/* 12219 */         if (v == null) this.compiled_cursor_ = (v = new DatastorePb.CompiledCursor());
/* 12220 */         v.mergeFrom(that.compiled_cursor_);
/*       */       }
/*       */ 
/* 12223 */       if (that.uninterpreted != null) {
/* 12224 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 12226 */       this.optional_0_ = this_t0;
/* 12227 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(QueryResult that) {
/* 12231 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(QueryResult that) {
/* 12235 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(QueryResult that, boolean ignoreUninterpreted) {
/* 12239 */       if (that == null) return false;
/* 12240 */       if (that == this) return true;
/* 12241 */       int this_t0 = this.optional_0_;
/* 12242 */       int that_t0 = that.optional_0_;
/* 12243 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 12245 */       if (((this_t0 & 0x1) != 0) && 
/* 12246 */         (!this.cursor_.equals(that.cursor_, ignoreUninterpreted))) return false;
/* 12250 */       int n;
/* 12250 */       if ((n = this.result_ != null ? this.result_.size() : 0) != (that.result_ != null ? that.result_.size() : 0)) return false;
/* 12251 */       for (int i = 0; i < n; i++) {
/* 12252 */         if (!((OnestoreEntity.EntityProto)this.result_.get(i)).equals((OnestoreEntity.EntityProto)that.result_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 12255 */       if (((this_t0 & 0x2) != 0) && 
/* 12256 */         (this.skipped_results_ != that.skipped_results_)) return false;
/*       */ 
/* 12259 */       if (((this_t0 & 0x4) != 0) && 
/* 12260 */         (this.more_results_ != that.more_results_)) return false;
/*       */ 
/* 12263 */       if (((this_t0 & 0x8) != 0) && 
/* 12264 */         (this.keys_only_ != that.keys_only_)) return false;
/*       */ 
/* 12267 */       if (((this_t0 & 0x10) != 0) && 
/* 12268 */         (!this.compiled_query_.equals(that.compiled_query_, ignoreUninterpreted))) return false;
/*       */ 
/* 12271 */       if (((this_t0 & 0x20) != 0) && 
/* 12272 */         (!this.compiled_cursor_.equals(that.compiled_cursor_, ignoreUninterpreted))) return false;
/*       */ 
/* 12275 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 12280 */       return ((that instanceof QueryResult)) && (equals((QueryResult)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 12284 */       int hash = -76248718;
/*       */ 
/* 12286 */       int this_t0 = this.optional_0_;
/* 12287 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.cursor_.hashCode() : -113);
/*       */ 
/* 12289 */       hash *= 31;
/* 12290 */       int i = 0; for (int n = this.result_ != null ? this.result_.size() : 0; i < n; i++) {
/* 12291 */         hash = hash * 31 + ((OnestoreEntity.EntityProto)this.result_.get(i)).hashCode();
/*       */       }
/*       */ 
/* 12294 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? 1237 : this.more_results_ ? 1231 : -113);
/*       */ 
/* 12296 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? 1237 : this.keys_only_ ? 1231 : -113);
/*       */ 
/* 12298 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? this.compiled_query_.hashCode() : -113);
/*       */ 
/* 12300 */       hash = hash * 31 + ((this_t0 & 0x20) != 0 ? this.compiled_cursor_.hashCode() : -113);
/*       */ 
/* 12302 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.skipped_results_ : -113);
/* 12303 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 12304 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 12306 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 12310 */       int this_t0 = this.optional_0_;
/* 12311 */       if ((this_t0 & 0x4) != 4) {
/* 12312 */         return false;
/*       */       }
/*       */ 
/* 12315 */       if (((this_t0 & 0x1) != 0) && 
/* 12316 */         (!this.cursor_.isInitialized())) {
/* 12317 */         return false;
/*       */       }
/*       */ 
/* 12321 */       if (this.result_ != null) {
/* 12322 */         for (OnestoreEntity.EntityProto v : this.result_) {
/* 12323 */           if (!v.isInitialized()) {
/* 12324 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/* 12329 */       if (((this_t0 & 0x10) != 0) && 
/* 12330 */         (!this.compiled_query_.isInitialized())) {
/* 12331 */         return false;
/*       */       }
/*       */ 
/* 12337 */       return ((this_t0 & 0x20) == 0) || 
/* 12336 */         (this.compiled_cursor_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 12345 */       int n = 2;
/*       */       int m;
/* 12348 */       n += (m = this.result_ != null ? this.result_.size() : 0);
/* 12349 */       for (int i = 0; i < m; i++) {
/* 12350 */         n += Protocol.stringSize(((OnestoreEntity.EntityProto)this.result_.get(i)).encodingSize());
/*       */       }
/* 12352 */       int this_t0 = this.optional_0_;
/* 12353 */       if ((this_t0 & 0x3B) != 0) {
/* 12354 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/* 12356 */           n += 1 + Protocol.stringSize(this.cursor_.encodingSize());
/*       */         }
/* 12358 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 12360 */           n += 1 + Protocol.varLongSize(this.skipped_results_);
/*       */         }
/* 12362 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/* 12364 */           n += 2;
/*       */         }
/* 12366 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/* 12368 */           n += 1 + Protocol.stringSize(this.compiled_query_.encodingSize());
/*       */         }
/* 12370 */         if ((this_t0 & 0x20) != 0)
/*       */         {
/* 12372 */           n += 1 + Protocol.stringSize(this.compiled_cursor_.encodingSize());
/*       */         }
/*       */       }
/*       */ 
/* 12376 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 12384 */       int n = 15;
/*       */       int m;
/* 12387 */       n += 6 * (m = this.result_ != null ? this.result_.size() : 0);
/* 12388 */       for (int i = 0; i < m; i++) {
/* 12389 */         n += ((OnestoreEntity.EntityProto)this.result_.get(i)).maxEncodingSize();
/*       */       }
/* 12391 */       int this_t0 = this.optional_0_;
/* 12392 */       if ((this_t0 & 0x31) != 0) {
/* 12393 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/* 12395 */           n += 6 + this.cursor_.maxEncodingSize();
/*       */         }
/* 12397 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/* 12399 */           n += 6 + this.compiled_query_.maxEncodingSize();
/*       */         }
/* 12401 */         if ((this_t0 & 0x20) != 0)
/*       */         {
/* 12403 */           n += 6 + this.compiled_cursor_.maxEncodingSize();
/*       */         }
/*       */       }
/*       */ 
/* 12407 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 12412 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 12416 */       this.optional_0_ = 0;
/* 12417 */       if (this.cursor_ != null) this.cursor_.clear();
/* 12418 */       if (this.result_ != null) this.result_.clear();
/* 12419 */       this.skipped_results_ = 0;
/* 12420 */       this.more_results_ = false;
/* 12421 */       this.keys_only_ = false;
/* 12422 */       if (this.compiled_query_ != null) this.compiled_query_.clear();
/* 12423 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.clear();
/* 12424 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public QueryResult newInstance() {
/* 12428 */       return new QueryResult();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 12432 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 12482 */       int this_t0 = this.optional_0_;
/* 12483 */       if ((this_t0 & 0x1) != 0) {
/* 12484 */         sink.putByte(10);
/* 12485 */         sink.putForeign(this.cursor_);
/*       */       }
/*       */ 
/* 12488 */       int i = 0; for (int m = this.result_ != null ? this.result_.size() : 0; i < m; i++) {
/* 12489 */         OnestoreEntity.EntityProto v = (OnestoreEntity.EntityProto)this.result_.get(i);
/* 12490 */         sink.putByte(18);
/* 12491 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 12494 */       sink.putByte(24);
/* 12495 */       sink.putBoolean(this.more_results_);
/*       */ 
/* 12497 */       if ((this_t0 & 0x8) != 0) {
/* 12498 */         sink.putByte(32);
/* 12499 */         sink.putBoolean(this.keys_only_);
/*       */       }
/*       */ 
/* 12502 */       if ((this_t0 & 0x10) != 0) {
/* 12503 */         sink.putByte(42);
/* 12504 */         sink.putForeign(this.compiled_query_);
/*       */       }
/*       */ 
/* 12507 */       if ((this_t0 & 0x20) != 0) {
/* 12508 */         sink.putByte(50);
/* 12509 */         sink.putForeign(this.compiled_cursor_);
/*       */       }
/*       */ 
/* 12512 */       if ((this_t0 & 0x2) != 0) {
/* 12513 */         sink.putByte(56);
/* 12514 */         sink.putVarLong(this.skipped_results_);
/*       */       }
/*       */ 
/* 12517 */       if (this.uninterpreted != null)
/* 12518 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 12523 */       boolean result = true;
/* 12524 */       int this_t0 = this.optional_0_;
/*       */ 
/* 12526 */       while (source.hasRemaining()) {
/* 12527 */         int tt = source.getVarInt();
/* 12528 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 12532 */           result = false;
/* 12533 */           break;
/*       */         case 10:
/* 12536 */           source.push(source.getVarInt());
/* 12537 */           DatastorePb.Cursor v1 = this.cursor_;
/* 12538 */           if (v1 == null) this.cursor_ = (v1 = new DatastorePb.Cursor());
/* 12539 */           if (!v1.merge(source)) { result = false; break label383; }
/* 12540 */           source.pop();
/* 12541 */           this_t0 |= 1;
/* 12542 */           break;
/*       */         case 18:
/* 12545 */           source.push(source.getVarInt());
/* 12546 */           if (!addResult().merge(source)) { result = false; break label383; }
/* 12547 */           source.pop();
/* 12548 */           break;
/*       */         case 24:
/* 12551 */           this.more_results_ = source.getBoolean();
/* 12552 */           this_t0 |= 4;
/* 12553 */           break;
/*       */         case 32:
/* 12556 */           this.keys_only_ = source.getBoolean();
/* 12557 */           this_t0 |= 8;
/* 12558 */           break;
/*       */         case 42:
/* 12561 */           source.push(source.getVarInt());
/* 12562 */           DatastorePb.CompiledQuery v5 = this.compiled_query_;
/* 12563 */           if (v5 == null) this.compiled_query_ = (v5 = new DatastorePb.CompiledQuery());
/* 12564 */           if (!v5.merge(source)) { result = false; break label383; }
/* 12565 */           source.pop();
/* 12566 */           this_t0 |= 16;
/* 12567 */           break;
/*       */         case 50:
/* 12570 */           source.push(source.getVarInt());
/* 12571 */           DatastorePb.CompiledCursor v6 = this.compiled_cursor_;
/* 12572 */           if (v6 == null) this.compiled_cursor_ = (v6 = new DatastorePb.CompiledCursor());
/* 12573 */           if (!v6.merge(source)) { result = false; break label383; }
/* 12574 */           source.pop();
/* 12575 */           this_t0 |= 32;
/* 12576 */           break;
/*       */         case 56:
/* 12579 */           this.skipped_results_ = source.getVarInt();
/* 12580 */           this_t0 |= 2;
/* 12581 */           break;
/*       */         default:
/* 12583 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 12588 */       label383: this.optional_0_ = this_t0;
/* 12589 */       return result;
/*       */     }
/*       */ 
/*       */     public QueryResult getDefaultInstanceForType()
/*       */     {
/* 12594 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final QueryResult getDefaultInstance() {
/* 12598 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public QueryResult freeze()
/*       */     {
/* 12712 */       if (this.cursor_ != null) this.cursor_.freeze();
/* 12713 */       this.result_ = ProtocolSupport.freezeMessages(this.result_);
/* 12714 */       if (this.compiled_query_ != null) this.compiled_query_.freeze();
/* 12715 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.freeze();
/* 12716 */       return this;
/*       */     }
/*       */ 
/*       */     public QueryResult unfreeze() {
/* 12720 */       if (this.cursor_ != null) this.cursor_.unfreeze();
/* 12721 */       this.result_ = ProtocolSupport.unfreezeMessages(this.result_);
/* 12722 */       if (this.compiled_query_ != null) this.compiled_query_.unfreeze();
/* 12723 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.unfreeze();
/* 12724 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 12728 */       return ((this.cursor_ != null) && (this.cursor_.isFrozen())) || (ProtocolSupport.isFrozenMessages(this.result_)) || ((this.compiled_query_ != null) && (this.compiled_query_.isFrozen())) || ((this.compiled_cursor_ != null) && (this.compiled_cursor_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/* 12734 */       if (this.uninterpreted == null) {
/* 12735 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 12737 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 12602 */       IMMUTABLE_DEFAULT_INSTANCE = new QueryResult()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.QueryResult clearCursor()
/*       */         {
/* 12610 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult setCursor(DatastorePb.Cursor x) {
/* 12613 */           ProtocolSupport.unsupportedOperation();
/* 12614 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor getMutableCursor() {
/* 12617 */           return (DatastorePb.Cursor)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult clearResult()
/*       */         {
/* 12622 */           return this;
/*       */         }
/*       */         public OnestoreEntity.EntityProto getMutableResult(int i) {
/* 12625 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto addResult() {
/* 12628 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto addResult(OnestoreEntity.EntityProto v) {
/* 12631 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto insertResult(int i, OnestoreEntity.EntityProto v) {
/* 12634 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto removeResult(int i) {
/* 12637 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult clearSkippedResults()
/*       */         {
/* 12642 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult setSkippedResults(int x) {
/* 12645 */           ProtocolSupport.unsupportedOperation();
/* 12646 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult clearMoreResults()
/*       */         {
/* 12651 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult setMoreResults(boolean x) {
/* 12654 */           ProtocolSupport.unsupportedOperation();
/* 12655 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult clearKeysOnly()
/*       */         {
/* 12660 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult setKeysOnly(boolean x) {
/* 12663 */           ProtocolSupport.unsupportedOperation();
/* 12664 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult clearCompiledQuery()
/*       */         {
/* 12669 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult setCompiledQuery(DatastorePb.CompiledQuery x) {
/* 12672 */           ProtocolSupport.unsupportedOperation();
/* 12673 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery getMutableCompiledQuery() {
/* 12676 */           return (DatastorePb.CompiledQuery)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult clearCompiledCursor()
/*       */         {
/* 12681 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult setCompiledCursor(DatastorePb.CompiledCursor x) {
/* 12684 */           ProtocolSupport.unsupportedOperation();
/* 12685 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledCursor getMutableCompiledCursor() {
/* 12688 */           return (DatastorePb.CompiledCursor)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.QueryResult mergeFrom(DatastorePb.QueryResult that) {
/* 12692 */           ProtocolSupport.unsupportedOperation();
/* 12693 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 12696 */           ProtocolSupport.unsupportedOperation();
/* 12697 */           return false;
/*       */         }
/*       */         public DatastorePb.QueryResult freeze() {
/* 12700 */           return this;
/*       */         }
/*       */         public DatastorePb.QueryResult unfreeze() {
/* 12703 */           ProtocolSupport.unsupportedOperation();
/* 12704 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 12707 */           return true;
/*       */         }
/*       */       };
/* 12748 */       text = new String[8];
/*       */ 
/* 12750 */       text[0] = "ErrorCode";
/* 12751 */       text[1] = "cursor";
/* 12752 */       text[2] = "result";
/* 12753 */       text[3] = "more_results";
/* 12754 */       text[4] = "keys_only";
/* 12755 */       text[5] = "compiled_query";
/* 12756 */       text[6] = "compiled_cursor";
/* 12757 */       text[7] = "skipped_results";
/*       */ 
/* 12760 */       types = new int[8];
/*       */ 
/* 12762 */       Arrays.fill(types, 6);
/* 12763 */       types[0] = 0;
/* 12764 */       types[1] = 2;
/* 12765 */       types[2] = 2;
/* 12766 */       types[3] = 0;
/* 12767 */       types[4] = 0;
/* 12768 */       types[5] = 2;
/* 12769 */       types[6] = 2;
/* 12770 */       types[7] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 12436 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.QueryResult.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("cursor", "cursor", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Cursor.class), new ProtocolType.FieldType("result", "result", 2, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.EntityProto.class), new ProtocolType.FieldType("skipped_results", "skipped_results", 7, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("more_results", "more_results", 3, 2, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("keys_only", "keys_only", 4, 3, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("compiled_query", "compiled_query", 5, 4, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.CompiledQuery.class), new ProtocolType.FieldType("compiled_cursor", "compiled_cursor", 6, 5, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.CompiledCursor.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class NextRequest extends ProtocolMessage<NextRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 11509 */     private DatastorePb.Cursor cursor_ = new DatastorePb.Cursor();
/* 11510 */     private int count_ = 0;
/* 11511 */     private int offset_ = 0;
/* 11512 */     private boolean compile_ = false;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final NextRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kcursor = 1;
/*       */     public static final int kcount = 2;
/*       */     public static final int koffset = 4;
/*       */     public static final int kcompile = 3;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final DatastorePb.Cursor getCursor()
/*       */     {
/* 11518 */       return this.cursor_;
/*       */     }
/*       */     public final boolean hasCursor() {
/* 11521 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public NextRequest clearCursor() {
/* 11524 */       this.optional_0_ &= -2;
/* 11525 */       this.cursor_.clear();
/* 11526 */       return this;
/*       */     }
/*       */     public NextRequest setCursor(DatastorePb.Cursor x) {
/* 11529 */       if (x == null) throw new NullPointerException();
/* 11530 */       this.optional_0_ |= 1;
/* 11531 */       this.cursor_ = x;
/* 11532 */       return this;
/*       */     }
/*       */     public DatastorePb.Cursor getMutableCursor() {
/* 11535 */       this.optional_0_ |= 1;
/* 11536 */       return this.cursor_;
/*       */     }
/*       */ 
/*       */     public final int getCount()
/*       */     {
/* 11541 */       return this.count_;
/*       */     }
/*       */     public final boolean hasCount() {
/* 11544 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public NextRequest clearCount() {
/* 11547 */       this.optional_0_ &= -3;
/* 11548 */       this.count_ = 0;
/* 11549 */       return this;
/*       */     }
/*       */     public NextRequest setCount(int x) {
/* 11552 */       this.optional_0_ |= 2;
/* 11553 */       this.count_ = x;
/* 11554 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getOffset()
/*       */     {
/* 11559 */       return this.offset_;
/*       */     }
/*       */     public final boolean hasOffset() {
/* 11562 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public NextRequest clearOffset() {
/* 11565 */       this.optional_0_ &= -5;
/* 11566 */       this.offset_ = 0;
/* 11567 */       return this;
/*       */     }
/*       */     public NextRequest setOffset(int x) {
/* 11570 */       this.optional_0_ |= 4;
/* 11571 */       this.offset_ = x;
/* 11572 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isCompile()
/*       */     {
/* 11577 */       return this.compile_;
/*       */     }
/*       */     public final boolean hasCompile() {
/* 11580 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public NextRequest clearCompile() {
/* 11583 */       this.optional_0_ &= -9;
/* 11584 */       this.compile_ = false;
/* 11585 */       return this;
/*       */     }
/*       */     public NextRequest setCompile(boolean x) {
/* 11588 */       this.optional_0_ |= 8;
/* 11589 */       this.compile_ = x;
/* 11590 */       return this;
/*       */     }
/*       */ 
/*       */     public NextRequest mergeFrom(NextRequest that)
/*       */     {
/* 11597 */       assert (that != this);
/* 11598 */       int this_t0 = this.optional_0_;
/* 11599 */       int that_t0 = that.optional_0_;
/*       */ 
/* 11601 */       if ((that_t0 & 0x1) != 0) {
/* 11602 */         this_t0 |= 1;
/* 11603 */         DatastorePb.Cursor v = this.cursor_;
/* 11604 */         v.mergeFrom(that.cursor_);
/*       */       }
/*       */ 
/* 11607 */       if ((that_t0 & 0x2) != 0) {
/* 11608 */         this_t0 |= 2;
/* 11609 */         this.count_ = that.count_;
/*       */       }
/*       */ 
/* 11612 */       if ((that_t0 & 0x4) != 0) {
/* 11613 */         this_t0 |= 4;
/* 11614 */         this.offset_ = that.offset_;
/*       */       }
/*       */ 
/* 11617 */       if ((that_t0 & 0x8) != 0) {
/* 11618 */         this_t0 |= 8;
/* 11619 */         this.compile_ = that.compile_;
/*       */       }
/*       */ 
/* 11622 */       if (that.uninterpreted != null) {
/* 11623 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 11625 */       this.optional_0_ = this_t0;
/* 11626 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(NextRequest that) {
/* 11630 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(NextRequest that) {
/* 11634 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(NextRequest that, boolean ignoreUninterpreted) {
/* 11638 */       if (that == null) return false;
/* 11639 */       if (that == this) return true;
/* 11640 */       int this_t0 = this.optional_0_;
/* 11641 */       int that_t0 = that.optional_0_;
/* 11642 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 11644 */       if (((this_t0 & 0x1) != 0) && 
/* 11645 */         (!this.cursor_.equals(that.cursor_, ignoreUninterpreted))) return false;
/*       */ 
/* 11648 */       if (((this_t0 & 0x2) != 0) && 
/* 11649 */         (this.count_ != that.count_)) return false;
/*       */ 
/* 11652 */       if (((this_t0 & 0x4) != 0) && 
/* 11653 */         (this.offset_ != that.offset_)) return false;
/*       */ 
/* 11656 */       if (((this_t0 & 0x8) != 0) && 
/* 11657 */         (this.compile_ != that.compile_)) return false;
/*       */ 
/* 11660 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 11665 */       return ((that instanceof NextRequest)) && (equals((NextRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 11669 */       int hash = -1275574653;
/*       */ 
/* 11671 */       int this_t0 = this.optional_0_;
/* 11672 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.cursor_.hashCode() : -113);
/*       */ 
/* 11674 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.count_ : -113);
/*       */ 
/* 11676 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? 1237 : this.compile_ ? 1231 : -113);
/*       */ 
/* 11678 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.offset_ : -113);
/* 11679 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 11680 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 11682 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/* 11686 */       int this_t0 = this.optional_0_;
/* 11687 */       if ((this_t0 & 0x1) != 1) {
/* 11688 */         return false;
/*       */       }
/*       */ 
/* 11692 */       return this.cursor_.isInitialized();
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 11699 */       int n = 1 + Protocol.stringSize(this.cursor_.encodingSize());
/* 11700 */       int this_t0 = this.optional_0_;
/* 11701 */       if ((this_t0 & 0xE) != 0) {
/* 11702 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 11704 */           n += 1 + Protocol.varLongSize(this.count_);
/*       */         }
/* 11706 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/* 11708 */           n += 1 + Protocol.varLongSize(this.offset_);
/*       */         }
/* 11710 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/* 11712 */           n += 2;
/*       */         }
/*       */       }
/*       */ 
/* 11716 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 11725 */       int n = 30 + this.cursor_.maxEncodingSize();
/*       */ 
/* 11727 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 11732 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 11736 */       this.optional_0_ = 0;
/* 11737 */       this.cursor_.clear();
/* 11738 */       this.count_ = 0;
/* 11739 */       this.offset_ = 0;
/* 11740 */       this.compile_ = false;
/* 11741 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public NextRequest newInstance() {
/* 11745 */       return new NextRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 11749 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 11783 */       sink.putByte(10);
/* 11784 */       sink.putForeign(this.cursor_);
/*       */ 
/* 11786 */       int this_t0 = this.optional_0_;
/* 11787 */       if ((this_t0 & 0x2) != 0) {
/* 11788 */         sink.putByte(16);
/* 11789 */         sink.putVarLong(this.count_);
/*       */       }
/*       */ 
/* 11792 */       if ((this_t0 & 0x8) != 0) {
/* 11793 */         sink.putByte(24);
/* 11794 */         sink.putBoolean(this.compile_);
/*       */       }
/*       */ 
/* 11797 */       if ((this_t0 & 0x4) != 0) {
/* 11798 */         sink.putByte(32);
/* 11799 */         sink.putVarLong(this.offset_);
/*       */       }
/*       */ 
/* 11802 */       if (this.uninterpreted != null)
/* 11803 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 11808 */       boolean result = true;
/* 11809 */       int this_t0 = this.optional_0_;
/*       */ 
/* 11811 */       while (source.hasRemaining()) {
/* 11812 */         int tt = source.getVarInt();
/* 11813 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 11817 */           result = false;
/* 11818 */           break;
/*       */         case 10:
/* 11821 */           source.push(source.getVarInt());
/* 11822 */           if (!this.cursor_.merge(source)) { result = false; break label181; }
/* 11823 */           source.pop();
/* 11824 */           this_t0 |= 1;
/* 11825 */           break;
/*       */         case 16:
/* 11828 */           this.count_ = source.getVarInt();
/* 11829 */           this_t0 |= 2;
/* 11830 */           break;
/*       */         case 24:
/* 11833 */           this.compile_ = source.getBoolean();
/* 11834 */           this_t0 |= 8;
/* 11835 */           break;
/*       */         case 32:
/* 11838 */           this.offset_ = source.getVarInt();
/* 11839 */           this_t0 |= 4;
/* 11840 */           break;
/*       */         default:
/* 11842 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 11847 */       label181: this.optional_0_ = this_t0;
/* 11848 */       return result;
/*       */     }
/*       */ 
/*       */     public NextRequest getDefaultInstanceForType()
/*       */     {
/* 11853 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final NextRequest getDefaultInstance() {
/* 11857 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public NextRequest freeze()
/*       */     {
/* 11927 */       this.cursor_.freeze();
/* 11928 */       return this;
/*       */     }
/*       */ 
/*       */     public NextRequest unfreeze() {
/* 11932 */       this.cursor_.unfreeze();
/* 11933 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 11937 */       return this.cursor_.isFrozen();
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 11940 */       if (this.uninterpreted == null) {
/* 11941 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 11943 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 11861 */       IMMUTABLE_DEFAULT_INSTANCE = new NextRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.NextRequest clearCursor()
/*       */         {
/* 11869 */           return this;
/*       */         }
/*       */         public DatastorePb.NextRequest setCursor(DatastorePb.Cursor x) {
/* 11872 */           ProtocolSupport.unsupportedOperation();
/* 11873 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor getMutableCursor() {
/* 11876 */           return (DatastorePb.Cursor)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.NextRequest clearCount()
/*       */         {
/* 11881 */           return this;
/*       */         }
/*       */         public DatastorePb.NextRequest setCount(int x) {
/* 11884 */           ProtocolSupport.unsupportedOperation();
/* 11885 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.NextRequest clearOffset()
/*       */         {
/* 11890 */           return this;
/*       */         }
/*       */         public DatastorePb.NextRequest setOffset(int x) {
/* 11893 */           ProtocolSupport.unsupportedOperation();
/* 11894 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.NextRequest clearCompile()
/*       */         {
/* 11899 */           return this;
/*       */         }
/*       */         public DatastorePb.NextRequest setCompile(boolean x) {
/* 11902 */           ProtocolSupport.unsupportedOperation();
/* 11903 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.NextRequest mergeFrom(DatastorePb.NextRequest that) {
/* 11907 */           ProtocolSupport.unsupportedOperation();
/* 11908 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 11911 */           ProtocolSupport.unsupportedOperation();
/* 11912 */           return false;
/*       */         }
/*       */         public DatastorePb.NextRequest freeze() {
/* 11915 */           return this;
/*       */         }
/*       */         public DatastorePb.NextRequest unfreeze() {
/* 11918 */           ProtocolSupport.unsupportedOperation();
/* 11919 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 11922 */           return true;
/*       */         }
/*       */       };
/* 11951 */       text = new String[5];
/*       */ 
/* 11953 */       text[0] = "ErrorCode";
/* 11954 */       text[1] = "cursor";
/* 11955 */       text[2] = "count";
/* 11956 */       text[3] = "compile";
/* 11957 */       text[4] = "offset";
/*       */ 
/* 11960 */       types = new int[5];
/*       */ 
/* 11962 */       Arrays.fill(types, 6);
/* 11963 */       types[0] = 0;
/* 11964 */       types[1] = 2;
/* 11965 */       types[2] = 0;
/* 11966 */       types[3] = 0;
/* 11967 */       types[4] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 11753 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.NextRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("cursor", "cursor", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, DatastorePb.Cursor.class), new ProtocolType.FieldType("count", "count", 2, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("offset", "offset", 4, 2, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("compile", "compile", 3, 3, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class DeleteResponse extends ProtocolMessage<DeleteResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 11213 */     private DatastorePb.Cost cost_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final DeleteResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kcost = 1;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final DatastorePb.Cost getCost()
/*       */     {
/* 11219 */       if (this.cost_ == null) {
/* 11220 */         return DatastorePb.Cost.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 11222 */       return this.cost_;
/*       */     }
/*       */     public final boolean hasCost() {
/* 11225 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public DeleteResponse clearCost() {
/* 11228 */       this.optional_0_ &= -2;
/* 11229 */       if (this.cost_ != null) this.cost_.clear();
/* 11230 */       return this;
/*       */     }
/*       */     public DeleteResponse setCost(DatastorePb.Cost x) {
/* 11233 */       if (x == null) throw new NullPointerException();
/* 11234 */       this.optional_0_ |= 1;
/* 11235 */       this.cost_ = x;
/* 11236 */       return this;
/*       */     }
/*       */     public DatastorePb.Cost getMutableCost() {
/* 11239 */       this.optional_0_ |= 1;
/* 11240 */       if (this.cost_ == null) this.cost_ = new DatastorePb.Cost();
/* 11241 */       return this.cost_;
/*       */     }
/*       */ 
/*       */     public DeleteResponse mergeFrom(DeleteResponse that)
/*       */     {
/* 11248 */       assert (that != this);
/* 11249 */       int this_t0 = this.optional_0_;
/* 11250 */       int that_t0 = that.optional_0_;
/*       */ 
/* 11252 */       if ((that_t0 & 0x1) != 0) {
/* 11253 */         this_t0 |= 1;
/* 11254 */         DatastorePb.Cost v = this.cost_;
/* 11255 */         if (v == null) this.cost_ = (v = new DatastorePb.Cost());
/* 11256 */         v.mergeFrom(that.cost_);
/*       */       }
/*       */ 
/* 11259 */       if (that.uninterpreted != null) {
/* 11260 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 11262 */       this.optional_0_ = this_t0;
/* 11263 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(DeleteResponse that) {
/* 11267 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(DeleteResponse that) {
/* 11271 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(DeleteResponse that, boolean ignoreUninterpreted) {
/* 11275 */       if (that == null) return false;
/* 11276 */       if (that == this) return true;
/* 11277 */       int this_t0 = this.optional_0_;
/* 11278 */       int that_t0 = that.optional_0_;
/* 11279 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 11281 */       if (((this_t0 & 0x1) != 0) && 
/* 11282 */         (!this.cost_.equals(that.cost_, ignoreUninterpreted))) return false;
/*       */ 
/* 11285 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 11290 */       return ((that instanceof DeleteResponse)) && (equals((DeleteResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 11294 */       int hash = -411317989;
/*       */ 
/* 11296 */       int this_t0 = this.optional_0_;
/* 11297 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.cost_.hashCode() : -113);
/* 11298 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 11299 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 11301 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 11306 */       int this_t0 = this.optional_0_;
/*       */ 
/* 11309 */       return ((this_t0 & 0x1) == 0) || 
/* 11308 */         (this.cost_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 11316 */       int n = 0;
/* 11317 */       int this_t0 = this.optional_0_;
/* 11318 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 11320 */         n += 1 + Protocol.stringSize(this.cost_.encodingSize());
/*       */       }
/*       */ 
/* 11323 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 11328 */       int n = 0;
/* 11329 */       int this_t0 = this.optional_0_;
/* 11330 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 11332 */         n += 6 + this.cost_.maxEncodingSize();
/*       */       }
/*       */ 
/* 11335 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 11340 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 11344 */       this.optional_0_ = 0;
/* 11345 */       if (this.cost_ != null) this.cost_.clear();
/* 11346 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public DeleteResponse newInstance() {
/* 11350 */       return new DeleteResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 11354 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 11375 */       int this_t0 = this.optional_0_;
/* 11376 */       if ((this_t0 & 0x1) != 0) {
/* 11377 */         sink.putByte(10);
/* 11378 */         sink.putForeign(this.cost_);
/*       */       }
/*       */ 
/* 11381 */       if (this.uninterpreted != null)
/* 11382 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 11387 */       boolean result = true;
/* 11388 */       int this_t0 = this.optional_0_;
/*       */ 
/* 11390 */       while (source.hasRemaining()) {
/* 11391 */         int tt = source.getVarInt();
/* 11392 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 11396 */           result = false;
/* 11397 */           break;
/*       */         case 10:
/* 11400 */           source.push(source.getVarInt());
/* 11401 */           DatastorePb.Cost v1 = this.cost_;
/* 11402 */           if (v1 == null) this.cost_ = (v1 = new DatastorePb.Cost());
/* 11403 */           if (!v1.merge(source)) { result = false; break label134; }
/* 11404 */           source.pop();
/* 11405 */           this_t0 |= 1;
/* 11406 */           break;
/*       */         default:
/* 11408 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 11413 */       label134: this.optional_0_ = this_t0;
/* 11414 */       return result;
/*       */     }
/*       */ 
/*       */     public DeleteResponse getDefaultInstanceForType()
/*       */     {
/* 11419 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final DeleteResponse getDefaultInstance() {
/* 11423 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public DeleteResponse freeze()
/*       */     {
/* 11466 */       if (this.cost_ != null) this.cost_.freeze();
/* 11467 */       return this;
/*       */     }
/*       */ 
/*       */     public DeleteResponse unfreeze() {
/* 11471 */       if (this.cost_ != null) this.cost_.unfreeze();
/* 11472 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 11476 */       return (this.cost_ != null) && (this.cost_.isFrozen());
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 11479 */       if (this.uninterpreted == null) {
/* 11480 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 11482 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 11427 */       IMMUTABLE_DEFAULT_INSTANCE = new DeleteResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.DeleteResponse clearCost()
/*       */         {
/* 11435 */           return this;
/*       */         }
/*       */         public DatastorePb.DeleteResponse setCost(DatastorePb.Cost x) {
/* 11438 */           ProtocolSupport.unsupportedOperation();
/* 11439 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost getMutableCost() {
/* 11442 */           return (DatastorePb.Cost)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.DeleteResponse mergeFrom(DatastorePb.DeleteResponse that) {
/* 11446 */           ProtocolSupport.unsupportedOperation();
/* 11447 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 11450 */           ProtocolSupport.unsupportedOperation();
/* 11451 */           return false;
/*       */         }
/*       */         public DatastorePb.DeleteResponse freeze() {
/* 11454 */           return this;
/*       */         }
/*       */         public DatastorePb.DeleteResponse unfreeze() {
/* 11457 */           ProtocolSupport.unsupportedOperation();
/* 11458 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 11461 */           return true;
/*       */         }
/*       */       };
/* 11487 */       text = new String[2];
/*       */ 
/* 11489 */       text[0] = "ErrorCode";
/* 11490 */       text[1] = "cost";
/*       */ 
/* 11493 */       types = new int[2];
/*       */ 
/* 11495 */       Arrays.fill(types, 6);
/* 11496 */       types[0] = 0;
/* 11497 */       types[1] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 11358 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.DeleteResponse.class, "Z'apphosting/datastore/datastore_v3.proto\n&apphosting_datastore_v3.DeleteResponse\023\032\004cost \001(\0020\0138\001J\034apphosting_datastore_v3.Cost\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("cost", "cost", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Cost.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class DeleteRequest extends ProtocolMessage<DeleteRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 10720 */     private List<OnestoreEntity.Reference> key_ = null;
/* 10721 */     private DatastorePb.Transaction transaction_ = null;
/* 10722 */     private boolean trusted_ = false;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final DeleteRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kkey = 6;
/*       */     public static final int ktransaction = 5;
/*       */     public static final int ktrusted = 4;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int keySize()
/*       */     {
/* 10728 */       return this.key_ != null ? this.key_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.Reference getKey(int i) {
/* 10731 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.key_ != null ? this.key_.size() : 0)); } else throw new AssertionError();
/* 10732 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public DeleteRequest clearKey() {
/* 10735 */       if (this.key_ != null) this.key_.clear();
/* 10736 */       return this;
/*       */     }
/*       */     public OnestoreEntity.Reference getMutableKey(int i) {
/* 10739 */       assert ((i >= 0) && (this.key_ != null) && (i < this.key_.size()));
/* 10740 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public OnestoreEntity.Reference addKey() {
/* 10743 */       OnestoreEntity.Reference v = new OnestoreEntity.Reference();
/* 10744 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10745 */       this.key_.add(v);
/* 10746 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/* 10749 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10750 */       this.key_.add(v);
/* 10751 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/* 10754 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10755 */       this.key_.add(i, v);
/* 10756 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference removeKey(int i) {
/* 10759 */       return (OnestoreEntity.Reference)this.key_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.Reference> keyIterator() {
/* 10762 */       if (this.key_ == null) {
/* 10763 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 10765 */       return this.key_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> keys() {
/* 10768 */       return ProtocolSupport.unmodifiableList(this.key_);
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> mutableKeys() {
/* 10771 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10772 */       return this.key_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.Transaction getTransaction()
/*       */     {
/* 10777 */       if (this.transaction_ == null) {
/* 10778 */         return DatastorePb.Transaction.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 10780 */       return this.transaction_;
/*       */     }
/*       */     public final boolean hasTransaction() {
/* 10783 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public DeleteRequest clearTransaction() {
/* 10786 */       this.optional_0_ &= -2;
/* 10787 */       if (this.transaction_ != null) this.transaction_.clear();
/* 10788 */       return this;
/*       */     }
/*       */     public DeleteRequest setTransaction(DatastorePb.Transaction x) {
/* 10791 */       if (x == null) throw new NullPointerException();
/* 10792 */       this.optional_0_ |= 1;
/* 10793 */       this.transaction_ = x;
/* 10794 */       return this;
/*       */     }
/*       */     public DatastorePb.Transaction getMutableTransaction() {
/* 10797 */       this.optional_0_ |= 1;
/* 10798 */       if (this.transaction_ == null) this.transaction_ = new DatastorePb.Transaction();
/* 10799 */       return this.transaction_;
/*       */     }
/*       */ 
/*       */     public final boolean isTrusted()
/*       */     {
/* 10804 */       return this.trusted_;
/*       */     }
/*       */     public final boolean hasTrusted() {
/* 10807 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public DeleteRequest clearTrusted() {
/* 10810 */       this.optional_0_ &= -3;
/* 10811 */       this.trusted_ = false;
/* 10812 */       return this;
/*       */     }
/*       */     public DeleteRequest setTrusted(boolean x) {
/* 10815 */       this.optional_0_ |= 2;
/* 10816 */       this.trusted_ = x;
/* 10817 */       return this;
/*       */     }
/*       */ 
/*       */     public DeleteRequest mergeFrom(DeleteRequest that)
/*       */     {
/* 10824 */       assert (that != this);
/* 10825 */       int this_t0 = this.optional_0_;
/* 10826 */       int that_t0 = that.optional_0_;
/*       */ 
/* 10828 */       if (that.key_ != null) {
/* 10829 */         for (OnestoreEntity.Reference v : that.key_) {
/* 10830 */           addKey().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 10834 */       if ((that_t0 & 0x1) != 0) {
/* 10835 */         this_t0 |= 1;
/* 10836 */         DatastorePb.Transaction v = this.transaction_;
/* 10837 */         if (v == null) this.transaction_ = (v = new DatastorePb.Transaction());
/* 10838 */         v.mergeFrom(that.transaction_);
/*       */       }
/*       */ 
/* 10841 */       if ((that_t0 & 0x2) != 0) {
/* 10842 */         this_t0 |= 2;
/* 10843 */         this.trusted_ = that.trusted_;
/*       */       }
/*       */ 
/* 10846 */       if (that.uninterpreted != null) {
/* 10847 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 10849 */       this.optional_0_ = this_t0;
/* 10850 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(DeleteRequest that) {
/* 10854 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(DeleteRequest that) {
/* 10858 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(DeleteRequest that, boolean ignoreUninterpreted) {
/* 10862 */       if (that == null) return false;
/* 10863 */       if (that == this) return true;
/* 10864 */       int this_t0 = this.optional_0_;
/* 10865 */       int that_t0 = that.optional_0_;
/* 10866 */       if (this_t0 != that_t0) return false;
/* 10869 */       int n;
/* 10869 */       if ((n = this.key_ != null ? this.key_.size() : 0) != (that.key_ != null ? that.key_.size() : 0)) return false;
/* 10870 */       for (int i = 0; i < n; i++) {
/* 10871 */         if (!((OnestoreEntity.Reference)this.key_.get(i)).equals((OnestoreEntity.Reference)that.key_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 10874 */       if (((this_t0 & 0x1) != 0) && 
/* 10875 */         (!this.transaction_.equals(that.transaction_, ignoreUninterpreted))) return false;
/*       */ 
/* 10878 */       if (((this_t0 & 0x2) != 0) && 
/* 10879 */         (this.trusted_ != that.trusted_)) return false;
/*       */ 
/* 10882 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 10887 */       return ((that instanceof DeleteRequest)) && (equals((DeleteRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 10891 */       int hash = -59827476;
/*       */ 
/* 10893 */       int this_t0 = this.optional_0_;
/* 10894 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? 1237 : this.trusted_ ? 1231 : -113);
/*       */ 
/* 10896 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.transaction_.hashCode() : -113);
/*       */ 
/* 10898 */       hash *= 31;
/* 10899 */       int i = 0; for (int n = this.key_ != null ? this.key_.size() : 0; i < n; i++) {
/* 10900 */         hash = hash * 31 + ((OnestoreEntity.Reference)this.key_.get(i)).hashCode();
/*       */       }
/* 10902 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 10903 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 10905 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 10910 */       if (this.key_ != null) {
/* 10911 */         for (OnestoreEntity.Reference v : this.key_) {
/* 10912 */           if (!v.isInitialized()) {
/* 10913 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/* 10918 */       int this_t0 = this.optional_0_;
/*       */ 
/* 10921 */       return ((this_t0 & 0x1) == 0) || 
/* 10920 */         (this.transaction_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 10928 */       int n = 0;
/*       */       int m;
/* 10931 */       n += (m = this.key_ != null ? this.key_.size() : 0);
/* 10932 */       for (int i = 0; i < m; i++) {
/* 10933 */         n += Protocol.stringSize(((OnestoreEntity.Reference)this.key_.get(i)).encodingSize());
/*       */       }
/* 10935 */       int this_t0 = this.optional_0_;
/* 10936 */       if ((this_t0 & 0x3) != 0) {
/* 10937 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/* 10939 */           n += 1 + Protocol.stringSize(this.transaction_.encodingSize());
/*       */         }
/* 10941 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/* 10943 */           n += 2;
/*       */         }
/*       */       }
/*       */ 
/* 10947 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 10953 */       int n = 2;
/*       */       int m;
/* 10956 */       n += 6 * (m = this.key_ != null ? this.key_.size() : 0);
/* 10957 */       for (int i = 0; i < m; i++) {
/* 10958 */         n += ((OnestoreEntity.Reference)this.key_.get(i)).maxEncodingSize();
/*       */       }
/* 10960 */       int this_t0 = this.optional_0_;
/* 10961 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 10963 */         n += 6 + this.transaction_.maxEncodingSize();
/*       */       }
/*       */ 
/* 10966 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 10971 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 10975 */       this.optional_0_ = 0;
/* 10976 */       if (this.key_ != null) this.key_.clear();
/* 10977 */       if (this.transaction_ != null) this.transaction_.clear();
/* 10978 */       this.trusted_ = false;
/* 10979 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public DeleteRequest newInstance() {
/* 10983 */       return new DeleteRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 10987 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 11019 */       int this_t0 = this.optional_0_;
/* 11020 */       if ((this_t0 & 0x2) != 0) {
/* 11021 */         sink.putByte(32);
/* 11022 */         sink.putBoolean(this.trusted_);
/*       */       }
/*       */ 
/* 11025 */       if ((this_t0 & 0x1) != 0) {
/* 11026 */         sink.putByte(42);
/* 11027 */         sink.putForeign(this.transaction_);
/*       */       }
/*       */ 
/* 11030 */       int i = 0; for (int m = this.key_ != null ? this.key_.size() : 0; i < m; i++) {
/* 11031 */         OnestoreEntity.Reference v = (OnestoreEntity.Reference)this.key_.get(i);
/* 11032 */         sink.putByte(50);
/* 11033 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 11036 */       if (this.uninterpreted != null)
/* 11037 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 11042 */       boolean result = true;
/* 11043 */       int this_t0 = this.optional_0_;
/*       */ 
/* 11045 */       while (source.hasRemaining()) {
/* 11046 */         int tt = source.getVarInt();
/* 11047 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 11051 */           result = false;
/* 11052 */           break;
/*       */         case 32:
/* 11055 */           this.trusted_ = source.getBoolean();
/* 11056 */           this_t0 |= 2;
/* 11057 */           break;
/*       */         case 42:
/* 11060 */           source.push(source.getVarInt());
/* 11061 */           DatastorePb.Transaction v5 = this.transaction_;
/* 11062 */           if (v5 == null) this.transaction_ = (v5 = new DatastorePb.Transaction());
/* 11063 */           if (!v5.merge(source)) { result = false; break label198; }
/* 11064 */           source.pop();
/* 11065 */           this_t0 |= 1;
/* 11066 */           break;
/*       */         case 50:
/* 11069 */           source.push(source.getVarInt());
/* 11070 */           if (!addKey().merge(source)) { result = false; break label198; }
/* 11071 */           source.pop();
/* 11072 */           break;
/*       */         default:
/* 11074 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 11079 */       label198: this.optional_0_ = this_t0;
/* 11080 */       return result;
/*       */     }
/*       */ 
/*       */     public DeleteRequest getDefaultInstanceForType()
/*       */     {
/* 11085 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final DeleteRequest getDefaultInstance() {
/* 11089 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public DeleteRequest freeze()
/*       */     {
/* 11161 */       this.key_ = ProtocolSupport.freezeMessages(this.key_);
/* 11162 */       if (this.transaction_ != null) this.transaction_.freeze();
/* 11163 */       return this;
/*       */     }
/*       */ 
/*       */     public DeleteRequest unfreeze() {
/* 11167 */       this.key_ = ProtocolSupport.unfreezeMessages(this.key_);
/* 11168 */       if (this.transaction_ != null) this.transaction_.unfreeze();
/* 11169 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 11173 */       return (ProtocolSupport.isFrozenMessages(this.key_)) || ((this.transaction_ != null) && (this.transaction_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 11177 */       if (this.uninterpreted == null) {
/* 11178 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 11180 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 11093 */       IMMUTABLE_DEFAULT_INSTANCE = new DeleteRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.DeleteRequest clearKey()
/*       */         {
/* 11101 */           return this;
/*       */         }
/*       */         public OnestoreEntity.Reference getMutableKey(int i) {
/* 11104 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey() {
/* 11107 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/* 11110 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/* 11113 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference removeKey(int i) {
/* 11116 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.DeleteRequest clearTransaction()
/*       */         {
/* 11121 */           return this;
/*       */         }
/*       */         public DatastorePb.DeleteRequest setTransaction(DatastorePb.Transaction x) {
/* 11124 */           ProtocolSupport.unsupportedOperation();
/* 11125 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction getMutableTransaction() {
/* 11128 */           return (DatastorePb.Transaction)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.DeleteRequest clearTrusted()
/*       */         {
/* 11133 */           return this;
/*       */         }
/*       */         public DatastorePb.DeleteRequest setTrusted(boolean x) {
/* 11136 */           ProtocolSupport.unsupportedOperation();
/* 11137 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.DeleteRequest mergeFrom(DatastorePb.DeleteRequest that) {
/* 11141 */           ProtocolSupport.unsupportedOperation();
/* 11142 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 11145 */           ProtocolSupport.unsupportedOperation();
/* 11146 */           return false;
/*       */         }
/*       */         public DatastorePb.DeleteRequest freeze() {
/* 11149 */           return this;
/*       */         }
/*       */         public DatastorePb.DeleteRequest unfreeze() {
/* 11152 */           ProtocolSupport.unsupportedOperation();
/* 11153 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 11156 */           return true;
/*       */         }
/*       */       };
/* 11187 */       text = new String[7];
/*       */ 
/* 11189 */       text[0] = "ErrorCode";
/* 11190 */       text[4] = "trusted";
/* 11191 */       text[5] = "transaction";
/* 11192 */       text[6] = "key";
/*       */ 
/* 11195 */       types = new int[7];
/*       */ 
/* 11197 */       Arrays.fill(types, 6);
/* 11198 */       types[0] = 0;
/* 11199 */       types[4] = 0;
/* 11200 */       types[5] = 2;
/* 11201 */       types[6] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 10991 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.DeleteRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("key", "key", 6, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Reference.class), new ProtocolType.FieldType("transaction", "transaction", 5, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Transaction.class), new ProtocolType.FieldType("trusted", "trusted", 4, 1, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class TouchResponse extends ProtocolMessage<TouchResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 10424 */     private DatastorePb.Cost cost_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final TouchResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kcost = 1;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final DatastorePb.Cost getCost()
/*       */     {
/* 10430 */       if (this.cost_ == null) {
/* 10431 */         return DatastorePb.Cost.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/* 10433 */       return this.cost_;
/*       */     }
/*       */     public final boolean hasCost() {
/* 10436 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public TouchResponse clearCost() {
/* 10439 */       this.optional_0_ &= -2;
/* 10440 */       if (this.cost_ != null) this.cost_.clear();
/* 10441 */       return this;
/*       */     }
/*       */     public TouchResponse setCost(DatastorePb.Cost x) {
/* 10444 */       if (x == null) throw new NullPointerException();
/* 10445 */       this.optional_0_ |= 1;
/* 10446 */       this.cost_ = x;
/* 10447 */       return this;
/*       */     }
/*       */     public DatastorePb.Cost getMutableCost() {
/* 10450 */       this.optional_0_ |= 1;
/* 10451 */       if (this.cost_ == null) this.cost_ = new DatastorePb.Cost();
/* 10452 */       return this.cost_;
/*       */     }
/*       */ 
/*       */     public TouchResponse mergeFrom(TouchResponse that)
/*       */     {
/* 10459 */       assert (that != this);
/* 10460 */       int this_t0 = this.optional_0_;
/* 10461 */       int that_t0 = that.optional_0_;
/*       */ 
/* 10463 */       if ((that_t0 & 0x1) != 0) {
/* 10464 */         this_t0 |= 1;
/* 10465 */         DatastorePb.Cost v = this.cost_;
/* 10466 */         if (v == null) this.cost_ = (v = new DatastorePb.Cost());
/* 10467 */         v.mergeFrom(that.cost_);
/*       */       }
/*       */ 
/* 10470 */       if (that.uninterpreted != null) {
/* 10471 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 10473 */       this.optional_0_ = this_t0;
/* 10474 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(TouchResponse that) {
/* 10478 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(TouchResponse that) {
/* 10482 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(TouchResponse that, boolean ignoreUninterpreted) {
/* 10486 */       if (that == null) return false;
/* 10487 */       if (that == this) return true;
/* 10488 */       int this_t0 = this.optional_0_;
/* 10489 */       int that_t0 = that.optional_0_;
/* 10490 */       if (this_t0 != that_t0) return false;
/*       */ 
/* 10492 */       if (((this_t0 & 0x1) != 0) && 
/* 10493 */         (!this.cost_.equals(that.cost_, ignoreUninterpreted))) return false;
/*       */ 
/* 10496 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 10501 */       return ((that instanceof TouchResponse)) && (equals((TouchResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 10505 */       int hash = 533747239;
/*       */ 
/* 10507 */       int this_t0 = this.optional_0_;
/* 10508 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.cost_.hashCode() : -113);
/* 10509 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 10510 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 10512 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 10517 */       int this_t0 = this.optional_0_;
/*       */ 
/* 10520 */       return ((this_t0 & 0x1) == 0) || 
/* 10519 */         (this.cost_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/* 10527 */       int n = 0;
/* 10528 */       int this_t0 = this.optional_0_;
/* 10529 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 10531 */         n += 1 + Protocol.stringSize(this.cost_.encodingSize());
/*       */       }
/*       */ 
/* 10534 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 10539 */       int n = 0;
/* 10540 */       int this_t0 = this.optional_0_;
/* 10541 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/* 10543 */         n += 6 + this.cost_.maxEncodingSize();
/*       */       }
/*       */ 
/* 10546 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 10551 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 10555 */       this.optional_0_ = 0;
/* 10556 */       if (this.cost_ != null) this.cost_.clear();
/* 10557 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public TouchResponse newInstance() {
/* 10561 */       return new TouchResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 10565 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 10586 */       int this_t0 = this.optional_0_;
/* 10587 */       if ((this_t0 & 0x1) != 0) {
/* 10588 */         sink.putByte(10);
/* 10589 */         sink.putForeign(this.cost_);
/*       */       }
/*       */ 
/* 10592 */       if (this.uninterpreted != null)
/* 10593 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 10598 */       boolean result = true;
/* 10599 */       int this_t0 = this.optional_0_;
/*       */ 
/* 10601 */       while (source.hasRemaining()) {
/* 10602 */         int tt = source.getVarInt();
/* 10603 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 10607 */           result = false;
/* 10608 */           break;
/*       */         case 10:
/* 10611 */           source.push(source.getVarInt());
/* 10612 */           DatastorePb.Cost v1 = this.cost_;
/* 10613 */           if (v1 == null) this.cost_ = (v1 = new DatastorePb.Cost());
/* 10614 */           if (!v1.merge(source)) { result = false; break label134; }
/* 10615 */           source.pop();
/* 10616 */           this_t0 |= 1;
/* 10617 */           break;
/*       */         default:
/* 10619 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 10624 */       label134: this.optional_0_ = this_t0;
/* 10625 */       return result;
/*       */     }
/*       */ 
/*       */     public TouchResponse getDefaultInstanceForType()
/*       */     {
/* 10630 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final TouchResponse getDefaultInstance() {
/* 10634 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public TouchResponse freeze()
/*       */     {
/* 10677 */       if (this.cost_ != null) this.cost_.freeze();
/* 10678 */       return this;
/*       */     }
/*       */ 
/*       */     public TouchResponse unfreeze() {
/* 10682 */       if (this.cost_ != null) this.cost_.unfreeze();
/* 10683 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 10687 */       return (this.cost_ != null) && (this.cost_.isFrozen());
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 10690 */       if (this.uninterpreted == null) {
/* 10691 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 10693 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 10638 */       IMMUTABLE_DEFAULT_INSTANCE = new TouchResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.TouchResponse clearCost()
/*       */         {
/* 10646 */           return this;
/*       */         }
/*       */         public DatastorePb.TouchResponse setCost(DatastorePb.Cost x) {
/* 10649 */           ProtocolSupport.unsupportedOperation();
/* 10650 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost getMutableCost() {
/* 10653 */           return (DatastorePb.Cost)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.TouchResponse mergeFrom(DatastorePb.TouchResponse that) {
/* 10657 */           ProtocolSupport.unsupportedOperation();
/* 10658 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 10661 */           ProtocolSupport.unsupportedOperation();
/* 10662 */           return false;
/*       */         }
/*       */         public DatastorePb.TouchResponse freeze() {
/* 10665 */           return this;
/*       */         }
/*       */         public DatastorePb.TouchResponse unfreeze() {
/* 10668 */           ProtocolSupport.unsupportedOperation();
/* 10669 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 10672 */           return true;
/*       */         }
/*       */       };
/* 10698 */       text = new String[2];
/*       */ 
/* 10700 */       text[0] = "ErrorCode";
/* 10701 */       text[1] = "cost";
/*       */ 
/* 10704 */       types = new int[2];
/*       */ 
/* 10706 */       Arrays.fill(types, 6);
/* 10707 */       types[0] = 0;
/* 10708 */       types[1] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 10569 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.TouchResponse.class, "Z'apphosting/datastore/datastore_v3.proto\n%apphosting_datastore_v3.TouchResponse\023\032\004cost \001(\0020\0138\001J\034apphosting_datastore_v3.Cost\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("cost", "cost", 1, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Cost.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class TouchRequest extends ProtocolMessage<TouchRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  9976 */     private List<OnestoreEntity.Reference> key_ = null;
/*  9977 */     private List<OnestoreEntity.CompositeIndex> composite_index_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     public static final TouchRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kkey = 1;
/*       */     public static final int kcomposite_index = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int keySize()
/*       */     {
/*  9982 */       return this.key_ != null ? this.key_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.Reference getKey(int i) {
/*  9985 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.key_ != null ? this.key_.size() : 0)); } else throw new AssertionError();
/*  9986 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public TouchRequest clearKey() {
/*  9989 */       if (this.key_ != null) this.key_.clear();
/*  9990 */       return this;
/*       */     }
/*       */     public OnestoreEntity.Reference getMutableKey(int i) {
/*  9993 */       assert ((i >= 0) && (this.key_ != null) && (i < this.key_.size()));
/*  9994 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public OnestoreEntity.Reference addKey() {
/*  9997 */       OnestoreEntity.Reference v = new OnestoreEntity.Reference();
/*  9998 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  9999 */       this.key_.add(v);
/* 10000 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/* 10003 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10004 */       this.key_.add(v);
/* 10005 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/* 10008 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10009 */       this.key_.add(i, v);
/* 10010 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference removeKey(int i) {
/* 10013 */       return (OnestoreEntity.Reference)this.key_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.Reference> keyIterator() {
/* 10016 */       if (this.key_ == null) {
/* 10017 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 10019 */       return this.key_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> keys() {
/* 10022 */       return ProtocolSupport.unmodifiableList(this.key_);
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> mutableKeys() {
/* 10025 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/* 10026 */       return this.key_;
/*       */     }
/*       */ 
/*       */     public final int compositeIndexSize()
/*       */     {
/* 10031 */       return this.composite_index_ != null ? this.composite_index_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.CompositeIndex getCompositeIndex(int i) {
/* 10034 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.composite_index_ != null ? this.composite_index_.size() : 0)); } else throw new AssertionError();
/* 10035 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*       */     }
/*       */     public TouchRequest clearCompositeIndex() {
/* 10038 */       if (this.composite_index_ != null) this.composite_index_.clear();
/* 10039 */       return this;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex getMutableCompositeIndex(int i) {
/* 10042 */       assert ((i >= 0) && (this.composite_index_ != null) && (i < this.composite_index_.size()));
/* 10043 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addCompositeIndex() {
/* 10046 */       OnestoreEntity.CompositeIndex v = new OnestoreEntity.CompositeIndex();
/* 10047 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/* 10048 */       this.composite_index_.add(v);
/* 10049 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addCompositeIndex(OnestoreEntity.CompositeIndex v) {
/* 10052 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/* 10053 */       this.composite_index_.add(v);
/* 10054 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex insertCompositeIndex(int i, OnestoreEntity.CompositeIndex v) {
/* 10057 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/* 10058 */       this.composite_index_.add(i, v);
/* 10059 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex removeCompositeIndex(int i) {
/* 10062 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.CompositeIndex> compositeIndexIterator() {
/* 10065 */       if (this.composite_index_ == null) {
/* 10066 */         return ProtocolSupport.emptyIterator();
/*       */       }
/* 10068 */       return this.composite_index_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> compositeIndexs() {
/* 10071 */       return ProtocolSupport.unmodifiableList(this.composite_index_);
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> mutableCompositeIndexs() {
/* 10074 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/* 10075 */       return this.composite_index_;
/*       */     }
/*       */ 
/*       */     public TouchRequest mergeFrom(TouchRequest that)
/*       */     {
/* 10082 */       assert (that != this);
/*       */ 
/* 10084 */       if (that.key_ != null) {
/* 10085 */         for (OnestoreEntity.Reference v : that.key_) {
/* 10086 */           addKey().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 10090 */       if (that.composite_index_ != null) {
/* 10091 */         for (OnestoreEntity.CompositeIndex v : that.composite_index_) {
/* 10092 */           addCompositeIndex().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/* 10096 */       if (that.uninterpreted != null) {
/* 10097 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/* 10099 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(TouchRequest that) {
/* 10103 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(TouchRequest that) {
/* 10107 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(TouchRequest that, boolean ignoreUninterpreted) {
/* 10111 */       if (that == null) return false;
/* 10112 */       if (that == this) return true;
/* 10115 */       int n;
/* 10115 */       if ((n = this.key_ != null ? this.key_.size() : 0) != (that.key_ != null ? that.key_.size() : 0)) return false;
/* 10116 */       for (int i = 0; i < n; i++) {
/* 10117 */         if (!((OnestoreEntity.Reference)this.key_.get(i)).equals((OnestoreEntity.Reference)that.key_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 10120 */       if ((n = this.composite_index_ != null ? this.composite_index_.size() : 0) != (that.composite_index_ != null ? that.composite_index_.size() : 0)) return false;
/* 10121 */       for (int i = 0; i < n; i++) {
/* 10122 */         if (!((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).equals((OnestoreEntity.CompositeIndex)that.composite_index_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/* 10125 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/* 10130 */       return ((that instanceof TouchRequest)) && (equals((TouchRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/* 10134 */       int hash = 639207132;
/*       */ 
/* 10136 */       hash *= 31;
/* 10137 */       int i = 0; for (int n = this.key_ != null ? this.key_.size() : 0; i < n; i++) {
/* 10138 */         hash = hash * 31 + ((OnestoreEntity.Reference)this.key_.get(i)).hashCode();
/*       */       }
/*       */ 
/* 10141 */       hash *= 31;
/* 10142 */       int i = 0; for (int n = this.composite_index_ != null ? this.composite_index_.size() : 0; i < n; i++) {
/* 10143 */         hash = hash * 31 + ((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).hashCode();
/*       */       }
/* 10145 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/* 10146 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/* 10148 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/* 10153 */       if (this.key_ != null) {
/* 10154 */         for (OnestoreEntity.Reference v : this.key_) {
/* 10155 */           if (!v.isInitialized()) {
/* 10156 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/* 10161 */       if (this.composite_index_ != null) {
/* 10162 */         for (OnestoreEntity.CompositeIndex v : this.composite_index_) {
/* 10163 */           if (!v.isInitialized()) {
/* 10164 */             return false;
/*       */           }
/*       */         }
/*       */       }
/* 10168 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/* 10172 */       int n = 0;
/*       */       int m;
/* 10175 */       n += (m = this.key_ != null ? this.key_.size() : 0);
/* 10176 */       for (int i = 0; i < m; i++) {
/* 10177 */         n += Protocol.stringSize(((OnestoreEntity.Reference)this.key_.get(i)).encodingSize());
/*       */       }
/*       */ 
/* 10180 */       n += (m = this.composite_index_ != null ? this.composite_index_.size() : 0);
/* 10181 */       for (int i = 0; i < m; i++) {
/* 10182 */         n += Protocol.stringSize(((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).encodingSize());
/*       */       }
/*       */ 
/* 10185 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/* 10190 */       int n = 0;
/*       */       int m;
/* 10193 */       n += 6 * (m = this.key_ != null ? this.key_.size() : 0);
/* 10194 */       for (int i = 0; i < m; i++) {
/* 10195 */         n += ((OnestoreEntity.Reference)this.key_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/* 10198 */       n += 6 * (m = this.composite_index_ != null ? this.composite_index_.size() : 0);
/* 10199 */       for (int i = 0; i < m; i++) {
/* 10200 */         n += ((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/* 10203 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/* 10208 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/* 10212 */       if (this.key_ != null) this.key_.clear();
/* 10213 */       if (this.composite_index_ != null) this.composite_index_.clear();
/* 10214 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public TouchRequest newInstance() {
/* 10218 */       return new TouchRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/* 10222 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/* 10249 */       int i = 0; for (int m = this.key_ != null ? this.key_.size() : 0; i < m; i++) {
/* 10250 */         OnestoreEntity.Reference v = (OnestoreEntity.Reference)this.key_.get(i);
/* 10251 */         sink.putByte(10);
/* 10252 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 10255 */       int i = 0; for (int m = this.composite_index_ != null ? this.composite_index_.size() : 0; i < m; i++) {
/* 10256 */         OnestoreEntity.CompositeIndex v = (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/* 10257 */         sink.putByte(18);
/* 10258 */         sink.putForeign(v);
/*       */       }
/*       */ 
/* 10261 */       if (this.uninterpreted != null)
/* 10262 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/* 10267 */       boolean result = true;
/*       */ 
/* 10269 */       while (source.hasRemaining()) {
/* 10270 */         int tt = source.getVarInt();
/* 10271 */         switch (tt)
/*       */         {
/*       */         case 0:
/* 10275 */           result = false;
/* 10276 */           break;
/*       */         case 10:
/* 10279 */           source.push(source.getVarInt());
/* 10280 */           if (!addKey().merge(source)) { result = false; break label138; }
/* 10281 */           source.pop();
/* 10282 */           break;
/*       */         case 18:
/* 10285 */           source.push(source.getVarInt());
/* 10286 */           if (!addCompositeIndex().merge(source)) { result = false; break label138; }
/* 10287 */           source.pop();
/* 10288 */           break;
/*       */         default:
/* 10290 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/* 10295 */       label138: return result;
/*       */     }
/*       */ 
/*       */     public TouchRequest getDefaultInstanceForType()
/*       */     {
/* 10300 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final TouchRequest getDefaultInstance() {
/* 10304 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public TouchRequest freeze()
/*       */     {
/* 10375 */       this.key_ = ProtocolSupport.freezeMessages(this.key_);
/* 10376 */       this.composite_index_ = ProtocolSupport.freezeMessages(this.composite_index_);
/* 10377 */       return this;
/*       */     }
/*       */ 
/*       */     public TouchRequest unfreeze() {
/* 10381 */       this.key_ = ProtocolSupport.unfreezeMessages(this.key_);
/* 10382 */       this.composite_index_ = ProtocolSupport.unfreezeMessages(this.composite_index_);
/* 10383 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/* 10387 */       return (ProtocolSupport.isFrozenMessages(this.key_)) || (ProtocolSupport.isFrozenMessages(this.composite_index_));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/* 10391 */       if (this.uninterpreted == null) {
/* 10392 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/* 10394 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/* 10308 */       IMMUTABLE_DEFAULT_INSTANCE = new TouchRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.TouchRequest clearKey()
/*       */         {
/* 10316 */           return this;
/*       */         }
/*       */         public OnestoreEntity.Reference getMutableKey(int i) {
/* 10319 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey() {
/* 10322 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/* 10325 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/* 10328 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference removeKey(int i) {
/* 10331 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.TouchRequest clearCompositeIndex()
/*       */         {
/* 10336 */           return this;
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex getMutableCompositeIndex(int i) {
/* 10339 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addCompositeIndex() {
/* 10342 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addCompositeIndex(OnestoreEntity.CompositeIndex v) {
/* 10345 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex insertCompositeIndex(int i, OnestoreEntity.CompositeIndex v) {
/* 10348 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex removeCompositeIndex(int i) {
/* 10351 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.TouchRequest mergeFrom(DatastorePb.TouchRequest that) {
/* 10355 */           ProtocolSupport.unsupportedOperation();
/* 10356 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/* 10359 */           ProtocolSupport.unsupportedOperation();
/* 10360 */           return false;
/*       */         }
/*       */         public DatastorePb.TouchRequest freeze() {
/* 10363 */           return this;
/*       */         }
/*       */         public DatastorePb.TouchRequest unfreeze() {
/* 10366 */           ProtocolSupport.unsupportedOperation();
/* 10367 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/* 10370 */           return true;
/*       */         }
/*       */       };
/* 10400 */       text = new String[3];
/*       */ 
/* 10402 */       text[0] = "ErrorCode";
/* 10403 */       text[1] = "key";
/* 10404 */       text[2] = "composite_index";
/*       */ 
/* 10407 */       types = new int[3];
/*       */ 
/* 10409 */       Arrays.fill(types, 6);
/* 10410 */       types[0] = 0;
/* 10411 */       types[1] = 2;
/* 10412 */       types[2] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/* 10226 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.TouchRequest.class, "Z'apphosting/datastore/datastore_v3.proto\n$apphosting_datastore_v3.TouchRequest\023\032\003key \001(\0020\0138\003J\035storage_onestore_v3.Reference\024\023\032\017composite_index \002(\0020\0138\003J\"storage_onestore_v3.CompositeIndex\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("key", "key", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Reference.class), new ProtocolType.FieldType("composite_index", "composite_index", 2, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.CompositeIndex.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class PutResponse extends ProtocolMessage<PutResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  9549 */     private List<OnestoreEntity.Reference> key_ = null;
/*  9550 */     private DatastorePb.Cost cost_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final PutResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kkey = 1;
/*       */     public static final int kcost = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int keySize()
/*       */     {
/*  9556 */       return this.key_ != null ? this.key_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.Reference getKey(int i) {
/*  9559 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.key_ != null ? this.key_.size() : 0)); } else throw new AssertionError();
/*  9560 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public PutResponse clearKey() {
/*  9563 */       if (this.key_ != null) this.key_.clear();
/*  9564 */       return this;
/*       */     }
/*       */     public OnestoreEntity.Reference getMutableKey(int i) {
/*  9567 */       assert ((i >= 0) && (this.key_ != null) && (i < this.key_.size()));
/*  9568 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public OnestoreEntity.Reference addKey() {
/*  9571 */       OnestoreEntity.Reference v = new OnestoreEntity.Reference();
/*  9572 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  9573 */       this.key_.add(v);
/*  9574 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/*  9577 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  9578 */       this.key_.add(v);
/*  9579 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/*  9582 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  9583 */       this.key_.add(i, v);
/*  9584 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference removeKey(int i) {
/*  9587 */       return (OnestoreEntity.Reference)this.key_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.Reference> keyIterator() {
/*  9590 */       if (this.key_ == null) {
/*  9591 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  9593 */       return this.key_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> keys() {
/*  9596 */       return ProtocolSupport.unmodifiableList(this.key_);
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> mutableKeys() {
/*  9599 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  9600 */       return this.key_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.Cost getCost()
/*       */     {
/*  9605 */       if (this.cost_ == null) {
/*  9606 */         return DatastorePb.Cost.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  9608 */       return this.cost_;
/*       */     }
/*       */     public final boolean hasCost() {
/*  9611 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public PutResponse clearCost() {
/*  9614 */       this.optional_0_ &= -2;
/*  9615 */       if (this.cost_ != null) this.cost_.clear();
/*  9616 */       return this;
/*       */     }
/*       */     public PutResponse setCost(DatastorePb.Cost x) {
/*  9619 */       if (x == null) throw new NullPointerException();
/*  9620 */       this.optional_0_ |= 1;
/*  9621 */       this.cost_ = x;
/*  9622 */       return this;
/*       */     }
/*       */     public DatastorePb.Cost getMutableCost() {
/*  9625 */       this.optional_0_ |= 1;
/*  9626 */       if (this.cost_ == null) this.cost_ = new DatastorePb.Cost();
/*  9627 */       return this.cost_;
/*       */     }
/*       */ 
/*       */     public PutResponse mergeFrom(PutResponse that)
/*       */     {
/*  9634 */       assert (that != this);
/*  9635 */       int this_t0 = this.optional_0_;
/*  9636 */       int that_t0 = that.optional_0_;
/*       */ 
/*  9638 */       if (that.key_ != null) {
/*  9639 */         for (OnestoreEntity.Reference v : that.key_) {
/*  9640 */           addKey().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  9644 */       if ((that_t0 & 0x1) != 0) {
/*  9645 */         this_t0 |= 1;
/*  9646 */         DatastorePb.Cost v = this.cost_;
/*  9647 */         if (v == null) this.cost_ = (v = new DatastorePb.Cost());
/*  9648 */         v.mergeFrom(that.cost_);
/*       */       }
/*       */ 
/*  9651 */       if (that.uninterpreted != null) {
/*  9652 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  9654 */       this.optional_0_ = this_t0;
/*  9655 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(PutResponse that) {
/*  9659 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(PutResponse that) {
/*  9663 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(PutResponse that, boolean ignoreUninterpreted) {
/*  9667 */       if (that == null) return false;
/*  9668 */       if (that == this) return true;
/*  9669 */       int this_t0 = this.optional_0_;
/*  9670 */       int that_t0 = that.optional_0_;
/*  9671 */       if (this_t0 != that_t0) return false;
/*  9674 */       int n;
/*  9674 */       if ((n = this.key_ != null ? this.key_.size() : 0) != (that.key_ != null ? that.key_.size() : 0)) return false;
/*  9675 */       for (int i = 0; i < n; i++) {
/*  9676 */         if (!((OnestoreEntity.Reference)this.key_.get(i)).equals((OnestoreEntity.Reference)that.key_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  9679 */       if (((this_t0 & 0x1) != 0) && 
/*  9680 */         (!this.cost_.equals(that.cost_, ignoreUninterpreted))) return false;
/*       */ 
/*  9683 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  9688 */       return ((that instanceof PutResponse)) && (equals((PutResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  9692 */       int hash = -1158486768;
/*       */ 
/*  9694 */       hash *= 31;
/*  9695 */       int i = 0; for (int n = this.key_ != null ? this.key_.size() : 0; i < n; i++) {
/*  9696 */         hash = hash * 31 + ((OnestoreEntity.Reference)this.key_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  9699 */       int this_t0 = this.optional_0_;
/*  9700 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.cost_.hashCode() : -113);
/*  9701 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  9702 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  9704 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/*  9709 */       if (this.key_ != null) {
/*  9710 */         for (OnestoreEntity.Reference v : this.key_) {
/*  9711 */           if (!v.isInitialized()) {
/*  9712 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*  9717 */       int this_t0 = this.optional_0_;
/*       */ 
/*  9720 */       return ((this_t0 & 0x1) == 0) || 
/*  9719 */         (this.cost_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*  9727 */       int n = 0;
/*       */       int m;
/*  9730 */       n += (m = this.key_ != null ? this.key_.size() : 0);
/*  9731 */       for (int i = 0; i < m; i++) {
/*  9732 */         n += Protocol.stringSize(((OnestoreEntity.Reference)this.key_.get(i)).encodingSize());
/*       */       }
/*  9734 */       int this_t0 = this.optional_0_;
/*  9735 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/*  9737 */         n += 1 + Protocol.stringSize(this.cost_.encodingSize());
/*       */       }
/*       */ 
/*  9740 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  9745 */       int n = 0;
/*       */       int m;
/*  9748 */       n += 6 * (m = this.key_ != null ? this.key_.size() : 0);
/*  9749 */       for (int i = 0; i < m; i++) {
/*  9750 */         n += ((OnestoreEntity.Reference)this.key_.get(i)).maxEncodingSize();
/*       */       }
/*  9752 */       int this_t0 = this.optional_0_;
/*  9753 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/*  9755 */         n += 6 + this.cost_.maxEncodingSize();
/*       */       }
/*       */ 
/*  9758 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  9763 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  9767 */       this.optional_0_ = 0;
/*  9768 */       if (this.key_ != null) this.key_.clear();
/*  9769 */       if (this.cost_ != null) this.cost_.clear();
/*  9770 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public PutResponse newInstance() {
/*  9774 */       return new PutResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  9778 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  9804 */       int i = 0; for (int m = this.key_ != null ? this.key_.size() : 0; i < m; i++) {
/*  9805 */         OnestoreEntity.Reference v = (OnestoreEntity.Reference)this.key_.get(i);
/*  9806 */         sink.putByte(10);
/*  9807 */         sink.putForeign(v);
/*       */       }
/*       */ 
/*  9810 */       int this_t0 = this.optional_0_;
/*  9811 */       if ((this_t0 & 0x1) != 0) {
/*  9812 */         sink.putByte(18);
/*  9813 */         sink.putForeign(this.cost_);
/*       */       }
/*       */ 
/*  9816 */       if (this.uninterpreted != null)
/*  9817 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  9822 */       boolean result = true;
/*  9823 */       int this_t0 = this.optional_0_;
/*       */ 
/*  9825 */       while (source.hasRemaining()) {
/*  9826 */         int tt = source.getVarInt();
/*  9827 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  9831 */           result = false;
/*  9832 */           break;
/*       */         case 10:
/*  9835 */           source.push(source.getVarInt());
/*  9836 */           if (!addKey().merge(source)) { result = false; break label175; }
/*  9837 */           source.pop();
/*  9838 */           break;
/*       */         case 18:
/*  9841 */           source.push(source.getVarInt());
/*  9842 */           DatastorePb.Cost v2 = this.cost_;
/*  9843 */           if (v2 == null) this.cost_ = (v2 = new DatastorePb.Cost());
/*  9844 */           if (!v2.merge(source)) { result = false; break label175; }
/*  9845 */           source.pop();
/*  9846 */           this_t0 |= 1;
/*  9847 */           break;
/*       */         default:
/*  9849 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  9854 */       label175: this.optional_0_ = this_t0;
/*  9855 */       return result;
/*       */     }
/*       */ 
/*       */     public PutResponse getDefaultInstanceForType()
/*       */     {
/*  9860 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final PutResponse getDefaultInstance() {
/*  9864 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public PutResponse freeze()
/*       */     {
/*  9927 */       this.key_ = ProtocolSupport.freezeMessages(this.key_);
/*  9928 */       if (this.cost_ != null) this.cost_.freeze();
/*  9929 */       return this;
/*       */     }
/*       */ 
/*       */     public PutResponse unfreeze() {
/*  9933 */       this.key_ = ProtocolSupport.unfreezeMessages(this.key_);
/*  9934 */       if (this.cost_ != null) this.cost_.unfreeze();
/*  9935 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  9939 */       return (ProtocolSupport.isFrozenMessages(this.key_)) || ((this.cost_ != null) && (this.cost_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*  9943 */       if (this.uninterpreted == null) {
/*  9944 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  9946 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  9868 */       IMMUTABLE_DEFAULT_INSTANCE = new PutResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.PutResponse clearKey()
/*       */         {
/*  9876 */           return this;
/*       */         }
/*       */         public OnestoreEntity.Reference getMutableKey(int i) {
/*  9879 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey() {
/*  9882 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/*  9885 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/*  9888 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference removeKey(int i) {
/*  9891 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.PutResponse clearCost()
/*       */         {
/*  9896 */           return this;
/*       */         }
/*       */         public DatastorePb.PutResponse setCost(DatastorePb.Cost x) {
/*  9899 */           ProtocolSupport.unsupportedOperation();
/*  9900 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost getMutableCost() {
/*  9903 */           return (DatastorePb.Cost)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.PutResponse mergeFrom(DatastorePb.PutResponse that) {
/*  9907 */           ProtocolSupport.unsupportedOperation();
/*  9908 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  9911 */           ProtocolSupport.unsupportedOperation();
/*  9912 */           return false;
/*       */         }
/*       */         public DatastorePb.PutResponse freeze() {
/*  9915 */           return this;
/*       */         }
/*       */         public DatastorePb.PutResponse unfreeze() {
/*  9918 */           ProtocolSupport.unsupportedOperation();
/*  9919 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  9922 */           return true;
/*       */         }
/*       */       };
/*  9952 */       text = new String[3];
/*       */ 
/*  9954 */       text[0] = "ErrorCode";
/*  9955 */       text[1] = "key";
/*  9956 */       text[2] = "cost";
/*       */ 
/*  9959 */       types = new int[3];
/*       */ 
/*  9961 */       Arrays.fill(types, 6);
/*  9962 */       types[0] = 0;
/*  9963 */       types[1] = 2;
/*  9964 */       types[2] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  9782 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.PutResponse.class, "Z'apphosting/datastore/datastore_v3.proto\n#apphosting_datastore_v3.PutResponse\023\032\003key \001(\0020\0138\003J\035storage_onestore_v3.Reference\024\023\032\004cost \002(\0020\0138\001J\034apphosting_datastore_v3.Cost\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("key", "key", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Reference.class), new ProtocolType.FieldType("cost", "cost", 2, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Cost.class) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class PutRequest extends ProtocolMessage<PutRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  8927 */     private List<OnestoreEntity.EntityProto> entity_ = null;
/*  8928 */     private DatastorePb.Transaction transaction_ = null;
/*  8929 */     private List<OnestoreEntity.CompositeIndex> composite_index_ = null;
/*  8930 */     private boolean trusted_ = false;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final PutRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kentity = 1;
/*       */     public static final int ktransaction = 2;
/*       */     public static final int kcomposite_index = 3;
/*       */     public static final int ktrusted = 4;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int entitySize()
/*       */     {
/*  8936 */       return this.entity_ != null ? this.entity_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.EntityProto getEntity(int i) {
/*  8939 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.entity_ != null ? this.entity_.size() : 0)); } else throw new AssertionError();
/*  8940 */       return (OnestoreEntity.EntityProto)this.entity_.get(i);
/*       */     }
/*       */     public PutRequest clearEntity() {
/*  8943 */       if (this.entity_ != null) this.entity_.clear();
/*  8944 */       return this;
/*       */     }
/*       */     public OnestoreEntity.EntityProto getMutableEntity(int i) {
/*  8947 */       assert ((i >= 0) && (this.entity_ != null) && (i < this.entity_.size()));
/*  8948 */       return (OnestoreEntity.EntityProto)this.entity_.get(i);
/*       */     }
/*       */     public OnestoreEntity.EntityProto addEntity() {
/*  8951 */       OnestoreEntity.EntityProto v = new OnestoreEntity.EntityProto();
/*  8952 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8953 */       this.entity_.add(v);
/*  8954 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto addEntity(OnestoreEntity.EntityProto v) {
/*  8957 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8958 */       this.entity_.add(v);
/*  8959 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto insertEntity(int i, OnestoreEntity.EntityProto v) {
/*  8962 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8963 */       this.entity_.add(i, v);
/*  8964 */       return v;
/*       */     }
/*       */     public OnestoreEntity.EntityProto removeEntity(int i) {
/*  8967 */       return (OnestoreEntity.EntityProto)this.entity_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.EntityProto> entityIterator() {
/*  8970 */       if (this.entity_ == null) {
/*  8971 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  8973 */       return this.entity_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.EntityProto> entitys() {
/*  8976 */       return ProtocolSupport.unmodifiableList(this.entity_);
/*       */     }
/*       */     public final List<OnestoreEntity.EntityProto> mutableEntitys() {
/*  8979 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8980 */       return this.entity_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.Transaction getTransaction()
/*       */     {
/*  8985 */       if (this.transaction_ == null) {
/*  8986 */         return DatastorePb.Transaction.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  8988 */       return this.transaction_;
/*       */     }
/*       */     public final boolean hasTransaction() {
/*  8991 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public PutRequest clearTransaction() {
/*  8994 */       this.optional_0_ &= -2;
/*  8995 */       if (this.transaction_ != null) this.transaction_.clear();
/*  8996 */       return this;
/*       */     }
/*       */     public PutRequest setTransaction(DatastorePb.Transaction x) {
/*  8999 */       if (x == null) throw new NullPointerException();
/*  9000 */       this.optional_0_ |= 1;
/*  9001 */       this.transaction_ = x;
/*  9002 */       return this;
/*       */     }
/*       */     public DatastorePb.Transaction getMutableTransaction() {
/*  9005 */       this.optional_0_ |= 1;
/*  9006 */       if (this.transaction_ == null) this.transaction_ = new DatastorePb.Transaction();
/*  9007 */       return this.transaction_;
/*       */     }
/*       */ 
/*       */     public final int compositeIndexSize()
/*       */     {
/*  9012 */       return this.composite_index_ != null ? this.composite_index_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.CompositeIndex getCompositeIndex(int i) {
/*  9015 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.composite_index_ != null ? this.composite_index_.size() : 0)); } else throw new AssertionError();
/*  9016 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*       */     }
/*       */     public PutRequest clearCompositeIndex() {
/*  9019 */       if (this.composite_index_ != null) this.composite_index_.clear();
/*  9020 */       return this;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex getMutableCompositeIndex(int i) {
/*  9023 */       assert ((i >= 0) && (this.composite_index_ != null) && (i < this.composite_index_.size()));
/*  9024 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addCompositeIndex() {
/*  9027 */       OnestoreEntity.CompositeIndex v = new OnestoreEntity.CompositeIndex();
/*  9028 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  9029 */       this.composite_index_.add(v);
/*  9030 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addCompositeIndex(OnestoreEntity.CompositeIndex v) {
/*  9033 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  9034 */       this.composite_index_.add(v);
/*  9035 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex insertCompositeIndex(int i, OnestoreEntity.CompositeIndex v) {
/*  9038 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  9039 */       this.composite_index_.add(i, v);
/*  9040 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex removeCompositeIndex(int i) {
/*  9043 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.CompositeIndex> compositeIndexIterator() {
/*  9046 */       if (this.composite_index_ == null) {
/*  9047 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  9049 */       return this.composite_index_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> compositeIndexs() {
/*  9052 */       return ProtocolSupport.unmodifiableList(this.composite_index_);
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> mutableCompositeIndexs() {
/*  9055 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  9056 */       return this.composite_index_;
/*       */     }
/*       */ 
/*       */     public final boolean isTrusted()
/*       */     {
/*  9061 */       return this.trusted_;
/*       */     }
/*       */     public final boolean hasTrusted() {
/*  9064 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public PutRequest clearTrusted() {
/*  9067 */       this.optional_0_ &= -3;
/*  9068 */       this.trusted_ = false;
/*  9069 */       return this;
/*       */     }
/*       */     public PutRequest setTrusted(boolean x) {
/*  9072 */       this.optional_0_ |= 2;
/*  9073 */       this.trusted_ = x;
/*  9074 */       return this;
/*       */     }
/*       */ 
/*       */     public PutRequest mergeFrom(PutRequest that)
/*       */     {
/*  9081 */       assert (that != this);
/*  9082 */       int this_t0 = this.optional_0_;
/*  9083 */       int that_t0 = that.optional_0_;
/*       */ 
/*  9085 */       if (that.entity_ != null) {
/*  9086 */         for (OnestoreEntity.EntityProto v : that.entity_) {
/*  9087 */           addEntity().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  9091 */       if ((that_t0 & 0x1) != 0) {
/*  9092 */         this_t0 |= 1;
/*  9093 */         DatastorePb.Transaction v = this.transaction_;
/*  9094 */         if (v == null) this.transaction_ = (v = new DatastorePb.Transaction());
/*  9095 */         v.mergeFrom(that.transaction_);
/*       */       }
/*       */ 
/*  9098 */       if (that.composite_index_ != null) {
/*  9099 */         for (OnestoreEntity.CompositeIndex v : that.composite_index_) {
/*  9100 */           addCompositeIndex().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  9104 */       if ((that_t0 & 0x2) != 0) {
/*  9105 */         this_t0 |= 2;
/*  9106 */         this.trusted_ = that.trusted_;
/*       */       }
/*       */ 
/*  9109 */       if (that.uninterpreted != null) {
/*  9110 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  9112 */       this.optional_0_ = this_t0;
/*  9113 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(PutRequest that) {
/*  9117 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(PutRequest that) {
/*  9121 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(PutRequest that, boolean ignoreUninterpreted) {
/*  9125 */       if (that == null) return false;
/*  9126 */       if (that == this) return true;
/*  9127 */       int this_t0 = this.optional_0_;
/*  9128 */       int that_t0 = that.optional_0_;
/*  9129 */       if (this_t0 != that_t0) return false;
/*  9132 */       int n;
/*  9132 */       if ((n = this.entity_ != null ? this.entity_.size() : 0) != (that.entity_ != null ? that.entity_.size() : 0)) return false;
/*  9133 */       for (int i = 0; i < n; i++) {
/*  9134 */         if (!((OnestoreEntity.EntityProto)this.entity_.get(i)).equals((OnestoreEntity.EntityProto)that.entity_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  9137 */       if (((this_t0 & 0x1) != 0) && 
/*  9138 */         (!this.transaction_.equals(that.transaction_, ignoreUninterpreted))) return false;
/*       */ 
/*  9141 */       if ((n = this.composite_index_ != null ? this.composite_index_.size() : 0) != (that.composite_index_ != null ? that.composite_index_.size() : 0)) return false;
/*  9142 */       for (int i = 0; i < n; i++) {
/*  9143 */         if (!((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).equals((OnestoreEntity.CompositeIndex)that.composite_index_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  9146 */       if (((this_t0 & 0x2) != 0) && 
/*  9147 */         (this.trusted_ != that.trusted_)) return false;
/*       */ 
/*  9150 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  9155 */       return ((that instanceof PutRequest)) && (equals((PutRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  9159 */       int hash = -2089263550;
/*       */ 
/*  9161 */       hash *= 31;
/*  9162 */       int i = 0; for (int n = this.entity_ != null ? this.entity_.size() : 0; i < n; i++) {
/*  9163 */         hash = hash * 31 + ((OnestoreEntity.EntityProto)this.entity_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  9166 */       int this_t0 = this.optional_0_;
/*  9167 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.transaction_.hashCode() : -113);
/*       */ 
/*  9169 */       hash *= 31;
/*  9170 */       int i = 0; for (int n = this.composite_index_ != null ? this.composite_index_.size() : 0; i < n; i++) {
/*  9171 */         hash = hash * 31 + ((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  9174 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? 1237 : this.trusted_ ? 1231 : -113);
/*  9175 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  9176 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  9178 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/*  9183 */       if (this.entity_ != null) {
/*  9184 */         for (OnestoreEntity.EntityProto v : this.entity_) {
/*  9185 */           if (!v.isInitialized()) {
/*  9186 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*  9191 */       int this_t0 = this.optional_0_;
/*  9192 */       if (((this_t0 & 0x1) != 0) && 
/*  9193 */         (!this.transaction_.isInitialized())) {
/*  9194 */         return false;
/*       */       }
/*       */ 
/*  9198 */       if (this.composite_index_ != null) {
/*  9199 */         for (OnestoreEntity.CompositeIndex v : this.composite_index_) {
/*  9200 */           if (!v.isInitialized()) {
/*  9201 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*  9205 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/*  9209 */       int n = 0;
/*       */       int m;
/*  9212 */       n += (m = this.entity_ != null ? this.entity_.size() : 0);
/*  9213 */       for (int i = 0; i < m; i++) {
/*  9214 */         n += Protocol.stringSize(((OnestoreEntity.EntityProto)this.entity_.get(i)).encodingSize());
/*       */       }
/*       */ 
/*  9217 */       n += (m = this.composite_index_ != null ? this.composite_index_.size() : 0);
/*  9218 */       for (int i = 0; i < m; i++) {
/*  9219 */         n += Protocol.stringSize(((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).encodingSize());
/*       */       }
/*  9221 */       int this_t0 = this.optional_0_;
/*  9222 */       if ((this_t0 & 0x3) != 0) {
/*  9223 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/*  9225 */           n += 1 + Protocol.stringSize(this.transaction_.encodingSize());
/*       */         }
/*  9227 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  9229 */           n += 2;
/*       */         }
/*       */       }
/*       */ 
/*  9233 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  9239 */       int n = 2;
/*       */       int m;
/*  9242 */       n += 6 * (m = this.entity_ != null ? this.entity_.size() : 0);
/*  9243 */       for (int i = 0; i < m; i++) {
/*  9244 */         n += ((OnestoreEntity.EntityProto)this.entity_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/*  9247 */       n += 6 * (m = this.composite_index_ != null ? this.composite_index_.size() : 0);
/*  9248 */       for (int i = 0; i < m; i++) {
/*  9249 */         n += ((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).maxEncodingSize();
/*       */       }
/*  9251 */       int this_t0 = this.optional_0_;
/*  9252 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/*  9254 */         n += 6 + this.transaction_.maxEncodingSize();
/*       */       }
/*       */ 
/*  9257 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  9262 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  9266 */       this.optional_0_ = 0;
/*  9267 */       if (this.entity_ != null) this.entity_.clear();
/*  9268 */       if (this.transaction_ != null) this.transaction_.clear();
/*  9269 */       if (this.composite_index_ != null) this.composite_index_.clear();
/*  9270 */       this.trusted_ = false;
/*  9271 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public PutRequest newInstance() {
/*  9275 */       return new PutRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  9279 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  9317 */       int i = 0; for (int m = this.entity_ != null ? this.entity_.size() : 0; i < m; i++) {
/*  9318 */         OnestoreEntity.EntityProto v = (OnestoreEntity.EntityProto)this.entity_.get(i);
/*  9319 */         sink.putByte(10);
/*  9320 */         sink.putForeign(v);
/*       */       }
/*       */ 
/*  9323 */       int this_t0 = this.optional_0_;
/*  9324 */       if ((this_t0 & 0x1) != 0) {
/*  9325 */         sink.putByte(18);
/*  9326 */         sink.putForeign(this.transaction_);
/*       */       }
/*       */ 
/*  9329 */       int i = 0; for (int m = this.composite_index_ != null ? this.composite_index_.size() : 0; i < m; i++) {
/*  9330 */         OnestoreEntity.CompositeIndex v = (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*  9331 */         sink.putByte(26);
/*  9332 */         sink.putForeign(v);
/*       */       }
/*       */ 
/*  9335 */       if ((this_t0 & 0x2) != 0) {
/*  9336 */         sink.putByte(32);
/*  9337 */         sink.putBoolean(this.trusted_);
/*       */       }
/*       */ 
/*  9340 */       if (this.uninterpreted != null)
/*  9341 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  9346 */       boolean result = true;
/*  9347 */       int this_t0 = this.optional_0_;
/*       */ 
/*  9349 */       while (source.hasRemaining()) {
/*  9350 */         int tt = source.getVarInt();
/*  9351 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  9355 */           result = false;
/*  9356 */           break;
/*       */         case 10:
/*  9359 */           source.push(source.getVarInt());
/*  9360 */           if (!addEntity().merge(source)) { result = false; break label239; }
/*  9361 */           source.pop();
/*  9362 */           break;
/*       */         case 18:
/*  9365 */           source.push(source.getVarInt());
/*  9366 */           DatastorePb.Transaction v2 = this.transaction_;
/*  9367 */           if (v2 == null) this.transaction_ = (v2 = new DatastorePb.Transaction());
/*  9368 */           if (!v2.merge(source)) { result = false; break label239; }
/*  9369 */           source.pop();
/*  9370 */           this_t0 |= 1;
/*  9371 */           break;
/*       */         case 26:
/*  9374 */           source.push(source.getVarInt());
/*  9375 */           if (!addCompositeIndex().merge(source)) { result = false; break label239; }
/*  9376 */           source.pop();
/*  9377 */           break;
/*       */         case 32:
/*  9380 */           this.trusted_ = source.getBoolean();
/*  9381 */           this_t0 |= 2;
/*  9382 */           break;
/*       */         default:
/*  9384 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  9389 */       label239: this.optional_0_ = this_t0;
/*  9390 */       return result;
/*       */     }
/*       */ 
/*       */     public PutRequest getDefaultInstanceForType()
/*       */     {
/*  9395 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final PutRequest getDefaultInstance() {
/*  9399 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public PutRequest freeze()
/*       */     {
/*  9491 */       this.entity_ = ProtocolSupport.freezeMessages(this.entity_);
/*  9492 */       if (this.transaction_ != null) this.transaction_.freeze();
/*  9493 */       this.composite_index_ = ProtocolSupport.freezeMessages(this.composite_index_);
/*  9494 */       return this;
/*       */     }
/*       */ 
/*       */     public PutRequest unfreeze() {
/*  9498 */       this.entity_ = ProtocolSupport.unfreezeMessages(this.entity_);
/*  9499 */       if (this.transaction_ != null) this.transaction_.unfreeze();
/*  9500 */       this.composite_index_ = ProtocolSupport.unfreezeMessages(this.composite_index_);
/*  9501 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  9505 */       return (ProtocolSupport.isFrozenMessages(this.entity_)) || ((this.transaction_ != null) && (this.transaction_.isFrozen())) || (ProtocolSupport.isFrozenMessages(this.composite_index_));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/*  9510 */       if (this.uninterpreted == null) {
/*  9511 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  9513 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  9403 */       IMMUTABLE_DEFAULT_INSTANCE = new PutRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.PutRequest clearEntity()
/*       */         {
/*  9411 */           return this;
/*       */         }
/*       */         public OnestoreEntity.EntityProto getMutableEntity(int i) {
/*  9414 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto addEntity() {
/*  9417 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto addEntity(OnestoreEntity.EntityProto v) {
/*  9420 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto insertEntity(int i, OnestoreEntity.EntityProto v) {
/*  9423 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.EntityProto removeEntity(int i) {
/*  9426 */           return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.PutRequest clearTransaction()
/*       */         {
/*  9431 */           return this;
/*       */         }
/*       */         public DatastorePb.PutRequest setTransaction(DatastorePb.Transaction x) {
/*  9434 */           ProtocolSupport.unsupportedOperation();
/*  9435 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction getMutableTransaction() {
/*  9438 */           return (DatastorePb.Transaction)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.PutRequest clearCompositeIndex()
/*       */         {
/*  9443 */           return this;
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex getMutableCompositeIndex(int i) {
/*  9446 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addCompositeIndex() {
/*  9449 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addCompositeIndex(OnestoreEntity.CompositeIndex v) {
/*  9452 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex insertCompositeIndex(int i, OnestoreEntity.CompositeIndex v) {
/*  9455 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex removeCompositeIndex(int i) {
/*  9458 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.PutRequest clearTrusted()
/*       */         {
/*  9463 */           return this;
/*       */         }
/*       */         public DatastorePb.PutRequest setTrusted(boolean x) {
/*  9466 */           ProtocolSupport.unsupportedOperation();
/*  9467 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.PutRequest mergeFrom(DatastorePb.PutRequest that) {
/*  9471 */           ProtocolSupport.unsupportedOperation();
/*  9472 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  9475 */           ProtocolSupport.unsupportedOperation();
/*  9476 */           return false;
/*       */         }
/*       */         public DatastorePb.PutRequest freeze() {
/*  9479 */           return this;
/*       */         }
/*       */         public DatastorePb.PutRequest unfreeze() {
/*  9482 */           ProtocolSupport.unsupportedOperation();
/*  9483 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  9486 */           return true;
/*       */         }
/*       */       };
/*  9521 */       text = new String[5];
/*       */ 
/*  9523 */       text[0] = "ErrorCode";
/*  9524 */       text[1] = "entity";
/*  9525 */       text[2] = "transaction";
/*  9526 */       text[3] = "composite_index";
/*  9527 */       text[4] = "trusted";
/*       */ 
/*  9530 */       types = new int[5];
/*       */ 
/*  9532 */       Arrays.fill(types, 6);
/*  9533 */       types[0] = 0;
/*  9534 */       types[1] = 2;
/*  9535 */       types[2] = 2;
/*  9536 */       types[3] = 2;
/*  9537 */       types[4] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  9283 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.PutRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("entity", "entity", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.EntityProto.class), new ProtocolType.FieldType("transaction", "transaction", 2, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Transaction.class), new ProtocolType.FieldType("composite_index", "composite_index", 3, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.CompositeIndex.class), new ProtocolType.FieldType("trusted", "trusted", 4, 1, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class GetResponse extends ProtocolMessage<GetResponse>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  8605 */     private List<Entity> entity_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     public static final GetResponse IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kEntityGroup = 1;
/*       */     public static final int kEntityentity = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int entitySize()
/*       */     {
/*  8610 */       return this.entity_ != null ? this.entity_.size() : 0;
/*       */     }
/*       */     public final Entity getEntity(int i) {
/*  8613 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.entity_ != null ? this.entity_.size() : 0)); } else throw new AssertionError();
/*  8614 */       return (Entity)this.entity_.get(i);
/*       */     }
/*       */     public GetResponse clearEntity() {
/*  8617 */       if (this.entity_ != null) this.entity_.clear();
/*  8618 */       return this;
/*       */     }
/*       */     public Entity getMutableEntity(int i) {
/*  8621 */       assert ((i >= 0) && (this.entity_ != null) && (i < this.entity_.size()));
/*  8622 */       return (Entity)this.entity_.get(i);
/*       */     }
/*       */     public Entity addEntity() {
/*  8625 */       Entity v = new Entity();
/*  8626 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8627 */       this.entity_.add(v);
/*  8628 */       return v;
/*       */     }
/*       */     public Entity addEntity(Entity v) {
/*  8631 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8632 */       this.entity_.add(v);
/*  8633 */       return v;
/*       */     }
/*       */     public Entity insertEntity(int i, Entity v) {
/*  8636 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8637 */       this.entity_.add(i, v);
/*  8638 */       return v;
/*       */     }
/*       */     public Entity removeEntity(int i) {
/*  8641 */       return (Entity)this.entity_.remove(i);
/*       */     }
/*       */     public final Iterator<Entity> entityIterator() {
/*  8644 */       if (this.entity_ == null) {
/*  8645 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  8647 */       return this.entity_.iterator();
/*       */     }
/*       */     public final List<Entity> entitys() {
/*  8650 */       return ProtocolSupport.unmodifiableList(this.entity_);
/*       */     }
/*       */     public final List<Entity> mutableEntitys() {
/*  8653 */       if (this.entity_ == null) this.entity_ = new ArrayList(4);
/*  8654 */       return this.entity_;
/*       */     }
/*       */ 
/*       */     public GetResponse mergeFrom(GetResponse that)
/*       */     {
/*  8661 */       assert (that != this);
/*       */ 
/*  8663 */       if (that.entity_ != null) {
/*  8664 */         for (Entity v : that.entity_) {
/*  8665 */           addEntity().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  8669 */       if (that.uninterpreted != null) {
/*  8670 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  8672 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(GetResponse that) {
/*  8676 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetResponse that) {
/*  8680 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetResponse that, boolean ignoreUninterpreted) {
/*  8684 */       if (that == null) return false;
/*  8685 */       if (that == this) return true;
/*  8688 */       int n;
/*  8688 */       if ((n = this.entity_ != null ? this.entity_.size() : 0) != (that.entity_ != null ? that.entity_.size() : 0)) return false;
/*  8689 */       for (int i = 0; i < n; i++) {
/*  8690 */         if (!((Entity)this.entity_.get(i)).equals((Entity)that.entity_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  8693 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  8698 */       return ((that instanceof GetResponse)) && (equals((GetResponse)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  8702 */       int hash = -1978281171;
/*       */ 
/*  8704 */       hash *= 31;
/*  8705 */       int i = 0; for (int n = this.entity_ != null ? this.entity_.size() : 0; i < n; i++) {
/*  8706 */         hash = hash * 31 + ((Entity)this.entity_.get(i)).hashCode();
/*       */       }
/*  8708 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  8709 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  8711 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/*  8716 */       if (this.entity_ != null) {
/*  8717 */         for (Entity v : this.entity_) {
/*  8718 */           if (!v.isInitialized()) {
/*  8719 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*  8723 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/*  8727 */       int n = 0;
/*       */       int m;
/*  8730 */       n += (m = this.entity_ != null ? this.entity_.size() : 0);
/*  8731 */       for (int i = 0; i < m; i++) {
/*  8732 */         n += ((Entity)this.entity_.get(i)).encodingSize();
/*       */       }
/*       */ 
/*  8735 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  8740 */       int n = 0;
/*       */       int m;
/*  8743 */       n += (m = this.entity_ != null ? this.entity_.size() : 0);
/*  8744 */       for (int i = 0; i < m; i++) {
/*  8745 */         n += ((Entity)this.entity_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/*  8748 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  8753 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  8757 */       if (this.entity_ != null) this.entity_.clear();
/*  8758 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public GetResponse newInstance() {
/*  8762 */       return new GetResponse();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  8766 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  8789 */       int i = 0; for (int m = this.entity_ != null ? this.entity_.size() : 0; i < m; i++) {
/*  8790 */         Entity v = (Entity)this.entity_.get(i);
/*  8791 */         sink.putByte(11);
/*  8792 */         v.outputTo(sink);
/*       */       }
/*       */ 
/*  8795 */       if (this.uninterpreted != null)
/*  8796 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  8801 */       boolean result = true;
/*       */ 
/*  8803 */       while (source.hasRemaining()) {
/*  8804 */         int tt = source.getVarInt();
/*  8805 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  8809 */           result = false;
/*  8810 */           break;
/*       */         case 11:
/*  8813 */           if (addEntity().merge(source)) break; result = false; break;
/*       */         default:
/*  8816 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  8821 */       return result;
/*       */     }
/*       */ 
/*       */     public GetResponse getDefaultInstanceForType()
/*       */     {
/*  8826 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final GetResponse getDefaultInstance() {
/*  8830 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public GetResponse freeze()
/*       */     {
/*  8881 */       this.entity_ = ProtocolSupport.freezeMessages(this.entity_);
/*  8882 */       return this;
/*       */     }
/*       */ 
/*       */     public GetResponse unfreeze() {
/*  8886 */       this.entity_ = ProtocolSupport.unfreezeMessages(this.entity_);
/*  8887 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  8891 */       return ProtocolSupport.isFrozenMessages(this.entity_);
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*  8894 */       if (this.uninterpreted == null) {
/*  8895 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  8897 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  8834 */       IMMUTABLE_DEFAULT_INSTANCE = new GetResponse()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.GetResponse clearEntity()
/*       */         {
/*  8842 */           return this;
/*       */         }
/*       */         public DatastorePb.GetResponse.Entity getMutableEntity(int i) {
/*  8845 */           return (DatastorePb.GetResponse.Entity)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.GetResponse.Entity addEntity() {
/*  8848 */           return (DatastorePb.GetResponse.Entity)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.GetResponse.Entity addEntity(DatastorePb.GetResponse.Entity v) {
/*  8851 */           return (DatastorePb.GetResponse.Entity)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.GetResponse.Entity insertEntity(int i, DatastorePb.GetResponse.Entity v) {
/*  8854 */           return (DatastorePb.GetResponse.Entity)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.GetResponse.Entity removeEntity(int i) {
/*  8857 */           return (DatastorePb.GetResponse.Entity)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetResponse mergeFrom(DatastorePb.GetResponse that) {
/*  8861 */           ProtocolSupport.unsupportedOperation();
/*  8862 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  8865 */           ProtocolSupport.unsupportedOperation();
/*  8866 */           return false;
/*       */         }
/*       */         public DatastorePb.GetResponse freeze() {
/*  8869 */           return this;
/*       */         }
/*       */         public DatastorePb.GetResponse unfreeze() {
/*  8872 */           ProtocolSupport.unsupportedOperation();
/*  8873 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  8876 */           return true;
/*       */         }
/*       */       };
/*  8903 */       text = new String[3];
/*       */ 
/*  8905 */       text[0] = "ErrorCode";
/*  8906 */       text[1] = "Entity";
/*  8907 */       text[2] = "entity";
/*       */ 
/*  8910 */       types = new int[3];
/*       */ 
/*  8912 */       Arrays.fill(types, 6);
/*  8913 */       types[0] = 0;
/*  8914 */       types[1] = 3;
/*  8915 */       types[2] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  8770 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.GetResponse.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("Entity", "entity", 1, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, DatastorePb.GetResponse.Entity.class) });
/*       */     }
/*       */ 
/*       */     public static class Entity extends ProtocolMessage<Entity>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*  8332 */       private OnestoreEntity.EntityProto entity_ = null;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final Entity IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final OnestoreEntity.EntityProto getEntity()
/*       */       {
/*  8338 */         if (this.entity_ == null) {
/*  8339 */           return OnestoreEntity.EntityProto.IMMUTABLE_DEFAULT_INSTANCE;
/*       */         }
/*  8341 */         return this.entity_;
/*       */       }
/*       */       public final boolean hasEntity() {
/*  8344 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public Entity clearEntity() {
/*  8347 */         this.optional_0_ &= -2;
/*  8348 */         if (this.entity_ != null) this.entity_.clear();
/*  8349 */         return this;
/*       */       }
/*       */       public Entity setEntity(OnestoreEntity.EntityProto x) {
/*  8352 */         if (x == null) throw new NullPointerException();
/*  8353 */         this.optional_0_ |= 1;
/*  8354 */         this.entity_ = x;
/*  8355 */         return this;
/*       */       }
/*       */       public OnestoreEntity.EntityProto getMutableEntity() {
/*  8358 */         this.optional_0_ |= 1;
/*  8359 */         if (this.entity_ == null) this.entity_ = new OnestoreEntity.EntityProto();
/*  8360 */         return this.entity_;
/*       */       }
/*       */ 
/*       */       public Entity mergeFrom(Entity that)
/*       */       {
/*  8367 */         assert (that != this);
/*  8368 */         int this_t0 = this.optional_0_;
/*  8369 */         int that_t0 = that.optional_0_;
/*       */ 
/*  8371 */         if ((that_t0 & 0x1) != 0) {
/*  8372 */           this_t0 |= 1;
/*  8373 */           OnestoreEntity.EntityProto v = this.entity_;
/*  8374 */           if (v == null) this.entity_ = (v = new OnestoreEntity.EntityProto());
/*  8375 */           v.mergeFrom(that.entity_);
/*       */         }
/*       */ 
/*  8378 */         if (that.uninterpreted != null) {
/*  8379 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*  8381 */         this.optional_0_ = this_t0;
/*  8382 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(Entity that) {
/*  8386 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(Entity that) {
/*  8390 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(Entity that, boolean ignoreUninterpreted) {
/*  8394 */         if (that == null) return false;
/*  8395 */         if (that == this) return true;
/*  8396 */         int this_t0 = this.optional_0_;
/*  8397 */         int that_t0 = that.optional_0_;
/*  8398 */         if (this_t0 != that_t0) return false;
/*       */ 
/*  8400 */         if (((this_t0 & 0x1) != 0) && 
/*  8401 */           (!this.entity_.equals(that.entity_, ignoreUninterpreted))) return false;
/*       */ 
/*  8404 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*  8409 */         return ((that instanceof Entity)) && (equals((Entity)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*  8413 */         int hash = -1979940775;
/*       */ 
/*  8415 */         int this_t0 = this.optional_0_;
/*  8416 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.entity_.hashCode() : -113);
/*  8417 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  8418 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*  8420 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized()
/*       */       {
/*  8425 */         int this_t0 = this.optional_0_;
/*       */ 
/*  8428 */         return ((this_t0 & 0x1) == 0) || 
/*  8427 */           (this.entity_.isInitialized());
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*  8436 */         int n = 1;
/*  8437 */         int this_t0 = this.optional_0_;
/*  8438 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/*  8440 */           n += 1 + Protocol.stringSize(this.entity_.encodingSize());
/*       */         }
/*       */ 
/*  8443 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*  8449 */         int n = 1;
/*  8450 */         int this_t0 = this.optional_0_;
/*  8451 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/*  8453 */           n += 6 + this.entity_.maxEncodingSize();
/*       */         }
/*       */ 
/*  8456 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*  8461 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*  8465 */         this.optional_0_ = 0;
/*  8466 */         if (this.entity_ != null) this.entity_.clear();
/*  8467 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public Entity newInstance() {
/*  8471 */         return new Entity();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*  8475 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*  8488 */         int this_t0 = this.optional_0_;
/*  8489 */         if ((this_t0 & 0x1) != 0) {
/*  8490 */           sink.putByte(18);
/*  8491 */           sink.putForeign(this.entity_);
/*       */         }
/*       */ 
/*  8494 */         if (this.uninterpreted != null) {
/*  8495 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*  8498 */         sink.putByte(12);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*  8502 */         boolean result = true;
/*  8503 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*  8506 */           int tt = source.getVarInt();
/*  8507 */           switch (tt)
/*       */           {
/*       */           case 12:
/*  8510 */             break;
/*       */           case 0:
/*  8514 */             result = false;
/*  8515 */             break;
/*       */           case 18:
/*  8518 */             source.push(source.getVarInt());
/*  8519 */             OnestoreEntity.EntityProto v2 = this.entity_;
/*  8520 */             if (v2 == null) this.entity_ = (v2 = new OnestoreEntity.EntityProto());
/*  8521 */             if (!v2.merge(source)) { result = false; break label137; }
/*  8522 */             source.pop();
/*  8523 */             this_t0 |= 1;
/*  8524 */             break;
/*       */           default:
/*  8526 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*  8531 */         label137: this.optional_0_ = this_t0;
/*  8532 */         return result;
/*       */       }
/*       */ 
/*       */       public Entity getDefaultInstanceForType()
/*       */       {
/*  8537 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final Entity getDefaultInstance() {
/*  8541 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public Entity freeze()
/*       */       {
/*  8584 */         if (this.entity_ != null) this.entity_.freeze();
/*  8585 */         return this;
/*       */       }
/*       */ 
/*       */       public Entity unfreeze() {
/*  8589 */         if (this.entity_ != null) this.entity_.unfreeze();
/*  8590 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean isFrozen() {
/*  8594 */         return (this.entity_ != null) && (this.entity_.isFrozen());
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*  8597 */         if (this.uninterpreted == null) {
/*  8598 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*  8600 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  8545 */         IMMUTABLE_DEFAULT_INSTANCE = new Entity()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.GetResponse.Entity clearEntity()
/*       */           {
/*  8553 */             return this;
/*       */           }
/*       */           public DatastorePb.GetResponse.Entity setEntity(OnestoreEntity.EntityProto x) {
/*  8556 */             ProtocolSupport.unsupportedOperation();
/*  8557 */             return this;
/*       */           }
/*       */           public OnestoreEntity.EntityProto getMutableEntity() {
/*  8560 */             return (OnestoreEntity.EntityProto)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */ 
/*       */           public DatastorePb.GetResponse.Entity mergeFrom(DatastorePb.GetResponse.Entity that) {
/*  8564 */             ProtocolSupport.unsupportedOperation();
/*  8565 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*  8568 */             ProtocolSupport.unsupportedOperation();
/*  8569 */             return false;
/*       */           }
/*       */           public DatastorePb.GetResponse.Entity freeze() {
/*  8572 */             return this;
/*       */           }
/*       */           public DatastorePb.GetResponse.Entity unfreeze() {
/*  8575 */             ProtocolSupport.unsupportedOperation();
/*  8576 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*  8579 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*  8479 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.GetResponse.Entity.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("entity", "entity", 2, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, OnestoreEntity.EntityProto.class) });
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class GetRequest extends ProtocolMessage<GetRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  7778 */     private List<OnestoreEntity.Reference> key_ = null;
/*  7779 */     private DatastorePb.Transaction transaction_ = null;
/*  7780 */     private long failover_ms_ = 0L;
/*  7781 */     private boolean strong_ = false;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final GetRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kkey = 1;
/*       */     public static final int ktransaction = 2;
/*       */     public static final int kfailover_ms = 3;
/*       */     public static final int kstrong = 4;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int keySize()
/*       */     {
/*  7787 */       return this.key_ != null ? this.key_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.Reference getKey(int i) {
/*  7790 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.key_ != null ? this.key_.size() : 0)); } else throw new AssertionError();
/*  7791 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public GetRequest clearKey() {
/*  7794 */       if (this.key_ != null) this.key_.clear();
/*  7795 */       return this;
/*       */     }
/*       */     public OnestoreEntity.Reference getMutableKey(int i) {
/*  7798 */       assert ((i >= 0) && (this.key_ != null) && (i < this.key_.size()));
/*  7799 */       return (OnestoreEntity.Reference)this.key_.get(i);
/*       */     }
/*       */     public OnestoreEntity.Reference addKey() {
/*  7802 */       OnestoreEntity.Reference v = new OnestoreEntity.Reference();
/*  7803 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  7804 */       this.key_.add(v);
/*  7805 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/*  7808 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  7809 */       this.key_.add(v);
/*  7810 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/*  7813 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  7814 */       this.key_.add(i, v);
/*  7815 */       return v;
/*       */     }
/*       */     public OnestoreEntity.Reference removeKey(int i) {
/*  7818 */       return (OnestoreEntity.Reference)this.key_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.Reference> keyIterator() {
/*  7821 */       if (this.key_ == null) {
/*  7822 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  7824 */       return this.key_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> keys() {
/*  7827 */       return ProtocolSupport.unmodifiableList(this.key_);
/*       */     }
/*       */     public final List<OnestoreEntity.Reference> mutableKeys() {
/*  7830 */       if (this.key_ == null) this.key_ = new ArrayList(4);
/*  7831 */       return this.key_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.Transaction getTransaction()
/*       */     {
/*  7836 */       if (this.transaction_ == null) {
/*  7837 */         return DatastorePb.Transaction.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  7839 */       return this.transaction_;
/*       */     }
/*       */     public final boolean hasTransaction() {
/*  7842 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public GetRequest clearTransaction() {
/*  7845 */       this.optional_0_ &= -2;
/*  7846 */       if (this.transaction_ != null) this.transaction_.clear();
/*  7847 */       return this;
/*       */     }
/*       */     public GetRequest setTransaction(DatastorePb.Transaction x) {
/*  7850 */       if (x == null) throw new NullPointerException();
/*  7851 */       this.optional_0_ |= 1;
/*  7852 */       this.transaction_ = x;
/*  7853 */       return this;
/*       */     }
/*       */     public DatastorePb.Transaction getMutableTransaction() {
/*  7856 */       this.optional_0_ |= 1;
/*  7857 */       if (this.transaction_ == null) this.transaction_ = new DatastorePb.Transaction();
/*  7858 */       return this.transaction_;
/*       */     }
/*       */ 
/*       */     public final long getFailoverMs()
/*       */     {
/*  7863 */       return this.failover_ms_;
/*       */     }
/*       */     public final boolean hasFailoverMs() {
/*  7866 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public GetRequest clearFailoverMs() {
/*  7869 */       this.optional_0_ &= -3;
/*  7870 */       this.failover_ms_ = 0L;
/*  7871 */       return this;
/*       */     }
/*       */     public GetRequest setFailoverMs(long x) {
/*  7874 */       this.optional_0_ |= 2;
/*  7875 */       this.failover_ms_ = x;
/*  7876 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isStrong()
/*       */     {
/*  7881 */       return this.strong_;
/*       */     }
/*       */     public final boolean hasStrong() {
/*  7884 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public GetRequest clearStrong() {
/*  7887 */       this.optional_0_ &= -5;
/*  7888 */       this.strong_ = false;
/*  7889 */       return this;
/*       */     }
/*       */     public GetRequest setStrong(boolean x) {
/*  7892 */       this.optional_0_ |= 4;
/*  7893 */       this.strong_ = x;
/*  7894 */       return this;
/*       */     }
/*       */ 
/*       */     public GetRequest mergeFrom(GetRequest that)
/*       */     {
/*  7901 */       assert (that != this);
/*  7902 */       int this_t0 = this.optional_0_;
/*  7903 */       int that_t0 = that.optional_0_;
/*       */ 
/*  7905 */       if (that.key_ != null) {
/*  7906 */         for (OnestoreEntity.Reference v : that.key_) {
/*  7907 */           addKey().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  7911 */       if ((that_t0 & 0x1) != 0) {
/*  7912 */         this_t0 |= 1;
/*  7913 */         DatastorePb.Transaction v = this.transaction_;
/*  7914 */         if (v == null) this.transaction_ = (v = new DatastorePb.Transaction());
/*  7915 */         v.mergeFrom(that.transaction_);
/*       */       }
/*       */ 
/*  7918 */       if ((that_t0 & 0x2) != 0) {
/*  7919 */         this_t0 |= 2;
/*  7920 */         this.failover_ms_ = that.failover_ms_;
/*       */       }
/*       */ 
/*  7923 */       if ((that_t0 & 0x4) != 0) {
/*  7924 */         this_t0 |= 4;
/*  7925 */         this.strong_ = that.strong_;
/*       */       }
/*       */ 
/*  7928 */       if (that.uninterpreted != null) {
/*  7929 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  7931 */       this.optional_0_ = this_t0;
/*  7932 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(GetRequest that) {
/*  7936 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetRequest that) {
/*  7940 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(GetRequest that, boolean ignoreUninterpreted) {
/*  7944 */       if (that == null) return false;
/*  7945 */       if (that == this) return true;
/*  7946 */       int this_t0 = this.optional_0_;
/*  7947 */       int that_t0 = that.optional_0_;
/*  7948 */       if (this_t0 != that_t0) return false;
/*  7951 */       int n;
/*  7951 */       if ((n = this.key_ != null ? this.key_.size() : 0) != (that.key_ != null ? that.key_.size() : 0)) return false;
/*  7952 */       for (int i = 0; i < n; i++) {
/*  7953 */         if (!((OnestoreEntity.Reference)this.key_.get(i)).equals((OnestoreEntity.Reference)that.key_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  7956 */       if (((this_t0 & 0x1) != 0) && 
/*  7957 */         (!this.transaction_.equals(that.transaction_, ignoreUninterpreted))) return false;
/*       */ 
/*  7960 */       if (((this_t0 & 0x2) != 0) && 
/*  7961 */         (this.failover_ms_ != that.failover_ms_)) return false;
/*       */ 
/*  7964 */       if (((this_t0 & 0x4) != 0) && 
/*  7965 */         (this.strong_ != that.strong_)) return false;
/*       */ 
/*  7968 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  7973 */       return ((that instanceof GetRequest)) && (equals((GetRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  7977 */       int hash = 2060036071;
/*       */ 
/*  7979 */       hash *= 31;
/*  7980 */       int i = 0; for (int n = this.key_ != null ? this.key_.size() : 0; i < n; i++) {
/*  7981 */         hash = hash * 31 + ((OnestoreEntity.Reference)this.key_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  7984 */       int this_t0 = this.optional_0_;
/*  7985 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.transaction_.hashCode() : -113);
/*       */ 
/*  7987 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? ProtocolSupport.hashCode(this.failover_ms_) : -113);
/*       */ 
/*  7989 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? 1237 : this.strong_ ? 1231 : -113);
/*  7990 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  7991 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  7993 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/*  7998 */       if (this.key_ != null) {
/*  7999 */         for (OnestoreEntity.Reference v : this.key_) {
/*  8000 */           if (!v.isInitialized()) {
/*  8001 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*  8006 */       int this_t0 = this.optional_0_;
/*       */ 
/*  8009 */       return ((this_t0 & 0x1) == 0) || 
/*  8008 */         (this.transaction_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*  8016 */       int n = 0;
/*       */       int m;
/*  8019 */       n += (m = this.key_ != null ? this.key_.size() : 0);
/*  8020 */       for (int i = 0; i < m; i++) {
/*  8021 */         n += Protocol.stringSize(((OnestoreEntity.Reference)this.key_.get(i)).encodingSize());
/*       */       }
/*  8023 */       int this_t0 = this.optional_0_;
/*  8024 */       if ((this_t0 & 0x7) != 0) {
/*  8025 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/*  8027 */           n += 1 + Protocol.stringSize(this.transaction_.encodingSize());
/*       */         }
/*  8029 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  8031 */           n += 1 + Protocol.varLongSize(this.failover_ms_);
/*       */         }
/*  8033 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/*  8035 */           n += 2;
/*       */         }
/*       */       }
/*       */ 
/*  8039 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  8046 */       int n = 13;
/*       */       int m;
/*  8049 */       n += 6 * (m = this.key_ != null ? this.key_.size() : 0);
/*  8050 */       for (int i = 0; i < m; i++) {
/*  8051 */         n += ((OnestoreEntity.Reference)this.key_.get(i)).maxEncodingSize();
/*       */       }
/*  8053 */       int this_t0 = this.optional_0_;
/*  8054 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/*  8056 */         n += 6 + this.transaction_.maxEncodingSize();
/*       */       }
/*       */ 
/*  8059 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  8064 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  8068 */       this.optional_0_ = 0;
/*  8069 */       if (this.key_ != null) this.key_.clear();
/*  8070 */       if (this.transaction_ != null) this.transaction_.clear();
/*  8071 */       this.failover_ms_ = 0L;
/*  8072 */       this.strong_ = false;
/*  8073 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public GetRequest newInstance() {
/*  8077 */       return new GetRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  8081 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  8114 */       int i = 0; for (int m = this.key_ != null ? this.key_.size() : 0; i < m; i++) {
/*  8115 */         OnestoreEntity.Reference v = (OnestoreEntity.Reference)this.key_.get(i);
/*  8116 */         sink.putByte(10);
/*  8117 */         sink.putForeign(v);
/*       */       }
/*       */ 
/*  8120 */       int this_t0 = this.optional_0_;
/*  8121 */       if ((this_t0 & 0x1) != 0) {
/*  8122 */         sink.putByte(18);
/*  8123 */         sink.putForeign(this.transaction_);
/*       */       }
/*       */ 
/*  8126 */       if ((this_t0 & 0x2) != 0) {
/*  8127 */         sink.putByte(24);
/*  8128 */         sink.putVarLong(this.failover_ms_);
/*       */       }
/*       */ 
/*  8131 */       if ((this_t0 & 0x4) != 0) {
/*  8132 */         sink.putByte(32);
/*  8133 */         sink.putBoolean(this.strong_);
/*       */       }
/*       */ 
/*  8136 */       if (this.uninterpreted != null)
/*  8137 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  8142 */       boolean result = true;
/*  8143 */       int this_t0 = this.optional_0_;
/*       */ 
/*  8145 */       while (source.hasRemaining()) {
/*  8146 */         int tt = source.getVarInt();
/*  8147 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  8151 */           result = false;
/*  8152 */           break;
/*       */         case 10:
/*  8155 */           source.push(source.getVarInt());
/*  8156 */           if (!addKey().merge(source)) { result = false; break label221; }
/*  8157 */           source.pop();
/*  8158 */           break;
/*       */         case 18:
/*  8161 */           source.push(source.getVarInt());
/*  8162 */           DatastorePb.Transaction v2 = this.transaction_;
/*  8163 */           if (v2 == null) this.transaction_ = (v2 = new DatastorePb.Transaction());
/*  8164 */           if (!v2.merge(source)) { result = false; break label221; }
/*  8165 */           source.pop();
/*  8166 */           this_t0 |= 1;
/*  8167 */           break;
/*       */         case 24:
/*  8170 */           this.failover_ms_ = source.getVarLong();
/*  8171 */           this_t0 |= 2;
/*  8172 */           break;
/*       */         case 32:
/*  8175 */           this.strong_ = source.getBoolean();
/*  8176 */           this_t0 |= 4;
/*  8177 */           break;
/*       */         default:
/*  8179 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  8184 */       label221: this.optional_0_ = this_t0;
/*  8185 */       return result;
/*       */     }
/*       */ 
/*       */     public GetRequest getDefaultInstanceForType()
/*       */     {
/*  8190 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final GetRequest getDefaultInstance() {
/*  8194 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public GetRequest freeze()
/*       */     {
/*  8275 */       this.key_ = ProtocolSupport.freezeMessages(this.key_);
/*  8276 */       if (this.transaction_ != null) this.transaction_.freeze();
/*  8277 */       return this;
/*       */     }
/*       */ 
/*       */     public GetRequest unfreeze() {
/*  8281 */       this.key_ = ProtocolSupport.unfreezeMessages(this.key_);
/*  8282 */       if (this.transaction_ != null) this.transaction_.unfreeze();
/*  8283 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  8287 */       return (ProtocolSupport.isFrozenMessages(this.key_)) || ((this.transaction_ != null) && (this.transaction_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*  8291 */       if (this.uninterpreted == null) {
/*  8292 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  8294 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  8198 */       IMMUTABLE_DEFAULT_INSTANCE = new GetRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.GetRequest clearKey()
/*       */         {
/*  8206 */           return this;
/*       */         }
/*       */         public OnestoreEntity.Reference getMutableKey(int i) {
/*  8209 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey() {
/*  8212 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference addKey(OnestoreEntity.Reference v) {
/*  8215 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference insertKey(int i, OnestoreEntity.Reference v) {
/*  8218 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.Reference removeKey(int i) {
/*  8221 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetRequest clearTransaction()
/*       */         {
/*  8226 */           return this;
/*       */         }
/*       */         public DatastorePb.GetRequest setTransaction(DatastorePb.Transaction x) {
/*  8229 */           ProtocolSupport.unsupportedOperation();
/*  8230 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction getMutableTransaction() {
/*  8233 */           return (DatastorePb.Transaction)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetRequest clearFailoverMs()
/*       */         {
/*  8238 */           return this;
/*       */         }
/*       */         public DatastorePb.GetRequest setFailoverMs(long x) {
/*  8241 */           ProtocolSupport.unsupportedOperation();
/*  8242 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetRequest clearStrong()
/*       */         {
/*  8247 */           return this;
/*       */         }
/*       */         public DatastorePb.GetRequest setStrong(boolean x) {
/*  8250 */           ProtocolSupport.unsupportedOperation();
/*  8251 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.GetRequest mergeFrom(DatastorePb.GetRequest that) {
/*  8255 */           ProtocolSupport.unsupportedOperation();
/*  8256 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  8259 */           ProtocolSupport.unsupportedOperation();
/*  8260 */           return false;
/*       */         }
/*       */         public DatastorePb.GetRequest freeze() {
/*  8263 */           return this;
/*       */         }
/*       */         public DatastorePb.GetRequest unfreeze() {
/*  8266 */           ProtocolSupport.unsupportedOperation();
/*  8267 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  8270 */           return true;
/*       */         }
/*       */       };
/*  8302 */       text = new String[5];
/*       */ 
/*  8304 */       text[0] = "ErrorCode";
/*  8305 */       text[1] = "key";
/*  8306 */       text[2] = "transaction";
/*  8307 */       text[3] = "failover_ms";
/*  8308 */       text[4] = "strong";
/*       */ 
/*  8311 */       types = new int[5];
/*       */ 
/*  8313 */       Arrays.fill(types, 6);
/*  8314 */       types[0] = 0;
/*  8315 */       types[1] = 2;
/*  8316 */       types[2] = 2;
/*  8317 */       types[3] = 0;
/*  8318 */       types[4] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  8085 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.GetRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("key", "key", 1, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Reference.class), new ProtocolType.FieldType("transaction", "transaction", 2, 0, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Transaction.class), new ProtocolType.FieldType("failover_ms", "failover_ms", 3, 1, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("strong", "strong", 4, 2, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class Cost extends ProtocolMessage<Cost>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  7340 */     private int index_writes_ = 0;
/*  7341 */     private int index_write_bytes_ = 0;
/*  7342 */     private int entity_writes_ = 0;
/*  7343 */     private int entity_write_bytes_ = 0;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final Cost IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kindex_writes = 1;
/*       */     public static final int kindex_write_bytes = 2;
/*       */     public static final int kentity_writes = 3;
/*       */     public static final int kentity_write_bytes = 4;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int getIndexWrites()
/*       */     {
/*  7349 */       return this.index_writes_;
/*       */     }
/*       */     public final boolean hasIndexWrites() {
/*  7352 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public Cost clearIndexWrites() {
/*  7355 */       this.optional_0_ &= -2;
/*  7356 */       this.index_writes_ = 0;
/*  7357 */       return this;
/*       */     }
/*       */     public Cost setIndexWrites(int x) {
/*  7360 */       this.optional_0_ |= 1;
/*  7361 */       this.index_writes_ = x;
/*  7362 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getIndexWriteBytes()
/*       */     {
/*  7367 */       return this.index_write_bytes_;
/*       */     }
/*       */     public final boolean hasIndexWriteBytes() {
/*  7370 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public Cost clearIndexWriteBytes() {
/*  7373 */       this.optional_0_ &= -3;
/*  7374 */       this.index_write_bytes_ = 0;
/*  7375 */       return this;
/*       */     }
/*       */     public Cost setIndexWriteBytes(int x) {
/*  7378 */       this.optional_0_ |= 2;
/*  7379 */       this.index_write_bytes_ = x;
/*  7380 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getEntityWrites()
/*       */     {
/*  7385 */       return this.entity_writes_;
/*       */     }
/*       */     public final boolean hasEntityWrites() {
/*  7388 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public Cost clearEntityWrites() {
/*  7391 */       this.optional_0_ &= -5;
/*  7392 */       this.entity_writes_ = 0;
/*  7393 */       return this;
/*       */     }
/*       */     public Cost setEntityWrites(int x) {
/*  7396 */       this.optional_0_ |= 4;
/*  7397 */       this.entity_writes_ = x;
/*  7398 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getEntityWriteBytes()
/*       */     {
/*  7403 */       return this.entity_write_bytes_;
/*       */     }
/*       */     public final boolean hasEntityWriteBytes() {
/*  7406 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public Cost clearEntityWriteBytes() {
/*  7409 */       this.optional_0_ &= -9;
/*  7410 */       this.entity_write_bytes_ = 0;
/*  7411 */       return this;
/*       */     }
/*       */     public Cost setEntityWriteBytes(int x) {
/*  7414 */       this.optional_0_ |= 8;
/*  7415 */       this.entity_write_bytes_ = x;
/*  7416 */       return this;
/*       */     }
/*       */ 
/*       */     public Cost mergeFrom(Cost that)
/*       */     {
/*  7423 */       assert (that != this);
/*  7424 */       int this_t0 = this.optional_0_;
/*  7425 */       int that_t0 = that.optional_0_;
/*       */ 
/*  7427 */       if ((that_t0 & 0x1) != 0) {
/*  7428 */         this_t0 |= 1;
/*  7429 */         this.index_writes_ = that.index_writes_;
/*       */       }
/*       */ 
/*  7432 */       if ((that_t0 & 0x2) != 0) {
/*  7433 */         this_t0 |= 2;
/*  7434 */         this.index_write_bytes_ = that.index_write_bytes_;
/*       */       }
/*       */ 
/*  7437 */       if ((that_t0 & 0x4) != 0) {
/*  7438 */         this_t0 |= 4;
/*  7439 */         this.entity_writes_ = that.entity_writes_;
/*       */       }
/*       */ 
/*  7442 */       if ((that_t0 & 0x8) != 0) {
/*  7443 */         this_t0 |= 8;
/*  7444 */         this.entity_write_bytes_ = that.entity_write_bytes_;
/*       */       }
/*       */ 
/*  7447 */       if (that.uninterpreted != null) {
/*  7448 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  7450 */       this.optional_0_ = this_t0;
/*  7451 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(Cost that) {
/*  7455 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(Cost that) {
/*  7459 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(Cost that, boolean ignoreUninterpreted) {
/*  7463 */       if (that == null) return false;
/*  7464 */       if (that == this) return true;
/*  7465 */       int this_t0 = this.optional_0_;
/*  7466 */       int that_t0 = that.optional_0_;
/*  7467 */       if (this_t0 != that_t0) return false;
/*       */ 
/*  7469 */       if (((this_t0 & 0x1) != 0) && 
/*  7470 */         (this.index_writes_ != that.index_writes_)) return false;
/*       */ 
/*  7473 */       if (((this_t0 & 0x2) != 0) && 
/*  7474 */         (this.index_write_bytes_ != that.index_write_bytes_)) return false;
/*       */ 
/*  7477 */       if (((this_t0 & 0x4) != 0) && 
/*  7478 */         (this.entity_writes_ != that.entity_writes_)) return false;
/*       */ 
/*  7481 */       if (((this_t0 & 0x8) != 0) && 
/*  7482 */         (this.entity_write_bytes_ != that.entity_write_bytes_)) return false;
/*       */ 
/*  7485 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  7490 */       return ((that instanceof Cost)) && (equals((Cost)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  7494 */       int hash = -160304242;
/*       */ 
/*  7496 */       int this_t0 = this.optional_0_;
/*  7497 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.index_writes_ : -113);
/*       */ 
/*  7499 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.index_write_bytes_ : -113);
/*       */ 
/*  7501 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.entity_writes_ : -113);
/*       */ 
/*  7503 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.entity_write_bytes_ : -113);
/*  7504 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  7505 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  7507 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*  7511 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/*  7515 */       int n = 0;
/*  7516 */       int this_t0 = this.optional_0_;
/*  7517 */       if ((this_t0 & 0xF) != 0) {
/*  7518 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/*  7520 */           n += 1 + Protocol.varLongSize(this.index_writes_);
/*       */         }
/*  7522 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  7524 */           n += 1 + Protocol.varLongSize(this.index_write_bytes_);
/*       */         }
/*  7526 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/*  7528 */           n += 1 + Protocol.varLongSize(this.entity_writes_);
/*       */         }
/*  7530 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/*  7532 */           n += 1 + Protocol.varLongSize(this.entity_write_bytes_);
/*       */         }
/*       */       }
/*       */ 
/*  7536 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  7545 */       int n = 44;
/*       */ 
/*  7547 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  7552 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  7556 */       this.optional_0_ = 0;
/*  7557 */       this.index_writes_ = 0;
/*  7558 */       this.index_write_bytes_ = 0;
/*  7559 */       this.entity_writes_ = 0;
/*  7560 */       this.entity_write_bytes_ = 0;
/*  7561 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public Cost newInstance() {
/*  7565 */       return new Cost();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  7569 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  7599 */       int this_t0 = this.optional_0_;
/*  7600 */       if ((this_t0 & 0x1) != 0) {
/*  7601 */         sink.putByte(8);
/*  7602 */         sink.putVarLong(this.index_writes_);
/*       */       }
/*       */ 
/*  7605 */       if ((this_t0 & 0x2) != 0) {
/*  7606 */         sink.putByte(16);
/*  7607 */         sink.putVarLong(this.index_write_bytes_);
/*       */       }
/*       */ 
/*  7610 */       if ((this_t0 & 0x4) != 0) {
/*  7611 */         sink.putByte(24);
/*  7612 */         sink.putVarLong(this.entity_writes_);
/*       */       }
/*       */ 
/*  7615 */       if ((this_t0 & 0x8) != 0) {
/*  7616 */         sink.putByte(32);
/*  7617 */         sink.putVarLong(this.entity_write_bytes_);
/*       */       }
/*       */ 
/*  7620 */       if (this.uninterpreted != null)
/*  7621 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  7626 */       boolean result = true;
/*  7627 */       int this_t0 = this.optional_0_;
/*       */ 
/*  7629 */       while (source.hasRemaining()) {
/*  7630 */         int tt = source.getVarInt();
/*  7631 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  7635 */           result = false;
/*  7636 */           break;
/*       */         case 8:
/*  7639 */           this.index_writes_ = source.getVarInt();
/*  7640 */           this_t0 |= 1;
/*  7641 */           break;
/*       */         case 16:
/*  7644 */           this.index_write_bytes_ = source.getVarInt();
/*  7645 */           this_t0 |= 2;
/*  7646 */           break;
/*       */         case 24:
/*  7649 */           this.entity_writes_ = source.getVarInt();
/*  7650 */           this_t0 |= 4;
/*  7651 */           break;
/*       */         case 32:
/*  7654 */           this.entity_write_bytes_ = source.getVarInt();
/*  7655 */           this_t0 |= 8;
/*  7656 */           break;
/*       */         default:
/*  7658 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  7663 */       this.optional_0_ = this_t0;
/*  7664 */       return result;
/*       */     }
/*       */ 
/*       */     public Cost getDefaultInstanceForType()
/*       */     {
/*  7669 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final Cost getDefaultInstance() {
/*  7673 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/*  7739 */       if (this.uninterpreted == null) {
/*  7740 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  7742 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  7677 */       IMMUTABLE_DEFAULT_INSTANCE = new Cost()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.Cost clearIndexWrites()
/*       */         {
/*  7685 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost setIndexWrites(int x) {
/*  7688 */           ProtocolSupport.unsupportedOperation();
/*  7689 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Cost clearIndexWriteBytes()
/*       */         {
/*  7694 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost setIndexWriteBytes(int x) {
/*  7697 */           ProtocolSupport.unsupportedOperation();
/*  7698 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Cost clearEntityWrites()
/*       */         {
/*  7703 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost setEntityWrites(int x) {
/*  7706 */           ProtocolSupport.unsupportedOperation();
/*  7707 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Cost clearEntityWriteBytes()
/*       */         {
/*  7712 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost setEntityWriteBytes(int x) {
/*  7715 */           ProtocolSupport.unsupportedOperation();
/*  7716 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Cost mergeFrom(DatastorePb.Cost that) {
/*  7720 */           ProtocolSupport.unsupportedOperation();
/*  7721 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  7724 */           ProtocolSupport.unsupportedOperation();
/*  7725 */           return false;
/*       */         }
/*       */         public DatastorePb.Cost freeze() {
/*  7728 */           return this;
/*       */         }
/*       */         public DatastorePb.Cost unfreeze() {
/*  7731 */           ProtocolSupport.unsupportedOperation();
/*  7732 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  7735 */           return true;
/*       */         }
/*       */       };
/*  7750 */       text = new String[5];
/*       */ 
/*  7752 */       text[0] = "ErrorCode";
/*  7753 */       text[1] = "index_writes";
/*  7754 */       text[2] = "index_write_bytes";
/*  7755 */       text[3] = "entity_writes";
/*  7756 */       text[4] = "entity_write_bytes";
/*       */ 
/*  7759 */       types = new int[5];
/*       */ 
/*  7761 */       Arrays.fill(types, 6);
/*  7762 */       types[0] = 0;
/*  7763 */       types[1] = 0;
/*  7764 */       types[2] = 0;
/*  7765 */       types[3] = 0;
/*  7766 */       types[4] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  7573 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Cost.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("index_writes", "index_writes", 1, 0, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("index_write_bytes", "index_write_bytes", 2, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("entity_writes", "entity_writes", 3, 2, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("entity_write_bytes", "entity_write_bytes", 4, 3, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class Error extends ProtocolMessage<Error>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*       */     private UninterpretedTags uninterpreted;
/*       */     public static final Error IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public Error mergeFrom(Error that)
/*       */     {
/*  7153 */       assert (that != this);
/*       */ 
/*  7155 */       if (that.uninterpreted != null) {
/*  7156 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  7158 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(Error that) {
/*  7162 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(Error that) {
/*  7166 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(Error that, boolean ignoreUninterpreted) {
/*  7170 */       if (that == null) return false;
/*  7171 */       if (that == this) return true;
/*       */ 
/*  7173 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  7178 */       return ((that instanceof Error)) && (equals((Error)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  7182 */       int hash = -1068360440;
/*  7183 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  7184 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  7186 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*  7190 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/*  7194 */       int n = 0;
/*       */ 
/*  7196 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  7201 */       int n = 0;
/*       */ 
/*  7203 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  7208 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  7212 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public Error newInstance() {
/*  7216 */       return new Error();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  7220 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  7252 */       if (this.uninterpreted != null)
/*  7253 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  7258 */       boolean result = true;
/*       */ 
/*  7260 */       while (source.hasRemaining()) {
/*  7261 */         int tt = source.getVarInt();
/*  7262 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  7266 */           result = false;
/*  7267 */           break;
/*       */         default:
/*  7269 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  7274 */       return result;
/*       */     }
/*       */ 
/*       */     public Error getDefaultInstanceForType()
/*       */     {
/*  7279 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final Error getDefaultInstance() {
/*  7283 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/*  7313 */       if (this.uninterpreted == null) {
/*  7314 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  7316 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  7287 */       IMMUTABLE_DEFAULT_INSTANCE = new Error()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.Error mergeFrom(DatastorePb.Error that)
/*       */         {
/*  7294 */           ProtocolSupport.unsupportedOperation();
/*  7295 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  7298 */           ProtocolSupport.unsupportedOperation();
/*  7299 */           return false;
/*       */         }
/*       */         public DatastorePb.Error freeze() {
/*  7302 */           return this;
/*       */         }
/*       */         public DatastorePb.Error unfreeze() {
/*  7305 */           ProtocolSupport.unsupportedOperation();
/*  7306 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  7309 */           return true;
/*       */         }
/*       */       };
/*  7320 */       text = new String[1];
/*       */ 
/*  7322 */       text[0] = "ErrorCode";
/*       */ 
/*  7325 */       types = new int[1];
/*       */ 
/*  7327 */       Arrays.fill(types, 6);
/*  7328 */       types[0] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  7224 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Error.class, "Z'apphosting/datastore/datastore_v3.proto\n\035apphosting_datastore_v3.Errorsz\tErrorCode\001\001\013BAD_REQUEST\001\001\001\001\001\026CONCURRENT_TRANSACTION\001\002\001\001\001\016INTERNAL_ERROR\001\003\001\001\001\nNEED_INDEX\001\004\001\001\001\007TIMEOUT\001\005\001\001\001\021PERMISSION_DENIED\001\006\001\001\001\016BIGTABLE_ERROR\001\007\001\001\001\034COMMITTED_BUT_STILL_APPLYING\001\b\001\001\001\023CAPABILITY_DISABLED\001\t\001t", new ProtocolType.FieldType[0]);
/*       */     }
/*       */ 
/*       */     public static enum ErrorCode
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  7115 */       BAD_REQUEST(1), 
/*  7116 */       CONCURRENT_TRANSACTION(2), 
/*  7117 */       INTERNAL_ERROR(3), 
/*  7118 */       NEED_INDEX(4), 
/*  7119 */       TIMEOUT(5), 
/*  7120 */       PERMISSION_DENIED(6), 
/*  7121 */       BIGTABLE_ERROR(7), 
/*  7122 */       COMMITTED_BUT_STILL_APPLYING(8), 
/*  7123 */       CAPABILITY_DISABLED(9);
/*       */ 
/*       */       public static final ErrorCode ErrorCode_MIN;
/*       */       public static final ErrorCode ErrorCode_MAX;
/*       */       private final int value;
/*       */ 
/*  7128 */       public int getValue() { return this.value; }
/*       */ 
/*       */       public static ErrorCode valueOf(int value) {
/*  7131 */         switch (value) { case 1:
/*  7132 */           return BAD_REQUEST;
/*       */         case 2:
/*  7133 */           return CONCURRENT_TRANSACTION;
/*       */         case 3:
/*  7134 */           return INTERNAL_ERROR;
/*       */         case 4:
/*  7135 */           return NEED_INDEX;
/*       */         case 5:
/*  7136 */           return TIMEOUT;
/*       */         case 6:
/*  7137 */           return PERMISSION_DENIED;
/*       */         case 7:
/*  7138 */           return BIGTABLE_ERROR;
/*       */         case 8:
/*  7139 */           return COMMITTED_BUT_STILL_APPLYING;
/*       */         case 9:
/*  7140 */           return CAPABILITY_DISABLED;
/*       */         }
/*  7142 */         return null;
/*       */       }
/*       */ 
/*       */       private ErrorCode(int v) {
/*  7146 */         this.value = v;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  7125 */         ErrorCode_MIN = BAD_REQUEST;
/*  7126 */         ErrorCode_MAX = CAPABILITY_DISABLED;
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class Cursor extends ProtocolMessage<Cursor>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  6767 */     private long cursor_ = 0L;
/*  6768 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final Cursor IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kcursor = 1;
/*       */     public static final int kapp = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final long getCursor()
/*       */     {
/*  6774 */       return this.cursor_;
/*       */     }
/*       */     public final boolean hasCursor() {
/*  6777 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public Cursor clearCursor() {
/*  6780 */       this.optional_0_ &= -2;
/*  6781 */       this.cursor_ = 0L;
/*  6782 */       return this;
/*       */     }
/*       */     public Cursor setCursor(long x) {
/*  6785 */       this.optional_0_ |= 1;
/*  6786 */       this.cursor_ = x;
/*  6787 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/*  6792 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/*  6795 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public Cursor clearApp() {
/*  6798 */       this.optional_0_ &= -3;
/*  6799 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6800 */       return this;
/*       */     }
/*       */     public Cursor setAppAsBytes(byte[] x) {
/*  6803 */       this.optional_0_ |= 2;
/*  6804 */       this.app_ = x;
/*  6805 */       return this;
/*       */     }
/*       */     public final String getApp() {
/*  6808 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public Cursor setApp(String v) {
/*  6811 */       if (v == null) throw new NullPointerException();
/*  6812 */       this.optional_0_ |= 2;
/*  6813 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/*  6814 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/*  6817 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public Cursor setApp(String v, Charset cs) {
/*  6820 */       if (v == null) throw new NullPointerException();
/*  6821 */       this.optional_0_ |= 2;
/*  6822 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/*  6823 */       return this;
/*       */     }
/*       */ 
/*       */     public Cursor mergeFrom(Cursor that)
/*       */     {
/*  6830 */       assert (that != this);
/*  6831 */       int this_t0 = this.optional_0_;
/*  6832 */       int that_t0 = that.optional_0_;
/*       */ 
/*  6834 */       if ((that_t0 & 0x1) != 0) {
/*  6835 */         this_t0 |= 1;
/*  6836 */         this.cursor_ = that.cursor_;
/*       */       }
/*       */ 
/*  6839 */       if ((that_t0 & 0x2) != 0) {
/*  6840 */         this_t0 |= 2;
/*  6841 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/*  6844 */       if (that.uninterpreted != null) {
/*  6845 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  6847 */       this.optional_0_ = this_t0;
/*  6848 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(Cursor that) {
/*  6852 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(Cursor that) {
/*  6856 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(Cursor that, boolean ignoreUninterpreted) {
/*  6860 */       if (that == null) return false;
/*  6861 */       if (that == this) return true;
/*  6862 */       int this_t0 = this.optional_0_;
/*  6863 */       int that_t0 = that.optional_0_;
/*  6864 */       if (this_t0 != that_t0) return false;
/*       */ 
/*  6866 */       if (((this_t0 & 0x1) != 0) && 
/*  6867 */         (this.cursor_ != that.cursor_)) return false;
/*       */ 
/*  6870 */       if (((this_t0 & 0x2) != 0) && 
/*  6871 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/*  6874 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  6879 */       return ((that instanceof Cursor)) && (equals((Cursor)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  6883 */       int hash = 234521377;
/*       */ 
/*  6885 */       int this_t0 = this.optional_0_;
/*  6886 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.cursor_) : -113);
/*       */ 
/*  6888 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.app_) : -113);
/*  6889 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  6890 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  6892 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*  6896 */       int this_t0 = this.optional_0_;
/*       */ 
/*  6898 */       return (this_t0 & 0x1) == 1;
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*  6905 */       int n = 9;
/*  6906 */       int this_t0 = this.optional_0_;
/*  6907 */       if ((this_t0 & 0x2) != 0)
/*       */       {
/*  6909 */         n += 1 + Protocol.stringSize(this.app_.length);
/*       */       }
/*       */ 
/*  6912 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  6918 */       int n = 9;
/*  6919 */       int this_t0 = this.optional_0_;
/*  6920 */       if ((this_t0 & 0x2) != 0)
/*       */       {
/*  6922 */         n += 6 + this.app_.length;
/*       */       }
/*       */ 
/*  6925 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  6930 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  6934 */       this.optional_0_ = 0;
/*  6935 */       this.cursor_ = 0L;
/*  6936 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6937 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public Cursor newInstance() {
/*  6941 */       return new Cursor();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  6945 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  6967 */       sink.putByte(9);
/*  6968 */       sink.putLong(this.cursor_);
/*       */ 
/*  6970 */       int this_t0 = this.optional_0_;
/*  6971 */       if ((this_t0 & 0x2) != 0) {
/*  6972 */         sink.putByte(18);
/*  6973 */         sink.putPrefixedData(this.app_);
/*       */       }
/*       */ 
/*  6976 */       if (this.uninterpreted != null)
/*  6977 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  6982 */       boolean result = true;
/*  6983 */       int this_t0 = this.optional_0_;
/*       */ 
/*  6985 */       while (source.hasRemaining()) {
/*  6986 */         int tt = source.getVarInt();
/*  6987 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  6991 */           result = false;
/*  6992 */           break;
/*       */         case 9:
/*  6995 */           this.cursor_ = source.getLong();
/*  6996 */           this_t0 |= 1;
/*  6997 */           break;
/*       */         case 18:
/*  7000 */           this.app_ = source.getPrefixedData();
/*  7001 */           this_t0 |= 2;
/*  7002 */           break;
/*       */         default:
/*  7004 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  7009 */       this.optional_0_ = this_t0;
/*  7010 */       return result;
/*       */     }
/*       */ 
/*       */     public Cursor getDefaultInstanceForType()
/*       */     {
/*  7015 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final Cursor getDefaultInstance() {
/*  7019 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public Cursor freeze()
/*       */     {
/*  7076 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/*  7077 */       return this;
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*  7080 */       if (this.uninterpreted == null) {
/*  7081 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  7083 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  7023 */       IMMUTABLE_DEFAULT_INSTANCE = new Cursor()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.Cursor clearCursor()
/*       */         {
/*  7031 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor setCursor(long x) {
/*  7034 */           ProtocolSupport.unsupportedOperation();
/*  7035 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Cursor clearApp()
/*       */         {
/*  7040 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor setAppAsBytes(byte[] x) {
/*  7043 */           ProtocolSupport.unsupportedOperation();
/*  7044 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor setApp(String v) {
/*  7047 */           ProtocolSupport.unsupportedOperation();
/*  7048 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor setApp(String v, Charset cs) {
/*  7051 */           ProtocolSupport.unsupportedOperation();
/*  7052 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Cursor mergeFrom(DatastorePb.Cursor that) {
/*  7056 */           ProtocolSupport.unsupportedOperation();
/*  7057 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  7060 */           ProtocolSupport.unsupportedOperation();
/*  7061 */           return false;
/*       */         }
/*       */         public DatastorePb.Cursor freeze() {
/*  7064 */           return this;
/*       */         }
/*       */         public DatastorePb.Cursor unfreeze() {
/*  7067 */           ProtocolSupport.unsupportedOperation();
/*  7068 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  7071 */           return true;
/*       */         }
/*       */       };
/*  7089 */       text = new String[3];
/*       */ 
/*  7091 */       text[0] = "ErrorCode";
/*  7092 */       text[1] = "cursor";
/*  7093 */       text[2] = "app";
/*       */ 
/*  7096 */       types = new int[3];
/*       */ 
/*  7098 */       Arrays.fill(types, 6);
/*  7099 */       types[0] = 0;
/*  7100 */       types[1] = 1;
/*  7101 */       types[2] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  6949 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Cursor.class, "Z'apphosting/datastore/datastore_v3.proto\n\036apphosting_datastore_v3.Cursor\023\032\006cursor \001(\0010\0068\002\024\023\032\003app \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("cursor", "cursor", 1, 0, ProtocolType.FieldBaseType.FIXED64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("app", "app", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class RunCompiledQueryRequest extends ProtocolMessage<RunCompiledQueryRequest>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  6084 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6085 */     private byte[] name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6086 */     private DatastorePb.CompiledQuery compiled_query_ = new DatastorePb.CompiledQuery();
/*  6087 */     private DatastorePb.Query original_query_ = null;
/*  6088 */     private int count_ = 0;
/*  6089 */     private long failover_ms_ = 0L;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final RunCompiledQueryRequest IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kapp = 5;
/*       */     public static final int kname_space = 6;
/*       */     public static final int kcompiled_query = 1;
/*       */     public static final int koriginal_query = 2;
/*       */     public static final int kcount = 3;
/*       */     public static final int kfailover_ms = 4;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/*  6095 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/*  6098 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public RunCompiledQueryRequest clearApp() {
/*  6101 */       this.optional_0_ &= -2;
/*  6102 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6103 */       return this;
/*       */     }
/*       */     public RunCompiledQueryRequest setAppAsBytes(byte[] x) {
/*  6106 */       this.optional_0_ |= 1;
/*  6107 */       this.app_ = x;
/*  6108 */       return this;
/*       */     }
/*       */     public final String getApp() {
/*  6111 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public RunCompiledQueryRequest setApp(String v) {
/*  6114 */       if (v == null) throw new NullPointerException();
/*  6115 */       this.optional_0_ |= 1;
/*  6116 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/*  6117 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/*  6120 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public RunCompiledQueryRequest setApp(String v, Charset cs) {
/*  6123 */       if (v == null) throw new NullPointerException();
/*  6124 */       this.optional_0_ |= 1;
/*  6125 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/*  6126 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getNameSpaceAsBytes()
/*       */     {
/*  6131 */       return this.name_space_;
/*       */     }
/*       */     public final boolean hasNameSpace() {
/*  6134 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public RunCompiledQueryRequest clearNameSpace() {
/*  6137 */       this.optional_0_ &= -3;
/*  6138 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6139 */       return this;
/*       */     }
/*       */     public RunCompiledQueryRequest setNameSpaceAsBytes(byte[] x) {
/*  6142 */       this.optional_0_ |= 2;
/*  6143 */       this.name_space_ = x;
/*  6144 */       return this;
/*       */     }
/*       */     public final String getNameSpace() {
/*  6147 */       return ProtocolSupport.toStringUtf8(this.name_space_);
/*       */     }
/*       */     public RunCompiledQueryRequest setNameSpace(String v) {
/*  6150 */       if (v == null) throw new NullPointerException();
/*  6151 */       this.optional_0_ |= 2;
/*  6152 */       this.name_space_ = ProtocolSupport.toBytesUtf8(v);
/*  6153 */       return this;
/*       */     }
/*       */     public final String getNameSpace(Charset cs) {
/*  6156 */       return ProtocolSupport.toString(this.name_space_, cs);
/*       */     }
/*       */     public RunCompiledQueryRequest setNameSpace(String v, Charset cs) {
/*  6159 */       if (v == null) throw new NullPointerException();
/*  6160 */       this.optional_0_ |= 2;
/*  6161 */       this.name_space_ = ProtocolSupport.toBytes(v, cs);
/*  6162 */       return this;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.CompiledQuery getCompiledQuery()
/*       */     {
/*  6167 */       return this.compiled_query_;
/*       */     }
/*       */     public final boolean hasCompiledQuery() {
/*  6170 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public RunCompiledQueryRequest clearCompiledQuery() {
/*  6173 */       this.optional_0_ &= -5;
/*  6174 */       this.compiled_query_.clear();
/*  6175 */       return this;
/*       */     }
/*       */     public RunCompiledQueryRequest setCompiledQuery(DatastorePb.CompiledQuery x) {
/*  6178 */       if (x == null) throw new NullPointerException();
/*  6179 */       this.optional_0_ |= 4;
/*  6180 */       this.compiled_query_ = x;
/*  6181 */       return this;
/*       */     }
/*       */     public DatastorePb.CompiledQuery getMutableCompiledQuery() {
/*  6184 */       this.optional_0_ |= 4;
/*  6185 */       return this.compiled_query_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.Query getOriginalQuery()
/*       */     {
/*  6190 */       if (this.original_query_ == null) {
/*  6191 */         return DatastorePb.Query.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  6193 */       return this.original_query_;
/*       */     }
/*       */     public final boolean hasOriginalQuery() {
/*  6196 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public RunCompiledQueryRequest clearOriginalQuery() {
/*  6199 */       this.optional_0_ &= -9;
/*  6200 */       if (this.original_query_ != null) this.original_query_.clear();
/*  6201 */       return this;
/*       */     }
/*       */     public RunCompiledQueryRequest setOriginalQuery(DatastorePb.Query x) {
/*  6204 */       if (x == null) throw new NullPointerException();
/*  6205 */       this.optional_0_ |= 8;
/*  6206 */       this.original_query_ = x;
/*  6207 */       return this;
/*       */     }
/*       */     public DatastorePb.Query getMutableOriginalQuery() {
/*  6210 */       this.optional_0_ |= 8;
/*  6211 */       if (this.original_query_ == null) this.original_query_ = new DatastorePb.Query();
/*  6212 */       return this.original_query_;
/*       */     }
/*       */ 
/*       */     public final int getCount()
/*       */     {
/*  6217 */       return this.count_;
/*       */     }
/*       */     public final boolean hasCount() {
/*  6220 */       return (this.optional_0_ & 0x10) != 0;
/*       */     }
/*       */     public RunCompiledQueryRequest clearCount() {
/*  6223 */       this.optional_0_ &= -17;
/*  6224 */       this.count_ = 0;
/*  6225 */       return this;
/*       */     }
/*       */     public RunCompiledQueryRequest setCount(int x) {
/*  6228 */       this.optional_0_ |= 16;
/*  6229 */       this.count_ = x;
/*  6230 */       return this;
/*       */     }
/*       */ 
/*       */     public final long getFailoverMs()
/*       */     {
/*  6235 */       return this.failover_ms_;
/*       */     }
/*       */     public final boolean hasFailoverMs() {
/*  6238 */       return (this.optional_0_ & 0x20) != 0;
/*       */     }
/*       */     public RunCompiledQueryRequest clearFailoverMs() {
/*  6241 */       this.optional_0_ &= -33;
/*  6242 */       this.failover_ms_ = 0L;
/*  6243 */       return this;
/*       */     }
/*       */     public RunCompiledQueryRequest setFailoverMs(long x) {
/*  6246 */       this.optional_0_ |= 32;
/*  6247 */       this.failover_ms_ = x;
/*  6248 */       return this;
/*       */     }
/*       */ 
/*       */     public RunCompiledQueryRequest mergeFrom(RunCompiledQueryRequest that)
/*       */     {
/*  6255 */       assert (that != this);
/*  6256 */       int this_t0 = this.optional_0_;
/*  6257 */       int that_t0 = that.optional_0_;
/*       */ 
/*  6259 */       if ((that_t0 & 0x1) != 0) {
/*  6260 */         this_t0 |= 1;
/*  6261 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/*  6264 */       if ((that_t0 & 0x2) != 0) {
/*  6265 */         this_t0 |= 2;
/*  6266 */         this.name_space_ = that.name_space_;
/*       */       }
/*       */ 
/*  6269 */       if ((that_t0 & 0x4) != 0) {
/*  6270 */         this_t0 |= 4;
/*  6271 */         DatastorePb.CompiledQuery v = this.compiled_query_;
/*  6272 */         v.mergeFrom(that.compiled_query_);
/*       */       }
/*       */ 
/*  6275 */       if ((that_t0 & 0x8) != 0) {
/*  6276 */         this_t0 |= 8;
/*  6277 */         DatastorePb.Query v = this.original_query_;
/*  6278 */         if (v == null) this.original_query_ = (v = new DatastorePb.Query());
/*  6279 */         v.mergeFrom(that.original_query_);
/*       */       }
/*       */ 
/*  6282 */       if ((that_t0 & 0x10) != 0) {
/*  6283 */         this_t0 |= 16;
/*  6284 */         this.count_ = that.count_;
/*       */       }
/*       */ 
/*  6287 */       if ((that_t0 & 0x20) != 0) {
/*  6288 */         this_t0 |= 32;
/*  6289 */         this.failover_ms_ = that.failover_ms_;
/*       */       }
/*       */ 
/*  6292 */       if (that.uninterpreted != null) {
/*  6293 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  6295 */       this.optional_0_ = this_t0;
/*  6296 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(RunCompiledQueryRequest that) {
/*  6300 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(RunCompiledQueryRequest that) {
/*  6304 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(RunCompiledQueryRequest that, boolean ignoreUninterpreted) {
/*  6308 */       if (that == null) return false;
/*  6309 */       if (that == this) return true;
/*  6310 */       int this_t0 = this.optional_0_;
/*  6311 */       int that_t0 = that.optional_0_;
/*  6312 */       if (this_t0 != that_t0) return false;
/*       */ 
/*  6314 */       if (((this_t0 & 0x1) != 0) && 
/*  6315 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/*  6318 */       if (((this_t0 & 0x2) != 0) && 
/*  6319 */         (!Arrays.equals(this.name_space_, that.name_space_))) return false;
/*       */ 
/*  6322 */       if (((this_t0 & 0x4) != 0) && 
/*  6323 */         (!this.compiled_query_.equals(that.compiled_query_, ignoreUninterpreted))) return false;
/*       */ 
/*  6326 */       if (((this_t0 & 0x8) != 0) && 
/*  6327 */         (!this.original_query_.equals(that.original_query_, ignoreUninterpreted))) return false;
/*       */ 
/*  6330 */       if (((this_t0 & 0x10) != 0) && 
/*  6331 */         (this.count_ != that.count_)) return false;
/*       */ 
/*  6334 */       if (((this_t0 & 0x20) != 0) && 
/*  6335 */         (this.failover_ms_ != that.failover_ms_)) return false;
/*       */ 
/*  6338 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  6343 */       return ((that instanceof RunCompiledQueryRequest)) && (equals((RunCompiledQueryRequest)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  6347 */       int hash = 399711602;
/*       */ 
/*  6349 */       int this_t0 = this.optional_0_;
/*  6350 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.compiled_query_.hashCode() : -113);
/*       */ 
/*  6352 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.original_query_.hashCode() : -113);
/*       */ 
/*  6354 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? this.count_ : -113);
/*       */ 
/*  6356 */       hash = hash * 31 + ((this_t0 & 0x20) != 0 ? ProtocolSupport.hashCode(this.failover_ms_) : -113);
/*       */ 
/*  6358 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/*       */ 
/*  6360 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.name_space_) : -113);
/*  6361 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  6362 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  6364 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*  6368 */       int this_t0 = this.optional_0_;
/*  6369 */       if ((this_t0 & 0x5) != 5)
/*       */       {
/*  6371 */         return (this_t0 & 0x1) != 0;
/*       */       }
/*       */ 
/*  6376 */       if (!this.compiled_query_.isInitialized()) {
/*  6377 */         return false;
/*       */       }
/*       */ 
/*  6382 */       return ((this_t0 & 0x8) == 0) || 
/*  6381 */         (this.original_query_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*  6391 */       int n = 2 + Protocol.stringSize(this.app_.length) + Protocol.stringSize(this.compiled_query_.encodingSize());
/*       */ 
/*  6393 */       int this_t0 = this.optional_0_;
/*  6394 */       if ((this_t0 & 0x3A) != 0) {
/*  6395 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  6397 */           n += 1 + Protocol.stringSize(this.name_space_.length);
/*       */         }
/*  6399 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/*  6401 */           n += 1 + Protocol.stringSize(this.original_query_.encodingSize());
/*       */         }
/*  6403 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/*  6405 */           n += 1 + Protocol.varLongSize(this.count_);
/*       */         }
/*  6407 */         if ((this_t0 & 0x20) != 0)
/*       */         {
/*  6409 */           n += 1 + Protocol.varLongSize(this.failover_ms_);
/*       */         }
/*       */       }
/*       */ 
/*  6413 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  6422 */       int n = 34 + this.app_.length + this.compiled_query_.maxEncodingSize();
/*  6423 */       int this_t0 = this.optional_0_;
/*  6424 */       if ((this_t0 & 0xA) != 0) {
/*  6425 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  6427 */           n += 6 + this.name_space_.length;
/*       */         }
/*  6429 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/*  6431 */           n += 6 + this.original_query_.maxEncodingSize();
/*       */         }
/*       */       }
/*       */ 
/*  6435 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  6440 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  6444 */       this.optional_0_ = 0;
/*  6445 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6446 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  6447 */       this.compiled_query_.clear();
/*  6448 */       if (this.original_query_ != null) this.original_query_.clear();
/*  6449 */       this.count_ = 0;
/*  6450 */       this.failover_ms_ = 0L;
/*  6451 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public RunCompiledQueryRequest newInstance() {
/*  6455 */       return new RunCompiledQueryRequest();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  6459 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  6501 */       sink.putByte(10);
/*  6502 */       sink.putForeign(this.compiled_query_);
/*       */ 
/*  6504 */       int this_t0 = this.optional_0_;
/*  6505 */       if ((this_t0 & 0x8) != 0) {
/*  6506 */         sink.putByte(18);
/*  6507 */         sink.putForeign(this.original_query_);
/*       */       }
/*       */ 
/*  6510 */       if ((this_t0 & 0x10) != 0) {
/*  6511 */         sink.putByte(24);
/*  6512 */         sink.putVarLong(this.count_);
/*       */       }
/*       */ 
/*  6515 */       if ((this_t0 & 0x20) != 0) {
/*  6516 */         sink.putByte(32);
/*  6517 */         sink.putVarLong(this.failover_ms_);
/*       */       }
/*       */ 
/*  6520 */       sink.putByte(42);
/*  6521 */       sink.putPrefixedData(this.app_);
/*       */ 
/*  6523 */       if ((this_t0 & 0x2) != 0) {
/*  6524 */         sink.putByte(50);
/*  6525 */         sink.putPrefixedData(this.name_space_);
/*       */       }
/*       */ 
/*  6528 */       if (this.uninterpreted != null)
/*  6529 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  6534 */       boolean result = true;
/*  6535 */       int this_t0 = this.optional_0_;
/*       */ 
/*  6537 */       while (source.hasRemaining()) {
/*  6538 */         int tt = source.getVarInt();
/*  6539 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  6543 */           result = false;
/*  6544 */           break;
/*       */         case 10:
/*  6547 */           source.push(source.getVarInt());
/*  6548 */           if (!this.compiled_query_.merge(source)) { result = false; break label274; }
/*  6549 */           source.pop();
/*  6550 */           this_t0 |= 4;
/*  6551 */           break;
/*       */         case 18:
/*  6554 */           source.push(source.getVarInt());
/*  6555 */           DatastorePb.Query v2 = this.original_query_;
/*  6556 */           if (v2 == null) this.original_query_ = (v2 = new DatastorePb.Query());
/*  6557 */           if (!v2.merge(source)) { result = false; break label274; }
/*  6558 */           source.pop();
/*  6559 */           this_t0 |= 8;
/*  6560 */           break;
/*       */         case 24:
/*  6563 */           this.count_ = source.getVarInt();
/*  6564 */           this_t0 |= 16;
/*  6565 */           break;
/*       */         case 32:
/*  6568 */           this.failover_ms_ = source.getVarLong();
/*  6569 */           this_t0 |= 32;
/*  6570 */           break;
/*       */         case 42:
/*  6573 */           this.app_ = source.getPrefixedData();
/*  6574 */           this_t0 |= 1;
/*  6575 */           break;
/*       */         case 50:
/*  6578 */           this.name_space_ = source.getPrefixedData();
/*  6579 */           this_t0 |= 2;
/*  6580 */           break;
/*       */         default:
/*  6582 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  6587 */       label274: this.optional_0_ = this_t0;
/*  6588 */       return result;
/*       */     }
/*       */ 
/*       */     public RunCompiledQueryRequest getDefaultInstanceForType()
/*       */     {
/*  6593 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final RunCompiledQueryRequest getDefaultInstance() {
/*  6597 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public RunCompiledQueryRequest freeze()
/*       */     {
/*  6704 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/*  6705 */       this.name_space_ = ProtocolSupport.freezeString(this.name_space_);
/*  6706 */       this.compiled_query_.freeze();
/*  6707 */       if (this.original_query_ != null) this.original_query_.freeze();
/*  6708 */       return this;
/*       */     }
/*       */ 
/*       */     public RunCompiledQueryRequest unfreeze() {
/*  6712 */       this.compiled_query_.unfreeze();
/*  6713 */       if (this.original_query_ != null) this.original_query_.unfreeze();
/*  6714 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  6718 */       return (this.compiled_query_.isFrozen()) || ((this.original_query_ != null) && (this.original_query_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*  6722 */       if (this.uninterpreted == null) {
/*  6723 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  6725 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  6601 */       IMMUTABLE_DEFAULT_INSTANCE = new RunCompiledQueryRequest()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest clearApp()
/*       */         {
/*  6609 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setAppAsBytes(byte[] x) {
/*  6612 */           ProtocolSupport.unsupportedOperation();
/*  6613 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setApp(String v) {
/*  6616 */           ProtocolSupport.unsupportedOperation();
/*  6617 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setApp(String v, Charset cs) {
/*  6620 */           ProtocolSupport.unsupportedOperation();
/*  6621 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest clearNameSpace()
/*       */         {
/*  6626 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setNameSpaceAsBytes(byte[] x) {
/*  6629 */           ProtocolSupport.unsupportedOperation();
/*  6630 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setNameSpace(String v) {
/*  6633 */           ProtocolSupport.unsupportedOperation();
/*  6634 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setNameSpace(String v, Charset cs) {
/*  6637 */           ProtocolSupport.unsupportedOperation();
/*  6638 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest clearCompiledQuery()
/*       */         {
/*  6643 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setCompiledQuery(DatastorePb.CompiledQuery x) {
/*  6646 */           ProtocolSupport.unsupportedOperation();
/*  6647 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery getMutableCompiledQuery() {
/*  6650 */           return (DatastorePb.CompiledQuery)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest clearOriginalQuery()
/*       */         {
/*  6655 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setOriginalQuery(DatastorePb.Query x) {
/*  6658 */           ProtocolSupport.unsupportedOperation();
/*  6659 */           return this;
/*       */         }
/*       */         public DatastorePb.Query getMutableOriginalQuery() {
/*  6662 */           return (DatastorePb.Query)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest clearCount()
/*       */         {
/*  6667 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setCount(int x) {
/*  6670 */           ProtocolSupport.unsupportedOperation();
/*  6671 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest clearFailoverMs()
/*       */         {
/*  6676 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest setFailoverMs(long x) {
/*  6679 */           ProtocolSupport.unsupportedOperation();
/*  6680 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.RunCompiledQueryRequest mergeFrom(DatastorePb.RunCompiledQueryRequest that) {
/*  6684 */           ProtocolSupport.unsupportedOperation();
/*  6685 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  6688 */           ProtocolSupport.unsupportedOperation();
/*  6689 */           return false;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest freeze() {
/*  6692 */           return this;
/*       */         }
/*       */         public DatastorePb.RunCompiledQueryRequest unfreeze() {
/*  6695 */           ProtocolSupport.unsupportedOperation();
/*  6696 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  6699 */           return true;
/*       */         }
/*       */       };
/*  6735 */       text = new String[7];
/*       */ 
/*  6737 */       text[0] = "ErrorCode";
/*  6738 */       text[1] = "compiled_query";
/*  6739 */       text[2] = "original_query";
/*  6740 */       text[3] = "count";
/*  6741 */       text[4] = "failover_ms";
/*  6742 */       text[5] = "app";
/*  6743 */       text[6] = "name_space";
/*       */ 
/*  6746 */       types = new int[7];
/*       */ 
/*  6748 */       Arrays.fill(types, 6);
/*  6749 */       types[0] = 0;
/*  6750 */       types[1] = 2;
/*  6751 */       types[2] = 2;
/*  6752 */       types[3] = 0;
/*  6753 */       types[4] = 0;
/*  6754 */       types[5] = 2;
/*  6755 */       types[6] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  6463 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.RunCompiledQueryRequest.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 5, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("name_space", "name_space", 6, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("compiled_query", "compiled_query", 1, 2, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REQUIRED, DatastorePb.CompiledQuery.class), new ProtocolType.FieldType("original_query", "original_query", 2, 3, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Query.class), new ProtocolType.FieldType("count", "count", 3, 4, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("failover_ms", "failover_ms", 4, 5, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class CompiledCursor extends ProtocolMessage<CompiledCursor>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  5681 */     private int multiquery_index_ = 0;
/*  5682 */     private List<Position> position_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final CompiledCursor IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kmultiquery_index = 1;
/*       */     public static final int kPositionGroup = 2;
/*       */     public static final int kPositionstart_key = 27;
/*       */     public static final int kPositionstart_inclusive = 28;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final int getMultiqueryIndex()
/*       */     {
/*  5688 */       return this.multiquery_index_;
/*       */     }
/*       */     public final boolean hasMultiqueryIndex() {
/*  5691 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public CompiledCursor clearMultiqueryIndex() {
/*  5694 */       this.optional_0_ &= -2;
/*  5695 */       this.multiquery_index_ = 0;
/*  5696 */       return this;
/*       */     }
/*       */     public CompiledCursor setMultiqueryIndex(int x) {
/*  5699 */       this.optional_0_ |= 1;
/*  5700 */       this.multiquery_index_ = x;
/*  5701 */       return this;
/*       */     }
/*       */ 
/*       */     public final int positionSize()
/*       */     {
/*  5706 */       return this.position_ != null ? this.position_.size() : 0;
/*       */     }
/*       */     public final Position getPosition(int i) {
/*  5709 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.position_ != null ? this.position_.size() : 0)); } else throw new AssertionError();
/*  5710 */       return (Position)this.position_.get(i);
/*       */     }
/*       */     public CompiledCursor clearPosition() {
/*  5713 */       if (this.position_ != null) this.position_.clear();
/*  5714 */       return this;
/*       */     }
/*       */     public Position getMutablePosition(int i) {
/*  5717 */       assert ((i >= 0) && (this.position_ != null) && (i < this.position_.size()));
/*  5718 */       return (Position)this.position_.get(i);
/*       */     }
/*       */     public Position addPosition() {
/*  5721 */       Position v = new Position();
/*  5722 */       if (this.position_ == null) this.position_ = new ArrayList(4);
/*  5723 */       this.position_.add(v);
/*  5724 */       return v;
/*       */     }
/*       */     public Position addPosition(Position v) {
/*  5727 */       if (this.position_ == null) this.position_ = new ArrayList(4);
/*  5728 */       this.position_.add(v);
/*  5729 */       return v;
/*       */     }
/*       */     public Position insertPosition(int i, Position v) {
/*  5732 */       if (this.position_ == null) this.position_ = new ArrayList(4);
/*  5733 */       this.position_.add(i, v);
/*  5734 */       return v;
/*       */     }
/*       */     public Position removePosition(int i) {
/*  5737 */       return (Position)this.position_.remove(i);
/*       */     }
/*       */     public final Iterator<Position> positionIterator() {
/*  5740 */       if (this.position_ == null) {
/*  5741 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  5743 */       return this.position_.iterator();
/*       */     }
/*       */     public final List<Position> positions() {
/*  5746 */       return ProtocolSupport.unmodifiableList(this.position_);
/*       */     }
/*       */     public final List<Position> mutablePositions() {
/*  5749 */       if (this.position_ == null) this.position_ = new ArrayList(4);
/*  5750 */       return this.position_;
/*       */     }
/*       */ 
/*       */     public CompiledCursor mergeFrom(CompiledCursor that)
/*       */     {
/*  5757 */       assert (that != this);
/*  5758 */       int this_t0 = this.optional_0_;
/*  5759 */       int that_t0 = that.optional_0_;
/*       */ 
/*  5761 */       if ((that_t0 & 0x1) != 0) {
/*  5762 */         this_t0 |= 1;
/*  5763 */         this.multiquery_index_ = that.multiquery_index_;
/*       */       }
/*       */ 
/*  5766 */       if (that.position_ != null) {
/*  5767 */         for (Position v : that.position_) {
/*  5768 */           addPosition().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  5772 */       if (that.uninterpreted != null) {
/*  5773 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  5775 */       this.optional_0_ = this_t0;
/*  5776 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(CompiledCursor that) {
/*  5780 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(CompiledCursor that) {
/*  5784 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(CompiledCursor that, boolean ignoreUninterpreted) {
/*  5788 */       if (that == null) return false;
/*  5789 */       if (that == this) return true;
/*  5790 */       int this_t0 = this.optional_0_;
/*  5791 */       int that_t0 = that.optional_0_;
/*  5792 */       if (this_t0 != that_t0) return false;
/*       */ 
/*  5794 */       if (((this_t0 & 0x1) != 0) && 
/*  5795 */         (this.multiquery_index_ != that.multiquery_index_)) return false;
/*  5799 */       int n;
/*  5799 */       if ((n = this.position_ != null ? this.position_.size() : 0) != (that.position_ != null ? that.position_.size() : 0)) return false;
/*  5800 */       for (int i = 0; i < n; i++) {
/*  5801 */         if (!((Position)this.position_.get(i)).equals((Position)that.position_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  5804 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  5809 */       return ((that instanceof CompiledCursor)) && (equals((CompiledCursor)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  5813 */       int hash = -1596561824;
/*       */ 
/*  5815 */       int this_t0 = this.optional_0_;
/*  5816 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.multiquery_index_ : -113);
/*       */ 
/*  5818 */       hash *= 31;
/*  5819 */       int i = 0; for (int n = this.position_ != null ? this.position_.size() : 0; i < n; i++) {
/*  5820 */         hash = hash * 31 + ((Position)this.position_.get(i)).hashCode();
/*       */       }
/*  5822 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  5823 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  5825 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized()
/*       */     {
/*  5830 */       if (this.position_ != null) {
/*  5831 */         for (Position v : this.position_) {
/*  5832 */           if (!v.isInitialized()) {
/*  5833 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*  5837 */       return true;
/*       */     }
/*       */ 
/*       */     public int encodingSize() {
/*  5841 */       int n = 0;
/*       */       int m;
/*  5844 */       n += (m = this.position_ != null ? this.position_.size() : 0);
/*  5845 */       for (int i = 0; i < m; i++) {
/*  5846 */         n += ((Position)this.position_.get(i)).encodingSize();
/*       */       }
/*  5848 */       int this_t0 = this.optional_0_;
/*  5849 */       if ((this_t0 & 0x1) != 0)
/*       */       {
/*  5851 */         n += 1 + Protocol.varLongSize(this.multiquery_index_);
/*       */       }
/*       */ 
/*  5854 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  5860 */       int n = 11;
/*       */       int m;
/*  5863 */       n += (m = this.position_ != null ? this.position_.size() : 0);
/*  5864 */       for (int i = 0; i < m; i++) {
/*  5865 */         n += ((Position)this.position_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/*  5868 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  5873 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  5877 */       this.optional_0_ = 0;
/*  5878 */       this.multiquery_index_ = 0;
/*  5879 */       if (this.position_ != null) this.position_.clear();
/*  5880 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public CompiledCursor newInstance() {
/*  5884 */       return new CompiledCursor();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  5888 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  5918 */       int this_t0 = this.optional_0_;
/*  5919 */       if ((this_t0 & 0x1) != 0) {
/*  5920 */         sink.putByte(8);
/*  5921 */         sink.putVarLong(this.multiquery_index_);
/*       */       }
/*       */ 
/*  5924 */       int i = 0; for (int m = this.position_ != null ? this.position_.size() : 0; i < m; i++) {
/*  5925 */         Position v = (Position)this.position_.get(i);
/*  5926 */         sink.putByte(19);
/*  5927 */         v.outputTo(sink);
/*       */       }
/*       */ 
/*  5930 */       if (this.uninterpreted != null)
/*  5931 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  5936 */       boolean result = true;
/*  5937 */       int this_t0 = this.optional_0_;
/*       */ 
/*  5939 */       while (source.hasRemaining()) {
/*  5940 */         int tt = source.getVarInt();
/*  5941 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  5945 */           result = false;
/*  5946 */           break;
/*       */         case 8:
/*  5949 */           this.multiquery_index_ = source.getVarInt();
/*  5950 */           this_t0 |= 1;
/*  5951 */           break;
/*       */         case 19:
/*  5954 */           if (addPosition().merge(source)) break; result = false; break;
/*       */         default:
/*  5957 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  5962 */       this.optional_0_ = this_t0;
/*  5963 */       return result;
/*       */     }
/*       */ 
/*       */     public CompiledCursor getDefaultInstanceForType()
/*       */     {
/*  5968 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final CompiledCursor getDefaultInstance() {
/*  5972 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public CompiledCursor freeze()
/*       */     {
/*  6032 */       this.position_ = ProtocolSupport.freezeMessages(this.position_);
/*  6033 */       return this;
/*       */     }
/*       */ 
/*       */     public CompiledCursor unfreeze() {
/*  6037 */       this.position_ = ProtocolSupport.unfreezeMessages(this.position_);
/*  6038 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  6042 */       return ProtocolSupport.isFrozenMessages(this.position_);
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*  6045 */       if (this.uninterpreted == null) {
/*  6046 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  6048 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  5976 */       IMMUTABLE_DEFAULT_INSTANCE = new CompiledCursor()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.CompiledCursor clearMultiqueryIndex()
/*       */         {
/*  5984 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledCursor setMultiqueryIndex(int x) {
/*  5987 */           ProtocolSupport.unsupportedOperation();
/*  5988 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledCursor clearPosition()
/*       */         {
/*  5993 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledCursor.Position getMutablePosition(int i) {
/*  5996 */           return (DatastorePb.CompiledCursor.Position)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledCursor.Position addPosition() {
/*  5999 */           return (DatastorePb.CompiledCursor.Position)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledCursor.Position addPosition(DatastorePb.CompiledCursor.Position v) {
/*  6002 */           return (DatastorePb.CompiledCursor.Position)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledCursor.Position insertPosition(int i, DatastorePb.CompiledCursor.Position v) {
/*  6005 */           return (DatastorePb.CompiledCursor.Position)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledCursor.Position removePosition(int i) {
/*  6008 */           return (DatastorePb.CompiledCursor.Position)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledCursor mergeFrom(DatastorePb.CompiledCursor that) {
/*  6012 */           ProtocolSupport.unsupportedOperation();
/*  6013 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  6016 */           ProtocolSupport.unsupportedOperation();
/*  6017 */           return false;
/*       */         }
/*       */         public DatastorePb.CompiledCursor freeze() {
/*  6020 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledCursor unfreeze() {
/*  6023 */           ProtocolSupport.unsupportedOperation();
/*  6024 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  6027 */           return true;
/*       */         }
/*       */       };
/*  6056 */       text = new String[29];
/*       */ 
/*  6058 */       text[0] = "ErrorCode";
/*  6059 */       text[1] = "multiquery_index";
/*  6060 */       text[2] = "Position";
/*  6061 */       text[27] = "start_key";
/*  6062 */       text[28] = "start_inclusive";
/*       */ 
/*  6065 */       types = new int[29];
/*       */ 
/*  6067 */       Arrays.fill(types, 6);
/*  6068 */       types[0] = 0;
/*  6069 */       types[1] = 0;
/*  6070 */       types[2] = 3;
/*  6071 */       types[27] = 2;
/*  6072 */       types[28] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  5892 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompiledCursor.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("multiquery_index", "multiquery_index", 1, 0, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("Position", "position", 2, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, DatastorePb.CompiledCursor.Position.class) });
/*       */     }
/*       */ 
/*       */     public static class Position extends ProtocolMessage<Position>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*  5355 */       private byte[] start_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  5356 */       private boolean start_inclusive_ = true;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final Position IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final byte[] getStartKeyAsBytes()
/*       */       {
/*  5362 */         return this.start_key_;
/*       */       }
/*       */       public final boolean hasStartKey() {
/*  5365 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public Position clearStartKey() {
/*  5368 */         this.optional_0_ &= -2;
/*  5369 */         this.start_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  5370 */         return this;
/*       */       }
/*       */       public Position setStartKeyAsBytes(byte[] x) {
/*  5373 */         this.optional_0_ |= 1;
/*  5374 */         this.start_key_ = x;
/*  5375 */         return this;
/*       */       }
/*       */       public final String getStartKey() {
/*  5378 */         return ProtocolSupport.toStringUtf8(this.start_key_);
/*       */       }
/*       */       public Position setStartKey(String v) {
/*  5381 */         if (v == null) throw new NullPointerException();
/*  5382 */         this.optional_0_ |= 1;
/*  5383 */         this.start_key_ = ProtocolSupport.toBytesUtf8(v);
/*  5384 */         return this;
/*       */       }
/*       */       public final String getStartKey(Charset cs) {
/*  5387 */         return ProtocolSupport.toString(this.start_key_, cs);
/*       */       }
/*       */       public Position setStartKey(String v, Charset cs) {
/*  5390 */         if (v == null) throw new NullPointerException();
/*  5391 */         this.optional_0_ |= 1;
/*  5392 */         this.start_key_ = ProtocolSupport.toBytes(v, cs);
/*  5393 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isStartInclusive()
/*       */       {
/*  5398 */         return this.start_inclusive_;
/*       */       }
/*       */       public final boolean hasStartInclusive() {
/*  5401 */         return (this.optional_0_ & 0x2) != 0;
/*       */       }
/*       */       public Position clearStartInclusive() {
/*  5404 */         this.optional_0_ &= -3;
/*  5405 */         this.start_inclusive_ = true;
/*  5406 */         return this;
/*       */       }
/*       */       public Position setStartInclusive(boolean x) {
/*  5409 */         this.optional_0_ |= 2;
/*  5410 */         this.start_inclusive_ = x;
/*  5411 */         return this;
/*       */       }
/*       */ 
/*       */       public Position mergeFrom(Position that)
/*       */       {
/*  5418 */         assert (that != this);
/*  5419 */         int this_t0 = this.optional_0_;
/*  5420 */         int that_t0 = that.optional_0_;
/*       */ 
/*  5422 */         if ((that_t0 & 0x1) != 0) {
/*  5423 */           this_t0 |= 1;
/*  5424 */           this.start_key_ = that.start_key_;
/*       */         }
/*       */ 
/*  5427 */         if ((that_t0 & 0x2) != 0) {
/*  5428 */           this_t0 |= 2;
/*  5429 */           this.start_inclusive_ = that.start_inclusive_;
/*       */         }
/*       */ 
/*  5432 */         if (that.uninterpreted != null) {
/*  5433 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*  5435 */         this.optional_0_ = this_t0;
/*  5436 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(Position that) {
/*  5440 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(Position that) {
/*  5444 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(Position that, boolean ignoreUninterpreted) {
/*  5448 */         if (that == null) return false;
/*  5449 */         if (that == this) return true;
/*  5450 */         int this_t0 = this.optional_0_;
/*  5451 */         int that_t0 = that.optional_0_;
/*  5452 */         if (this_t0 != that_t0) return false;
/*       */ 
/*  5454 */         if (((this_t0 & 0x1) != 0) && 
/*  5455 */           (!Arrays.equals(this.start_key_, that.start_key_))) return false;
/*       */ 
/*  5458 */         if (((this_t0 & 0x2) != 0) && 
/*  5459 */           (this.start_inclusive_ != that.start_inclusive_)) return false;
/*       */ 
/*  5462 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*  5467 */         return ((that instanceof Position)) && (equals((Position)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*  5471 */         int hash = -931617623;
/*       */ 
/*  5473 */         int this_t0 = this.optional_0_;
/*  5474 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.start_key_) : -113);
/*       */ 
/*  5476 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? 1237 : this.start_inclusive_ ? 1231 : -113);
/*  5477 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  5478 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*  5480 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized() {
/*  5484 */         return true;
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*  5489 */         int n = 1;
/*  5490 */         int this_t0 = this.optional_0_;
/*  5491 */         if ((this_t0 & 0x3) != 0) {
/*  5492 */           if ((this_t0 & 0x1) != 0)
/*       */           {
/*  5494 */             n += 2 + Protocol.stringSize(this.start_key_.length);
/*       */           }
/*  5496 */           if ((this_t0 & 0x2) != 0)
/*       */           {
/*  5498 */             n += 3;
/*       */           }
/*       */         }
/*       */ 
/*  5502 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*  5509 */         int n = 4;
/*  5510 */         int this_t0 = this.optional_0_;
/*  5511 */         if ((this_t0 & 0x1) != 0)
/*       */         {
/*  5513 */           n += 7 + this.start_key_.length;
/*       */         }
/*       */ 
/*  5516 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*  5521 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*  5525 */         this.optional_0_ = 0;
/*  5526 */         this.start_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  5527 */         this.start_inclusive_ = true;
/*  5528 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public Position newInstance() {
/*  5532 */         return new Position();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*  5536 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*  5551 */         int this_t0 = this.optional_0_;
/*  5552 */         if ((this_t0 & 0x1) != 0) {
/*  5553 */           sink.putByte(-38);
/*  5554 */           sink.putByte(1);
/*  5555 */           sink.putPrefixedData(this.start_key_);
/*       */         }
/*       */ 
/*  5558 */         if ((this_t0 & 0x2) != 0) {
/*  5559 */           sink.putByte(-32);
/*  5560 */           sink.putByte(1);
/*  5561 */           sink.putBoolean(this.start_inclusive_);
/*       */         }
/*       */ 
/*  5564 */         if (this.uninterpreted != null) {
/*  5565 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*  5568 */         sink.putByte(20);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*  5572 */         boolean result = true;
/*  5573 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*  5576 */           int tt = source.getVarInt();
/*  5577 */           switch (tt)
/*       */           {
/*       */           case 20:
/*  5580 */             break;
/*       */           case 0:
/*  5584 */             result = false;
/*  5585 */             break;
/*       */           case 218:
/*  5588 */             this.start_key_ = source.getPrefixedData();
/*  5589 */             this_t0 |= 1;
/*  5590 */             break;
/*       */           case 224:
/*  5593 */             this.start_inclusive_ = source.getBoolean();
/*  5594 */             this_t0 |= 2;
/*  5595 */             break;
/*       */           default:
/*  5597 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*  5602 */         this.optional_0_ = this_t0;
/*  5603 */         return result;
/*       */       }
/*       */ 
/*       */       public Position getDefaultInstanceForType()
/*       */       {
/*  5608 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final Position getDefaultInstance() {
/*  5612 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public Position freeze()
/*       */       {
/*  5669 */         this.start_key_ = ProtocolSupport.freezeString(this.start_key_);
/*  5670 */         return this;
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*  5673 */         if (this.uninterpreted == null) {
/*  5674 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*  5676 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  5616 */         IMMUTABLE_DEFAULT_INSTANCE = new Position()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.CompiledCursor.Position clearStartKey()
/*       */           {
/*  5624 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledCursor.Position setStartKeyAsBytes(byte[] x) {
/*  5627 */             ProtocolSupport.unsupportedOperation();
/*  5628 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledCursor.Position setStartKey(String v) {
/*  5631 */             ProtocolSupport.unsupportedOperation();
/*  5632 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledCursor.Position setStartKey(String v, Charset cs) {
/*  5635 */             ProtocolSupport.unsupportedOperation();
/*  5636 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledCursor.Position clearStartInclusive()
/*       */           {
/*  5641 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledCursor.Position setStartInclusive(boolean x) {
/*  5644 */             ProtocolSupport.unsupportedOperation();
/*  5645 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledCursor.Position mergeFrom(DatastorePb.CompiledCursor.Position that) {
/*  5649 */             ProtocolSupport.unsupportedOperation();
/*  5650 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*  5653 */             ProtocolSupport.unsupportedOperation();
/*  5654 */             return false;
/*       */           }
/*       */           public DatastorePb.CompiledCursor.Position freeze() {
/*  5657 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledCursor.Position unfreeze() {
/*  5660 */             ProtocolSupport.unsupportedOperation();
/*  5661 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*  5664 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*  5540 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompiledCursor.Position.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("start_key", "start_key", 27, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("start_inclusive", "start_inclusive", 28, 1, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL) });
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class CompiledQuery extends ProtocolMessage<CompiledQuery>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  4607 */     private PrimaryScan primaryscan_ = new PrimaryScan();
/*  4608 */     private List<MergeJoinScan> mergejoinscan_ = null;
/*  4609 */     private int offset_ = 0;
/*  4610 */     private int limit_ = 0;
/*  4611 */     private boolean keys_only_ = false;
/*  4612 */     private EntityFilter entityfilter_ = null;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final CompiledQuery IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kPrimaryScanGroup = 1;
/*       */     public static final int kPrimaryScanindex_name = 2;
/*       */     public static final int kPrimaryScanstart_key = 3;
/*       */     public static final int kPrimaryScanstart_inclusive = 4;
/*       */     public static final int kPrimaryScanend_key = 5;
/*       */     public static final int kPrimaryScanend_inclusive = 6;
/*       */     public static final int kPrimaryScanend_unapplied_log_timestamp_us = 19;
/*       */     public static final int kMergeJoinScanGroup = 7;
/*       */     public static final int kMergeJoinScanindex_name = 8;
/*       */     public static final int kMergeJoinScanprefix_value = 9;
/*       */     public static final int koffset = 10;
/*       */     public static final int klimit = 11;
/*       */     public static final int kkeys_only = 12;
/*       */     public static final int kEntityFilterGroup = 13;
/*       */     public static final int kEntityFilterdistinct = 14;
/*       */     public static final int kEntityFilterkind = 17;
/*       */     public static final int kEntityFilterancestor = 18;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final PrimaryScan getPrimaryScan()
/*       */     {
/*  4618 */       return this.primaryscan_;
/*       */     }
/*       */     public final boolean hasPrimaryScan() {
/*  4621 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public CompiledQuery clearPrimaryScan() {
/*  4624 */       this.optional_0_ &= -2;
/*  4625 */       this.primaryscan_.clear();
/*  4626 */       return this;
/*       */     }
/*       */     public CompiledQuery setPrimaryScan(PrimaryScan x) {
/*  4629 */       if (x == null) throw new NullPointerException();
/*  4630 */       this.optional_0_ |= 1;
/*  4631 */       this.primaryscan_ = x;
/*  4632 */       return this;
/*       */     }
/*       */     public PrimaryScan getMutablePrimaryScan() {
/*  4635 */       this.optional_0_ |= 1;
/*  4636 */       return this.primaryscan_;
/*       */     }
/*       */ 
/*       */     public final int mergeJoinScanSize()
/*       */     {
/*  4641 */       return this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0;
/*       */     }
/*       */     public final MergeJoinScan getMergeJoinScan(int i) {
/*  4644 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0)); } else throw new AssertionError();
/*  4645 */       return (MergeJoinScan)this.mergejoinscan_.get(i);
/*       */     }
/*       */     public CompiledQuery clearMergeJoinScan() {
/*  4648 */       if (this.mergejoinscan_ != null) this.mergejoinscan_.clear();
/*  4649 */       return this;
/*       */     }
/*       */     public MergeJoinScan getMutableMergeJoinScan(int i) {
/*  4652 */       assert ((i >= 0) && (this.mergejoinscan_ != null) && (i < this.mergejoinscan_.size()));
/*  4653 */       return (MergeJoinScan)this.mergejoinscan_.get(i);
/*       */     }
/*       */     public MergeJoinScan addMergeJoinScan() {
/*  4656 */       MergeJoinScan v = new MergeJoinScan();
/*  4657 */       if (this.mergejoinscan_ == null) this.mergejoinscan_ = new ArrayList(4);
/*  4658 */       this.mergejoinscan_.add(v);
/*  4659 */       return v;
/*       */     }
/*       */     public MergeJoinScan addMergeJoinScan(MergeJoinScan v) {
/*  4662 */       if (this.mergejoinscan_ == null) this.mergejoinscan_ = new ArrayList(4);
/*  4663 */       this.mergejoinscan_.add(v);
/*  4664 */       return v;
/*       */     }
/*       */     public MergeJoinScan insertMergeJoinScan(int i, MergeJoinScan v) {
/*  4667 */       if (this.mergejoinscan_ == null) this.mergejoinscan_ = new ArrayList(4);
/*  4668 */       this.mergejoinscan_.add(i, v);
/*  4669 */       return v;
/*       */     }
/*       */     public MergeJoinScan removeMergeJoinScan(int i) {
/*  4672 */       return (MergeJoinScan)this.mergejoinscan_.remove(i);
/*       */     }
/*       */     public final Iterator<MergeJoinScan> mergeJoinScanIterator() {
/*  4675 */       if (this.mergejoinscan_ == null) {
/*  4676 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  4678 */       return this.mergejoinscan_.iterator();
/*       */     }
/*       */     public final List<MergeJoinScan> mergeJoinScans() {
/*  4681 */       return ProtocolSupport.unmodifiableList(this.mergejoinscan_);
/*       */     }
/*       */     public final List<MergeJoinScan> mutableMergeJoinScans() {
/*  4684 */       if (this.mergejoinscan_ == null) this.mergejoinscan_ = new ArrayList(4);
/*  4685 */       return this.mergejoinscan_;
/*       */     }
/*       */ 
/*       */     public final int getOffset()
/*       */     {
/*  4690 */       return this.offset_;
/*       */     }
/*       */     public final boolean hasOffset() {
/*  4693 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public CompiledQuery clearOffset() {
/*  4696 */       this.optional_0_ &= -3;
/*  4697 */       this.offset_ = 0;
/*  4698 */       return this;
/*       */     }
/*       */     public CompiledQuery setOffset(int x) {
/*  4701 */       this.optional_0_ |= 2;
/*  4702 */       this.offset_ = x;
/*  4703 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getLimit()
/*       */     {
/*  4708 */       return this.limit_;
/*       */     }
/*       */     public final boolean hasLimit() {
/*  4711 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public CompiledQuery clearLimit() {
/*  4714 */       this.optional_0_ &= -5;
/*  4715 */       this.limit_ = 0;
/*  4716 */       return this;
/*       */     }
/*       */     public CompiledQuery setLimit(int x) {
/*  4719 */       this.optional_0_ |= 4;
/*  4720 */       this.limit_ = x;
/*  4721 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isKeysOnly()
/*       */     {
/*  4726 */       return this.keys_only_;
/*       */     }
/*       */     public final boolean hasKeysOnly() {
/*  4729 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public CompiledQuery clearKeysOnly() {
/*  4732 */       this.optional_0_ &= -9;
/*  4733 */       this.keys_only_ = false;
/*  4734 */       return this;
/*       */     }
/*       */     public CompiledQuery setKeysOnly(boolean x) {
/*  4737 */       this.optional_0_ |= 8;
/*  4738 */       this.keys_only_ = x;
/*  4739 */       return this;
/*       */     }
/*       */ 
/*       */     public final EntityFilter getEntityFilter()
/*       */     {
/*  4744 */       if (this.entityfilter_ == null) {
/*  4745 */         return EntityFilter.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  4747 */       return this.entityfilter_;
/*       */     }
/*       */     public final boolean hasEntityFilter() {
/*  4750 */       return (this.optional_0_ & 0x10) != 0;
/*       */     }
/*       */     public CompiledQuery clearEntityFilter() {
/*  4753 */       this.optional_0_ &= -17;
/*  4754 */       if (this.entityfilter_ != null) this.entityfilter_.clear();
/*  4755 */       return this;
/*       */     }
/*       */     public CompiledQuery setEntityFilter(EntityFilter x) {
/*  4758 */       if (x == null) throw new NullPointerException();
/*  4759 */       this.optional_0_ |= 16;
/*  4760 */       this.entityfilter_ = x;
/*  4761 */       return this;
/*       */     }
/*       */     public EntityFilter getMutableEntityFilter() {
/*  4764 */       this.optional_0_ |= 16;
/*  4765 */       if (this.entityfilter_ == null) this.entityfilter_ = new EntityFilter();
/*  4766 */       return this.entityfilter_;
/*       */     }
/*       */ 
/*       */     public CompiledQuery mergeFrom(CompiledQuery that)
/*       */     {
/*  4773 */       assert (that != this);
/*  4774 */       int this_t0 = this.optional_0_;
/*  4775 */       int that_t0 = that.optional_0_;
/*       */ 
/*  4777 */       if ((that_t0 & 0x1) != 0) {
/*  4778 */         this_t0 |= 1;
/*  4779 */         PrimaryScan v = this.primaryscan_;
/*  4780 */         v.mergeFrom(that.primaryscan_);
/*       */       }
/*       */ 
/*  4783 */       if (that.mergejoinscan_ != null) {
/*  4784 */         for (MergeJoinScan v : that.mergejoinscan_) {
/*  4785 */           addMergeJoinScan().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  4789 */       if ((that_t0 & 0x2) != 0) {
/*  4790 */         this_t0 |= 2;
/*  4791 */         this.offset_ = that.offset_;
/*       */       }
/*       */ 
/*  4794 */       if ((that_t0 & 0x4) != 0) {
/*  4795 */         this_t0 |= 4;
/*  4796 */         this.limit_ = that.limit_;
/*       */       }
/*       */ 
/*  4799 */       if ((that_t0 & 0x8) != 0) {
/*  4800 */         this_t0 |= 8;
/*  4801 */         this.keys_only_ = that.keys_only_;
/*       */       }
/*       */ 
/*  4804 */       if ((that_t0 & 0x10) != 0) {
/*  4805 */         this_t0 |= 16;
/*  4806 */         EntityFilter v = this.entityfilter_;
/*  4807 */         if (v == null) this.entityfilter_ = (v = new EntityFilter());
/*  4808 */         v.mergeFrom(that.entityfilter_);
/*       */       }
/*       */ 
/*  4811 */       if (that.uninterpreted != null) {
/*  4812 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  4814 */       this.optional_0_ = this_t0;
/*  4815 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(CompiledQuery that) {
/*  4819 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(CompiledQuery that) {
/*  4823 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(CompiledQuery that, boolean ignoreUninterpreted) {
/*  4827 */       if (that == null) return false;
/*  4828 */       if (that == this) return true;
/*  4829 */       int this_t0 = this.optional_0_;
/*  4830 */       int that_t0 = that.optional_0_;
/*  4831 */       if (this_t0 != that_t0) return false;
/*       */ 
/*  4833 */       if (((this_t0 & 0x1) != 0) && 
/*  4834 */         (!this.primaryscan_.equals(that.primaryscan_, ignoreUninterpreted))) return false;
/*  4838 */       int n;
/*  4838 */       if ((n = this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0) != (that.mergejoinscan_ != null ? that.mergejoinscan_.size() : 0)) return false;
/*  4839 */       for (int i = 0; i < n; i++) {
/*  4840 */         if (!((MergeJoinScan)this.mergejoinscan_.get(i)).equals((MergeJoinScan)that.mergejoinscan_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  4843 */       if (((this_t0 & 0x2) != 0) && 
/*  4844 */         (this.offset_ != that.offset_)) return false;
/*       */ 
/*  4847 */       if (((this_t0 & 0x4) != 0) && 
/*  4848 */         (this.limit_ != that.limit_)) return false;
/*       */ 
/*  4851 */       if (((this_t0 & 0x8) != 0) && 
/*  4852 */         (this.keys_only_ != that.keys_only_)) return false;
/*       */ 
/*  4855 */       if (((this_t0 & 0x10) != 0) && 
/*  4856 */         (!this.entityfilter_.equals(that.entityfilter_, ignoreUninterpreted))) return false;
/*       */ 
/*  4859 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  4864 */       return ((that instanceof CompiledQuery)) && (equals((CompiledQuery)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  4868 */       int hash = -2115295705;
/*       */ 
/*  4870 */       int this_t0 = this.optional_0_;
/*  4871 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.primaryscan_.hashCode() : -113);
/*       */ 
/*  4873 */       hash *= 31;
/*  4874 */       int i = 0; for (int n = this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0; i < n; i++) {
/*  4875 */         hash = hash * 31 + ((MergeJoinScan)this.mergejoinscan_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  4878 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.offset_ : -113);
/*       */ 
/*  4880 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.limit_ : -113);
/*       */ 
/*  4882 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? 1237 : this.keys_only_ ? 1231 : -113);
/*       */ 
/*  4884 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? this.entityfilter_.hashCode() : -113);
/*  4885 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  4886 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  4888 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*  4892 */       int this_t0 = this.optional_0_;
/*  4893 */       if ((this_t0 & 0x9) != 9)
/*       */       {
/*  4895 */         return (this_t0 & 0x1) != 0;
/*       */       }
/*       */ 
/*  4900 */       if (!this.primaryscan_.isInitialized()) {
/*  4901 */         return false;
/*       */       }
/*       */ 
/*  4904 */       if (this.mergejoinscan_ != null) {
/*  4905 */         for (MergeJoinScan v : this.mergejoinscan_) {
/*  4906 */           if (!v.isInitialized()) {
/*  4907 */             return false;
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  4914 */       return ((this_t0 & 0x10) == 0) || 
/*  4913 */         (this.entityfilter_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*  4923 */       int n = 3 + this.primaryscan_.encodingSize();
/*       */       int m;
/*  4926 */       n += (m = this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0);
/*  4927 */       for (int i = 0; i < m; i++) {
/*  4928 */         n += ((MergeJoinScan)this.mergejoinscan_.get(i)).encodingSize();
/*       */       }
/*  4930 */       int this_t0 = this.optional_0_;
/*  4931 */       if ((this_t0 & 0x16) != 0) {
/*  4932 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  4934 */           n += 1 + Protocol.varLongSize(this.offset_);
/*       */         }
/*  4936 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/*  4938 */           n += 1 + Protocol.varLongSize(this.limit_);
/*       */         }
/*  4940 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/*  4942 */           n += 1 + this.entityfilter_.encodingSize();
/*       */         }
/*       */       }
/*       */ 
/*  4946 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  4955 */       int n = 25 + this.primaryscan_.maxEncodingSize();
/*       */       int m;
/*  4958 */       n += (m = this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0);
/*  4959 */       for (int i = 0; i < m; i++) {
/*  4960 */         n += ((MergeJoinScan)this.mergejoinscan_.get(i)).maxEncodingSize();
/*       */       }
/*  4962 */       int this_t0 = this.optional_0_;
/*  4963 */       if ((this_t0 & 0x10) != 0)
/*       */       {
/*  4965 */         n += 1 + this.entityfilter_.maxEncodingSize();
/*       */       }
/*       */ 
/*  4968 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  4973 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  4977 */       this.optional_0_ = 0;
/*  4978 */       this.primaryscan_.clear();
/*  4979 */       if (this.mergejoinscan_ != null) this.mergejoinscan_.clear();
/*  4980 */       this.offset_ = 0;
/*  4981 */       this.limit_ = 0;
/*  4982 */       this.keys_only_ = false;
/*  4983 */       if (this.entityfilter_ != null) this.entityfilter_.clear();
/*  4984 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public CompiledQuery newInstance() {
/*  4988 */       return new CompiledQuery();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  4992 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  5062 */       sink.putByte(11);
/*  5063 */       this.primaryscan_.outputTo(sink);
/*       */ 
/*  5065 */       int i = 0; for (int m = this.mergejoinscan_ != null ? this.mergejoinscan_.size() : 0; i < m; i++) {
/*  5066 */         MergeJoinScan v = (MergeJoinScan)this.mergejoinscan_.get(i);
/*  5067 */         sink.putByte(59);
/*  5068 */         v.outputTo(sink);
/*       */       }
/*       */ 
/*  5071 */       int this_t0 = this.optional_0_;
/*  5072 */       if ((this_t0 & 0x2) != 0) {
/*  5073 */         sink.putByte(80);
/*  5074 */         sink.putVarLong(this.offset_);
/*       */       }
/*       */ 
/*  5077 */       if ((this_t0 & 0x4) != 0) {
/*  5078 */         sink.putByte(88);
/*  5079 */         sink.putVarLong(this.limit_);
/*       */       }
/*       */ 
/*  5082 */       sink.putByte(96);
/*  5083 */       sink.putBoolean(this.keys_only_);
/*       */ 
/*  5085 */       if ((this_t0 & 0x10) != 0) {
/*  5086 */         sink.putByte(107);
/*  5087 */         this.entityfilter_.outputTo(sink);
/*       */       }
/*       */ 
/*  5090 */       if (this.uninterpreted != null)
/*  5091 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  5096 */       boolean result = true;
/*  5097 */       int this_t0 = this.optional_0_;
/*       */ 
/*  5099 */       while (source.hasRemaining()) {
/*  5100 */         int tt = source.getVarInt();
/*  5101 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  5105 */           result = false;
/*  5106 */           break;
/*       */         case 11:
/*  5109 */           if (!this.primaryscan_.merge(source)) { result = false; break label246; }
/*  5110 */           this_t0 |= 1;
/*  5111 */           break;
/*       */         case 59:
/*  5114 */           if (addMergeJoinScan().merge(source)) break; result = false; break;
/*       */         case 80:
/*  5118 */           this.offset_ = source.getVarInt();
/*  5119 */           this_t0 |= 2;
/*  5120 */           break;
/*       */         case 88:
/*  5123 */           this.limit_ = source.getVarInt();
/*  5124 */           this_t0 |= 4;
/*  5125 */           break;
/*       */         case 96:
/*  5128 */           this.keys_only_ = source.getBoolean();
/*  5129 */           this_t0 |= 8;
/*  5130 */           break;
/*       */         case 107:
/*  5133 */           EntityFilter v13 = this.entityfilter_;
/*  5134 */           if (v13 == null) this.entityfilter_ = (v13 = new EntityFilter());
/*  5135 */           if (!v13.merge(source)) { result = false; break label246; }
/*  5136 */           this_t0 |= 16;
/*  5137 */           break;
/*       */         default:
/*  5139 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  5144 */       label246: this.optional_0_ = this_t0;
/*  5145 */       return result;
/*       */     }
/*       */ 
/*       */     public CompiledQuery getDefaultInstanceForType()
/*       */     {
/*  5150 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final CompiledQuery getDefaultInstance() {
/*  5154 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public CompiledQuery freeze()
/*       */     {
/*  5256 */       this.primaryscan_.freeze();
/*  5257 */       this.mergejoinscan_ = ProtocolSupport.freezeMessages(this.mergejoinscan_);
/*  5258 */       if (this.entityfilter_ != null) this.entityfilter_.freeze();
/*  5259 */       return this;
/*       */     }
/*       */ 
/*       */     public CompiledQuery unfreeze() {
/*  5263 */       this.primaryscan_.unfreeze();
/*  5264 */       this.mergejoinscan_ = ProtocolSupport.unfreezeMessages(this.mergejoinscan_);
/*  5265 */       if (this.entityfilter_ != null) this.entityfilter_.unfreeze();
/*  5266 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  5270 */       return (this.primaryscan_.isFrozen()) || (ProtocolSupport.isFrozenMessages(this.mergejoinscan_)) || ((this.entityfilter_ != null) && (this.entityfilter_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/*  5275 */       if (this.uninterpreted == null) {
/*  5276 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  5278 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  5158 */       IMMUTABLE_DEFAULT_INSTANCE = new CompiledQuery()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.CompiledQuery clearPrimaryScan()
/*       */         {
/*  5166 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery setPrimaryScan(DatastorePb.CompiledQuery.PrimaryScan x) {
/*  5169 */           ProtocolSupport.unsupportedOperation();
/*  5170 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery.PrimaryScan getMutablePrimaryScan() {
/*  5173 */           return (DatastorePb.CompiledQuery.PrimaryScan)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledQuery clearMergeJoinScan()
/*       */         {
/*  5178 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery.MergeJoinScan getMutableMergeJoinScan(int i) {
/*  5181 */           return (DatastorePb.CompiledQuery.MergeJoinScan)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledQuery.MergeJoinScan addMergeJoinScan() {
/*  5184 */           return (DatastorePb.CompiledQuery.MergeJoinScan)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledQuery.MergeJoinScan addMergeJoinScan(DatastorePb.CompiledQuery.MergeJoinScan v) {
/*  5187 */           return (DatastorePb.CompiledQuery.MergeJoinScan)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledQuery.MergeJoinScan insertMergeJoinScan(int i, DatastorePb.CompiledQuery.MergeJoinScan v) {
/*  5190 */           return (DatastorePb.CompiledQuery.MergeJoinScan)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.CompiledQuery.MergeJoinScan removeMergeJoinScan(int i) {
/*  5193 */           return (DatastorePb.CompiledQuery.MergeJoinScan)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledQuery clearOffset()
/*       */         {
/*  5198 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery setOffset(int x) {
/*  5201 */           ProtocolSupport.unsupportedOperation();
/*  5202 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledQuery clearLimit()
/*       */         {
/*  5207 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery setLimit(int x) {
/*  5210 */           ProtocolSupport.unsupportedOperation();
/*  5211 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledQuery clearKeysOnly()
/*       */         {
/*  5216 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery setKeysOnly(boolean x) {
/*  5219 */           ProtocolSupport.unsupportedOperation();
/*  5220 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledQuery clearEntityFilter()
/*       */         {
/*  5225 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery setEntityFilter(DatastorePb.CompiledQuery.EntityFilter x) {
/*  5228 */           ProtocolSupport.unsupportedOperation();
/*  5229 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery.EntityFilter getMutableEntityFilter() {
/*  5232 */           return (DatastorePb.CompiledQuery.EntityFilter)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.CompiledQuery mergeFrom(DatastorePb.CompiledQuery that) {
/*  5236 */           ProtocolSupport.unsupportedOperation();
/*  5237 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  5240 */           ProtocolSupport.unsupportedOperation();
/*  5241 */           return false;
/*       */         }
/*       */         public DatastorePb.CompiledQuery freeze() {
/*  5244 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledQuery unfreeze() {
/*  5247 */           ProtocolSupport.unsupportedOperation();
/*  5248 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  5251 */           return true;
/*       */         }
/*       */       };
/*  5299 */       text = new String[20];
/*       */ 
/*  5301 */       text[0] = "ErrorCode";
/*  5302 */       text[1] = "PrimaryScan";
/*  5303 */       text[2] = "index_name";
/*  5304 */       text[3] = "start_key";
/*  5305 */       text[4] = "start_inclusive";
/*  5306 */       text[5] = "end_key";
/*  5307 */       text[6] = "end_inclusive";
/*  5308 */       text[7] = "MergeJoinScan";
/*  5309 */       text[8] = "index_name";
/*  5310 */       text[9] = "prefix_value";
/*  5311 */       text[10] = "offset";
/*  5312 */       text[11] = "limit";
/*  5313 */       text[12] = "keys_only";
/*  5314 */       text[13] = "EntityFilter";
/*  5315 */       text[14] = "distinct";
/*  5316 */       text[17] = "kind";
/*  5317 */       text[18] = "ancestor";
/*  5318 */       text[19] = "end_unapplied_log_timestamp_us";
/*       */ 
/*  5321 */       types = new int[20];
/*       */ 
/*  5323 */       Arrays.fill(types, 6);
/*  5324 */       types[0] = 0;
/*  5325 */       types[1] = 3;
/*  5326 */       types[2] = 2;
/*  5327 */       types[3] = 2;
/*  5328 */       types[4] = 0;
/*  5329 */       types[5] = 2;
/*  5330 */       types[6] = 0;
/*  5331 */       types[7] = 3;
/*  5332 */       types[8] = 2;
/*  5333 */       types[9] = 2;
/*  5334 */       types[10] = 0;
/*  5335 */       types[11] = 0;
/*  5336 */       types[12] = 0;
/*  5337 */       types[13] = 3;
/*  5338 */       types[14] = 0;
/*  5339 */       types[17] = 2;
/*  5340 */       types[18] = 2;
/*  5341 */       types[19] = 0;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  4996 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompiledQuery.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("PrimaryScan", "primaryscan", 1, 0, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REQUIRED, DatastorePb.CompiledQuery.PrimaryScan.class), new ProtocolType.FieldType("MergeJoinScan", "mergejoinscan", 7, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, DatastorePb.CompiledQuery.MergeJoinScan.class), new ProtocolType.FieldType("offset", "offset", 10, 1, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("limit", "limit", 11, 2, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("keys_only", "keys_only", 12, 3, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("EntityFilter", "entityfilter", 13, 4, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.OPTIONAL, DatastorePb.CompiledQuery.EntityFilter.class) });
/*       */     }
/*       */ 
/*       */     public static class EntityFilter extends ProtocolMessage<EntityFilter>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*  4184 */       private boolean distinct_ = false;
/*  4185 */       private byte[] kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  4186 */       private OnestoreEntity.Reference ancestor_ = null;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final EntityFilter IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final boolean isDistinct()
/*       */       {
/*  4192 */         return this.distinct_;
/*       */       }
/*       */       public final boolean hasDistinct() {
/*  4195 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public EntityFilter clearDistinct() {
/*  4198 */         this.optional_0_ &= -2;
/*  4199 */         this.distinct_ = false;
/*  4200 */         return this;
/*       */       }
/*       */       public EntityFilter setDistinct(boolean x) {
/*  4203 */         this.optional_0_ |= 1;
/*  4204 */         this.distinct_ = x;
/*  4205 */         return this;
/*       */       }
/*       */ 
/*       */       public final byte[] getKindAsBytes()
/*       */       {
/*  4210 */         return this.kind_;
/*       */       }
/*       */       public final boolean hasKind() {
/*  4213 */         return (this.optional_0_ & 0x2) != 0;
/*       */       }
/*       */       public EntityFilter clearKind() {
/*  4216 */         this.optional_0_ &= -3;
/*  4217 */         this.kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  4218 */         return this;
/*       */       }
/*       */       public EntityFilter setKindAsBytes(byte[] x) {
/*  4221 */         this.optional_0_ |= 2;
/*  4222 */         this.kind_ = x;
/*  4223 */         return this;
/*       */       }
/*       */       public final String getKind() {
/*  4226 */         return ProtocolSupport.toStringUtf8(this.kind_);
/*       */       }
/*       */       public EntityFilter setKind(String v) {
/*  4229 */         if (v == null) throw new NullPointerException();
/*  4230 */         this.optional_0_ |= 2;
/*  4231 */         this.kind_ = ProtocolSupport.toBytesUtf8(v);
/*  4232 */         return this;
/*       */       }
/*       */       public final String getKind(Charset cs) {
/*  4235 */         return ProtocolSupport.toString(this.kind_, cs);
/*       */       }
/*       */       public EntityFilter setKind(String v, Charset cs) {
/*  4238 */         if (v == null) throw new NullPointerException();
/*  4239 */         this.optional_0_ |= 2;
/*  4240 */         this.kind_ = ProtocolSupport.toBytes(v, cs);
/*  4241 */         return this;
/*       */       }
/*       */ 
/*       */       public final OnestoreEntity.Reference getAncestor()
/*       */       {
/*  4246 */         if (this.ancestor_ == null) {
/*  4247 */           return OnestoreEntity.Reference.IMMUTABLE_DEFAULT_INSTANCE;
/*       */         }
/*  4249 */         return this.ancestor_;
/*       */       }
/*       */       public final boolean hasAncestor() {
/*  4252 */         return (this.optional_0_ & 0x4) != 0;
/*       */       }
/*       */       public EntityFilter clearAncestor() {
/*  4255 */         this.optional_0_ &= -5;
/*  4256 */         if (this.ancestor_ != null) this.ancestor_.clear();
/*  4257 */         return this;
/*       */       }
/*       */       public EntityFilter setAncestor(OnestoreEntity.Reference x) {
/*  4260 */         if (x == null) throw new NullPointerException();
/*  4261 */         this.optional_0_ |= 4;
/*  4262 */         this.ancestor_ = x;
/*  4263 */         return this;
/*       */       }
/*       */       public OnestoreEntity.Reference getMutableAncestor() {
/*  4266 */         this.optional_0_ |= 4;
/*  4267 */         if (this.ancestor_ == null) this.ancestor_ = new OnestoreEntity.Reference();
/*  4268 */         return this.ancestor_;
/*       */       }
/*       */ 
/*       */       public EntityFilter mergeFrom(EntityFilter that)
/*       */       {
/*  4275 */         assert (that != this);
/*  4276 */         int this_t0 = this.optional_0_;
/*  4277 */         int that_t0 = that.optional_0_;
/*       */ 
/*  4279 */         if ((that_t0 & 0x1) != 0) {
/*  4280 */           this_t0 |= 1;
/*  4281 */           this.distinct_ = that.distinct_;
/*       */         }
/*       */ 
/*  4284 */         if ((that_t0 & 0x2) != 0) {
/*  4285 */           this_t0 |= 2;
/*  4286 */           this.kind_ = that.kind_;
/*       */         }
/*       */ 
/*  4289 */         if ((that_t0 & 0x4) != 0) {
/*  4290 */           this_t0 |= 4;
/*  4291 */           OnestoreEntity.Reference v = this.ancestor_;
/*  4292 */           if (v == null) this.ancestor_ = (v = new OnestoreEntity.Reference());
/*  4293 */           v.mergeFrom(that.ancestor_);
/*       */         }
/*       */ 
/*  4296 */         if (that.uninterpreted != null) {
/*  4297 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*  4299 */         this.optional_0_ = this_t0;
/*  4300 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(EntityFilter that) {
/*  4304 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(EntityFilter that) {
/*  4308 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(EntityFilter that, boolean ignoreUninterpreted) {
/*  4312 */         if (that == null) return false;
/*  4313 */         if (that == this) return true;
/*  4314 */         int this_t0 = this.optional_0_;
/*  4315 */         int that_t0 = that.optional_0_;
/*  4316 */         if (this_t0 != that_t0) return false;
/*       */ 
/*  4318 */         if (((this_t0 & 0x1) != 0) && 
/*  4319 */           (this.distinct_ != that.distinct_)) return false;
/*       */ 
/*  4322 */         if (((this_t0 & 0x2) != 0) && 
/*  4323 */           (!Arrays.equals(this.kind_, that.kind_))) return false;
/*       */ 
/*  4326 */         if (((this_t0 & 0x4) != 0) && 
/*  4327 */           (!this.ancestor_.equals(that.ancestor_, ignoreUninterpreted))) return false;
/*       */ 
/*  4330 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*  4335 */         return ((that instanceof EntityFilter)) && (equals((EntityFilter)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*  4339 */         int hash = -1222631282;
/*       */ 
/*  4341 */         int this_t0 = this.optional_0_;
/*  4342 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? 1237 : this.distinct_ ? 1231 : -113);
/*       */ 
/*  4344 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.kind_) : -113);
/*       */ 
/*  4346 */         hash = hash * 31 + ((this_t0 & 0x4) != 0 ? this.ancestor_.hashCode() : -113);
/*  4347 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  4348 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*  4350 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized()
/*       */       {
/*  4355 */         int this_t0 = this.optional_0_;
/*       */ 
/*  4358 */         return ((this_t0 & 0x4) == 0) || 
/*  4357 */           (this.ancestor_.isInitialized());
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*  4366 */         int n = 1;
/*  4367 */         int this_t0 = this.optional_0_;
/*  4368 */         if ((this_t0 & 0x7) != 0) {
/*  4369 */           if ((this_t0 & 0x1) != 0)
/*       */           {
/*  4371 */             n += 2;
/*       */           }
/*  4373 */           if ((this_t0 & 0x2) != 0)
/*       */           {
/*  4375 */             n += 2 + Protocol.stringSize(this.kind_.length);
/*       */           }
/*  4377 */           if ((this_t0 & 0x4) != 0)
/*       */           {
/*  4379 */             n += 2 + Protocol.stringSize(this.ancestor_.encodingSize());
/*       */           }
/*       */         }
/*       */ 
/*  4383 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*  4390 */         int n = 3;
/*  4391 */         int this_t0 = this.optional_0_;
/*  4392 */         if ((this_t0 & 0x6) != 0) {
/*  4393 */           if ((this_t0 & 0x2) != 0)
/*       */           {
/*  4395 */             n += 7 + this.kind_.length;
/*       */           }
/*  4397 */           if ((this_t0 & 0x4) != 0)
/*       */           {
/*  4399 */             n += 7 + this.ancestor_.maxEncodingSize();
/*       */           }
/*       */         }
/*       */ 
/*  4403 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*  4408 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*  4412 */         this.optional_0_ = 0;
/*  4413 */         this.distinct_ = false;
/*  4414 */         this.kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  4415 */         if (this.ancestor_ != null) this.ancestor_.clear();
/*  4416 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public EntityFilter newInstance() {
/*  4420 */         return new EntityFilter();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*  4424 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*  4441 */         int this_t0 = this.optional_0_;
/*  4442 */         if ((this_t0 & 0x1) != 0) {
/*  4443 */           sink.putByte(112);
/*  4444 */           sink.putBoolean(this.distinct_);
/*       */         }
/*       */ 
/*  4447 */         if ((this_t0 & 0x2) != 0) {
/*  4448 */           sink.putByte(-118);
/*  4449 */           sink.putByte(1);
/*  4450 */           sink.putPrefixedData(this.kind_);
/*       */         }
/*       */ 
/*  4453 */         if ((this_t0 & 0x4) != 0) {
/*  4454 */           sink.putByte(-110);
/*  4455 */           sink.putByte(1);
/*  4456 */           sink.putForeign(this.ancestor_);
/*       */         }
/*       */ 
/*  4459 */         if (this.uninterpreted != null) {
/*  4460 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*  4463 */         sink.putByte(108);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*  4467 */         boolean result = true;
/*  4468 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*  4471 */           int tt = source.getVarInt();
/*  4472 */           switch (tt)
/*       */           {
/*       */           case 108:
/*  4475 */             break;
/*       */           case 0:
/*  4479 */             result = false;
/*  4480 */             break;
/*       */           case 112:
/*  4483 */             this.distinct_ = source.getBoolean();
/*  4484 */             this_t0 |= 1;
/*  4485 */             break;
/*       */           case 138:
/*  4488 */             this.kind_ = source.getPrefixedData();
/*  4489 */             this_t0 |= 2;
/*  4490 */             break;
/*       */           case 146:
/*  4493 */             source.push(source.getVarInt());
/*  4494 */             OnestoreEntity.Reference v18 = this.ancestor_;
/*  4495 */             if (v18 == null) this.ancestor_ = (v18 = new OnestoreEntity.Reference());
/*  4496 */             if (!v18.merge(source)) { result = false; break label183; }
/*  4497 */             source.pop();
/*  4498 */             this_t0 |= 4;
/*  4499 */             break;
/*       */           default:
/*  4501 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*  4506 */         label183: this.optional_0_ = this_t0;
/*  4507 */         return result;
/*       */       }
/*       */ 
/*       */       public EntityFilter getDefaultInstanceForType()
/*       */       {
/*  4512 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final EntityFilter getDefaultInstance() {
/*  4516 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public EntityFilter freeze()
/*       */       {
/*  4585 */         this.kind_ = ProtocolSupport.freezeString(this.kind_);
/*  4586 */         if (this.ancestor_ != null) this.ancestor_.freeze();
/*  4587 */         return this;
/*       */       }
/*       */ 
/*       */       public EntityFilter unfreeze() {
/*  4591 */         if (this.ancestor_ != null) this.ancestor_.unfreeze();
/*  4592 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean isFrozen() {
/*  4596 */         return (this.ancestor_ != null) && (this.ancestor_.isFrozen());
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*  4599 */         if (this.uninterpreted == null) {
/*  4600 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*  4602 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  4520 */         IMMUTABLE_DEFAULT_INSTANCE = new EntityFilter()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.CompiledQuery.EntityFilter clearDistinct()
/*       */           {
/*  4528 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter setDistinct(boolean x) {
/*  4531 */             ProtocolSupport.unsupportedOperation();
/*  4532 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.EntityFilter clearKind()
/*       */           {
/*  4537 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter setKindAsBytes(byte[] x) {
/*  4540 */             ProtocolSupport.unsupportedOperation();
/*  4541 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter setKind(String v) {
/*  4544 */             ProtocolSupport.unsupportedOperation();
/*  4545 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter setKind(String v, Charset cs) {
/*  4548 */             ProtocolSupport.unsupportedOperation();
/*  4549 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.EntityFilter clearAncestor()
/*       */           {
/*  4554 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter setAncestor(OnestoreEntity.Reference x) {
/*  4557 */             ProtocolSupport.unsupportedOperation();
/*  4558 */             return this;
/*       */           }
/*       */           public OnestoreEntity.Reference getMutableAncestor() {
/*  4561 */             return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.EntityFilter mergeFrom(DatastorePb.CompiledQuery.EntityFilter that) {
/*  4565 */             ProtocolSupport.unsupportedOperation();
/*  4566 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*  4569 */             ProtocolSupport.unsupportedOperation();
/*  4570 */             return false;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter freeze() {
/*  4573 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.EntityFilter unfreeze() {
/*  4576 */             ProtocolSupport.unsupportedOperation();
/*  4577 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*  4580 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*  4428 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompiledQuery.EntityFilter.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("distinct", "distinct", 14, 0, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("kind", "kind", 17, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("ancestor", "ancestor", 18, 2, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, OnestoreEntity.Reference.class) });
/*       */       }
/*       */     }
/*       */ 
/*       */     public static class MergeJoinScan extends ProtocolMessage<MergeJoinScan>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*  3760 */       private byte[] index_name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3761 */       private List<byte[]> prefix_value_ = null;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final MergeJoinScan IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final byte[] getIndexNameAsBytes()
/*       */       {
/*  3767 */         return this.index_name_;
/*       */       }
/*       */       public final boolean hasIndexName() {
/*  3770 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public MergeJoinScan clearIndexName() {
/*  3773 */         this.optional_0_ &= -2;
/*  3774 */         this.index_name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3775 */         return this;
/*       */       }
/*       */       public MergeJoinScan setIndexNameAsBytes(byte[] x) {
/*  3778 */         this.optional_0_ |= 1;
/*  3779 */         this.index_name_ = x;
/*  3780 */         return this;
/*       */       }
/*       */       public final String getIndexName() {
/*  3783 */         return ProtocolSupport.toStringUtf8(this.index_name_);
/*       */       }
/*       */       public MergeJoinScan setIndexName(String v) {
/*  3786 */         if (v == null) throw new NullPointerException();
/*  3787 */         this.optional_0_ |= 1;
/*  3788 */         this.index_name_ = ProtocolSupport.toBytesUtf8(v);
/*  3789 */         return this;
/*       */       }
/*       */       public final String getIndexName(Charset cs) {
/*  3792 */         return ProtocolSupport.toString(this.index_name_, cs);
/*       */       }
/*       */       public MergeJoinScan setIndexName(String v, Charset cs) {
/*  3795 */         if (v == null) throw new NullPointerException();
/*  3796 */         this.optional_0_ |= 1;
/*  3797 */         this.index_name_ = ProtocolSupport.toBytes(v, cs);
/*  3798 */         return this;
/*       */       }
/*       */ 
/*       */       public final int prefixValueSize()
/*       */       {
/*  3803 */         return this.prefix_value_ != null ? this.prefix_value_.size() : 0;
/*       */       }
/*       */       public final byte[] getPrefixValueAsBytes(int i) {
/*  3806 */         if (!$assertionsDisabled) if (i >= 0) { if (i < (this.prefix_value_ != null ? this.prefix_value_.size() : 0)); } else throw new AssertionError();
/*  3807 */         return (byte[])this.prefix_value_.get(i);
/*       */       }
/*       */       public MergeJoinScan clearPrefixValue() {
/*  3810 */         if (this.prefix_value_ != null) this.prefix_value_.clear();
/*  3811 */         return this;
/*       */       }
/*       */       public final String getPrefixValue(int i) {
/*  3814 */         return ProtocolSupport.toStringUtf8((byte[])this.prefix_value_.get(i));
/*       */       }
/*       */       public MergeJoinScan setPrefixValueAsBytes(int i, byte[] v) {
/*  3817 */         this.prefix_value_.set(i, v);
/*  3818 */         return this;
/*       */       }
/*       */       public MergeJoinScan setPrefixValue(int i, String v) {
/*  3821 */         if (v == null) throw new NullPointerException();
/*  3822 */         this.prefix_value_.set(i, ProtocolSupport.toBytesUtf8(v));
/*  3823 */         return this;
/*       */       }
/*       */       public MergeJoinScan addPrefixValueAsBytes(byte[] v) {
/*  3826 */         if (this.prefix_value_ == null) this.prefix_value_ = new ArrayList(4);
/*  3827 */         this.prefix_value_.add(v);
/*  3828 */         return this;
/*       */       }
/*       */       public MergeJoinScan addPrefixValue(String v) {
/*  3831 */         if (v == null) throw new NullPointerException();
/*  3832 */         if (this.prefix_value_ == null) this.prefix_value_ = new ArrayList(4);
/*  3833 */         this.prefix_value_.add(ProtocolSupport.toBytesUtf8(v));
/*  3834 */         return this;
/*       */       }
/*       */       public final Iterator<String> prefixValueIterator() {
/*  3837 */         return ProtocolSupport.byteArrayToUnicodeIterator(this.prefix_value_);
/*       */       }
/*       */       public final List<String> prefixValues() {
/*  3840 */         return ProtocolSupport.byteArrayToUnicodeList(this.prefix_value_);
/*       */       }
/*       */       public final Iterator<byte[]> prefixValueAsBytesIterator() {
/*  3843 */         return this.prefix_value_ == null ? ProtocolSupport.emptyIterator() : this.prefix_value_.iterator();
/*       */       }
/*       */ 
/*       */       public final List<byte[]> prefixValuesAsBytes()
/*       */       {
/*  3848 */         return ProtocolSupport.unmodifiableList(this.prefix_value_);
/*       */       }
/*       */       public final List<byte[]> mutablePrefixValuesAsBytes() {
/*  3851 */         if (this.prefix_value_ == null) this.prefix_value_ = new ArrayList(4);
/*  3852 */         return this.prefix_value_;
/*       */       }
/*       */       public final String getPrefixValue(int i, Charset cs) {
/*  3855 */         return ProtocolSupport.toString((byte[])this.prefix_value_.get(i), cs);
/*       */       }
/*       */ 
/*       */       public MergeJoinScan setPrefixValue(int i, String v, Charset cs) {
/*  3859 */         if (v == null) throw new NullPointerException();
/*  3860 */         this.prefix_value_.set(i, ProtocolSupport.toBytes(v, cs));
/*  3861 */         return this;
/*       */       }
/*       */ 
/*       */       public MergeJoinScan addPrefixValue(String v, Charset cs) {
/*  3865 */         if (v == null) throw new NullPointerException();
/*  3866 */         if (this.prefix_value_ == null) this.prefix_value_ = new ArrayList(4);
/*  3867 */         this.prefix_value_.add(ProtocolSupport.toBytes(v, cs));
/*  3868 */         return this;
/*       */       }
/*       */ 
/*       */       public final Iterator<String> prefixValueIterator(Charset cs) {
/*  3872 */         return ProtocolSupport.byteArrayToUnicodeIterator(this.prefix_value_, cs);
/*       */       }
/*       */ 
/*       */       public final List<String> prefixValues(Charset cs) {
/*  3876 */         return ProtocolSupport.byteArrayToUnicodeList(this.prefix_value_, cs);
/*       */       }
/*       */ 
/*       */       public MergeJoinScan mergeFrom(MergeJoinScan that)
/*       */       {
/*  3883 */         assert (that != this);
/*  3884 */         int this_t0 = this.optional_0_;
/*  3885 */         int that_t0 = that.optional_0_;
/*       */ 
/*  3887 */         if ((that_t0 & 0x1) != 0) {
/*  3888 */           this_t0 |= 1;
/*  3889 */           this.index_name_ = that.index_name_;
/*       */         }
/*       */ 
/*  3892 */         if ((that.prefix_value_ != null) && (that.prefix_value_.size() > 0)) {
/*  3893 */           if (this.prefix_value_ == null)
/*  3894 */             this.prefix_value_ = new ArrayList(that.prefix_value_);
/*       */           else {
/*  3896 */             this.prefix_value_.addAll(that.prefix_value_);
/*       */           }
/*       */         }
/*       */ 
/*  3900 */         if (that.uninterpreted != null) {
/*  3901 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*  3903 */         this.optional_0_ = this_t0;
/*  3904 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(MergeJoinScan that) {
/*  3908 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(MergeJoinScan that) {
/*  3912 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(MergeJoinScan that, boolean ignoreUninterpreted) {
/*  3916 */         if (that == null) return false;
/*  3917 */         if (that == this) return true;
/*  3918 */         int this_t0 = this.optional_0_;
/*  3919 */         int that_t0 = that.optional_0_;
/*  3920 */         if (this_t0 != that_t0) return false;
/*       */ 
/*  3922 */         if (((this_t0 & 0x1) != 0) && 
/*  3923 */           (!Arrays.equals(this.index_name_, that.index_name_))) return false;
/*  3927 */         int n;
/*  3927 */         if ((n = this.prefix_value_ != null ? this.prefix_value_.size() : 0) != (that.prefix_value_ != null ? that.prefix_value_.size() : 0)) return false;
/*  3928 */         for (int i = 0; i < n; i++) {
/*  3929 */           if (!Arrays.equals((byte[])this.prefix_value_.get(i), (byte[])that.prefix_value_.get(i))) return false;
/*       */         }
/*       */ 
/*  3932 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*  3937 */         return ((that instanceof MergeJoinScan)) && (equals((MergeJoinScan)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*  3941 */         int hash = -1594206531;
/*       */ 
/*  3943 */         int this_t0 = this.optional_0_;
/*  3944 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.index_name_) : -113);
/*       */ 
/*  3946 */         hash *= 31;
/*  3947 */         int i = 0; for (int n = this.prefix_value_ != null ? this.prefix_value_.size() : 0; i < n; i++) {
/*  3948 */           hash = hash * 31 + Arrays.hashCode((byte[])this.prefix_value_.get(i));
/*       */         }
/*  3950 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  3951 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*  3953 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized() {
/*  3957 */         int this_t0 = this.optional_0_;
/*       */ 
/*  3959 */         return (this_t0 & 0x1) == 1;
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*  3967 */         int n = 2 + Protocol.stringSize(this.index_name_.length);
/*       */         int m;
/*  3970 */         n += (m = this.prefix_value_ != null ? this.prefix_value_.size() : 0);
/*  3971 */         for (int i = 0; i < m; i++) {
/*  3972 */           n += Protocol.stringSize(((byte[])this.prefix_value_.get(i)).length);
/*       */         }
/*       */ 
/*  3975 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*  3982 */         int n = 7 + this.index_name_.length;
/*       */         int m;
/*  3985 */         n += 6 * (m = this.prefix_value_ != null ? this.prefix_value_.size() : 0);
/*  3986 */         for (int i = 0; i < m; i++) {
/*  3987 */           n += ((byte[])this.prefix_value_.get(i)).length;
/*       */         }
/*       */ 
/*  3990 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*  3995 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*  3999 */         this.optional_0_ = 0;
/*  4000 */         this.index_name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  4001 */         if (this.prefix_value_ != null) this.prefix_value_.clear();
/*  4002 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public MergeJoinScan newInstance() {
/*  4006 */         return new MergeJoinScan();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*  4010 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*  4025 */         sink.putByte(66);
/*  4026 */         sink.putPrefixedData(this.index_name_);
/*       */ 
/*  4028 */         int i = 0; for (int m = this.prefix_value_ != null ? this.prefix_value_.size() : 0; i < m; i++) {
/*  4029 */           byte[] v = (byte[])this.prefix_value_.get(i);
/*  4030 */           sink.putByte(74);
/*  4031 */           sink.putPrefixedData(v);
/*       */         }
/*       */ 
/*  4034 */         if (this.uninterpreted != null) {
/*  4035 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*  4038 */         sink.putByte(60);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*  4042 */         boolean result = true;
/*  4043 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*  4046 */           int tt = source.getVarInt();
/*  4047 */           switch (tt)
/*       */           {
/*       */           case 60:
/*  4050 */             break;
/*       */           case 0:
/*  4054 */             result = false;
/*  4055 */             break;
/*       */           case 66:
/*  4058 */             this.index_name_ = source.getPrefixedData();
/*  4059 */             this_t0 |= 1;
/*  4060 */             break;
/*       */           case 74:
/*  4063 */             addPrefixValueAsBytes(source.getPrefixedData());
/*  4064 */             break;
/*       */           default:
/*  4066 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*  4071 */         this.optional_0_ = this_t0;
/*  4072 */         return result;
/*       */       }
/*       */ 
/*       */       public MergeJoinScan getDefaultInstanceForType()
/*       */       {
/*  4077 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final MergeJoinScan getDefaultInstance() {
/*  4081 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public MergeJoinScan freeze()
/*       */       {
/*  4160 */         this.index_name_ = ProtocolSupport.freezeString(this.index_name_);
/*  4161 */         this.prefix_value_ = ProtocolSupport.freezeStrings(this.prefix_value_);
/*  4162 */         return this;
/*       */       }
/*       */ 
/*       */       public MergeJoinScan unfreeze() {
/*  4166 */         this.prefix_value_ = ProtocolSupport.unfreezeStrings(this.prefix_value_);
/*  4167 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean isFrozen() {
/*  4171 */         return ProtocolSupport.isFrozenStrings(this.prefix_value_);
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*  4174 */         if (this.uninterpreted == null) {
/*  4175 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*  4177 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  4085 */         IMMUTABLE_DEFAULT_INSTANCE = new MergeJoinScan()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan clearIndexName()
/*       */           {
/*  4093 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan setIndexNameAsBytes(byte[] x) {
/*  4096 */             ProtocolSupport.unsupportedOperation();
/*  4097 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan setIndexName(String v) {
/*  4100 */             ProtocolSupport.unsupportedOperation();
/*  4101 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan setIndexName(String v, Charset cs) {
/*  4104 */             ProtocolSupport.unsupportedOperation();
/*  4105 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan clearPrefixValue()
/*       */           {
/*  4110 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan setPrefixValueAsBytes(int i, byte[] v) {
/*  4113 */             ProtocolSupport.unsupportedOperation();
/*  4114 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan setPrefixValue(int i, String v) {
/*  4117 */             ProtocolSupport.unsupportedOperation();
/*  4118 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan addPrefixValueAsBytes(byte[] v) {
/*  4121 */             ProtocolSupport.unsupportedOperation();
/*  4122 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan addPrefixValue(String v) {
/*  4125 */             ProtocolSupport.unsupportedOperation();
/*  4126 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan setPrefixValue(int i, String v, Charset cs) {
/*  4130 */             ProtocolSupport.unsupportedOperation();
/*  4131 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan addPrefixValue(String v, Charset cs) {
/*  4135 */             ProtocolSupport.unsupportedOperation();
/*  4136 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan mergeFrom(DatastorePb.CompiledQuery.MergeJoinScan that) {
/*  4140 */             ProtocolSupport.unsupportedOperation();
/*  4141 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*  4144 */             ProtocolSupport.unsupportedOperation();
/*  4145 */             return false;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan freeze() {
/*  4148 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.MergeJoinScan unfreeze() {
/*  4151 */             ProtocolSupport.unsupportedOperation();
/*  4152 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*  4155 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*  4014 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompiledQuery.MergeJoinScan.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("index_name", "index_name", 8, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("prefix_value", "prefix_value", 9, -1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REPEATED) });
/*       */       }
/*       */     }
/*       */ 
/*       */     public static class PrimaryScan extends ProtocolMessage<PrimaryScan>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*  3143 */       private byte[] index_name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3144 */       private byte[] start_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3145 */       private boolean start_inclusive_ = false;
/*  3146 */       private byte[] end_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3147 */       private boolean end_inclusive_ = false;
/*  3148 */       private long end_unapplied_log_timestamp_us_ = 0L;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final PrimaryScan IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final byte[] getIndexNameAsBytes()
/*       */       {
/*  3154 */         return this.index_name_;
/*       */       }
/*       */       public final boolean hasIndexName() {
/*  3157 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public PrimaryScan clearIndexName() {
/*  3160 */         this.optional_0_ &= -2;
/*  3161 */         this.index_name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3162 */         return this;
/*       */       }
/*       */       public PrimaryScan setIndexNameAsBytes(byte[] x) {
/*  3165 */         this.optional_0_ |= 1;
/*  3166 */         this.index_name_ = x;
/*  3167 */         return this;
/*       */       }
/*       */       public final String getIndexName() {
/*  3170 */         return ProtocolSupport.toStringUtf8(this.index_name_);
/*       */       }
/*       */       public PrimaryScan setIndexName(String v) {
/*  3173 */         if (v == null) throw new NullPointerException();
/*  3174 */         this.optional_0_ |= 1;
/*  3175 */         this.index_name_ = ProtocolSupport.toBytesUtf8(v);
/*  3176 */         return this;
/*       */       }
/*       */       public final String getIndexName(Charset cs) {
/*  3179 */         return ProtocolSupport.toString(this.index_name_, cs);
/*       */       }
/*       */       public PrimaryScan setIndexName(String v, Charset cs) {
/*  3182 */         if (v == null) throw new NullPointerException();
/*  3183 */         this.optional_0_ |= 1;
/*  3184 */         this.index_name_ = ProtocolSupport.toBytes(v, cs);
/*  3185 */         return this;
/*       */       }
/*       */ 
/*       */       public final byte[] getStartKeyAsBytes()
/*       */       {
/*  3190 */         return this.start_key_;
/*       */       }
/*       */       public final boolean hasStartKey() {
/*  3193 */         return (this.optional_0_ & 0x2) != 0;
/*       */       }
/*       */       public PrimaryScan clearStartKey() {
/*  3196 */         this.optional_0_ &= -3;
/*  3197 */         this.start_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3198 */         return this;
/*       */       }
/*       */       public PrimaryScan setStartKeyAsBytes(byte[] x) {
/*  3201 */         this.optional_0_ |= 2;
/*  3202 */         this.start_key_ = x;
/*  3203 */         return this;
/*       */       }
/*       */       public final String getStartKey() {
/*  3206 */         return ProtocolSupport.toStringUtf8(this.start_key_);
/*       */       }
/*       */       public PrimaryScan setStartKey(String v) {
/*  3209 */         if (v == null) throw new NullPointerException();
/*  3210 */         this.optional_0_ |= 2;
/*  3211 */         this.start_key_ = ProtocolSupport.toBytesUtf8(v);
/*  3212 */         return this;
/*       */       }
/*       */       public final String getStartKey(Charset cs) {
/*  3215 */         return ProtocolSupport.toString(this.start_key_, cs);
/*       */       }
/*       */       public PrimaryScan setStartKey(String v, Charset cs) {
/*  3218 */         if (v == null) throw new NullPointerException();
/*  3219 */         this.optional_0_ |= 2;
/*  3220 */         this.start_key_ = ProtocolSupport.toBytes(v, cs);
/*  3221 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isStartInclusive()
/*       */       {
/*  3226 */         return this.start_inclusive_;
/*       */       }
/*       */       public final boolean hasStartInclusive() {
/*  3229 */         return (this.optional_0_ & 0x4) != 0;
/*       */       }
/*       */       public PrimaryScan clearStartInclusive() {
/*  3232 */         this.optional_0_ &= -5;
/*  3233 */         this.start_inclusive_ = false;
/*  3234 */         return this;
/*       */       }
/*       */       public PrimaryScan setStartInclusive(boolean x) {
/*  3237 */         this.optional_0_ |= 4;
/*  3238 */         this.start_inclusive_ = x;
/*  3239 */         return this;
/*       */       }
/*       */ 
/*       */       public final byte[] getEndKeyAsBytes()
/*       */       {
/*  3244 */         return this.end_key_;
/*       */       }
/*       */       public final boolean hasEndKey() {
/*  3247 */         return (this.optional_0_ & 0x8) != 0;
/*       */       }
/*       */       public PrimaryScan clearEndKey() {
/*  3250 */         this.optional_0_ &= -9;
/*  3251 */         this.end_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3252 */         return this;
/*       */       }
/*       */       public PrimaryScan setEndKeyAsBytes(byte[] x) {
/*  3255 */         this.optional_0_ |= 8;
/*  3256 */         this.end_key_ = x;
/*  3257 */         return this;
/*       */       }
/*       */       public final String getEndKey() {
/*  3260 */         return ProtocolSupport.toStringUtf8(this.end_key_);
/*       */       }
/*       */       public PrimaryScan setEndKey(String v) {
/*  3263 */         if (v == null) throw new NullPointerException();
/*  3264 */         this.optional_0_ |= 8;
/*  3265 */         this.end_key_ = ProtocolSupport.toBytesUtf8(v);
/*  3266 */         return this;
/*       */       }
/*       */       public final String getEndKey(Charset cs) {
/*  3269 */         return ProtocolSupport.toString(this.end_key_, cs);
/*       */       }
/*       */       public PrimaryScan setEndKey(String v, Charset cs) {
/*  3272 */         if (v == null) throw new NullPointerException();
/*  3273 */         this.optional_0_ |= 8;
/*  3274 */         this.end_key_ = ProtocolSupport.toBytes(v, cs);
/*  3275 */         return this;
/*       */       }
/*       */ 
/*       */       public final boolean isEndInclusive()
/*       */       {
/*  3280 */         return this.end_inclusive_;
/*       */       }
/*       */       public final boolean hasEndInclusive() {
/*  3283 */         return (this.optional_0_ & 0x10) != 0;
/*       */       }
/*       */       public PrimaryScan clearEndInclusive() {
/*  3286 */         this.optional_0_ &= -17;
/*  3287 */         this.end_inclusive_ = false;
/*  3288 */         return this;
/*       */       }
/*       */       public PrimaryScan setEndInclusive(boolean x) {
/*  3291 */         this.optional_0_ |= 16;
/*  3292 */         this.end_inclusive_ = x;
/*  3293 */         return this;
/*       */       }
/*       */ 
/*       */       public final long getEndUnappliedLogTimestampUs()
/*       */       {
/*  3298 */         return this.end_unapplied_log_timestamp_us_;
/*       */       }
/*       */       public final boolean hasEndUnappliedLogTimestampUs() {
/*  3301 */         return (this.optional_0_ & 0x20) != 0;
/*       */       }
/*       */       public PrimaryScan clearEndUnappliedLogTimestampUs() {
/*  3304 */         this.optional_0_ &= -33;
/*  3305 */         this.end_unapplied_log_timestamp_us_ = 0L;
/*  3306 */         return this;
/*       */       }
/*       */       public PrimaryScan setEndUnappliedLogTimestampUs(long x) {
/*  3309 */         this.optional_0_ |= 32;
/*  3310 */         this.end_unapplied_log_timestamp_us_ = x;
/*  3311 */         return this;
/*       */       }
/*       */ 
/*       */       public PrimaryScan mergeFrom(PrimaryScan that)
/*       */       {
/*  3318 */         assert (that != this);
/*  3319 */         int this_t0 = this.optional_0_;
/*  3320 */         int that_t0 = that.optional_0_;
/*       */ 
/*  3322 */         if ((that_t0 & 0x1) != 0) {
/*  3323 */           this_t0 |= 1;
/*  3324 */           this.index_name_ = that.index_name_;
/*       */         }
/*       */ 
/*  3327 */         if ((that_t0 & 0x2) != 0) {
/*  3328 */           this_t0 |= 2;
/*  3329 */           this.start_key_ = that.start_key_;
/*       */         }
/*       */ 
/*  3332 */         if ((that_t0 & 0x4) != 0) {
/*  3333 */           this_t0 |= 4;
/*  3334 */           this.start_inclusive_ = that.start_inclusive_;
/*       */         }
/*       */ 
/*  3337 */         if ((that_t0 & 0x8) != 0) {
/*  3338 */           this_t0 |= 8;
/*  3339 */           this.end_key_ = that.end_key_;
/*       */         }
/*       */ 
/*  3342 */         if ((that_t0 & 0x10) != 0) {
/*  3343 */           this_t0 |= 16;
/*  3344 */           this.end_inclusive_ = that.end_inclusive_;
/*       */         }
/*       */ 
/*  3347 */         if ((that_t0 & 0x20) != 0) {
/*  3348 */           this_t0 |= 32;
/*  3349 */           this.end_unapplied_log_timestamp_us_ = that.end_unapplied_log_timestamp_us_;
/*       */         }
/*       */ 
/*  3352 */         if (that.uninterpreted != null) {
/*  3353 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*  3355 */         this.optional_0_ = this_t0;
/*  3356 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(PrimaryScan that) {
/*  3360 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(PrimaryScan that) {
/*  3364 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(PrimaryScan that, boolean ignoreUninterpreted) {
/*  3368 */         if (that == null) return false;
/*  3369 */         if (that == this) return true;
/*  3370 */         int this_t0 = this.optional_0_;
/*  3371 */         int that_t0 = that.optional_0_;
/*  3372 */         if (this_t0 != that_t0) return false;
/*       */ 
/*  3374 */         if (((this_t0 & 0x1) != 0) && 
/*  3375 */           (!Arrays.equals(this.index_name_, that.index_name_))) return false;
/*       */ 
/*  3378 */         if (((this_t0 & 0x2) != 0) && 
/*  3379 */           (!Arrays.equals(this.start_key_, that.start_key_))) return false;
/*       */ 
/*  3382 */         if (((this_t0 & 0x4) != 0) && 
/*  3383 */           (this.start_inclusive_ != that.start_inclusive_)) return false;
/*       */ 
/*  3386 */         if (((this_t0 & 0x8) != 0) && 
/*  3387 */           (!Arrays.equals(this.end_key_, that.end_key_))) return false;
/*       */ 
/*  3390 */         if (((this_t0 & 0x10) != 0) && 
/*  3391 */           (this.end_inclusive_ != that.end_inclusive_)) return false;
/*       */ 
/*  3394 */         if (((this_t0 & 0x20) != 0) && 
/*  3395 */           (this.end_unapplied_log_timestamp_us_ != that.end_unapplied_log_timestamp_us_)) return false;
/*       */ 
/*  3398 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*  3403 */         return ((that instanceof PrimaryScan)) && (equals((PrimaryScan)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*  3407 */         int hash = -922036726;
/*       */ 
/*  3409 */         int this_t0 = this.optional_0_;
/*  3410 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.index_name_) : -113);
/*       */ 
/*  3412 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.start_key_) : -113);
/*       */ 
/*  3414 */         hash = hash * 31 + ((this_t0 & 0x4) != 0 ? 1237 : this.start_inclusive_ ? 1231 : -113);
/*       */ 
/*  3416 */         hash = hash * 31 + ((this_t0 & 0x8) != 0 ? Arrays.hashCode(this.end_key_) : -113);
/*       */ 
/*  3418 */         hash = hash * 31 + ((this_t0 & 0x10) != 0 ? 1237 : this.end_inclusive_ ? 1231 : -113);
/*       */ 
/*  3420 */         hash = hash * 31 + ((this_t0 & 0x20) != 0 ? ProtocolSupport.hashCode(this.end_unapplied_log_timestamp_us_) : -113);
/*  3421 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  3422 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*  3424 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized() {
/*  3428 */         return true;
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*  3433 */         int n = 1;
/*  3434 */         int this_t0 = this.optional_0_;
/*  3435 */         if ((this_t0 & 0x3F) != 0) {
/*  3436 */           if ((this_t0 & 0x1) != 0)
/*       */           {
/*  3438 */             n += 1 + Protocol.stringSize(this.index_name_.length);
/*       */           }
/*  3440 */           if ((this_t0 & 0x2) != 0)
/*       */           {
/*  3442 */             n += 1 + Protocol.stringSize(this.start_key_.length);
/*       */           }
/*  3444 */           if ((this_t0 & 0x4) != 0)
/*       */           {
/*  3446 */             n += 2;
/*       */           }
/*  3448 */           if ((this_t0 & 0x8) != 0)
/*       */           {
/*  3450 */             n += 1 + Protocol.stringSize(this.end_key_.length);
/*       */           }
/*  3452 */           if ((this_t0 & 0x10) != 0)
/*       */           {
/*  3454 */             n += 2;
/*       */           }
/*  3456 */           if ((this_t0 & 0x20) != 0)
/*       */           {
/*  3458 */             n += 2 + Protocol.varLongSize(this.end_unapplied_log_timestamp_us_);
/*       */           }
/*       */         }
/*       */ 
/*  3462 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*  3471 */         int n = 17;
/*  3472 */         int this_t0 = this.optional_0_;
/*  3473 */         if ((this_t0 & 0xB) != 0) {
/*  3474 */           if ((this_t0 & 0x1) != 0)
/*       */           {
/*  3476 */             n += 6 + this.index_name_.length;
/*       */           }
/*  3478 */           if ((this_t0 & 0x2) != 0)
/*       */           {
/*  3480 */             n += 6 + this.start_key_.length;
/*       */           }
/*  3482 */           if ((this_t0 & 0x8) != 0)
/*       */           {
/*  3484 */             n += 6 + this.end_key_.length;
/*       */           }
/*       */         }
/*       */ 
/*  3488 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*  3493 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*  3497 */         this.optional_0_ = 0;
/*  3498 */         this.index_name_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3499 */         this.start_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3500 */         this.start_inclusive_ = false;
/*  3501 */         this.end_key_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  3502 */         this.end_inclusive_ = false;
/*  3503 */         this.end_unapplied_log_timestamp_us_ = 0L;
/*  3504 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public PrimaryScan newInstance() {
/*  3508 */         return new PrimaryScan();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*  3512 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*  3535 */         int this_t0 = this.optional_0_;
/*  3536 */         if ((this_t0 & 0x1) != 0) {
/*  3537 */           sink.putByte(18);
/*  3538 */           sink.putPrefixedData(this.index_name_);
/*       */         }
/*       */ 
/*  3541 */         if ((this_t0 & 0x2) != 0) {
/*  3542 */           sink.putByte(26);
/*  3543 */           sink.putPrefixedData(this.start_key_);
/*       */         }
/*       */ 
/*  3546 */         if ((this_t0 & 0x4) != 0) {
/*  3547 */           sink.putByte(32);
/*  3548 */           sink.putBoolean(this.start_inclusive_);
/*       */         }
/*       */ 
/*  3551 */         if ((this_t0 & 0x8) != 0) {
/*  3552 */           sink.putByte(42);
/*  3553 */           sink.putPrefixedData(this.end_key_);
/*       */         }
/*       */ 
/*  3556 */         if ((this_t0 & 0x10) != 0) {
/*  3557 */           sink.putByte(48);
/*  3558 */           sink.putBoolean(this.end_inclusive_);
/*       */         }
/*       */ 
/*  3561 */         if ((this_t0 & 0x20) != 0) {
/*  3562 */           sink.putByte(-104);
/*  3563 */           sink.putByte(1);
/*  3564 */           sink.putVarLong(this.end_unapplied_log_timestamp_us_);
/*       */         }
/*       */ 
/*  3567 */         if (this.uninterpreted != null) {
/*  3568 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*  3571 */         sink.putByte(12);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*  3575 */         boolean result = true;
/*  3576 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*  3579 */           int tt = source.getVarInt();
/*  3580 */           switch (tt)
/*       */           {
/*       */           case 12:
/*  3583 */             break;
/*       */           case 0:
/*  3587 */             result = false;
/*  3588 */             break;
/*       */           case 18:
/*  3591 */             this.index_name_ = source.getPrefixedData();
/*  3592 */             this_t0 |= 1;
/*  3593 */             break;
/*       */           case 26:
/*  3596 */             this.start_key_ = source.getPrefixedData();
/*  3597 */             this_t0 |= 2;
/*  3598 */             break;
/*       */           case 32:
/*  3601 */             this.start_inclusive_ = source.getBoolean();
/*  3602 */             this_t0 |= 4;
/*  3603 */             break;
/*       */           case 42:
/*  3606 */             this.end_key_ = source.getPrefixedData();
/*  3607 */             this_t0 |= 8;
/*  3608 */             break;
/*       */           case 48:
/*  3611 */             this.end_inclusive_ = source.getBoolean();
/*  3612 */             this_t0 |= 16;
/*  3613 */             break;
/*       */           case 152:
/*  3616 */             this.end_unapplied_log_timestamp_us_ = source.getVarLong();
/*  3617 */             this_t0 |= 32;
/*  3618 */             break;
/*       */           default:
/*  3620 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*  3625 */         this.optional_0_ = this_t0;
/*  3626 */         return result;
/*       */       }
/*       */ 
/*       */       public PrimaryScan getDefaultInstanceForType()
/*       */       {
/*  3631 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final PrimaryScan getDefaultInstance() {
/*  3635 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public PrimaryScan freeze()
/*       */       {
/*  3744 */         this.index_name_ = ProtocolSupport.freezeString(this.index_name_);
/*  3745 */         this.start_key_ = ProtocolSupport.freezeString(this.start_key_);
/*  3746 */         this.end_key_ = ProtocolSupport.freezeString(this.end_key_);
/*  3747 */         return this;
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*  3750 */         if (this.uninterpreted == null) {
/*  3751 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*  3753 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  3639 */         IMMUTABLE_DEFAULT_INSTANCE = new PrimaryScan()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan clearIndexName()
/*       */           {
/*  3647 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setIndexNameAsBytes(byte[] x) {
/*  3650 */             ProtocolSupport.unsupportedOperation();
/*  3651 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setIndexName(String v) {
/*  3654 */             ProtocolSupport.unsupportedOperation();
/*  3655 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setIndexName(String v, Charset cs) {
/*  3658 */             ProtocolSupport.unsupportedOperation();
/*  3659 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan clearStartKey()
/*       */           {
/*  3664 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setStartKeyAsBytes(byte[] x) {
/*  3667 */             ProtocolSupport.unsupportedOperation();
/*  3668 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setStartKey(String v) {
/*  3671 */             ProtocolSupport.unsupportedOperation();
/*  3672 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setStartKey(String v, Charset cs) {
/*  3675 */             ProtocolSupport.unsupportedOperation();
/*  3676 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan clearStartInclusive()
/*       */           {
/*  3681 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setStartInclusive(boolean x) {
/*  3684 */             ProtocolSupport.unsupportedOperation();
/*  3685 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan clearEndKey()
/*       */           {
/*  3690 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setEndKeyAsBytes(byte[] x) {
/*  3693 */             ProtocolSupport.unsupportedOperation();
/*  3694 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setEndKey(String v) {
/*  3697 */             ProtocolSupport.unsupportedOperation();
/*  3698 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setEndKey(String v, Charset cs) {
/*  3701 */             ProtocolSupport.unsupportedOperation();
/*  3702 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan clearEndInclusive()
/*       */           {
/*  3707 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setEndInclusive(boolean x) {
/*  3710 */             ProtocolSupport.unsupportedOperation();
/*  3711 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan clearEndUnappliedLogTimestampUs()
/*       */           {
/*  3716 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan setEndUnappliedLogTimestampUs(long x) {
/*  3719 */             ProtocolSupport.unsupportedOperation();
/*  3720 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.CompiledQuery.PrimaryScan mergeFrom(DatastorePb.CompiledQuery.PrimaryScan that) {
/*  3724 */             ProtocolSupport.unsupportedOperation();
/*  3725 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*  3728 */             ProtocolSupport.unsupportedOperation();
/*  3729 */             return false;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan freeze() {
/*  3732 */             return this;
/*       */           }
/*       */           public DatastorePb.CompiledQuery.PrimaryScan unfreeze() {
/*  3735 */             ProtocolSupport.unsupportedOperation();
/*  3736 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*  3739 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*  3516 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.CompiledQuery.PrimaryScan.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("index_name", "index_name", 2, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("start_key", "start_key", 3, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("start_inclusive", "start_inclusive", 4, 2, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("end_key", "end_key", 5, 3, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("end_inclusive", "end_inclusive", 6, 4, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("end_unapplied_log_timestamp_us", "end_unapplied_log_timestamp_us", 19, 5, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL) });
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class Query extends ProtocolMessage<Query>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  1164 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1165 */     private byte[] name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1166 */     private byte[] kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1167 */     private OnestoreEntity.Reference ancestor_ = null;
/*  1168 */     private List<Filter> filter_ = null;
/*  1169 */     private byte[] search_query_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1170 */     private List<Order> order_ = null;
/*  1171 */     private int hint_ = 0;
/*  1172 */     private int count_ = 0;
/*  1173 */     private int offset_ = 0;
/*  1174 */     private int limit_ = 0;
/*  1175 */     private DatastorePb.CompiledCursor compiled_cursor_ = null;
/*  1176 */     private DatastorePb.CompiledCursor end_compiled_cursor_ = null;
/*  1177 */     private List<OnestoreEntity.CompositeIndex> composite_index_ = null;
/*  1178 */     private boolean require_perfect_plan_ = false;
/*  1179 */     private boolean keys_only_ = false;
/*  1180 */     private DatastorePb.Transaction transaction_ = null;
/*  1181 */     private boolean distinct_ = false;
/*  1182 */     private boolean compile_ = false;
/*  1183 */     private long failover_ms_ = 0L;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final Query IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int kapp = 1;
/*       */     public static final int kname_space = 29;
/*       */     public static final int kkind = 3;
/*       */     public static final int kancestor = 17;
/*       */     public static final int kFilterGroup = 4;
/*       */     public static final int kFilterop = 6;
/*       */     public static final int kFilterproperty = 14;
/*       */     public static final int ksearch_query = 8;
/*       */     public static final int kOrderGroup = 9;
/*       */     public static final int kOrderproperty = 10;
/*       */     public static final int kOrderdirection = 11;
/*       */     public static final int khint = 18;
/*       */     public static final int kcount = 23;
/*       */     public static final int koffset = 12;
/*       */     public static final int klimit = 16;
/*       */     public static final int kcompiled_cursor = 30;
/*       */     public static final int kend_compiled_cursor = 31;
/*       */     public static final int kcomposite_index = 19;
/*       */     public static final int krequire_perfect_plan = 20;
/*       */     public static final int kkeys_only = 21;
/*       */     public static final int ktransaction = 22;
/*       */     public static final int kdistinct = 24;
/*       */     public static final int kcompile = 25;
/*       */     public static final int kfailover_ms = 26;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/*  1212 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/*  1215 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public Query clearApp() {
/*  1218 */       this.optional_0_ &= -2;
/*  1219 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1220 */       return this;
/*       */     }
/*       */     public Query setAppAsBytes(byte[] x) {
/*  1223 */       this.optional_0_ |= 1;
/*  1224 */       this.app_ = x;
/*  1225 */       return this;
/*       */     }
/*       */     public final String getApp() {
/*  1228 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public Query setApp(String v) {
/*  1231 */       if (v == null) throw new NullPointerException();
/*  1232 */       this.optional_0_ |= 1;
/*  1233 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/*  1234 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/*  1237 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public Query setApp(String v, Charset cs) {
/*  1240 */       if (v == null) throw new NullPointerException();
/*  1241 */       this.optional_0_ |= 1;
/*  1242 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/*  1243 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getNameSpaceAsBytes()
/*       */     {
/*  1248 */       return this.name_space_;
/*       */     }
/*       */     public final boolean hasNameSpace() {
/*  1251 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public Query clearNameSpace() {
/*  1254 */       this.optional_0_ &= -3;
/*  1255 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1256 */       return this;
/*       */     }
/*       */     public Query setNameSpaceAsBytes(byte[] x) {
/*  1259 */       this.optional_0_ |= 2;
/*  1260 */       this.name_space_ = x;
/*  1261 */       return this;
/*       */     }
/*       */     public final String getNameSpace() {
/*  1264 */       return ProtocolSupport.toStringUtf8(this.name_space_);
/*       */     }
/*       */     public Query setNameSpace(String v) {
/*  1267 */       if (v == null) throw new NullPointerException();
/*  1268 */       this.optional_0_ |= 2;
/*  1269 */       this.name_space_ = ProtocolSupport.toBytesUtf8(v);
/*  1270 */       return this;
/*       */     }
/*       */     public final String getNameSpace(Charset cs) {
/*  1273 */       return ProtocolSupport.toString(this.name_space_, cs);
/*       */     }
/*       */     public Query setNameSpace(String v, Charset cs) {
/*  1276 */       if (v == null) throw new NullPointerException();
/*  1277 */       this.optional_0_ |= 2;
/*  1278 */       this.name_space_ = ProtocolSupport.toBytes(v, cs);
/*  1279 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getKindAsBytes()
/*       */     {
/*  1284 */       return this.kind_;
/*       */     }
/*       */     public final boolean hasKind() {
/*  1287 */       return (this.optional_0_ & 0x4) != 0;
/*       */     }
/*       */     public Query clearKind() {
/*  1290 */       this.optional_0_ &= -5;
/*  1291 */       this.kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1292 */       return this;
/*       */     }
/*       */     public Query setKindAsBytes(byte[] x) {
/*  1295 */       this.optional_0_ |= 4;
/*  1296 */       this.kind_ = x;
/*  1297 */       return this;
/*       */     }
/*       */     public final String getKind() {
/*  1300 */       return ProtocolSupport.toStringUtf8(this.kind_);
/*       */     }
/*       */     public Query setKind(String v) {
/*  1303 */       if (v == null) throw new NullPointerException();
/*  1304 */       this.optional_0_ |= 4;
/*  1305 */       this.kind_ = ProtocolSupport.toBytesUtf8(v);
/*  1306 */       return this;
/*       */     }
/*       */     public final String getKind(Charset cs) {
/*  1309 */       return ProtocolSupport.toString(this.kind_, cs);
/*       */     }
/*       */     public Query setKind(String v, Charset cs) {
/*  1312 */       if (v == null) throw new NullPointerException();
/*  1313 */       this.optional_0_ |= 4;
/*  1314 */       this.kind_ = ProtocolSupport.toBytes(v, cs);
/*  1315 */       return this;
/*       */     }
/*       */ 
/*       */     public final OnestoreEntity.Reference getAncestor()
/*       */     {
/*  1320 */       if (this.ancestor_ == null) {
/*  1321 */         return OnestoreEntity.Reference.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  1323 */       return this.ancestor_;
/*       */     }
/*       */     public final boolean hasAncestor() {
/*  1326 */       return (this.optional_0_ & 0x8) != 0;
/*       */     }
/*       */     public Query clearAncestor() {
/*  1329 */       this.optional_0_ &= -9;
/*  1330 */       if (this.ancestor_ != null) this.ancestor_.clear();
/*  1331 */       return this;
/*       */     }
/*       */     public Query setAncestor(OnestoreEntity.Reference x) {
/*  1334 */       if (x == null) throw new NullPointerException();
/*  1335 */       this.optional_0_ |= 8;
/*  1336 */       this.ancestor_ = x;
/*  1337 */       return this;
/*       */     }
/*       */     public OnestoreEntity.Reference getMutableAncestor() {
/*  1340 */       this.optional_0_ |= 8;
/*  1341 */       if (this.ancestor_ == null) this.ancestor_ = new OnestoreEntity.Reference();
/*  1342 */       return this.ancestor_;
/*       */     }
/*       */ 
/*       */     public final int filterSize()
/*       */     {
/*  1347 */       return this.filter_ != null ? this.filter_.size() : 0;
/*       */     }
/*       */     public final Filter getFilter(int i) {
/*  1350 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.filter_ != null ? this.filter_.size() : 0)); } else throw new AssertionError();
/*  1351 */       return (Filter)this.filter_.get(i);
/*       */     }
/*       */     public Query clearFilter() {
/*  1354 */       if (this.filter_ != null) this.filter_.clear();
/*  1355 */       return this;
/*       */     }
/*       */     public Filter getMutableFilter(int i) {
/*  1358 */       assert ((i >= 0) && (this.filter_ != null) && (i < this.filter_.size()));
/*  1359 */       return (Filter)this.filter_.get(i);
/*       */     }
/*       */     public Filter addFilter() {
/*  1362 */       Filter v = new Filter();
/*  1363 */       if (this.filter_ == null) this.filter_ = new ArrayList(4);
/*  1364 */       this.filter_.add(v);
/*  1365 */       return v;
/*       */     }
/*       */     public Filter addFilter(Filter v) {
/*  1368 */       if (this.filter_ == null) this.filter_ = new ArrayList(4);
/*  1369 */       this.filter_.add(v);
/*  1370 */       return v;
/*       */     }
/*       */     public Filter insertFilter(int i, Filter v) {
/*  1373 */       if (this.filter_ == null) this.filter_ = new ArrayList(4);
/*  1374 */       this.filter_.add(i, v);
/*  1375 */       return v;
/*       */     }
/*       */     public Filter removeFilter(int i) {
/*  1378 */       return (Filter)this.filter_.remove(i);
/*       */     }
/*       */     public final Iterator<Filter> filterIterator() {
/*  1381 */       if (this.filter_ == null) {
/*  1382 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  1384 */       return this.filter_.iterator();
/*       */     }
/*       */     public final List<Filter> filters() {
/*  1387 */       return ProtocolSupport.unmodifiableList(this.filter_);
/*       */     }
/*       */     public final List<Filter> mutableFilters() {
/*  1390 */       if (this.filter_ == null) this.filter_ = new ArrayList(4);
/*  1391 */       return this.filter_;
/*       */     }
/*       */ 
/*       */     public final byte[] getSearchQueryAsBytes()
/*       */     {
/*  1396 */       return this.search_query_;
/*       */     }
/*       */     public final boolean hasSearchQuery() {
/*  1399 */       return (this.optional_0_ & 0x10) != 0;
/*       */     }
/*       */     public Query clearSearchQuery() {
/*  1402 */       this.optional_0_ &= -17;
/*  1403 */       this.search_query_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1404 */       return this;
/*       */     }
/*       */     public Query setSearchQueryAsBytes(byte[] x) {
/*  1407 */       this.optional_0_ |= 16;
/*  1408 */       this.search_query_ = x;
/*  1409 */       return this;
/*       */     }
/*       */     public final String getSearchQuery() {
/*  1412 */       return ProtocolSupport.toStringUtf8(this.search_query_);
/*       */     }
/*       */     public Query setSearchQuery(String v) {
/*  1415 */       if (v == null) throw new NullPointerException();
/*  1416 */       this.optional_0_ |= 16;
/*  1417 */       this.search_query_ = ProtocolSupport.toBytesUtf8(v);
/*  1418 */       return this;
/*       */     }
/*       */     public final String getSearchQuery(Charset cs) {
/*  1421 */       return ProtocolSupport.toString(this.search_query_, cs);
/*       */     }
/*       */     public Query setSearchQuery(String v, Charset cs) {
/*  1424 */       if (v == null) throw new NullPointerException();
/*  1425 */       this.optional_0_ |= 16;
/*  1426 */       this.search_query_ = ProtocolSupport.toBytes(v, cs);
/*  1427 */       return this;
/*       */     }
/*       */ 
/*       */     public final int orderSize()
/*       */     {
/*  1432 */       return this.order_ != null ? this.order_.size() : 0;
/*       */     }
/*       */     public final Order getOrder(int i) {
/*  1435 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.order_ != null ? this.order_.size() : 0)); } else throw new AssertionError();
/*  1436 */       return (Order)this.order_.get(i);
/*       */     }
/*       */     public Query clearOrder() {
/*  1439 */       if (this.order_ != null) this.order_.clear();
/*  1440 */       return this;
/*       */     }
/*       */     public Order getMutableOrder(int i) {
/*  1443 */       assert ((i >= 0) && (this.order_ != null) && (i < this.order_.size()));
/*  1444 */       return (Order)this.order_.get(i);
/*       */     }
/*       */     public Order addOrder() {
/*  1447 */       Order v = new Order();
/*  1448 */       if (this.order_ == null) this.order_ = new ArrayList(4);
/*  1449 */       this.order_.add(v);
/*  1450 */       return v;
/*       */     }
/*       */     public Order addOrder(Order v) {
/*  1453 */       if (this.order_ == null) this.order_ = new ArrayList(4);
/*  1454 */       this.order_.add(v);
/*  1455 */       return v;
/*       */     }
/*       */     public Order insertOrder(int i, Order v) {
/*  1458 */       if (this.order_ == null) this.order_ = new ArrayList(4);
/*  1459 */       this.order_.add(i, v);
/*  1460 */       return v;
/*       */     }
/*       */     public Order removeOrder(int i) {
/*  1463 */       return (Order)this.order_.remove(i);
/*       */     }
/*       */     public final Iterator<Order> orderIterator() {
/*  1466 */       if (this.order_ == null) {
/*  1467 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  1469 */       return this.order_.iterator();
/*       */     }
/*       */     public final List<Order> orders() {
/*  1472 */       return ProtocolSupport.unmodifiableList(this.order_);
/*       */     }
/*       */     public final List<Order> mutableOrders() {
/*  1475 */       if (this.order_ == null) this.order_ = new ArrayList(4);
/*  1476 */       return this.order_;
/*       */     }
/*       */ 
/*       */     public final int getHint()
/*       */     {
/*  1481 */       return this.hint_;
/*       */     }
/*       */     public Hint getHintEnum() {
/*  1484 */       return Hint.valueOf(getHint());
/*       */     }
/*       */     public final boolean hasHint() {
/*  1487 */       return (this.optional_0_ & 0x20) != 0;
/*       */     }
/*       */     public Query clearHint() {
/*  1490 */       this.optional_0_ &= -33;
/*  1491 */       this.hint_ = 0;
/*  1492 */       return this;
/*       */     }
/*       */     public Query setHint(int x) {
/*  1495 */       this.optional_0_ |= 32;
/*  1496 */       this.hint_ = x;
/*  1497 */       return this;
/*       */     }
/*       */     public Query setHint(Hint x) {
/*  1500 */       if (x == null) {
/*  1501 */         this.optional_0_ &= -33;
/*  1502 */         this.hint_ = 0;
/*       */       } else {
/*  1504 */         setHint(x.getValue());
/*       */       }
/*  1506 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getCount()
/*       */     {
/*  1511 */       return this.count_;
/*       */     }
/*       */     public final boolean hasCount() {
/*  1514 */       return (this.optional_0_ & 0x40) != 0;
/*       */     }
/*       */     public Query clearCount() {
/*  1517 */       this.optional_0_ &= -65;
/*  1518 */       this.count_ = 0;
/*  1519 */       return this;
/*       */     }
/*       */     public Query setCount(int x) {
/*  1522 */       this.optional_0_ |= 64;
/*  1523 */       this.count_ = x;
/*  1524 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getOffset()
/*       */     {
/*  1529 */       return this.offset_;
/*       */     }
/*       */     public final boolean hasOffset() {
/*  1532 */       return (this.optional_0_ & 0x80) != 0;
/*       */     }
/*       */     public Query clearOffset() {
/*  1535 */       this.optional_0_ &= -129;
/*  1536 */       this.offset_ = 0;
/*  1537 */       return this;
/*       */     }
/*       */     public Query setOffset(int x) {
/*  1540 */       this.optional_0_ |= 128;
/*  1541 */       this.offset_ = x;
/*  1542 */       return this;
/*       */     }
/*       */ 
/*       */     public final int getLimit()
/*       */     {
/*  1547 */       return this.limit_;
/*       */     }
/*       */     public final boolean hasLimit() {
/*  1550 */       return (this.optional_0_ & 0x100) != 0;
/*       */     }
/*       */     public Query clearLimit() {
/*  1553 */       this.optional_0_ &= -257;
/*  1554 */       this.limit_ = 0;
/*  1555 */       return this;
/*       */     }
/*       */     public Query setLimit(int x) {
/*  1558 */       this.optional_0_ |= 256;
/*  1559 */       this.limit_ = x;
/*  1560 */       return this;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.CompiledCursor getCompiledCursor()
/*       */     {
/*  1565 */       if (this.compiled_cursor_ == null) {
/*  1566 */         return DatastorePb.CompiledCursor.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  1568 */       return this.compiled_cursor_;
/*       */     }
/*       */     public final boolean hasCompiledCursor() {
/*  1571 */       return (this.optional_0_ & 0x200) != 0;
/*       */     }
/*       */     public Query clearCompiledCursor() {
/*  1574 */       this.optional_0_ &= -513;
/*  1575 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.clear();
/*  1576 */       return this;
/*       */     }
/*       */     public Query setCompiledCursor(DatastorePb.CompiledCursor x) {
/*  1579 */       if (x == null) throw new NullPointerException();
/*  1580 */       this.optional_0_ |= 512;
/*  1581 */       this.compiled_cursor_ = x;
/*  1582 */       return this;
/*       */     }
/*       */     public DatastorePb.CompiledCursor getMutableCompiledCursor() {
/*  1585 */       this.optional_0_ |= 512;
/*  1586 */       if (this.compiled_cursor_ == null) this.compiled_cursor_ = new DatastorePb.CompiledCursor();
/*  1587 */       return this.compiled_cursor_;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.CompiledCursor getEndCompiledCursor()
/*       */     {
/*  1592 */       if (this.end_compiled_cursor_ == null) {
/*  1593 */         return DatastorePb.CompiledCursor.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  1595 */       return this.end_compiled_cursor_;
/*       */     }
/*       */     public final boolean hasEndCompiledCursor() {
/*  1598 */       return (this.optional_0_ & 0x400) != 0;
/*       */     }
/*       */     public Query clearEndCompiledCursor() {
/*  1601 */       this.optional_0_ &= -1025;
/*  1602 */       if (this.end_compiled_cursor_ != null) this.end_compiled_cursor_.clear();
/*  1603 */       return this;
/*       */     }
/*       */     public Query setEndCompiledCursor(DatastorePb.CompiledCursor x) {
/*  1606 */       if (x == null) throw new NullPointerException();
/*  1607 */       this.optional_0_ |= 1024;
/*  1608 */       this.end_compiled_cursor_ = x;
/*  1609 */       return this;
/*       */     }
/*       */     public DatastorePb.CompiledCursor getMutableEndCompiledCursor() {
/*  1612 */       this.optional_0_ |= 1024;
/*  1613 */       if (this.end_compiled_cursor_ == null) this.end_compiled_cursor_ = new DatastorePb.CompiledCursor();
/*  1614 */       return this.end_compiled_cursor_;
/*       */     }
/*       */ 
/*       */     public final int compositeIndexSize()
/*       */     {
/*  1619 */       return this.composite_index_ != null ? this.composite_index_.size() : 0;
/*       */     }
/*       */     public final OnestoreEntity.CompositeIndex getCompositeIndex(int i) {
/*  1622 */       if (!$assertionsDisabled) if (i >= 0) { if (i < (this.composite_index_ != null ? this.composite_index_.size() : 0)); } else throw new AssertionError();
/*  1623 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*       */     }
/*       */     public Query clearCompositeIndex() {
/*  1626 */       if (this.composite_index_ != null) this.composite_index_.clear();
/*  1627 */       return this;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex getMutableCompositeIndex(int i) {
/*  1630 */       assert ((i >= 0) && (this.composite_index_ != null) && (i < this.composite_index_.size()));
/*  1631 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addCompositeIndex() {
/*  1634 */       OnestoreEntity.CompositeIndex v = new OnestoreEntity.CompositeIndex();
/*  1635 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  1636 */       this.composite_index_.add(v);
/*  1637 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex addCompositeIndex(OnestoreEntity.CompositeIndex v) {
/*  1640 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  1641 */       this.composite_index_.add(v);
/*  1642 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex insertCompositeIndex(int i, OnestoreEntity.CompositeIndex v) {
/*  1645 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  1646 */       this.composite_index_.add(i, v);
/*  1647 */       return v;
/*       */     }
/*       */     public OnestoreEntity.CompositeIndex removeCompositeIndex(int i) {
/*  1650 */       return (OnestoreEntity.CompositeIndex)this.composite_index_.remove(i);
/*       */     }
/*       */     public final Iterator<OnestoreEntity.CompositeIndex> compositeIndexIterator() {
/*  1653 */       if (this.composite_index_ == null) {
/*  1654 */         return ProtocolSupport.emptyIterator();
/*       */       }
/*  1656 */       return this.composite_index_.iterator();
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> compositeIndexs() {
/*  1659 */       return ProtocolSupport.unmodifiableList(this.composite_index_);
/*       */     }
/*       */     public final List<OnestoreEntity.CompositeIndex> mutableCompositeIndexs() {
/*  1662 */       if (this.composite_index_ == null) this.composite_index_ = new ArrayList(4);
/*  1663 */       return this.composite_index_;
/*       */     }
/*       */ 
/*       */     public final boolean isRequirePerfectPlan()
/*       */     {
/*  1668 */       return this.require_perfect_plan_;
/*       */     }
/*       */     public final boolean hasRequirePerfectPlan() {
/*  1671 */       return (this.optional_0_ & 0x800) != 0;
/*       */     }
/*       */     public Query clearRequirePerfectPlan() {
/*  1674 */       this.optional_0_ &= -2049;
/*  1675 */       this.require_perfect_plan_ = false;
/*  1676 */       return this;
/*       */     }
/*       */     public Query setRequirePerfectPlan(boolean x) {
/*  1679 */       this.optional_0_ |= 2048;
/*  1680 */       this.require_perfect_plan_ = x;
/*  1681 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isKeysOnly()
/*       */     {
/*  1686 */       return this.keys_only_;
/*       */     }
/*       */     public final boolean hasKeysOnly() {
/*  1689 */       return (this.optional_0_ & 0x1000) != 0;
/*       */     }
/*       */     public Query clearKeysOnly() {
/*  1692 */       this.optional_0_ &= -4097;
/*  1693 */       this.keys_only_ = false;
/*  1694 */       return this;
/*       */     }
/*       */     public Query setKeysOnly(boolean x) {
/*  1697 */       this.optional_0_ |= 4096;
/*  1698 */       this.keys_only_ = x;
/*  1699 */       return this;
/*       */     }
/*       */ 
/*       */     public final DatastorePb.Transaction getTransaction()
/*       */     {
/*  1704 */       if (this.transaction_ == null) {
/*  1705 */         return DatastorePb.Transaction.IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*  1707 */       return this.transaction_;
/*       */     }
/*       */     public final boolean hasTransaction() {
/*  1710 */       return (this.optional_0_ & 0x2000) != 0;
/*       */     }
/*       */     public Query clearTransaction() {
/*  1713 */       this.optional_0_ &= -8193;
/*  1714 */       if (this.transaction_ != null) this.transaction_.clear();
/*  1715 */       return this;
/*       */     }
/*       */     public Query setTransaction(DatastorePb.Transaction x) {
/*  1718 */       if (x == null) throw new NullPointerException();
/*  1719 */       this.optional_0_ |= 8192;
/*  1720 */       this.transaction_ = x;
/*  1721 */       return this;
/*       */     }
/*       */     public DatastorePb.Transaction getMutableTransaction() {
/*  1724 */       this.optional_0_ |= 8192;
/*  1725 */       if (this.transaction_ == null) this.transaction_ = new DatastorePb.Transaction();
/*  1726 */       return this.transaction_;
/*       */     }
/*       */ 
/*       */     public final boolean isDistinct()
/*       */     {
/*  1731 */       return this.distinct_;
/*       */     }
/*       */     public final boolean hasDistinct() {
/*  1734 */       return (this.optional_0_ & 0x4000) != 0;
/*       */     }
/*       */     public Query clearDistinct() {
/*  1737 */       this.optional_0_ &= -16385;
/*  1738 */       this.distinct_ = false;
/*  1739 */       return this;
/*       */     }
/*       */     public Query setDistinct(boolean x) {
/*  1742 */       this.optional_0_ |= 16384;
/*  1743 */       this.distinct_ = x;
/*  1744 */       return this;
/*       */     }
/*       */ 
/*       */     public final boolean isCompile()
/*       */     {
/*  1749 */       return this.compile_;
/*       */     }
/*       */     public final boolean hasCompile() {
/*  1752 */       return (this.optional_0_ & 0x8000) != 0;
/*       */     }
/*       */     public Query clearCompile() {
/*  1755 */       this.optional_0_ &= -32769;
/*  1756 */       this.compile_ = false;
/*  1757 */       return this;
/*       */     }
/*       */     public Query setCompile(boolean x) {
/*  1760 */       this.optional_0_ |= 32768;
/*  1761 */       this.compile_ = x;
/*  1762 */       return this;
/*       */     }
/*       */ 
/*       */     public final long getFailoverMs()
/*       */     {
/*  1767 */       return this.failover_ms_;
/*       */     }
/*       */     public final boolean hasFailoverMs() {
/*  1770 */       return (this.optional_0_ & 0x10000) != 0;
/*       */     }
/*       */     public Query clearFailoverMs() {
/*  1773 */       this.optional_0_ &= -65537;
/*  1774 */       this.failover_ms_ = 0L;
/*  1775 */       return this;
/*       */     }
/*       */     public Query setFailoverMs(long x) {
/*  1778 */       this.optional_0_ |= 65536;
/*  1779 */       this.failover_ms_ = x;
/*  1780 */       return this;
/*       */     }
/*       */ 
/*       */     public Query mergeFrom(Query that)
/*       */     {
/*  1787 */       assert (that != this);
/*  1788 */       int this_t0 = this.optional_0_;
/*  1789 */       int that_t0 = that.optional_0_;
/*       */ 
/*  1791 */       if ((that_t0 & 0x1) != 0) {
/*  1792 */         this_t0 |= 1;
/*  1793 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/*  1796 */       if ((that_t0 & 0x2) != 0) {
/*  1797 */         this_t0 |= 2;
/*  1798 */         this.name_space_ = that.name_space_;
/*       */       }
/*       */ 
/*  1801 */       if ((that_t0 & 0x4) != 0) {
/*  1802 */         this_t0 |= 4;
/*  1803 */         this.kind_ = that.kind_;
/*       */       }
/*       */ 
/*  1806 */       if ((that_t0 & 0x8) != 0) {
/*  1807 */         this_t0 |= 8;
/*  1808 */         OnestoreEntity.Reference v = this.ancestor_;
/*  1809 */         if (v == null) this.ancestor_ = (v = new OnestoreEntity.Reference());
/*  1810 */         v.mergeFrom(that.ancestor_);
/*       */       }
/*       */ 
/*  1813 */       if (that.filter_ != null) {
/*  1814 */         for (Filter v : that.filter_) {
/*  1815 */           addFilter().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  1819 */       if ((that_t0 & 0x10) != 0) {
/*  1820 */         this_t0 |= 16;
/*  1821 */         this.search_query_ = that.search_query_;
/*       */       }
/*       */ 
/*  1824 */       if (that.order_ != null) {
/*  1825 */         for (Order v : that.order_) {
/*  1826 */           addOrder().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  1830 */       if ((that_t0 & 0x20) != 0) {
/*  1831 */         this_t0 |= 32;
/*  1832 */         this.hint_ = that.hint_;
/*       */       }
/*       */ 
/*  1835 */       if ((that_t0 & 0x40) != 0) {
/*  1836 */         this_t0 |= 64;
/*  1837 */         this.count_ = that.count_;
/*       */       }
/*       */ 
/*  1840 */       if ((that_t0 & 0x80) != 0) {
/*  1841 */         this_t0 |= 128;
/*  1842 */         this.offset_ = that.offset_;
/*       */       }
/*       */ 
/*  1845 */       if ((that_t0 & 0x100) != 0) {
/*  1846 */         this_t0 |= 256;
/*  1847 */         this.limit_ = that.limit_;
/*       */       }
/*       */ 
/*  1850 */       if ((that_t0 & 0x200) != 0) {
/*  1851 */         this_t0 |= 512;
/*  1852 */         DatastorePb.CompiledCursor v = this.compiled_cursor_;
/*  1853 */         if (v == null) this.compiled_cursor_ = (v = new DatastorePb.CompiledCursor());
/*  1854 */         v.mergeFrom(that.compiled_cursor_);
/*       */       }
/*       */ 
/*  1857 */       if ((that_t0 & 0x400) != 0) {
/*  1858 */         this_t0 |= 1024;
/*  1859 */         DatastorePb.CompiledCursor v = this.end_compiled_cursor_;
/*  1860 */         if (v == null) this.end_compiled_cursor_ = (v = new DatastorePb.CompiledCursor());
/*  1861 */         v.mergeFrom(that.end_compiled_cursor_);
/*       */       }
/*       */ 
/*  1864 */       if (that.composite_index_ != null) {
/*  1865 */         for (OnestoreEntity.CompositeIndex v : that.composite_index_) {
/*  1866 */           addCompositeIndex().mergeFrom(v);
/*       */         }
/*       */       }
/*       */ 
/*  1870 */       if ((that_t0 & 0x800) != 0) {
/*  1871 */         this_t0 |= 2048;
/*  1872 */         this.require_perfect_plan_ = that.require_perfect_plan_;
/*       */       }
/*       */ 
/*  1875 */       if ((that_t0 & 0x1000) != 0) {
/*  1876 */         this_t0 |= 4096;
/*  1877 */         this.keys_only_ = that.keys_only_;
/*       */       }
/*       */ 
/*  1880 */       if ((that_t0 & 0x2000) != 0) {
/*  1881 */         this_t0 |= 8192;
/*  1882 */         DatastorePb.Transaction v = this.transaction_;
/*  1883 */         if (v == null) this.transaction_ = (v = new DatastorePb.Transaction());
/*  1884 */         v.mergeFrom(that.transaction_);
/*       */       }
/*       */ 
/*  1887 */       if ((that_t0 & 0x4000) != 0) {
/*  1888 */         this_t0 |= 16384;
/*  1889 */         this.distinct_ = that.distinct_;
/*       */       }
/*       */ 
/*  1892 */       if ((that_t0 & 0x8000) != 0) {
/*  1893 */         this_t0 |= 32768;
/*  1894 */         this.compile_ = that.compile_;
/*       */       }
/*       */ 
/*  1897 */       if ((that_t0 & 0x10000) != 0) {
/*  1898 */         this_t0 |= 65536;
/*  1899 */         this.failover_ms_ = that.failover_ms_;
/*       */       }
/*       */ 
/*  1902 */       if (that.uninterpreted != null) {
/*  1903 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*  1905 */       this.optional_0_ = this_t0;
/*  1906 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(Query that) {
/*  1910 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(Query that) {
/*  1914 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(Query that, boolean ignoreUninterpreted) {
/*  1918 */       if (that == null) return false;
/*  1919 */       if (that == this) return true;
/*  1920 */       int this_t0 = this.optional_0_;
/*  1921 */       int that_t0 = that.optional_0_;
/*  1922 */       if (this_t0 != that_t0) return false;
/*       */ 
/*  1924 */       if (((this_t0 & 0x1) != 0) && 
/*  1925 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/*  1928 */       if (((this_t0 & 0x2) != 0) && 
/*  1929 */         (!Arrays.equals(this.name_space_, that.name_space_))) return false;
/*       */ 
/*  1932 */       if (((this_t0 & 0x4) != 0) && 
/*  1933 */         (!Arrays.equals(this.kind_, that.kind_))) return false;
/*       */ 
/*  1936 */       if (((this_t0 & 0x8) != 0) && 
/*  1937 */         (!this.ancestor_.equals(that.ancestor_, ignoreUninterpreted))) return false;
/*  1941 */       int n;
/*  1941 */       if ((n = this.filter_ != null ? this.filter_.size() : 0) != (that.filter_ != null ? that.filter_.size() : 0)) return false;
/*  1942 */       for (int i = 0; i < n; i++) {
/*  1943 */         if (!((Filter)this.filter_.get(i)).equals((Filter)that.filter_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  1946 */       if (((this_t0 & 0x10) != 0) && 
/*  1947 */         (!Arrays.equals(this.search_query_, that.search_query_))) return false;
/*       */ 
/*  1950 */       if ((n = this.order_ != null ? this.order_.size() : 0) != (that.order_ != null ? that.order_.size() : 0)) return false;
/*  1951 */       for (int i = 0; i < n; i++) {
/*  1952 */         if (!((Order)this.order_.get(i)).equals((Order)that.order_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  1955 */       if (((this_t0 & 0x20) != 0) && 
/*  1956 */         (this.hint_ != that.hint_)) return false;
/*       */ 
/*  1959 */       if (((this_t0 & 0x40) != 0) && 
/*  1960 */         (this.count_ != that.count_)) return false;
/*       */ 
/*  1963 */       if (((this_t0 & 0x80) != 0) && 
/*  1964 */         (this.offset_ != that.offset_)) return false;
/*       */ 
/*  1967 */       if (((this_t0 & 0x100) != 0) && 
/*  1968 */         (this.limit_ != that.limit_)) return false;
/*       */ 
/*  1971 */       if (((this_t0 & 0x200) != 0) && 
/*  1972 */         (!this.compiled_cursor_.equals(that.compiled_cursor_, ignoreUninterpreted))) return false;
/*       */ 
/*  1975 */       if (((this_t0 & 0x400) != 0) && 
/*  1976 */         (!this.end_compiled_cursor_.equals(that.end_compiled_cursor_, ignoreUninterpreted))) return false;
/*       */ 
/*  1979 */       if ((n = this.composite_index_ != null ? this.composite_index_.size() : 0) != (that.composite_index_ != null ? that.composite_index_.size() : 0)) return false;
/*  1980 */       for (int i = 0; i < n; i++) {
/*  1981 */         if (!((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).equals((OnestoreEntity.CompositeIndex)that.composite_index_.get(i), ignoreUninterpreted)) return false;
/*       */       }
/*       */ 
/*  1984 */       if (((this_t0 & 0x800) != 0) && 
/*  1985 */         (this.require_perfect_plan_ != that.require_perfect_plan_)) return false;
/*       */ 
/*  1988 */       if (((this_t0 & 0x1000) != 0) && 
/*  1989 */         (this.keys_only_ != that.keys_only_)) return false;
/*       */ 
/*  1992 */       if (((this_t0 & 0x2000) != 0) && 
/*  1993 */         (!this.transaction_.equals(that.transaction_, ignoreUninterpreted))) return false;
/*       */ 
/*  1996 */       if (((this_t0 & 0x4000) != 0) && 
/*  1997 */         (this.distinct_ != that.distinct_)) return false;
/*       */ 
/*  2000 */       if (((this_t0 & 0x8000) != 0) && 
/*  2001 */         (this.compile_ != that.compile_)) return false;
/*       */ 
/*  2004 */       if (((this_t0 & 0x10000) != 0) && 
/*  2005 */         (this.failover_ms_ != that.failover_ms_)) return false;
/*       */ 
/*  2008 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*  2013 */       return ((that instanceof Query)) && (equals((Query)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*  2017 */       int hash = 2075045219;
/*       */ 
/*  2019 */       int this_t0 = this.optional_0_;
/*  2020 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.app_) : -113);
/*       */ 
/*  2022 */       hash = hash * 31 + ((this_t0 & 0x4) != 0 ? Arrays.hashCode(this.kind_) : -113);
/*       */ 
/*  2024 */       hash *= 31;
/*  2025 */       int i = 0; for (int n = this.filter_ != null ? this.filter_.size() : 0; i < n; i++) {
/*  2026 */         hash = hash * 31 + ((Filter)this.filter_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  2029 */       hash = hash * 31 + ((this_t0 & 0x10) != 0 ? Arrays.hashCode(this.search_query_) : -113);
/*       */ 
/*  2031 */       hash *= 31;
/*  2032 */       int i = 0; for (int n = this.order_ != null ? this.order_.size() : 0; i < n; i++) {
/*  2033 */         hash = hash * 31 + ((Order)this.order_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  2036 */       hash = hash * 31 + ((this_t0 & 0x80) != 0 ? this.offset_ : -113);
/*       */ 
/*  2038 */       hash = hash * 31 + ((this_t0 & 0x100) != 0 ? this.limit_ : -113);
/*       */ 
/*  2040 */       hash = hash * 31 + ((this_t0 & 0x8) != 0 ? this.ancestor_.hashCode() : -113);
/*       */ 
/*  2042 */       hash = hash * 31 + ((this_t0 & 0x20) != 0 ? this.hint_ : -113);
/*       */ 
/*  2044 */       hash *= 31;
/*  2045 */       int i = 0; for (int n = this.composite_index_ != null ? this.composite_index_.size() : 0; i < n; i++) {
/*  2046 */         hash = hash * 31 + ((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).hashCode();
/*       */       }
/*       */ 
/*  2049 */       hash = hash * 31 + ((this_t0 & 0x800) != 0 ? 1237 : this.require_perfect_plan_ ? 1231 : -113);
/*       */ 
/*  2051 */       hash = hash * 31 + ((this_t0 & 0x1000) != 0 ? 1237 : this.keys_only_ ? 1231 : -113);
/*       */ 
/*  2053 */       hash = hash * 31 + ((this_t0 & 0x2000) != 0 ? this.transaction_.hashCode() : -113);
/*       */ 
/*  2055 */       hash = hash * 31 + ((this_t0 & 0x40) != 0 ? this.count_ : -113);
/*       */ 
/*  2057 */       hash = hash * 31 + ((this_t0 & 0x4000) != 0 ? 1237 : this.distinct_ ? 1231 : -113);
/*       */ 
/*  2059 */       hash = hash * 31 + ((this_t0 & 0x8000) != 0 ? 1237 : this.compile_ ? 1231 : -113);
/*       */ 
/*  2061 */       hash = hash * 31 + ((this_t0 & 0x10000) != 0 ? ProtocolSupport.hashCode(this.failover_ms_) : -113);
/*       */ 
/*  2063 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.name_space_) : -113);
/*       */ 
/*  2065 */       hash = hash * 31 + ((this_t0 & 0x200) != 0 ? this.compiled_cursor_.hashCode() : -113);
/*       */ 
/*  2067 */       hash = hash * 31 + ((this_t0 & 0x400) != 0 ? this.end_compiled_cursor_.hashCode() : -113);
/*  2068 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*  2069 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*  2071 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*  2075 */       int this_t0 = this.optional_0_;
/*  2076 */       if ((this_t0 & 0x1) != 1) {
/*  2077 */         return false;
/*       */       }
/*       */ 
/*  2080 */       if (((this_t0 & 0x8) != 0) && 
/*  2081 */         (!this.ancestor_.isInitialized())) {
/*  2082 */         return false;
/*       */       }
/*       */ 
/*  2086 */       if (this.filter_ != null) {
/*  2087 */         for (Filter v : this.filter_) {
/*  2088 */           if (!v.isInitialized()) {
/*  2089 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*  2094 */       if (this.order_ != null) {
/*  2095 */         for (Order v : this.order_) {
/*  2096 */           if (!v.isInitialized()) {
/*  2097 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*  2102 */       if (((this_t0 & 0x200) != 0) && 
/*  2103 */         (!this.compiled_cursor_.isInitialized())) {
/*  2104 */         return false;
/*       */       }
/*       */ 
/*  2108 */       if (((this_t0 & 0x400) != 0) && 
/*  2109 */         (!this.end_compiled_cursor_.isInitialized())) {
/*  2110 */         return false;
/*       */       }
/*       */ 
/*  2114 */       if (this.composite_index_ != null) {
/*  2115 */         for (OnestoreEntity.CompositeIndex v : this.composite_index_) {
/*  2116 */           if (!v.isInitialized()) {
/*  2117 */             return false;
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  2124 */       return ((this_t0 & 0x2000) == 0) || 
/*  2123 */         (this.transaction_.isInitialized());
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*  2132 */       int n = 1 + Protocol.stringSize(this.app_.length);
/*       */       int m;
/*  2135 */       n += (m = this.filter_ != null ? this.filter_.size() : 0);
/*  2136 */       for (int i = 0; i < m; i++) {
/*  2137 */         n += ((Filter)this.filter_.get(i)).encodingSize();
/*       */       }
/*       */ 
/*  2140 */       n += (m = this.order_ != null ? this.order_.size() : 0);
/*  2141 */       for (int i = 0; i < m; i++) {
/*  2142 */         n += ((Order)this.order_.get(i)).encodingSize();
/*       */       }
/*       */ 
/*  2145 */       n += 2 * (m = this.composite_index_ != null ? this.composite_index_.size() : 0);
/*  2146 */       for (int i = 0; i < m; i++) {
/*  2147 */         n += Protocol.stringSize(((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).encodingSize());
/*       */       }
/*  2149 */       int this_t0 = this.optional_0_;
/*  2150 */       if ((this_t0 & 0x1FE) != 0) {
/*  2151 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  2153 */           n += 2 + Protocol.stringSize(this.name_space_.length);
/*       */         }
/*  2155 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/*  2157 */           n += 1 + Protocol.stringSize(this.kind_.length);
/*       */         }
/*  2159 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/*  2161 */           n += 2 + Protocol.stringSize(this.ancestor_.encodingSize());
/*       */         }
/*  2163 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/*  2165 */           n += 1 + Protocol.stringSize(this.search_query_.length);
/*       */         }
/*  2167 */         if ((this_t0 & 0x20) != 0)
/*       */         {
/*  2169 */           n += 2 + Protocol.varLongSize(this.hint_);
/*       */         }
/*  2171 */         if ((this_t0 & 0x40) != 0)
/*       */         {
/*  2173 */           n += 2 + Protocol.varLongSize(this.count_);
/*       */         }
/*  2175 */         if ((this_t0 & 0x80) != 0)
/*       */         {
/*  2177 */           n += 1 + Protocol.varLongSize(this.offset_);
/*       */         }
/*  2179 */         if ((this_t0 & 0x100) != 0)
/*       */         {
/*  2181 */           n += 2 + Protocol.varLongSize(this.limit_);
/*       */         }
/*       */       }
/*  2184 */       if ((this_t0 & 0x1FE00) != 0) {
/*  2185 */         if ((this_t0 & 0x200) != 0)
/*       */         {
/*  2187 */           n += 2 + Protocol.stringSize(this.compiled_cursor_.encodingSize());
/*       */         }
/*  2189 */         if ((this_t0 & 0x400) != 0)
/*       */         {
/*  2191 */           n += 2 + Protocol.stringSize(this.end_compiled_cursor_.encodingSize());
/*       */         }
/*  2193 */         if ((this_t0 & 0x800) != 0)
/*       */         {
/*  2195 */           n += 3;
/*       */         }
/*  2197 */         if ((this_t0 & 0x1000) != 0)
/*       */         {
/*  2199 */           n += 3;
/*       */         }
/*  2201 */         if ((this_t0 & 0x2000) != 0)
/*       */         {
/*  2203 */           n += 2 + Protocol.stringSize(this.transaction_.encodingSize());
/*       */         }
/*  2205 */         if ((this_t0 & 0x4000) != 0)
/*       */         {
/*  2207 */           n += 3;
/*       */         }
/*  2209 */         if ((this_t0 & 0x8000) != 0)
/*       */         {
/*  2211 */           n += 3;
/*       */         }
/*  2213 */         if ((this_t0 & 0x10000) != 0)
/*       */         {
/*  2215 */           n += 2 + Protocol.varLongSize(this.failover_ms_);
/*       */         }
/*       */       }
/*       */ 
/*  2219 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*  2234 */       int n = 77 + this.app_.length;
/*       */       int m;
/*  2237 */       n += (m = this.filter_ != null ? this.filter_.size() : 0);
/*  2238 */       for (int i = 0; i < m; i++) {
/*  2239 */         n += ((Filter)this.filter_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/*  2242 */       n += (m = this.order_ != null ? this.order_.size() : 0);
/*  2243 */       for (int i = 0; i < m; i++) {
/*  2244 */         n += ((Order)this.order_.get(i)).maxEncodingSize();
/*       */       }
/*       */ 
/*  2247 */       n += 7 * (m = this.composite_index_ != null ? this.composite_index_.size() : 0);
/*  2248 */       for (int i = 0; i < m; i++) {
/*  2249 */         n += ((OnestoreEntity.CompositeIndex)this.composite_index_.get(i)).maxEncodingSize();
/*       */       }
/*  2251 */       int this_t0 = this.optional_0_;
/*  2252 */       if ((this_t0 & 0x261E) != 0) {
/*  2253 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*  2255 */           n += 7 + this.name_space_.length;
/*       */         }
/*  2257 */         if ((this_t0 & 0x4) != 0)
/*       */         {
/*  2259 */           n += 6 + this.kind_.length;
/*       */         }
/*  2261 */         if ((this_t0 & 0x8) != 0)
/*       */         {
/*  2263 */           n += 7 + this.ancestor_.maxEncodingSize();
/*       */         }
/*  2265 */         if ((this_t0 & 0x10) != 0)
/*       */         {
/*  2267 */           n += 6 + this.search_query_.length;
/*       */         }
/*  2269 */         if ((this_t0 & 0x200) != 0)
/*       */         {
/*  2271 */           n += 7 + this.compiled_cursor_.maxEncodingSize();
/*       */         }
/*  2273 */         if ((this_t0 & 0x400) != 0)
/*       */         {
/*  2275 */           n += 7 + this.end_compiled_cursor_.maxEncodingSize();
/*       */         }
/*  2277 */         if ((this_t0 & 0x2000) != 0)
/*       */         {
/*  2279 */           n += 7 + this.transaction_.maxEncodingSize();
/*       */         }
/*       */       }
/*       */ 
/*  2283 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*  2288 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*  2292 */       this.optional_0_ = 0;
/*  2293 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  2294 */       this.name_space_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  2295 */       this.kind_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  2296 */       if (this.ancestor_ != null) this.ancestor_.clear();
/*  2297 */       if (this.filter_ != null) this.filter_.clear();
/*  2298 */       this.search_query_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  2299 */       if (this.order_ != null) this.order_.clear();
/*  2300 */       this.hint_ = 0;
/*  2301 */       this.count_ = 0;
/*  2302 */       this.offset_ = 0;
/*  2303 */       this.limit_ = 0;
/*  2304 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.clear();
/*  2305 */       if (this.end_compiled_cursor_ != null) this.end_compiled_cursor_.clear();
/*  2306 */       if (this.composite_index_ != null) this.composite_index_.clear();
/*  2307 */       this.require_perfect_plan_ = false;
/*  2308 */       this.keys_only_ = false;
/*  2309 */       if (this.transaction_ != null) this.transaction_.clear();
/*  2310 */       this.distinct_ = false;
/*  2311 */       this.compile_ = false;
/*  2312 */       this.failover_ms_ = 0L;
/*  2313 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public Query newInstance() {
/*  2317 */       return new Query();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*  2321 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*  2455 */       sink.putByte(10);
/*  2456 */       sink.putPrefixedData(this.app_);
/*       */ 
/*  2458 */       int this_t0 = this.optional_0_;
/*  2459 */       if ((this_t0 & 0x4) != 0) {
/*  2460 */         sink.putByte(26);
/*  2461 */         sink.putPrefixedData(this.kind_);
/*       */       }
/*       */ 
/*  2464 */       int i = 0; for (int m = this.filter_ != null ? this.filter_.size() : 0; i < m; i++) {
/*  2465 */         Filter v = (Filter)this.filter_.get(i);
/*  2466 */         sink.putByte(35);
/*  2467 */         v.outputTo(sink);
/*       */       }
/*       */ 
/*  2470 */       if ((this_t0 & 0x10) != 0) {
/*  2471 */         sink.putByte(66);
/*  2472 */         sink.putPrefixedData(this.search_query_);
/*       */       }
/*       */ 
/*  2475 */       int i = 0; for (int m = this.order_ != null ? this.order_.size() : 0; i < m; i++) {
/*  2476 */         Order v = (Order)this.order_.get(i);
/*  2477 */         sink.putByte(75);
/*  2478 */         v.outputTo(sink);
/*       */       }
/*       */ 
/*  2481 */       if ((this_t0 & 0x80) != 0) {
/*  2482 */         sink.putByte(96);
/*  2483 */         sink.putVarLong(this.offset_);
/*       */       }
/*       */ 
/*  2486 */       if ((this_t0 & 0x100) != 0) {
/*  2487 */         sink.putByte(-128);
/*  2488 */         sink.putByte(1);
/*  2489 */         sink.putVarLong(this.limit_);
/*       */       }
/*       */ 
/*  2492 */       if ((this_t0 & 0x8) != 0) {
/*  2493 */         sink.putByte(-118);
/*  2494 */         sink.putByte(1);
/*  2495 */         sink.putForeign(this.ancestor_);
/*       */       }
/*       */ 
/*  2498 */       if ((this_t0 & 0x20) != 0) {
/*  2499 */         sink.putByte(-112);
/*  2500 */         sink.putByte(1);
/*  2501 */         sink.putVarLong(this.hint_);
/*       */       }
/*       */ 
/*  2504 */       int i = 0; for (int m = this.composite_index_ != null ? this.composite_index_.size() : 0; i < m; i++) {
/*  2505 */         OnestoreEntity.CompositeIndex v = (OnestoreEntity.CompositeIndex)this.composite_index_.get(i);
/*  2506 */         sink.putByte(-102);
/*  2507 */         sink.putByte(1);
/*  2508 */         sink.putForeign(v);
/*       */       }
/*       */ 
/*  2511 */       if ((this_t0 & 0x800) != 0) {
/*  2512 */         sink.putByte(-96);
/*  2513 */         sink.putByte(1);
/*  2514 */         sink.putBoolean(this.require_perfect_plan_);
/*       */       }
/*       */ 
/*  2517 */       if ((this_t0 & 0x1000) != 0) {
/*  2518 */         sink.putByte(-88);
/*  2519 */         sink.putByte(1);
/*  2520 */         sink.putBoolean(this.keys_only_);
/*       */       }
/*       */ 
/*  2523 */       if ((this_t0 & 0x2000) != 0) {
/*  2524 */         sink.putByte(-78);
/*  2525 */         sink.putByte(1);
/*  2526 */         sink.putForeign(this.transaction_);
/*       */       }
/*       */ 
/*  2529 */       if ((this_t0 & 0x40) != 0) {
/*  2530 */         sink.putByte(-72);
/*  2531 */         sink.putByte(1);
/*  2532 */         sink.putVarLong(this.count_);
/*       */       }
/*       */ 
/*  2535 */       if ((this_t0 & 0x4000) != 0) {
/*  2536 */         sink.putByte(-64);
/*  2537 */         sink.putByte(1);
/*  2538 */         sink.putBoolean(this.distinct_);
/*       */       }
/*       */ 
/*  2541 */       if ((this_t0 & 0x8000) != 0) {
/*  2542 */         sink.putByte(-56);
/*  2543 */         sink.putByte(1);
/*  2544 */         sink.putBoolean(this.compile_);
/*       */       }
/*       */ 
/*  2547 */       if ((this_t0 & 0x10000) != 0) {
/*  2548 */         sink.putByte(-48);
/*  2549 */         sink.putByte(1);
/*  2550 */         sink.putVarLong(this.failover_ms_);
/*       */       }
/*       */ 
/*  2553 */       if ((this_t0 & 0x2) != 0) {
/*  2554 */         sink.putByte(-22);
/*  2555 */         sink.putByte(1);
/*  2556 */         sink.putPrefixedData(this.name_space_);
/*       */       }
/*       */ 
/*  2559 */       if ((this_t0 & 0x200) != 0) {
/*  2560 */         sink.putByte(-14);
/*  2561 */         sink.putByte(1);
/*  2562 */         sink.putForeign(this.compiled_cursor_);
/*       */       }
/*       */ 
/*  2565 */       if ((this_t0 & 0x400) != 0) {
/*  2566 */         sink.putByte(-6);
/*  2567 */         sink.putByte(1);
/*  2568 */         sink.putForeign(this.end_compiled_cursor_);
/*       */       }
/*       */ 
/*  2571 */       if (this.uninterpreted != null)
/*  2572 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*  2577 */       boolean result = true;
/*  2578 */       int this_t0 = this.optional_0_;
/*       */ 
/*  2580 */       while (source.hasRemaining()) {
/*  2581 */         int tt = source.getVarInt();
/*  2582 */         switch (tt)
/*       */         {
/*       */         case 0:
/*  2586 */           result = false;
/*  2587 */           break;
/*       */         case 10:
/*  2590 */           this.app_ = source.getPrefixedData();
/*  2591 */           this_t0 |= 1;
/*  2592 */           break;
/*       */         case 26:
/*  2595 */           this.kind_ = source.getPrefixedData();
/*  2596 */           this_t0 |= 4;
/*  2597 */           break;
/*       */         case 35:
/*  2600 */           if (addFilter().merge(source)) break; result = false; break;
/*       */         case 66:
/*  2604 */           this.search_query_ = source.getPrefixedData();
/*  2605 */           this_t0 |= 16;
/*  2606 */           break;
/*       */         case 75:
/*  2609 */           if (addOrder().merge(source)) break; result = false; break;
/*       */         case 96:
/*  2613 */           this.offset_ = source.getVarInt();
/*  2614 */           this_t0 |= 128;
/*  2615 */           break;
/*       */         case 128:
/*  2618 */           this.limit_ = source.getVarInt();
/*  2619 */           this_t0 |= 256;
/*  2620 */           break;
/*       */         case 138:
/*  2623 */           source.push(source.getVarInt());
/*  2624 */           OnestoreEntity.Reference v17 = this.ancestor_;
/*  2625 */           if (v17 == null) this.ancestor_ = (v17 = new OnestoreEntity.Reference());
/*  2626 */           if (!v17.merge(source)) { result = false; break label750; }
/*  2627 */           source.pop();
/*  2628 */           this_t0 |= 8;
/*  2629 */           break;
/*       */         case 144:
/*  2632 */           this.hint_ = source.getVarInt();
/*  2633 */           this_t0 |= 32;
/*  2634 */           break;
/*       */         case 154:
/*  2637 */           source.push(source.getVarInt());
/*  2638 */           if (!addCompositeIndex().merge(source)) { result = false; break label750; }
/*  2639 */           source.pop();
/*  2640 */           break;
/*       */         case 160:
/*  2643 */           this.require_perfect_plan_ = source.getBoolean();
/*  2644 */           this_t0 |= 2048;
/*  2645 */           break;
/*       */         case 168:
/*  2648 */           this.keys_only_ = source.getBoolean();
/*  2649 */           this_t0 |= 4096;
/*  2650 */           break;
/*       */         case 178:
/*  2653 */           source.push(source.getVarInt());
/*  2654 */           DatastorePb.Transaction v22 = this.transaction_;
/*  2655 */           if (v22 == null) this.transaction_ = (v22 = new DatastorePb.Transaction());
/*  2656 */           if (!v22.merge(source)) { result = false; break label750; }
/*  2657 */           source.pop();
/*  2658 */           this_t0 |= 8192;
/*  2659 */           break;
/*       */         case 184:
/*  2662 */           this.count_ = source.getVarInt();
/*  2663 */           this_t0 |= 64;
/*  2664 */           break;
/*       */         case 192:
/*  2667 */           this.distinct_ = source.getBoolean();
/*  2668 */           this_t0 |= 16384;
/*  2669 */           break;
/*       */         case 200:
/*  2672 */           this.compile_ = source.getBoolean();
/*  2673 */           this_t0 |= 32768;
/*  2674 */           break;
/*       */         case 208:
/*  2677 */           this.failover_ms_ = source.getVarLong();
/*  2678 */           this_t0 |= 65536;
/*  2679 */           break;
/*       */         case 234:
/*  2682 */           this.name_space_ = source.getPrefixedData();
/*  2683 */           this_t0 |= 2;
/*  2684 */           break;
/*       */         case 242:
/*  2687 */           source.push(source.getVarInt());
/*  2688 */           DatastorePb.CompiledCursor v30 = this.compiled_cursor_;
/*  2689 */           if (v30 == null) this.compiled_cursor_ = (v30 = new DatastorePb.CompiledCursor());
/*  2690 */           if (!v30.merge(source)) { result = false; break label750; }
/*  2691 */           source.pop();
/*  2692 */           this_t0 |= 512;
/*  2693 */           break;
/*       */         case 250:
/*  2696 */           source.push(source.getVarInt());
/*  2697 */           DatastorePb.CompiledCursor v31 = this.end_compiled_cursor_;
/*  2698 */           if (v31 == null) this.end_compiled_cursor_ = (v31 = new DatastorePb.CompiledCursor());
/*  2699 */           if (!v31.merge(source)) { result = false; break label750; }
/*  2700 */           source.pop();
/*  2701 */           this_t0 |= 1024;
/*  2702 */           break;
/*       */         default:
/*  2704 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*  2709 */       label750: this.optional_0_ = this_t0;
/*  2710 */       return result;
/*       */     }
/*       */ 
/*       */     public Query getDefaultInstanceForType()
/*       */     {
/*  2715 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final Query getDefaultInstance() {
/*  2719 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public Query freeze()
/*       */     {
/*  3007 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/*  3008 */       this.name_space_ = ProtocolSupport.freezeString(this.name_space_);
/*  3009 */       this.kind_ = ProtocolSupport.freezeString(this.kind_);
/*  3010 */       if (this.ancestor_ != null) this.ancestor_.freeze();
/*  3011 */       this.filter_ = ProtocolSupport.freezeMessages(this.filter_);
/*  3012 */       this.search_query_ = ProtocolSupport.freezeString(this.search_query_);
/*  3013 */       this.order_ = ProtocolSupport.freezeMessages(this.order_);
/*  3014 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.freeze();
/*  3015 */       if (this.end_compiled_cursor_ != null) this.end_compiled_cursor_.freeze();
/*  3016 */       this.composite_index_ = ProtocolSupport.freezeMessages(this.composite_index_);
/*  3017 */       if (this.transaction_ != null) this.transaction_.freeze();
/*  3018 */       return this;
/*       */     }
/*       */ 
/*       */     public Query unfreeze() {
/*  3022 */       if (this.ancestor_ != null) this.ancestor_.unfreeze();
/*  3023 */       this.filter_ = ProtocolSupport.unfreezeMessages(this.filter_);
/*  3024 */       this.order_ = ProtocolSupport.unfreezeMessages(this.order_);
/*  3025 */       if (this.compiled_cursor_ != null) this.compiled_cursor_.unfreeze();
/*  3026 */       if (this.end_compiled_cursor_ != null) this.end_compiled_cursor_.unfreeze();
/*  3027 */       this.composite_index_ = ProtocolSupport.unfreezeMessages(this.composite_index_);
/*  3028 */       if (this.transaction_ != null) this.transaction_.unfreeze();
/*  3029 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean isFrozen() {
/*  3033 */       return ((this.ancestor_ != null) && (this.ancestor_.isFrozen())) || (ProtocolSupport.isFrozenMessages(this.filter_)) || (ProtocolSupport.isFrozenMessages(this.order_)) || ((this.compiled_cursor_ != null) && (this.compiled_cursor_.isFrozen())) || ((this.end_compiled_cursor_ != null) && (this.end_compiled_cursor_.isFrozen())) || (ProtocolSupport.isFrozenMessages(this.composite_index_)) || ((this.transaction_ != null) && (this.transaction_.isFrozen()));
/*       */     }
/*       */ 
/*       */     public UninterpretedTags getUninterpretedForWrite()
/*       */     {
/*  3042 */       if (this.uninterpreted == null) {
/*  3043 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*  3045 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*  2723 */       IMMUTABLE_DEFAULT_INSTANCE = new Query()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.Query clearApp()
/*       */         {
/*  2731 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setAppAsBytes(byte[] x) {
/*  2734 */           ProtocolSupport.unsupportedOperation();
/*  2735 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setApp(String v) {
/*  2738 */           ProtocolSupport.unsupportedOperation();
/*  2739 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setApp(String v, Charset cs) {
/*  2742 */           ProtocolSupport.unsupportedOperation();
/*  2743 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearNameSpace()
/*       */         {
/*  2748 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setNameSpaceAsBytes(byte[] x) {
/*  2751 */           ProtocolSupport.unsupportedOperation();
/*  2752 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setNameSpace(String v) {
/*  2755 */           ProtocolSupport.unsupportedOperation();
/*  2756 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setNameSpace(String v, Charset cs) {
/*  2759 */           ProtocolSupport.unsupportedOperation();
/*  2760 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearKind()
/*       */         {
/*  2765 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setKindAsBytes(byte[] x) {
/*  2768 */           ProtocolSupport.unsupportedOperation();
/*  2769 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setKind(String v) {
/*  2772 */           ProtocolSupport.unsupportedOperation();
/*  2773 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setKind(String v, Charset cs) {
/*  2776 */           ProtocolSupport.unsupportedOperation();
/*  2777 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearAncestor()
/*       */         {
/*  2782 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setAncestor(OnestoreEntity.Reference x) {
/*  2785 */           ProtocolSupport.unsupportedOperation();
/*  2786 */           return this;
/*       */         }
/*       */         public OnestoreEntity.Reference getMutableAncestor() {
/*  2789 */           return (OnestoreEntity.Reference)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearFilter()
/*       */         {
/*  2794 */           return this;
/*       */         }
/*       */         public DatastorePb.Query.Filter getMutableFilter(int i) {
/*  2797 */           return (DatastorePb.Query.Filter)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Filter addFilter() {
/*  2800 */           return (DatastorePb.Query.Filter)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Filter addFilter(DatastorePb.Query.Filter v) {
/*  2803 */           return (DatastorePb.Query.Filter)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Filter insertFilter(int i, DatastorePb.Query.Filter v) {
/*  2806 */           return (DatastorePb.Query.Filter)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Filter removeFilter(int i) {
/*  2809 */           return (DatastorePb.Query.Filter)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearSearchQuery()
/*       */         {
/*  2814 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setSearchQueryAsBytes(byte[] x) {
/*  2817 */           ProtocolSupport.unsupportedOperation();
/*  2818 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setSearchQuery(String v) {
/*  2821 */           ProtocolSupport.unsupportedOperation();
/*  2822 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setSearchQuery(String v, Charset cs) {
/*  2825 */           ProtocolSupport.unsupportedOperation();
/*  2826 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearOrder()
/*       */         {
/*  2831 */           return this;
/*       */         }
/*       */         public DatastorePb.Query.Order getMutableOrder(int i) {
/*  2834 */           return (DatastorePb.Query.Order)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Order addOrder() {
/*  2837 */           return (DatastorePb.Query.Order)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Order addOrder(DatastorePb.Query.Order v) {
/*  2840 */           return (DatastorePb.Query.Order)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Order insertOrder(int i, DatastorePb.Query.Order v) {
/*  2843 */           return (DatastorePb.Query.Order)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public DatastorePb.Query.Order removeOrder(int i) {
/*  2846 */           return (DatastorePb.Query.Order)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearHint()
/*       */         {
/*  2851 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setHint(int x) {
/*  2854 */           ProtocolSupport.unsupportedOperation();
/*  2855 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearCount()
/*       */         {
/*  2860 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setCount(int x) {
/*  2863 */           ProtocolSupport.unsupportedOperation();
/*  2864 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearOffset()
/*       */         {
/*  2869 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setOffset(int x) {
/*  2872 */           ProtocolSupport.unsupportedOperation();
/*  2873 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearLimit()
/*       */         {
/*  2878 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setLimit(int x) {
/*  2881 */           ProtocolSupport.unsupportedOperation();
/*  2882 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearCompiledCursor()
/*       */         {
/*  2887 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setCompiledCursor(DatastorePb.CompiledCursor x) {
/*  2890 */           ProtocolSupport.unsupportedOperation();
/*  2891 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledCursor getMutableCompiledCursor() {
/*  2894 */           return (DatastorePb.CompiledCursor)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearEndCompiledCursor()
/*       */         {
/*  2899 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setEndCompiledCursor(DatastorePb.CompiledCursor x) {
/*  2902 */           ProtocolSupport.unsupportedOperation();
/*  2903 */           return this;
/*       */         }
/*       */         public DatastorePb.CompiledCursor getMutableEndCompiledCursor() {
/*  2906 */           return (DatastorePb.CompiledCursor)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearCompositeIndex()
/*       */         {
/*  2911 */           return this;
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex getMutableCompositeIndex(int i) {
/*  2914 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addCompositeIndex() {
/*  2917 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex addCompositeIndex(OnestoreEntity.CompositeIndex v) {
/*  2920 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex insertCompositeIndex(int i, OnestoreEntity.CompositeIndex v) {
/*  2923 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */         public OnestoreEntity.CompositeIndex removeCompositeIndex(int i) {
/*  2926 */           return (OnestoreEntity.CompositeIndex)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearRequirePerfectPlan()
/*       */         {
/*  2931 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setRequirePerfectPlan(boolean x) {
/*  2934 */           ProtocolSupport.unsupportedOperation();
/*  2935 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearKeysOnly()
/*       */         {
/*  2940 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setKeysOnly(boolean x) {
/*  2943 */           ProtocolSupport.unsupportedOperation();
/*  2944 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearTransaction()
/*       */         {
/*  2949 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setTransaction(DatastorePb.Transaction x) {
/*  2952 */           ProtocolSupport.unsupportedOperation();
/*  2953 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction getMutableTransaction() {
/*  2956 */           return (DatastorePb.Transaction)ProtocolSupport.unsupportedOperation();
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearDistinct()
/*       */         {
/*  2961 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setDistinct(boolean x) {
/*  2964 */           ProtocolSupport.unsupportedOperation();
/*  2965 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearCompile()
/*       */         {
/*  2970 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setCompile(boolean x) {
/*  2973 */           ProtocolSupport.unsupportedOperation();
/*  2974 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query clearFailoverMs()
/*       */         {
/*  2979 */           return this;
/*       */         }
/*       */         public DatastorePb.Query setFailoverMs(long x) {
/*  2982 */           ProtocolSupport.unsupportedOperation();
/*  2983 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Query mergeFrom(DatastorePb.Query that) {
/*  2987 */           ProtocolSupport.unsupportedOperation();
/*  2988 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*  2991 */           ProtocolSupport.unsupportedOperation();
/*  2992 */           return false;
/*       */         }
/*       */         public DatastorePb.Query freeze() {
/*  2995 */           return this;
/*       */         }
/*       */         public DatastorePb.Query unfreeze() {
/*  2998 */           ProtocolSupport.unsupportedOperation();
/*  2999 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*  3002 */           return true;
/*       */         }
/*       */       };
/*  3073 */       text = new String[32];
/*       */ 
/*  3075 */       text[0] = "ErrorCode";
/*  3076 */       text[1] = "app";
/*  3077 */       text[3] = "kind";
/*  3078 */       text[4] = "Filter";
/*  3079 */       text[6] = "op";
/*  3080 */       text[8] = "search_query";
/*  3081 */       text[9] = "Order";
/*  3082 */       text[10] = "property";
/*  3083 */       text[11] = "direction";
/*  3084 */       text[12] = "offset";
/*  3085 */       text[14] = "property";
/*  3086 */       text[16] = "limit";
/*  3087 */       text[17] = "ancestor";
/*  3088 */       text[18] = "hint";
/*  3089 */       text[19] = "composite_index";
/*  3090 */       text[20] = "require_perfect_plan";
/*  3091 */       text[21] = "keys_only";
/*  3092 */       text[22] = "transaction";
/*  3093 */       text[23] = "count";
/*  3094 */       text[24] = "distinct";
/*  3095 */       text[25] = "compile";
/*  3096 */       text[26] = "failover_ms";
/*  3097 */       text[29] = "name_space";
/*  3098 */       text[30] = "compiled_cursor";
/*  3099 */       text[31] = "end_compiled_cursor";
/*       */ 
/*  3102 */       types = new int[32];
/*       */ 
/*  3104 */       Arrays.fill(types, 6);
/*  3105 */       types[0] = 0;
/*  3106 */       types[1] = 2;
/*  3107 */       types[3] = 2;
/*  3108 */       types[4] = 3;
/*  3109 */       types[6] = 0;
/*  3110 */       types[8] = 2;
/*  3111 */       types[9] = 3;
/*  3112 */       types[10] = 2;
/*  3113 */       types[11] = 0;
/*  3114 */       types[12] = 0;
/*  3115 */       types[14] = 2;
/*  3116 */       types[16] = 0;
/*  3117 */       types[17] = 2;
/*  3118 */       types[18] = 0;
/*  3119 */       types[19] = 2;
/*  3120 */       types[20] = 0;
/*  3121 */       types[21] = 0;
/*  3122 */       types[22] = 2;
/*  3123 */       types[23] = 0;
/*  3124 */       types[24] = 0;
/*  3125 */       types[25] = 0;
/*  3126 */       types[26] = 0;
/*  3127 */       types[29] = 2;
/*  3128 */       types[30] = 2;
/*  3129 */       types[31] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*  2325 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Query.class, "", new ProtocolType.FieldType[] { new ProtocolType.FieldType("app", "app", 1, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("name_space", "name_space", 29, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("kind", "kind", 3, 2, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("ancestor", "ancestor", 17, 3, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, OnestoreEntity.Reference.class), new ProtocolType.FieldType("Filter", "filter", 4, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, DatastorePb.Query.Filter.class), new ProtocolType.FieldType("search_query", "search_query", 8, 4, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("Order", "order", 9, -1, ProtocolType.FieldBaseType.GROUP, ProtocolType.Presence.REPEATED, DatastorePb.Query.Order.class), new ProtocolType.FieldType("hint", "hint", 18, 5, ProtocolType.Presence.OPTIONAL, DatastorePb.Query.Hint.class), new ProtocolType.FieldType("count", "count", 23, 6, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("offset", "offset", 12, 7, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("limit", "limit", 16, 8, ProtocolType.FieldBaseType.INT32, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("compiled_cursor", "compiled_cursor", 30, 9, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.CompiledCursor.class), new ProtocolType.FieldType("end_compiled_cursor", "end_compiled_cursor", 31, 10, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.CompiledCursor.class), new ProtocolType.FieldType("composite_index", "composite_index", 19, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.CompositeIndex.class), new ProtocolType.FieldType("require_perfect_plan", "require_perfect_plan", 20, 11, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("keys_only", "keys_only", 21, 12, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("transaction", "transaction", 22, 13, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.OPTIONAL, DatastorePb.Transaction.class), new ProtocolType.FieldType("distinct", "distinct", 24, 14, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("compile", "compile", 25, 15, ProtocolType.FieldBaseType.BOOL, ProtocolType.Presence.OPTIONAL), new ProtocolType.FieldType("failover_ms", "failover_ms", 26, 16, ProtocolType.FieldBaseType.INT64, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */ 
/*       */     public static enum Hint
/*       */       implements ProtocolMessageEnum
/*       */     {
/*  1188 */       ORDER_FIRST(1), 
/*  1189 */       ANCESTOR_FIRST(2), 
/*  1190 */       FILTER_FIRST(3);
/*       */ 
/*       */       public static final Hint Hint_MIN;
/*       */       public static final Hint Hint_MAX;
/*       */       private final int value;
/*       */ 
/*  1195 */       public int getValue() { return this.value; }
/*       */ 
/*       */       public static Hint valueOf(int value) {
/*  1198 */         switch (value) { case 1:
/*  1199 */           return ORDER_FIRST;
/*       */         case 2:
/*  1200 */           return ANCESTOR_FIRST;
/*       */         case 3:
/*  1201 */           return FILTER_FIRST;
/*       */         }
/*  1203 */         return null;
/*       */       }
/*       */ 
/*       */       private Hint(int v) {
/*  1207 */         this.value = v;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  1192 */         Hint_MIN = ORDER_FIRST;
/*  1193 */         Hint_MAX = FILTER_FIRST;
/*       */       }
/*       */     }
/*       */ 
/*       */     public static class Order extends ProtocolMessage<Order>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*   814 */       private byte[] property_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*   815 */       private int direction_ = 1;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final Order IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final byte[] getPropertyAsBytes()
/*       */       {
/*   842 */         return this.property_;
/*       */       }
/*       */       public final boolean hasProperty() {
/*   845 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public Order clearProperty() {
/*   848 */         this.optional_0_ &= -2;
/*   849 */         this.property_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*   850 */         return this;
/*       */       }
/*       */       public Order setPropertyAsBytes(byte[] x) {
/*   853 */         this.optional_0_ |= 1;
/*   854 */         this.property_ = x;
/*   855 */         return this;
/*       */       }
/*       */       public final String getProperty() {
/*   858 */         return ProtocolSupport.toStringUtf8(this.property_);
/*       */       }
/*       */       public Order setProperty(String v) {
/*   861 */         if (v == null) throw new NullPointerException();
/*   862 */         this.optional_0_ |= 1;
/*   863 */         this.property_ = ProtocolSupport.toBytesUtf8(v);
/*   864 */         return this;
/*       */       }
/*       */       public final String getProperty(Charset cs) {
/*   867 */         return ProtocolSupport.toString(this.property_, cs);
/*       */       }
/*       */       public Order setProperty(String v, Charset cs) {
/*   870 */         if (v == null) throw new NullPointerException();
/*   871 */         this.optional_0_ |= 1;
/*   872 */         this.property_ = ProtocolSupport.toBytes(v, cs);
/*   873 */         return this;
/*       */       }
/*       */ 
/*       */       public final int getDirection()
/*       */       {
/*   878 */         return this.direction_;
/*       */       }
/*       */       public Direction getDirectionEnum() {
/*   881 */         return Direction.valueOf(getDirection());
/*       */       }
/*       */       public final boolean hasDirection() {
/*   884 */         return (this.optional_0_ & 0x2) != 0;
/*       */       }
/*       */       public Order clearDirection() {
/*   887 */         this.optional_0_ &= -3;
/*   888 */         this.direction_ = 1;
/*   889 */         return this;
/*       */       }
/*       */       public Order setDirection(int x) {
/*   892 */         this.optional_0_ |= 2;
/*   893 */         this.direction_ = x;
/*   894 */         return this;
/*       */       }
/*       */       public Order setDirection(Direction x) {
/*   897 */         if (x == null) {
/*   898 */           this.optional_0_ &= -3;
/*   899 */           this.direction_ = 1;
/*       */         } else {
/*   901 */           setDirection(x.getValue());
/*       */         }
/*   903 */         return this;
/*       */       }
/*       */ 
/*       */       public Order mergeFrom(Order that)
/*       */       {
/*   910 */         assert (that != this);
/*   911 */         int this_t0 = this.optional_0_;
/*   912 */         int that_t0 = that.optional_0_;
/*       */ 
/*   914 */         if ((that_t0 & 0x1) != 0) {
/*   915 */           this_t0 |= 1;
/*   916 */           this.property_ = that.property_;
/*       */         }
/*       */ 
/*   919 */         if ((that_t0 & 0x2) != 0) {
/*   920 */           this_t0 |= 2;
/*   921 */           this.direction_ = that.direction_;
/*       */         }
/*       */ 
/*   924 */         if (that.uninterpreted != null) {
/*   925 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*   927 */         this.optional_0_ = this_t0;
/*   928 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(Order that) {
/*   932 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(Order that) {
/*   936 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(Order that, boolean ignoreUninterpreted) {
/*   940 */         if (that == null) return false;
/*   941 */         if (that == this) return true;
/*   942 */         int this_t0 = this.optional_0_;
/*   943 */         int that_t0 = that.optional_0_;
/*   944 */         if (this_t0 != that_t0) return false;
/*       */ 
/*   946 */         if (((this_t0 & 0x1) != 0) && 
/*   947 */           (!Arrays.equals(this.property_, that.property_))) return false;
/*       */ 
/*   950 */         if (((this_t0 & 0x2) != 0) && 
/*   951 */           (this.direction_ != that.direction_)) return false;
/*       */ 
/*   954 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*   959 */         return ((that instanceof Order)) && (equals((Order)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*   963 */         int hash = 1286285931;
/*       */ 
/*   965 */         int this_t0 = this.optional_0_;
/*   966 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? Arrays.hashCode(this.property_) : -113);
/*       */ 
/*   968 */         hash = hash * 31 + ((this_t0 & 0x2) != 0 ? this.direction_ : -113);
/*   969 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*   970 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*   972 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized() {
/*   976 */         int this_t0 = this.optional_0_;
/*       */ 
/*   978 */         return (this_t0 & 0x1) == 1;
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*   986 */         int n = 2 + Protocol.stringSize(this.property_.length);
/*   987 */         int this_t0 = this.optional_0_;
/*   988 */         if ((this_t0 & 0x2) != 0)
/*       */         {
/*   990 */           n += 1 + Protocol.varLongSize(this.direction_);
/*       */         }
/*       */ 
/*   993 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*  1001 */         int n = 18 + this.property_.length;
/*       */ 
/*  1003 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*  1008 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*  1012 */         this.optional_0_ = 0;
/*  1013 */         this.property_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*  1014 */         this.direction_ = 1;
/*  1015 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public Order newInstance() {
/*  1019 */         return new Order();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*  1023 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*  1038 */         sink.putByte(82);
/*  1039 */         sink.putPrefixedData(this.property_);
/*       */ 
/*  1041 */         int this_t0 = this.optional_0_;
/*  1042 */         if ((this_t0 & 0x2) != 0) {
/*  1043 */           sink.putByte(88);
/*  1044 */           sink.putVarLong(this.direction_);
/*       */         }
/*       */ 
/*  1047 */         if (this.uninterpreted != null) {
/*  1048 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*  1051 */         sink.putByte(76);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*  1055 */         boolean result = true;
/*  1056 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*  1059 */           int tt = source.getVarInt();
/*  1060 */           switch (tt)
/*       */           {
/*       */           case 76:
/*  1063 */             break;
/*       */           case 0:
/*  1067 */             result = false;
/*  1068 */             break;
/*       */           case 82:
/*  1071 */             this.property_ = source.getPrefixedData();
/*  1072 */             this_t0 |= 1;
/*  1073 */             break;
/*       */           case 88:
/*  1076 */             this.direction_ = source.getVarInt();
/*  1077 */             this_t0 |= 2;
/*  1078 */             break;
/*       */           default:
/*  1080 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*  1085 */         this.optional_0_ = this_t0;
/*  1086 */         return result;
/*       */       }
/*       */ 
/*       */       public Order getDefaultInstanceForType()
/*       */       {
/*  1091 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final Order getDefaultInstance() {
/*  1095 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public Order freeze()
/*       */       {
/*  1152 */         this.property_ = ProtocolSupport.freezeString(this.property_);
/*  1153 */         return this;
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*  1156 */         if (this.uninterpreted == null) {
/*  1157 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*  1159 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*  1099 */         IMMUTABLE_DEFAULT_INSTANCE = new Order()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.Query.Order clearProperty()
/*       */           {
/*  1107 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Order setPropertyAsBytes(byte[] x) {
/*  1110 */             ProtocolSupport.unsupportedOperation();
/*  1111 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Order setProperty(String v) {
/*  1114 */             ProtocolSupport.unsupportedOperation();
/*  1115 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Order setProperty(String v, Charset cs) {
/*  1118 */             ProtocolSupport.unsupportedOperation();
/*  1119 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.Query.Order clearDirection()
/*       */           {
/*  1124 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Order setDirection(int x) {
/*  1127 */             ProtocolSupport.unsupportedOperation();
/*  1128 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.Query.Order mergeFrom(DatastorePb.Query.Order that) {
/*  1132 */             ProtocolSupport.unsupportedOperation();
/*  1133 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*  1136 */             ProtocolSupport.unsupportedOperation();
/*  1137 */             return false;
/*       */           }
/*       */           public DatastorePb.Query.Order freeze() {
/*  1140 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Order unfreeze() {
/*  1143 */             ProtocolSupport.unsupportedOperation();
/*  1144 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*  1147 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*  1027 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Query.Order.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("property", "property", 10, 0, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("direction", "direction", 11, 1, ProtocolType.Presence.OPTIONAL, DatastorePb.Query.Order.Direction.class) });
/*       */       }
/*       */ 
/*       */       public static enum Direction
/*       */         implements ProtocolMessageEnum
/*       */       {
/*   820 */         ASCENDING(1), 
/*   821 */         DESCENDING(2);
/*       */ 
/*       */         public static final Direction Direction_MIN;
/*       */         public static final Direction Direction_MAX;
/*       */         private final int value;
/*       */ 
/*   826 */         public int getValue() { return this.value; }
/*       */ 
/*       */         public static Direction valueOf(int value) {
/*   829 */           switch (value) { case 1:
/*   830 */             return ASCENDING;
/*       */           case 2:
/*   831 */             return DESCENDING;
/*       */           }
/*   833 */           return null;
/*       */         }
/*       */ 
/*       */         private Direction(int v) {
/*   837 */           this.value = v;
/*       */         }
/*       */ 
/*       */         static
/*       */         {
/*   823 */           Direction_MIN = ASCENDING;
/*   824 */           Direction_MAX = DESCENDING;
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */     public static class Filter extends ProtocolMessage<Filter>
/*       */     {
/*       */       private static final long serialVersionUID = 1L;
/*   406 */       private int op_ = 0;
/*   407 */       private List<OnestoreEntity.Property> property_ = null;
/*       */       private UninterpretedTags uninterpreted;
/*       */       private int optional_0_;
/*       */       public static final Filter IMMUTABLE_DEFAULT_INSTANCE;
/*       */ 
/*       */       public final int getOp()
/*       */       {
/*   444 */         return this.op_;
/*       */       }
/*       */       public Operator getOpEnum() {
/*   447 */         return hasOp() ? Operator.valueOf(getOp()) : null;
/*       */       }
/*       */       public final boolean hasOp() {
/*   450 */         return (this.optional_0_ & 0x1) != 0;
/*       */       }
/*       */       public Filter clearOp() {
/*   453 */         this.optional_0_ &= -2;
/*   454 */         this.op_ = 0;
/*   455 */         return this;
/*       */       }
/*       */       public Filter setOp(int x) {
/*   458 */         this.optional_0_ |= 1;
/*   459 */         this.op_ = x;
/*   460 */         return this;
/*       */       }
/*       */       public Filter setOp(Operator x) {
/*   463 */         if (x == null) {
/*   464 */           this.optional_0_ &= -2;
/*   465 */           this.op_ = 0;
/*       */         } else {
/*   467 */           setOp(x.getValue());
/*       */         }
/*   469 */         return this;
/*       */       }
/*       */ 
/*       */       public final int propertySize()
/*       */       {
/*   474 */         return this.property_ != null ? this.property_.size() : 0;
/*       */       }
/*       */       public final OnestoreEntity.Property getProperty(int i) {
/*   477 */         if (!$assertionsDisabled) if (i >= 0) { if (i < (this.property_ != null ? this.property_.size() : 0)); } else throw new AssertionError();
/*   478 */         return (OnestoreEntity.Property)this.property_.get(i);
/*       */       }
/*       */       public Filter clearProperty() {
/*   481 */         if (this.property_ != null) this.property_.clear();
/*   482 */         return this;
/*       */       }
/*       */       public OnestoreEntity.Property getMutableProperty(int i) {
/*   485 */         assert ((i >= 0) && (this.property_ != null) && (i < this.property_.size()));
/*   486 */         return (OnestoreEntity.Property)this.property_.get(i);
/*       */       }
/*       */       public OnestoreEntity.Property addProperty() {
/*   489 */         OnestoreEntity.Property v = new OnestoreEntity.Property();
/*   490 */         if (this.property_ == null) this.property_ = new ArrayList(4);
/*   491 */         this.property_.add(v);
/*   492 */         return v;
/*       */       }
/*       */       public OnestoreEntity.Property addProperty(OnestoreEntity.Property v) {
/*   495 */         if (this.property_ == null) this.property_ = new ArrayList(4);
/*   496 */         this.property_.add(v);
/*   497 */         return v;
/*       */       }
/*       */       public OnestoreEntity.Property insertProperty(int i, OnestoreEntity.Property v) {
/*   500 */         if (this.property_ == null) this.property_ = new ArrayList(4);
/*   501 */         this.property_.add(i, v);
/*   502 */         return v;
/*       */       }
/*       */       public OnestoreEntity.Property removeProperty(int i) {
/*   505 */         return (OnestoreEntity.Property)this.property_.remove(i);
/*       */       }
/*       */       public final Iterator<OnestoreEntity.Property> propertyIterator() {
/*   508 */         if (this.property_ == null) {
/*   509 */           return ProtocolSupport.emptyIterator();
/*       */         }
/*   511 */         return this.property_.iterator();
/*       */       }
/*       */       public final List<OnestoreEntity.Property> propertys() {
/*   514 */         return ProtocolSupport.unmodifiableList(this.property_);
/*       */       }
/*       */       public final List<OnestoreEntity.Property> mutablePropertys() {
/*   517 */         if (this.property_ == null) this.property_ = new ArrayList(4);
/*   518 */         return this.property_;
/*       */       }
/*       */ 
/*       */       public Filter mergeFrom(Filter that)
/*       */       {
/*   525 */         assert (that != this);
/*   526 */         int this_t0 = this.optional_0_;
/*   527 */         int that_t0 = that.optional_0_;
/*       */ 
/*   529 */         if ((that_t0 & 0x1) != 0) {
/*   530 */           this_t0 |= 1;
/*   531 */           this.op_ = that.op_;
/*       */         }
/*       */ 
/*   534 */         if (that.property_ != null) {
/*   535 */           for (OnestoreEntity.Property v : that.property_) {
/*   536 */             addProperty().mergeFrom(v);
/*       */           }
/*       */         }
/*       */ 
/*   540 */         if (that.uninterpreted != null) {
/*   541 */           getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */         }
/*   543 */         this.optional_0_ = this_t0;
/*   544 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean equalsIgnoreUninterpreted(Filter that) {
/*   548 */         return equals(that, true);
/*       */       }
/*       */ 
/*       */       public boolean equals(Filter that) {
/*   552 */         return equals(that, false);
/*       */       }
/*       */ 
/*       */       public boolean equals(Filter that, boolean ignoreUninterpreted) {
/*   556 */         if (that == null) return false;
/*   557 */         if (that == this) return true;
/*   558 */         int this_t0 = this.optional_0_;
/*   559 */         int that_t0 = that.optional_0_;
/*   560 */         if (this_t0 != that_t0) return false;
/*       */ 
/*   562 */         if (((this_t0 & 0x1) != 0) && 
/*   563 */           (this.op_ != that.op_)) return false;
/*   567 */         int n;
/*   567 */         if ((n = this.property_ != null ? this.property_.size() : 0) != (that.property_ != null ? that.property_.size() : 0)) return false;
/*   568 */         for (int i = 0; i < n; i++) {
/*   569 */           if (!((OnestoreEntity.Property)this.property_.get(i)).equals((OnestoreEntity.Property)that.property_.get(i), ignoreUninterpreted)) return false;
/*       */         }
/*       */ 
/*   572 */         return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */       }
/*       */ 
/*       */       public boolean equals(Object that)
/*       */       {
/*   577 */         return ((that instanceof Filter)) && (equals((Filter)that));
/*       */       }
/*       */ 
/*       */       public int hashCode() {
/*   581 */         int hash = -158325294;
/*       */ 
/*   583 */         int this_t0 = this.optional_0_;
/*   584 */         hash = hash * 31 + ((this_t0 & 0x1) != 0 ? this.op_ : -113);
/*       */ 
/*   586 */         hash *= 31;
/*   587 */         int i = 0; for (int n = this.property_ != null ? this.property_.size() : 0; i < n; i++) {
/*   588 */           hash = hash * 31 + ((OnestoreEntity.Property)this.property_.get(i)).hashCode();
/*       */         }
/*   590 */         if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*   591 */           hash = hash * 31 + this.uninterpreted.hashCode();
/*       */         }
/*   593 */         return hash;
/*       */       }
/*       */ 
/*       */       public boolean isInitialized() {
/*   597 */         int this_t0 = this.optional_0_;
/*   598 */         if ((this_t0 & 0x1) != 1) {
/*   599 */           return false;
/*       */         }
/*       */ 
/*   602 */         if (this.property_ != null) {
/*   603 */           for (OnestoreEntity.Property v : this.property_) {
/*   604 */             if (!v.isInitialized()) {
/*   605 */               return false;
/*       */             }
/*       */           }
/*       */         }
/*   609 */         return true;
/*       */       }
/*       */ 
/*       */       public int encodingSize()
/*       */       {
/*   615 */         int n = 2 + Protocol.varLongSize(this.op_);
/*       */         int m;
/*   618 */         n += (m = this.property_ != null ? this.property_.size() : 0);
/*   619 */         for (int i = 0; i < m; i++) {
/*   620 */           n += Protocol.stringSize(((OnestoreEntity.Property)this.property_.get(i)).encodingSize());
/*       */         }
/*       */ 
/*   623 */         return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */       }
/*       */ 
/*       */       public int maxEncodingSize()
/*       */       {
/*   630 */         int n = 12;
/*       */         int m;
/*   633 */         n += 6 * (m = this.property_ != null ? this.property_.size() : 0);
/*   634 */         for (int i = 0; i < m; i++) {
/*   635 */           n += ((OnestoreEntity.Property)this.property_.get(i)).maxEncodingSize();
/*       */         }
/*       */ 
/*   638 */         return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */       }
/*       */ 
/*       */       public MessageAppender getMessageAppender()
/*       */       {
/*   643 */         return getUninterpretedForWrite();
/*       */       }
/*       */ 
/*       */       public void clear() {
/*   647 */         this.optional_0_ = 0;
/*   648 */         this.op_ = 0;
/*   649 */         if (this.property_ != null) this.property_.clear();
/*   650 */         this.uninterpreted = null;
/*       */       }
/*       */ 
/*       */       public Filter newInstance() {
/*   654 */         return new Filter();
/*       */       }
/*       */ 
/*       */       public ProtocolType getProtocolType() {
/*   658 */         return StaticHolder.protocolType;
/*       */       }
/*       */ 
/*       */       public void outputTo(ProtocolSink sink)
/*       */       {
/*   673 */         sink.putByte(48);
/*   674 */         sink.putVarLong(this.op_);
/*       */ 
/*   676 */         int i = 0; for (int m = this.property_ != null ? this.property_.size() : 0; i < m; i++) {
/*   677 */           OnestoreEntity.Property v = (OnestoreEntity.Property)this.property_.get(i);
/*   678 */           sink.putByte(114);
/*   679 */           sink.putForeign(v);
/*       */         }
/*       */ 
/*   682 */         if (this.uninterpreted != null) {
/*   683 */           this.uninterpreted.put(sink);
/*       */         }
/*       */ 
/*   686 */         sink.putByte(36);
/*       */       }
/*       */ 
/*       */       public boolean merge(ProtocolSource source) {
/*   690 */         boolean result = true;
/*   691 */         int this_t0 = this.optional_0_;
/*       */         while (true)
/*       */         {
/*   694 */           int tt = source.getVarInt();
/*   695 */           switch (tt)
/*       */           {
/*       */           case 36:
/*   698 */             break;
/*       */           case 0:
/*   702 */             result = false;
/*   703 */             break;
/*       */           case 48:
/*   706 */             this.op_ = source.getVarInt();
/*   707 */             this_t0 |= 1;
/*   708 */             break;
/*       */           case 114:
/*   711 */             source.push(source.getVarInt());
/*   712 */             if (!addProperty().merge(source)) { result = false; break label133; }
/*   713 */             source.pop();
/*   714 */             break;
/*       */           default:
/*   716 */             getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */           }
/*       */ 
/*       */         }
/*       */ 
/*   721 */         label133: this.optional_0_ = this_t0;
/*   722 */         return result;
/*       */       }
/*       */ 
/*       */       public Filter getDefaultInstanceForType()
/*       */       {
/*   727 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public static final Filter getDefaultInstance() {
/*   731 */         return IMMUTABLE_DEFAULT_INSTANCE;
/*       */       }
/*       */ 
/*       */       public Filter freeze()
/*       */       {
/*   791 */         this.property_ = ProtocolSupport.freezeMessages(this.property_);
/*   792 */         return this;
/*       */       }
/*       */ 
/*       */       public Filter unfreeze() {
/*   796 */         this.property_ = ProtocolSupport.unfreezeMessages(this.property_);
/*   797 */         return this;
/*       */       }
/*       */ 
/*       */       public boolean isFrozen() {
/*   801 */         return ProtocolSupport.isFrozenMessages(this.property_);
/*       */       }
/*       */       public UninterpretedTags getUninterpretedForWrite() {
/*   804 */         if (this.uninterpreted == null) {
/*   805 */           this.uninterpreted = new UninterpretedTags();
/*       */         }
/*   807 */         return this.uninterpreted;
/*       */       }
/*       */ 
/*       */       static
/*       */       {
/*   735 */         IMMUTABLE_DEFAULT_INSTANCE = new Filter()
/*       */         {
/*       */           private static final long serialVersionUID = 1L;
/*       */ 
/*       */           public DatastorePb.Query.Filter clearOp()
/*       */           {
/*   743 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Filter setOp(int x) {
/*   746 */             ProtocolSupport.unsupportedOperation();
/*   747 */             return this;
/*       */           }
/*       */ 
/*       */           public DatastorePb.Query.Filter clearProperty()
/*       */           {
/*   752 */             return this;
/*       */           }
/*       */           public OnestoreEntity.Property getMutableProperty(int i) {
/*   755 */             return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */           public OnestoreEntity.Property addProperty() {
/*   758 */             return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */           public OnestoreEntity.Property addProperty(OnestoreEntity.Property v) {
/*   761 */             return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */           public OnestoreEntity.Property insertProperty(int i, OnestoreEntity.Property v) {
/*   764 */             return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */           public OnestoreEntity.Property removeProperty(int i) {
/*   767 */             return (OnestoreEntity.Property)ProtocolSupport.unsupportedOperation();
/*       */           }
/*       */ 
/*       */           public DatastorePb.Query.Filter mergeFrom(DatastorePb.Query.Filter that) {
/*   771 */             ProtocolSupport.unsupportedOperation();
/*   772 */             return this;
/*       */           }
/*       */           public boolean merge(ProtocolSource source) {
/*   775 */             ProtocolSupport.unsupportedOperation();
/*   776 */             return false;
/*       */           }
/*       */           public DatastorePb.Query.Filter freeze() {
/*   779 */             return this;
/*       */           }
/*       */           public DatastorePb.Query.Filter unfreeze() {
/*   782 */             ProtocolSupport.unsupportedOperation();
/*   783 */             return this;
/*       */           }
/*       */           public boolean isFrozen() {
/*   786 */             return true;
/*       */           }
/*       */         };
/*       */       }
/*       */ 
/*       */       private static class StaticHolder
/*       */       {
/*   662 */         private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Query.Filter.class, null, new ProtocolType.FieldType[] { new ProtocolType.FieldType("op", "op", 6, 0, ProtocolType.Presence.REQUIRED, DatastorePb.Query.Filter.Operator.class), new ProtocolType.FieldType("property", "property", 14, -1, ProtocolType.FieldBaseType.FOREIGN, ProtocolType.Presence.REPEATED, OnestoreEntity.Property.class) });
/*       */       }
/*       */ 
/*       */       public static enum Operator
/*       */         implements ProtocolMessageEnum
/*       */       {
/*   412 */         LESS_THAN(1), 
/*   413 */         LESS_THAN_OR_EQUAL(2), 
/*   414 */         GREATER_THAN(3), 
/*   415 */         GREATER_THAN_OR_EQUAL(4), 
/*   416 */         EQUAL(5), 
/*   417 */         IN(6), 
/*   418 */         EXISTS(7);
/*       */ 
/*       */         public static final Operator Operator_MIN;
/*       */         public static final Operator Operator_MAX;
/*       */         private final int value;
/*       */ 
/*   423 */         public int getValue() { return this.value; }
/*       */ 
/*       */         public static Operator valueOf(int value) {
/*   426 */           switch (value) { case 1:
/*   427 */             return LESS_THAN;
/*       */           case 2:
/*   428 */             return LESS_THAN_OR_EQUAL;
/*       */           case 3:
/*   429 */             return GREATER_THAN;
/*       */           case 4:
/*   430 */             return GREATER_THAN_OR_EQUAL;
/*       */           case 5:
/*   431 */             return EQUAL;
/*       */           case 6:
/*   432 */             return IN;
/*       */           case 7:
/*   433 */             return EXISTS;
/*       */           }
/*   435 */           return null;
/*       */         }
/*       */ 
/*       */         private Operator(int v) {
/*   439 */           this.value = v;
/*       */         }
/*       */ 
/*       */         static
/*       */         {
/*   420 */           Operator_MIN = LESS_THAN;
/*   421 */           Operator_MAX = EXISTS;
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   public static class Transaction extends ProtocolMessage<Transaction>
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*    58 */     private long handle_ = 0L;
/*    59 */     private byte[] app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*       */     private UninterpretedTags uninterpreted;
/*       */     private int optional_0_;
/*       */     public static final Transaction IMMUTABLE_DEFAULT_INSTANCE;
/*       */     public static final int khandle = 1;
/*       */     public static final int kapp = 2;
/*       */     public static final String[] text;
/*       */     public static final int[] types;
/*       */     public static final String style = "";
/*       */     public static final String style_content_type = "";
/*       */ 
/*       */     public final long getHandle()
/*       */     {
/*    65 */       return this.handle_;
/*       */     }
/*       */     public final boolean hasHandle() {
/*    68 */       return (this.optional_0_ & 0x1) != 0;
/*       */     }
/*       */     public Transaction clearHandle() {
/*    71 */       this.optional_0_ &= -2;
/*    72 */       this.handle_ = 0L;
/*    73 */       return this;
/*       */     }
/*       */     public Transaction setHandle(long x) {
/*    76 */       this.optional_0_ |= 1;
/*    77 */       this.handle_ = x;
/*    78 */       return this;
/*       */     }
/*       */ 
/*       */     public final byte[] getAppAsBytes()
/*       */     {
/*    83 */       return this.app_;
/*       */     }
/*       */     public final boolean hasApp() {
/*    86 */       return (this.optional_0_ & 0x2) != 0;
/*       */     }
/*       */     public Transaction clearApp() {
/*    89 */       this.optional_0_ &= -3;
/*    90 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*    91 */       return this;
/*       */     }
/*       */     public Transaction setAppAsBytes(byte[] x) {
/*    94 */       this.optional_0_ |= 2;
/*    95 */       this.app_ = x;
/*    96 */       return this;
/*       */     }
/*       */     public final String getApp() {
/*    99 */       return ProtocolSupport.toStringUtf8(this.app_);
/*       */     }
/*       */     public Transaction setApp(String v) {
/*   102 */       if (v == null) throw new NullPointerException();
/*   103 */       this.optional_0_ |= 2;
/*   104 */       this.app_ = ProtocolSupport.toBytesUtf8(v);
/*   105 */       return this;
/*       */     }
/*       */     public final String getApp(Charset cs) {
/*   108 */       return ProtocolSupport.toString(this.app_, cs);
/*       */     }
/*       */     public Transaction setApp(String v, Charset cs) {
/*   111 */       if (v == null) throw new NullPointerException();
/*   112 */       this.optional_0_ |= 2;
/*   113 */       this.app_ = ProtocolSupport.toBytes(v, cs);
/*   114 */       return this;
/*       */     }
/*       */ 
/*       */     public Transaction mergeFrom(Transaction that)
/*       */     {
/*   121 */       assert (that != this);
/*   122 */       int this_t0 = this.optional_0_;
/*   123 */       int that_t0 = that.optional_0_;
/*       */ 
/*   125 */       if ((that_t0 & 0x1) != 0) {
/*   126 */         this_t0 |= 1;
/*   127 */         this.handle_ = that.handle_;
/*       */       }
/*       */ 
/*   130 */       if ((that_t0 & 0x2) != 0) {
/*   131 */         this_t0 |= 2;
/*   132 */         this.app_ = that.app_;
/*       */       }
/*       */ 
/*   135 */       if (that.uninterpreted != null) {
/*   136 */         getUninterpretedForWrite().putAll(that.uninterpreted);
/*       */       }
/*   138 */       this.optional_0_ = this_t0;
/*   139 */       return this;
/*       */     }
/*       */ 
/*       */     public boolean equalsIgnoreUninterpreted(Transaction that) {
/*   143 */       return equals(that, true);
/*       */     }
/*       */ 
/*       */     public boolean equals(Transaction that) {
/*   147 */       return equals(that, false);
/*       */     }
/*       */ 
/*       */     public boolean equals(Transaction that, boolean ignoreUninterpreted) {
/*   151 */       if (that == null) return false;
/*   152 */       if (that == this) return true;
/*   153 */       int this_t0 = this.optional_0_;
/*   154 */       int that_t0 = that.optional_0_;
/*   155 */       if (this_t0 != that_t0) return false;
/*       */ 
/*   157 */       if (((this_t0 & 0x1) != 0) && 
/*   158 */         (this.handle_ != that.handle_)) return false;
/*       */ 
/*   161 */       if (((this_t0 & 0x2) != 0) && 
/*   162 */         (!Arrays.equals(this.app_, that.app_))) return false;
/*       */ 
/*   165 */       return (ignoreUninterpreted) || (UninterpretedTags.equivalent(this.uninterpreted, that.uninterpreted));
/*       */     }
/*       */ 
/*       */     public boolean equals(Object that)
/*       */     {
/*   170 */       return ((that instanceof Transaction)) && (equals((Transaction)that));
/*       */     }
/*       */ 
/*       */     public int hashCode() {
/*   174 */       int hash = 1433558001;
/*       */ 
/*   176 */       int this_t0 = this.optional_0_;
/*   177 */       hash = hash * 31 + ((this_t0 & 0x1) != 0 ? ProtocolSupport.hashCode(this.handle_) : -113);
/*       */ 
/*   179 */       hash = hash * 31 + ((this_t0 & 0x2) != 0 ? Arrays.hashCode(this.app_) : -113);
/*   180 */       if ((this.uninterpreted != null) && (!this.uninterpreted.isEmpty())) {
/*   181 */         hash = hash * 31 + this.uninterpreted.hashCode();
/*       */       }
/*   183 */       return hash;
/*       */     }
/*       */ 
/*       */     public boolean isInitialized() {
/*   187 */       int this_t0 = this.optional_0_;
/*       */ 
/*   189 */       return (this_t0 & 0x1) == 1;
/*       */     }
/*       */ 
/*       */     public int encodingSize()
/*       */     {
/*   196 */       int n = 9;
/*   197 */       int this_t0 = this.optional_0_;
/*   198 */       if ((this_t0 & 0x2) != 0)
/*       */       {
/*   200 */         n += 1 + Protocol.stringSize(this.app_.length);
/*       */       }
/*       */ 
/*   203 */       return this.uninterpreted != null ? n + this.uninterpreted.encodingSize() : n;
/*       */     }
/*       */ 
/*       */     public int maxEncodingSize()
/*       */     {
/*   209 */       int n = 9;
/*   210 */       int this_t0 = this.optional_0_;
/*   211 */       if ((this_t0 & 0x2) != 0)
/*       */       {
/*   213 */         n += 6 + this.app_.length;
/*       */       }
/*       */ 
/*   216 */       return this.uninterpreted != null ? n + this.uninterpreted.maxEncodingSize() : n;
/*       */     }
/*       */ 
/*       */     public MessageAppender getMessageAppender()
/*       */     {
/*   221 */       return getUninterpretedForWrite();
/*       */     }
/*       */ 
/*       */     public void clear() {
/*   225 */       this.optional_0_ = 0;
/*   226 */       this.handle_ = 0L;
/*   227 */       this.app_ = ProtocolSupport.EMPTY_BYTE_ARRAY;
/*   228 */       this.uninterpreted = null;
/*       */     }
/*       */ 
/*       */     public Transaction newInstance() {
/*   232 */       return new Transaction();
/*       */     }
/*       */ 
/*       */     public ProtocolType getProtocolType() {
/*   236 */       return StaticHolder.protocolType;
/*       */     }
/*       */ 
/*       */     public void outputTo(ProtocolSink sink)
/*       */     {
/*   258 */       sink.putByte(9);
/*   259 */       sink.putLong(this.handle_);
/*       */ 
/*   261 */       int this_t0 = this.optional_0_;
/*   262 */       if ((this_t0 & 0x2) != 0) {
/*   263 */         sink.putByte(18);
/*   264 */         sink.putPrefixedData(this.app_);
/*       */       }
/*       */ 
/*   267 */       if (this.uninterpreted != null)
/*   268 */         this.uninterpreted.put(sink);
/*       */     }
/*       */ 
/*       */     public boolean merge(ProtocolSource source)
/*       */     {
/*   273 */       boolean result = true;
/*   274 */       int this_t0 = this.optional_0_;
/*       */ 
/*   276 */       while (source.hasRemaining()) {
/*   277 */         int tt = source.getVarInt();
/*   278 */         switch (tt)
/*       */         {
/*       */         case 0:
/*   282 */           result = false;
/*   283 */           break;
/*       */         case 9:
/*   286 */           this.handle_ = source.getLong();
/*   287 */           this_t0 |= 1;
/*   288 */           break;
/*       */         case 18:
/*   291 */           this.app_ = source.getPrefixedData();
/*   292 */           this_t0 |= 2;
/*   293 */           break;
/*       */         default:
/*   295 */           getUninterpretedForWrite().putBytes(Integer.valueOf(tt), source.getUninterpreted(tt));
/*       */         }
/*       */ 
/*       */       }
/*       */ 
/*   300 */       this.optional_0_ = this_t0;
/*   301 */       return result;
/*       */     }
/*       */ 
/*       */     public Transaction getDefaultInstanceForType()
/*       */     {
/*   306 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public static final Transaction getDefaultInstance() {
/*   310 */       return IMMUTABLE_DEFAULT_INSTANCE;
/*       */     }
/*       */ 
/*       */     public Transaction freeze()
/*       */     {
/*   367 */       this.app_ = ProtocolSupport.freezeString(this.app_);
/*   368 */       return this;
/*       */     }
/*       */     public UninterpretedTags getUninterpretedForWrite() {
/*   371 */       if (this.uninterpreted == null) {
/*   372 */         this.uninterpreted = new UninterpretedTags();
/*       */       }
/*   374 */       return this.uninterpreted;
/*       */     }
/*       */ 
/*       */     static
/*       */     {
/*   314 */       IMMUTABLE_DEFAULT_INSTANCE = new Transaction()
/*       */       {
/*       */         private static final long serialVersionUID = 1L;
/*       */ 
/*       */         public DatastorePb.Transaction clearHandle()
/*       */         {
/*   322 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction setHandle(long x) {
/*   325 */           ProtocolSupport.unsupportedOperation();
/*   326 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Transaction clearApp()
/*       */         {
/*   331 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction setAppAsBytes(byte[] x) {
/*   334 */           ProtocolSupport.unsupportedOperation();
/*   335 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction setApp(String v) {
/*   338 */           ProtocolSupport.unsupportedOperation();
/*   339 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction setApp(String v, Charset cs) {
/*   342 */           ProtocolSupport.unsupportedOperation();
/*   343 */           return this;
/*       */         }
/*       */ 
/*       */         public DatastorePb.Transaction mergeFrom(DatastorePb.Transaction that) {
/*   347 */           ProtocolSupport.unsupportedOperation();
/*   348 */           return this;
/*       */         }
/*       */         public boolean merge(ProtocolSource source) {
/*   351 */           ProtocolSupport.unsupportedOperation();
/*   352 */           return false;
/*       */         }
/*       */         public DatastorePb.Transaction freeze() {
/*   355 */           return this;
/*       */         }
/*       */         public DatastorePb.Transaction unfreeze() {
/*   358 */           ProtocolSupport.unsupportedOperation();
/*   359 */           return this;
/*       */         }
/*       */         public boolean isFrozen() {
/*   362 */           return true;
/*       */         }
/*       */       };
/*   380 */       text = new String[3];
/*       */ 
/*   382 */       text[0] = "ErrorCode";
/*   383 */       text[1] = "handle";
/*   384 */       text[2] = "app";
/*       */ 
/*   387 */       types = new int[3];
/*       */ 
/*   389 */       Arrays.fill(types, 6);
/*   390 */       types[0] = 0;
/*   391 */       types[1] = 1;
/*   392 */       types[2] = 2;
/*       */     }
/*       */ 
/*       */     private static class StaticHolder
/*       */     {
/*   240 */       private static final ProtocolType protocolType = new ProtocolType(DatastorePb.Transaction.class, "Z'apphosting/datastore/datastore_v3.proto\n#apphosting_datastore_v3.Transaction\023\032\006handle \001(\0010\0068\002\024\023\032\003app \002(\0020\t8\001\024", new ProtocolType.FieldType[] { new ProtocolType.FieldType("handle", "handle", 1, 0, ProtocolType.FieldBaseType.FIXED64, ProtocolType.Presence.REQUIRED), new ProtocolType.FieldType("app", "app", 2, 1, ProtocolType.FieldBaseType.STRING, ProtocolType.Presence.OPTIONAL) });
/*       */     }
/*       */   }
/*       */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.apphosting.api.DatastorePb
 * JD-Core Version:    0.6.0
 */