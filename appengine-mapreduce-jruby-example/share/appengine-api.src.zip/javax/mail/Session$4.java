/*      */ package javax.mail;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ 
/*      */ class Session$4
/*      */   implements PrivilegedExceptionAction
/*      */ {
/*      */   public Object run()
/*      */     throws IOException
/*      */   {
/* 1207 */     return this.val$c.getResourceAsStream(this.val$name);
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Session.4
 * JD-Core Version:    0.6.0
 */