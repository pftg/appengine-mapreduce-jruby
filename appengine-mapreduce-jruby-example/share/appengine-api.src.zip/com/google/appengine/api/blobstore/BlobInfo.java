/*     */ package com.google.appengine.api.blobstore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class BlobInfo
/*     */   implements Serializable
/*     */ {
/*     */   protected final BlobKey blobKey;
/*     */   protected final String contentType;
/*     */   protected final Date creation;
/*     */   protected final String filename;
/*     */   protected final long size;
/*     */ 
/*     */   public BlobInfo(BlobKey blobKey, String contentType, Date creation, String filename, long size)
/*     */   {
/*  29 */     if (blobKey == null) {
/*  30 */       throw new NullPointerException("blobKey must not be null");
/*     */     }
/*  32 */     if (contentType == null) {
/*  33 */       throw new NullPointerException("contentType must not be null");
/*     */     }
/*  35 */     if (creation == null) {
/*  36 */       throw new NullPointerException("creation must not be null");
/*     */     }
/*  38 */     if (filename == null) {
/*  39 */       throw new NullPointerException("filename must not be null");
/*     */     }
/*     */ 
/*  42 */     this.blobKey = blobKey;
/*  43 */     this.contentType = contentType;
/*  44 */     this.creation = creation;
/*  45 */     this.filename = filename;
/*  46 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public BlobKey getBlobKey()
/*     */   {
/*  53 */     return this.blobKey;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  61 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public Date getCreation()
/*     */   {
/*  68 */     return this.creation;
/*     */   }
/*     */ 
/*     */   public String getFilename()
/*     */   {
/*  76 */     return this.filename;
/*     */   }
/*     */ 
/*     */   public long getSize()
/*     */   {
/*  83 */     return this.size;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if ((obj instanceof BlobInfo)) {
/*  89 */       BlobInfo bi = (BlobInfo)obj;
/*  90 */       return (this.blobKey.equals(bi.blobKey)) && (this.contentType.equals(bi.contentType)) && (this.creation.equals(bi.creation)) && (this.filename.equals(bi.filename)) && (this.size == bi.size);
/*     */     }
/*     */ 
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 101 */     int hash = 17;
/* 102 */     hash = hash * 37 + this.blobKey.hashCode();
/* 103 */     hash = hash * 37 + this.contentType.hashCode();
/* 104 */     hash = hash * 37 + this.filename.hashCode();
/* 105 */     return hash;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 110 */     StringBuilder builder = new StringBuilder();
/* 111 */     builder.append("<BlobInfo: ");
/* 112 */     builder.append(this.blobKey);
/* 113 */     builder.append(", contentType = ");
/* 114 */     builder.append(this.contentType);
/* 115 */     builder.append(", creation = ");
/* 116 */     builder.append(this.creation.toString());
/* 117 */     builder.append(", filename = ");
/* 118 */     builder.append(this.filename);
/* 119 */     builder.append(", size = ");
/* 120 */     builder.append(Long.toString(this.size));
/* 121 */     builder.append(">");
/* 122 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.blobstore.BlobInfo
 * JD-Core Version:    0.6.0
 */