/*    */ package com.google.appengine.api.xmpp;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class SendResponse
/*    */ {
/* 15 */   private final Map<JID, Status> statusMap = new HashMap();
/*    */ 
/*    */   public void addStatus(JID jabberId, Status status)
/*    */   {
/* 21 */     this.statusMap.put(jabberId, status);
/*    */   }
/*    */ 
/*    */   public Map<JID, Status> getStatusMap() {
/* 25 */     return this.statusMap;
/*    */   }
/*    */ 
/*    */   public static enum Status
/*    */   {
/* 32 */     SUCCESS, 
/* 33 */     INVALID_ID, 
/* 34 */     OTHER_ERROR;
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.xmpp.SendResponse
 * JD-Core Version:    0.6.0
 */