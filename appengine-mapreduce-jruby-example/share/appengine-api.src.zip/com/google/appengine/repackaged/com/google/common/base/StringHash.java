/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ 
/*     */ @GoogleInternal
/*     */ public final class StringHash
/*     */ {
/*     */   public static long hash64(CharSequence val)
/*     */   {
/*  27 */     return hash64(val, 0, val.length(), false, 3141592653589793238L);
/*     */   }
/*     */ 
/*     */   public static long hash64(CharSequence val, int pos, int len)
/*     */   {
/*  39 */     return hash64(val, pos, len, false, 3141592653589793238L);
/*     */   }
/*     */ 
/*     */   public static long hash64IgnoreCase(CharSequence val)
/*     */   {
/*  49 */     return hash64(val, 0, val.length(), true, 3141592653589793238L);
/*     */   }
/*     */ 
/*     */   public static long hash64IgnoreCase(CharSequence val, int pos, int len)
/*     */   {
/*  61 */     return hash64(val, pos, len, true, 3141592653589793238L);
/*     */   }
/*     */ 
/*     */   private static long hash64(CharSequence val, int pos, int len, boolean ignoreCase, long seed)
/*     */   {
/*  77 */     long a = -2266404186210603134L;
/*  78 */     long b = -2266404186210603134L;
/*  79 */     long c = seed;
/*     */ 
/*  82 */     for (int keylen = len; keylen >= 12; pos += 12) {
/*  83 */       a += word64At(val, pos, ignoreCase);
/*  84 */       b += word64At(val, pos + 4, ignoreCase);
/*  85 */       c += word64At(val, pos + 8, ignoreCase);
/*     */ 
/*  88 */       a -= b; a -= c; a ^= c >>> 43;
/*  89 */       b -= c; b -= a; b ^= a << 9;
/*  90 */       c -= a; c -= b; c ^= b >>> 8;
/*  91 */       a -= b; a -= c; a ^= c >>> 38;
/*  92 */       b -= c; b -= a; b ^= a << 23;
/*  93 */       c -= a; c -= b; c ^= b >>> 5;
/*  94 */       a -= b; a -= c; a ^= c >>> 35;
/*  95 */       b -= c; b -= a; b ^= a << 49;
/*  96 */       c -= a; c -= b; c ^= b >>> 11;
/*  97 */       a -= b; a -= c; a ^= c >>> 12;
/*  98 */       b -= c; b -= a; b ^= a << 18;
/*  99 */       c -= a; c -= b; c ^= b >>> 22;
/*     */ 
/*  82 */       keylen -= 12;
/*     */     }
/*     */ 
/* 102 */     c += len;
/* 103 */     switch (keylen) {
/*     */     case 11:
/* 105 */       c += (((!ignoreCase ? val.charAt(pos + 10) : Character.toLowerCase(val.charAt(pos + 10))) & 0xFFFF) << 40);
/*     */     case 10:
/* 109 */       c += (((!ignoreCase ? val.charAt(pos + 9) : Character.toLowerCase(val.charAt(pos + 9))) & 0xFFFF) << 24);
/*     */     case 9:
/* 113 */       c += (((!ignoreCase ? val.charAt(pos + 8) : Character.toLowerCase(val.charAt(pos + 8))) & 0xFFFF) << 8);
/*     */     case 8:
/* 118 */       b += word64At(val, pos + 4, ignoreCase);
/* 119 */       a += word64At(val, pos, ignoreCase);
/* 120 */       break;
/*     */     case 7:
/* 123 */       b += (((!ignoreCase ? val.charAt(pos + 6) : Character.toLowerCase(val.charAt(pos + 6))) & 0xFFFF) << 32);
/*     */     case 6:
/* 127 */       b += (((!ignoreCase ? val.charAt(pos + 5) : Character.toLowerCase(val.charAt(pos + 5))) & 0xFFFF) << 16);
/*     */     case 5:
/* 131 */       b += ((!ignoreCase ? val.charAt(pos + 4) : Character.toLowerCase(val.charAt(pos + 4))) & 0xFFFF);
/*     */     case 4:
/* 135 */       a += word64At(val, pos, ignoreCase);
/* 136 */       break;
/*     */     case 3:
/* 139 */       a += (((!ignoreCase ? val.charAt(pos + 2) : Character.toLowerCase(val.charAt(pos + 2))) & 0xFFFF) << 32);
/*     */     case 2:
/* 143 */       a += (((!ignoreCase ? val.charAt(pos + 1) : Character.toLowerCase(val.charAt(pos + 1))) & 0xFFFF) << 16);
/*     */     case 1:
/* 147 */       a += ((!ignoreCase ? val.charAt(pos + 0) : Character.toLowerCase(val.charAt(pos + 0))) & 0xFFFF);
/*     */     }
/*     */ 
/* 152 */     return Hash.mix64(a, b, c);
/*     */   }
/*     */ 
/*     */   private static long word64At(CharSequence chars, int offset, boolean ignoreCase)
/*     */   {
/* 157 */     if (ignoreCase) {
/* 158 */       return (Character.toLowerCase(chars.charAt(offset + 0)) & 0xFFFF) + ((Character.toLowerCase(chars.charAt(offset + 1)) & 0xFFFF) << 16) + ((Character.toLowerCase(chars.charAt(offset + 2)) & 0xFFFF) << 32) + ((Character.toLowerCase(chars.charAt(offset + 3)) & 0xFFFF) << 48);
/*     */     }
/*     */ 
/* 164 */     return (chars.charAt(offset + 0) & 0xFFFF) + ((chars.charAt(offset + 1) & 0xFFFF) << 16) + ((chars.charAt(offset + 2) & 0xFFFF) << 32) + ((chars.charAt(offset + 3) & 0xFFFF) << 48);
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.StringHash
 * JD-Core Version:    0.6.0
 */