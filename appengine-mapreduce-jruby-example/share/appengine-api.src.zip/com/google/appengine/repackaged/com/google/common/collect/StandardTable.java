/*      */ package com.google.appengine.repackaged.com.google.common.collect;
/*      */ 
/*      */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicate;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Predicates;
/*      */ import com.google.appengine.repackaged.com.google.common.base.Supplier;
/*      */ import com.google.common.annotations.GoogleInternal;
/*      */ import com.google.common.annotations.GwtCompatible;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ @GwtCompatible
/*      */ @GoogleInternal
/*      */ public class StandardTable<R, C, V>
/*      */   implements Table<R, C, V>, Serializable
/*      */ {
/*      */   final Map<R, Map<C, V>> backingMap;
/*      */   final Supplier<? extends Map<C, V>> factory;
/*      */   private transient StandardTable<R, C, V>.CellSet cellSet;
/*      */   private transient StandardTable<R, C, V>.RowKeySet rowKeySet;
/*      */   private transient Set<C> columnKeySet;
/*      */   private transient StandardTable<R, C, V>.Values values;
/*      */   private transient StandardTable<R, C, V>.RowMap rowMap;
/*      */   private transient StandardTable<R, C, V>.ColumnMap columnMap;
/*      */   private static final long serialVersionUID = 0L;
/*      */ 
/*      */   public static <R, C, V> StandardTable<R, C, V> create(Map<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/*      */   {
/*   90 */     Preconditions.checkArgument(backingMap.isEmpty());
/*   91 */     Preconditions.checkNotNull(factory);
/*   92 */     return new StandardTable(backingMap, factory);
/*      */   }
/*      */ 
/*      */   StandardTable(Map<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/*      */   {
/*   97 */     this.backingMap = backingMap;
/*   98 */     this.factory = factory;
/*      */   }
/*      */ 
/*      */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*      */   {
/*  104 */     if ((rowKey == null) || (columnKey == null)) {
/*  105 */       return false;
/*      */     }
/*  107 */     Map map = (Map)Maps.safeGet(this.backingMap, rowKey);
/*  108 */     return (map != null) && (Maps.safeContainsKey(map, columnKey));
/*      */   }
/*      */ 
/*      */   public boolean containsColumn(@Nullable Object columnKey) {
/*  112 */     if (columnKey == null) {
/*  113 */       return false;
/*      */     }
/*  115 */     for (Map map : this.backingMap.values()) {
/*  116 */       if (Maps.safeContainsKey(map, columnKey)) {
/*  117 */         return true;
/*      */       }
/*      */     }
/*  120 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean containsRow(@Nullable Object rowKey) {
/*  124 */     return (rowKey != null) && (Maps.safeContainsKey(this.backingMap, rowKey));
/*      */   }
/*      */ 
/*      */   public boolean containsValue(@Nullable Object value) {
/*  128 */     if (value == null) {
/*  129 */       return false;
/*      */     }
/*  131 */     for (Map map : this.backingMap.values()) {
/*  132 */       if (map.containsValue(value)) {
/*  133 */         return true;
/*      */       }
/*      */     }
/*  136 */     return false;
/*      */   }
/*      */ 
/*      */   public V get(@Nullable Object rowKey, @Nullable Object columnKey) {
/*  140 */     if ((rowKey == null) || (columnKey == null)) {
/*  141 */       return null;
/*      */     }
/*  143 */     Map map = (Map)Maps.safeGet(this.backingMap, rowKey);
/*  144 */     return map == null ? null : Maps.safeGet(map, columnKey);
/*      */   }
/*      */ 
/*      */   public boolean isEmpty() {
/*  148 */     return this.backingMap.isEmpty();
/*      */   }
/*      */ 
/*      */   public int size() {
/*  152 */     int size = 0;
/*  153 */     for (Map map : this.backingMap.values()) {
/*  154 */       size += map.size();
/*      */     }
/*  156 */     return size;
/*      */   }
/*      */ 
/*      */   public boolean equals(@Nullable Object obj) {
/*  160 */     if (obj == this) {
/*  161 */       return true;
/*      */     }
/*  163 */     if ((obj instanceof Table)) {
/*  164 */       Table other = (Table)obj;
/*  165 */       return cellSet().equals(other.cellSet());
/*      */     }
/*  167 */     return false;
/*      */   }
/*      */ 
/*      */   public int hashCode() {
/*  171 */     return cellSet().hashCode();
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  178 */     return rowMap().toString();
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/*  184 */     this.backingMap.clear();
/*      */   }
/*      */ 
/*      */   private Map<C, V> getOrCreate(R rowKey) {
/*  188 */     Map map = (Map)this.backingMap.get(rowKey);
/*  189 */     if (map == null) {
/*  190 */       map = (Map)this.factory.get();
/*  191 */       this.backingMap.put(rowKey, map);
/*      */     }
/*  193 */     return map;
/*      */   }
/*      */ 
/*      */   public V put(R rowKey, C columnKey, V value) {
/*  197 */     Preconditions.checkNotNull(rowKey);
/*  198 */     Preconditions.checkNotNull(columnKey);
/*  199 */     Preconditions.checkNotNull(value);
/*  200 */     return getOrCreate(rowKey).put(columnKey, value);
/*      */   }
/*      */ 
/*      */   public void putAll(Table<? extends R, ? extends C, ? extends V> table) {
/*  204 */     for (Table.Cell cell : table.cellSet())
/*  205 */       put(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/*      */   }
/*      */ 
/*      */   public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/*      */   {
/*  210 */     if ((rowKey == null) || (columnKey == null)) {
/*  211 */       return null;
/*      */     }
/*  213 */     Map map = (Map)Maps.safeGet(this.backingMap, rowKey);
/*  214 */     if (map == null) {
/*  215 */       return null;
/*      */     }
/*  217 */     Object value = map.remove(columnKey);
/*  218 */     if (map.isEmpty()) {
/*  219 */       this.backingMap.remove(rowKey);
/*      */     }
/*  221 */     return value;
/*      */   }
/*      */ 
/*      */   private Map<R, V> removeColumn(Object column) {
/*  225 */     Map output = new LinkedHashMap();
/*  226 */     Iterator iterator = this.backingMap.entrySet().iterator();
/*      */ 
/*  228 */     while (iterator.hasNext()) {
/*  229 */       Map.Entry entry = (Map.Entry)iterator.next();
/*  230 */       Object value = ((Map)entry.getValue()).remove(column);
/*  231 */       if (value != null) {
/*  232 */         output.put(entry.getKey(), value);
/*  233 */         if (((Map)entry.getValue()).isEmpty()) {
/*  234 */           iterator.remove();
/*      */         }
/*      */       }
/*      */     }
/*  238 */     return output;
/*      */   }
/*      */ 
/*      */   private boolean containsMapping(Object rowKey, Object columnKey, Object value)
/*      */   {
/*  243 */     return (value != null) && (value.equals(get(rowKey, columnKey)));
/*      */   }
/*      */ 
/*      */   private boolean removeMapping(Object rowKey, Object columnKey, Object value)
/*      */   {
/*  248 */     if (containsMapping(rowKey, columnKey, value)) {
/*  249 */       remove(rowKey, columnKey);
/*  250 */       return true;
/*      */     }
/*  252 */     return false;
/*      */   }
/*      */ 
/*      */   public Set<Table.Cell<R, C, V>> cellSet()
/*      */   {
/*  298 */     CellSet result = this.cellSet;
/*  299 */     return result == null ? (this.cellSet = new CellSet(null)) : result;
/*      */   }
/*      */ 
/*      */   public Map<C, V> row(R rowKey)
/*      */   {
/*  360 */     return new Row(rowKey);
/*      */   }
/*      */ 
/*      */   public Map<R, V> column(C columnKey)
/*      */   {
/*  462 */     return new Column(columnKey);
/*      */   }
/*      */ 
/*      */   public Set<R> rowKeySet()
/*      */   {
/*  712 */     Set result = this.rowKeySet;
/*  713 */     return result == null ? (this.rowKeySet = new RowKeySet()) : result;
/*      */   }
/*      */ 
/*      */   public Set<C> columnKeySet()
/*      */   {
/*  746 */     Set result = this.columnKeySet;
/*  747 */     return result == null ? (this.columnKeySet = new ColumnKeySet(null)) : result;
/*      */   }
/*      */ 
/*      */   public Collection<V> values()
/*      */   {
/*  857 */     Values result = this.values;
/*  858 */     return result == null ? (this.values = new Values(null)) : result;
/*      */   }
/*      */ 
/*      */   public Map<R, Map<C, V>> rowMap()
/*      */   {
/*  886 */     RowMap result = this.rowMap;
/*  887 */     return result == null ? (this.rowMap = new RowMap()) : result;
/*      */   }
/*      */ 
/*      */   public Map<C, Map<R, V>> columnMap()
/*      */   {
/*  965 */     ColumnMap result = this.columnMap;
/*  966 */     return result == null ? (this.columnMap = new ColumnMap(null)) : result;
/*      */   }
/*      */ 
/*      */   static <K, V> Iterator<K> keyIteratorImpl(Map<K, V> map)
/*      */   {
/* 1118 */     Iterator entryIterator = map.entrySet().iterator();
/* 1119 */     return new Iterator(entryIterator) {
/*      */       public boolean hasNext() {
/* 1121 */         return this.val$entryIterator.hasNext();
/*      */       }
/*      */       public K next() {
/* 1124 */         return ((Map.Entry)this.val$entryIterator.next()).getKey();
/*      */       }
/*      */       public void remove() {
/* 1127 */         this.val$entryIterator.remove();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   static <K, V> Iterator<V> valueIteratorImpl(Map<K, V> map)
/*      */   {
/* 1137 */     Iterator entryIterator = map.entrySet().iterator();
/* 1138 */     return new Iterator(entryIterator) {
/*      */       public boolean hasNext() {
/* 1140 */         return this.val$entryIterator.hasNext();
/*      */       }
/*      */       public V next() {
/* 1143 */         return ((Map.Entry)this.val$entryIterator.next()).getValue();
/*      */       }
/*      */       public void remove() {
/* 1146 */         this.val$entryIterator.remove();
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   private class ColumnMap extends Maps.ImprovedAbstractMap<C, Map<R, V>>
/*      */   {
/*      */     StandardTable<R, C, V>.ColumnMap.ColumnMapValues columnMapValues;
/*      */ 
/*      */     private ColumnMap()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Map<R, V> get(Object key)
/*      */     {
/*  974 */       return StandardTable.this.containsColumn(key) ? StandardTable.this.column(key) : null;
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  978 */       return StandardTable.this.containsColumn(key);
/*      */     }
/*      */ 
/*      */     public Map<R, V> remove(Object key) {
/*  982 */       return StandardTable.this.containsColumn(key) ? StandardTable.this.removeColumn(key) : null;
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<C, Map<R, V>>> createEntrySet() {
/*  986 */       return new ColumnMapEntrySet();
/*      */     }
/*      */ 
/*      */     public Set<C> keySet() {
/*  990 */       return StandardTable.this.columnKeySet();
/*      */     }
/*      */ 
/*      */     public Collection<Map<R, V>> values()
/*      */     {
/*  996 */       ColumnMapValues result = this.columnMapValues;
/*  997 */       return result == null ? (this.columnMapValues = new ColumnMapValues(null)) : result;
/*      */     }
/*      */ 
/*      */     private class ColumnMapValues extends StandardTable<R, C, V>.TableCollection<Map<R, V>>
/*      */     {
/*      */       private ColumnMapValues()
/*      */       {
/* 1064 */         super(null);
/*      */       }
/* 1066 */       public Iterator<Map<R, V>> iterator() { return StandardTable.valueIteratorImpl(StandardTable.ColumnMap.this); }
/*      */ 
/*      */       public boolean remove(Object obj)
/*      */       {
/* 1070 */         for (Map.Entry entry : StandardTable.ColumnMap.this.entrySet()) {
/* 1071 */           if (((Map)entry.getValue()).equals(obj)) {
/* 1072 */             StandardTable.this.removeColumn(entry.getKey());
/* 1073 */             return true;
/*      */           }
/*      */         }
/* 1076 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> c) {
/* 1080 */         Preconditions.checkNotNull(c);
/* 1081 */         boolean changed = false;
/* 1082 */         for (Iterator i$ = Lists.newArrayList(StandardTable.this.columnKeySet().iterator()).iterator(); i$.hasNext(); ) { Object columnKey = i$.next();
/* 1083 */           if (c.contains(StandardTable.this.column(columnKey))) {
/* 1084 */             StandardTable.this.removeColumn(columnKey);
/* 1085 */             changed = true;
/*      */           }
/*      */         }
/* 1088 */         return changed;
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> c) {
/* 1092 */         Preconditions.checkNotNull(c);
/* 1093 */         boolean changed = false;
/* 1094 */         for (Iterator i$ = Lists.newArrayList(StandardTable.this.columnKeySet().iterator()).iterator(); i$.hasNext(); ) { Object columnKey = i$.next();
/* 1095 */           if (!c.contains(StandardTable.this.column(columnKey))) {
/* 1096 */             StandardTable.this.removeColumn(columnKey);
/* 1097 */             changed = true;
/*      */           }
/*      */         }
/* 1100 */         return changed;
/*      */       }
/*      */ 
/*      */       public int size() {
/* 1104 */         return StandardTable.this.columnKeySet().size();
/*      */       }
/*      */     }
/*      */ 
/*      */     class ColumnMapEntrySet extends StandardTable<R, C, V>.TableSet<Map.Entry<C, Map<R, V>>>
/*      */     {
/*      */       ColumnMapEntrySet()
/*      */       {
/* 1001 */         super(null);
/*      */       }
/* 1003 */       public Iterator<Map.Entry<C, Map<R, V>>> iterator() { Iterator columnIterator = StandardTable.this.columnKeySet().iterator();
/* 1004 */         return new UnmodifiableIterator(columnIterator) {
/*      */           public boolean hasNext() {
/* 1006 */             return this.val$columnIterator.hasNext();
/*      */           }
/*      */           public Map.Entry<C, Map<R, V>> next() {
/* 1009 */             Object columnKey = this.val$columnIterator.next();
/* 1010 */             return new ImmutableEntry(columnKey, StandardTable.this.column(columnKey));
/*      */           }
/*      */         }; }
/*      */ 
/*      */       public int size()
/*      */       {
/* 1017 */         return StandardTable.this.columnKeySet().size();
/*      */       }
/*      */ 
/*      */       public boolean contains(Object obj) {
/* 1021 */         if ((obj instanceof Map.Entry)) {
/* 1022 */           Map.Entry entry = (Map.Entry)obj;
/* 1023 */           if (StandardTable.this.containsColumn(entry.getKey()))
/*      */           {
/* 1027 */             Object columnKey = entry.getKey();
/* 1028 */             return StandardTable.ColumnMap.this.get(columnKey).equals(entry.getValue());
/*      */           }
/*      */         }
/* 1031 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean remove(Object obj) {
/* 1035 */         if (contains(obj)) {
/* 1036 */           Map.Entry entry = (Map.Entry)obj;
/* 1037 */           StandardTable.this.removeColumn(entry.getKey());
/* 1038 */           return true;
/*      */         }
/* 1040 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> c) {
/* 1044 */         boolean changed = false;
/* 1045 */         for (Iterator i$ = c.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/* 1046 */           changed |= remove(obj);
/*      */         }
/* 1048 */         return changed;
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> c) {
/* 1052 */         boolean changed = false;
/* 1053 */         for (Iterator i$ = Lists.newArrayList(StandardTable.this.columnKeySet().iterator()).iterator(); i$.hasNext(); ) { Object columnKey = i$.next();
/* 1054 */           if (!c.contains(new ImmutableEntry(columnKey, StandardTable.this.column(columnKey))))
/*      */           {
/* 1056 */             StandardTable.this.removeColumn(columnKey);
/* 1057 */             changed = true;
/*      */           }
/*      */         }
/* 1060 */         return changed;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class RowMap extends Maps.ImprovedAbstractMap<R, Map<C, V>>
/*      */   {
/*      */     RowMap()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key)
/*      */     {
/*  893 */       return StandardTable.this.containsRow(key);
/*      */     }
/*      */ 
/*      */     public Map<C, V> get(Object key)
/*      */     {
/*  899 */       return StandardTable.this.containsRow(key) ? StandardTable.this.row(key) : null;
/*      */     }
/*      */ 
/*      */     public Set<R> keySet() {
/*  903 */       return StandardTable.this.rowKeySet();
/*      */     }
/*      */ 
/*      */     public Map<C, V> remove(Object key) {
/*  907 */       return key == null ? null : (Map)StandardTable.this.backingMap.remove(key);
/*      */     }
/*      */ 
/*      */     protected Set<Map.Entry<R, Map<C, V>>> createEntrySet() {
/*  911 */       return new EntrySet();
/*      */     }
/*      */ 
/*      */     class EntryIterator
/*      */       implements Iterator<Map.Entry<R, Map<C, V>>>
/*      */     {
/*  945 */       final Iterator<R> delegate = StandardTable.this.backingMap.keySet().iterator();
/*      */ 
/*      */       EntryIterator() {  }
/*      */ 
/*  948 */       public boolean hasNext() { return this.delegate.hasNext(); }
/*      */ 
/*      */       public Map.Entry<R, Map<C, V>> next()
/*      */       {
/*  952 */         Object rowKey = this.delegate.next();
/*  953 */         return new ImmutableEntry(rowKey, StandardTable.this.row(rowKey));
/*      */       }
/*      */ 
/*      */       public void remove() {
/*  957 */         this.delegate.remove();
/*      */       }
/*      */     }
/*      */ 
/*      */     class EntrySet extends StandardTable<R, C, V>.TableSet<Map.Entry<R, Map<C, V>>>
/*      */     {
/*      */       EntrySet()
/*      */       {
/*  914 */         super(null);
/*      */       }
/*  916 */       public Iterator<Map.Entry<R, Map<C, V>>> iterator() { return new StandardTable.RowMap.EntryIterator(StandardTable.RowMap.this); }
/*      */ 
/*      */       public int size()
/*      */       {
/*  920 */         return StandardTable.this.backingMap.size();
/*      */       }
/*      */ 
/*      */       public boolean contains(Object obj) {
/*  924 */         if ((obj instanceof Map.Entry)) {
/*  925 */           Map.Entry entry = (Map.Entry)obj;
/*  926 */           return (entry.getKey() != null) && ((entry.getValue() instanceof Map)) && (Collections2.safeContains(StandardTable.this.backingMap.entrySet(), entry));
/*      */         }
/*      */ 
/*  930 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean remove(Object obj) {
/*  934 */         if ((obj instanceof Map.Entry)) {
/*  935 */           Map.Entry entry = (Map.Entry)obj;
/*  936 */           return (entry.getKey() != null) && ((entry.getValue() instanceof Map)) && (StandardTable.this.backingMap.entrySet().remove(entry));
/*      */         }
/*      */ 
/*  940 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Values extends StandardTable<R, C, V>.TableCollection<V>
/*      */   {
/*      */     private Values()
/*      */     {
/*  861 */       super(null);
/*      */     }
/*      */     public Iterator<V> iterator() {
/*  864 */       Iterator cellIterator = StandardTable.this.cellSet().iterator();
/*  865 */       return new Iterator(cellIterator) {
/*      */         public boolean hasNext() {
/*  867 */           return this.val$cellIterator.hasNext();
/*      */         }
/*      */         public V next() {
/*  870 */           return ((Table.Cell)this.val$cellIterator.next()).getValue();
/*      */         }
/*      */         public void remove() {
/*  873 */           this.val$cellIterator.remove();
/*      */         } } ;
/*      */     }
/*      */ 
/*      */     public int size() {
/*  879 */       return StandardTable.this.size();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ColumnKeyIterator extends AbstractIterator<C>
/*      */   {
/*  827 */     final Map<C, V> seen = (Map)StandardTable.this.factory.get();
/*  828 */     final Iterator<Map<C, V>> mapIterator = StandardTable.this.backingMap.values().iterator();
/*  829 */     Iterator<Map.Entry<C, V>> entryIterator = Iterators.emptyIterator();
/*      */ 
/*      */     private ColumnKeyIterator() {
/*      */     }
/*      */     protected C computeNext() { while (true) { if (this.entryIterator.hasNext()) {
/*  834 */           Map.Entry entry = (Map.Entry)this.entryIterator.next();
/*  835 */           if (!this.seen.containsKey(entry.getKey())) {
/*  836 */             this.seen.put(entry.getKey(), entry.getValue());
/*  837 */             return entry.getKey();
/*      */           }
/*  839 */           continue; } if (!this.mapIterator.hasNext()) break;
/*  840 */         this.entryIterator = ((Map)this.mapIterator.next()).entrySet().iterator();
/*      */       }
/*  842 */       return endOfData();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ColumnKeySet extends StandardTable<R, C, V>.TableSet<C>
/*      */   {
/*      */     private ColumnKeySet()
/*      */     {
/*  750 */       super(null);
/*      */     }
/*  752 */     public Iterator<C> iterator() { return new StandardTable.ColumnKeyIterator(StandardTable.this, null); }
/*      */ 
/*      */     public int size()
/*      */     {
/*  756 */       return Iterators.size(iterator());
/*      */     }
/*      */ 
/*      */     public boolean remove(Object obj) {
/*  760 */       if (obj == null) {
/*  761 */         return false;
/*      */       }
/*  763 */       boolean changed = false;
/*  764 */       Iterator iterator = StandardTable.this.backingMap.values().iterator();
/*  765 */       while (iterator.hasNext()) {
/*  766 */         Map map = (Map)iterator.next();
/*  767 */         if (map.keySet().remove(obj)) {
/*  768 */           changed = true;
/*  769 */           if (map.isEmpty()) {
/*  770 */             iterator.remove();
/*      */           }
/*      */         }
/*      */       }
/*  774 */       return changed;
/*      */     }
/*      */ 
/*      */     public boolean removeAll(Collection<?> c) {
/*  778 */       Preconditions.checkNotNull(c);
/*  779 */       boolean changed = false;
/*  780 */       Iterator iterator = StandardTable.this.backingMap.values().iterator();
/*  781 */       while (iterator.hasNext()) {
/*  782 */         Map map = (Map)iterator.next();
/*      */ 
/*  785 */         if (Iterators.removeAll(map.keySet().iterator(), c)) {
/*  786 */           changed = true;
/*  787 */           if (map.isEmpty()) {
/*  788 */             iterator.remove();
/*      */           }
/*      */         }
/*      */       }
/*  792 */       return changed;
/*      */     }
/*      */ 
/*      */     public boolean retainAll(Collection<?> c) {
/*  796 */       Preconditions.checkNotNull(c);
/*  797 */       boolean changed = false;
/*  798 */       Iterator iterator = StandardTable.this.backingMap.values().iterator();
/*  799 */       while (iterator.hasNext()) {
/*  800 */         Map map = (Map)iterator.next();
/*  801 */         if (map.keySet().retainAll(c)) {
/*  802 */           changed = true;
/*  803 */           if (map.isEmpty()) {
/*  804 */             iterator.remove();
/*      */           }
/*      */         }
/*      */       }
/*  808 */       return changed;
/*      */     }
/*      */ 
/*      */     public boolean contains(Object obj) {
/*  812 */       if (obj == null) {
/*  813 */         return false;
/*      */       }
/*  815 */       for (Map map : StandardTable.this.backingMap.values()) {
/*  816 */         if (map.containsKey(obj)) {
/*  817 */           return true;
/*      */         }
/*      */       }
/*  820 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   class RowKeySet extends StandardTable<R, C, V>.TableSet<R>
/*      */   {
/*      */     RowKeySet()
/*      */     {
/*  716 */       super(null);
/*      */     }
/*  718 */     public Iterator<R> iterator() { return StandardTable.keyIteratorImpl(StandardTable.this.rowMap()); }
/*      */ 
/*      */     public int size()
/*      */     {
/*  722 */       return StandardTable.this.backingMap.size();
/*      */     }
/*      */ 
/*      */     public boolean contains(Object obj) {
/*  726 */       return StandardTable.this.containsRow(obj);
/*      */     }
/*      */ 
/*      */     public boolean remove(Object obj) {
/*  730 */       return (obj != null) && (StandardTable.this.backingMap.remove(obj) != null);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Column extends Maps.ImprovedAbstractMap<R, V>
/*      */   {
/*      */     final C columnKey;
/*      */     StandardTable<R, C, V>.Column.Values columnValues;
/*      */     StandardTable<R, C, V>.Column.KeySet keySet;
/*      */ 
/*      */     Column()
/*      */     {
/*  469 */       this.columnKey = Preconditions.checkNotNull(columnKey);
/*      */     }
/*      */ 
/*      */     public V put(R key, V value) {
/*  473 */       return StandardTable.this.put(key, this.columnKey, value);
/*      */     }
/*      */ 
/*      */     public V get(Object key) {
/*  477 */       return StandardTable.this.get(key, this.columnKey);
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  481 */       return StandardTable.this.contains(key, this.columnKey);
/*      */     }
/*      */ 
/*      */     public V remove(Object key) {
/*  485 */       return StandardTable.this.remove(key, this.columnKey);
/*      */     }
/*      */ 
/*      */     public Set<Map.Entry<R, V>> createEntrySet() {
/*  489 */       return new EntrySet();
/*      */     }
/*      */ 
/*      */     public Collection<V> values()
/*      */     {
/*  495 */       Values result = this.columnValues;
/*  496 */       return result == null ? (this.columnValues = new Values()) : result;
/*      */     }
/*      */ 
/*      */     boolean removePredicate(Predicate<? super Map.Entry<R, V>> predicate)
/*      */     {
/*  504 */       boolean changed = false;
/*  505 */       Iterator iterator = StandardTable.this.backingMap.entrySet().iterator();
/*      */ 
/*  507 */       while (iterator.hasNext()) {
/*  508 */         Map.Entry entry = (Map.Entry)iterator.next();
/*  509 */         Map map = (Map)entry.getValue();
/*  510 */         Object value = map.get(this.columnKey);
/*  511 */         if ((value != null) && (predicate.apply(new ImmutableEntry(entry.getKey(), value))))
/*      */         {
/*  514 */           map.remove(this.columnKey);
/*  515 */           changed = true;
/*  516 */           if (map.isEmpty()) {
/*  517 */             iterator.remove();
/*      */           }
/*      */         }
/*      */       }
/*  521 */       return changed;
/*      */     }
/*      */ 
/*      */     public Set<R> keySet()
/*      */     {
/*  604 */       KeySet result = this.keySet;
/*  605 */       return result == null ? (this.keySet = new KeySet()) : result;
/*      */     }
/*      */ 
/*      */     class Values extends AbstractCollection<V>
/*      */     {
/*      */       Values()
/*      */       {
/*      */       }
/*      */ 
/*      */       public Iterator<V> iterator()
/*      */       {
/*  654 */         return StandardTable.valueIteratorImpl(StandardTable.Column.this);
/*      */       }
/*      */ 
/*      */       public int size() {
/*  658 */         return StandardTable.Column.this.entrySet().size();
/*      */       }
/*      */ 
/*      */       public boolean isEmpty() {
/*  662 */         return !StandardTable.this.containsColumn(StandardTable.Column.this.columnKey);
/*      */       }
/*      */ 
/*      */       public void clear() {
/*  666 */         StandardTable.Column.this.entrySet().clear();
/*      */       }
/*      */ 
/*      */       public boolean remove(Object obj) {
/*  670 */         if (obj == null) {
/*  671 */           return false;
/*      */         }
/*  673 */         Iterator iterator = StandardTable.this.backingMap.values().iterator();
/*  674 */         while (iterator.hasNext()) {
/*  675 */           Map map = (Map)iterator.next();
/*  676 */           if (map.entrySet().remove(new ImmutableEntry(StandardTable.Column.this.columnKey, obj)))
/*      */           {
/*  678 */             if (map.isEmpty()) {
/*  679 */               iterator.remove();
/*      */             }
/*  681 */             return true;
/*      */           }
/*      */         }
/*  684 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> c) {
/*  688 */         Preconditions.checkNotNull(c);
/*  689 */         Predicate predicate = new Predicate(c) {
/*      */           public boolean apply(Map.Entry<R, V> entry) {
/*  691 */             return this.val$c.contains(entry.getValue());
/*      */           }
/*      */         };
/*  694 */         return StandardTable.Column.this.removePredicate(predicate);
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> c) {
/*  698 */         Preconditions.checkNotNull(c);
/*  699 */         Predicate predicate = new Predicate(c) {
/*      */           public boolean apply(Map.Entry<R, V> entry) {
/*  701 */             return !this.val$c.contains(entry.getValue());
/*      */           }
/*      */         };
/*  704 */         return StandardTable.Column.this.removePredicate(predicate);
/*      */       }
/*      */     }
/*      */ 
/*      */     class KeySet extends AbstractSet<R>
/*      */     {
/*      */       KeySet()
/*      */       {
/*      */       }
/*      */ 
/*      */       public Iterator<R> iterator()
/*      */       {
/*  610 */         return StandardTable.keyIteratorImpl(StandardTable.Column.this);
/*      */       }
/*      */ 
/*      */       public int size() {
/*  614 */         return StandardTable.Column.this.entrySet().size();
/*      */       }
/*      */ 
/*      */       public boolean isEmpty() {
/*  618 */         return !StandardTable.this.containsColumn(StandardTable.Column.this.columnKey);
/*      */       }
/*      */ 
/*      */       public boolean contains(Object obj) {
/*  622 */         return StandardTable.this.contains(obj, StandardTable.Column.this.columnKey);
/*      */       }
/*      */ 
/*      */       public boolean remove(Object obj) {
/*  626 */         return StandardTable.this.remove(obj, StandardTable.Column.this.columnKey) != null;
/*      */       }
/*      */ 
/*      */       public void clear() {
/*  630 */         StandardTable.Column.this.entrySet().clear();
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> c) {
/*  634 */         boolean changed = false;
/*  635 */         for (Iterator i$ = c.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/*  636 */           changed |= remove(obj);
/*      */         }
/*  638 */         return changed;
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> c) {
/*  642 */         Preconditions.checkNotNull(c);
/*  643 */         Predicate predicate = new Predicate(c) {
/*      */           public boolean apply(Map.Entry<R, V> entry) {
/*  645 */             return !this.val$c.contains(entry.getKey());
/*      */           }
/*      */         };
/*  648 */         return StandardTable.Column.this.removePredicate(predicate);
/*      */       }
/*      */     }
/*      */ 
/*      */     class EntrySetIterator extends AbstractIterator<Map.Entry<R, V>>
/*      */     {
/*  578 */       final Iterator<Map.Entry<R, Map<C, V>>> iterator = StandardTable.this.backingMap.entrySet().iterator();
/*      */ 
/*      */       EntrySetIterator() {  }
/*      */ 
/*  581 */       protected Map.Entry<R, V> computeNext() { while (this.iterator.hasNext()) {
/*  582 */           Map.Entry entry = (Map.Entry)this.iterator.next();
/*  583 */           if (((Map)entry.getValue()).containsKey(StandardTable.Column.this.columnKey))
/*  584 */             return new AbstractMapEntry(entry) {
/*      */               public R getKey() {
/*  586 */                 return this.val$entry.getKey();
/*      */               }
/*      */               public V getValue() {
/*  589 */                 return ((Map)this.val$entry.getValue()).get(StandardTable.Column.this.columnKey);
/*      */               }
/*      */               public V setValue(V value) {
/*  592 */                 return ((Map)this.val$entry.getValue()).put(StandardTable.Column.this.columnKey, Preconditions.checkNotNull(value));
/*      */               }
/*      */             };
/*      */         }
/*  597 */         return (Map.Entry)endOfData();
/*      */       }
/*      */     }
/*      */ 
/*      */     class EntrySet extends AbstractSet<Map.Entry<R, V>>
/*      */     {
/*      */       EntrySet()
/*      */       {
/*      */       }
/*      */ 
/*      */       public Iterator<Map.Entry<R, V>> iterator()
/*      */       {
/*  526 */         return new StandardTable.Column.EntrySetIterator(StandardTable.Column.this);
/*      */       }
/*      */ 
/*      */       public int size() {
/*  530 */         int size = 0;
/*  531 */         for (Map map : StandardTable.this.backingMap.values()) {
/*  532 */           if (map.containsKey(StandardTable.Column.this.columnKey)) {
/*  533 */             size++;
/*      */           }
/*      */         }
/*  536 */         return size;
/*      */       }
/*      */ 
/*      */       public boolean isEmpty() {
/*  540 */         return !StandardTable.this.containsColumn(StandardTable.Column.this.columnKey);
/*      */       }
/*      */ 
/*      */       public void clear() {
/*  544 */         Predicate predicate = Predicates.alwaysTrue();
/*  545 */         StandardTable.Column.this.removePredicate(predicate);
/*      */       }
/*      */ 
/*      */       public boolean contains(Object o) {
/*  549 */         if ((o instanceof Map.Entry)) {
/*  550 */           Map.Entry entry = (Map.Entry)o;
/*  551 */           return StandardTable.this.containsMapping(entry.getKey(), StandardTable.Column.this.columnKey, entry.getValue());
/*      */         }
/*  553 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean remove(Object obj) {
/*  557 */         if ((obj instanceof Map.Entry)) {
/*  558 */           Map.Entry entry = (Map.Entry)obj;
/*  559 */           return StandardTable.this.removeMapping(entry.getKey(), StandardTable.Column.this.columnKey, entry.getValue());
/*      */         }
/*  561 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean removeAll(Collection<?> c) {
/*  565 */         boolean changed = false;
/*  566 */         for (Iterator i$ = c.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/*  567 */           changed |= remove(obj);
/*      */         }
/*  569 */         return changed;
/*      */       }
/*      */ 
/*      */       public boolean retainAll(Collection<?> c) {
/*  573 */         return StandardTable.Column.this.removePredicate(Predicates.not(Predicates.in(c)));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class Row extends Maps.ImprovedAbstractMap<C, V>
/*      */   {
/*      */     final R rowKey;
/*      */ 
/*      */     Row()
/*      */     {
/*  374 */       this.rowKey = Preconditions.checkNotNull(rowKey);
/*      */     }
/*      */ 
/*      */     protected Set<Map.Entry<C, V>> createEntrySet() {
/*  378 */       return new RowEntrySet(null);
/*      */     }
/*      */ 
/*      */     public boolean containsKey(Object key) {
/*  382 */       return StandardTable.this.contains(this.rowKey, key);
/*      */     }
/*      */ 
/*      */     public V get(Object key) {
/*  386 */       return StandardTable.this.get(this.rowKey, key);
/*      */     }
/*      */ 
/*      */     public V put(C key, V value) {
/*  390 */       return StandardTable.this.put(this.rowKey, key, value);
/*      */     }
/*      */ 
/*      */     public V remove(Object key) {
/*  394 */       return StandardTable.this.remove(this.rowKey, key);
/*      */     }
/*      */     private class RowEntrySet extends AbstractSet<Map.Entry<C, V>> {
/*      */       private RowEntrySet() {
/*      */       }
/*  399 */       public void clear() { StandardTable.this.backingMap.remove(StandardTable.Row.this.rowKey); }
/*      */ 
/*      */       public boolean contains(Object o)
/*      */       {
/*  403 */         if ((o instanceof Map.Entry)) {
/*  404 */           Map.Entry entry = (Map.Entry)o;
/*  405 */           return StandardTable.this.containsMapping(StandardTable.Row.this.rowKey, entry.getKey(), entry.getValue());
/*      */         }
/*  407 */         return false;
/*      */       }
/*      */ 
/*      */       public boolean remove(Object o) {
/*  411 */         if ((o instanceof Map.Entry)) {
/*  412 */           Map.Entry entry = (Map.Entry)o;
/*  413 */           return StandardTable.this.removeMapping(StandardTable.Row.this.rowKey, entry.getKey(), entry.getValue());
/*      */         }
/*  415 */         return false;
/*      */       }
/*      */ 
/*      */       public int size() {
/*  419 */         Map map = (Map)StandardTable.this.backingMap.get(StandardTable.Row.this.rowKey);
/*  420 */         return map == null ? 0 : map.size();
/*      */       }
/*      */ 
/*      */       public Iterator<Map.Entry<C, V>> iterator() {
/*  424 */         Map map = (Map)StandardTable.this.backingMap.get(StandardTable.Row.this.rowKey);
/*  425 */         if (map == null) {
/*  426 */           return Iterators.emptyModifiableIterator();
/*      */         }
/*  428 */         Iterator iterator = map.entrySet().iterator();
/*  429 */         return new Iterator(iterator, map) {
/*      */           public boolean hasNext() {
/*  431 */             return this.val$iterator.hasNext();
/*      */           }
/*      */           public Map.Entry<C, V> next() {
/*  434 */             Map.Entry entry = (Map.Entry)this.val$iterator.next();
/*  435 */             return new ForwardingMapEntry(entry) {
/*      */               protected Map.Entry<C, V> delegate() {
/*  437 */                 return this.val$entry;
/*      */               }
/*      */               public V setValue(V value) {
/*  440 */                 return super.setValue(Preconditions.checkNotNull(value));
/*      */               } } ;
/*      */           }
/*      */ 
/*      */           public void remove() {
/*  445 */             this.val$iterator.remove();
/*  446 */             if (this.val$map.isEmpty())
/*  447 */               StandardTable.this.backingMap.remove(StandardTable.Row.this.rowKey);
/*      */           }
/*      */         };
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class CellIterator
/*      */     implements Iterator<Table.Cell<R, C, V>>
/*      */   {
/*  331 */     final Iterator<Map.Entry<R, Map<C, V>>> rowIterator = StandardTable.this.backingMap.entrySet().iterator();
/*      */     Map.Entry<R, Map<C, V>> rowEntry;
/*  334 */     Iterator<Map.Entry<C, V>> columnIterator = Iterators.emptyModifiableIterator();
/*      */ 
/*      */     private CellIterator() {
/*      */     }
/*  338 */     public boolean hasNext() { return (this.rowIterator.hasNext()) || (this.columnIterator.hasNext()); }
/*      */ 
/*      */     public Table.Cell<R, C, V> next()
/*      */     {
/*  342 */       if (!this.columnIterator.hasNext()) {
/*  343 */         this.rowEntry = ((Map.Entry)this.rowIterator.next());
/*  344 */         this.columnIterator = ((Map)this.rowEntry.getValue()).entrySet().iterator();
/*      */       }
/*  346 */       Map.Entry columnEntry = (Map.Entry)this.columnIterator.next();
/*  347 */       return Tables.immutableCell(this.rowEntry.getKey(), columnEntry.getKey(), columnEntry.getValue());
/*      */     }
/*      */ 
/*      */     public void remove()
/*      */     {
/*  352 */       this.columnIterator.remove();
/*  353 */       if (((Map)this.rowEntry.getValue()).isEmpty())
/*  354 */         this.rowIterator.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class CellSet extends StandardTable<R, C, V>.TableSet<Table.Cell<R, C, V>>
/*      */   {
/*      */     private CellSet()
/*      */     {
/*  302 */       super(null);
/*      */     }
/*  304 */     public Iterator<Table.Cell<R, C, V>> iterator() { return new StandardTable.CellIterator(StandardTable.this, null); }
/*      */ 
/*      */     public int size()
/*      */     {
/*  308 */       return StandardTable.this.size();
/*      */     }
/*      */ 
/*      */     public boolean contains(Object obj) {
/*  312 */       if ((obj instanceof Table.Cell)) {
/*  313 */         Table.Cell cell = (Table.Cell)obj;
/*  314 */         return StandardTable.this.containsMapping(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/*      */       }
/*      */ 
/*  317 */       return false;
/*      */     }
/*      */ 
/*      */     public boolean remove(Object obj) {
/*  321 */       if ((obj instanceof Table.Cell)) {
/*  322 */         Table.Cell cell = (Table.Cell)obj;
/*  323 */         return StandardTable.this.removeMapping(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/*      */       }
/*      */ 
/*  326 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private abstract class TableSet<T> extends AbstractSet<T>
/*      */   {
/*      */     private TableSet()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean isEmpty()
/*      */     {
/*  277 */       return StandardTable.this.backingMap.isEmpty();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  281 */       StandardTable.this.backingMap.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   private abstract class TableCollection<T> extends AbstractCollection<T>
/*      */   {
/*      */     private TableCollection()
/*      */     {
/*      */     }
/*      */ 
/*      */     public boolean isEmpty()
/*      */     {
/*  263 */       return StandardTable.this.backingMap.isEmpty();
/*      */     }
/*      */ 
/*      */     public void clear() {
/*  267 */       StandardTable.this.backingMap.clear();
/*      */     }
/*      */   }
/*      */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.StandardTable
 * JD-Core Version:    0.6.0
 */