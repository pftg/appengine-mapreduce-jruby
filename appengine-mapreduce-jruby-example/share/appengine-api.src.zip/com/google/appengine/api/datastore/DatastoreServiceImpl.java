/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import com.google.apphosting.api.ApiProxy.ApiConfig;
/*     */ import com.google.apphosting.api.DatastorePb.AllocateIdsRequest;
/*     */ import com.google.apphosting.api.DatastorePb.AllocateIdsResponse;
/*     */ import com.google.apphosting.api.DatastorePb.BeginTransactionRequest;
/*     */ import com.google.apphosting.api.DatastorePb.DeleteRequest;
/*     */ import com.google.apphosting.api.DatastorePb.DeleteResponse;
/*     */ import com.google.apphosting.api.DatastorePb.GetRequest;
/*     */ import com.google.apphosting.api.DatastorePb.GetResponse;
/*     */ import com.google.apphosting.api.DatastorePb.GetResponse.Entity;
/*     */ import com.google.apphosting.api.DatastorePb.PutRequest;
/*     */ import com.google.apphosting.api.DatastorePb.PutResponse;
/*     */ import com.google.apphosting.api.DatastorePb.Transaction;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.EntityProto;
/*     */ import com.google.storage.onestore.v3.OnestoreEntity.Reference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class DatastoreServiceImpl
/*     */   implements DatastoreService
/*     */ {
/*  34 */   private static final Logger logger = Logger.getLogger(DatastoreServiceImpl.class.getName());
/*     */   static final long ARBITRARY_FAILOVER_READ_MS = -1L;
/*     */   private final DatastoreServiceConfig datastoreServiceConfig;
/*     */   private final ApiProxy.ApiConfig apiConfig;
/*     */   final TransactionStack defaultTxnProvider;
/*     */ 
/*     */   public DatastoreServiceImpl(DatastoreServiceConfig datastoreServiceConfig, TransactionStack defaultTxnProvider)
/*     */   {
/*  60 */     this.datastoreServiceConfig = datastoreServiceConfig;
/*  61 */     this.apiConfig = createApiConfig(datastoreServiceConfig);
/*  62 */     this.defaultTxnProvider = defaultTxnProvider;
/*     */   }
/*     */ 
/*     */   private ApiProxy.ApiConfig createApiConfig(DatastoreServiceConfig config) {
/*  66 */     ApiProxy.ApiConfig apiConfig = new ApiProxy.ApiConfig();
/*  67 */     apiConfig.setDeadlineInSeconds(config.getDeadline());
/*  68 */     return apiConfig;
/*     */   }
/*     */ 
/*     */   public Entity get(Transaction txn, Key key) throws EntityNotFoundException {
/*  72 */     return get(txn, key, false);
/*     */   }
/*     */ 
/*     */   public Entity get(Key key) throws EntityNotFoundException {
/*  76 */     GetOrCreateTransactionResult result = getOrCreateTransaction();
/*  77 */     return get(result.getTransaction(), key, result.isNew());
/*     */   }
/*     */ 
/*     */   Entity get(Transaction txn, Key key, boolean finishTxn) throws EntityNotFoundException {
/*  81 */     if (key == null) {
/*  82 */       throw new NullPointerException("key cannot be null");
/*     */     }
/*  84 */     Map entities = get(txn, Arrays.asList(new Key[] { key }), finishTxn);
/*  85 */     Entity entity = (Entity)entities.get(key);
/*  86 */     if (entity == null) {
/*  87 */       throw new EntityNotFoundException(key);
/*     */     }
/*  89 */     return entity;
/*     */   }
/*     */ 
/*     */   public Map<Key, Entity> get(Iterable<Key> keys) {
/*  93 */     GetOrCreateTransactionResult result = getOrCreateTransaction();
/*  94 */     return get(result.getTransaction(), keys, result.isNew());
/*     */   }
/*     */ 
/*     */   public Map<Key, Entity> get(Transaction txn, Iterable<Key> keys) {
/*  98 */     return get(txn, keys, false);
/*     */   }
/*     */ 
/*     */   Map<Key, Entity> get(Transaction txn, Iterable<Key> keys, boolean finishTxn) {
/* 102 */     if (keys == null) {
/* 103 */       throw new NullPointerException("keys cannot be null");
/*     */     }
/* 105 */     DatastorePb.GetRequest req = new DatastorePb.GetRequest();
/* 106 */     DatastorePb.GetResponse resp = new DatastorePb.GetResponse();
/*     */ 
/* 111 */     new TransactionRunner(txn, finishTxn, txn, req, keys, resp)
/*     */     {
/*     */       protected void run() {
/* 114 */         if (this.val$txn != null) {
/* 115 */           this.val$req.setTransaction(DatastoreServiceImpl.localTxnToRemoteTxn(this.val$txn));
/*     */         }
/*     */ 
/* 118 */         for (Key key : this.val$keys) {
/* 119 */           if (!key.isComplete()) {
/* 120 */             throw new IllegalArgumentException(key + " is incomplete.");
/*     */           }
/*     */ 
/* 123 */           this.val$req.addKey(KeyTranslator.convertToPb(key));
/*     */         }
/* 125 */         if (DatastoreServiceImpl.this.datastoreServiceConfig.getReadPolicy().getConsistency() == ReadPolicy.Consistency.EVENTUAL) {
/* 126 */           this.val$req.setFailoverMs(-1L);
/*     */         }
/* 128 */         DatastoreApiHelper.makeSyncCall(DatastoreServiceImpl.this.apiConfig, "Get", this.val$req, this.val$resp);
/*     */       }
/*     */     }
/* 111 */     .runInTransaction();
/*     */ 
/* 132 */     Map results = new HashMap();
/* 133 */     Iterator keyIterator = keys.iterator();
/* 134 */     Iterator responseEntitiesIterator = resp.entitys().iterator();
/* 135 */     while (keyIterator.hasNext()) {
/* 136 */       Key key = (Key)keyIterator.next();
/* 137 */       DatastorePb.GetResponse.Entity responseEntity = (DatastorePb.GetResponse.Entity)responseEntitiesIterator.next();
/* 138 */       if (responseEntity.hasEntity()) {
/* 139 */         results.put(key, EntityTranslator.createFromPb(responseEntity.getEntity()));
/*     */       }
/*     */     }
/*     */ 
/* 143 */     return results;
/*     */   }
/*     */ 
/*     */   public Key put(Entity entity) {
/* 147 */     GetOrCreateTransactionResult result = getOrCreateTransaction();
/* 148 */     return put(result.getTransaction(), entity, result.isNew());
/*     */   }
/*     */ 
/*     */   public Key put(Transaction txn, Entity entity) {
/* 152 */     return put(txn, entity, false);
/*     */   }
/*     */ 
/*     */   Key put(Transaction txn, Entity entity, boolean finishTxn) {
/* 156 */     put(txn, Arrays.asList(new Entity[] { entity }), finishTxn);
/* 157 */     return entity.getKey();
/*     */   }
/*     */ 
/*     */   public List<Key> put(Iterable<Entity> entities) {
/* 161 */     GetOrCreateTransactionResult result = getOrCreateTransaction();
/* 162 */     return put(result.getTransaction(), entities, result.isNew());
/*     */   }
/*     */ 
/*     */   public List<Key> put(Transaction txn, Iterable<Entity> entities) {
/* 166 */     return put(txn, entities, false);
/*     */   }
/*     */ 
/*     */   private List<Key> put(Transaction txn, Iterable<Entity> entities, boolean finishTxn) {
/* 170 */     DatastorePb.PutRequest req = new DatastorePb.PutRequest();
/* 171 */     DatastorePb.PutResponse resp = new DatastorePb.PutResponse();
/*     */ 
/* 176 */     new TransactionRunner(txn, finishTxn, txn, req, entities, resp)
/*     */     {
/*     */       protected void run() {
/* 179 */         if (this.val$txn != null) {
/* 180 */           this.val$req.setTransaction(DatastoreServiceImpl.localTxnToRemoteTxn(this.val$txn));
/*     */         }
/*     */ 
/* 183 */         for (Entity entity : this.val$entities) {
/* 184 */           OnestoreEntity.EntityProto proto = EntityTranslator.convertToPb(entity);
/* 185 */           this.val$req.addEntity(proto);
/*     */         }
/*     */ 
/* 188 */         DatastoreApiHelper.makeSyncCall(DatastoreServiceImpl.this.apiConfig, "Put", this.val$req, this.val$resp);
/*     */       }
/*     */     }
/* 176 */     .runInTransaction();
/*     */ 
/* 192 */     Iterator entitiesIterator = entities.iterator();
/* 193 */     Iterator referenceIterator = resp.keys().iterator();
/* 194 */     List keysInOrder = new ArrayList(resp.keySize());
/* 195 */     while (entitiesIterator.hasNext()) {
/* 196 */       Entity entity = (Entity)entitiesIterator.next();
/* 197 */       OnestoreEntity.Reference reference = (OnestoreEntity.Reference)referenceIterator.next();
/*     */ 
/* 201 */       KeyTranslator.updateKey(reference, entity.getKey());
/* 202 */       keysInOrder.add(entity.getKey());
/*     */     }
/* 204 */     return keysInOrder;
/*     */   }
/*     */ 
/*     */   public void delete(Key[] keys) {
/* 208 */     GetOrCreateTransactionResult result = getOrCreateTransaction();
/* 209 */     delete(result.getTransaction(), result.isNew(), keys);
/*     */   }
/*     */ 
/*     */   public void delete(Transaction txn, Key[] keys) {
/* 213 */     delete(txn, false, keys);
/*     */   }
/*     */ 
/*     */   void delete(Transaction txn, boolean finishTxn, Key[] keys) {
/* 217 */     delete(txn, Arrays.asList(keys), finishTxn);
/*     */   }
/*     */ 
/*     */   public void delete(Iterable<Key> keys) {
/* 221 */     GetOrCreateTransactionResult result = getOrCreateTransaction();
/* 222 */     delete(result.getTransaction(), keys, result.isNew());
/*     */   }
/*     */ 
/*     */   public void delete(Transaction txn, Iterable<Key> keys) {
/* 226 */     delete(txn, keys, false);
/*     */   }
/*     */ 
/*     */   void delete(Transaction txn, Iterable<Key> keys, boolean finishTxn) {
/* 230 */     DatastorePb.DeleteRequest request = new DatastorePb.DeleteRequest();
/* 231 */     DatastorePb.DeleteResponse response = new DatastorePb.DeleteResponse();
/*     */ 
/* 236 */     new TransactionRunner(txn, finishTxn, txn, request, keys, response)
/*     */     {
/*     */       protected void run() {
/* 239 */         if (this.val$txn != null) {
/* 240 */           this.val$request.setTransaction(DatastoreServiceImpl.localTxnToRemoteTxn(this.val$txn));
/*     */         }
/*     */ 
/* 243 */         for (Key key : this.val$keys) {
/* 244 */           if (!key.isComplete()) {
/* 245 */             throw new IllegalArgumentException(key + " is incomplete.");
/*     */           }
/* 247 */           this.val$request.addKey(KeyTranslator.convertToPb(key));
/*     */         }
/*     */ 
/* 250 */         DatastoreApiHelper.makeSyncCall(DatastoreServiceImpl.this.apiConfig, "Delete", this.val$request, this.val$response);
/*     */       }
/*     */     }
/* 236 */     .runInTransaction();
/*     */   }
/*     */ 
/*     */   public PreparedQuery prepare(Query query)
/*     */   {
/* 256 */     return prepare(null, query);
/*     */   }
/*     */ 
/*     */   public PreparedQuery prepare(Transaction txn, Query query)
/*     */   {
/* 284 */     MultiQueryBuilder queriesToRun = QuerySplitHelper.splitQuery(query);
/* 285 */     if (queriesToRun != null) {
/* 286 */       return new PreparedMultiQuery(this.apiConfig, this.datastoreServiceConfig, queriesToRun, txn);
/*     */     }
/*     */ 
/* 289 */     return new PreparedQueryImpl(this.apiConfig, this.datastoreServiceConfig, query, txn);
/*     */   }
/*     */ 
/*     */   public Transaction beginTransaction() {
/* 293 */     DatastorePb.Transaction remoteTxn = new DatastorePb.Transaction();
/* 294 */     DatastorePb.BeginTransactionRequest request = new DatastorePb.BeginTransactionRequest();
/* 295 */     request.setApp(DatastoreApiHelper.getCurrentAppId());
/*     */ 
/* 297 */     DatastoreApiHelper.makeSyncCall(this.apiConfig, "BeginTransaction", request, remoteTxn);
/*     */ 
/* 299 */     Transaction localTxn = remoteTxnToLocalTxn(remoteTxn);
/*     */ 
/* 302 */     this.defaultTxnProvider.push(localTxn);
/* 303 */     return localTxn;
/*     */   }
/*     */ 
/*     */   public Transaction getCurrentTransaction() {
/* 307 */     return this.defaultTxnProvider.peek();
/*     */   }
/*     */ 
/*     */   public Transaction getCurrentTransaction(Transaction returnedIfNoTxn) {
/* 311 */     return this.defaultTxnProvider.peek(returnedIfNoTxn);
/*     */   }
/*     */ 
/*     */   public Collection<Transaction> getActiveTransactions() {
/* 315 */     return this.defaultTxnProvider.getAll();
/*     */   }
/*     */ 
/*     */   Transaction remoteTxnToLocalTxn(DatastorePb.Transaction remote) {
/* 319 */     return new TransactionImpl(this.apiConfig, remote.getApp(), remote.getHandle(), this.defaultTxnProvider);
/*     */   }
/*     */ 
/*     */   static DatastorePb.Transaction localTxnToRemoteTxn(Transaction local) {
/* 323 */     DatastorePb.Transaction remote = new DatastorePb.Transaction();
/* 324 */     remote.setApp(local.getApp());
/* 325 */     remote.setHandle(Long.parseLong(local.getId()));
/* 326 */     return remote;
/*     */   }
/*     */ 
/*     */   GetOrCreateTransactionResult getOrCreateTransaction()
/*     */   {
/* 335 */     Transaction currentTxn = getCurrentTransaction(null);
/*     */ 
/* 337 */     if (currentTxn != null) {
/* 338 */       return new GetOrCreateTransactionResult(false, currentTxn, null);
/*     */     }
/*     */ 
/* 342 */     switch (4.$SwitchMap$com$google$appengine$api$datastore$ImplicitTransactionManagementPolicy[this.datastoreServiceConfig.getImplicitTransactionManagementPolicy().ordinal()])
/*     */     {
/*     */     case 1:
/* 345 */       return new GetOrCreateTransactionResult(false, null, null);
/*     */     case 2:
/* 347 */       return new GetOrCreateTransactionResult(true, beginTransaction(), null);
/*     */     }
/* 349 */     String msg = "Unexpected Transaction Creation Policy: " + this.datastoreServiceConfig.getImplicitTransactionManagementPolicy();
/*     */ 
/* 351 */     logger.severe(msg);
/* 352 */     throw new IllegalArgumentException(msg);
/*     */   }
/*     */ 
/*     */   public KeyRange allocateIds(String kind, long num)
/*     */   {
/* 387 */     return allocateIds(null, kind, num);
/*     */   }
/*     */ 
/*     */   public KeyRange allocateIds(Key parent, String kind, long num) {
/* 391 */     if (num <= 0L) {
/* 392 */       throw new IllegalArgumentException("num must be > 0");
/*     */     }
/*     */ 
/* 395 */     if (num > 1000000000L) {
/* 396 */       throw new IllegalArgumentException("num must be < 1 billion");
/*     */     }
/*     */ 
/* 400 */     OnestoreEntity.Reference allocateIdsRef = buildAllocateIdsRef(parent, kind);
/* 401 */     DatastorePb.AllocateIdsRequest req = new DatastorePb.AllocateIdsRequest().setSize(num).setModelKey(allocateIdsRef);
/*     */ 
/* 403 */     DatastorePb.AllocateIdsResponse resp = new DatastorePb.AllocateIdsResponse();
/* 404 */     DatastoreApiHelper.makeSyncCall(this.apiConfig, "AllocateIds", req, resp);
/* 405 */     return new KeyRange(parent, kind, resp.getStart(), resp.getEnd());
/*     */   }
/*     */ 
/*     */   static OnestoreEntity.Reference buildAllocateIdsRef(Key parent, String kind)
/*     */   {
/* 410 */     if ((parent != null) && (!parent.isComplete())) {
/* 411 */       throw new IllegalArgumentException("parent key must be complete");
/*     */     }
/*     */ 
/* 414 */     Key key = KeyFactory.createKey(parent, kind, "ignored");
/* 415 */     return KeyTranslator.convertToPb(key);
/*     */   }
/*     */ 
/*     */   public DatastoreService.KeyRangeState allocateIdRange(KeyRange range)
/*     */   {
/* 420 */     Key parent = range.getParent();
/* 421 */     String kind = range.getKind();
/* 422 */     long start = range.getStart().getId();
/* 423 */     long end = range.getEnd().getId();
/*     */ 
/* 425 */     DatastorePb.AllocateIdsRequest req = new DatastorePb.AllocateIdsRequest().setModelKey(buildAllocateIdsRef(parent, kind)).setMax(end);
/*     */ 
/* 428 */     DatastorePb.AllocateIdsResponse resp = new DatastorePb.AllocateIdsResponse();
/* 429 */     DatastoreApiHelper.makeSyncCall(this.apiConfig, "AllocateIds", req, resp);
/*     */ 
/* 437 */     Query query = new Query(kind).setKeysOnly();
/* 438 */     query.addFilter("__key__", Query.FilterOperator.GREATER_THAN_OR_EQUAL, range.getStart());
/* 439 */     query.addFilter("__key__", Query.FilterOperator.LESS_THAN_OR_EQUAL, range.getEnd());
/* 440 */     List collision = prepare(query).asList(FetchOptions.Builder.withLimit(1));
/*     */ 
/* 442 */     if (!collision.isEmpty()) {
/* 443 */       return DatastoreService.KeyRangeState.COLLISION;
/*     */     }
/*     */ 
/* 448 */     boolean raceCondition = start < resp.getStart();
/* 449 */     return raceCondition ? DatastoreService.KeyRangeState.CONTENTION : DatastoreService.KeyRangeState.EMPTY;
/*     */   }
/*     */ 
/*     */   static final class GetOrCreateTransactionResult
/*     */   {
/*     */     private final boolean isNew;
/*     */     private final Transaction txn;
/*     */ 
/*     */     private GetOrCreateTransactionResult(boolean aNew, Transaction txn)
/*     */     {
/* 366 */       this.isNew = aNew;
/* 367 */       this.txn = txn;
/*     */     }
/*     */ 
/*     */     public boolean isNew()
/*     */     {
/* 375 */       return this.isNew;
/*     */     }
/*     */ 
/*     */     public Transaction getTransaction()
/*     */     {
/* 382 */       return this.txn;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.DatastoreServiceImpl
 * JD-Core Version:    0.6.0
 */