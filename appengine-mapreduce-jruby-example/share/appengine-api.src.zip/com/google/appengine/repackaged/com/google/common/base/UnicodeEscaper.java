/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.IOException;
/*     */ 
/*     */ @GoogleInternal
/*     */ @GwtCompatible
/*     */ public abstract class UnicodeEscaper extends Escaper
/*     */ {
/*     */   private static final int DEST_PAD = 32;
/*     */ 
/*     */   protected abstract char[] escape(int paramInt);
/*     */ 
/*     */   protected int nextEscapeIndex(CharSequence csq, int start, int end)
/*     */   {
/* 100 */     int index = start;
/* 101 */     while (index < end) {
/* 102 */       int cp = codePointAt(csq, index, end);
/* 103 */       if ((cp < 0) || (escape(cp) != null)) {
/*     */         break;
/*     */       }
/* 106 */       index += (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*     */     }
/* 108 */     return index;
/*     */   }
/*     */ 
/*     */   public String escape(String string)
/*     */   {
/* 136 */     Preconditions.checkNotNull(string);
/* 137 */     int end = string.length();
/* 138 */     int index = nextEscapeIndex(string, 0, end);
/* 139 */     return index == end ? string : escapeSlow(string, index);
/*     */   }
/*     */ 
/*     */   protected final String escapeSlow(String s, int index)
/*     */   {
/* 160 */     int end = s.length();
/*     */ 
/* 163 */     char[] dest = Platform.charBufferFromThreadLocal();
/* 164 */     int destIndex = 0;
/* 165 */     int unescapedChunkStart = 0;
/*     */ 
/* 167 */     while (index < end) {
/* 168 */       int cp = codePointAt(s, index, end);
/* 169 */       if (cp < 0) {
/* 170 */         throw new IllegalArgumentException("Trailing high surrogate at end of input");
/*     */       }
/*     */ 
/* 176 */       char[] escaped = escape(cp);
/* 177 */       int nextIndex = index + (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/* 178 */       if (escaped != null) {
/* 179 */         int charsSkipped = index - unescapedChunkStart;
/*     */ 
/* 183 */         int sizeNeeded = destIndex + charsSkipped + escaped.length;
/* 184 */         if (dest.length < sizeNeeded) {
/* 185 */           int destLength = sizeNeeded + (end - index) + 32;
/* 186 */           dest = growBuffer(dest, destIndex, destLength);
/*     */         }
/*     */ 
/* 189 */         if (charsSkipped > 0) {
/* 190 */           s.getChars(unescapedChunkStart, index, dest, destIndex);
/* 191 */           destIndex += charsSkipped;
/*     */         }
/* 193 */         if (escaped.length > 0) {
/* 194 */           System.arraycopy(escaped, 0, dest, destIndex, escaped.length);
/* 195 */           destIndex += escaped.length;
/*     */         }
/*     */ 
/* 198 */         unescapedChunkStart = nextIndex;
/*     */       }
/* 200 */       index = nextEscapeIndex(s, nextIndex, end);
/*     */     }
/*     */ 
/* 205 */     int charsSkipped = end - unescapedChunkStart;
/* 206 */     if (charsSkipped > 0) {
/* 207 */       int endIndex = destIndex + charsSkipped;
/* 208 */       if (dest.length < endIndex) {
/* 209 */         dest = growBuffer(dest, destIndex, endIndex);
/*     */       }
/* 211 */       s.getChars(unescapedChunkStart, end, dest, destIndex);
/* 212 */       destIndex = endIndex;
/*     */     }
/* 214 */     return new String(dest, 0, destIndex);
/*     */   }
/*     */ 
/*     */   public Appendable escape(Appendable out)
/*     */   {
/* 254 */     Preconditions.checkNotNull(out);
/*     */ 
/* 256 */     return new Appendable(out) {
/* 257 */       char pendingHighSurrogate = '\000';
/*     */ 
/*     */       public Appendable append(CharSequence csq) throws IOException
/*     */       {
/* 261 */         return append(csq, 0, csq.length());
/*     */       }
/*     */ 
/*     */       public Appendable append(CharSequence csq, int start, int end)
/*     */         throws IOException
/*     */       {
/* 267 */         Preconditions.checkNotNull(csq);
/* 268 */         Preconditions.checkPositionIndexes(start, end, csq.length());
/*     */ 
/* 272 */         if ((this.pendingHighSurrogate != 0) && (start < end)) {
/* 273 */           completeSurrogatePair(csq.charAt(start++));
/*     */         }
/*     */ 
/* 276 */         if (start < end)
/*     */         {
/* 279 */           char last = csq.charAt(end - 1);
/* 280 */           if (Character.isHighSurrogate(last)) {
/* 281 */             this.pendingHighSurrogate = last;
/* 282 */             end--;
/*     */           }
/*     */ 
/* 287 */           this.val$out.append(UnicodeEscaper.this.escape(csq.subSequence(start, end).toString()));
/*     */         }
/* 289 */         return this;
/*     */       }
/*     */ 
/*     */       public Appendable append(char c) throws IOException
/*     */       {
/* 294 */         if (this.pendingHighSurrogate != 0) {
/* 295 */           completeSurrogatePair(c);
/* 296 */         } else if (Character.isHighSurrogate(c)) {
/* 297 */           this.pendingHighSurrogate = c;
/*     */         } else {
/* 299 */           if (Character.isLowSurrogate(c)) {
/* 300 */             throw new IllegalArgumentException("Unexpected low surrogate character '" + c + "' with value " + c);
/*     */           }
/*     */ 
/* 305 */           char[] escaped = UnicodeEscaper.this.escape(c);
/* 306 */           if (escaped != null)
/* 307 */             outputChars(escaped);
/*     */           else {
/* 309 */             this.val$out.append(c);
/*     */           }
/*     */         }
/* 312 */         return this;
/*     */       }
/*     */ 
/*     */       private void completeSurrogatePair(char c)
/*     */         throws IOException
/*     */       {
/* 321 */         if (!Character.isLowSurrogate(c)) {
/* 322 */           throw new IllegalArgumentException("Expected low surrogate character but got '" + c + "' with value " + c);
/*     */         }
/*     */ 
/* 326 */         char[] escaped = UnicodeEscaper.this.escape(Character.toCodePoint(this.pendingHighSurrogate, c));
/*     */ 
/* 328 */         if (escaped != null) {
/* 329 */           outputChars(escaped);
/*     */         } else {
/* 331 */           this.val$out.append(this.pendingHighSurrogate);
/* 332 */           this.val$out.append(c);
/*     */         }
/* 334 */         this.pendingHighSurrogate = '\000';
/*     */       }
/*     */ 
/*     */       private void outputChars(char[] chars)
/*     */         throws IOException
/*     */       {
/* 341 */         for (int n = 0; n < chars.length; n++)
/* 342 */           this.val$out.append(chars[n]);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   protected static final int codePointAt(CharSequence seq, int index, int end)
/*     */   {
/* 381 */     if (index < end) {
/* 382 */       char c1 = seq.charAt(index++);
/* 383 */       if ((c1 < 55296) || (c1 > 57343))
/*     */       {
/* 386 */         return c1;
/* 387 */       }if (c1 <= 56319)
/*     */       {
/* 389 */         if (index == end) {
/* 390 */           return -c1;
/*     */         }
/*     */ 
/* 393 */         char c2 = seq.charAt(index);
/* 394 */         if (Character.isLowSurrogate(c2)) {
/* 395 */           return Character.toCodePoint(c1, c2);
/*     */         }
/* 397 */         throw new IllegalArgumentException("Expected low surrogate but got char '" + c2 + "' with value " + c2 + " at index " + index);
/*     */       }
/*     */ 
/* 401 */       throw new IllegalArgumentException("Unexpected low surrogate character '" + c1 + "' with value " + c1 + " at index " + (index - 1));
/*     */     }
/*     */ 
/* 406 */     throw new IndexOutOfBoundsException("Index exceeds specified range");
/*     */   }
/*     */ 
/*     */   private static final char[] growBuffer(char[] dest, int index, int size)
/*     */   {
/* 415 */     char[] copy = new char[size];
/* 416 */     if (index > 0) {
/* 417 */       System.arraycopy(dest, 0, copy, 0, index);
/*     */     }
/* 419 */     return copy;
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.UnicodeEscaper
 * JD-Core Version:    0.6.0
 */