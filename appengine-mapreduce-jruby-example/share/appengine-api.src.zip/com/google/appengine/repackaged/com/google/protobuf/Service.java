package com.google.appengine.repackaged.com.google.protobuf;

public abstract interface Service
{
  public abstract Descriptors.ServiceDescriptor getDescriptorForType();

  public abstract void callMethod(Descriptors.MethodDescriptor paramMethodDescriptor, RpcController paramRpcController, Message paramMessage, RpcCallback<Message> paramRpcCallback);

  public abstract Message getRequestPrototype(Descriptors.MethodDescriptor paramMethodDescriptor);

  public abstract Message getResponsePrototype(Descriptors.MethodDescriptor paramMethodDescriptor);
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.Service
 * JD-Core Version:    0.6.0
 */