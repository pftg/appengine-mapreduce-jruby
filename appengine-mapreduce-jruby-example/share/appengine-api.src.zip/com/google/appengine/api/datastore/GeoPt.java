/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public final class GeoPt
/*     */   implements Serializable, Comparable<GeoPt>
/*     */ {
/*     */   public static final long serialVersionUID = 349808987517153697L;
/*     */   private float latitude;
/*     */   private float longitude;
/*     */ 
/*     */   public GeoPt(float latitude, float longitude)
/*     */   {
/*  33 */     if (Math.abs(latitude) > 90.0F) {
/*  34 */       throw new IllegalArgumentException("Latitude must be between -90 and 90 (inclusive).");
/*     */     }
/*     */ 
/*  37 */     if (Math.abs(longitude) > 180.0F) {
/*  38 */       throw new IllegalArgumentException("Latitude must be between -180 and 180.");
/*     */     }
/*     */ 
/*  41 */     this.latitude = latitude;
/*  42 */     this.longitude = longitude;
/*     */   }
/*     */ 
/*     */   private GeoPt()
/*     */   {
/*  52 */     this(0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public float getLatitude() {
/*  56 */     return this.latitude;
/*     */   }
/*     */ 
/*     */   public float getLongitude() {
/*  60 */     return this.longitude;
/*     */   }
/*     */ 
/*     */   public int compareTo(GeoPt o)
/*     */   {
/*  67 */     int latResult = Float.valueOf(this.latitude).compareTo(Float.valueOf(o.latitude));
/*  68 */     if (latResult != 0) {
/*  69 */       return latResult;
/*     */     }
/*  71 */     return Float.valueOf(this.longitude).compareTo(Float.valueOf(o.longitude));
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  76 */     if (this == o) {
/*  77 */       return true;
/*     */     }
/*  79 */     if ((o == null) || (getClass() != o.getClass())) {
/*  80 */       return false;
/*     */     }
/*     */ 
/*  83 */     GeoPt geoPt = (GeoPt)o;
/*     */ 
/*  85 */     if (Float.compare(geoPt.latitude, this.latitude) != 0) {
/*  86 */       return false;
/*     */     }
/*     */ 
/*  89 */     return Float.compare(geoPt.longitude, this.longitude) == 0;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  98 */     int result = this.latitude != 0.0F ? Float.floatToIntBits(this.latitude) : 0;
/*  99 */     result = 31 * result + (this.longitude != 0.0F ? Float.floatToIntBits(this.longitude) : 0);
/* 100 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 105 */     return String.format("%f,%f", new Object[] { Float.valueOf(this.latitude), Float.valueOf(this.longitude) });
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.GeoPt
 * JD-Core Version:    0.6.0
 */