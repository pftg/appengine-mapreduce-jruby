/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.mail.event.ConnectionEvent;
/*     */ import javax.mail.event.ConnectionListener;
/*     */ import javax.mail.event.FolderEvent;
/*     */ import javax.mail.event.FolderListener;
/*     */ import javax.mail.event.MailEvent;
/*     */ import javax.mail.event.MessageChangedEvent;
/*     */ import javax.mail.event.MessageChangedListener;
/*     */ import javax.mail.event.MessageCountEvent;
/*     */ import javax.mail.event.MessageCountListener;
/*     */ import javax.mail.search.SearchTerm;
/*     */ 
/*     */ public abstract class Folder
/*     */ {
/*     */   public static final int HOLDS_MESSAGES = 1;
/*     */   public static final int HOLDS_FOLDERS = 2;
/*     */   public static final int READ_ONLY = 1;
/*     */   public static final int READ_WRITE = 2;
/*     */   protected Store store;
/*  82 */   protected int mode = -1;
/*     */ 
/*  84 */   private final ArrayList connectionListeners = new ArrayList(2);
/*  85 */   private final ArrayList folderListeners = new ArrayList(2);
/*  86 */   private final ArrayList messageChangedListeners = new ArrayList(2);
/*  87 */   private final ArrayList messageCountListeners = new ArrayList(2);
/*     */ 
/*  90 */   private EventQueue queue = null;
/*     */ 
/*     */   protected Folder(Store store)
/*     */   {
/*  98 */     this.store = store;
/*     */   }
/*     */ 
/*     */   public abstract String getName();
/*     */ 
/*     */   public abstract String getFullName();
/*     */ 
/*     */   public URLName getURLName()
/*     */     throws MessagingException
/*     */   {
/* 124 */     URLName baseURL = this.store.getURLName();
/* 125 */     return new URLName(baseURL.getProtocol(), baseURL.getHost(), baseURL.getPort(), getFullName(), baseURL.getUsername(), null);
/*     */   }
/*     */ 
/*     */   public Store getStore()
/*     */   {
/* 135 */     return this.store;
/*     */   }
/*     */ 
/*     */   public abstract Folder getParent()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract boolean exists()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Folder[] list(String paramString)
/*     */     throws MessagingException;
/*     */ 
/*     */   public Folder[] listSubscribed(String pattern)
/*     */     throws MessagingException
/*     */   {
/* 182 */     return list(pattern);
/*     */   }
/*     */ 
/*     */   public Folder[] list()
/*     */     throws MessagingException
/*     */   {
/* 192 */     return list("%");
/*     */   }
/*     */ 
/*     */   public Folder[] listSubscribed()
/*     */     throws MessagingException
/*     */   {
/* 202 */     return listSubscribed("%");
/*     */   }
/*     */ 
/*     */   public abstract char getSeparator()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract int getType()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract boolean create(int paramInt)
/*     */     throws MessagingException;
/*     */ 
/*     */   public boolean isSubscribed()
/*     */   {
/* 244 */     return true;
/*     */   }
/*     */ 
/*     */   public void setSubscribed(boolean subscribed)
/*     */     throws MessagingException
/*     */   {
/* 257 */     throw new MethodNotSupportedException();
/*     */   }
/*     */ 
/*     */   public abstract boolean hasNewMessages()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Folder getFolder(String paramString)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract boolean delete(boolean paramBoolean)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract boolean renameTo(Folder paramFolder)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void open(int paramInt)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void close(boolean paramBoolean)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract boolean isOpen();
/*     */ 
/*     */   public int getMode()
/*     */   {
/* 369 */     return this.mode;
/*     */   }
/*     */ 
/*     */   public abstract Flags getPermanentFlags();
/*     */ 
/*     */   public abstract int getMessageCount()
/*     */     throws MessagingException;
/*     */ 
/*     */   public int getNewMessageCount()
/*     */     throws MessagingException
/*     */   {
/* 402 */     return getCount(Flags.Flag.RECENT, true);
/*     */   }
/*     */ 
/*     */   public int getUnreadMessageCount()
/*     */     throws MessagingException
/*     */   {
/* 417 */     return getCount(Flags.Flag.SEEN, false);
/*     */   }
/*     */ 
/*     */   public int getDeletedMessageCount()
/*     */     throws MessagingException
/*     */   {
/* 432 */     return getCount(Flags.Flag.DELETED, true);
/*     */   }
/*     */ 
/*     */   private int getCount(Flags.Flag flag, boolean value) throws MessagingException {
/* 436 */     if (!isOpen()) {
/* 437 */       return -1;
/*     */     }
/* 439 */     Message[] messages = getMessages();
/* 440 */     int total = 0;
/* 441 */     for (int i = 0; i < messages.length; i++) {
/* 442 */       if (messages[i].getFlags().contains(flag) == value) {
/* 443 */         total++;
/*     */       }
/*     */     }
/* 446 */     return total;
/*     */   }
/*     */ 
/*     */   public abstract Message getMessage(int paramInt)
/*     */     throws MessagingException;
/*     */ 
/*     */   public Message[] getMessages(int start, int end)
/*     */     throws MessagingException
/*     */   {
/* 471 */     Message[] result = new Message[end - start + 1];
/* 472 */     for (int i = 0; i < result.length; i++) {
/* 473 */       result[i] = getMessage(start++);
/*     */     }
/* 475 */     return result;
/*     */   }
/*     */ 
/*     */   public Message[] getMessages(int[] ids)
/*     */     throws MessagingException
/*     */   {
/* 486 */     Message[] result = new Message[ids.length];
/* 487 */     for (int i = 0; i < ids.length; i++) {
/* 488 */       result[i] = getMessage(ids[i]);
/*     */     }
/* 490 */     return result;
/*     */   }
/*     */ 
/*     */   public Message[] getMessages()
/*     */     throws MessagingException
/*     */   {
/* 500 */     return getMessages(1, getMessageCount());
/*     */   }
/*     */ 
/*     */   public abstract void appendMessages(Message[] paramArrayOfMessage)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void fetch(Message[] messages, FetchProfile profile)
/*     */     throws MessagingException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setFlags(Message[] messages, Flags flags, boolean value)
/*     */     throws MessagingException
/*     */   {
/* 540 */     for (int i = 0; i < messages.length; i++) {
/* 541 */       Message message = messages[i];
/* 542 */       message.setFlags(flags, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setFlags(int start, int end, Flags flags, boolean value)
/*     */     throws MessagingException
/*     */   {
/* 559 */     for (int i = start; i <= end; i++) {
/* 560 */       Message message = getMessage(i);
/* 561 */       message.setFlags(flags, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setFlags(int[] ids, Flags flags, boolean value)
/*     */     throws MessagingException
/*     */   {
/* 577 */     for (int i = 0; i < ids.length; i++) {
/* 578 */       Message message = getMessage(ids[i]);
/* 579 */       message.setFlags(flags, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void copyMessages(Message[] messages, Folder folder)
/*     */     throws MessagingException
/*     */   {
/* 592 */     folder.appendMessages(messages);
/*     */   }
/*     */ 
/*     */   public abstract Message[] expunge()
/*     */     throws MessagingException;
/*     */ 
/*     */   public Message[] search(SearchTerm term)
/*     */     throws MessagingException
/*     */   {
/* 617 */     return search(term, getMessages());
/*     */   }
/*     */ 
/*     */   public Message[] search(SearchTerm term, Message[] messages)
/*     */     throws MessagingException
/*     */   {
/* 633 */     List result = new ArrayList(messages.length);
/* 634 */     for (int i = 0; i < messages.length; i++) {
/* 635 */       Message message = messages[i];
/* 636 */       if (message.match(term)) {
/* 637 */         result.add(message);
/*     */       }
/*     */     }
/* 640 */     return (Message[])(Message[])result.toArray(new Message[result.size()]);
/*     */   }
/*     */ 
/*     */   public void addConnectionListener(ConnectionListener listener) {
/* 644 */     this.connectionListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeConnectionListener(ConnectionListener listener) {
/* 648 */     this.connectionListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyConnectionListeners(int type) {
/* 652 */     queueEvent(new ConnectionEvent(this, type), this.connectionListeners);
/*     */   }
/*     */ 
/*     */   public void addFolderListener(FolderListener listener) {
/* 656 */     this.folderListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeFolderListener(FolderListener listener) {
/* 660 */     this.folderListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyFolderListeners(int type) {
/* 664 */     queueEvent(new FolderEvent(this, this, type), this.folderListeners);
/*     */   }
/*     */ 
/*     */   protected void notifyFolderRenamedListeners(Folder newFolder) {
/* 668 */     queueEvent(new FolderEvent(this, this, newFolder, 3), this.folderListeners);
/*     */   }
/*     */ 
/*     */   public void addMessageCountListener(MessageCountListener listener) {
/* 672 */     this.messageCountListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeMessageCountListener(MessageCountListener listener) {
/* 676 */     this.messageCountListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyMessageAddedListeners(Message[] messages) {
/* 680 */     queueEvent(new MessageCountEvent(this, 1, false, messages), this.messageChangedListeners);
/*     */   }
/*     */ 
/*     */   protected void notifyMessageRemovedListeners(boolean removed, Message[] messages) {
/* 684 */     queueEvent(new MessageCountEvent(this, 2, removed, messages), this.messageChangedListeners);
/*     */   }
/*     */ 
/*     */   public void addMessageChangedListener(MessageChangedListener listener) {
/* 688 */     this.messageChangedListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeMessageChangedListener(MessageChangedListener listener) {
/* 692 */     this.messageChangedListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   protected void notifyMessageChangedListeners(int type, Message message) {
/* 696 */     queueEvent(new MessageChangedEvent(this, type, message), this.messageChangedListeners);
/*     */   }
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 704 */     if (this.queue != null) {
/* 705 */       this.queue.stop();
/* 706 */       this.queue = null;
/*     */     }
/* 708 */     this.connectionListeners.clear();
/* 709 */     this.folderListeners.clear();
/* 710 */     this.messageChangedListeners.clear();
/* 711 */     this.messageCountListeners.clear();
/* 712 */     this.store = null;
/* 713 */     super.finalize();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 721 */     String name = getFullName();
/* 722 */     return name == null ? super.toString() : name;
/*     */   }
/*     */ 
/*     */   private synchronized void queueEvent(MailEvent event, ArrayList listeners)
/*     */   {
/* 737 */     if (listeners.isEmpty()) {
/* 738 */       return;
/*     */     }
/*     */ 
/* 741 */     if (this.queue == null) {
/* 742 */       this.queue = new EventQueue();
/*     */     }
/*     */ 
/* 745 */     this.queue.queueEvent(event, (List)listeners.clone());
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Folder
 * JD-Core Version:    0.6.0
 */