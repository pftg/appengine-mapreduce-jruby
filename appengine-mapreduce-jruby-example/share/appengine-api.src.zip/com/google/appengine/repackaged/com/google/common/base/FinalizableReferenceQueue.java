/*     */ package com.google.appengine.repackaged.com.google.common.base;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class FinalizableReferenceQueue
/*     */ {
/*  75 */   private static final Logger logger = Logger.getLogger(FinalizableReferenceQueue.class.getName());
/*     */   private static final String FINALIZER_CLASS_NAME = "com.google.appengine.repackaged.com.google.common.base.internal.Finalizer";
/*     */   private static final Method startFinalizer;
/*     */   final ReferenceQueue<Object> queue;
/*     */   final boolean threadStarted;
/*     */ 
/*     */   public FinalizableReferenceQueue()
/*     */   {
/* 104 */     boolean threadStarted = false;
/*     */     ReferenceQueue queue;
/*     */     try
/*     */     {
/* 106 */       queue = (ReferenceQueue)startFinalizer.invoke(null, new Object[] { FinalizableReference.class, this });
/*     */ 
/* 108 */       threadStarted = true;
/*     */     } catch (IllegalAccessException impossible) {
/* 110 */       throw new AssertionError(impossible);
/*     */     } catch (Throwable t) {
/* 112 */       logger.log(Level.INFO, "Failed to start reference finalizer thread. Reference cleanup will only occur when new references are created.", t);
/*     */ 
/* 114 */       queue = new ReferenceQueue();
/*     */     }
/*     */ 
/* 117 */     this.queue = queue;
/* 118 */     this.threadStarted = threadStarted;
/*     */   }
/*     */ 
/*     */   void cleanUp()
/*     */   {
/* 127 */     if (this.threadStarted)
/* 128 */       return;
/*     */     Reference reference;
/* 132 */     while ((reference = this.queue.poll()) != null)
/*     */     {
/* 137 */       reference.clear();
/*     */       try {
/* 139 */         ((FinalizableReference)reference).finalizeReferent();
/*     */       } catch (Throwable t) {
/* 141 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Class<?> loadFinalizer(FinalizerLoader[] loaders)
/*     */   {
/* 152 */     for (FinalizerLoader loader : loaders) {
/* 153 */       Class finalizer = loader.loadFinalizer();
/* 154 */       if (finalizer != null) {
/* 155 */         return finalizer;
/*     */       }
/*     */     }
/*     */ 
/* 159 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   static Method getStartFinalizer(Class<?> finalizer)
/*     */   {
/*     */     try
/*     */     {
/* 276 */       return finalizer.getMethod("startFinalizer", new Class[] { Class.class, Object.class }); } catch (NoSuchMethodException e) {
/*     */     }
/* 278 */     throw new AssertionError(e);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  82 */     Class finalizer = loadFinalizer(new FinalizerLoader[] { new SystemLoader(), new DecoupledLoader(), new DirectLoader() });
/*     */ 
/*  84 */     startFinalizer = getStartFinalizer(finalizer);
/*     */   }
/*     */ 
/*     */   static class DirectLoader
/*     */     implements FinalizableReferenceQueue.FinalizerLoader
/*     */   {
/*     */     public Class<?> loadFinalizer()
/*     */     {
/*     */       try
/*     */       {
/* 264 */         return Class.forName("com.google.appengine.repackaged.com.google.common.base.internal.Finalizer"); } catch (ClassNotFoundException e) {
/*     */       }
/* 266 */       throw new AssertionError(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class DecoupledLoader
/*     */     implements FinalizableReferenceQueue.FinalizerLoader
/*     */   {
/*     */     private static final String LOADING_ERROR = "Could not load Finalizer in its own class loader.Loading Finalizer in the current class loader instead. As a result, you will not be ableto garbage collect this class loader. To support reclaiming this class loader, eitherresolve the underlying issue, or move Google Collections to your system class path.";
/*     */ 
/*     */     public Class<?> loadFinalizer()
/*     */     {
/*     */       try
/*     */       {
/* 223 */         ClassLoader finalizerLoader = newLoader(getBaseUrl());
/* 224 */         return finalizerLoader.loadClass("com.google.appengine.repackaged.com.google.common.base.internal.Finalizer");
/*     */       } catch (Exception e) {
/* 226 */         FinalizableReferenceQueue.logger.log(Level.WARNING, "Could not load Finalizer in its own class loader.Loading Finalizer in the current class loader instead. As a result, you will not be ableto garbage collect this class loader. To support reclaiming this class loader, eitherresolve the underlying issue, or move Google Collections to your system class path.", e);
/* 227 */       }return null;
/*     */     }
/*     */ 
/*     */     URL getBaseUrl()
/*     */       throws IOException
/*     */     {
/* 236 */       String finalizerPath = "com.google.appengine.repackaged.com.google.common.base.internal.Finalizer".replace('.', '/') + ".class";
/* 237 */       URL finalizerUrl = getClass().getClassLoader().getResource(finalizerPath);
/* 238 */       if (finalizerUrl == null) {
/* 239 */         throw new FileNotFoundException(finalizerPath);
/*     */       }
/*     */ 
/* 243 */       String urlString = finalizerUrl.toString();
/* 244 */       if (!urlString.endsWith(finalizerPath)) {
/* 245 */         throw new IOException("Unsupported path style: " + urlString);
/*     */       }
/* 247 */       urlString = urlString.substring(0, urlString.length() - finalizerPath.length());
/* 248 */       return new URL(finalizerUrl, urlString);
/*     */     }
/*     */ 
/*     */     URLClassLoader newLoader(URL base)
/*     */     {
/* 253 */       return new URLClassLoader(new URL[] { base });
/*     */     }
/*     */   }
/*     */ 
/*     */   static class SystemLoader
/*     */     implements FinalizableReferenceQueue.FinalizerLoader
/*     */   {
/*     */     public Class<?> loadFinalizer()
/*     */     {
/*     */       ClassLoader systemLoader;
/*     */       try
/*     */       {
/* 183 */         systemLoader = ClassLoader.getSystemClassLoader();
/*     */       } catch (SecurityException e) {
/* 185 */         FinalizableReferenceQueue.logger.info("Not allowed to access system class loader.");
/* 186 */         return null;
/*     */       }
/* 188 */       if (systemLoader != null) {
/*     */         try {
/* 190 */           return systemLoader.loadClass("com.google.appengine.repackaged.com.google.common.base.internal.Finalizer");
/*     */         }
/*     */         catch (ClassNotFoundException e) {
/* 193 */           return null;
/*     */         }
/*     */       }
/* 196 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface FinalizerLoader
/*     */   {
/*     */     public abstract Class<?> loadFinalizer();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.FinalizableReferenceQueue
 * JD-Core Version:    0.6.0
 */