/*     */ package com.google.appengine.repackaged.com.google.protobuf;
/*     */ 
/*     */ public final class WireFormat
/*     */ {
/*     */   public static final int WIRETYPE_VARINT = 0;
/*     */   public static final int WIRETYPE_FIXED64 = 1;
/*     */   public static final int WIRETYPE_LENGTH_DELIMITED = 2;
/*     */   public static final int WIRETYPE_START_GROUP = 3;
/*     */   public static final int WIRETYPE_END_GROUP = 4;
/*     */   public static final int WIRETYPE_FIXED32 = 5;
/*     */   static final int TAG_TYPE_BITS = 3;
/*     */   static final int TAG_TYPE_MASK = 7;
/*     */   static final int MESSAGE_SET_ITEM = 1;
/*     */   static final int MESSAGE_SET_TYPE_ID = 2;
/*     */   static final int MESSAGE_SET_MESSAGE = 3;
/* 127 */   static final int MESSAGE_SET_ITEM_TAG = makeTag(1, 3);
/*     */ 
/* 129 */   static final int MESSAGE_SET_ITEM_END_TAG = makeTag(1, 4);
/*     */ 
/* 131 */   static final int MESSAGE_SET_TYPE_ID_TAG = makeTag(2, 0);
/*     */ 
/* 133 */   static final int MESSAGE_SET_MESSAGE_TAG = makeTag(3, 2);
/*     */ 
/*     */   static int getTagWireType(int tag)
/*     */   {
/*  32 */     return tag & 0x7;
/*     */   }
/*     */ 
/*     */   public static int getTagFieldNumber(int tag)
/*     */   {
/*  37 */     return tag >>> 3;
/*     */   }
/*     */ 
/*     */   static int makeTag(int fieldNumber, int wireType)
/*     */   {
/*  42 */     return fieldNumber << 3 | wireType;
/*     */   }
/*     */ 
/*     */   public static enum FieldType
/*     */   {
/*  80 */     DOUBLE(WireFormat.JavaType.DOUBLE, 1), 
/*  81 */     FLOAT(WireFormat.JavaType.FLOAT, 5), 
/*  82 */     INT64(WireFormat.JavaType.LONG, 0), 
/*  83 */     UINT64(WireFormat.JavaType.LONG, 0), 
/*  84 */     INT32(WireFormat.JavaType.INT, 0), 
/*  85 */     FIXED64(WireFormat.JavaType.LONG, 1), 
/*  86 */     FIXED32(WireFormat.JavaType.INT, 5), 
/*  87 */     BOOL(WireFormat.JavaType.BOOLEAN, 0), 
/*  88 */     STRING(WireFormat.JavaType.STRING, 2), 
/*     */ 
/*  91 */     GROUP(WireFormat.JavaType.MESSAGE, 3), 
/*     */ 
/*  94 */     MESSAGE(WireFormat.JavaType.MESSAGE, 2), 
/*     */ 
/*  97 */     BYTES(WireFormat.JavaType.BYTE_STRING, 2), 
/*     */ 
/* 100 */     UINT32(WireFormat.JavaType.INT, 0), 
/* 101 */     ENUM(WireFormat.JavaType.ENUM, 0), 
/* 102 */     SFIXED32(WireFormat.JavaType.INT, 5), 
/* 103 */     SFIXED64(WireFormat.JavaType.LONG, 1), 
/* 104 */     SINT32(WireFormat.JavaType.INT, 0), 
/* 105 */     SINT64(WireFormat.JavaType.LONG, 0);
/*     */ 
/*     */     private final WireFormat.JavaType javaType;
/*     */     private final int wireType;
/*     */ 
/* 108 */     private FieldType(WireFormat.JavaType javaType, int wireType) { this.javaType = javaType;
/* 109 */       this.wireType = wireType;
/*     */     }
/*     */ 
/*     */     public WireFormat.JavaType getJavaType()
/*     */     {
/* 115 */       return this.javaType; } 
/* 116 */     public int getWireType() { return this.wireType; } 
/*     */     public boolean isPackable() {
/* 118 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum JavaType
/*     */   {
/*  50 */     INT(Integer.valueOf(0)), 
/*  51 */     LONG(Long.valueOf(0L)), 
/*  52 */     FLOAT(Float.valueOf(0.0F)), 
/*  53 */     DOUBLE(Double.valueOf(0.0D)), 
/*  54 */     BOOLEAN(Boolean.valueOf(false)), 
/*  55 */     STRING(""), 
/*  56 */     BYTE_STRING(ByteString.EMPTY), 
/*  57 */     ENUM(null), 
/*  58 */     MESSAGE(null);
/*     */ 
/*     */     private final Object defaultDefault;
/*     */ 
/*  61 */     private JavaType(Object defaultDefault) { this.defaultDefault = defaultDefault;
/*     */     }
/*     */ 
/*     */     Object getDefaultDefault()
/*     */     {
/*  69 */       return this.defaultDefault;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.WireFormat
 * JD-Core Version:    0.6.0
 */