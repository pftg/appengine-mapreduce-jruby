/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ @GwtCompatible
/*     */ @GoogleInternal
/*     */ public abstract class DiscreteType<C extends Comparable>
/*     */ {
/*     */   public abstract C next(C paramC);
/*     */ 
/*     */   public abstract C previous(C paramC);
/*     */ 
/*     */   public abstract long distance(C paramC1, C paramC2);
/*     */ 
/*     */   public C minValue()
/*     */   {
/* 102 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */   public C maxValue()
/*     */   {
/* 117 */     throw new NoSuchElementException();
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.DiscreteType
 * JD-Core Version:    0.6.0
 */