/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Joiner;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ final class RegularImmutableMap<K, V> extends ImmutableMap<K, V>
/*     */ {
/*     */   private final transient Map.Entry<K, V>[] entries;
/*     */   private final transient Object[] table;
/*     */   private final transient int mask;
/*     */   private final transient int keySetHashCode;
/*     */   private transient ImmutableSet<Map.Entry<K, V>> entrySet;
/*     */   private transient ImmutableSet<K> keySet;
/*     */   private transient ImmutableCollection<V> values;
/*     */   private static final long serialVersionUID = 0L;
/*     */ 
/*     */   RegularImmutableMap(Map.Entry<?, ?>[] immutableEntries)
/*     */   {
/*  41 */     Map.Entry[] tmp = (Map.Entry[])immutableEntries;
/*  42 */     this.entries = tmp;
/*     */ 
/*  44 */     int tableSize = Hashing.chooseTableSize(immutableEntries.length);
/*  45 */     this.table = new Object[tableSize * 2];
/*  46 */     this.mask = (tableSize - 1);
/*     */ 
/*  48 */     int keySetHashCodeMutable = 0;
/*  49 */     for (Map.Entry entry : this.entries) {
/*  50 */       Object key = entry.getKey();
/*  51 */       int keyHashCode = key.hashCode();
/*  52 */       for (int i = Hashing.smear(keyHashCode); ; i++) {
/*  53 */         int index = (i & this.mask) * 2;
/*  54 */         Object existing = this.table[index];
/*  55 */         if (existing == null) {
/*  56 */           Object value = entry.getValue();
/*  57 */           this.table[index] = key;
/*  58 */           this.table[(index + 1)] = value;
/*  59 */           keySetHashCodeMutable += keyHashCode;
/*  60 */           break;
/*  61 */         }if (existing.equals(key)) {
/*  62 */           throw new IllegalArgumentException("duplicate key: " + key);
/*     */         }
/*     */       }
/*     */     }
/*  66 */     this.keySetHashCode = keySetHashCodeMutable;
/*     */   }
/*     */ 
/*     */   public V get(Object key) {
/*  70 */     if (key == null) {
/*  71 */       return null;
/*     */     }
/*  73 */     for (int i = Hashing.smear(key.hashCode()); ; i++) {
/*  74 */       int index = (i & this.mask) * 2;
/*  75 */       Object candidate = this.table[index];
/*  76 */       if (candidate == null) {
/*  77 */         return null;
/*     */       }
/*  79 */       if (!candidate.equals(key)) {
/*     */         continue;
/*     */       }
/*  82 */       Object value = this.table[(index + 1)];
/*  83 */       return value;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  89 */     return this.entries.length;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/*  97 */     if (value == null) {
/*  98 */       return false;
/*     */     }
/* 100 */     for (Map.Entry entry : this.entries) {
/* 101 */       if (entry.getValue().equals(value)) {
/* 102 */         return true;
/*     */       }
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/*     */   {
/* 116 */     ImmutableSet es = this.entrySet;
/* 117 */     return es == null ? (this.entrySet = new EntrySet(this)) : es;
/*     */   }
/*     */ 
/*     */   public ImmutableSet<K> keySet()
/*     */   {
/* 142 */     ImmutableSet ks = this.keySet;
/* 143 */     return ks == null ? (this.keySet = new KeySet(this)) : ks;
/*     */   }
/*     */ 
/*     */   public ImmutableCollection<V> values()
/*     */   {
/* 168 */     ImmutableCollection v = this.values;
/* 169 */     return v == null ? (this.values = new Values(this)) : v;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 201 */     StringBuilder result = new StringBuilder(size() * 16).append('{');
/* 202 */     Collections2.standardJoiner.appendTo(result, this.entries);
/* 203 */     return '}';
/*     */   }
/*     */ 
/*     */   private static class Values<V> extends ImmutableCollection<V>
/*     */   {
/*     */     final RegularImmutableMap<?, V> map;
/*     */ 
/*     */     Values(RegularImmutableMap<?, V> map)
/*     */     {
/* 177 */       this.map = map;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 181 */       return this.map.entries.length;
/*     */     }
/*     */ 
/*     */     public UnmodifiableIterator<V> iterator() {
/* 185 */       return new AbstractIterator() {
/* 186 */         int index = 0;
/*     */ 
/* 188 */         protected V computeNext() { return this.index < RegularImmutableMap.Values.this.map.entries.length ? RegularImmutableMap.Values.this.map.entries[(this.index++)].getValue() : endOfData();
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public boolean contains(Object target)
/*     */     {
/* 196 */       return this.map.containsValue(target);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class KeySet<K, V> extends ImmutableSet.TransformedImmutableSet<Map.Entry<K, V>, K>
/*     */   {
/*     */     final RegularImmutableMap<K, V> map;
/*     */ 
/*     */     KeySet(RegularImmutableMap<K, V> map)
/*     */     {
/* 152 */       super(map.keySetHashCode);
/* 153 */       this.map = map;
/*     */     }
/*     */ 
/*     */     K transform(Map.Entry<K, V> element) {
/* 157 */       return element.getKey();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object target) {
/* 161 */       return this.map.containsKey(target);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EntrySet<K, V> extends ImmutableSet.ArrayImmutableSet<Map.Entry<K, V>>
/*     */   {
/*     */     final transient RegularImmutableMap<K, V> map;
/*     */ 
/*     */     EntrySet(RegularImmutableMap<K, V> map)
/*     */     {
/* 125 */       super();
/* 126 */       this.map = map;
/*     */     }
/*     */ 
/*     */     public boolean contains(Object target) {
/* 130 */       if ((target instanceof Map.Entry)) {
/* 131 */         Map.Entry entry = (Map.Entry)target;
/* 132 */         Object mappedValue = this.map.get(entry.getKey());
/* 133 */         return (mappedValue != null) && (mappedValue.equals(entry.getValue()));
/*     */       }
/* 135 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.RegularImmutableMap
 * JD-Core Version:    0.6.0
 */