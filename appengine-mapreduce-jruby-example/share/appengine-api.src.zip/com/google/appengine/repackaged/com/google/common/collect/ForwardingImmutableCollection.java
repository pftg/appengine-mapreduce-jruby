package com.google.appengine.repackaged.com.google.common.collect;

import com.google.common.annotations.GoogleInternal;
import com.google.common.annotations.GwtCompatible;

@GoogleInternal
@GwtCompatible(emulated=true)
class ForwardingImmutableCollection
{
}

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ForwardingImmutableCollection
 * JD-Core Version:    0.6.0
 */