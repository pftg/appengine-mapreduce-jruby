/*    */ package com.google.appengine.api.capabilities;
/*    */ 
/*    */ import com.google.appengine.repackaged.com.google.protobuf.InvalidProtocolBufferException;
/*    */ import com.google.apphosting.api.ApiProxy;
/*    */ import com.google.apphosting.api.ApiProxy.ArgumentException;
/*    */ 
/*    */ class CapabilitiesServiceImpl
/*    */   implements CapabilitiesService
/*    */ {
/*    */   private static final String PACKAGE_NAME = "capability_service";
/*    */   private static final String METHOD_NAME = "IsEnabled";
/*    */ 
/*    */   public CapabilityState getStatus(Capability capability)
/*    */   {
/* 25 */     CapabilityServicePb.IsEnabledRequest.Builder builder = CapabilityServicePb.IsEnabledRequest.newBuilder();
/* 26 */     builder.setPackage(capability.getPackageName());
/* 27 */     builder.addCapability(capability.getName());
/* 28 */     CapabilityServicePb.IsEnabledRequest request = builder.build();
/*    */     try
/*    */     {
/* 31 */       byte[] responseBytes = ApiProxy.makeSyncCall("capability_service", "IsEnabled", request.toByteArray());
/*    */ 
/* 33 */       CapabilityServicePb.IsEnabledResponse response = CapabilityServicePb.IsEnabledResponse.parseFrom(responseBytes);
/* 34 */       CapabilityServicePb.IsEnabledResponse.SummaryStatus status = response.getSummaryStatus();
/*    */ 
/* 36 */       long timeUntilScheduled = -1L;
/*    */       CapabilityStatus statusValue;
/* 37 */       switch (1.$SwitchMap$com$google$appengine$api$capabilities$CapabilityServicePb$IsEnabledResponse$SummaryStatus[status.ordinal()]) {
/*    */       case 1:
/* 39 */         statusValue = CapabilityStatus.ENABLED;
/* 40 */         break;
/*    */       case 2:
/* 42 */         timeUntilScheduled = 0L;
/* 43 */         statusValue = CapabilityStatus.SCHEDULED_MAINTENANCE;
/* 44 */         break;
/*    */       case 3:
/* 46 */         timeUntilScheduled = response.getTimeUntilScheduled();
/* 47 */         statusValue = CapabilityStatus.SCHEDULED_MAINTENANCE;
/* 48 */         break;
/*    */       case 4:
/* 50 */         statusValue = CapabilityStatus.DISABLED;
/* 51 */         break;
/*    */       default:
/* 53 */         statusValue = CapabilityStatus.UNKNOWN;
/*    */       }
/*    */ 
/* 57 */       return new CapabilityState(capability, statusValue, timeUntilScheduled);
/*    */     } catch (InvalidProtocolBufferException ex) {
/*    */     }
/* 60 */     throw new ApiProxy.ArgumentException("capability_service", "IsEnabled");
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.capabilities.CapabilitiesServiceImpl
 * JD-Core Version:    0.6.0
 */