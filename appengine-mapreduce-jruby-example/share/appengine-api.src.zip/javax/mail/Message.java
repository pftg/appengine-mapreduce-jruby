/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import javax.mail.search.SearchTerm;
/*     */ 
/*     */ public abstract class Message
/*     */   implements Part
/*     */ {
/*     */   protected int msgnum;
/*     */   protected boolean expunged;
/*     */   protected Folder folder;
/*     */   protected Session session;
/*     */ 
/*     */   protected Message()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Message(Folder folder, int msgnum)
/*     */   {
/* 101 */     this.folder = folder;
/* 102 */     this.msgnum = msgnum;
/*     */ 
/* 104 */     this.session = folder.getStore().getSession();
/*     */   }
/*     */ 
/*     */   protected Message(Session session)
/*     */   {
/* 113 */     this.session = session;
/*     */   }
/*     */ 
/*     */   public abstract Address[] getFrom()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setFrom()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setFrom(Address paramAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void addFrom(Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Address[] getRecipients(RecipientType paramRecipientType)
/*     */     throws MessagingException;
/*     */ 
/*     */   public Address[] getAllRecipients()
/*     */     throws MessagingException
/*     */   {
/* 170 */     Address[] to = getRecipients(RecipientType.TO);
/* 171 */     Address[] cc = getRecipients(RecipientType.CC);
/* 172 */     Address[] bcc = getRecipients(RecipientType.BCC);
/* 173 */     if ((to == null) && (cc == null) && (bcc == null)) {
/* 174 */       return null;
/*     */     }
/* 176 */     int length = (to != null ? to.length : 0) + (cc != null ? cc.length : 0) + (bcc != null ? bcc.length : 0);
/* 177 */     Address[] result = new Address[length];
/* 178 */     int j = 0;
/* 179 */     if (to != null) {
/* 180 */       for (int i = 0; i < to.length; i++) {
/* 181 */         result[(j++)] = to[i];
/*     */       }
/*     */     }
/* 184 */     if (cc != null) {
/* 185 */       for (int i = 0; i < cc.length; i++) {
/* 186 */         result[(j++)] = cc[i];
/*     */       }
/*     */     }
/* 189 */     if (bcc != null) {
/* 190 */       for (int i = 0; i < bcc.length; i++) {
/* 191 */         result[(j++)] = bcc[i];
/*     */       }
/*     */     }
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   public abstract void setRecipients(RecipientType paramRecipientType, Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void setRecipient(RecipientType type, Address address)
/*     */     throws MessagingException
/*     */   {
/* 214 */     setRecipients(type, new Address[] { address });
/*     */   }
/*     */ 
/*     */   public abstract void addRecipients(RecipientType paramRecipientType, Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void addRecipient(RecipientType type, Address address)
/*     */     throws MessagingException
/*     */   {
/* 234 */     addRecipients(type, new Address[] { address });
/*     */   }
/*     */ 
/*     */   public Address[] getReplyTo()
/*     */     throws MessagingException
/*     */   {
/* 247 */     return getFrom();
/*     */   }
/*     */ 
/*     */   public void setReplyTo(Address[] addresses)
/*     */     throws MessagingException
/*     */   {
/* 259 */     throw new MethodNotSupportedException("setReplyTo not supported");
/*     */   }
/*     */ 
/*     */   public abstract String getSubject()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setSubject(String paramString)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Date getSentDate()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setSentDate(Date paramDate)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Date getReceivedDate()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Flags getFlags()
/*     */     throws MessagingException;
/*     */ 
/*     */   public boolean isSet(Flags.Flag flag)
/*     */     throws MessagingException
/*     */   {
/* 319 */     return getFlags().contains(flag);
/*     */   }
/*     */ 
/*     */   public abstract void setFlags(Flags paramFlags, boolean paramBoolean)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void setFlag(Flags.Flag flag, boolean set)
/*     */     throws MessagingException
/*     */   {
/* 341 */     setFlags(new Flags(flag), set);
/*     */   }
/*     */ 
/*     */   public int getMessageNumber()
/*     */   {
/* 354 */     return this.msgnum;
/*     */   }
/*     */ 
/*     */   protected void setMessageNumber(int number)
/*     */   {
/* 364 */     this.msgnum = number;
/*     */   }
/*     */ 
/*     */   public Folder getFolder()
/*     */   {
/* 374 */     return this.folder;
/*     */   }
/*     */ 
/*     */   public boolean isExpunged()
/*     */   {
/* 384 */     return this.expunged;
/*     */   }
/*     */ 
/*     */   protected void setExpunged(boolean expunged)
/*     */   {
/* 393 */     this.expunged = expunged;
/*     */   }
/*     */ 
/*     */   public abstract Message reply(boolean paramBoolean)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void saveChanges()
/*     */     throws MessagingException;
/*     */ 
/*     */   public boolean match(SearchTerm term)
/*     */     throws MessagingException
/*     */   {
/* 432 */     return term.match(this);
/*     */   }
/*     */ 
/*     */   public static class RecipientType
/*     */     implements Serializable
/*     */   {
/*  39 */     public static final RecipientType TO = new RecipientType("To");
/*     */ 
/*  43 */     public static final RecipientType CC = new RecipientType("Cc");
/*     */ 
/*  47 */     public static final RecipientType BCC = new RecipientType("Bcc");
/*     */     protected String type;
/*     */ 
/*     */     protected RecipientType(String type)
/*     */     {
/*  51 */       this.type = type;
/*     */     }
/*     */ 
/*     */     protected Object readResolve() throws ObjectStreamException {
/*  55 */       if (this.type.equals("To"))
/*  56 */         return TO;
/*  57 */       if (this.type.equals("Cc"))
/*  58 */         return CC;
/*  59 */       if (this.type.equals("Bcc")) {
/*  60 */         return BCC;
/*     */       }
/*  62 */       throw new InvalidObjectException("Invalid RecipientType: " + this.type);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  67 */       return this.type;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     javax.mail.Message
 * JD-Core Version:    0.6.0
 */