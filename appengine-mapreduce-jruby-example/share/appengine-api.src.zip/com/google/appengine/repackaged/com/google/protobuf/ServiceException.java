/*    */ package com.google.appengine.repackaged.com.google.protobuf;
/*    */ 
/*    */ public class ServiceException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -1219262335729891920L;
/*    */ 
/*    */   public ServiceException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ 
/*    */   public ServiceException(Throwable cause) {
/* 17 */     super(cause);
/*    */   }
/*    */ 
/*    */   public ServiceException(String message, Throwable cause) {
/* 21 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.protobuf.ServiceException
 * JD-Core Version:    0.6.0
 */