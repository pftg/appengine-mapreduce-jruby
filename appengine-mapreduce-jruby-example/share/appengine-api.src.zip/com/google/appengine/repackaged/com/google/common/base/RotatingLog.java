/*    */ package com.google.appengine.repackaged.com.google.common.base;
/*    */ 
/*    */ import com.google.common.annotations.GoogleInternal;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.text.SimpleDateFormat;
/*    */ 
/*    */ @Deprecated
/*    */ @GoogleInternal
/*    */ public final class RotatingLog extends LogWriter
/*    */ {
/* 36 */   private static final SimpleDateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyMMdd HH:mm:ss ");
/*    */ 
/*    */   RotatingLog(String filePath, long rotateSize)
/*    */     throws IOException
/*    */   {
/* 44 */     this(filePath, DEFAULT_DATE_FORMAT, rotateSize);
/*    */   }
/*    */ 
/*    */   public RotatingLog(String filePath, SimpleDateFormat dateFormat, long rotateSize)
/*    */     throws IOException
/*    */   {
/* 54 */     if (!Log2.useJavaLogging) {
/* 55 */       this.dateFormatter = dateFormat;
/* 56 */       RotatingLogStream rls = new RotatingLogStream(filePath);
/* 57 */       rls.setRotateSize(rotateSize);
/* 58 */       this.writer = new BufferedWriter(new OutputStreamWriter(rls));
/*    */     } else {
/* 60 */       createAndSetJavaLogger(filePath, filePath, null, dateFormat, RotatingLogStream.kDefaultDateFormat, rotateSize);
/*    */     }
/*    */   }
/*    */ 
/*    */   public RotatingLog(String filePath, String linkName, String extension, SimpleDateFormat dateFormat, long rotateSize)
/*    */     throws IOException
/*    */   {
/* 88 */     if (!Log2.useJavaLogging) {
/* 89 */       this.dateFormatter = dateFormat;
/* 90 */       RotatingLogStream rls = new RotatingLogStream(filePath, linkName, extension, dateFormat);
/*    */ 
/* 94 */       rls.setRotateSize(rotateSize);
/* 95 */       this.writer = new BufferedWriter(new OutputStreamWriter(rls));
/*    */     } else {
/* 97 */       createAndSetJavaLogger(filePath, linkName, extension, dateFormat, dateFormat, rotateSize);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.base.RotatingLog
 * JD-Core Version:    0.6.0
 */