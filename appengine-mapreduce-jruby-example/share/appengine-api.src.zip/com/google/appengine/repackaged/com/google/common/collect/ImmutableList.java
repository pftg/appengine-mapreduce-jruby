/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.RandomAccess;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible(serializable=true, emulated=true)
/*     */ public abstract class ImmutableList<E> extends ImmutableCollection<E>
/*     */   implements List<E>, RandomAccess
/*     */ {
/*     */   public static <E> ImmutableList<E> of()
/*     */   {
/*  67 */     return EmptyImmutableList.INSTANCE;
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E element)
/*     */   {
/*  79 */     return new SingletonImmutableList(element);
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2)
/*     */   {
/*  88 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3)
/*     */   {
/*  97 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4)
/*     */   {
/* 106 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5)
/*     */   {
/* 115 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6)
/*     */   {
/* 124 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5, e6 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7)
/*     */   {
/* 134 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5, e6, e7 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8)
/*     */   {
/* 145 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9)
/*     */   {
/* 156 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10)
/*     */   {
/* 167 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10, E e11)
/*     */   {
/* 178 */     return new RegularImmutableList(copyIntoArray(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10, e11 }));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10, E e11, E e12, E[] others)
/*     */   {
/* 193 */     int paramCount = 12;
/* 194 */     Object[] array = new Object[12 + others.length];
/* 195 */     copyIntoArray(array, 0, new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10, e11, e12 });
/* 196 */     copyIntoArray(array, 12, others);
/* 197 */     return new RegularImmutableList(array);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static <E> ImmutableList<E> of(E[] elements)
/*     */   {
/* 208 */     switch (elements.length) {
/*     */     case 0:
/* 210 */       return of();
/*     */     case 1:
/* 212 */       return new SingletonImmutableList(elements[0]);
/*     */     }
/* 214 */     return new RegularImmutableList(copyIntoArray(elements));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> copyOf(Iterable<? extends E> elements)
/*     */   {
/* 228 */     Preconditions.checkNotNull(elements);
/* 229 */     return (elements instanceof Collection) ? copyOf((Collection)elements) : copyOf(elements.iterator());
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> copyOf(Collection<? extends E> elements)
/*     */   {
/* 255 */     if ((elements instanceof ImmutableCollection))
/*     */     {
/* 261 */       ImmutableCollection list = (ImmutableCollection)elements;
/* 262 */       return list.asList();
/*     */     }
/* 264 */     return copyFromCollection(elements);
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> copyOf(Iterator<? extends E> elements)
/*     */   {
/* 273 */     return copyFromCollection(Lists.newArrayList(elements));
/*     */   }
/*     */ 
/*     */   public static <E> ImmutableList<E> copyOf(E[] elements)
/*     */   {
/* 283 */     switch (elements.length) {
/*     */     case 0:
/* 285 */       return of();
/*     */     case 1:
/* 287 */       return new SingletonImmutableList(elements[0]);
/*     */     }
/* 289 */     return new RegularImmutableList(copyIntoArray(elements));
/*     */   }
/*     */ 
/*     */   private static <E> ImmutableList<E> copyFromCollection(Collection<? extends E> collection)
/*     */   {
/* 295 */     Object[] elements = collection.toArray();
/* 296 */     switch (elements.length) {
/*     */     case 0:
/* 298 */       return of();
/*     */     case 1:
/* 301 */       ImmutableList list = new SingletonImmutableList(elements[0]);
/* 302 */       return list;
/*     */     }
/* 304 */     return new RegularImmutableList(copyIntoArray(elements));
/*     */   }
/*     */ 
/*     */   public abstract UnmodifiableIterator<E> iterator();
/*     */ 
/*     */   public abstract int indexOf(@Nullable Object paramObject);
/*     */ 
/*     */   public abstract int lastIndexOf(@Nullable Object paramObject);
/*     */ 
/*     */   public abstract ImmutableList<E> subList(int paramInt1, int paramInt2);
/*     */ 
/*     */   public final boolean addAll(int index, Collection<? extends E> newElements)
/*     */   {
/* 336 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final E set(int index, E element)
/*     */   {
/* 345 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final void add(int index, E element)
/*     */   {
/* 354 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final E remove(int index)
/*     */   {
/* 363 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   private static Object[] copyIntoArray(Object[] source) {
/* 367 */     return copyIntoArray(new Object[source.length], 0, source);
/*     */   }
/*     */ 
/*     */   private static Object[] copyIntoArray(Object[] dest, int pos, Object[] source)
/*     */   {
/* 372 */     int index = pos;
/* 373 */     for (Object element : source) {
/* 374 */       if (element == null) {
/* 375 */         throw new NullPointerException("at index " + index);
/*     */       }
/* 377 */       dest[(index++)] = element;
/*     */     }
/* 379 */     return dest;
/*     */   }
/*     */ 
/*     */   public ImmutableList<E> asList()
/*     */   {
/* 388 */     return this;
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream stream)
/*     */     throws InvalidObjectException
/*     */   {
/* 408 */     throw new InvalidObjectException("Use SerializedForm");
/*     */   }
/*     */ 
/*     */   Object writeReplace() {
/* 412 */     return new SerializedForm(toArray());
/*     */   }
/*     */ 
/*     */   public static <E> Builder<E> builder()
/*     */   {
/* 420 */     return new Builder();
/*     */   }
/*     */ 
/*     */   public static final class Builder<E> extends ImmutableCollection.Builder<E>
/*     */   {
/* 440 */     private final ArrayList<E> contents = Lists.newArrayList();
/*     */ 
/*     */     public Builder<E> add(E element)
/*     */     {
/* 456 */       this.contents.add(Preconditions.checkNotNull(element));
/* 457 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterable<? extends E> elements)
/*     */     {
/* 469 */       if ((elements instanceof Collection)) {
/* 470 */         Collection collection = (Collection)elements;
/* 471 */         this.contents.ensureCapacity(this.contents.size() + collection.size());
/*     */       }
/* 473 */       super.addAll(elements);
/* 474 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> add(E[] elements)
/*     */     {
/* 486 */       this.contents.ensureCapacity(this.contents.size() + elements.length);
/* 487 */       super.add(elements);
/* 488 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder<E> addAll(Iterator<? extends E> elements)
/*     */     {
/* 500 */       super.addAll(elements);
/* 501 */       return this;
/*     */     }
/*     */ 
/*     */     public ImmutableList<E> build()
/*     */     {
/* 509 */       return ImmutableList.copyOf(this.contents);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SerializedForm
/*     */     implements Serializable
/*     */   {
/*     */     final Object[] elements;
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     SerializedForm(Object[] elements)
/*     */     {
/* 398 */       this.elements = elements;
/*     */     }
/*     */     Object readResolve() {
/* 401 */       return ImmutableList.copyOf(this.elements);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.ImmutableList
 * JD-Core Version:    0.6.0
 */