/*     */ package com.google.appengine.api.datastore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ class TransactionStackImpl
/*     */   implements TransactionStack
/*     */ {
/*     */   private final ThreadLocalTransactionStack stack;
/*     */ 
/*     */   public TransactionStackImpl()
/*     */   {
/*  31 */     this(new TransactionStackImpl.ThreadLocalTransactionStack.StaticMember());
/*     */   }
/*     */ 
/*     */   TransactionStackImpl(ThreadLocalTransactionStack stack)
/*     */   {
/*  41 */     this.stack = stack;
/*     */   }
/*     */ 
/*     */   public void push(Transaction txn) {
/*  45 */     getStack().addFirst(txn);
/*     */   }
/*     */ 
/*     */   public Transaction pop() {
/*     */     try {
/*  50 */       return (Transaction)getStack().removeFirst(); } catch (NoSuchElementException e) {
/*     */     }
/*  52 */     throw new IllegalStateException(e);
/*     */   }
/*     */ 
/*     */   public void remove(Transaction txn)
/*     */   {
/*  60 */     if (!getStack().remove(txn))
/*  61 */       throw new IllegalStateException("Attempted to deregister a transaction that is not currently registered.");
/*     */   }
/*     */ 
/*     */   public Transaction peek()
/*     */   {
/*     */     try
/*     */     {
/*  68 */       return (Transaction)getStack().getFirst(); } catch (NoSuchElementException e) {
/*     */     }
/*  70 */     throw new IllegalStateException(e);
/*     */   }
/*     */ 
/*     */   public Transaction peek(Transaction returnedIfNoTxn)
/*     */   {
/*  75 */     LinkedList stack = getStack();
/*  76 */     Transaction txn = stack.isEmpty() ? null : (Transaction)getStack().peek();
/*  77 */     return txn == null ? returnedIfNoTxn : txn;
/*     */   }
/*     */ 
/*     */   public Collection<Transaction> getAll()
/*     */   {
/*  82 */     return new ArrayList(getStack());
/*     */   }
/*     */ 
/*     */   LinkedList<Transaction> getStack() {
/*  86 */     return this.stack.get();
/*     */   }
/*     */ 
/*     */   public void clearAll() {
/*  90 */     getStack().clear();
/*     */   }
/*     */ 
/*     */   static abstract interface ThreadLocalTransactionStack
/*     */   {
/*     */     public abstract LinkedList<Transaction> get();
/*     */ 
/*     */     public static class StaticMember
/*     */       implements TransactionStackImpl.ThreadLocalTransactionStack
/*     */     {
/* 109 */       private static final ThreadLocal<LinkedList<Transaction>> STACK = new ThreadLocal()
/*     */       {
/*     */         protected LinkedList<Transaction> initialValue()
/*     */         {
/* 113 */           return new LinkedList();
/*     */         }
/* 109 */       };
/*     */ 
/*     */       public LinkedList<Transaction> get()
/*     */       {
/* 118 */         return (LinkedList)STACK.get();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.api.datastore.TransactionStackImpl
 * JD-Core Version:    0.6.0
 */