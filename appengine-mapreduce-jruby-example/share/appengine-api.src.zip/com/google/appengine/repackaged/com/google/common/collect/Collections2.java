/*     */ package com.google.appengine.repackaged.com.google.common.collect;
/*     */ 
/*     */ import com.google.appengine.repackaged.com.google.common.base.Function;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Joiner;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Preconditions;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Predicate;
/*     */ import com.google.appengine.repackaged.com.google.common.base.Predicates;
/*     */ import com.google.common.annotations.GoogleInternal;
/*     */ import com.google.common.annotations.GwtCompatible;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ @GwtCompatible
/*     */ public final class Collections2
/*     */ {
/* 377 */   static final Joiner standardJoiner = Joiner.on(", ");
/*     */ 
/*     */   @GoogleInternal
/*     */   public static <E> Collection<E> forIterable(Iterable<E> iterable)
/*     */   {
/*  94 */     Preconditions.checkNotNull(iterable);
/*     */ 
/*  96 */     if ((iterable instanceof Collection)) {
/*  97 */       return (Collection)iterable;
/*     */     }
/*     */ 
/* 100 */     return new AbstractCollection(iterable) {
/*     */       public Iterator<E> iterator() {
/* 102 */         return this.val$iterable.iterator();
/*     */       }
/*     */ 
/*     */       public int size() {
/* 106 */         return Iterables.size(this.val$iterable);
/*     */       }
/*     */ 
/*     */       public boolean isEmpty() {
/* 110 */         return Iterables.isEmpty(this.val$iterable);
/*     */       }
/*     */ 
/*     */       public boolean removeAll(Collection<?> c) {
/* 114 */         return Iterators.removeAll(iterator(), c);
/*     */       }
/*     */ 
/*     */       public boolean retainAll(Collection<?> c) {
/* 118 */         return Iterators.retainAll(iterator(), c);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   static boolean containsAll(Collection<?> self, Collection<?> c)
/*     */   {
/* 137 */     Preconditions.checkNotNull(self);
/* 138 */     for (Iterator i$ = c.iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 139 */       if (!self.contains(o)) {
/* 140 */         return false;
/*     */       }
/*     */     }
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */   static <E> Collection<E> toCollection(Iterable<E> iterable)
/*     */   {
/* 152 */     return (iterable instanceof Collection) ? (Collection)iterable : Lists.newArrayList(iterable.iterator());
/*     */   }
/*     */ 
/*     */   public static <E> Collection<E> filter(Collection<E> unfiltered, Predicate<? super E> predicate)
/*     */   {
/* 181 */     if ((unfiltered instanceof FilteredCollection))
/*     */     {
/* 184 */       return ((FilteredCollection)unfiltered).createCombined(predicate);
/*     */     }
/*     */ 
/* 187 */     return new FilteredCollection((Collection)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*     */   }
/*     */ 
/*     */   static boolean safeContains(Collection<?> collection, Object object)
/*     */   {
/*     */     try
/*     */     {
/* 197 */       return collection.contains(object); } catch (ClassCastException e) {
/*     */     }
/* 199 */     return false;
/*     */   }
/*     */ 
/*     */   public static <F, T> Collection<T> transform(Collection<F> fromCollection, Function<? super F, T> function)
/*     */   {
/* 335 */     return new TransformedCollection(fromCollection, function);
/*     */   }
/*     */ 
/*     */   static boolean setEquals(Set<?> thisSet, @Nullable Object object)
/*     */   {
/* 366 */     if (object == thisSet) {
/* 367 */       return true;
/*     */     }
/* 369 */     if ((object instanceof Set)) {
/* 370 */       Set thatSet = (Set)object;
/* 371 */       return (thisSet.size() == thatSet.size()) && (thisSet.containsAll(thatSet));
/*     */     }
/*     */ 
/* 374 */     return false;
/*     */   }
/*     */ 
/*     */   static class TransformedCollection<F, T> extends AbstractCollection<T>
/*     */   {
/*     */     final Collection<F> fromCollection;
/*     */     final Function<? super F, ? extends T> function;
/*     */ 
/*     */     TransformedCollection(Collection<F> fromCollection, Function<? super F, ? extends T> function)
/*     */     {
/* 344 */       this.fromCollection = ((Collection)Preconditions.checkNotNull(fromCollection));
/* 345 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 349 */       this.fromCollection.clear();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 353 */       return this.fromCollection.isEmpty();
/*     */     }
/*     */ 
/*     */     public Iterator<T> iterator() {
/* 357 */       return Iterators.transform(this.fromCollection.iterator(), this.function);
/*     */     }
/*     */ 
/*     */     public int size() {
/* 361 */       return this.fromCollection.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class FilteredCollection<E>
/*     */     implements Collection<E>
/*     */   {
/*     */     final Collection<E> unfiltered;
/*     */     final Predicate<? super E> predicate;
/*     */ 
/*     */     FilteredCollection(Collection<E> unfiltered, Predicate<? super E> predicate)
/*     */     {
/* 209 */       this.unfiltered = unfiltered;
/* 210 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     FilteredCollection<E> createCombined(Predicate<? super E> newPredicate) {
/* 214 */       return new FilteredCollection(this.unfiltered, Predicates.and(this.predicate, newPredicate));
/*     */     }
/*     */ 
/*     */     public boolean add(E element)
/*     */     {
/* 220 */       Preconditions.checkArgument(this.predicate.apply(element));
/* 221 */       return this.unfiltered.add(element);
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection<? extends E> collection) {
/* 225 */       for (Iterator i$ = collection.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 226 */         Preconditions.checkArgument(this.predicate.apply(element));
/*     */       }
/* 228 */       return this.unfiltered.addAll(collection);
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 232 */       Iterables.removeIf(this.unfiltered, this.predicate);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object element)
/*     */     {
/*     */       try
/*     */       {
/* 240 */         Object e = element;
/* 241 */         return (this.predicate.apply(e)) && (this.unfiltered.contains(element));
/*     */       } catch (NullPointerException e) {
/* 243 */         return false; } catch (ClassCastException e) {
/*     */       }
/* 245 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection<?> collection)
/*     */     {
/* 250 */       for (Iterator i$ = collection.iterator(); i$.hasNext(); ) { Object element = i$.next();
/* 251 */         if (!contains(element)) {
/* 252 */           return false;
/*     */         }
/*     */       }
/* 255 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 259 */       return !Iterators.any(this.unfiltered.iterator(), this.predicate);
/*     */     }
/*     */ 
/*     */     public Iterator<E> iterator() {
/* 263 */       return Iterators.filter(this.unfiltered.iterator(), this.predicate);
/*     */     }
/*     */ 
/*     */     public boolean remove(Object element)
/*     */     {
/*     */       try
/*     */       {
/* 271 */         Object e = element;
/* 272 */         return (this.predicate.apply(e)) && (this.unfiltered.remove(element));
/*     */       } catch (NullPointerException e) {
/* 274 */         return false; } catch (ClassCastException e) {
/*     */       }
/* 276 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> collection)
/*     */     {
/* 281 */       Preconditions.checkNotNull(collection);
/* 282 */       Predicate combinedPredicate = new Predicate(collection) {
/*     */         public boolean apply(E input) {
/* 284 */           return (Collections2.FilteredCollection.this.predicate.apply(input)) && (this.val$collection.contains(input));
/*     */         }
/*     */       };
/* 287 */       return Iterables.removeIf(this.unfiltered, combinedPredicate);
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> collection) {
/* 291 */       Preconditions.checkNotNull(collection);
/* 292 */       Predicate combinedPredicate = new Predicate(collection) {
/*     */         public boolean apply(E input) {
/* 294 */           return (Collections2.FilteredCollection.this.predicate.apply(input)) && (!this.val$collection.contains(input));
/*     */         }
/*     */       };
/* 297 */       return Iterables.removeIf(this.unfiltered, combinedPredicate);
/*     */     }
/*     */ 
/*     */     public int size() {
/* 301 */       return Iterators.size(iterator());
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 306 */       return Lists.newArrayList(iterator()).toArray();
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] array) {
/* 310 */       return Lists.newArrayList(iterator()).toArray(array);
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 314 */       return Iterators.toString(iterator());
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/pftg/dev/appengine-mapreduce-jruby/appengine-mapreduce/sdk/appengine-java-sdk-1.3.7/lib/impl/appengine-api.jar
 * Qualified Name:     com.google.appengine.repackaged.com.google.common.collect.Collections2
 * JD-Core Version:    0.6.0
 */